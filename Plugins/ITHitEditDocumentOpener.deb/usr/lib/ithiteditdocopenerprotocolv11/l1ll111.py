#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import gi
gi.require_version(l111l (u"ࠨࡉࡷ࡯ࠬঽ"), l111l (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11llll1
import logging
logger = logging.getLogger(l111l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1ll1l1l(Gtk.Window):
    def __init__(self, l1ll1l1111, l1l11l11ll):
        Gtk.Window.__init__(self)
        self.l1l1l=30
        self.l1l1ll1111 = False
        self.service = l1ll1l1111
        self.l1ll111l=l1l11l11ll
        self.l1111ll=l11llll1.l1l11ll1
        self.l1ll11ll11 = Gtk.ListStore(str)
        self.l1ll11ll1l()
    def l1ll11l11l(self, service):
        l1l11l1l1l = self.l1111ll.l1l1l1ll(l111l (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l11l1l1l
    def l1ll11ll1l(self, l1ll1l1111=None):
        if l1ll1l1111:
            self.l1ll11ll11.clear()
            l1l1l1111l=self.l1ll11l11l(l1ll1l1111)
            self.l1ll11ll11.append([l111l (u"ࠧࠨু")])
            for l1ll111l in l1l1l1111l:
                self.l1ll11ll11.append([l1ll111l])
        else:
            self.l1ll11ll11.clear()
            self.l1ll11ll11.append([l111l (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1l1l11l(self, widget, data=None):
        l1ll1l1lll= widget.get_active()
        if data == l111l (u"ࠢ࠲ࠤৃ") and l1ll1l1lll:
            self.l1ll11ll1l()
            self.l1ll1l1ll1.set_active(0)
            self.l1ll1lll11.set_text(l111l (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1lll11.set_sensitive(False)
            self.l1ll1l1ll1.set_sensitive(False)
        else:
            self.l1ll11ll1l(l1ll1l1111=self.service)
            self.l1ll1l1ll1.set_active(0)
            self.l1ll1lll11.set_text(l111l (u"ࠤࠥ৅"))
            self.l1ll1l1ll1.set_sensitive(True)
            self.l1ll1lll11.set_sensitive(True)
    def l1ll11lll1(self, widget):
        if widget.get_active():
            l1ll111l = widget.get_child().get_text()
        else:
            l1ll111l = self.l1ll11ll11[widget.get_active()][0]
        password = self.l1l1l11ll1(self.service, l1ll111l)
        if password:
            self.l1ll1lll11.set_text(password)
        else:
            self.l1ll1lll11.set_text(l111l (u"ࠥࠦ৆"))
    def l1l1l1l1ll(self, l1ll111l, pwd, service):
        keyring.set_password(service, l1ll111l, pwd)
        l1l11l1l1l=self.l1111ll.l1l1l1ll(l111l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1ll111l in l1l11l1l1l:
            value = self.l1111ll.get_value(l111l (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1111ll.l11ll111(l111l (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l111l (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1ll111l))
    def l1l1l11ll1(self, service, l1ll111l):
        l1l1l1llll = keyring.get_password(service, l1ll111l)
        return l1l1l1llll
    def l1ll1l11ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1ll11ll(self, widget, data=None):
        self.l1l1ll1111=widget.get_active()
    def l1ll1l1(self, message, title=l111l (u"ࠨࠩো"), l11lll1ll=True):
        if l11lll1ll:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1l1l1l = Gtk.MessageDialog(self,
            l1l11l1l11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1l1l1l.set_title(title)
        l1ll1l1l1l.set_default_response(Gtk.ResponseType.OK)
        l1ll1ll1ll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll11l1ll = Gtk.VBox()
        l1l1ll1ll1 = Gtk.Box(spacing=1)
        l1l1ll1ll1.set_homogeneous(False)
        l1l1l11lll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l11lll.set_homogeneous(False)
        l1l11ll1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11ll1l1.set_homogeneous(False)
        l1l1ll1ll1.pack_start(l1l1l11lll, True, True, 0)
        l1l1ll1ll1.pack_start(l1l11ll1l1, True, True, 0)
        l1l1l1l111 = l1ll1l1l1l.get_content_area()
        l1l1l1ll11 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l111.pack_start(l1l1l1ll11, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1llll11 = Gtk.Label()
        l1ll111ll1 = Gtk.Label()
        l1ll111ll1.set_text(l111l (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1ll111ll1, True, True, 0)
        l1l1llll11.set_text(l111l (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1llll11.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1llll11, 0, 1, 0, 1)
        l1ll111l11 = Gtk.RadioButton.new_with_label_from_widget(None, l111l (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll111l11.connect(l111l (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1l1l11l, l111l (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll111l11, 1, 2, 0, 1)
        l1l11ll11l = Gtk.RadioButton.new_with_label_from_widget(l1ll111l11, l111l (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l11ll11l.connect(l111l (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1l1l11l, l111l (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l11ll11l, 1, 2, 1, 2)
        l1l11lll11 = Gtk.Label()
        l1l11lll11.set_text(l111l (u"ࠥࠤࠧ৔"))
        table.attach(l1l11lll11, 0, 1, 4, 6)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l111l (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll1111ll.set_justify(Gtk.Justification.RIGHT)
        l1ll1111ll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1l1ll1 = Gtk.ComboBox.new_with_model_and_entry(self.l1ll11ll11)
        self.l1ll1l1ll1.set_entry_text_column(0)
        table.attach(l1ll1111ll, 0, 1, 6, 8)
        table.attach(self.l1ll1l1ll1, 1, 3, 6, 8)
        self.l1ll1l1ll1.connect(l111l (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1ll11lll1)
        l1l11ll1ll = Gtk.Label()
        l1l11ll1ll.set_text(l111l (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l11ll1ll.set_justify(Gtk.Justification.RIGHT)
        l1l11ll1ll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1lll11 = Gtk.Entry()
        self.l1ll1lll11.set_visibility(False)
        self.l1ll1lll11.connect(l111l (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1ll1l11ll, l1ll1l1l1l)
        table.attach(l1l11ll1ll, 0, 1, 8, 10)
        table.attach(self.l1ll1lll11, 1, 3, 8, 10)
        l1l1ll11l1 = Gtk.CheckButton(l111l (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll11l1.connect(l111l (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1ll11ll, l1l1ll11l1)
        l1l1ll11l1.set_active(False)
        table.attach(l1l1ll11l1, 1, 3, 12, 14)
        l1ll1ll1l1 = Gtk.Label()
        l1ll1ll1l1.set_text(l111l (u"ࠥࠤࠧ৛") * 5)
        l1ll11l1ll.pack_start(l1ll1ll1l1, True, True, 0)
        if self.l1ll111l:
            l1l11ll11l.set_active(True)
            self.l1ll1l1ll1.set_active(0)
            self.l1ll1l1ll1.set_sensitive(True)
            self.l1ll1lll11.set_text(l111l (u"ࠦࠧড়"))
            self.l1ll1lll11.set_sensitive(True)
        else:
            self.l1ll1l1ll1.set_active(0)
            self.l1ll1l1ll1.set_sensitive(False)
            self.l1ll1lll11.set_text(l111l (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1lll11.set_sensitive(False)
        l1ll1ll1ll.pack_start(vbox, True, True, 0)
        l1ll1ll1ll.pack_start(table, True, True, 0)
        l1ll1ll1ll.pack_end(l1ll11l1ll, True, True, 0)
        l1l1l1ll11.pack_start(l1ll1ll1ll, True, True, 0)
        l1ll1l1l1l.show_all()
        response = l1ll1l1l1l.run()
        if self.l1ll1l1ll1.get_active():
            l1ll111l = self.l1ll1l1ll1.get_child().get_text()
        else:
            l1ll111l = self.l1ll11ll11[self.l1ll1l1ll1.get_active()][0]
        pwd = self.l1ll1lll11.get_text()
        l1ll1l1l1l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1ll1111:
                self.l1l1l1l1ll(l1ll111l, pwd, self.service)
            return l1ll111l, pwd
        else:
            return l111l (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l111l (u"ࠧࠨয়")
class l11111lll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1l11l1l(self, l11lll11):
        l1l1l111ll = Gtk.ScrolledWindow()
        l1l1l111ll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1ll1lll=None
        self.l1ll1l1l11 = Gtk.TextBuffer()
        self.l1ll1l1l11.set_text(l11lll11)
        self.set_style()
        regexp= l111l (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll1ll11l = self._1l1lll1ll(l11lll11, regexp)
        self.l1l11llll1(l1ll1ll11l, self.l1ll1l1l11.get_start_iter())
        self.l1l1lll1l1 = Gtk.TextView(buffer=self.l1ll1l1l11)
        self.l1l1lll1l1.set_property(l111l (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1lll1l1.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1lll1l1.connect(l111l (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1llllll)
        self.l1l1lll1l1.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1l111ll.set_size_request(300,100)
        self.l1l1lll1l1.show()
        l1l1l111ll.add(self.l1l1lll1l1)
        l1l1l111ll.show()
        return l1l1l111ll
    def _1l1llllll(self, *args, **kwargs):
        l1l1l1l1l1, l1l11lllll=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l1l1l1, l1l11lllll).get_tags()
        if not self.l1l1ll1lll:
            self.l1l1ll1lll = args[1].window.get_cursor()
            self.l1ll1l11l1 = Gdk.Cursor(Gdk.CursorType.l1l11l1ll1)
        elif tag:
            args[1].window.set_cursor(self.l1ll1l11l1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1ll1lll:
                args[1].window.set_cursor(self.l1l1ll1lll)
    def _1l1lll1ll(self, l11lll11, l1ll1llll1):
        res=[]
        l1l1lll111=re.findall(l1ll1llll1,l11lll11)
        for l1l1lllll1 in l1l1lll111:
            for el in l1l1lllll1:
                if el:
                    res.append(el)
        return res
    def l1l11llll1(self, l1ll1ll11l, start):
        l1l1l1lll1=0
        for text in l1ll1ll11l:
            end = self.l1ll1l1l11.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l1lll1+=1
                l1l1l111l1, l1ll1ll111 = match
                tag = self.l1ll1l1l11.create_tag(str(l1l1l1lll1), foreground=l111l (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l111l (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1llll1l, text)
                self.l1ll1l1l11.apply_tag(tag, l1l1l111l1, l1ll1ll111)
                self.l1l11llll1(l1ll1ll11l, l1ll1ll111)
    def _1l1llll1l(self, tag, widget, l1l1lll11l, _1ll111111, text):
        _1ll1lll1l = l1l1lll11l.type
        _1l1l1ll1l = l1l1lll11l.window
        if _1ll1lll1l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll1lll1l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1lll11l.button
            self.l1l1ll1lll = Gdk.Cursor(Gdk.CursorType.l1l11l1ll1)
            if _1ll1lll1l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l111l (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l111111l1(self, message, title=l111l (u"ࠧࠨ০"), l11lll1ll=True, l1l1l11l11=None):
        if l11lll1ll:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l11l1l11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1l11l11:
            l1l1l1l111 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1ll1ll1 = Gtk.HBox(spacing=0)
            l1l1ll1l1l = Gtk.HBox(spacing=5)
            l1ll1l111l = Gtk.Label()
            l1ll1l111l.set_markup(l111l (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll1l111l.set_line_wrap(True)
            l1ll1l111l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l111l (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l11lll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lll1l.show()
            l1l11ll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll111.show()
            l1ll111l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111l1l.show()
            l1l1ll1ll1.pack_start(separator, True, True, 0)
            l1l1ll1ll1.pack_start(l1l11lll1l, True, True, 0)
            l1l1ll1ll1.pack_start(l1l11ll111, True, True, 0)
            l1l1ll1ll1.pack_start(l1ll111l1l, True, True, 0)
            l1l1ll1ll1.pack_start(l1ll1l111l, False, True, 0)
            l1ll11111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11111l.show()
            l1l1ll1ll1.pack_end(l1ll11111l, True, True, 0)
            l1ll1lllll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1lllll.show()
            vbox.pack_start(l1l1ll1ll1, True, True, 0)
            l1l1l111ll=self.__1l1l11l1l(l11lll11=l1l1l11l11)
            vbox.pack_start(l1l1l111ll, False, False, 0)
            vbox.pack_end(l1ll1lllll, False, False, 0)
            l1l1ll1l1l.pack_start(vbox, True, True,5)
            l1l1ll1l1l.show()
            l1l1l1l111.pack_end(l1l1ll1l1l, False, False, 0)
            vbox.show()
            l1l1ll1ll1.show()
        window.run()
class l11l1lll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll1111l1(self, widget, l1ll11l111):
        if l1ll11l111 == Gtk.ResponseType.OK:
            self.result = l111l (u"ࠥࡓࡐࠨ৩")
        elif l1ll11l111 == Gtk.ResponseType.CANCEL:
            self.result = l111l (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll11l111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l111l (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1l11l111(self, title=l111l (u"ࠨࠢ৬"), message=l111l (u"ࠢࠣ৭") , l11lll1ll=True):
        if l11lll1ll:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1l11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l111l (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll1111l1)
        window.run()
class l1ll11l1l1(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll11llll=None
        self.result = None
    def l1ll1111l1(self, widget, l1ll11l111):
        print(widget, l1ll11l111)
        if l1ll11l111 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll11l111 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll11l111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1ll11ll(self, widget, l1l1ll1l11):
        if l1l1ll1l11.get_active():
            self.l1ll11llll = 1
        else:
            self.l1ll11llll = 0
    def l1ll111lll(self, title=l111l (u"ࠤࠥ৯"), message=l111l (u"ࠥࠦৰ"), l1l1l11111 =l111l (u"ࠦࠧৱ"),l11lll1ll=True):
        if l11lll1ll:
            l1l11l1l11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1l11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l111l (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll1111l1)
        l1l1ll11l1 = Gtk.CheckButton(l1l1l11111)
        l1l1ll11l1.connect(l111l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1ll11ll, l1l1ll11l1)
        l1l1ll11l1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll11l1, expand=True, fill=True, padding=0)
        l1l1ll11l1.show()
        window.run()
def l11l11ll1(title, msg, l1l1l11111=l111l (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11lll1ll=True):
    result=None
    try:
        l1l11l1lll = l1ll11l1l1()
        l1l11l1lll.l1ll111lll(title, msg, l1l1l11111, l11lll1ll)
        result = {l111l (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l11l1lll.result,  l111l (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l11l1lll.l1ll11llll}
    except Exception as e:
        logger.exception(l111l (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l111l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l111lll1l = l11111lll()
    message= l111l (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1ll111l = l111l (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l111lll1l.l111111l1(message, l111l (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11lll1ll=True, l1l1l11l11=l1l1ll111l)