#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1llll1l = 7
def l1lllll1 (l11ll1l):
    global l1l1ll
    l1ll1 = ord (l11ll1l [-1])
    l1l11ll = l11ll1l [:-1]
    l111111 = l1ll1 % len (l1l11ll)
    l1ll11l1 = l1l11ll [:l111111] + l1l11ll [l111111:]
    if l11ll1:
        l1lllll = l11l111 () .join ([unichr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    else:
        l1lllll = str () .join ([chr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    return eval (l1lllll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllll1l1=logging.WARNING
logger = logging.getLogger(l1lllll1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lllll1l1)
l1l1llll = SysLogHandler(address=l1lllll1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lllll1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1llll.setFormatter(formatter)
logger.addHandler(l1l1llll)
ch = logging.StreamHandler()
ch.setLevel(l1lllll1l1)
logger.addHandler(ch)
class l1lll1l1l1(io.FileIO):
    l1lllll1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lllll1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1l111, l1llll11ll,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1l111 = l1lll1l111
            self.l1llll11ll = l1llll11ll
            if not options:
                options = l1lllll1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lllll1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1l111,
                                              self.l1llll11ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l1ll = os.path.join(os.path.sep, l1lllll1 (u"ࠪࡩࡹࡩࠧই"), l1lllll1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll11ll1 = path
        else:
            self._1lll11ll1 = self.l1lll1l1ll
        super(l1lll1l1l1, self).__init__(self._1lll11ll1, l1lllll1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lllll11l(self, line):
        return l1lll1l1l1.Entry(*[x for x in line.strip(l1lllll1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lllll1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lllll1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lllll1 (u"ࠤࠦࠦ঍")):
                    yield self._1lllll11l(line)
            except ValueError:
                pass
    def l1llll1l11(self, attr, value):
        for entry in self.entries:
            l1lllllll1 = getattr(entry, attr)
            if l1lllllll1 == value:
                return entry
        return None
    def l1llll11l1(self, entry):
        if self.l1llll1l11(l1lllll1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lllll1 (u"ࠫࡡࡴࠧএ")).encode(l1lllll1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1l1l(self, entry):
        self.seek(0)
        lines = [l.decode(l1lllll1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lllll1 (u"ࠢࠤࠤ঒")):
                if self._1lllll11l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lllll1 (u"ࠨࠩও").join(lines).encode(l1lllll1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll11l1l(cls, l1lll1l111, path=None):
        l1lll1l11l = cls(path=path)
        entry = l1lll1l11l.l1llll1l11(l1lllll1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1l111)
        if entry:
            return l1lll1l11l.l1llll1l1l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1l111, l1llll11ll, options=None, path=None):
        return cls(path=path).l1llll11l1(l1lll1l1l1.Entry(device,
                                                    l1lll1l111, l1llll11ll,
                                                    options=options))
class l1llllll11(object):
    def __init__(self, l1lll1ll1l):
        self.l1lll1111l=l1lllll1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1ll11=l1lllll1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1ll1l=l1lll1ll1l
        self.l1lll1lll1()
        self.l1lllll1ll()
        self.l1llll1111()
        self.l1lll11111()
        self.l1llll1lll()
    def l1lll1lll1(self):
        temp_file=open(l1llll1ll1,l1lllll1 (u"࠭ࡲࠨঘ"))
        l1ll11ll=temp_file.read()
        data=json.loads(l1ll11ll)
        self.user=data[l1lllll1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l=data[l1lllll1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l1l11=data[l1lllll1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1lll=data[l1lllll1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11lll=data[l1lllll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1llll=data[l1lllll1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1111(self):
        l1llllll=os.path.join(l1lllll1 (u"ࠨ࠯ࠣট"),l1lllll1 (u"ࠢࡶࡵࡵࠦঠ"),l1lllll1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lllll1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lllll1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1llllll)
    def l1llll1lll(self):
        logger.info(l1lllll1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l1l11=os.path.join(self.l1lll,self.l1lll1111l)
        l1llll111l = pwd.getpwnam(self.user).pw_uid
        l1lll11l11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l1l11):
            os.makedirs(l1l1l11)
            os.system(l1lllll1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l1l11))
            logger.debug(l1lllll1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l1l11)
        else:
            logger.debug(l1lllll1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l1l11)
        l1llllll=os.path.join(l1l1l11, self.l1lll1ll11)
        print(l1llllll)
        logger.debug(l1lllll1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1llllll)
        with open(l1llllll, l1lllll1 (u"ࠤࡺ࠯ࠧ঩")) as l1lllll111:
            logger.debug(self.l11l + l1lllll1 (u"ࠪࠤࠬপ")+self.l1lll11lll+l1lllll1 (u"ࠫࠥࠨࠧফ")+self.l1lll1llll+l1lllll1 (u"ࠬࠨࠧব"))
            l1lllll111.writelines(self.l11l + l1lllll1 (u"࠭ࠠࠨভ")+self.l1lll11lll+l1lllll1 (u"ࠧࠡࠤࠪম")+self.l1lll1llll+l1lllll1 (u"ࠨࠤࠪয"))
        os.chmod(l1llllll, 0o600)
        os.chown(l1llllll, l1llll111l, l1lll11l11)
    def l1lllll1ll(self, l1lll111ll=l1lllll1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lllll1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll111ll in groups:
            logger.info(l1lllll1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll111ll))
        else:
            logger.warning(l1lllll1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll111ll))
            l1ll111l=l1lllll1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll111ll,self.user)
            logger.debug(l1lllll1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll111l)
            os.system(l1ll111l)
            logger.debug(l1lllll1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll11111(self):
        logger.debug(l1lllll1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l11l=l1lll1l1l1()
        l1lll1l11l.add(self.l11l, self.l1l1l11, l1llll11ll=l1lllll1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lllll1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lllll1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll1ll1 = urllib.parse.unquote(sys.argv[1])
        if l1llll1ll1:
            l1llllll1l=l1llllll11(l1llll1ll1)
        else:
            raise (l1lllll1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lllll1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise