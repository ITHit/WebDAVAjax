#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1llll1l = 7
def l1lllll1 (l11ll1l):
    global l1l1ll
    l1ll1 = ord (l11ll1l [-1])
    l1l11ll = l11ll1l [:-1]
    l111111 = l1ll1 % len (l1l11ll)
    l1ll11l1 = l1l11ll [:l111111] + l1l11ll [l111111:]
    if l11ll1:
        l1lllll = l11l111 () .join ([unichr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    else:
        l1lllll = str () .join ([chr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    return eval (l1lllll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111l1 import l11l11
from configobj import ConfigObj
l11lllll = l1lllll1 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1ll1l = l1lllll1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠵࠶࠲࠵ࠨࡤ")
l11l1lll = l1lllll1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lllll1 (u"ࠣ࠸࠱࠴࠳࠾࠷࠴࠵࠱࠴ࠧࡦ")
l1l1l1ll=os.path.join(os.environ.get(l1lllll1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lllll1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11l1lll.replace(l1lllll1 (u"ࠦࠥࠨࡩ"), l1lllll1 (u"ࠧࡥࠢࡪ")).lower())
l1l1111l=os.environ.get(l1lllll1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lllll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l111ll=l1l1ll1l.replace(l1lllll1 (u"ࠣࠢࠥ࡭"), l1lllll1 (u"ࠤࡢࠦ࡮"))+l1lllll1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lllll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll111=os.path.join(os.environ.get(l1lllll1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l111ll)
elif platform.system() == l1lllll1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1ll11=l11l11(l1l1l1ll+l1lllll1 (u"ࠢ࠰ࠤࡳ"))
    l11ll111 = os.path.join(l1l1ll11, l1l111ll)
else:
    l11ll111 = os.path.join( l1l111ll)
l1l1111l=l1l1111l.upper()
if l1l1111l == l1lllll1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11111=logging.DEBUG
elif l1l1111l == l1lllll1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11111 = logging.INFO
elif l1l1111l == l1lllll1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11111 = logging.WARNING
elif l1l1111l == l1lllll1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11111 = logging.ERROR
elif l1l1111l == l1lllll1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11111 = logging.CRITICAL
elif l1l1111l == l1lllll1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11111 = logging.NOTSET
logger = logging.getLogger(l1lllll1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11111)
l1l11l11 = logging.FileHandler(l11ll111, mode=l1lllll1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l11l11.setLevel(l1l11111)
formatter = logging.Formatter(l1lllll1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lllll1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11l11.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11111)
l1l1llll = SysLogHandler(address=l1lllll1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1llll.setFormatter(formatter)
logger.addHandler(l1l11l11)
logger.addHandler(ch)
logger.addHandler(l1l1llll)
class Settings():
    l1l1lll1 = l1lllll1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11ll1ll = l1lllll1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111l1 = l1lllll1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1ll1l):
        self.l11ll1l1 = self._11ll11l(l1l1ll1l)
        self._1l11l1l()
    def _11ll11l(self, l1l1ll1l):
        l11lll11 = l1l1ll1l.split(l1lllll1 (u"ࠣࠢࠥࢂ"))
        l11lll11 = l1lllll1 (u"ࠤࠣࠦࢃ").join(l11lll11)
        if platform.system() == l1lllll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11ll1l1 = os.path.join(l1l1l1ll, l1lllll1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11lll11 + l1lllll1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11ll1l1
    def l1l1l111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l11l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lllll1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lllll1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11llll1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11l1l(self):
        if not os.path.exists(os.path.dirname(self.l11ll1l1)):
            os.makedirs(os.path.dirname(self.l11ll1l1))
        if not os.path.exists(self.l11ll1l1):
            self.config = ConfigObj(self.l11ll1l1)
            self.config[l1lllll1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lllll1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lllll1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111l1
            self.config[l1lllll1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lllll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lllll1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11ll1ll
            self.config[l1lllll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lllll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1lll1
            self.config[l1lllll1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll1l1)
            self.l1l111l1 = self.get_value(l1lllll1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lllll1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11ll1ll = self.get_value(l1lllll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lllll1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1lll1 = self.get_value(l1lllll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lllll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11lll(self):
        l11lll1l = l1lllll1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1lll1
        l11lll1l += l1lllll1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11ll1ll
        l11lll1l += l1lllll1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111l1
        return l11lll1l
    def __unicode__(self):
        return self._1l11lll()
    def __str__(self):
        return self._1l11lll()
    def __del__(self):
        self.config.write()
l1l11ll1 = Settings(l1l1ll1l)