#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l11 = 2048
l11111 = 7
def l1l1l1 (l111):
    global l1l1
    l1llll1 = ord (l111 [-1])
    l1ll11l = l111 [:-1]
    l1lll111 = l1llll1 % len (l1ll11l)
    l1lll = l1ll11l [:l1lll111] + l1ll11l [l1lll111:]
    if l1lllll:
        l1l111 = l111lll () .join ([unichr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    return eval (l1l111)
import re
class l1l(Exception):
    def __init__(self, *args,**kwargs):
        self.l111111l = kwargs.get(l1l1l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll1ll = kwargs.get(l1l1l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll11ll = self.l1lllll11(args)
        if l1lll11ll:
            args=args+ l1lll11ll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        l1lll11ll=None
        l1l11ll1 = args[0][0]
        if re.search(l1l1l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11ll1):
            l1lll11ll = (l1l1l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l111111l
                            ,)
        return l1lll11ll
class l1lll1lll(Exception):
    def __init__(self, *args, **kwargs):
        l1lll11ll = self.l1lllll11(args)
        if l1lll11ll:
            args = args + l1lll11ll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        s = l1l1l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l1l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1111l11(Exception):
    pass
class l1lll1ll(Exception):
    pass
class l1llll11l(Exception):
    def __init__(self, message, l1lll1l11, url):
        super(l1llll11l,self).__init__(message)
        self.l1lll1l11 = l1lll1l11
        self.url = url
class l11111l1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1111111(Exception):
    pass
class l111l11l(Exception):
    pass