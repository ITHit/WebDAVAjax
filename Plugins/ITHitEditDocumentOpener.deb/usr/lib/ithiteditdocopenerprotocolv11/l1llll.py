#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11ll = sys.version_info [0] == 2
l111ll1 = 2048
l1l1l = 7
def l1l1 (l111ll):
    global l1lllll
    l1ll1l1l = ord (l111ll [-1])
    l11llll = l111ll [:-1]
    l1111 = l1ll1l1l % len (l11llll)
    l1llllll = l11llll [:l1111] + l11llll [l1111:]
    if l1ll11ll:
        l1ll1l11 = l11l1l1 () .join ([unichr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    else:
        l1ll1l11 = str () .join ([chr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    return eval (l1ll1l11)
import hashlib
import os
import l1l1ll
from l1l11l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1ll import l1111l
from l111l import l1l11, ll
import logging
logger = logging.getLogger(l1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1lll1ll():
    def __init__(self, l11ll1,l11, l1l1lll= None, l1l=None):
        self.l1=False
        self.l1lllll1 = self._1lll11l()
        self.l11 = l11
        self.l1l1lll = l1l1lll
        self.l11111 = l11ll1
        if l1l1lll:
            self.l1ll1ll1 = True
        else:
            self.l1ll1ll1 = False
        self.l1l = l1l
    def _1lll11l(self):
        try:
            return l1l1ll.l111lll() is not None
        except:
            return False
    def open(self):
        l1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lllll1:
            raise NotImplementedError(l1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1lll = self.l11111
        if self.l11.lower().startswith(self.l11111.lower()):
            l111 = re.compile(re.escape(self.l11111), re.IGNORECASE)
            l11 = l111.sub(l1l1 (u"ࠨࠩࠄ"), self.l11)
            l11 = l11.replace(l1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l11ll(self.l11111, l1ll1lll, l11, self.l1l1lll)
    def l1l11ll(self,l11111, l1ll1lll, l11, l1l1lll):
        l1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1l11 = l1llll11(l11111)
        l1l1111 = self.l11l1l(l1l1l11)
        logger.info(l1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1l11)
        if l1l1111:
            logger.info(l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111l(l1l1l11)
            l1l1l11 = l1111l1(l11111, l1ll1lll, l1l1lll, self.l1l)
        logger.debug(l1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll111l=l1l1l11 + l1l1 (u"ࠤ࠲ࠦࠌ") + l11
        l1llll1l = l1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll111l+ l1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1llll1l)
        l11l11l = os.system(l1llll1l)
        if (l11l11l != 0):
            raise IOError(l1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll111l, l11l11l))
    def l11l1l(self, l1l1l11):
        if os.path.exists(l1l1l11):
            if os.path.islink(l1l1l11):
                l1l1l11 = os.readlink(l1l1l11)
            if os.path.ismount(l1l1l11):
                return True
        return False
def l1llll11(l11111):
    l11l = l11111.replace(l1l1 (u"࠭࡜࡝ࠩࠐ"), l1l1 (u"ࠧࡠࠩࠑ")).replace(l1l1 (u"ࠨ࠱ࠪࠒ"), l1l1 (u"ࠩࡢࠫࠓ"))
    l1ll1ll = l1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll11=os.environ[l1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll1l=os.path.join(l11ll11,l1ll1ll, l11l)
    l11l1=os.path.abspath(l1lll1l)
    return l11l1
def l1lll1(l1l111l):
    if not os.path.exists(l1l111l):
        os.makedirs(l1l111l)
def l1lll1l1(l11111, l1ll1lll, l111l1l=None, password=None):
    l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l111l = l1llll11(l11111)
    l1lll1(l1l111l)
    if not l111l1l:
        l11ll = l1ll()
        l11lll1 =l11ll.l1ll1l(l1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1lll + l1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1lll + l1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11lll1, str):
            l111l1l, password = l11lll1
        else:
            raise ll()
        logger.info(l1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l111l))
    l1l1ll1 = pwd.getpwuid( os.getuid())[0]
    l11l11=os.environ[l1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll111=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll1111={l1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l1ll1, l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11111, l1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l111l, l1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11l11, l1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111l1l, l1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll1111, temp_file)
        if not os.path.exists(os.path.join(l1ll111, l1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll11=l1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1l1 (u"ࠧࠨࠤ")
        else:
            l1lll11=l1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll11l1=l1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll11,temp_file.name)
        l1l11l1=[l1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll111, l1ll11l1)]
        p = subprocess.Popen(l1l11l1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l111l
    logger.debug(l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11l1=os.path.abspath(l1l111l)
    logger.debug(l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11l1)
    return l11l1
def l1111l1(l11111, l1ll1lll, l1l1lll, l1l):
    l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1l1(title):
        l1l1l1=30
        if len(title)>l1l1l1:
            l1llll1=title.split(l1l1 (u"ࠨ࠯ࠣ࠳"))
            l111l11=l1l1 (u"ࠧࠨ࠴")
            for block in l1llll1:
                l111l11+=block+l1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l111l11) > l1l1l1:
                    l111l11+=l1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111l11
        return title
    def l1lll(l11l111, password):
        l1l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l1 (u"ࠧࠦࠢ࠹").join(l11l111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l111 = l1l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l111.encode())
        l1l1l1l = [l1l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11111l = l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11111l)
            for e in l1l1l1l:
                if e in l11111l: return False
            raise l1l11(l11111l, l1111l1=l1l1ll.l111lll(), l1ll1lll=l1ll1lll)
        logger.info(l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l111l1l = l1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l1 (u"ࠦࠧ࠿")
    os.system(l1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll11 = l1llll11(l11111)
    l1l111l = l1llll11(hashlib.sha1(l11111.encode()).hexdigest()[:10])
    l1lll1(l1l111l)
    logger.info(l1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l111l))
    if l1l1lll:
        l11l111 = [l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l111l1l, l1l1lll),
                    urllib.parse.unquote(l1ll1lll), os.path.abspath(l1l111l)]
        l1lll(l11l111, password)
    else:
        while True:
            l111l1l, password = l11l1ll(l1l111l, l1ll1lll, l1l)
            if l111l1l.lower() != l1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l111 = [l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l1 (u"ࠤ࠰ࡸࠧࡋ"), l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l1 (u"ࠫ࠲ࡵࠧࡍ"), l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l111l1l,
                            urllib.parse.unquote(l1ll1lll), os.path.abspath(l1l111l)]
            else:
                raise ll()
            if l1lll(l11l111, password): break
    os.system(l1l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l111l, l1ll11))
    l11l1=os.path.abspath(l1ll11)
    return l11l1
def l11l1ll(l11111, l1ll1lll, l1l):
    l1lll111 = os.path.join(os.environ[l1l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll111)):
       os.makedirs(os.path.dirname(l1lll111))
    l11lll = l1l.get_value(l1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11ll = l1ll(l11111, l11lll)
    l111l1l, password = l11ll.l1ll1l(l1l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1lll + l1l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1lll + l1l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l111l1l != l1l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111111(l11111, l111l1l):
        l11ll1l = l1l1 (u"ࠤ࡙ࠣࠦ").join([l11111, l111l1l, l1l1 (u"࡚ࠪࠦࠬ") + password + l1l1 (u"࡛ࠫࠧ࠭"), l1l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll111, l1l1 (u"࠭ࡷࠬࠩ࡝")) as l111l1:
            l111l1.write(l11ll1l)
        os.chmod(l1lll111, 0o600)
    return l111l1l, password
def l111111(l11111, l111l1l):
    l1lll111 = l1ll1 = os.path.join(os.environ[l1l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll111):
        with open(l1lll111, l1l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll11l = data[0].split(l1l1 (u"ࠦࠥࠨࡢ"))
            if l11111 == l1ll11l[0] and l111l1l == l1ll11l[1]:
                return True
    return False