#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll1l = 2048
l1lll111 = 7
def l11l (l1l11ll):
    global l11llll
    l1l1l1 = ord (l1l11ll [-1])
    l1ll1l1 = l1l11ll [:-1]
    l111 = l1l1l1 % len (l1ll1l1)
    l1l1ll = l1ll1l1 [:l111] + l1ll1l1 [l111:]
    if l1ll111:
        l1111l1 = l11ll11 () .join ([unichr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    return eval (l1111l1)
import logging
import os
import re
from l111ll import l1lll11ll
logger = logging.getLogger(l11l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll111l():
    try:
        out = os.popen(l11l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11l (u"ࠤࠥॸ").join(result)
                logger.info(l11l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll11ll(l11l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11111(l11l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))