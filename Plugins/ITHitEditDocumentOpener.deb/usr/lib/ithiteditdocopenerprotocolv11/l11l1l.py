#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l11 = 2048
l11111 = 7
def l1l1l1 (l111):
    global l1l1
    l1llll1 = ord (l111 [-1])
    l1ll11l = l111 [:-1]
    l1lll111 = l1llll1 % len (l1ll11l)
    l1lll = l1ll11l [:l1lll111] + l1ll11l [l1lll111:]
    if l1lllll:
        l1l111 = l111lll () .join ([unichr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    return eval (l1l111)
import gi
gi.require_version(l1l1l1 (u"ࠨࡉࡷ࡯ࠬঽ"), l1l1l1 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l111ll
import logging
logger = logging.getLogger(l1l1l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1lll1(Gtk.Window):
    def __init__(self, l1l11ll11l, l1l1llll11):
        Gtk.Window.__init__(self)
        self.l1l11l1=30
        self.l1l11llll1 = False
        self.service = l1l11ll11l
        self.l1lll11=l1l1llll11
        self.l1ll1111=l1l111ll.l1l11111
        self.l1ll1ll111 = Gtk.ListStore(str)
        self.l1l1l1111l()
    def l1l1l1l111(self, service):
        l1ll1ll11l = self.l1ll1111.l1l11lll(l1l1l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll1ll11l
    def l1l1l1111l(self, l1l11ll11l=None):
        if l1l11ll11l:
            self.l1ll1ll111.clear()
            l1l11l1lll=self.l1l1l1l111(l1l11ll11l)
            self.l1ll1ll111.append([l1l1l1 (u"ࠧࠨু")])
            for l1lll11 in l1l11l1lll:
                self.l1ll1ll111.append([l1lll11])
        else:
            self.l1ll1ll111.clear()
            self.l1ll1ll111.append([l1l1l1 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll11111l(self, widget, data=None):
        l1ll1l1lll= widget.get_active()
        if data == l1l1l1 (u"ࠢ࠲ࠤৃ") and l1ll1l1lll:
            self.l1l1l1111l()
            self.l1l1l1lll1.set_active(0)
            self.l1ll1lllll.set_text(l1l1l1 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1lllll.set_sensitive(False)
            self.l1l1l1lll1.set_sensitive(False)
        else:
            self.l1l1l1111l(l1l11ll11l=self.service)
            self.l1l1l1lll1.set_active(0)
            self.l1ll1lllll.set_text(l1l1l1 (u"ࠤࠥ৅"))
            self.l1l1l1lll1.set_sensitive(True)
            self.l1ll1lllll.set_sensitive(True)
    def l1l1ll1ll1(self, widget):
        if widget.get_active():
            l1lll11 = widget.get_child().get_text()
        else:
            l1lll11 = self.l1ll1ll111[widget.get_active()][0]
        password = self.l1l1lllll1(self.service, l1lll11)
        if password:
            self.l1ll1lllll.set_text(password)
        else:
            self.l1ll1lllll.set_text(l1l1l1 (u"ࠥࠦ৆"))
    def l1ll11l1ll(self, l1lll11, pwd, service):
        keyring.set_password(service, l1lll11, pwd)
        l1ll1ll11l=self.l1ll1111.l1l11lll(l1l1l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1lll11 in l1ll1ll11l:
            value = self.l1ll1111.get_value(l1l1l1 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1ll1111.l1l1llll(l1l1l1 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1l1l1 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1lll11))
    def l1l1lllll1(self, service, l1lll11):
        l1ll111l11 = keyring.get_password(service, l1lll11)
        return l1ll111l11
    def l1l1lll111(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1ll11l1(self, widget, data=None):
        self.l1l11llll1=widget.get_active()
    def l1111l1(self, message, title=l1l1l1 (u"ࠨࠩো"), l1l1l1l11=True):
        if l1l1l1l11:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1ll1ll = Gtk.MessageDialog(self,
            l1l11l1l11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1ll1ll.set_title(title)
        l1ll1ll1ll.set_default_response(Gtk.ResponseType.OK)
        l1ll1l111l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l1ll11 = Gtk.VBox()
        l1ll111111 = Gtk.Box(spacing=1)
        l1ll111111.set_homogeneous(False)
        l1l1llllll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1llllll.set_homogeneous(False)
        l1l1l1l1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l1l1.set_homogeneous(False)
        l1ll111111.pack_start(l1l1llllll, True, True, 0)
        l1ll111111.pack_start(l1l1l1l1l1, True, True, 0)
        l1ll11l111 = l1ll1ll1ll.get_content_area()
        l1l1l11ll1 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll11l111.pack_start(l1l1l11ll1, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1lll1l = Gtk.Label()
        l1l1l1ll1l = Gtk.Label()
        l1l1l1ll1l.set_text(l1l1l1 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1l1ll1l, True, True, 0)
        l1ll1lll1l.set_text(l1l1l1 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll1lll1l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1lll1l, 0, 1, 0, 1)
        l1ll1l1111 = Gtk.RadioButton.new_with_label_from_widget(None, l1l1l1 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll1l1111.connect(l1l1l1 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll11111l, l1l1l1 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll1l1111, 1, 2, 0, 1)
        l1ll1l1l1l = Gtk.RadioButton.new_with_label_from_widget(l1ll1l1111, l1l1l1 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll1l1l1l.connect(l1l1l1 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll11111l, l1l1l1 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll1l1l1l, 1, 2, 1, 2)
        l1ll11lll1 = Gtk.Label()
        l1ll11lll1.set_text(l1l1l1 (u"ࠥࠤࠧ৔"))
        table.attach(l1ll11lll1, 0, 1, 4, 6)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l1l1l1 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll1111ll.set_justify(Gtk.Justification.RIGHT)
        l1ll1111ll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l1lll1 = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1ll111)
        self.l1l1l1lll1.set_entry_text_column(0)
        table.attach(l1ll1111ll, 0, 1, 6, 8)
        table.attach(self.l1l1l1lll1, 1, 3, 6, 8)
        self.l1l1l1lll1.connect(l1l1l1 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1ll1ll1)
        l1ll111lll = Gtk.Label()
        l1ll111lll.set_text(l1l1l1 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll111lll.set_justify(Gtk.Justification.RIGHT)
        l1ll111lll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1lllll = Gtk.Entry()
        self.l1ll1lllll.set_visibility(False)
        self.l1ll1lllll.connect(l1l1l1 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1lll111, l1ll1ll1ll)
        table.attach(l1ll111lll, 0, 1, 8, 10)
        table.attach(self.l1ll1lllll, 1, 3, 8, 10)
        l1ll1111l1 = Gtk.CheckButton(l1l1l1 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll1111l1.connect(l1l1l1 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1ll11l1, l1ll1111l1)
        l1ll1111l1.set_active(False)
        table.attach(l1ll1111l1, 1, 3, 12, 14)
        l1l1l11lll = Gtk.Label()
        l1l1l11lll.set_text(l1l1l1 (u"ࠥࠤࠧ৛") * 5)
        l1l1l1ll11.pack_start(l1l1l11lll, True, True, 0)
        if self.l1lll11:
            l1ll1l1l1l.set_active(True)
            self.l1l1l1lll1.set_active(0)
            self.l1l1l1lll1.set_sensitive(True)
            self.l1ll1lllll.set_text(l1l1l1 (u"ࠦࠧড়"))
            self.l1ll1lllll.set_sensitive(True)
        else:
            self.l1l1l1lll1.set_active(0)
            self.l1l1l1lll1.set_sensitive(False)
            self.l1ll1lllll.set_text(l1l1l1 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1lllll.set_sensitive(False)
        l1ll1l111l.pack_start(vbox, True, True, 0)
        l1ll1l111l.pack_start(table, True, True, 0)
        l1ll1l111l.pack_end(l1l1l1ll11, True, True, 0)
        l1l1l11ll1.pack_start(l1ll1l111l, True, True, 0)
        l1ll1ll1ll.show_all()
        response = l1ll1ll1ll.run()
        if self.l1l1l1lll1.get_active():
            l1lll11 = self.l1l1l1lll1.get_child().get_text()
        else:
            l1lll11 = self.l1ll1ll111[self.l1l1l1lll1.get_active()][0]
        pwd = self.l1ll1lllll.get_text()
        l1ll1ll1ll.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l11llll1:
                self.l1ll11l1ll(l1lll11, pwd, self.service)
            return l1lll11, pwd
        else:
            return l1l1l1 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1l1l1 (u"ࠧࠨয়")
class l1l11111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1lll1ll(self, l1l11ll1):
        l1l11ll1ll = Gtk.ScrolledWindow()
        l1l11ll1ll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1l1l1ll=None
        self.l1ll1l1ll1 = Gtk.TextBuffer()
        self.l1ll1l1ll1.set_text(l1l11ll1)
        self.set_style()
        regexp= l1l1l1 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l1l1llll = self._1ll1l1l11(l1l11ll1, regexp)
        self.l1l11ll111(l1l1l1llll, self.l1ll1l1ll1.get_start_iter())
        self.l1l11l1ll1 = Gtk.TextView(buffer=self.l1ll1l1ll1)
        self.l1l11l1ll1.set_property(l1l1l1 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l11l1ll1.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11l1ll1.connect(l1l1l1 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll11ll11)
        self.l1l11l1ll1.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l11ll1ll.set_size_request(300,100)
        self.l1l11l1ll1.show()
        l1l11ll1ll.add(self.l1l11l1ll1)
        l1l11ll1ll.show()
        return l1l11ll1ll
    def _1ll11ll11(self, *args, **kwargs):
        l1l1ll1lll, l1ll1ll1l1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1ll1lll, l1ll1ll1l1).get_tags()
        if not self.l1l1l1l1ll:
            self.l1l1l1l1ll = args[1].window.get_cursor()
            self.l1l1l11111 = Gdk.Cursor(Gdk.CursorType.l1l1l111ll)
        elif tag:
            args[1].window.set_cursor(self.l1l1l11111)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1l1l1ll:
                args[1].window.set_cursor(self.l1l1l1l1ll)
    def _1ll1l1l11(self, l1l11ll1, l1l11l11ll):
        res=[]
        l1ll1llll1=re.findall(l1l11l11ll,l1l11ll1)
        for l1ll111l1l in l1ll1llll1:
            for el in l1ll111l1l:
                if el:
                    res.append(el)
        return res
    def l1l11ll111(self, l1l1l1llll, start):
        l1l1ll1l1l=0
        for text in l1l1l1llll:
            end = self.l1ll1l1ll1.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1ll1l1l+=1
                l1l11lll11, l1l1lll1l1 = match
                tag = self.l1ll1l1ll1.create_tag(str(l1l1ll1l1l), foreground=l1l1l1 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1l1l1 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll1l11ll, text)
                self.l1ll1l1ll1.apply_tag(tag, l1l11lll11, l1l1lll1l1)
                self.l1l11ll111(l1l1l1llll, l1l1lll1l1)
    def _1ll1l11ll(self, tag, widget, l1l1lll11l, _1l11lllll, text):
        _1ll111ll1 = l1l1lll11l.type
        _1ll11l1l1 = l1l1lll11l.window
        if _1ll111ll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll111ll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1lll11l.button
            self.l1l1l1l1ll = Gdk.Cursor(Gdk.CursorType.l1l1l111ll)
            if _1ll111ll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1l1l1 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1l11llll(self, message, title=l1l1l1 (u"ࠧࠨ০"), l1l1l1l11=True, l1l1llll1l=None):
        if l1l1l1l11:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l11l1l11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1llll1l:
            l1ll11l111 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll111111 = Gtk.HBox(spacing=0)
            l1ll1lll11 = Gtk.HBox(spacing=5)
            l1l11l1l1l = Gtk.Label()
            l1l11l1l1l.set_markup(l1l1l1 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l11l1l1l.set_line_wrap(True)
            l1l11l1l1l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1l1l1 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1ll1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1l11.show()
            l1ll11l11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11l11l.show()
            l1ll11ll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11ll1l.show()
            l1ll111111.pack_start(separator, True, True, 0)
            l1ll111111.pack_start(l1l1ll1l11, True, True, 0)
            l1ll111111.pack_start(l1ll11l11l, True, True, 0)
            l1ll111111.pack_start(l1ll11ll1l, True, True, 0)
            l1ll111111.pack_start(l1l11l1l1l, False, True, 0)
            l1ll11llll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11llll.show()
            l1ll111111.pack_end(l1ll11llll, True, True, 0)
            l1l1ll1111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1111.show()
            vbox.pack_start(l1ll111111, True, True, 0)
            l1l11ll1ll=self.__1l1lll1ll(l1l11ll1=l1l1llll1l)
            vbox.pack_start(l1l11ll1ll, False, False, 0)
            vbox.pack_end(l1l1ll1111, False, False, 0)
            l1ll1lll11.pack_start(vbox, True, True,5)
            l1ll1lll11.show()
            l1ll11l111.pack_end(l1ll1lll11, False, False, 0)
            vbox.show()
            l1ll111111.show()
        window.run()
class l11l1111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l1l11l(self, widget, l1l1l11l11):
        if l1l1l11l11 == Gtk.ResponseType.OK:
            self.result = l1l1l1 (u"ࠥࡓࡐࠨ৩")
        elif l1l1l11l11 == Gtk.ResponseType.CANCEL:
            self.result = l1l1l1 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1l11l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1l1l1 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11ll1ll1(self, title=l1l1l1 (u"ࠨࠢ৬"), message=l1l1l1 (u"ࠢࠣ৭") , l1l1l1l11=True):
        if l1l1l1l11:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1l11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1l1l1 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1l1l11l)
        window.run()
class l1l1ll111l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l11lll1l=None
        self.result = None
    def l1l1l1l11l(self, widget, l1l1l11l11):
        print(widget, l1l1l11l11)
        if l1l1l11l11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l11l11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l11l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1ll11l1(self, widget, l1l11ll1l1):
        if l1l11ll1l1.get_active():
            self.l1l11lll1l = 1
        else:
            self.l1l11lll1l = 0
    def l1l1ll11ll(self, title=l1l1l1 (u"ࠤࠥ৯"), message=l1l1l1 (u"ࠥࠦৰ"), l1l1l111l1 =l1l1l1 (u"ࠦࠧৱ"),l1l1l1l11=True):
        if l1l1l1l11:
            l1l11l1l11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1l11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1l1l1 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1l1l11l)
        l1ll1111l1 = Gtk.CheckButton(l1l1l111l1)
        l1ll1111l1.connect(l1l1l1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1ll11l1, l1ll1111l1)
        l1ll1111l1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll1111l1, expand=True, fill=True, padding=0)
        l1ll1111l1.show()
        window.run()
def l11111l1l(title, msg, l1l1l111l1=l1l1l1 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1l1l1l11=True):
    result=None
    try:
        l1ll1l11l1 = l1l1ll111l()
        l1ll1l11l1.l1l1ll11ll(title, msg, l1l1l111l1, l1l1l1l11)
        result = {l1l1l1 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll1l11l1.result,  l1l1l1 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll1l11l1.l1l11lll1l}
    except Exception as e:
        logger.exception(l1l1l1 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1l1l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1ll1111l = l1l11111l()
    message= l1l1l1 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1l11l1l = l1l1l1 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1ll1111l.l1l11llll(message, l1l1l1 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1l1l1l11=True, l1l1llll1l=l1l1l11l1l)