#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l11 = 2048
l11111 = 7
def l1l1l1 (l111):
    global l1l1
    l1llll1 = ord (l111 [-1])
    l1ll11l = l111 [:-1]
    l1lll111 = l1llll1 % len (l1ll11l)
    l1lll = l1ll11l [:l1lll111] + l1ll11l [l1lll111:]
    if l1lllll:
        l1l111 = l111lll () .join ([unichr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    return eval (l1l111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll1l1 import l1l111l
from configobj import ConfigObj
l1l1111l = l1l1l1 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l11l1l = l1l1l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠷࠴࠸࠺࠵࠷࠲࠵ࠨࡤ")
l11ll1l1 = l1l1l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l1l1 (u"ࠣ࠸࠱࠶࠳࠾࠹࠴࠶࠱࠴ࠧࡦ")
l11ll1ll=os.path.join(os.environ.get(l1l1l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l1l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll1l1.replace(l1l1l1 (u"ࠦࠥࠨࡩ"), l1l1l1 (u"ࠧࡥࠢࡪ")).lower())
l11ll11l=os.environ.get(l1l1l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11ll111=l1l11l1l.replace(l1l1l1 (u"ࠣࠢࠥ࡭"), l1l1l1 (u"ࠤࡢࠦ࡮"))+l1l1l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1l1ll=os.path.join(os.environ.get(l1l1l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11ll111)
elif platform.system() == l1l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11l1lll=l1l111l(l11ll1ll+l1l1l1 (u"ࠢ࠰ࠤࡳ"))
    l1l1l1ll = os.path.join(l11l1lll, l11ll111)
else:
    l1l1l1ll = os.path.join( l11ll111)
l11ll11l=l11ll11l.upper()
if l11ll11l == l1l1l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1l111=logging.DEBUG
elif l11ll11l == l1l1l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1l111 = logging.INFO
elif l11ll11l == l1l1l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1l111 = logging.WARNING
elif l11ll11l == l1l1l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1l111 = logging.ERROR
elif l11ll11l == l1l1l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1l111 = logging.CRITICAL
elif l11ll11l == l1l1l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1l111 = logging.NOTSET
logger = logging.getLogger(l1l1l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1l111)
l11llll1 = logging.FileHandler(l1l1l1ll, mode=l1l1l1 (u"ࠣࡹ࠮ࠦࡻ"))
l11llll1.setLevel(l1l1l111)
formatter = logging.Formatter(l1l1l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l1l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11llll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l111)
l1l1ll1l = SysLogHandler(address=l1l1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l11llll1)
logger.addHandler(ch)
logger.addHandler(l1l1ll1l)
class Settings():
    l1l1l1l1 = l1l1l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1l11l = l1l1l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111l1 = l1l1l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l11l1l):
        self.l1l1lll1 = self._1l11l11(l1l11l1l)
        self._11lll11()
    def _1l11l11(self, l1l11l1l):
        l11lll1l = l1l11l1l.split(l1l1l1 (u"ࠣࠢࠥࢂ"))
        l11lll1l = l1l1l1 (u"ࠤࠣࠦࢃ").join(l11lll1l)
        if platform.system() == l1l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1lll1 = os.path.join(l11ll1ll, l1l1l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11lll1l + l1l1l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1lll1
    def l1l1llll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11lll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1ll11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll11(self):
        if not os.path.exists(os.path.dirname(self.l1l1lll1)):
            os.makedirs(os.path.dirname(self.l1l1lll1))
        if not os.path.exists(self.l1l1lll1):
            self.config = ConfigObj(self.l1l1lll1)
            self.config[l1l1l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l1l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l1l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111l1
            self.config[l1l1l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1l11l
            self.config[l1l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l1l1
            self.config[l1l1l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1lll1)
            self.l1l111l1 = self.get_value(l1l1l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l1l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1l11l = self.get_value(l1l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l1l1 = self.get_value(l1l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lllll(self):
        l1l11ll1 = l1l1l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l1l1
        l1l11ll1 += l1l1l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1l11l
        l1l11ll1 += l1l1l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111l1
        return l1l11ll1
    def __unicode__(self):
        return self._11lllll()
    def __str__(self):
        return self._11lllll()
    def __del__(self):
        self.config.write()
l1l11111 = Settings(l1l11l1l)