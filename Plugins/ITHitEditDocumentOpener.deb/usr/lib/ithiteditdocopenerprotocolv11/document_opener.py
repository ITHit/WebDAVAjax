#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l = 2048
l11l1ll = 7
def l1l11 (l1lll):
    global l1lll1
    l1ll11l1 = ord (l1lll [-1])
    l1ll1ll = l1lll [:-1]
    l1l1ll1 = l1ll11l1 % len (l1ll1ll)
    l1llll1 = l1ll1ll [:l1l1ll1] + l1ll1ll [l1l1ll1:]
    if l1ll1l:
        l1ll1111 = l1lll1l1 () .join ([unichr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    else:
        l1ll1111 = str () .join ([chr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    return eval (l1ll1111)
import sys, json
import os
import urllib
import l1l11l
from l1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l11l11 import l11lllll, logger, l1l1l111
from cookies import l11l1l11 as l1ll1l11l
from l1ll1 import l11l1
l1l11ll1l = None
from l11l1l import *
class l11111lll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l11 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l11l1l11l):
        self.config = l11l1l11l
        self.l111lll11 = l1l11l.l1l1l11()
    def l111l1ll1(self):
        data = platform.uname()
        logger.info(l1l11 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1l11 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1l11 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1l11 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1111llll():
    def __init__(self, encode = True):
        self._encode = encode
        self._11lll11l = [l1l11 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l1ll1ll = None
        self.l111l111l = None
        self.l11l11ll1 = None
        self.l1lll11l1 = None
        self.l11ll1l = None
        self.l1lll1111 = None
        self.l11ll11l1 = None
        self.l11l11lll = None
        self.cookies = None
    def l1l11ll11(self, url):
        l1l11 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1l11 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11l1ll11(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111111l1(url)
        self.dict = self._11llll1l(params)
        logger.info(l1l11 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l11111111(self.dict):
            raise l1111111(l1l11 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._11lll11l)
        self._111l1111(self.dict)
        if self._encode:
            self.l111l1l11()
        self._11ll1l11()
        self._1ll1111l()
        self._1l1l1lll()
        self._1111l1l1()
        self.l11l11l11()
        logger.info(l1l11 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1l11 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l1ll1ll))
        logger.info(l1l11 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l111l111l))
        logger.info(l1l11 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11l11ll1))
        logger.info(l1l11 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1lll11l1))
        logger.info(l1l11 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l11ll1l))
        logger.info(l1l11 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1lll1111))
        logger.info(l1l11 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l11ll11l1))
        logger.info(l1l11 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l11l11lll))
    def _111l1111(self, l1ll1l1l1):
        self.l1l1ll1ll = l1ll1l1l1.get(l1l11 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l111l111l = l1ll1l1l1.get(l1l11 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1l11 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11l11ll1 = l1ll1l1l1.get(l1l11 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1lll11l1 = l1ll1l1l1.get(l1l11 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l11ll1l = l1ll1l1l1.get(l1l11 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1lll1111 = l1ll1l1l1.get(l1l11 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l11ll11l1 = l1ll1l1l1.get(l1l11 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1l11 (u"ࠣࠤ࣏"))
        self.l11l11lll = l1ll1l1l1.get(l1l11 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1l11 (u"࣑ࠥࠦ"))
        self.cookies = l1ll1l1l1.get(l1l11 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11l11l11(self):
        l1111ll1l = False
        if self.l11ll1l:
            if self.l11ll1l.upper() == l1l11 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l11ll1l = l1l11 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l11ll1l.upper() == l1l11 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l11ll1l = l1l11 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l11ll1l.upper() == l1l11 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l11ll1l = l1l11 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l11ll1l.upper() == l1l11 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l11ll1l = l1l11 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l11ll1l == l1l11 (u"ࠨࠢࣛ"):
                l1111ll1l = True
            else:
                self.l11ll1l = self.l11ll1l.lower()
        else:
            l1111ll1l = True
        if l1111ll1l:
            self.l11ll1l = l1l11 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l111l1l11(self):
        l1l11 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l11 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11l111l1 = []
                    for el in self.__dict__.get(key):
                        l11l111l1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11l111l1
    def l11lll1l1(self, l11ll11ll):
        res = l11ll11ll
        if self._encode:
            res = urllib.parse.quote(l11ll11ll, safe=l1l11 (u"ࠥࠦࣟ"))
        return res
    def _11l1ll11(self, url):
        l1l11 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1l11 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1l11 (u"ࠨ࠺ࠣ࣢")), l1l11 (u"ࠧࠨࣣ"), url)
        return url
    def _111111l1(self, url):
        l1l11 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l111l11l1 = url.split(l1l11 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1l11 (u"ࠥ࠿ࣦࠧ")))
        result = l111l11l1
        if len(result) == 0:
            raise l1lllll1l(l1l11 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11llll1l(self, params):
        l1l11 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1l11 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1l11 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11111ll1 = data.group(l1l11 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11111ll1 in (l1l11 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1l11 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1l11 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1l11 (u"ࠧ࠲࣯ࠢ"))
                elif l11111ll1 == l1l11 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1l11 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l11 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11111ll1] = value
        return result
    def _111ll1l1(self, url, scheme):
        l1l11 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l1l11ll = {l1l11 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1l11 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11l1ll1l = url.split(l1l11 (u"ࠧࡀࣶࠢ"))
        if len(l11l1ll1l) == 1:
            for l1lll111l in list(l1l1l11ll.keys()):
                if l1lll111l == scheme:
                    url += l1l11 (u"ࠨ࠺ࠣࣷ") + str(l1l1l11ll[l1lll111l])
                    break
        return url
    def _11ll1l11(self):
        l1l11 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1lll11l1:
            l1l1l1l11 = self.l1lll11l1[0]
            l11111l1l = urlparse(l1l1l1l11)
        if self.l1l1ll1ll:
            l1l1l1ll1 = urlparse(self.l1l1ll1ll)
            if l1l1l1ll1.scheme:
                l1l1111l1 = l1l1l1ll1.scheme
            else:
                if l11111l1l.scheme:
                    l1l1111l1 = l11111l1l.scheme
                else:
                    raise l1lllll11(
                        l1l11 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1l1ll1.netloc:
                l11l1llll = l1l1l1ll1.netloc
            else:
                if l11111l1l.netloc:
                    l11l1llll = l11111l1l.netloc
                else:
                    raise l1lllll11(
                        l1l11 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l11l1llll = self._111ll1l1(l11l1llll, l1l1111l1)
            path = l1l1l1ll1.path
            if not path.endswith(l1l11 (u"ࠪ࠳ࠬࣻ")):
                path += l1l11 (u"ࠫ࠴࠭ࣼ")
            l1111ll11 = ParseResult(scheme=l1l1111l1, netloc=l11l1llll, path=path,
                                         params=l1l1l1ll1.params, query=l1l1l1ll1.query,
                                         fragment=l1l1l1ll1.fragment)
            self.l1l1ll1ll = l1111ll11.geturl()
        else:
            if not l11111l1l.netloc:
                raise l1lllll11(l1l11 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11lll1ll = l11111l1l.path
            l111ll111 = l1l11 (u"ࠨ࠯ࠣࣾ").join(l11lll1ll.split(l1l11 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1l11 (u"ࠣ࠱ࠥऀ")
            l1111ll11 = ParseResult(scheme=l11111l1l.scheme,
                                         netloc=self._111ll1l1(l11111l1l.netloc, l11111l1l.scheme),
                                         path=l111ll111,
                                         params=l1l11 (u"ࠤࠥँ"),
                                         query=l1l11 (u"ࠥࠦं"),
                                         fragment=l1l11 (u"ࠦࠧः")
                                         )
            self.l1l1ll1ll = l1111ll11.geturl()
    def _1l1l1lll(self):
        l1l11 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1lll11l1:
            l1l1l1l11 = self.l1lll11l1[0]
            l11111l1l = urlparse(l1l1l1l11)
        if self.l1lll1111:
            l11ll1l1l = urlparse(self.l1lll1111)
            if l11ll1l1l.scheme:
                l11llllll = l11ll1l1l.scheme
            else:
                l11llllll = l11111l1l.scheme
            if l11ll1l1l.netloc:
                l11llll11 = l11ll1l1l.netloc
            else:
                l11llll11 = l11111l1l.netloc
            l1l1111ll = ParseResult(scheme=l11llllll, netloc=l11llll11, path=l11ll1l1l.path,
                                      params=l11ll1l1l.params, query=l11ll1l1l.query,
                                      fragment=l11ll1l1l.fragment)
            self.l1lll1111 = l1l1111ll.geturl()
    def _1ll1111l(self):
        l1l11 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1lll11l1
        self.l1lll11l1 = []
        for item in items:
            l1l1lll11 = urlparse(item.strip(), scheme=l1l11 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1l1lll11.path[-1] == l1l11 (u"ࠣ࠱ࠥइ"):
                l1l11llll = l1l1lll11.path
            else:
                path_list = l1l1lll11.path.split(l1l11 (u"ࠤ࠲ࠦई"))
                l1l11llll = l1l11 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1l11 (u"ࠦ࠴ࠨऊ")
            l1l1lllll = urlparse(self.l1l1ll1ll, scheme=l1l11 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1l1lll11.scheme:
                scheme = l1l1lll11.scheme
            elif l1l1lllll.scheme:
                scheme = l1l1lllll.scheme
            else:
                scheme = l1l11 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1l1lll11.netloc and not l1l1lllll.netloc:
                l111ll1ll = l1l1lll11.netloc
            elif not l1l1lll11.netloc and l1l1lllll.netloc:
                l111ll1ll = l1l1lllll.netloc
            elif not l1l1lll11.netloc and not l1l1lllll.netloc and len(self.l1lll11l1) > 0:
                l11ll111l = urlparse(self.l1lll11l1[len(self.l1lll11l1) - 1])
                l111ll1ll = l11ll111l.netloc
            elif l1l1lllll.netloc:
                l111ll1ll = l1l1lll11.netloc
            elif not l1l1lllll.netloc:
                l111ll1ll = l1l1lll11.netloc
            if l1l1lll11.path:
                l1l1llll1 = l1l1lll11.path
            if l111ll1ll:
                l111ll1ll = self._111ll1l1(l111ll1ll, scheme)
                l111l1lll = ParseResult(scheme=scheme, netloc=l111ll1ll, path=l1l1llll1,
                                          params=l1l1lll11.params,
                                          query=l1l1lll11.query,
                                          fragment=l1l1lll11.fragment)
                self.l1lll11l1.append(l111l1lll.geturl())
    def _1111l1l1(self):
        l1l11 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1ll11lll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111llll(l1l11 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1ll11lll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111llll(l1l11 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11l11ll1:
            l1l1ll111 = []
            for l1l11l1ll in self.l11l11ll1:
                if l1l11l1ll not in [x[l1l11 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l1ll111.append(l1l11l1ll)
            if l1l1ll111:
                l1l1l11l = l1l11 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1l11 (u"ࠧ࠲ࠠࠣऒ").join(l1l1ll111))
                raise l111llll(l1l11 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l1l11l)
    def l11111111(self, params):
        l1l11 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1111lll1 = True
        for param in self._11lll11l:
            if not params.get(param.lower()):
                l1111lll1 = False
        return l1111lll1
class l111llll1():
    def __init__(self, l11l1l1l1):
        self.l11lllll1 = l1l11l.l1l1l11()
        self.l1ll11l11 = self.l11l1l1ll()
        self.l11lll111 = self.l1ll1l1ll()
        self.l11l1l1l1 = l11l1l1l1
        self._1ll1lll1 = [l1l11 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1l11 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1l11 (u"ࠥࡅࡱࡲࠢग"), l1l11 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1l11 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1l11 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1l11 (u"ࠢࡊࡇࠥछ"), l1l11 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l11l11l = [l1l11 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1l11 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1l11 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1l11 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1ll1llll = None
    def l11l1l1ll(self):
        l1ll1ll1l = l1l11 (u"ࠨࡎࡰࡰࡨࠦड")
        return l1ll1ll1l
    def l1ll1l1ll(self):
        l111lll1l = 0
        return l111lll1l
    def l11ll1lll(self):
        l1l1l11l = l1l11 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11lll111)
        l1l1l11l += l1l11 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1ll111ll(l11lllll, l1l1l11l, t=1)
        return res
    def run(self):
        l1ll1ll11 = True
        self._1l11111l()
        result = []
        try:
            for cookie in l1ll1l11l(l11l111l=self.l11l1l1l1.cookies).run():
                result.append(cookie)
        except l1111l11 as e:
            logger.exception(l1l11 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1l111lll = self._1l111l1l(result)
            if l1l111lll:
                logger.info(l1l11 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1l111lll)
                self.l1ll1llll = l1l111lll
            else:
                logger.info(l1l11 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1l111lll)
            l1ll1ll11 = True
        else:
            l1ll1ll11 = False
        return l1ll1ll11
    def _1l111l1l(self, l1l111l11):
        res = False
        l1l11l1 = os.path.join(os.environ[l1l11 (u"ࠬࡎࡏࡎࡇࠪध")], l1l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1l11 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1l111ll1 = {}
        for cookies in l1l111l11:
            l1l111ll1[cookies.name] = cookies.value
        l11l1l111 = l1l11 (u"ࠣࠤप")
        for key in list(l1l111ll1.keys()):
            l11l1l111 += l1l11 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1l111ll1[key].strip())
        if not os.path.exists(os.path.dirname(l1l11l1)):
            os.makedirs(os.path.dirname(l1l11l1))
        vers = int(l1l11 (u"ࠥࠦब").join(self.l11lllll1.split(l1l11 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1l1l111l = [l1l11 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1l11 (u"ࠨࠣࠡࠤय") + l1l11 (u"ࠢ࠮ࠤर") * 60,
                              l1l11 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1l11 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1l11 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11l1l111),
                              l1l11 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1l1l111l = [l1l11 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1l11 (u"ࠨࠣࠡࠤश") + l1l11 (u"ࠢ࠮ࠤष") * 60,
                              l1l11 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1l11 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1l11 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11l1l111),
                              l1l11 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1l11l1, l1l11 (u"ࠧࡽ़ࠢ")) as l1l11lll1:
            data = l1l11 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1l1l111l)
            l1l11lll1.write(data)
            l1l11lll1.write(l1l11 (u"ࠢ࡝ࡰࠥा"))
        res = l1l11l1
        return res
    def _1l11111l(self):
        self._1l111111(l1l11 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1l11l1l1()
    def _1l111111(self, l11l1111l):
        l1ll11111 = self.l11l1l1l1.dict[l11l1111l.lower()]
        if l1ll11111:
            if isinstance(l1ll11111, list):
                l1llllllll = l1ll11111
            else:
                l1llllllll = [l1ll11111]
            if l1l11 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11l1111l.lower():
                    for l111ll11l in l1llllllll:
                        l1l1ll11l = [l11l11111.upper() for l11l11111 in self._1ll1lll1]
                        if not l111ll11l.upper() in l1l1ll11l:
                            l1111l1ll = l1l11 (u"ࠥ࠰ࠥࠨु").join(self._1ll1lll1)
                            l111111ll = l1l11 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11l1111l, l1ll11111, l1111l1ll, )
                            raise l1llll1l1(l111111ll)
    def _1l11l1l1(self):
        l1l1l1l1l = []
        l11l111ll = self.l11l1l1l1.l11l11ll1
        for l11ll1111 in self._1ll1lll1:
            if not l11ll1111 in [l1l11 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1l11 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1l1l1l1l.append(l11ll1111)
        for l11111l11 in self.l11l1l1l1.l111l111l:
            if l11111l11 in l1l1l1l1l and not l11l111ll:
                l111111ll = l1l11 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1llll1l1(l111111ll)
def l1ll11l1l(title, message, l11l1lll1, l1ll1l111=None):
    l1l1l11l1 = l1ll11ll1()
    l1l1l11l1.l1l1l1111(message, title, l11l1lll1, l1ll1l111)
def l111l1l1l(title, message, l11l1lll1):
    l1ll111l1 = l1111l11l()
    l1ll111l1.l1111l111(title, message, l11l1lll1)
    res = l1ll111l1.result
    return res
def main():
    try:
        logger.info(l1l11 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1l111)
        system.l111l1ll1()
        logger.info(l1l11 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1111111(
                l1l11 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1l1ll1l1 = l1111llll()
        l1l1ll1l1.l1l11ll11(l1l11 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11l11l1l = [item.upper() for item in l1l1ll1l1.l111l111l]
        l111lllll = l1l11 (u"ࠧࡔࡏࡏࡇࠥॊ") in l11l11l1l
        if l111lllll:
            logger.info(l1l11 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1111111l = l1l1ll1l1.l1lll11l1
            for l1llll11 in l1111111l:
                logger.debug(l1l11 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1llll11))
                opener = l11l1(l1l1ll1l1.l1l1ll1ll, l1llll11, l1l11l1=None, l11ll11=l1l1l111)
                opener.open()
                logger.info(l1l11 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11ll1ll1 = l111llll1(l1l1ll1l1)
            l111l11ll = l11ll1ll1.run()
            l1111111l = l1l1ll1l1.l1lll11l1
            for l1llll11 in l1111111l:
                logger.info(l1l11 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1llll11))
                opener = l11l1(l1l1ll1l1.l1l1ll1ll, l1llll11, l1l11l1=l11ll1ll1.l1ll1llll,
                                l11ll11=l1l1l111)
                opener.open()
                logger.info(l1l11 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11111 as e:
        title = l1l11 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11lllll
        logger.exception(l1l11 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1l11l111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l11l111 = el
        l1l1lll1l = l1l11 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11lll, message.strip())
        l1ll11l1l(title, l1l1lll1l, l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1ll1l111=l1l11l111)
        sys.exit(2)
    except l1lll1l1l as e:
        title = l1l11 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11lllll
        logger.exception(l1l11 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1l11l111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l11l111 = el
        l1l1lll1l = l1l11 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1ll11l1l(title, l1l1lll1l, l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1ll1l111=l1l11l111)
        sys.exit(2)
    except l1111111 as e:
        title = l1l11 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11lllll
        logger.exception(l1l11 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1ll11l1l(title, str(e), l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1l11 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1l11 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11lllll
        logger.exception(l1l11 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1ll11l1l(title, l1l11 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1llll1l1 as e:
        title = l1l11 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11lllll
        logger.exception(l1l11 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1ll11l1l(title, l1l11 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll11ll as e:
        title = l1l11 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11lllll
        logger.exception(l1l11 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1ll11l1l(title, l1l11 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1l11 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll11:
        logger.info(l1l11 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1l11 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11lllll
        logger.exception(l1l11 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1ll11l1l(title, l1l11 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11l1lll1=l1l1l111.get_value(l1l11 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1l11 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l11 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()