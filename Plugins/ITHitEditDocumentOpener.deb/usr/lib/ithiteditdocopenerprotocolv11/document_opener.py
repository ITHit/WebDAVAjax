#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l1lllll1 = 2048
l1lll1 = 7
def l1ll1ll (l11l1ll):
    global l11l1l
    l1llllll = ord (l11l1ll [-1])
    l111111 = l11l1ll [:-1]
    l1ll1ll1 = l1llllll % len (l111111)
    l1l1ll = l111111 [:l1ll1ll1] + l111111 [l1ll1ll1:]
    if l1lllll:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    return eval (l1111)
import sys, json
import os
import urllib
import l111lll
from l111ll1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1l111 import l1l1llll, logger, l11lll11
from cookies import l1111ll1 as l11l1l11l
from l1llll1l import l1111ll
l1l1l1ll1 = None
from l1l1l1l import *
class l111ll111():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1ll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l11l1l1ll):
        self.config = l11l1l1ll
        self.l11ll1ll1 = l111lll.l11l11()
    def l1l111l11(self):
        data = platform.uname()
        logger.info(l1ll1ll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1ll1ll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1ll1ll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1ll1ll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1l1111l1():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l11l1ll = [l1ll1ll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l11llll11 = None
        self.l11lll11l = None
        self.l11llll1l = None
        self.l111ll11l = None
        self.l1l = None
        self.l1111l1l1 = None
        self.l1l11l11l = None
        self.l111ll1ll = None
        self.cookies = None
    def l11l1ll1l(self, url):
        l1ll1ll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1ll1ll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11l11l11(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l11lll1(url)
        self.dict = self._1l1llll1(params)
        logger.info(l1ll1ll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1llllllll(self.dict):
            raise l1111111(l1ll1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1l11l1ll)
        self._11ll11l1(self.dict)
        if self._encode:
            self.l1l1ll1ll()
        self._1111ll1l()
        self._1ll11lll()
        self._11ll1lll()
        self._1l11llll()
        self.l1l111ll1()
        logger.info(l1ll1ll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1ll1ll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l11llll11))
        logger.info(l1ll1ll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11lll11l))
        logger.info(l1ll1ll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11llll1l))
        logger.info(l1ll1ll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l111ll11l))
        logger.info(l1ll1ll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1l))
        logger.info(l1ll1ll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1111l1l1))
        logger.info(l1ll1ll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l11l11l))
        logger.info(l1ll1ll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l111ll1ll))
    def _11ll11l1(self, l1l11l1l1):
        self.l11llll11 = l1l11l1l1.get(l1ll1ll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11lll11l = l1l11l1l1.get(l1ll1ll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1ll1ll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11llll1l = l1l11l1l1.get(l1ll1ll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l111ll11l = l1l11l1l1.get(l1ll1ll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1l = l1l11l1l1.get(l1ll1ll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1111l1l1 = l1l11l1l1.get(l1ll1ll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l11l11l = l1l11l1l1.get(l1ll1ll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1ll1ll (u"ࠣࠤ࣏"))
        self.l111ll1ll = l1l11l1l1.get(l1ll1ll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1ll1ll (u"࣑ࠥࠦ"))
        self.cookies = l1l11l1l1.get(l1ll1ll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l111ll1(self):
        l1l1ll11l = False
        if self.l1l:
            if self.l1l.upper() == l1ll1ll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1l = l1ll1ll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1l.upper() == l1ll1ll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1l = l1ll1ll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1l.upper() == l1ll1ll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1l = l1ll1ll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1l.upper() == l1ll1ll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1l = l1ll1ll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1l == l1ll1ll (u"ࠨࠢࣛ"):
                l1l1ll11l = True
            else:
                self.l1l = self.l1l.lower()
        else:
            l1l1ll11l = True
        if l1l1ll11l:
            self.l1l = l1ll1ll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1l1ll1ll(self):
        l1ll1ll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1ll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1111l11l = []
                    for el in self.__dict__.get(key):
                        l1111l11l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1111l11l
    def l1l11111l(self, l1l1l11l1):
        res = l1l1l11l1
        if self._encode:
            res = urllib.parse.quote(l1l1l11l1, safe=l1ll1ll (u"ࠥࠦࣟ"))
        return res
    def _11l11l11(self, url):
        l1ll1ll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1ll1ll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1ll1ll (u"ࠨ࠺ࠣ࣢")), l1ll1ll (u"ࠧࠨࣣ"), url)
        return url
    def _1l11lll1(self, url):
        l1ll1ll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1l111l1l = url.split(l1ll1ll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1ll1ll (u"ࠥ࠿ࣦࠧ")))
        result = l1l111l1l
        if len(result) == 0:
            raise l1lllllll(l1ll1ll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1l1llll1(self, params):
        l1ll1ll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1ll1ll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1ll1ll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1ll1111l = data.group(l1ll1ll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1ll1111l in (l1ll1ll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1ll1ll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1ll1ll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1ll1ll (u"ࠧ࠲࣯ࠢ"))
                elif l1ll1111l == l1ll1ll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1ll1ll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1ll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1ll1111l] = value
        return result
    def _111l111l(self, url, scheme):
        l1ll1ll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l1ll1l1 = {l1ll1ll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1ll1ll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1ll1l111 = url.split(l1ll1ll (u"ࠧࡀࣶࠢ"))
        if len(l1ll1l111) == 1:
            for l111l11l1 in list(l1l1ll1l1.keys()):
                if l111l11l1 == scheme:
                    url += l1ll1ll (u"ࠨ࠺ࠣࣷ") + str(l1l1ll1l1[l111l11l1])
                    break
        return url
    def _1111ll1l(self):
        l1ll1ll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l111ll11l:
            l11lll1l1 = self.l111ll11l[0]
            l111l1111 = urlparse(l11lll1l1)
        if self.l11llll11:
            l1ll1ll11 = urlparse(self.l11llll11)
            if l1ll1ll11.scheme:
                l11l1l111 = l1ll1ll11.scheme
            else:
                if l111l1111.scheme:
                    l11l1l111 = l111l1111.scheme
                else:
                    raise l1llll11l(
                        l1ll1ll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1ll1ll11.netloc:
                l1l1ll111 = l1ll1ll11.netloc
            else:
                if l111l1111.netloc:
                    l1l1ll111 = l111l1111.netloc
                else:
                    raise l1llll11l(
                        l1ll1ll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l1ll111 = self._111l111l(l1l1ll111, l11l1l111)
            path = l1ll1ll11.path
            if not path.endswith(l1ll1ll (u"ࠪ࠳ࠬࣻ")):
                path += l1ll1ll (u"ࠫ࠴࠭ࣼ")
            l1ll11l11 = ParseResult(scheme=l11l1l111, netloc=l1l1ll111, path=path,
                                         params=l1ll1ll11.params, query=l1ll1ll11.query,
                                         fragment=l1ll1ll11.fragment)
            self.l11llll11 = l1ll11l11.geturl()
        else:
            if not l111l1111.netloc:
                raise l1llll11l(l1ll1ll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1ll1lll1 = l111l1111.path
            l111l1l11 = l1ll1ll (u"ࠨ࠯ࠣࣾ").join(l1ll1lll1.split(l1ll1ll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1ll1ll (u"ࠣ࠱ࠥऀ")
            l1ll11l11 = ParseResult(scheme=l111l1111.scheme,
                                         netloc=self._111l111l(l111l1111.netloc, l111l1111.scheme),
                                         path=l111l1l11,
                                         params=l1ll1ll (u"ࠤࠥँ"),
                                         query=l1ll1ll (u"ࠥࠦं"),
                                         fragment=l1ll1ll (u"ࠦࠧः")
                                         )
            self.l11llll11 = l1ll11l11.geturl()
    def _11ll1lll(self):
        l1ll1ll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l111ll11l:
            l11lll1l1 = self.l111ll11l[0]
            l111l1111 = urlparse(l11lll1l1)
        if self.l1111l1l1:
            l111l1l1l = urlparse(self.l1111l1l1)
            if l111l1l1l.scheme:
                l1ll11111 = l111l1l1l.scheme
            else:
                l1ll11111 = l111l1111.scheme
            if l111l1l1l.netloc:
                l1l1111ll = l111l1l1l.netloc
            else:
                l1l1111ll = l111l1111.netloc
            l11l11111 = ParseResult(scheme=l1ll11111, netloc=l1l1111ll, path=l111l1l1l.path,
                                      params=l111l1l1l.params, query=l111l1l1l.query,
                                      fragment=l111l1l1l.fragment)
            self.l1111l1l1 = l11l11111.geturl()
    def _1ll11lll(self):
        l1ll1ll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l111ll11l
        self.l111ll11l = []
        for item in items:
            l111lll1l = urlparse(item.strip(), scheme=l1ll1ll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l111lll1l.path[-1] == l1ll1ll (u"ࠣ࠱ࠥइ"):
                l1ll11ll1 = l111lll1l.path
            else:
                path_list = l111lll1l.path.split(l1ll1ll (u"ࠤ࠲ࠦई"))
                l1ll11ll1 = l1ll1ll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1ll1ll (u"ࠦ࠴ࠨऊ")
            l11l11ll1 = urlparse(self.l11llll11, scheme=l1ll1ll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l111lll1l.scheme:
                scheme = l111lll1l.scheme
            elif l11l11ll1.scheme:
                scheme = l11l11ll1.scheme
            else:
                scheme = l1ll1ll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l111lll1l.netloc and not l11l11ll1.netloc:
                l111111l1 = l111lll1l.netloc
            elif not l111lll1l.netloc and l11l11ll1.netloc:
                l111111l1 = l11l11ll1.netloc
            elif not l111lll1l.netloc and not l11l11ll1.netloc and len(self.l111ll11l) > 0:
                l11lllll1 = urlparse(self.l111ll11l[len(self.l111ll11l) - 1])
                l111111l1 = l11lllll1.netloc
            elif l11l11ll1.netloc:
                l111111l1 = l111lll1l.netloc
            elif not l11l11ll1.netloc:
                l111111l1 = l111lll1l.netloc
            if l111lll1l.path:
                l1l1l1l11 = l111lll1l.path
            if l111111l1:
                l111111l1 = self._111l111l(l111111l1, scheme)
                l1lll11l1 = ParseResult(scheme=scheme, netloc=l111111l1, path=l1l1l1l11,
                                          params=l111lll1l.params,
                                          query=l111lll1l.query,
                                          fragment=l111lll1l.fragment)
                self.l111ll11l.append(l1lll11l1.geturl())
    def _1l11llll(self):
        l1ll1ll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1ll1ll1l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l1ll1ll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1ll1ll1l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l1ll1ll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11llll1l:
            l11llllll = []
            for l1ll1l1l1 in self.l11llll1l:
                if l1ll1l1l1 not in [x[l1ll1ll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l11llllll.append(l1ll1l1l1)
            if l11llllll:
                l1l11ll1 = l1ll1ll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1ll1ll (u"ࠧ࠲ࠠࠣऒ").join(l11llllll))
                raise l111l111(l1ll1ll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l11ll1)
    def l1llllllll(self, params):
        l1ll1ll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l11l111l1 = True
        for param in self._1l11l1ll:
            if not params.get(param.lower()):
                l11l111l1 = False
        return l11l111l1
class l11111l1l():
    def __init__(self, l1l1lll11):
        self.l11l1lll1 = l111lll.l11l11()
        self.l11l1111l = self.l1ll11l1l()
        self.l1111l1ll = self.l111l1lll()
        self.l1l1lll11 = l1l1lll11
        self._111l11ll = [l1ll1ll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1ll1ll (u"ࠤࡑࡳࡳ࡫ࠢख"), l1ll1ll (u"ࠥࡅࡱࡲࠢग"), l1ll1ll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1ll1ll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1ll1ll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1ll1ll (u"ࠢࡊࡇࠥछ"), l1ll1ll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._11lll111 = [l1ll1ll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1ll1ll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1ll1ll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1ll1ll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l111l1ll1 = None
    def l1ll11l1l(self):
        l1l1l1lll = l1ll1ll (u"ࠨࡎࡰࡰࡨࠦड")
        return l1l1l1lll
    def l111l1lll(self):
        l11111lll = 0
        return l11111lll
    def l111lll11(self):
        l1l11ll1 = l1ll1ll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1111l1ll)
        l1l11ll1 += l1ll1ll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11l1ll11(l1l1llll, l1l11ll1, t=1)
        return res
    def run(self):
        l1111llll = True
        self._1l1l111l()
        result = []
        try:
            for cookie in l11l1l11l(l1111l1l=self.l1l1lll11.cookies).run():
                result.append(cookie)
        except l1lllll11 as e:
            logger.exception(l1ll1ll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11ll1111 = self._1l11l111(result)
            if l11ll1111:
                logger.info(l1ll1ll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11ll1111)
                self.l111l1ll1 = l11ll1111
            else:
                logger.info(l1ll1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11ll1111)
            l1111llll = True
        else:
            l1111llll = False
        return l1111llll
    def _1l11l111(self, l11111ll1):
        res = False
        l11lll1 = os.path.join(os.environ[l1ll1ll (u"ࠬࡎࡏࡎࡇࠪध")], l1ll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1ll1ll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l111lllll = {}
        for cookies in l11111ll1:
            l111lllll[cookies.name] = cookies.value
        l1111ll11 = l1ll1ll (u"ࠣࠤप")
        for key in list(l111lllll.keys()):
            l1111ll11 += l1ll1ll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l111lllll[key].strip())
        if not os.path.exists(os.path.dirname(l11lll1)):
            os.makedirs(os.path.dirname(l11lll1))
        vers = int(l1ll1ll (u"ࠥࠦब").join(self.l11l1lll1.split(l1ll1ll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11l11l1l = [l1ll1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1ll1ll (u"ࠨࠣࠡࠤय") + l1ll1ll (u"ࠢ࠮ࠤर") * 60,
                              l1ll1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1ll1ll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1ll1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1111ll11),
                              l1ll1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11l11l1l = [l1ll1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1ll1ll (u"ࠨࠣࠡࠤश") + l1ll1ll (u"ࠢ࠮ࠤष") * 60,
                              l1ll1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1ll1ll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1ll1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1111ll11),
                              l1ll1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l11lll1, l1ll1ll (u"ࠧࡽ़ࠢ")) as l1ll1l11l:
            data = l1ll1ll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11l11l1l)
            l1ll1l11l.write(data)
            l1ll1l11l.write(l1ll1ll (u"ࠢ࡝ࡰࠥा"))
        res = l11lll1
        return res
    def _1l1l111l(self):
        self._11ll111l(l1ll1ll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11l11lll()
    def _11ll111l(self, l11l1llll):
        l11ll1l1l = self.l1l1lll11.dict[l11l1llll.lower()]
        if l11ll1l1l:
            if isinstance(l11ll1l1l, list):
                l1111l111 = l11ll1l1l
            else:
                l1111l111 = [l11ll1l1l]
            if l1ll1ll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11l1llll.lower():
                    for l111llll1 in l1111l111:
                        l1l1l11ll = [l11111l11.upper() for l11111l11 in self._111l11ll]
                        if not l111llll1.upper() in l1l1l11ll:
                            l1ll1l1ll = l1ll1ll (u"ࠥ࠰ࠥࠨु").join(self._111l11ll)
                            l1ll111l1 = l1ll1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11l1llll, l11ll1l1l, l1ll1l1ll, )
                            raise l1lll11ll(l1ll111l1)
    def _11l11lll(self):
        l1l11ll11 = []
        l1l1l1111 = self.l1l1lll11.l11llll1l
        for l11ll1l11 in self._111l11ll:
            if not l11ll1l11 in [l1ll1ll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1ll1ll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1l11ll11.append(l11ll1l11)
        for l1111111l in self.l1l1lll11.l11lll11l:
            if l1111111l in l1l11ll11 and not l1l1l1111:
                l1ll111l1 = l1ll1ll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lll11ll(l1ll111l1)
def l1l1lllll(title, message, l1l111111, l11l111ll=None):
    l1l1lll1l = l1ll111ll()
    l1l1lll1l.l1lll111l(message, title, l1l111111, l11l111ll)
def l11lll1ll(title, message, l1l111111):
    l1l111lll = l1l11ll1l()
    l1l111lll.l11ll11ll(title, message, l1l111111)
    res = l1l111lll.result
    return res
def main():
    try:
        logger.info(l1ll1ll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11lll11)
        system.l1l111l11()
        logger.info(l1ll1ll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1111111(
                l1ll1ll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l11111111 = l1l1111l1()
        l11111111.l11l1ll1l(l1ll1ll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1lll1111 = [item.upper() for item in l11111111.l11lll11l]
        l1l1l1l1l = l1ll1ll (u"ࠧࡔࡏࡏࡇࠥॊ") in l1lll1111
        if l1l1l1l1l:
            logger.info(l1ll1ll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l11l1l1l1 = l11111111.l111ll11l
            for l11111l in l11l1l1l1:
                logger.debug(l1ll1ll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l11111l))
                opener = l1111ll(l11111111.l11llll11, l11111l, l11lll1=None, l1llll=l11lll11)
                opener.open()
                logger.info(l1ll1ll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111111ll = l11111l1l(l11111111)
            l1ll1llll = l111111ll.run()
            l11l1l1l1 = l11111111.l111ll11l
            for l11111l in l11l1l1l1:
                logger.info(l1ll1ll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l11111l))
                opener = l1111ll(l11111111.l11llll11, l11111l, l11lll1=l111111ll.l111l1ll1,
                                l1llll=l11lll11)
                opener.open()
                logger.info(l1ll1ll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11 as e:
        title = l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1llll
        logger.exception(l1ll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1111lll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1111lll1 = el
        l111ll1l1 = l1ll1ll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11ll1, message.strip())
        l1l1lllll(title, l111ll1l1, l1l111111=l11lll11.get_value(l1ll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1ll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l11l111ll=l1111lll1)
        sys.exit(2)
    except l1lll1ll1 as e:
        title = l1ll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1llll
        logger.exception(l1ll1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1111lll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1111lll1 = el
        l111ll1l1 = l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1l1lllll(title, l111ll1l1, l1l111111=l11lll11.get_value(l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1ll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l11l111ll=l1111lll1)
        sys.exit(2)
    except l1111111 as e:
        title = l1ll1ll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1llll
        logger.exception(l1ll1ll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1l1lllll(title, str(e), l1l111111=l11lll11.get_value(l1ll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1ll1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1llll
        logger.exception(l1ll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1l1lllll(title, l1ll1ll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1l111111=l11lll11.get_value(l1ll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1ll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lll11ll as e:
        title = l1ll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1llll
        logger.exception(l1ll1ll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1l1lllll(title, l1ll1ll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1l111111=l11lll11.get_value(l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1ll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l11111l1 as e:
        title = l1ll1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1llll
        logger.exception(l1ll1ll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1l1lllll(title, l1ll1ll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1l111111=l11lll11.get_value(l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1ll1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l11lll:
        logger.info(l1ll1ll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1ll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1llll
        logger.exception(l1ll1ll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1l1lllll(title, l1ll1ll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1l111111=l11lll11.get_value(l1ll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1ll1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()