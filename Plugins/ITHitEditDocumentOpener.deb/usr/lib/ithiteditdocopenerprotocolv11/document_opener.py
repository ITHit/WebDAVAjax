#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1llll1 = 2048
l11111l = 7
def l1lll1l (l11):
    global l1l1111
    ll = ord (l11 [-1])
    l1l1ll1 = l11 [:-1]
    l1l1l = ll % len (l1l1ll1)
    l1l1l11 = l1l1ll1 [:l1l1l] + l1l1ll1 [l1l1l:]
    if l1ll1ll1:
        l11l = l1llllll () .join ([unichr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    return eval (l11l)
import sys, json
import os
import urllib
import l11ll1
from l1lll11 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l11l1l import l1l1ll11, logger, l11llll1
from cookies import l11l1l11 as l11ll1111
from l1ll1ll import l1l11l1
l11l111ll = None
from l1ll11l1 import *
class l1llllllll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1lll1l (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1lll1111):
        self.config = l1lll1111
        self.l111l1ll1 = l11ll1.l11ll1l()
    def l1ll11l11(self):
        data = platform.uname()
        logger.info(l1lll1l (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1lll1l (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1lll1l (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1lll1l (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l111ll1l1():
    def __init__(self, encode = True):
        self._encode = encode
        self._1111l1l1 = [l1lll1l (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1ll1l11l = None
        self.l11l11ll1 = None
        self.l11l11111 = None
        self.l11l1ll11 = None
        self.l111l = None
        self.l1l1l1l1l = None
        self.l111lll1l = None
        self.l1l11111l = None
        self.cookies = None
    def l11l1llll(self, url):
        l1lll1l (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1lll1l (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11l11lll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l111111(url)
        self.dict = self._11llllll(params)
        logger.info(l1lll1l (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l111llll1(self.dict):
            raise l1llll111(l1lll1l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1111l1l1)
        self._1l1lllll(self.dict)
        if self._encode:
            self.l11111ll1()
        self._1ll11ll1()
        self._11llll1l()
        self._1111l11l()
        self._11l1l1ll()
        self.l1111llll()
        logger.info(l1lll1l (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1lll1l (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1ll1l11l))
        logger.info(l1lll1l (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11l11ll1))
        logger.info(l1lll1l (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11l11111))
        logger.info(l1lll1l (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l11l1ll11))
        logger.info(l1lll1l (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l111l))
        logger.info(l1lll1l (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1l1l1l1l))
        logger.info(l1lll1l (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l111lll1l))
        logger.info(l1lll1l (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1l11111l))
    def _1l1lllll(self, l1l1l11ll):
        self.l1ll1l11l = l1l1l11ll.get(l1lll1l (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11l11ll1 = l1l1l11ll.get(l1lll1l (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1lll1l (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11l11111 = l1l1l11ll.get(l1lll1l (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l11l1ll11 = l1l1l11ll.get(l1lll1l (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l111l = l1l1l11ll.get(l1lll1l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1l1l1l1l = l1l1l11ll.get(l1lll1l (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l111lll1l = l1l1l11ll.get(l1lll1l (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1lll1l (u"ࠣࠤ࣏"))
        self.l1l11111l = l1l1l11ll.get(l1lll1l (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1lll1l (u"࣑ࠥࠦ"))
        self.cookies = l1l1l11ll.get(l1lll1l (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1111llll(self):
        l1l11ll1l = False
        if self.l111l:
            if self.l111l.upper() == l1lll1l (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l111l = l1lll1l (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l111l.upper() == l1lll1l (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l111l = l1lll1l (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l111l.upper() == l1lll1l (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l111l = l1lll1l (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l111l.upper() == l1lll1l (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l111l = l1lll1l (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l111l == l1lll1l (u"ࠨࠢࣛ"):
                l1l11ll1l = True
            else:
                self.l111l = self.l111l.lower()
        else:
            l1l11ll1l = True
        if l1l11ll1l:
            self.l111l = l1lll1l (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l11111ll1(self):
        l1lll1l (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1lll1l (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1ll1llll = []
                    for el in self.__dict__.get(key):
                        l1ll1llll.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1ll1llll
    def l11l11l1l(self, l1ll11111):
        res = l1ll11111
        if self._encode:
            res = urllib.parse.quote(l1ll11111, safe=l1lll1l (u"ࠥࠦࣟ"))
        return res
    def _11l11lll(self, url):
        l1lll1l (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1lll1l (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1lll1l (u"ࠨ࠺ࠣ࣢")), l1lll1l (u"ࠧࠨࣣ"), url)
        return url
    def _1l111111(self, url):
        l1lll1l (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11ll1l11 = url.split(l1lll1l (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1lll1l (u"ࠥ࠿ࣦࠧ")))
        result = l11ll1l11
        if len(result) == 0:
            raise l1llll1l1(l1lll1l (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11llllll(self, params):
        l1lll1l (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1lll1l (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1lll1l (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l1111l1 = data.group(l1lll1l (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l1111l1 in (l1lll1l (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1lll1l (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1lll1l (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1lll1l (u"ࠧ࠲࣯ࠢ"))
                elif l1l1111l1 == l1lll1l (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1lll1l (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1lll1l (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l1111l1] = value
        return result
    def _11l1lll1(self, url, scheme):
        l1lll1l (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l111l111l = {l1lll1l (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1lll1l (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11ll11ll = url.split(l1lll1l (u"ࠧࡀࣶࠢ"))
        if len(l11ll11ll) == 1:
            for l1l1l1lll in list(l111l111l.keys()):
                if l1l1l1lll == scheme:
                    url += l1lll1l (u"ࠨ࠺ࠣࣷ") + str(l111l111l[l1l1l1lll])
                    break
        return url
    def _1ll11ll1(self):
        l1lll1l (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l11l1ll11:
            l1l1l1ll1 = self.l11l1ll11[0]
            l11l1l111 = urlparse(l1l1l1ll1)
        if self.l1ll1l11l:
            l1l1l11l1 = urlparse(self.l1ll1l11l)
            if l1l1l11l1.scheme:
                l1ll1ll1l = l1l1l11l1.scheme
            else:
                if l11l1l111.scheme:
                    l1ll1ll1l = l11l1l111.scheme
                else:
                    raise l1111111(
                        l1lll1l (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1l11l1.netloc:
                l1l11lll1 = l1l1l11l1.netloc
            else:
                if l11l1l111.netloc:
                    l1l11lll1 = l11l1l111.netloc
                else:
                    raise l1111111(
                        l1lll1l (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l11lll1 = self._11l1lll1(l1l11lll1, l1ll1ll1l)
            path = l1l1l11l1.path
            if not path.endswith(l1lll1l (u"ࠪ࠳ࠬࣻ")):
                path += l1lll1l (u"ࠫ࠴࠭ࣼ")
            l1111ll1l = ParseResult(scheme=l1ll1ll1l, netloc=l1l11lll1, path=path,
                                         params=l1l1l11l1.params, query=l1l1l11l1.query,
                                         fragment=l1l1l11l1.fragment)
            self.l1ll1l11l = l1111ll1l.geturl()
        else:
            if not l11l1l111.netloc:
                raise l1111111(l1lll1l (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11l1l1l1 = l11l1l111.path
            l1l111l11 = l1lll1l (u"ࠨ࠯ࠣࣾ").join(l11l1l1l1.split(l1lll1l (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1lll1l (u"ࠣ࠱ࠥऀ")
            l1111ll1l = ParseResult(scheme=l11l1l111.scheme,
                                         netloc=self._11l1lll1(l11l1l111.netloc, l11l1l111.scheme),
                                         path=l1l111l11,
                                         params=l1lll1l (u"ࠤࠥँ"),
                                         query=l1lll1l (u"ࠥࠦं"),
                                         fragment=l1lll1l (u"ࠦࠧः")
                                         )
            self.l1ll1l11l = l1111ll1l.geturl()
    def _1111l11l(self):
        l1lll1l (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l11l1ll11:
            l1l1l1ll1 = self.l11l1ll11[0]
            l11l1l111 = urlparse(l1l1l1ll1)
        if self.l1l1l1l1l:
            l1ll1l1ll = urlparse(self.l1l1l1l1l)
            if l1ll1l1ll.scheme:
                l1ll1ll11 = l1ll1l1ll.scheme
            else:
                l1ll1ll11 = l11l1l111.scheme
            if l1ll1l1ll.netloc:
                l111l1l1l = l1ll1l1ll.netloc
            else:
                l111l1l1l = l11l1l111.netloc
            l11ll1ll1 = ParseResult(scheme=l1ll1ll11, netloc=l111l1l1l, path=l1ll1l1ll.path,
                                      params=l1ll1l1ll.params, query=l1ll1l1ll.query,
                                      fragment=l1ll1l1ll.fragment)
            self.l1l1l1l1l = l11ll1ll1.geturl()
    def _11llll1l(self):
        l1lll1l (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l11l1ll11
        self.l11l1ll11 = []
        for item in items:
            l1l1lll11 = urlparse(item.strip(), scheme=l1lll1l (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1l1lll11.path[-1] == l1lll1l (u"ࠣ࠱ࠥइ"):
                l11ll11l1 = l1l1lll11.path
            else:
                path_list = l1l1lll11.path.split(l1lll1l (u"ࠤ࠲ࠦई"))
                l11ll11l1 = l1lll1l (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1lll1l (u"ࠦ࠴ࠨऊ")
            l1ll1l111 = urlparse(self.l1ll1l11l, scheme=l1lll1l (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1l1lll11.scheme:
                scheme = l1l1lll11.scheme
            elif l1ll1l111.scheme:
                scheme = l1ll1l111.scheme
            else:
                scheme = l1lll1l (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1l1lll11.netloc and not l1ll1l111.netloc:
                l1111111l = l1l1lll11.netloc
            elif not l1l1lll11.netloc and l1ll1l111.netloc:
                l1111111l = l1ll1l111.netloc
            elif not l1l1lll11.netloc and not l1ll1l111.netloc and len(self.l11l1ll11) > 0:
                l1ll11lll = urlparse(self.l11l1ll11[len(self.l11l1ll11) - 1])
                l1111111l = l1ll11lll.netloc
            elif l1ll1l111.netloc:
                l1111111l = l1l1lll11.netloc
            elif not l1ll1l111.netloc:
                l1111111l = l1l1lll11.netloc
            if l1l1lll11.path:
                l11lll11l = l1l1lll11.path
            if l1111111l:
                l1111111l = self._11l1lll1(l1111111l, scheme)
                l111l11l1 = ParseResult(scheme=scheme, netloc=l1111111l, path=l11lll11l,
                                          params=l1l1lll11.params,
                                          query=l1l1lll11.query,
                                          fragment=l1l1lll11.fragment)
                self.l11l1ll11.append(l111l11l1.geturl())
    def _11l1l1ll(self):
        l1lll1l (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l11lll1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l1lll1l (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l11lll1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l1lll1l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11l11111:
            l1l1lll1l = []
            for l1l1l111l in self.l11l11111:
                if l1l1l111l not in [x[l1lll1l (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l1lll1l.append(l1l1l111l)
            if l1l1lll1l:
                l11lll1l = l1lll1l (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1lll1l (u"ࠧ࠲ࠠࠣऒ").join(l1l1lll1l))
                raise l111ll11(l1lll1l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11lll1l)
    def l111llll1(self, params):
        l1lll1l (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1ll11l1l = True
        for param in self._1111l1l1:
            if not params.get(param.lower()):
                l1ll11l1l = False
        return l1ll11l1l
class l1l1ll11l():
    def __init__(self, l1ll111l1):
        self.l1lll111l = l11ll1.l11ll1l()
        self.l111ll111 = self.l1l1llll1()
        self.l1l1ll111 = self.l11lll1l1()
        self.l1ll111l1 = l1ll111l1
        self._111111ll = [l1lll1l (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1lll1l (u"ࠤࡑࡳࡳ࡫ࠢख"), l1lll1l (u"ࠥࡅࡱࡲࠢग"), l1lll1l (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1lll1l (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1lll1l (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1lll1l (u"ࠢࡊࡇࠥछ"), l1lll1l (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l11l11l = [l1lll1l (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1lll1l (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1lll1l (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1lll1l (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l111lll11 = None
    def l1l1llll1(self):
        l1l1ll1l1 = l1lll1l (u"ࠨࡎࡰࡰࡨࠦड")
        return l1l1ll1l1
    def l11lll1l1(self):
        l1111lll1 = 0
        return l1111lll1
    def l11ll1l1l(self):
        l11lll1l = l1lll1l (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1l1ll111)
        l11lll1l += l1lll1l (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l111l1l11(l1l1ll11, l11lll1l, t=1)
        return res
    def run(self):
        l1111l1ll = True
        self._1l111l1l()
        result = []
        try:
            for cookie in l11ll1111(l111llll=self.l1ll111l1.cookies).run():
                result.append(cookie)
        except l1llll11l as e:
            logger.exception(l1lll1l (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1l1ll1ll = self._1l1111ll(result)
            if l1l1ll1ll:
                logger.info(l1lll1l (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1l1ll1ll)
                self.l111lll11 = l1l1ll1ll
            else:
                logger.info(l1lll1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1l1ll1ll)
            l1111l1ll = True
        else:
            l1111l1ll = False
        return l1111l1ll
    def _1l1111ll(self, l1l111ll1):
        res = False
        l1l1l1l = os.path.join(os.environ[l1lll1l (u"ࠬࡎࡏࡎࡇࠪध")], l1lll1l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1lll1l (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11llll11 = {}
        for cookies in l1l111ll1:
            l11llll11[cookies.name] = cookies.value
        l1l1l1l11 = l1lll1l (u"ࠣࠤप")
        for key in list(l11llll11.keys()):
            l1l1l1l11 += l1lll1l (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11llll11[key].strip())
        if not os.path.exists(os.path.dirname(l1l1l1l)):
            os.makedirs(os.path.dirname(l1l1l1l))
        vers = int(l1lll1l (u"ࠥࠦब").join(self.l1lll111l.split(l1lll1l (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11lll111 = [l1lll1l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1lll1l (u"ࠨࠣࠡࠤय") + l1lll1l (u"ࠢ࠮ࠤर") * 60,
                              l1lll1l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1lll1l (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1lll1l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l1l1l11),
                              l1lll1l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11lll111 = [l1lll1l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1lll1l (u"ࠨࠣࠡࠤश") + l1lll1l (u"ࠢ࠮ࠤष") * 60,
                              l1lll1l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1lll1l (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1lll1l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l1l1l11),
                              l1lll1l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1l1l1l, l1lll1l (u"ࠧࡽ़ࠢ")) as l1ll1lll1:
            data = l1lll1l (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11lll111)
            l1ll1lll1.write(data)
            l1ll1lll1.write(l1lll1l (u"ࠢ࡝ࡰࠥा"))
        res = l1l1l1l
        return res
    def _1l111l1l(self):
        self._111l1111(l1lll1l (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1111ll11()
    def _111l1111(self, l111ll11l):
        l1l11ll11 = self.l1ll111l1.dict[l111ll11l.lower()]
        if l1l11ll11:
            if isinstance(l1l11ll11, list):
                l11l111l1 = l1l11ll11
            else:
                l11l111l1 = [l1l11ll11]
            if l1lll1l (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l111ll11l.lower():
                    for l1l11llll in l11l111l1:
                        l11111l11 = [l1ll1111l.upper() for l1ll1111l in self._111111ll]
                        if not l1l11llll.upper() in l11111l11:
                            l11l11l11 = l1lll1l (u"ࠥ࠰ࠥࠨु").join(self._111111ll)
                            l111lllll = l1lll1l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l111ll11l, l1l11ll11, l11l11l11, )
                            raise l11111l1(l111lllll)
    def _1111ll11(self):
        l11ll1lll = []
        l1111l111 = self.l1ll111l1.l11l11111
        for l1l11l111 in self._111111ll:
            if not l1l11l111 in [l1lll1l (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1lll1l (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11ll1lll.append(l1l11l111)
        for l11l1ll1l in self.l1ll111l1.l11l11ll1:
            if l11l1ll1l in l11ll1lll and not l1111l111:
                l111lllll = l1lll1l (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l11111l1(l111lllll)
def l111l1lll(title, message, l11111lll, l1l1l1111=None):
    l11111111 = l1l11l1ll()
    l11111111.l1ll111ll(message, title, l11111lll, l1l1l1111)
def l1lll11l1(title, message, l11111lll):
    l1l11l1l1 = l11111l1l()
    l1l11l1l1.l11lllll1(title, message, l11111lll)
    res = l1l11l1l1.result
    return res
def main():
    try:
        logger.info(l1lll1l (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11llll1)
        system.l1ll11l11()
        logger.info(l1lll1l (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1llll111(
                l1lll1l (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111ll1ll = l111ll1l1()
        l111ll1ll.l11l1llll(l1lll1l (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11l1l11l = [item.upper() for item in l111ll1ll.l11l11ll1]
        l11l1111l = l1lll1l (u"ࠧࡔࡏࡏࡇࠥॊ") in l11l1l11l
        if l11l1111l:
            logger.info(l1lll1l (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l111l11ll = l111ll1ll.l11l1ll11
            for l1lll in l111l11ll:
                logger.debug(l1lll1l (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1lll))
                opener = l1l11l1(l111ll1ll.l1ll1l11l, l1lll, l1l1l1l=None, l1ll1111=l11llll1)
                opener.open()
                logger.info(l1lll1l (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11ll111l = l1l1ll11l(l111ll1ll)
            l111111l1 = l11ll111l.run()
            l111l11ll = l111ll1ll.l11l1ll11
            for l1lll in l111l11ll:
                logger.info(l1lll1l (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1lll))
                opener = l1l11l1(l111ll1ll.l1ll1l11l, l1lll, l1l1l1l=l11ll111l.l111lll11,
                                l1ll1111=l11llll1)
                opener.open()
                logger.info(l1lll1l (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1ll1 as e:
        title = l1lll1l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1ll11
        logger.exception(l1lll1l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1ll1l1l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll1l1l1 = el
        l1l111lll = l1lll1l (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11l1ll, message.strip())
        l111l1lll(title, l1l111lll, l11111lll=l11llll1.get_value(l1lll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1lll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1l1l1111=l1ll1l1l1)
        sys.exit(2)
    except l1llllll1 as e:
        title = l1lll1l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1ll11
        logger.exception(l1lll1l (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1ll1l1l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll1l1l1 = el
        l1l111lll = l1lll1l (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l111l1lll(title, l1l111lll, l11111lll=l11llll1.get_value(l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1lll1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1l1l1111=l1ll1l1l1)
        sys.exit(2)
    except l1llll111 as e:
        title = l1lll1l (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1ll11
        logger.exception(l1lll1l (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l111l1lll(title, str(e), l11111lll=l11llll1.get_value(l1lll1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1lll1l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1lll1l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1ll11
        logger.exception(l1lll1l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l111l1lll(title, l1lll1l (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11111lll=l11llll1.get_value(l1lll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1lll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l11111l1 as e:
        title = l1lll1l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1ll11
        logger.exception(l1lll1l (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l111l1lll(title, l1lll1l (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11111lll=l11llll1.get_value(l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1lll1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1l11 as e:
        title = l1lll1l (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1ll11
        logger.exception(l1lll1l (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l111l1lll(title, l1lll1l (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11111lll=l11llll1.get_value(l1lll1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1lll1l (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1lll1l1:
        logger.info(l1lll1l (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1lll1l (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1ll11
        logger.exception(l1lll1l (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l111l1lll(title, l1lll1l (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11111lll=l11llll1.get_value(l1lll1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1lll1l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1lll1l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()