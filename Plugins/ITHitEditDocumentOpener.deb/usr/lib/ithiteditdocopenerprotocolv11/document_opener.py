#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll1l = 2048
l1lll111 = 7
def l11l (l1l11ll):
    global l11llll
    l1l1l1 = ord (l1l11ll [-1])
    l1ll1l1 = l1l11ll [:-1]
    l111 = l1l1l1 % len (l1ll1l1)
    l1l1ll = l1ll1l1 [:l111] + l1ll1l1 [l111:]
    if l1ll111:
        l1111l1 = l11ll11 () .join ([unichr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    return eval (l1111l1)
import sys, json
import os
import urllib
import l1llll
from l11l1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l11111 import l11ll1l1, logger, l1l1l11l
from cookies import l11l11ll as l11l11l11
from l11ll import l11l11
l11lll1ll = None
from l111ll import *
class l1l11llll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l11l (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l11ll11):
        self.config = l1l11ll11
        self.l1l1l1lll = l1llll.l1ll111l()
    def l111l1l1l(self):
        data = platform.uname()
        logger.info(l11l (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l11l (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l11l (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l11l (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll111ll():
    def __init__(self, encode = True):
        self._encode = encode
        self._1111111l = [l11l (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l1l11ll = None
        self.l111l1lll = None
        self.l111l11l1 = None
        self.l1ll1lll1 = None
        self.l1lll1l1 = None
        self.l111l111l = None
        self.l1ll1l1l1 = None
        self.l1lll1111 = None
        self.cookies = None
    def l111l11ll(self, url):
        l11l (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l11l (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11ll1111(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11l1lll1(url)
        self.dict = self._11l1l111(params)
        logger.info(l11l (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1l111111(self.dict):
            raise l11111ll(l11l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1111111l)
        self._1l11lll1(self.dict)
        if self._encode:
            self.l11lll11l()
        self._11l111l1()
        self._1l1llll1()
        self._1l1l1l1l()
        self._111lll11()
        self.l11llll11()
        logger.info(l11l (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l11l (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l1l11ll))
        logger.info(l11l (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l111l1lll))
        logger.info(l11l (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l111l11l1))
        logger.info(l11l (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1ll1lll1))
        logger.info(l11l (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1lll1l1))
        logger.info(l11l (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l111l111l))
        logger.info(l11l (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1ll1l1l1))
        logger.info(l11l (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1lll1111))
    def _1l11lll1(self, l1ll1ll11):
        self.l1l1l11ll = l1ll1ll11.get(l11l (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l111l1lll = l1ll1ll11.get(l11l (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l11l (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l111l11l1 = l1ll1ll11.get(l11l (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1ll1lll1 = l1ll1ll11.get(l11l (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1lll1l1 = l1ll1ll11.get(l11l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l111l111l = l1ll1ll11.get(l11l (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1ll1l1l1 = l1ll1ll11.get(l11l (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l11l (u"ࠣࠤ࣏"))
        self.l1lll1111 = l1ll1ll11.get(l11l (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l11l (u"࣑ࠥࠦ"))
        self.cookies = l1ll1ll11.get(l11l (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11llll11(self):
        l1l11l111 = False
        if self.l1lll1l1:
            if self.l1lll1l1.upper() == l11l (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1lll1l1 = l11l (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1lll1l1.upper() == l11l (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1lll1l1 = l11l (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1lll1l1.upper() == l11l (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1lll1l1 = l11l (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1lll1l1.upper() == l11l (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1lll1l1 = l11l (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1lll1l1 == l11l (u"ࠨࠢࣛ"):
                l1l11l111 = True
            else:
                self.l1lll1l1 = self.l1lll1l1.lower()
        else:
            l1l11l111 = True
        if l1l11l111:
            self.l1lll1l1 = l11l (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l11lll11l(self):
        l11l (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l11l (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1ll1111l = []
                    for el in self.__dict__.get(key):
                        l1ll1111l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1ll1111l
    def l1ll1l1ll(self, l1l1lllll):
        res = l1l1lllll
        if self._encode:
            res = urllib.parse.quote(l1l1lllll, safe=l11l (u"ࠥࠦࣟ"))
        return res
    def _11ll1111(self, url):
        l11l (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l11l (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l11l (u"ࠨ࠺ࠣ࣢")), l11l (u"ࠧࠨࣣ"), url)
        return url
    def _11l1lll1(self, url):
        l11l (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l111l1l11 = url.split(l11l (u"ࠤࡾ࠴ࢂࠨࣥ").format(l11l (u"ࠥ࠿ࣦࠧ")))
        result = l111l1l11
        if len(result) == 0:
            raise l1llllll1(l11l (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11l1l111(self, params):
        l11l (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l11l (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l11l (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1ll11l1l = data.group(l11l (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1ll11l1l in (l11l (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l11l (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l11l (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l11l (u"ࠧ࠲࣯ࠢ"))
                elif l1ll11l1l == l11l (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l11l (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l11l (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1ll11l1l] = value
        return result
    def _11l1l1l1(self, url, scheme):
        l11l (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1lll111l = {l11l (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l11l (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11ll1l1l = url.split(l11l (u"ࠧࡀࣶࠢ"))
        if len(l11ll1l1l) == 1:
            for l111111ll in list(l1lll111l.keys()):
                if l111111ll == scheme:
                    url += l11l (u"ࠨ࠺ࠣࣷ") + str(l1lll111l[l111111ll])
                    break
        return url
    def _11l111l1(self):
        l11l (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1ll1lll1:
            l1l1l11l1 = self.l1ll1lll1[0]
            l1111lll1 = urlparse(l1l1l11l1)
        if self.l1l1l11ll:
            l11ll11ll = urlparse(self.l1l1l11ll)
            if l11ll11ll.scheme:
                l11llll1l = l11ll11ll.scheme
            else:
                if l1111lll1.scheme:
                    l11llll1l = l1111lll1.scheme
                else:
                    raise l1llll111(
                        l11l (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l11ll11ll.netloc:
                l111l1ll1 = l11ll11ll.netloc
            else:
                if l1111lll1.netloc:
                    l111l1ll1 = l1111lll1.netloc
                else:
                    raise l1llll111(
                        l11l (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l111l1ll1 = self._11l1l1l1(l111l1ll1, l11llll1l)
            path = l11ll11ll.path
            if not path.endswith(l11l (u"ࠪ࠳ࠬࣻ")):
                path += l11l (u"ࠫ࠴࠭ࣼ")
            l111111l1 = ParseResult(scheme=l11llll1l, netloc=l111l1ll1, path=path,
                                         params=l11ll11ll.params, query=l11ll11ll.query,
                                         fragment=l11ll11ll.fragment)
            self.l1l1l11ll = l111111l1.geturl()
        else:
            if not l1111lll1.netloc:
                raise l1llll111(l11l (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l111llll1 = l1111lll1.path
            l1l11111l = l11l (u"ࠨ࠯ࠣࣾ").join(l111llll1.split(l11l (u"ࠢ࠰ࠤࣿ"))[:-1]) + l11l (u"ࠣ࠱ࠥऀ")
            l111111l1 = ParseResult(scheme=l1111lll1.scheme,
                                         netloc=self._11l1l1l1(l1111lll1.netloc, l1111lll1.scheme),
                                         path=l1l11111l,
                                         params=l11l (u"ࠤࠥँ"),
                                         query=l11l (u"ࠥࠦं"),
                                         fragment=l11l (u"ࠦࠧः")
                                         )
            self.l1l1l11ll = l111111l1.geturl()
    def _1l1l1l1l(self):
        l11l (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1ll1lll1:
            l1l1l11l1 = self.l1ll1lll1[0]
            l1111lll1 = urlparse(l1l1l11l1)
        if self.l111l111l:
            l1l11l1ll = urlparse(self.l111l111l)
            if l1l11l1ll.scheme:
                l11111l11 = l1l11l1ll.scheme
            else:
                l11111l11 = l1111lll1.scheme
            if l1l11l1ll.netloc:
                l11ll1ll1 = l1l11l1ll.netloc
            else:
                l11ll1ll1 = l1111lll1.netloc
            l1ll1l111 = ParseResult(scheme=l11111l11, netloc=l11ll1ll1, path=l1l11l1ll.path,
                                      params=l1l11l1ll.params, query=l1l11l1ll.query,
                                      fragment=l1l11l1ll.fragment)
            self.l111l111l = l1ll1l111.geturl()
    def _1l1llll1(self):
        l11l (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1ll1lll1
        self.l1ll1lll1 = []
        for item in items:
            l11l1llll = urlparse(item.strip(), scheme=l11l (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11l1llll.path[-1] == l11l (u"ࠣ࠱ࠥइ"):
                l11l11lll = l11l1llll.path
            else:
                path_list = l11l1llll.path.split(l11l (u"ࠤ࠲ࠦई"))
                l11l11lll = l11l (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l11l (u"ࠦ࠴ࠨऊ")
            l1ll11l11 = urlparse(self.l1l1l11ll, scheme=l11l (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11l1llll.scheme:
                scheme = l11l1llll.scheme
            elif l1ll11l11.scheme:
                scheme = l1ll11l11.scheme
            else:
                scheme = l11l (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11l1llll.netloc and not l1ll11l11.netloc:
                l11l1l11l = l11l1llll.netloc
            elif not l11l1llll.netloc and l1ll11l11.netloc:
                l11l1l11l = l1ll11l11.netloc
            elif not l11l1llll.netloc and not l1ll11l11.netloc and len(self.l1ll1lll1) > 0:
                l1111l1l1 = urlparse(self.l1ll1lll1[len(self.l1ll1lll1) - 1])
                l11l1l11l = l1111l1l1.netloc
            elif l1ll11l11.netloc:
                l11l1l11l = l11l1llll.netloc
            elif not l1ll11l11.netloc:
                l11l1l11l = l11l1llll.netloc
            if l11l1llll.path:
                l1111ll11 = l11l1llll.path
            if l11l1l11l:
                l11l1l11l = self._11l1l1l1(l11l1l11l, scheme)
                l111ll111 = ParseResult(scheme=scheme, netloc=l11l1l11l, path=l1111ll11,
                                          params=l11l1llll.params,
                                          query=l11l1llll.query,
                                          fragment=l11l1llll.fragment)
                self.l1ll1lll1.append(l111ll111.geturl())
    def _111lll11(self):
        l11l (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l111lll1l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l1l1(l11l (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l111lll1l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l1l1(l11l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l111l11l1:
            l111lllll = []
            for l1l1l111l in self.l111l11l1:
                if l1l1l111l not in [x[l11l (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l111lllll.append(l1l1l111l)
            if l111lllll:
                l1l111l1 = l11l (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l11l (u"ࠧ࠲ࠠࠣऒ").join(l111lllll))
                raise l111l1l1(l11l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l111l1)
    def l1l111111(self, params):
        l11l (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1l1l1l11 = True
        for param in self._1111111l:
            if not params.get(param.lower()):
                l1l1l1l11 = False
        return l1l1l1l11
class l11ll111l():
    def __init__(self, l1l11ll1l):
        self.l1111l11l = l1llll.l1ll111l()
        self.l11111111 = self.l1l111l1l()
        self.l1ll1llll = self.l1l1ll1ll()
        self.l1l11ll1l = l1l11ll1l
        self._11ll1lll = [l11l (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l11l (u"ࠤࡑࡳࡳ࡫ࠢख"), l11l (u"ࠥࡅࡱࡲࠢग"), l11l (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l11l (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l11l (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l11l (u"ࠢࡊࡇࠥछ"), l11l (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._11l1111l = [l11l (u"ࠤ࡙࡭ࡪࡽࠢझ"), l11l (u"ࠥࡉࡩ࡯ࡴࠣञ"), l11l (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l11l (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l1ll111 = None
    def l1l111l1l(self):
        l11ll11l1 = l11l (u"ࠨࡎࡰࡰࡨࠦड")
        return l11ll11l1
    def l1l1ll1ll(self):
        l1l111lll = 0
        return l1l111lll
    def l1111llll(self):
        l1l111l1 = l11l (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1ll1llll)
        l1l111l1 += l11l (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11l111ll(l11ll1l1, l1l111l1, t=1)
        return res
    def run(self):
        l1l111ll1 = True
        self._11111lll()
        result = []
        try:
            for cookie in l11l11l11(l111l1ll=self.l1l11ll1l.cookies).run():
                result.append(cookie)
        except l1lll1ll1 as e:
            logger.exception(l11l (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11111l1l = self._1l11l1l1(result)
            if l11111l1l:
                logger.info(l11l (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11111l1l)
                self.l1l1ll111 = l11111l1l
            else:
                logger.info(l11l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11111l1l)
            l1l111ll1 = True
        else:
            l1l111ll1 = False
        return l1l111ll1
    def _1l11l1l1(self, l111ll1ll):
        res = False
        l111l1 = os.path.join(os.environ[l11l (u"ࠬࡎࡏࡎࡇࠪध")], l11l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l11l (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1l1l1ll1 = {}
        for cookies in l111ll1ll:
            l1l1l1ll1[cookies.name] = cookies.value
        l1l1ll11l = l11l (u"ࠣࠤप")
        for key in list(l1l1l1ll1.keys()):
            l1l1ll11l += l11l (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1l1l1ll1[key].strip())
        if not os.path.exists(os.path.dirname(l111l1)):
            os.makedirs(os.path.dirname(l111l1))
        vers = int(l11l (u"ࠥࠦब").join(self.l1111l11l.split(l11l (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1111l1ll = [l11l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l11l (u"ࠨࠣࠡࠤय") + l11l (u"ࠢ࠮ࠤर") * 60,
                              l11l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l11l (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l11l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l1ll11l),
                              l11l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1111l1ll = [l11l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l11l (u"ࠨࠣࠡࠤश") + l11l (u"ࠢ࠮ࠤष") * 60,
                              l11l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l11l (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l11l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l1ll11l),
                              l11l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l111l1, l11l (u"ࠧࡽ़ࠢ")) as l1ll11lll:
            data = l11l (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1111l1ll)
            l1ll11lll.write(data)
            l1ll11lll.write(l11l (u"ࠢ࡝ࡰࠥा"))
        res = l111l1
        return res
    def _11111lll(self):
        self._1l1111ll(l11l (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1l1ll1l1()
    def _1l1111ll(self, l1lll11l1):
        l11l11111 = self.l1l11ll1l.dict[l1lll11l1.lower()]
        if l11l11111:
            if isinstance(l11l11111, list):
                l1ll11ll1 = l11l11111
            else:
                l1ll11ll1 = [l11l11111]
            if l11l (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1lll11l1.lower():
                    for l1111ll1l in l1ll11ll1:
                        l11l11l1l = [l1ll1l11l.upper() for l1ll1l11l in self._11ll1lll]
                        if not l1111ll1l.upper() in l11l11l1l:
                            l111l1111 = l11l (u"ࠥ࠰ࠥࠨु").join(self._11ll1lll)
                            l1l111l11 = l11l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1lll11l1, l11l11111, l111l1111, )
                            raise l1lllllll(l1l111l11)
    def _1l1ll1l1(self):
        l11lll1l1 = []
        l11lll111 = self.l1l11ll1l.l111l11l1
        for l111ll11l in self._11ll1lll:
            if not l111ll11l in [l11l (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l11l (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11lll1l1.append(l111ll11l)
        for l1l1lll1l in self.l1l11ll1l.l111l1lll:
            if l1l1lll1l in l11lll1l1 and not l11lll111:
                l1l111l11 = l11l (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lllllll(l1l111l11)
def l1l1l1111(title, message, l11llllll, l1l11l11l=None):
    l11l1ll11 = l11l1ll1l()
    l11l1ll11.l1111l111(message, title, l11llllll, l1l11l11l)
def l11l11ll1(title, message, l11llllll):
    l1llllllll = l11ll1l11()
    l1llllllll.l1l1111l1(title, message, l11llllll)
    res = l1llllllll.result
    return res
def main():
    try:
        logger.info(l11l (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1l11l)
        system.l111l1l1l()
        logger.info(l11l (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l11111ll(
                l11l (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1l1lll11 = l1ll111ll()
        l1l1lll11.l111l11ll(l11l (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11l1l1ll = [item.upper() for item in l1l1lll11.l111l1lll]
        l1ll11111 = l11l (u"ࠧࡔࡏࡏࡇࠥॊ") in l11l1l1ll
        if l1ll11111:
            logger.info(l11l (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l11111ll1 = l1l1lll11.l1ll1lll1
            for l1l111l in l11111ll1:
                logger.debug(l11l (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1l111l))
                opener = l11l11(l1l1lll11.l1l1l11ll, l1l111l, l111l1=None, l11l1ll=l1l1l11l)
                opener.open()
                logger.info(l11l (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l1ll111l1 = l11ll111l(l1l1lll11)
            l11lllll1 = l1ll111l1.run()
            l11111ll1 = l1l1lll11.l1ll1lll1
            for l1l111l in l11111ll1:
                logger.info(l11l (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1l111l))
                opener = l11l11(l1l1lll11.l1l1l11ll, l1l111l, l111l1=l1ll111l1.l1l1ll111,
                                l11l1ll=l1l1l11l)
                opener.open()
                logger.info(l11l (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1llll1 as e:
        title = l11l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11ll1l1
        logger.exception(l11l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l111ll1l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111ll1l1 = el
        l1ll1ll1l = l11l (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l111111, message.strip())
        l1l1l1111(title, l1ll1ll1l, l11llllll=l1l1l11l.get_value(l11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1l11l11l=l111ll1l1)
        sys.exit(2)
    except l1lll11ll as e:
        title = l11l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11ll1l1
        logger.exception(l11l (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l111ll1l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111ll1l1 = el
        l1ll1ll1l = l11l (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1l1l1111(title, l1ll1ll1l, l11llllll=l1l1l11l.get_value(l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1l11l11l=l111ll1l1)
        sys.exit(2)
    except l11111ll as e:
        title = l11l (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11ll1l1
        logger.exception(l11l (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1l1l1111(title, str(e), l11llllll=l1l1l11l.get_value(l11l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l11l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l11l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11ll1l1
        logger.exception(l11l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1l1l1111(title, l11l (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11llllll=l1l1l11l.get_value(l11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lllllll as e:
        title = l11l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11ll1l1
        logger.exception(l11l (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1l1l1111(title, l11l (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11llllll=l1l1l11l.get_value(l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lllll1l as e:
        title = l11l (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11ll1l1
        logger.exception(l11l (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1l1l1111(title, l11l (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11llllll=l1l1l11l.get_value(l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l11l (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1l11l1:
        logger.info(l11l (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l11l (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11ll1l1
        logger.exception(l11l (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1l1l1111(title, l11l (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11llllll=l1l1l11l.get_value(l11l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l11l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l11l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()