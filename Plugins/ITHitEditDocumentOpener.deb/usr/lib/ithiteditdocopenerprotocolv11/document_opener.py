#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111111 = sys.version_info [0] == 2
l111 = 2048
l1ll11 = 7
def l1ll1l1 (l1111ll):
    global l1ll1l11
    l1l1ll = ord (l1111ll [-1])
    l1111 = l1111ll [:-1]
    l11l1 = l1l1ll % len (l1111)
    l111lll = l1111 [:l11l1] + l1111 [l11l1:]
    if l111111:
        l111l1 = l11lll () .join ([unichr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    return eval (l111l1)
import sys, json
import os
import urllib
import ll
from l1l1lll import *
import platform
from urllib.parse import urlparse, ParseResult
from l11llll1 import l11ll11l, logger, l1l1l1l1
from cookies import l111lll1 as l11l11l1l
from l1lllll1 import l1ll1ll
l11l111ll = None
from l111ll import *
class l11l1llll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1l1 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1lll11l1):
        self.config = l1lll11l1
        self.l111l1l11 = ll.l1l111()
    def l1l1l1111(self):
        data = platform.uname()
        logger.info(l1ll1l1 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1ll1l1 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1ll1l1 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1ll1l1 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l11l11111():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l1ll11l = [l1ll1l1 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l1111ll = None
        self.l1llllllll = None
        self.l111l1111 = None
        self.l1ll11lll = None
        self.l1ll11l1 = None
        self.l1l11llll = None
        self.l1ll11ll1 = None
        self.l111ll111 = None
        self.cookies = None
    def l1ll1ll1l(self, url):
        l1ll1l1 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1ll1l1 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11ll1lll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l1ll1ll(url)
        self.dict = self._11111111(params)
        logger.info(l1ll1l1 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l111l111l(self.dict):
            raise l11111ll(l1ll1l1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1l1ll11l)
        self._1l111l11(self.dict)
        if self._encode:
            self.l11l11ll1()
        self._1ll111ll()
        self._111ll1ll()
        self._1l1ll1l1()
        self._11lll1ll()
        self.l1l1ll111()
        logger.info(l1ll1l1 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1ll1l1 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l1111ll))
        logger.info(l1ll1l1 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1llllllll))
        logger.info(l1ll1l1 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l111l1111))
        logger.info(l1ll1l1 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1ll11lll))
        logger.info(l1ll1l1 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1ll11l1))
        logger.info(l1ll1l1 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1l11llll))
        logger.info(l1ll1l1 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1ll11ll1))
        logger.info(l1ll1l1 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l111ll111))
    def _1l111l11(self, l111lllll):
        self.l1l1111ll = l111lllll.get(l1ll1l1 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1llllllll = l111lllll.get(l1ll1l1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1ll1l1 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l111l1111 = l111lllll.get(l1ll1l1 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1ll11lll = l111lllll.get(l1ll1l1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1ll11l1 = l111lllll.get(l1ll1l1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1l11llll = l111lllll.get(l1ll1l1 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1ll11ll1 = l111lllll.get(l1ll1l1 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1ll1l1 (u"ࠣࠤ࣏"))
        self.l111ll111 = l111lllll.get(l1ll1l1 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1ll1l1 (u"࣑ࠥࠦ"))
        self.cookies = l111lllll.get(l1ll1l1 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l1ll111(self):
        l111l11l1 = False
        if self.l1ll11l1:
            if self.l1ll11l1.upper() == l1ll1l1 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1ll11l1 = l1ll1l1 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1ll11l1.upper() == l1ll1l1 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1ll11l1 = l1ll1l1 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1ll11l1.upper() == l1ll1l1 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1ll11l1 = l1ll1l1 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1ll11l1.upper() == l1ll1l1 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1ll11l1 = l1ll1l1 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1ll11l1 == l1ll1l1 (u"ࠨࠢࣛ"):
                l111l11l1 = True
            else:
                self.l1ll11l1 = self.l1ll11l1.lower()
        else:
            l111l11l1 = True
        if l111l11l1:
            self.l1ll11l1 = l1ll1l1 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l11l11ll1(self):
        l1ll1l1 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1l1 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1111111l = []
                    for el in self.__dict__.get(key):
                        l1111111l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1111111l
    def l1l1l1ll1(self, l1ll111l1):
        res = l1ll111l1
        if self._encode:
            res = urllib.parse.quote(l1ll111l1, safe=l1ll1l1 (u"ࠥࠦࣟ"))
        return res
    def _11ll1lll(self, url):
        l1ll1l1 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1ll1l1 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1ll1l1 (u"ࠨ࠺ࠣ࣢")), l1ll1l1 (u"ࠧࠨࣣ"), url)
        return url
    def _1l1ll1ll(self, url):
        l1ll1l1 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11lll11l = url.split(l1ll1l1 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1ll1l1 (u"ࠥ࠿ࣦࠧ")))
        result = l11lll11l
        if len(result) == 0:
            raise l1111111(l1ll1l1 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11111111(self, params):
        l1ll1l1 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1ll1l1 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1ll1l1 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11ll111l = data.group(l1ll1l1 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11ll111l in (l1ll1l1 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1ll1l1 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1ll1l1 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1ll1l1 (u"ࠧ࠲࣯ࠢ"))
                elif l11ll111l == l1ll1l1 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1ll1l1 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1l1 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11ll111l] = value
        return result
    def _11lll111(self, url, scheme):
        l1ll1l1 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l1lll11 = {l1ll1l1 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1ll1l1 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1ll1ll11 = url.split(l1ll1l1 (u"ࠧࡀࣶࠢ"))
        if len(l1ll1ll11) == 1:
            for l1ll1llll in list(l1l1lll11.keys()):
                if l1ll1llll == scheme:
                    url += l1ll1l1 (u"ࠨ࠺ࠣࣷ") + str(l1l1lll11[l1ll1llll])
                    break
        return url
    def _1ll111ll(self):
        l1ll1l1 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1ll11lll:
            l11ll1l1l = self.l1ll11lll[0]
            l1l11lll1 = urlparse(l11ll1l1l)
        if self.l1l1111ll:
            l1111l1ll = urlparse(self.l1l1111ll)
            if l1111l1ll.scheme:
                l1ll1l11l = l1111l1ll.scheme
            else:
                if l1l11lll1.scheme:
                    l1ll1l11l = l1l11lll1.scheme
                else:
                    raise l1lll1l11(
                        l1ll1l1 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1111l1ll.netloc:
                l111llll1 = l1111l1ll.netloc
            else:
                if l1l11lll1.netloc:
                    l111llll1 = l1l11lll1.netloc
                else:
                    raise l1lll1l11(
                        l1ll1l1 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l111llll1 = self._11lll111(l111llll1, l1ll1l11l)
            path = l1111l1ll.path
            if not path.endswith(l1ll1l1 (u"ࠪ࠳ࠬࣻ")):
                path += l1ll1l1 (u"ࠫ࠴࠭ࣼ")
            l111l1ll1 = ParseResult(scheme=l1ll1l11l, netloc=l111llll1, path=path,
                                         params=l1111l1ll.params, query=l1111l1ll.query,
                                         fragment=l1111l1ll.fragment)
            self.l1l1111ll = l111l1ll1.geturl()
        else:
            if not l1l11lll1.netloc:
                raise l1lll1l11(l1ll1l1 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1lll111l = l1l11lll1.path
            l11llll11 = l1ll1l1 (u"ࠨ࠯ࠣࣾ").join(l1lll111l.split(l1ll1l1 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1ll1l1 (u"ࠣ࠱ࠥऀ")
            l111l1ll1 = ParseResult(scheme=l1l11lll1.scheme,
                                         netloc=self._11lll111(l1l11lll1.netloc, l1l11lll1.scheme),
                                         path=l11llll11,
                                         params=l1ll1l1 (u"ࠤࠥँ"),
                                         query=l1ll1l1 (u"ࠥࠦं"),
                                         fragment=l1ll1l1 (u"ࠦࠧः")
                                         )
            self.l1l1111ll = l111l1ll1.geturl()
    def _1l1ll1l1(self):
        l1ll1l1 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1ll11lll:
            l11ll1l1l = self.l1ll11lll[0]
            l1l11lll1 = urlparse(l11ll1l1l)
        if self.l1l11llll:
            l1ll1lll1 = urlparse(self.l1l11llll)
            if l1ll1lll1.scheme:
                l11l1l11l = l1ll1lll1.scheme
            else:
                l11l1l11l = l1l11lll1.scheme
            if l1ll1lll1.netloc:
                l11l1l1ll = l1ll1lll1.netloc
            else:
                l11l1l1ll = l1l11lll1.netloc
            l111111l1 = ParseResult(scheme=l11l1l11l, netloc=l11l1l1ll, path=l1ll1lll1.path,
                                      params=l1ll1lll1.params, query=l1ll1lll1.query,
                                      fragment=l1ll1lll1.fragment)
            self.l1l11llll = l111111l1.geturl()
    def _111ll1ll(self):
        l1ll1l1 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1ll11lll
        self.l1ll11lll = []
        for item in items:
            l1ll1111l = urlparse(item.strip(), scheme=l1ll1l1 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1ll1111l.path[-1] == l1ll1l1 (u"ࠣ࠱ࠥइ"):
                l1l1l1lll = l1ll1111l.path
            else:
                path_list = l1ll1111l.path.split(l1ll1l1 (u"ࠤ࠲ࠦई"))
                l1l1l1lll = l1ll1l1 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1ll1l1 (u"ࠦ࠴ࠨऊ")
            l1l11l1ll = urlparse(self.l1l1111ll, scheme=l1ll1l1 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1ll1111l.scheme:
                scheme = l1ll1111l.scheme
            elif l1l11l1ll.scheme:
                scheme = l1l11l1ll.scheme
            else:
                scheme = l1ll1l1 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1ll1111l.netloc and not l1l11l1ll.netloc:
                l11ll1111 = l1ll1111l.netloc
            elif not l1ll1111l.netloc and l1l11l1ll.netloc:
                l11ll1111 = l1l11l1ll.netloc
            elif not l1ll1111l.netloc and not l1l11l1ll.netloc and len(self.l1ll11lll) > 0:
                l1l1lll1l = urlparse(self.l1ll11lll[len(self.l1ll11lll) - 1])
                l11ll1111 = l1l1lll1l.netloc
            elif l1l11l1ll.netloc:
                l11ll1111 = l1ll1111l.netloc
            elif not l1l11l1ll.netloc:
                l11ll1111 = l1ll1111l.netloc
            if l1ll1111l.path:
                l1ll1l1l1 = l1ll1111l.path
            if l11ll1111:
                l11ll1111 = self._11lll111(l11ll1111, scheme)
                l111111ll = ParseResult(scheme=scheme, netloc=l11ll1111, path=l1ll1l1l1,
                                          params=l1ll1111l.params,
                                          query=l1ll1111l.query,
                                          fragment=l1ll1111l.fragment)
                self.l1ll11lll.append(l111111ll.geturl())
    def _11lll1ll(self):
        l1ll1l1 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l111l11ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1111(l1ll1l1 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l111l11ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1111(l1ll1l1 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l111l1111:
            l1111l1l1 = []
            for l11111l1l in self.l111l1111:
                if l11111l1l not in [x[l1ll1l1 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1111l1l1.append(l11111l1l)
            if l1111l1l1:
                l1l1ll11 = l1ll1l1 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1ll1l1 (u"ࠧ࠲ࠠࠣऒ").join(l1111l1l1))
                raise l11l1111(l1ll1l1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l1ll11)
    def l111l111l(self, params):
        l1ll1l1 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1ll11l1l = True
        for param in self._1l1ll11l:
            if not params.get(param.lower()):
                l1ll11l1l = False
        return l1ll11l1l
class l1l1l1l11():
    def __init__(self, l1111ll11):
        self.l11llllll = ll.l1l111()
        self.l1l11ll11 = self.l111lll11()
        self.l11lll1l1 = self.l1lll1111()
        self.l1111ll11 = l1111ll11
        self._1ll1l1ll = [l1ll1l1 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1ll1l1 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1ll1l1 (u"ࠥࡅࡱࡲࠢग"), l1ll1l1 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1ll1l1 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1ll1l1 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1ll1l1 (u"ࠢࡊࡇࠥछ"), l1ll1l1 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l1l11l1 = [l1ll1l1 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1ll1l1 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1ll1l1 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1ll1l1 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l11l1l1 = None
    def l111lll11(self):
        l11l11lll = l1ll1l1 (u"ࠨࡎࡰࡰࡨࠦड")
        return l11l11lll
    def l1lll1111(self):
        l1111l11l = 0
        return l1111l11l
    def l111lll1l(self):
        l1l1ll11 = l1ll1l1 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11lll1l1)
        l1l1ll11 += l1ll1l1 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11ll11ll(l11ll11l, l1l1ll11, t=1)
        return res
    def run(self):
        l11ll1ll1 = True
        self._1l11111l()
        result = []
        try:
            for cookie in l11l11l1l(l11l11ll=self.l1111ll11.cookies).run():
                result.append(cookie)
        except l11111l1 as e:
            logger.exception(l1ll1l1 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11111l11 = self._1l1lllll(result)
            if l11111l11:
                logger.info(l1ll1l1 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11111l11)
                self.l1l11l1l1 = l11111l11
            else:
                logger.info(l1ll1l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11111l11)
            l11ll1ll1 = True
        else:
            l11ll1ll1 = False
        return l11ll1ll1
    def _1l1lllll(self, l11l1l1l1):
        res = False
        l1l1l11 = os.path.join(os.environ[l1ll1l1 (u"ࠬࡎࡏࡎࡇࠪध")], l1ll1l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1ll1l1 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11l1ll1l = {}
        for cookies in l11l1l1l1:
            l11l1ll1l[cookies.name] = cookies.value
        l1l111lll = l1ll1l1 (u"ࠣࠤप")
        for key in list(l11l1ll1l.keys()):
            l1l111lll += l1ll1l1 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11l1ll1l[key].strip())
        if not os.path.exists(os.path.dirname(l1l1l11)):
            os.makedirs(os.path.dirname(l1l1l11))
        vers = int(l1ll1l1 (u"ࠥࠦब").join(self.l11llllll.split(l1ll1l1 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l111ll11l = [l1ll1l1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1ll1l1 (u"ࠨࠣࠡࠤय") + l1ll1l1 (u"ࠢ࠮ࠤर") * 60,
                              l1ll1l1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1ll1l1 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1ll1l1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l111lll),
                              l1ll1l1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l111ll11l = [l1ll1l1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1ll1l1 (u"ࠨࠣࠡࠤश") + l1ll1l1 (u"ࠢ࠮ࠤष") * 60,
                              l1ll1l1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1ll1l1 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1ll1l1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l111lll),
                              l1ll1l1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1l1l11, l1ll1l1 (u"ࠧࡽ़ࠢ")) as l11ll1l11:
            data = l1ll1l1 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l111ll11l)
            l11ll1l11.write(data)
            l11ll1l11.write(l1ll1l1 (u"ࠢ࡝ࡰࠥा"))
        res = l1l1l11
        return res
    def _1l11111l(self):
        self._1l11l111(l1ll1l1 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1111lll1()
    def _1l11l111(self, l11111lll):
        l11llll1l = self.l1111ll11.dict[l11111lll.lower()]
        if l11llll1l:
            if isinstance(l11llll1l, list):
                l1111l111 = l11llll1l
            else:
                l1111l111 = [l11llll1l]
            if l1ll1l1 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11111lll.lower():
                    for l1ll1l111 in l1111l111:
                        l11l1ll11 = [l11ll11l1.upper() for l11ll11l1 in self._1ll1l1ll]
                        if not l1ll1l111.upper() in l11l1ll11:
                            l1l111ll1 = l1ll1l1 (u"ࠥ࠰ࠥࠨु").join(self._1ll1l1ll)
                            l11l1111l = l1ll1l1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11111lll, l11llll1l, l1l111ll1, )
                            raise l1lllll1l(l11l1111l)
    def _1111lll1(self):
        l11l111l1 = []
        l1111ll1l = self.l1111ll11.l111l1111
        for l1l111111 in self._1ll1l1ll:
            if not l1l111111 in [l1ll1l1 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1ll1l1 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11l111l1.append(l1l111111)
        for l1ll11111 in self.l1111ll11.l1llllllll:
            if l1ll11111 in l11l111l1 and not l1111ll1l:
                l11l1111l = l1ll1l1 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lllll1l(l11l1111l)
def l11l11l11(title, message, l1ll11l11, l11l1l111=None):
    l1l1l111l = l11lllll1()
    l1l1l111l.l111l1lll(message, title, l1ll11l11, l11l1l111)
def l1l11l11l(title, message, l1ll11l11):
    l111l1l1l = l11111ll1()
    l111l1l1l.l1l111l1l(title, message, l1ll11l11)
    res = l111l1l1l.result
    return res
def main():
    try:
        logger.info(l1ll1l1 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1l1l1)
        system.l1l1l1111()
        logger.info(l1ll1l1 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l11111ll(
                l1ll1l1 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1l1l1l1l = l11l11111()
        l1l1l1l1l.l1ll1ll1l(l1ll1l1 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l1llll1 = [item.upper() for item in l1l1l1l1l.l1llllllll]
        l1111llll = l1ll1l1 (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l1llll1
        if l1111llll:
            logger.info(l1ll1l1 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1l1l11ll = l1l1l1l1l.l1ll11lll
            for l1111l1 in l1l1l11ll:
                logger.debug(l1ll1l1 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1111l1))
                opener = l1ll1ll(l1l1l1l1l.l1l1111ll, l1111l1, l1l1l11=None, l1ll11ll=l1l1l1l1)
                opener.open()
                logger.info(l1ll1l1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l1l11ll1l = l1l1l1l11(l1l1l1l1l)
            l1l1111l1 = l1l11ll1l.run()
            l1l1l11ll = l1l1l1l1l.l1ll11lll
            for l1111l1 in l1l1l11ll:
                logger.info(l1ll1l1 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1111l1))
                opener = l1ll1ll(l1l1l1l1l.l1l1111ll, l1111l1, l1l1l11=l1l11ll1l.l1l11l1l1,
                                l1ll11ll=l1l1l1l1)
                opener.open()
                logger.info(l1ll1l1 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1ll111 as e:
        title = l1ll1l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l111ll1l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111ll1l1 = el
        l11l1lll1 = l1ll1l1 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1l1, message.strip())
        l11l11l11(title, l11l1lll1, l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1ll1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l11l1l111=l111ll1l1)
        sys.exit(2)
    except l1llll11l as e:
        title = l1ll1l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l111ll1l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111ll1l1 = el
        l11l1lll1 = l1ll1l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l11l11l11(title, l11l1lll1, l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1ll1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l11l1l111=l111ll1l1)
        sys.exit(2)
    except l11111ll as e:
        title = l1ll1l1 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l11l11l11(title, str(e), l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1ll1l1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l11l11l11(title, l1ll1l1 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1ll1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lllll1l as e:
        title = l1ll1l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l11l11l11(title, l1ll1l1 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1ll1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1ll1 as e:
        title = l1ll1l1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l11l11l11(title, l1ll1l1 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1ll1l1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1lll11:
        logger.info(l1ll1l1 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1l1 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11ll11l
        logger.exception(l1ll1l1 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l11l11l11(title, l1ll1l1 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1ll11l11=l1l1l1l1.get_value(l1ll1l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1ll1l1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()