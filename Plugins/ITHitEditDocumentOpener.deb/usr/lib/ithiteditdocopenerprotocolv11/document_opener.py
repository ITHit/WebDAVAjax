#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111l1 = 2048
l1l11l = 7
def l1ll1ll (l11111l):
    global l1ll1
    l1ll1111 = ord (l11111l [-1])
    l11ll1l = l11111l [:-1]
    l11llll = l1ll1111 % len (l11ll1l)
    l1lll111 = l11ll1l [:l11llll] + l11ll1l [l11llll:]
    if l1lll1:
        l1ll11l = l11111 () .join ([unichr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    else:
        l1ll11l = str () .join ([chr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    return eval (l1ll11l)
import sys, json
import os
import urllib
import l1l11
from l1l1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l11111 import l1l1ll1l, logger, l1l1lll1
from cookies import l11l111l as l11llll11
from l1l1l1 import l11l111
l1ll111l1 = None
from l1l1ll import *
class l1111lll1():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1ll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l111l11ll):
        self.config = l111l11ll
        self.l1111l11l = l1l11.l11l11()
    def l111llll1(self):
        data = platform.uname()
        logger.info(l1ll1ll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1ll1ll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1ll1ll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1ll1ll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1l1ll11l():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l111lll = [l1ll1ll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l111l1111 = None
        self.l1l111l11 = None
        self.l1ll1l111 = None
        self.l1111l111 = None
        self.l1lllll1 = None
        self.l111lll1l = None
        self.l1ll1ll11 = None
        self.l111l1ll1 = None
        self.cookies = None
    def l11lll11l(self, url):
        l1ll1ll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1ll1ll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l1lllll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11111l11(url)
        self.dict = self._11l1l11l(params)
        logger.info(l1ll1ll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1l111l1l(self.dict):
            raise l1llllll1(l1ll1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1l111lll)
        self._11ll11ll(self.dict)
        if self._encode:
            self.l11l1ll11()
        self._1ll1111l()
        self._1ll11lll()
        self._1111l1l1()
        self._11lll1ll()
        self.l1l1lll1l()
        logger.info(l1ll1ll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1ll1ll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l111l1111))
        logger.info(l1ll1ll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1l111l11))
        logger.info(l1ll1ll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1ll1l111))
        logger.info(l1ll1ll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1111l111))
        logger.info(l1ll1ll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1lllll1))
        logger.info(l1ll1ll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l111lll1l))
        logger.info(l1ll1ll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1ll1ll11))
        logger.info(l1ll1ll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l111l1ll1))
    def _11ll11ll(self, l111lll11):
        self.l111l1111 = l111lll11.get(l1ll1ll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1l111l11 = l111lll11.get(l1ll1ll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1ll1ll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1ll1l111 = l111lll11.get(l1ll1ll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1111l111 = l111lll11.get(l1ll1ll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1lllll1 = l111lll11.get(l1ll1ll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l111lll1l = l111lll11.get(l1ll1ll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1ll1ll11 = l111lll11.get(l1ll1ll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1ll1ll (u"ࠣࠤ࣏"))
        self.l111l1ll1 = l111lll11.get(l1ll1ll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1ll1ll (u"࣑ࠥࠦ"))
        self.cookies = l111lll11.get(l1ll1ll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l1lll1l(self):
        l11l1llll = False
        if self.l1lllll1:
            if self.l1lllll1.upper() == l1ll1ll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1lllll1 = l1ll1ll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1lllll1.upper() == l1ll1ll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1lllll1 = l1ll1ll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1lllll1.upper() == l1ll1ll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1lllll1 = l1ll1ll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1lllll1.upper() == l1ll1ll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1lllll1 = l1ll1ll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1lllll1 == l1ll1ll (u"ࠨࠢࣛ"):
                l11l1llll = True
            else:
                self.l1lllll1 = self.l1lllll1.lower()
        else:
            l11l1llll = True
        if l11l1llll:
            self.l1lllll1 = l1ll1ll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l11l1ll11(self):
        l1ll1ll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1ll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11111lll = []
                    for el in self.__dict__.get(key):
                        l11111lll.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11111lll
    def l111ll1ll(self, l1llllllll):
        res = l1llllllll
        if self._encode:
            res = urllib.parse.quote(l1llllllll, safe=l1ll1ll (u"ࠥࠦࣟ"))
        return res
    def _1l1lllll(self, url):
        l1ll1ll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1ll1ll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1ll1ll (u"ࠨ࠺ࠣ࣢")), l1ll1ll (u"ࠧࠨࣣ"), url)
        return url
    def _11111l11(self, url):
        l1ll1ll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11llll1l = url.split(l1ll1ll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1ll1ll (u"ࠥ࠿ࣦࠧ")))
        result = l11llll1l
        if len(result) == 0:
            raise l1lll1l11(l1ll1ll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11l1l11l(self, params):
        l1ll1ll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1ll1ll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1ll1ll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l111111l1 = data.group(l1ll1ll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l111111l1 in (l1ll1ll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1ll1ll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1ll1ll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1ll1ll (u"ࠧ࠲࣯ࠢ"))
                elif l111111l1 == l1ll1ll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1ll1ll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1ll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l111111l1] = value
        return result
    def _1l1l1l1l(self, url, scheme):
        l1ll1ll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1111ll1l = {l1ll1ll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1ll1ll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11l111ll = url.split(l1ll1ll (u"ࠧࡀࣶࠢ"))
        if len(l11l111ll) == 1:
            for l111l11l1 in list(l1111ll1l.keys()):
                if l111l11l1 == scheme:
                    url += l1ll1ll (u"ࠨ࠺ࠣࣷ") + str(l1111ll1l[l111l11l1])
                    break
        return url
    def _1ll1111l(self):
        l1ll1ll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1111l111:
            l1ll111ll = self.l1111l111[0]
            l1l11l111 = urlparse(l1ll111ll)
        if self.l111l1111:
            l1l1l1111 = urlparse(self.l111l1111)
            if l1l1l1111.scheme:
                l111ll111 = l1l1l1111.scheme
            else:
                if l1l11l111.scheme:
                    l111ll111 = l1l11l111.scheme
                else:
                    raise l1lll11ll(
                        l1ll1ll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1l1111.netloc:
                l1111111l = l1l1l1111.netloc
            else:
                if l1l11l111.netloc:
                    l1111111l = l1l11l111.netloc
                else:
                    raise l1lll11ll(
                        l1ll1ll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1111111l = self._1l1l1l1l(l1111111l, l111ll111)
            path = l1l1l1111.path
            if not path.endswith(l1ll1ll (u"ࠪ࠳ࠬࣻ")):
                path += l1ll1ll (u"ࠫ࠴࠭ࣼ")
            l11lllll1 = ParseResult(scheme=l111ll111, netloc=l1111111l, path=path,
                                         params=l1l1l1111.params, query=l1l1l1111.query,
                                         fragment=l1l1l1111.fragment)
            self.l111l1111 = l11lllll1.geturl()
        else:
            if not l1l11l111.netloc:
                raise l1lll11ll(l1ll1ll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l11l11l = l1l11l111.path
            l11ll1ll1 = l1ll1ll (u"ࠨ࠯ࠣࣾ").join(l1l11l11l.split(l1ll1ll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1ll1ll (u"ࠣ࠱ࠥऀ")
            l11lllll1 = ParseResult(scheme=l1l11l111.scheme,
                                         netloc=self._1l1l1l1l(l1l11l111.netloc, l1l11l111.scheme),
                                         path=l11ll1ll1,
                                         params=l1ll1ll (u"ࠤࠥँ"),
                                         query=l1ll1ll (u"ࠥࠦं"),
                                         fragment=l1ll1ll (u"ࠦࠧः")
                                         )
            self.l111l1111 = l11lllll1.geturl()
    def _1111l1l1(self):
        l1ll1ll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1111l111:
            l1ll111ll = self.l1111l111[0]
            l1l11l111 = urlparse(l1ll111ll)
        if self.l111lll1l:
            l11l11l11 = urlparse(self.l111lll1l)
            if l11l11l11.scheme:
                l11llllll = l11l11l11.scheme
            else:
                l11llllll = l1l11l111.scheme
            if l11l11l11.netloc:
                l11l1ll1l = l11l11l11.netloc
            else:
                l11l1ll1l = l1l11l111.netloc
            l11l11l1l = ParseResult(scheme=l11llllll, netloc=l11l1ll1l, path=l11l11l11.path,
                                      params=l11l11l11.params, query=l11l11l11.query,
                                      fragment=l11l11l11.fragment)
            self.l111lll1l = l11l11l1l.geturl()
    def _1ll11lll(self):
        l1ll1ll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1111l111
        self.l1111l111 = []
        for item in items:
            l11ll1l1l = urlparse(item.strip(), scheme=l1ll1ll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11ll1l1l.path[-1] == l1ll1ll (u"ࠣ࠱ࠥइ"):
                l11ll11l1 = l11ll1l1l.path
            else:
                path_list = l11ll1l1l.path.split(l1ll1ll (u"ࠤ࠲ࠦई"))
                l11ll11l1 = l1ll1ll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1ll1ll (u"ࠦ࠴ࠨऊ")
            l1l1ll1ll = urlparse(self.l111l1111, scheme=l1ll1ll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11ll1l1l.scheme:
                scheme = l11ll1l1l.scheme
            elif l1l1ll1ll.scheme:
                scheme = l1l1ll1ll.scheme
            else:
                scheme = l1ll1ll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11ll1l1l.netloc and not l1l1ll1ll.netloc:
                l11ll1l11 = l11ll1l1l.netloc
            elif not l11ll1l1l.netloc and l1l1ll1ll.netloc:
                l11ll1l11 = l1l1ll1ll.netloc
            elif not l11ll1l1l.netloc and not l1l1ll1ll.netloc and len(self.l1111l111) > 0:
                l1l1l1l11 = urlparse(self.l1111l111[len(self.l1111l111) - 1])
                l11ll1l11 = l1l1l1l11.netloc
            elif l1l1ll1ll.netloc:
                l11ll1l11 = l11ll1l1l.netloc
            elif not l1l1ll1ll.netloc:
                l11ll1l11 = l11ll1l1l.netloc
            if l11ll1l1l.path:
                l11111111 = l11ll1l1l.path
            if l11ll1l11:
                l11ll1l11 = self._1l1l1l1l(l11ll1l11, scheme)
                l11l1111l = ParseResult(scheme=scheme, netloc=l11ll1l11, path=l11111111,
                                          params=l11ll1l1l.params,
                                          query=l11ll1l1l.query,
                                          fragment=l11ll1l1l.fragment)
                self.l1111l111.append(l11l1111l.geturl())
    def _11lll1ll(self):
        l1ll1ll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1111l1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111l1l(l1ll1ll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1111l1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111l1l(l1ll1ll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1ll1l111:
            l1l1ll111 = []
            for l1l1l1ll1 in self.l1ll1l111:
                if l1l1l1ll1 not in [x[l1ll1ll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l1ll111.append(l1l1l1ll1)
            if l1l1ll111:
                l1l1llll = l1ll1ll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1ll1ll (u"ࠧ࠲ࠠࠣऒ").join(l1l1ll111))
                raise l1111l1l(l1ll1ll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l1llll)
    def l1l111l1l(self, params):
        l1ll1ll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1ll11111 = True
        for param in self._1l111lll:
            if not params.get(param.lower()):
                l1ll11111 = False
        return l1ll11111
class l1l1lll11():
    def __init__(self, l1ll1l11l):
        self.l1lll11l1 = l1l11.l11l11()
        self.l111l111l = self.l1lll1111()
        self.l11l1lll1 = self.l1l1111ll()
        self.l1ll1l11l = l1ll1l11l
        self._11ll1111 = [l1ll1ll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1ll1ll (u"ࠤࡑࡳࡳ࡫ࠢख"), l1ll1ll (u"ࠥࡅࡱࡲࠢग"), l1ll1ll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1ll1ll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1ll1ll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1ll1ll (u"ࠢࡊࡇࠥछ"), l1ll1ll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l1l111l = [l1ll1ll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1ll1ll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1ll1ll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1ll1ll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11lll1l1 = None
    def l1lll1111(self):
        l11l1l111 = l1ll1ll (u"ࠨࡎࡰࡰࡨࠦड")
        return l11l1l111
    def l1l1111ll(self):
        l1l11ll1l = 0
        return l1l11ll1l
    def l1l1ll1l1(self):
        l1l1llll = l1ll1ll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11l1lll1)
        l1l1llll += l1ll1ll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l1llll1(l1l1ll1l, l1l1llll, t=1)
        return res
    def run(self):
        l11l1l1ll = True
        self._11ll1lll()
        result = []
        try:
            for cookie in l11llll11(l11l1ll1=self.l1ll1l11l.cookies).run():
                result.append(cookie)
        except l11111ll as e:
            logger.exception(l1ll1ll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1111llll = self._11l11111(result)
            if l1111llll:
                logger.info(l1ll1ll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1111llll)
                self.l11lll1l1 = l1111llll
            else:
                logger.info(l1ll1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1111llll)
            l11l1l1ll = True
        else:
            l11l1l1ll = False
        return l11l1l1ll
    def _11l11111(self, l1l1l11l1):
        res = False
        l1l111l = os.path.join(os.environ[l1ll1ll (u"ࠬࡎࡏࡎࡇࠪध")], l1ll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1ll1ll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11l111l1 = {}
        for cookies in l1l1l11l1:
            l11l111l1[cookies.name] = cookies.value
        l111ll1l1 = l1ll1ll (u"ࠣࠤप")
        for key in list(l11l111l1.keys()):
            l111ll1l1 += l1ll1ll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11l111l1[key].strip())
        if not os.path.exists(os.path.dirname(l1l111l)):
            os.makedirs(os.path.dirname(l1l111l))
        vers = int(l1ll1ll (u"ࠥࠦब").join(self.l1lll11l1.split(l1ll1ll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11111ll1 = [l1ll1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1ll1ll (u"ࠨࠣࠡࠤय") + l1ll1ll (u"ࠢ࠮ࠤर") * 60,
                              l1ll1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1ll1ll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1ll1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l111ll1l1),
                              l1ll1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11111ll1 = [l1ll1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1ll1ll (u"ࠨࠣࠡࠤश") + l1ll1ll (u"ࠢ࠮ࠤष") * 60,
                              l1ll1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1ll1ll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1ll1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l111ll1l1),
                              l1ll1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1l111l, l1ll1ll (u"ࠧࡽ़ࠢ")) as l111111ll:
            data = l1ll1ll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11111ll1)
            l111111ll.write(data)
            l111111ll.write(l1ll1ll (u"ࠢ࡝ࡰࠥा"))
        res = l1l111l
        return res
    def _11ll1lll(self):
        self._1ll11l11(l1ll1ll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._111l1lll()
    def _1ll11l11(self, l1l11llll):
        l11l11lll = self.l1ll1l11l.dict[l1l11llll.lower()]
        if l11l11lll:
            if isinstance(l11l11lll, list):
                l111l1l1l = l11l11lll
            else:
                l111l1l1l = [l11l11lll]
            if l1ll1ll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1l11llll.lower():
                    for l11lll111 in l111l1l1l:
                        l1ll1ll1l = [l1l11l1l1.upper() for l1l11l1l1 in self._11ll1111]
                        if not l11lll111.upper() in l1ll1ll1l:
                            l1l11111l = l1ll1ll (u"ࠥ࠰ࠥࠨु").join(self._11ll1111)
                            l1l1l11ll = l1ll1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1l11llll, l11l11lll, l1l11111l, )
                            raise l1lllll1l(l1l1l11ll)
    def _111l1lll(self):
        l111ll11l = []
        l1ll11l1l = self.l1ll1l11l.l1ll1l111
        for l1ll1lll1 in self._11ll1111:
            if not l1ll1lll1 in [l1ll1ll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1ll1ll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l111ll11l.append(l1ll1lll1)
        for l1l111111 in self.l1ll1l11l.l1l111l11:
            if l1l111111 in l111ll11l and not l1ll11l1l:
                l1l1l11ll = l1ll1ll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lllll1l(l1l1l11ll)
def l1111ll11(title, message, l11ll111l, l1l11ll11=None):
    l11111l1l = l111l1l11()
    l11111l1l.l1ll1llll(message, title, l11ll111l, l1l11ll11)
def l1l11lll1(title, message, l11ll111l):
    l1l111ll1 = l1lll111l()
    l1l111ll1.l1ll11ll1(title, message, l11ll111l)
    res = l1l111ll1.result
    return res
def main():
    try:
        logger.info(l1ll1ll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1lll1)
        system.l111llll1()
        logger.info(l1ll1ll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1llllll1(
                l1ll1ll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1ll1l1ll = l1l1ll11l()
        l1ll1l1ll.l11lll11l(l1ll1ll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11l1l1l1 = [item.upper() for item in l1ll1l1ll.l1l111l11]
        l11l11ll1 = l1ll1ll (u"ࠧࡔࡏࡏࡇࠥॊ") in l11l1l1l1
        if l11l11ll1:
            logger.info(l1ll1ll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1ll1l1l1 = l1ll1l1ll.l1111l111
            for l1l1ll1 in l1ll1l1l1:
                logger.debug(l1ll1ll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1l1ll1))
                opener = l11l111(l1ll1l1ll.l111l1111, l1l1ll1, l1l111l=None, l1llll=l1l1lll1)
                opener.open()
                logger.info(l1ll1ll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111lllll = l1l1lll11(l1ll1l1ll)
            l1l1l1lll = l111lllll.run()
            l1ll1l1l1 = l1ll1l1ll.l1111l111
            for l1l1ll1 in l1ll1l1l1:
                logger.info(l1ll1ll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1l1ll1))
                opener = l11l111(l1ll1l1ll.l111l1111, l1l1ll1, l1l111l=l111lllll.l11lll1l1,
                                l1llll=l1l1lll1)
                opener.open()
                logger.info(l1ll1ll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1ll1l1 as e:
        title = l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1l1111l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1111l1 = el
        l1l11l1ll = l1ll1ll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1ll1l, message.strip())
        l1111ll11(title, l1l11l1ll, l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1ll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1l11ll11=l1l1111l1)
        sys.exit(2)
    except l1111l11 as e:
        title = l1ll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1l1111l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1111l1 = el
        l1l11l1ll = l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1111ll11(title, l1l11l1ll, l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1ll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1l11ll11=l1l1111l1)
        sys.exit(2)
    except l1llllll1 as e:
        title = l1ll1ll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1111ll11(title, str(e), l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1ll1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1111ll11(title, l1ll1ll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1ll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lllll1l as e:
        title = l1ll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1111ll11(title, l1ll1ll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1ll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1llll11l as e:
        title = l1ll1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1111ll11(title, l1ll1ll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1ll1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll111:
        logger.info(l1ll1ll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1ll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1ll1l
        logger.exception(l1ll1ll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1111ll11(title, l1ll1ll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11ll111l=l1l1lll1.get_value(l1ll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1ll1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()