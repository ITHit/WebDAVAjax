#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1llll1l = 7
def l1lllll1 (l11ll1l):
    global l1l1ll
    l1ll1 = ord (l11ll1l [-1])
    l1l11ll = l11ll1l [:-1]
    l111111 = l1ll1 % len (l1l11ll)
    l1ll11l1 = l1l11ll [:l111111] + l1l11ll [l111111:]
    if l11ll1:
        l1lllll = l11l111 () .join ([unichr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    else:
        l1lllll = str () .join ([chr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    return eval (l1lllll)
import sys, json
import os
import urllib
import l111l1
from l1lll111 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1l1l1 import l1l1ll1l, logger, l1l11ll1
from cookies import l11l11l1 as l11l111ll
from l1l111l import l1ll1ll1
l111l11l1 = None
from l1ll11l import *
class l111ll1ll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1lllll1 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l111l11ll):
        self.config = l111l11ll
        self.l111ll1l1 = l111l1.l1l11l()
    def l1lll111l(self):
        data = platform.uname()
        logger.info(l1lllll1 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1lllll1 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1lllll1 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1lllll1 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1l11lll1():
    def __init__(self, encode = True):
        self._encode = encode
        self._111l1111 = [l1lllll1 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l11l1ll1l = None
        self.l11lll1ll = None
        self.l11ll1111 = None
        self.l1l1lll1l = None
        self.l1ll111l = None
        self.l11l11111 = None
        self.l11l11ll1 = None
        self.l1l1lllll = None
        self.cookies = None
    def l1l1111ll(self, url):
        l1lllll1 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1lllll1 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11ll1l1l(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l1lll11(url)
        self.dict = self._1ll111ll(params)
        logger.info(l1lllll1 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l11l1111l(self.dict):
            raise l1llll11l(l1lllll1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._111l1111)
        self._11l1llll(self.dict)
        if self._encode:
            self.l1ll1l11l()
        self._11lll1l1()
        self._111lll1l()
        self._11llllll()
        self._111111ll()
        self.l11l11l1l()
        logger.info(l1lllll1 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1lllll1 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l11l1ll1l))
        logger.info(l1lllll1 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11lll1ll))
        logger.info(l1lllll1 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11ll1111))
        logger.info(l1lllll1 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1l1lll1l))
        logger.info(l1lllll1 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1ll111l))
        logger.info(l1lllll1 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11l11111))
        logger.info(l1lllll1 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l11l11ll1))
        logger.info(l1lllll1 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1l1lllll))
    def _11l1llll(self, l1111ll11):
        self.l11l1ll1l = l1111ll11.get(l1lllll1 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11lll1ll = l1111ll11.get(l1lllll1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1lllll1 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11ll1111 = l1111ll11.get(l1lllll1 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1l1lll1l = l1111ll11.get(l1lllll1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1ll111l = l1111ll11.get(l1lllll1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11l11111 = l1111ll11.get(l1lllll1 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l11l11ll1 = l1111ll11.get(l1lllll1 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1lllll1 (u"ࠣࠤ࣏"))
        self.l1l1lllll = l1111ll11.get(l1lllll1 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1lllll1 (u"࣑ࠥࠦ"))
        self.cookies = l1111ll11.get(l1lllll1 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11l11l1l(self):
        l1l111lll = False
        if self.l1ll111l:
            if self.l1ll111l.upper() == l1lllll1 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1ll111l = l1lllll1 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1ll111l.upper() == l1lllll1 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1ll111l = l1lllll1 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1ll111l.upper() == l1lllll1 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1ll111l = l1lllll1 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1ll111l.upper() == l1lllll1 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1ll111l = l1lllll1 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1ll111l == l1lllll1 (u"ࠨࠢࣛ"):
                l1l111lll = True
            else:
                self.l1ll111l = self.l1ll111l.lower()
        else:
            l1l111lll = True
        if l1l111lll:
            self.l1ll111l = l1lllll1 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1ll1l11l(self):
        l1lllll1 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1lllll1 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1ll1l1l1 = []
                    for el in self.__dict__.get(key):
                        l1ll1l1l1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1ll1l1l1
    def l1ll1111l(self, l11l1ll11):
        res = l11l1ll11
        if self._encode:
            res = urllib.parse.quote(l11l1ll11, safe=l1lllll1 (u"ࠥࠦࣟ"))
        return res
    def _11ll1l1l(self, url):
        l1lllll1 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1lllll1 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1lllll1 (u"ࠨ࠺ࠣ࣢")), l1lllll1 (u"ࠧࠨࣣ"), url)
        return url
    def _1l1lll11(self, url):
        l1lllll1 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l111ll111 = url.split(l1lllll1 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1lllll1 (u"ࠥ࠿ࣦࠧ")))
        result = l111ll111
        if len(result) == 0:
            raise l111111l(l1lllll1 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1ll111ll(self, params):
        l1lllll1 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1lllll1 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1lllll1 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l1l1ll1 = data.group(l1lllll1 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l1l1ll1 in (l1lllll1 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1lllll1 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1lllll1 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1lllll1 (u"ࠧ࠲࣯ࠢ"))
                elif l1l1l1ll1 == l1lllll1 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1lllll1 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1lllll1 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l1l1ll1] = value
        return result
    def _111l1lll(self, url, scheme):
        l1lllll1 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l11l1l1ll = {l1lllll1 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1lllll1 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11l11lll = url.split(l1lllll1 (u"ࠧࡀࣶࠢ"))
        if len(l11l11lll) == 1:
            for l1l1ll111 in list(l11l1l1ll.keys()):
                if l1l1ll111 == scheme:
                    url += l1lllll1 (u"ࠨ࠺ࠣࣷ") + str(l11l1l1ll[l1l1ll111])
                    break
        return url
    def _11lll1l1(self):
        l1lllll1 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1l1lll1l:
            l1l1l11l1 = self.l1l1lll1l[0]
            l1111111l = urlparse(l1l1l11l1)
        if self.l11l1ll1l:
            l111lll11 = urlparse(self.l11l1ll1l)
            if l111lll11.scheme:
                l11ll1l11 = l111lll11.scheme
            else:
                if l1111111l.scheme:
                    l11ll1l11 = l1111111l.scheme
                else:
                    raise l1lllllll(
                        l1lllll1 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l111lll11.netloc:
                l1l11ll11 = l111lll11.netloc
            else:
                if l1111111l.netloc:
                    l1l11ll11 = l1111111l.netloc
                else:
                    raise l1lllllll(
                        l1lllll1 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l11ll11 = self._111l1lll(l1l11ll11, l11ll1l11)
            path = l111lll11.path
            if not path.endswith(l1lllll1 (u"ࠪ࠳ࠬࣻ")):
                path += l1lllll1 (u"ࠫ࠴࠭ࣼ")
            l1l1ll1l1 = ParseResult(scheme=l11ll1l11, netloc=l1l11ll11, path=path,
                                         params=l111lll11.params, query=l111lll11.query,
                                         fragment=l111lll11.fragment)
            self.l11l1ll1l = l1l1ll1l1.geturl()
        else:
            if not l1111111l.netloc:
                raise l1lllllll(l1lllll1 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1111l11l = l1111111l.path
            l111llll1 = l1lllll1 (u"ࠨ࠯ࠣࣾ").join(l1111l11l.split(l1lllll1 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1lllll1 (u"ࠣ࠱ࠥऀ")
            l1l1ll1l1 = ParseResult(scheme=l1111111l.scheme,
                                         netloc=self._111l1lll(l1111111l.netloc, l1111111l.scheme),
                                         path=l111llll1,
                                         params=l1lllll1 (u"ࠤࠥँ"),
                                         query=l1lllll1 (u"ࠥࠦं"),
                                         fragment=l1lllll1 (u"ࠦࠧः")
                                         )
            self.l11l1ll1l = l1l1ll1l1.geturl()
    def _11llllll(self):
        l1lllll1 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1l1lll1l:
            l1l1l11l1 = self.l1l1lll1l[0]
            l1111111l = urlparse(l1l1l11l1)
        if self.l11l11111:
            l1ll1ll1l = urlparse(self.l11l11111)
            if l1ll1ll1l.scheme:
                l11111l11 = l1ll1ll1l.scheme
            else:
                l11111l11 = l1111111l.scheme
            if l1ll1ll1l.netloc:
                l1l111ll1 = l1ll1ll1l.netloc
            else:
                l1l111ll1 = l1111111l.netloc
            l1l11ll1l = ParseResult(scheme=l11111l11, netloc=l1l111ll1, path=l1ll1ll1l.path,
                                      params=l1ll1ll1l.params, query=l1ll1ll1l.query,
                                      fragment=l1ll1ll1l.fragment)
            self.l11l11111 = l1l11ll1l.geturl()
    def _111lll1l(self):
        l1lllll1 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1l1lll1l
        self.l1l1lll1l = []
        for item in items:
            l11ll1ll1 = urlparse(item.strip(), scheme=l1lllll1 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11ll1ll1.path[-1] == l1lllll1 (u"ࠣ࠱ࠥइ"):
                l11l1l11l = l11ll1ll1.path
            else:
                path_list = l11ll1ll1.path.split(l1lllll1 (u"ࠤ࠲ࠦई"))
                l11l1l11l = l1lllll1 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1lllll1 (u"ࠦ࠴ࠨऊ")
            l11l111l1 = urlparse(self.l11l1ll1l, scheme=l1lllll1 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11ll1ll1.scheme:
                scheme = l11ll1ll1.scheme
            elif l11l111l1.scheme:
                scheme = l11l111l1.scheme
            else:
                scheme = l1lllll1 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11ll1ll1.netloc and not l11l111l1.netloc:
                l11l11l11 = l11ll1ll1.netloc
            elif not l11ll1ll1.netloc and l11l111l1.netloc:
                l11l11l11 = l11l111l1.netloc
            elif not l11ll1ll1.netloc and not l11l111l1.netloc and len(self.l1l1lll1l) > 0:
                l1111ll1l = urlparse(self.l1l1lll1l[len(self.l1l1lll1l) - 1])
                l11l11l11 = l1111ll1l.netloc
            elif l11l111l1.netloc:
                l11l11l11 = l11ll1ll1.netloc
            elif not l11l111l1.netloc:
                l11l11l11 = l11ll1ll1.netloc
            if l11ll1ll1.path:
                l11111ll1 = l11ll1ll1.path
            if l11l11l11:
                l11l11l11 = self._111l1lll(l11l11l11, scheme)
                l1l1l1111 = ParseResult(scheme=scheme, netloc=l11l11l11, path=l11111ll1,
                                          params=l11ll1ll1.params,
                                          query=l11ll1ll1.query,
                                          fragment=l11ll1ll1.fragment)
                self.l1l1lll1l.append(l1l1l1111.geturl())
    def _111111ll(self):
        l1lllll1 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1ll1l1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111llll(l1lllll1 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1ll1l1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111llll(l1lllll1 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11ll1111:
            l11ll111l = []
            for l1l1l1l1l in self.l11ll1111:
                if l1l1l1l1l not in [x[l1lllll1 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l11ll111l.append(l1l1l1l1l)
            if l11ll111l:
                l11lll1l = l1lllll1 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1lllll1 (u"ࠧ࠲ࠠࠣऒ").join(l11ll111l))
                raise l111llll(l1lllll1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11lll1l)
    def l11l1111l(self, params):
        l1lllll1 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1lll1111 = True
        for param in self._111l1111:
            if not params.get(param.lower()):
                l1lll1111 = False
        return l1lll1111
class l1l1l1lll():
    def __init__(self, l1l11llll):
        self.l1l1l11ll = l111l1.l1l11l()
        self.l1ll111l1 = self.l11111lll()
        self.l11111l1l = self.l11ll1lll()
        self.l1l11llll = l1l11llll
        self._1ll11l11 = [l1lllll1 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1lllll1 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1lllll1 (u"ࠥࡅࡱࡲࠢग"), l1lllll1 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1lllll1 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1lllll1 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1lllll1 (u"ࠢࡊࡇࠥछ"), l1lllll1 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1ll1ll11 = [l1lllll1 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1lllll1 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1lllll1 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1lllll1 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l111l1l = None
    def l11111lll(self):
        l11lll11l = l1lllll1 (u"ࠨࡎࡰࡰࡨࠦड")
        return l11lll11l
    def l11ll1lll(self):
        l1l11111l = 0
        return l1l11111l
    def l1l1ll1ll(self):
        l11lll1l = l1lllll1 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11111l1l)
        l11lll1l += l1lllll1 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l1l111l(l1l1ll1l, l11lll1l, t=1)
        return res
    def run(self):
        l1111llll = True
        self._1llllllll()
        result = []
        try:
            for cookie in l11l111ll(l111l1ll=self.l1l11llll.cookies).run():
                result.append(cookie)
        except l1lll1l1l as e:
            logger.exception(l1lllll1 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11l1l111 = self._1l1ll11l(result)
            if l11l1l111:
                logger.info(l1lllll1 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11l1l111)
                self.l1l111l1l = l11l1l111
            else:
                logger.info(l1lllll1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11l1l111)
            l1111llll = True
        else:
            l1111llll = False
        return l1111llll
    def _1l1ll11l(self, l11lll111):
        res = False
        l11lll1 = os.path.join(os.environ[l1lllll1 (u"ࠬࡎࡏࡎࡇࠪध")], l1lllll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1lllll1 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1111l111 = {}
        for cookies in l11lll111:
            l1111l111[cookies.name] = cookies.value
        l11llll1l = l1lllll1 (u"ࠣࠤप")
        for key in list(l1111l111.keys()):
            l11llll1l += l1lllll1 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1111l111[key].strip())
        if not os.path.exists(os.path.dirname(l11lll1)):
            os.makedirs(os.path.dirname(l11lll1))
        vers = int(l1lllll1 (u"ࠥࠦब").join(self.l1l1l11ll.split(l1lllll1 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l111ll11l = [l1lllll1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1lllll1 (u"ࠨࠣࠡࠤय") + l1lllll1 (u"ࠢ࠮ࠤर") * 60,
                              l1lllll1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1lllll1 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1lllll1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11llll1l),
                              l1lllll1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l111ll11l = [l1lllll1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1lllll1 (u"ࠨࠣࠡࠤश") + l1lllll1 (u"ࠢ࠮ࠤष") * 60,
                              l1lllll1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1lllll1 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1lllll1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11llll1l),
                              l1lllll1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l11lll1, l1lllll1 (u"ࠧࡽ़ࠢ")) as l111lllll:
            data = l1lllll1 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l111ll11l)
            l111lllll.write(data)
            l111lllll.write(l1lllll1 (u"ࠢ࡝ࡰࠥा"))
        res = l11lll1
        return res
    def _1llllllll(self):
        self._1l1111l1(l1lllll1 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1ll1llll()
    def _1l1111l1(self, l1ll1lll1):
        l11llll11 = self.l1l11llll.dict[l1ll1lll1.lower()]
        if l11llll11:
            if isinstance(l11llll11, list):
                l111l111l = l11llll11
            else:
                l111l111l = [l11llll11]
            if l1lllll1 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1ll1lll1.lower():
                    for l11l1l1l1 in l111l111l:
                        l1l11l1l1 = [l1ll11lll.upper() for l1ll11lll in self._1ll11l11]
                        if not l11l1l1l1.upper() in l1l11l1l1:
                            l1111l1ll = l1lllll1 (u"ࠥ࠰ࠥࠨु").join(self._1ll11l11)
                            l111l1ll1 = l1lllll1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1ll1lll1, l11llll11, l1111l1ll, )
                            raise l1111l11(l111l1ll1)
    def _1ll1llll(self):
        l1ll11111 = []
        l1l11l1ll = self.l1l11llll.l11ll1111
        for l1ll11l1l in self._1ll11l11:
            if not l1ll11l1l in [l1lllll1 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1lllll1 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1ll11111.append(l1ll11l1l)
        for l1111l1l1 in self.l1l11llll.l11lll1ll:
            if l1111l1l1 in l1ll11111 and not l1l11l1ll:
                l111l1ll1 = l1lllll1 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1111l11(l111l1ll1)
def l1ll1l111(title, message, l11l1lll1, l1l11l11l=None):
    l1l1llll1 = l111l1l1l()
    l1l1llll1.l1l11l111(message, title, l11l1lll1, l1l11l11l)
def l1l111111(title, message, l11l1lll1):
    l11lllll1 = l11ll11l1()
    l11lllll1.l1lll11l1(title, message, l11l1lll1)
    res = l11lllll1.result
    return res
def main():
    try:
        logger.info(l1lllll1 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l11ll1)
        system.l1lll111l()
        logger.info(l1lllll1 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1llll11l(
                l1lllll1 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111l1l11 = l1l11lll1()
        l111l1l11.l1l1111ll(l1lllll1 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1111lll1 = [item.upper() for item in l111l1l11.l11lll1ll]
        l1l111l11 = l1lllll1 (u"ࠧࡔࡏࡏࡇࠥॊ") in l1111lll1
        if l1l111l11:
            logger.info(l1lllll1 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1l1l1l11 = l111l1l11.l1l1lll1l
            for l1lll11l in l1l1l1l11:
                logger.debug(l1lllll1 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1lll11l))
                opener = l1ll1ll1(l111l1l11.l11l1ll1l, l1lll11l, l11lll1=None, l1l=l1l11ll1)
                opener.open()
                logger.info(l1lllll1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111111l1 = l1l1l1lll(l111l1l11)
            l1ll11ll1 = l111111l1.run()
            l1l1l1l11 = l111l1l11.l1l1lll1l
            for l1lll11l in l1l1l1l11:
                logger.info(l1lllll1 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1lll11l))
                opener = l1ll1ll1(l111l1l11.l11l1ll1l, l1lll11l, l11lll1=l111111l1.l1l111l1l,
                                l1l=l1l11ll1)
                opener.open()
                logger.info(l1lllll1 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1ll1111 as e:
        title = l1lllll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11ll11ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll11ll = el
        l11111111 = l1lllll1 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11llll, message.strip())
        l1ll1l111(title, l11111111, l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1lllll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1l11l11l=l11ll11ll)
        sys.exit(2)
    except l11111ll as e:
        title = l1lllll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11ll11ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll11ll = el
        l11111111 = l1lllll1 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1ll1l111(title, l11111111, l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1lllll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1l11l11l=l11ll11ll)
        sys.exit(2)
    except l1llll11l as e:
        title = l1lllll1 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1ll1l111(title, str(e), l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1lllll1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1lllll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1ll1l111(title, l1lllll1 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1lllll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1111l11 as e:
        title = l1lllll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1ll1l111(title, l1lllll1 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1lllll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l11111l1 as e:
        title = l1lllll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1ll1l111(title, l1lllll1 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1lllll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1:
        logger.info(l1lllll1 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1lllll1 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1ll1l
        logger.exception(l1lllll1 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1ll1l111(title, l1lllll1 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11l1lll1=l1l11ll1.get_value(l1lllll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1lllll1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1lllll1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()