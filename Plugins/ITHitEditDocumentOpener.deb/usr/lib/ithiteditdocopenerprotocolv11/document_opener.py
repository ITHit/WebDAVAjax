#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l11 = sys.version_info [0] == 2
l1ll1l = 2048
l11ll11 = 7
def l1llllll (l11l111):
    global l11l11
    l1ll1l11 = ord (l11l111 [-1])
    l1llll = l11l111 [:-1]
    ll = l1ll1l11 % len (l1llll)
    l1ll1 = l1llll [:ll] + l1llll [ll:]
    if l1l1l11:
        l1l111 = l1llll1l () .join ([unichr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    return eval (l1l111)
import sys, json
import os
import urllib
import l1lll11
from l1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l11lll11 import l11lllll, logger, l11l1lll
from cookies import l111ll11 as l1ll11ll1
from l1ll11 import l1ll11l
l1l111ll1 = None
from l1ll import *
class l1l111l1l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1llllll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l11l11l1l):
        self.config = l11l11l1l
        self.l111llll1 = l1lll11.l1111l1()
    def l11lllll1(self):
        data = platform.uname()
        logger.info(l1llllll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1llllll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1llllll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1llllll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1l1l111l():
    def __init__(self, encode = True):
        self._encode = encode
        self._11l1lll1 = [l1llllll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l1l1ll1 = None
        self.l11ll1lll = None
        self.l111ll1l1 = None
        self.l1ll1111l = None
        self.l11lll = None
        self.l11l1l111 = None
        self.l111l111l = None
        self.l11ll111l = None
        self.cookies = None
    def l11l1ll1l(self, url):
        l1llllll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1llllll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1111l1ll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1ll1l111(url)
        self.dict = self._1l11llll(params)
        logger.info(l1llllll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l11l11111(self.dict):
            raise l1111111(l1llllll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._11l1lll1)
        self._11lll1l1(self.dict)
        if self._encode:
            self.l1ll11l1l()
        self._1l111lll()
        self._1ll1l1ll()
        self._11l111ll()
        self._1l1l1lll()
        self.l111111ll()
        logger.info(l1llllll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1llllll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l1l1ll1))
        logger.info(l1llllll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11ll1lll))
        logger.info(l1llllll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l111ll1l1))
        logger.info(l1llllll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1ll1111l))
        logger.info(l1llllll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l11lll))
        logger.info(l1llllll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11l1l111))
        logger.info(l1llllll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l111l111l))
        logger.info(l1llllll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l11ll111l))
    def _11lll1l1(self, l1l1ll11l):
        self.l1l1l1ll1 = l1l1ll11l.get(l1llllll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11ll1lll = l1l1ll11l.get(l1llllll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1llllll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l111ll1l1 = l1l1ll11l.get(l1llllll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1ll1111l = l1l1ll11l.get(l1llllll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l11lll = l1l1ll11l.get(l1llllll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11l1l111 = l1l1ll11l.get(l1llllll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l111l111l = l1l1ll11l.get(l1llllll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1llllll (u"ࠣࠤ࣏"))
        self.l11ll111l = l1l1ll11l.get(l1llllll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1llllll (u"࣑ࠥࠦ"))
        self.cookies = l1l1ll11l.get(l1llllll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l111111ll(self):
        l1l1111ll = False
        if self.l11lll:
            if self.l11lll.upper() == l1llllll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l11lll = l1llllll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l11lll.upper() == l1llllll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l11lll = l1llllll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l11lll.upper() == l1llllll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l11lll = l1llllll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l11lll.upper() == l1llllll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l11lll = l1llllll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l11lll == l1llllll (u"ࠨࠢࣛ"):
                l1l1111ll = True
            else:
                self.l11lll = self.l11lll.lower()
        else:
            l1l1111ll = True
        if l1l1111ll:
            self.l11lll = l1llllll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1ll11l1l(self):
        l1llllll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1llllll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11llll1l = []
                    for el in self.__dict__.get(key):
                        l11llll1l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11llll1l
    def l111l11l1(self, l1l11ll1l):
        res = l1l11ll1l
        if self._encode:
            res = urllib.parse.quote(l1l11ll1l, safe=l1llllll (u"ࠥࠦࣟ"))
        return res
    def _1111l1ll(self, url):
        l1llllll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1llllll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1llllll (u"ࠨ࠺ࠣ࣢")), l1llllll (u"ࠧࠨࣣ"), url)
        return url
    def _1ll1l111(self, url):
        l1llllll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1111l111 = url.split(l1llllll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1llllll (u"ࠥ࠿ࣦࠧ")))
        result = l1111l111
        if len(result) == 0:
            raise l1lll11ll(l1llllll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1l11llll(self, params):
        l1llllll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1llllll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1llllll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1ll1l1l1 = data.group(l1llllll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1ll1l1l1 in (l1llllll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1llllll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1llllll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1llllll (u"ࠧ࠲࣯ࠢ"))
                elif l1ll1l1l1 == l1llllll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1llllll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1llllll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1ll1l1l1] = value
        return result
    def _1ll1lll1(self, url, scheme):
        l1llllll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1111l11l = {l1llllll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1llllll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l111l1l1l = url.split(l1llllll (u"ࠧࡀࣶࠢ"))
        if len(l111l1l1l) == 1:
            for l11111ll1 in list(l1111l11l.keys()):
                if l11111ll1 == scheme:
                    url += l1llllll (u"ࠨ࠺ࠣࣷ") + str(l1111l11l[l11111ll1])
                    break
        return url
    def _1l111lll(self):
        l1llllll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1ll1111l:
            l1111ll1l = self.l1ll1111l[0]
            l111l11ll = urlparse(l1111ll1l)
        if self.l1l1l1ll1:
            l1ll1ll11 = urlparse(self.l1l1l1ll1)
            if l1ll1ll11.scheme:
                l11lll111 = l1ll1ll11.scheme
            else:
                if l111l11ll.scheme:
                    l11lll111 = l111l11ll.scheme
                else:
                    raise l111111l(
                        l1llllll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1ll1ll11.netloc:
                l1l1lll1l = l1ll1ll11.netloc
            else:
                if l111l11ll.netloc:
                    l1l1lll1l = l111l11ll.netloc
                else:
                    raise l111111l(
                        l1llllll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l1lll1l = self._1ll1lll1(l1l1lll1l, l11lll111)
            path = l1ll1ll11.path
            if not path.endswith(l1llllll (u"ࠪ࠳ࠬࣻ")):
                path += l1llllll (u"ࠫ࠴࠭ࣼ")
            l1l111l11 = ParseResult(scheme=l11lll111, netloc=l1l1lll1l, path=path,
                                         params=l1ll1ll11.params, query=l1ll1ll11.query,
                                         fragment=l1ll1ll11.fragment)
            self.l1l1l1ll1 = l1l111l11.geturl()
        else:
            if not l111l11ll.netloc:
                raise l111111l(l1llllll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1ll111l1 = l111l11ll.path
            l11111l1l = l1llllll (u"ࠨ࠯ࠣࣾ").join(l1ll111l1.split(l1llllll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1llllll (u"ࠣ࠱ࠥऀ")
            l1l111l11 = ParseResult(scheme=l111l11ll.scheme,
                                         netloc=self._1ll1lll1(l111l11ll.netloc, l111l11ll.scheme),
                                         path=l11111l1l,
                                         params=l1llllll (u"ࠤࠥँ"),
                                         query=l1llllll (u"ࠥࠦं"),
                                         fragment=l1llllll (u"ࠦࠧः")
                                         )
            self.l1l1l1ll1 = l1l111l11.geturl()
    def _11l111ll(self):
        l1llllll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1ll1111l:
            l1111ll1l = self.l1ll1111l[0]
            l111l11ll = urlparse(l1111ll1l)
        if self.l11l1l111:
            l11l11l11 = urlparse(self.l11l1l111)
            if l11l11l11.scheme:
                l11llllll = l11l11l11.scheme
            else:
                l11llllll = l111l11ll.scheme
            if l11l11l11.netloc:
                l1l1l1111 = l11l11l11.netloc
            else:
                l1l1l1111 = l111l11ll.netloc
            l111l1l11 = ParseResult(scheme=l11llllll, netloc=l1l1l1111, path=l11l11l11.path,
                                      params=l11l11l11.params, query=l11l11l11.query,
                                      fragment=l11l11l11.fragment)
            self.l11l1l111 = l111l1l11.geturl()
    def _1ll1l1ll(self):
        l1llllll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1ll1111l
        self.l1ll1111l = []
        for item in items:
            l1ll1l11l = urlparse(item.strip(), scheme=l1llllll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1ll1l11l.path[-1] == l1llllll (u"ࠣ࠱ࠥइ"):
                l1l11ll11 = l1ll1l11l.path
            else:
                path_list = l1ll1l11l.path.split(l1llllll (u"ࠤ࠲ࠦई"))
                l1l11ll11 = l1llllll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1llllll (u"ࠦ࠴ࠨऊ")
            l1111llll = urlparse(self.l1l1l1ll1, scheme=l1llllll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1ll1l11l.scheme:
                scheme = l1ll1l11l.scheme
            elif l1111llll.scheme:
                scheme = l1111llll.scheme
            else:
                scheme = l1llllll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1ll1l11l.netloc and not l1111llll.netloc:
                l1ll111ll = l1ll1l11l.netloc
            elif not l1ll1l11l.netloc and l1111llll.netloc:
                l1ll111ll = l1111llll.netloc
            elif not l1ll1l11l.netloc and not l1111llll.netloc and len(self.l1ll1111l) > 0:
                l1l11lll1 = urlparse(self.l1ll1111l[len(self.l1ll1111l) - 1])
                l1ll111ll = l1l11lll1.netloc
            elif l1111llll.netloc:
                l1ll111ll = l1ll1l11l.netloc
            elif not l1111llll.netloc:
                l1ll111ll = l1ll1l11l.netloc
            if l1ll1l11l.path:
                l111l1lll = l1ll1l11l.path
            if l1ll111ll:
                l1ll111ll = self._1ll1lll1(l1ll111ll, scheme)
                l11l11lll = ParseResult(scheme=scheme, netloc=l1ll111ll, path=l111l1lll,
                                          params=l1ll1l11l.params,
                                          query=l1ll1l11l.query,
                                          fragment=l1ll1l11l.fragment)
                self.l1ll1111l.append(l11l11lll.geturl())
    def _1l1l1lll(self):
        l1llllll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1l11l1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l1ll(l1llllll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1l11l1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l1ll(l1llllll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l111ll1l1:
            l1llllllll = []
            for l1lll11l1 in self.l111ll1l1:
                if l1lll11l1 not in [x[l1llllll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1llllllll.append(l1lll11l1)
            if l1llllllll:
                l1l11111 = l1llllll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1llllll (u"ࠧ࠲ࠠࠣऒ").join(l1llllllll))
                raise l111l1ll(l1llllll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l11111)
    def l11l11111(self, params):
        l1llllll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l111ll111 = True
        for param in self._11l1lll1:
            if not params.get(param.lower()):
                l111ll111 = False
        return l111ll111
class l1l1ll111():
    def __init__(self, l1l1ll1ll):
        self.l111l1ll1 = l1lll11.l1111l1()
        self.l11l1ll11 = self.l1l111111()
        self.l11l111l1 = self.l11ll1ll1()
        self.l1l1ll1ll = l1l1ll1ll
        self._1111l1l1 = [l1llllll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1llllll (u"ࠤࡑࡳࡳ࡫ࠢख"), l1llllll (u"ࠥࡅࡱࡲࠢग"), l1llllll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1llllll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1llllll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1llllll (u"ࠢࡊࡇࠥछ"), l1llllll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l1l11l1 = [l1llllll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1llllll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1llllll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1llllll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11l1llll = None
    def l1l111111(self):
        l11111111 = l1llllll (u"ࠨࡎࡰࡰࡨࠦड")
        return l11111111
    def l11ll1ll1(self):
        l111ll11l = 0
        return l111ll11l
    def l111111l1(self):
        l1l11111 = l1llllll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11l111l1)
        l1l11111 += l1llllll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1ll11l11(l11lllll, l1l11111, t=1)
        return res
    def run(self):
        l11l11ll1 = True
        self._1111111l()
        result = []
        try:
            for cookie in l1ll11ll1(l11l1111=self.l1l1ll1ll.cookies).run():
                result.append(cookie)
        except l11111l1 as e:
            logger.exception(l1llllll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1l1111l1 = self._11ll11l1(result)
            if l1l1111l1:
                logger.info(l1llllll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1l1111l1)
                self.l11l1llll = l1l1111l1
            else:
                logger.info(l1llllll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1l1111l1)
            l11l11ll1 = True
        else:
            l11l11ll1 = False
        return l11l11ll1
    def _11ll11l1(self, l1l11l11l):
        res = False
        l1ll1111 = os.path.join(os.environ[l1llllll (u"ࠬࡎࡏࡎࡇࠪध")], l1llllll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1llllll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1l11111l = {}
        for cookies in l1l11l11l:
            l1l11111l[cookies.name] = cookies.value
        l11lll1ll = l1llllll (u"ࠣࠤप")
        for key in list(l1l11111l.keys()):
            l11lll1ll += l1llllll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1l11111l[key].strip())
        if not os.path.exists(os.path.dirname(l1ll1111)):
            os.makedirs(os.path.dirname(l1ll1111))
        vers = int(l1llllll (u"ࠥࠦब").join(self.l111l1ll1.split(l1llllll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1l1lll11 = [l1llllll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1llllll (u"ࠨࠣࠡࠤय") + l1llllll (u"ࠢ࠮ࠤर") * 60,
                              l1llllll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1llllll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1llllll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11lll1ll),
                              l1llllll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1l1lll11 = [l1llllll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1llllll (u"ࠨࠣࠡࠤश") + l1llllll (u"ࠢ࠮ࠤष") * 60,
                              l1llllll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1llllll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1llllll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11lll1ll),
                              l1llllll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1ll1111, l1llllll (u"ࠧࡽ़ࠢ")) as l11ll1111:
            data = l1llllll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1l1lll11)
            l11ll1111.write(data)
            l11ll1111.write(l1llllll (u"ࠢ࡝ࡰࠥा"))
        res = l1ll1111
        return res
    def _1111111l(self):
        self._11ll11ll(l1llllll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11ll1l1l()
    def _11ll11ll(self, l11l1l1l1):
        l11llll11 = self.l1l1ll1ll.dict[l11l1l1l1.lower()]
        if l11llll11:
            if isinstance(l11llll11, list):
                l1ll11111 = l11llll11
            else:
                l1ll11111 = [l11llll11]
            if l1llllll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11l1l1l1.lower():
                    for l111l1111 in l1ll11111:
                        l1l11l1l1 = [l11l1l11l.upper() for l11l1l11l in self._1111l1l1]
                        if not l111l1111.upper() in l1l11l1l1:
                            l1l1l1l1l = l1llllll (u"ࠥ࠰ࠥࠨु").join(self._1111l1l1)
                            l11lll11l = l1llllll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11l1l1l1, l11llll11, l1l1l1l1l, )
                            raise l1llllll1(l11lll11l)
    def _11ll1l1l(self):
        l1ll11lll = []
        l111lllll = self.l1l1ll1ll.l111ll1l1
        for l1111lll1 in self._1111l1l1:
            if not l1111lll1 in [l1llllll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1llllll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1ll11lll.append(l1111lll1)
        for l11l1l1ll in self.l1l1ll1ll.l11ll1lll:
            if l11l1l1ll in l1ll11lll and not l111lllll:
                l11lll11l = l1llllll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1llllll1(l11lll11l)
def l11l1111l(title, message, l11111lll, l1lll1111=None):
    l1l11l111 = l11ll1l11()
    l1l11l111.l1111ll11(message, title, l11111lll, l1lll1111)
def l111ll1ll(title, message, l11111lll):
    l1l1llll1 = l1l1l1l11()
    l1l1llll1.l11111l11(title, message, l11111lll)
    res = l1l1llll1.result
    return res
def main():
    try:
        logger.info(l1llllll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11l1lll)
        system.l11lllll1()
        logger.info(l1llllll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1111111(
                l1llllll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111lll11 = l1l1l111l()
        l111lll11.l11l1ll1l(l1llllll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l1l11ll = [item.upper() for item in l111lll11.l11ll1lll]
        l1l1lllll = l1llllll (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l1l11ll
        if l1l1lllll:
            logger.info(l1llllll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1lll111l = l111lll11.l1ll1111l
            for l1ll11ll in l1lll111l:
                logger.debug(l1llllll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1ll11ll))
                opener = l1ll11l(l111lll11.l1l1l1ll1, l1ll11ll, l1ll1111=None, l1l1l=l11l1lll)
                opener.open()
                logger.info(l1llllll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111lll1l = l1l1ll111(l111lll11)
            l1ll1llll = l111lll1l.run()
            l1lll111l = l111lll11.l1ll1111l
            for l1ll11ll in l1lll111l:
                logger.info(l1llllll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1ll11ll))
                opener = l1ll11l(l111lll11.l1l1l1ll1, l1ll11ll, l1ll1111=l111lll1l.l11l1llll,
                                l1l1l=l11l1lll)
                opener.open()
                logger.info(l1llllll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11l1l as e:
        title = l1llllll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11lllll
        logger.exception(l1llllll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1ll1ll1l = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll1ll1l = el
        l1l1ll1l1 = l1llllll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l111l11, message.strip())
        l11l1111l(title, l1l1ll1l1, l11111lll=l11l1lll.get_value(l1llllll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1llllll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1lll1111=l1ll1ll1l)
        sys.exit(2)
    except l1lll1l1l as e:
        title = l1llllll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11lllll
        logger.exception(l1llllll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1ll1ll1l = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll1ll1l = el
        l1l1ll1l1 = l1llllll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l11l1111l(title, l1l1ll1l1, l11111lll=l11l1lll.get_value(l1llllll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1llllll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1lll1111=l1ll1ll1l)
        sys.exit(2)
    except l1111111 as e:
        title = l1llllll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11lllll
        logger.exception(l1llllll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l11l1111l(title, str(e), l11111lll=l11l1lll.get_value(l1llllll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1llllll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1llllll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11lllll
        logger.exception(l1llllll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l11l1111l(title, l1llllll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11111lll=l11l1lll.get_value(l1llllll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1llllll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1llllll1 as e:
        title = l1llllll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11lllll
        logger.exception(l1llllll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l11l1111l(title, l1llllll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11111lll=l11l1lll.get_value(l1llllll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1llllll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1l11 as e:
        title = l1llllll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11lllll
        logger.exception(l1llllll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l11l1111l(title, l1llllll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11111lll=l11l1lll.get_value(l1llllll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1llllll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l11l1ll:
        logger.info(l1llllll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1llllll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11lllll
        logger.exception(l1llllll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l11l1111l(title, l1llllll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11111lll=l11l1lll.get_value(l1llllll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1llllll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1llllll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()