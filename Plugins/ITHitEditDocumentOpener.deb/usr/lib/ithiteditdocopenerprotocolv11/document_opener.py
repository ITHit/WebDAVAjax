#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1lll = 7
def l111ll1 (l11l111):
    global l1lll11l
    l1111ll = ord (l11l111 [-1])
    l1lll1l1 = l11l111 [:-1]
    l1lll1l = l1111ll % len (l1lll1l1)
    l1llll = l1lll1l1 [:l1lll1l] + l1lll1l1 [l1lll1l:]
    if l1l1111:
        l11l1ll = l1lllll () .join ([unichr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    return eval (l11l1ll)
import sys, json
import os
import urllib
import l1l1lll
from l1l111l import *
import platform
from urllib.parse import urlparse, ParseResult
from l11llll1 import l1l1ll11, logger, l1l1ll1l
from cookies import l111l1l1 as l11l11111
from l1ll11ll import l1l11l
l1l111111 = None
from l1l1l11 import *
class l11lll11l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l111ll1 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1ll11l1l):
        self.config = l1ll11l1l
        self.l111lll11 = l1l1lll.l1ll1l1l()
    def l11lll111(self):
        data = platform.uname()
        logger.info(l111ll1 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l111ll1 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l111ll1 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l111ll1 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll1llll():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l11l1ll = [l111ll1 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l1ll1ll = None
        self.l111lll1l = None
        self.l1l11llll = None
        self.l1l1lllll = None
        self.l111l1l = None
        self.l11ll111l = None
        self.l111l1ll1 = None
        self.l1ll111ll = None
        self.cookies = None
    def l1llllllll(self, url):
        l111ll1 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l111ll1 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._111lllll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111111l1(url)
        self.dict = self._111111ll(params)
        logger.info(l111ll1 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1ll1l111(self.dict):
            raise l11111l1(l111ll1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1l11l1ll)
        self._11l11ll1(self.dict)
        if self._encode:
            self.l1111l1ll()
        self._1ll1l1l1()
        self._111ll11l()
        self._1l1ll11l()
        self._1l11ll1l()
        self.l11111l11()
        logger.info(l111ll1 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l111ll1 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l1ll1ll))
        logger.info(l111ll1 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l111lll1l))
        logger.info(l111ll1 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1l11llll))
        logger.info(l111ll1 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1l1lllll))
        logger.info(l111ll1 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l111l1l))
        logger.info(l111ll1 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11ll111l))
        logger.info(l111ll1 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l111l1ll1))
        logger.info(l111ll1 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1ll111ll))
    def _11l11ll1(self, l11l1llll):
        self.l1l1ll1ll = l11l1llll.get(l111ll1 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l111lll1l = l11l1llll.get(l111ll1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l111ll1 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1l11llll = l11l1llll.get(l111ll1 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1l1lllll = l11l1llll.get(l111ll1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l111l1l = l11l1llll.get(l111ll1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11ll111l = l11l1llll.get(l111ll1 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l111l1ll1 = l11l1llll.get(l111ll1 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l111ll1 (u"ࠣࠤ࣏"))
        self.l1ll111ll = l11l1llll.get(l111ll1 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l111ll1 (u"࣑ࠥࠦ"))
        self.cookies = l11l1llll.get(l111ll1 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11111l11(self):
        l1ll11111 = False
        if self.l111l1l:
            if self.l111l1l.upper() == l111ll1 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l111l1l = l111ll1 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l111l1l.upper() == l111ll1 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l111l1l = l111ll1 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l111l1l.upper() == l111ll1 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l111l1l = l111ll1 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l111l1l.upper() == l111ll1 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l111l1l = l111ll1 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l111l1l == l111ll1 (u"ࠨࠢࣛ"):
                l1ll11111 = True
            else:
                self.l111l1l = self.l111l1l.lower()
        else:
            l1ll11111 = True
        if l1ll11111:
            self.l111l1l = l111ll1 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1111l1ll(self):
        l111ll1 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l111ll1 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l1111ll = []
                    for el in self.__dict__.get(key):
                        l1l1111ll.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l1111ll
    def l1l11lll1(self, l1l1l1l1l):
        res = l1l1l1l1l
        if self._encode:
            res = urllib.parse.quote(l1l1l1l1l, safe=l111ll1 (u"ࠥࠦࣟ"))
        return res
    def _111lllll(self, url):
        l111ll1 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l111ll1 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l111ll1 (u"ࠨ࠺ࠣ࣢")), l111ll1 (u"ࠧࠨࣣ"), url)
        return url
    def _111111l1(self, url):
        l111ll1 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1ll1ll11 = url.split(l111ll1 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l111ll1 (u"ࠥ࠿ࣦࠧ")))
        result = l1ll1ll11
        if len(result) == 0:
            raise l1llllll1(l111ll1 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _111111ll(self, params):
        l111ll1 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l111ll1 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l111ll1 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11ll1ll1 = data.group(l111ll1 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11ll1ll1 in (l111ll1 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l111ll1 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l111ll1 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l111ll1 (u"ࠧ࠲࣯ࠢ"))
                elif l11ll1ll1 == l111ll1 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l111ll1 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l111ll1 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11ll1ll1] = value
        return result
    def _11l11lll(self, url, scheme):
        l111ll1 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l11l1l1 = {l111ll1 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l111ll1 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l111ll1ll = url.split(l111ll1 (u"ࠧࡀࣶࠢ"))
        if len(l111ll1ll) == 1:
            for l11l1111l in list(l1l11l1l1.keys()):
                if l11l1111l == scheme:
                    url += l111ll1 (u"ࠨ࠺ࠣࣷ") + str(l1l11l1l1[l11l1111l])
                    break
        return url
    def _1ll1l1l1(self):
        l111ll1 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1l1lllll:
            l11ll11l1 = self.l1l1lllll[0]
            l11l11l1l = urlparse(l11ll11l1)
        if self.l1l1ll1ll:
            l1l111l1l = urlparse(self.l1l1ll1ll)
            if l1l111l1l.scheme:
                l1l1l1l11 = l1l111l1l.scheme
            else:
                if l11l11l1l.scheme:
                    l1l1l1l11 = l11l11l1l.scheme
                else:
                    raise l1lll1lll(
                        l111ll1 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l111l1l.netloc:
                l1ll1l1ll = l1l111l1l.netloc
            else:
                if l11l11l1l.netloc:
                    l1ll1l1ll = l11l11l1l.netloc
                else:
                    raise l1lll1lll(
                        l111ll1 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1ll1l1ll = self._11l11lll(l1ll1l1ll, l1l1l1l11)
            path = l1l111l1l.path
            if not path.endswith(l111ll1 (u"ࠪ࠳ࠬࣻ")):
                path += l111ll1 (u"ࠫ࠴࠭ࣼ")
            l1l111l11 = ParseResult(scheme=l1l1l1l11, netloc=l1ll1l1ll, path=path,
                                         params=l1l111l1l.params, query=l1l111l1l.query,
                                         fragment=l1l111l1l.fragment)
            self.l1l1ll1ll = l1l111l11.geturl()
        else:
            if not l11l11l1l.netloc:
                raise l1lll1lll(l111ll1 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11llll11 = l11l11l1l.path
            l1l11111l = l111ll1 (u"ࠨ࠯ࠣࣾ").join(l11llll11.split(l111ll1 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l111ll1 (u"ࠣ࠱ࠥऀ")
            l1l111l11 = ParseResult(scheme=l11l11l1l.scheme,
                                         netloc=self._11l11lll(l11l11l1l.netloc, l11l11l1l.scheme),
                                         path=l1l11111l,
                                         params=l111ll1 (u"ࠤࠥँ"),
                                         query=l111ll1 (u"ࠥࠦं"),
                                         fragment=l111ll1 (u"ࠦࠧः")
                                         )
            self.l1l1ll1ll = l1l111l11.geturl()
    def _1l1ll11l(self):
        l111ll1 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1l1lllll:
            l11ll11l1 = self.l1l1lllll[0]
            l11l11l1l = urlparse(l11ll11l1)
        if self.l11ll111l:
            l111l11l1 = urlparse(self.l11ll111l)
            if l111l11l1.scheme:
                l11ll1111 = l111l11l1.scheme
            else:
                l11ll1111 = l11l11l1l.scheme
            if l111l11l1.netloc:
                l1111l11l = l111l11l1.netloc
            else:
                l1111l11l = l11l11l1l.netloc
            l11lll1l1 = ParseResult(scheme=l11ll1111, netloc=l1111l11l, path=l111l11l1.path,
                                      params=l111l11l1.params, query=l111l11l1.query,
                                      fragment=l111l11l1.fragment)
            self.l11ll111l = l11lll1l1.geturl()
    def _111ll11l(self):
        l111ll1 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1l1lllll
        self.l1l1lllll = []
        for item in items:
            l1111llll = urlparse(item.strip(), scheme=l111ll1 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1111llll.path[-1] == l111ll1 (u"ࠣ࠱ࠥइ"):
                l11111lll = l1111llll.path
            else:
                path_list = l1111llll.path.split(l111ll1 (u"ࠤ࠲ࠦई"))
                l11111lll = l111ll1 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l111ll1 (u"ࠦ࠴ࠨऊ")
            l1l1ll111 = urlparse(self.l1l1ll1ll, scheme=l111ll1 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1111llll.scheme:
                scheme = l1111llll.scheme
            elif l1l1ll111.scheme:
                scheme = l1l1ll111.scheme
            else:
                scheme = l111ll1 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1111llll.netloc and not l1l1ll111.netloc:
                l111ll111 = l1111llll.netloc
            elif not l1111llll.netloc and l1l1ll111.netloc:
                l111ll111 = l1l1ll111.netloc
            elif not l1111llll.netloc and not l1l1ll111.netloc and len(self.l1l1lllll) > 0:
                l1l1l11l1 = urlparse(self.l1l1lllll[len(self.l1l1lllll) - 1])
                l111ll111 = l1l1l11l1.netloc
            elif l1l1ll111.netloc:
                l111ll111 = l1111llll.netloc
            elif not l1l1ll111.netloc:
                l111ll111 = l1111llll.netloc
            if l1111llll.path:
                l1ll11lll = l1111llll.path
            if l111ll111:
                l111ll111 = self._11l11lll(l111ll111, scheme)
                l1l1l11ll = ParseResult(scheme=scheme, netloc=l111ll111, path=l1ll11lll,
                                          params=l1111llll.params,
                                          query=l1111llll.query,
                                          fragment=l1111llll.fragment)
                self.l1l1lllll.append(l1l1l11ll.geturl())
    def _1l11ll1l(self):
        l111ll1 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1111ll1l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111lll(l111ll1 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1111ll1l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111lll(l111ll1 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1l11llll:
            l1l1llll1 = []
            for l1ll11l11 in self.l1l11llll:
                if l1ll11l11 not in [x[l111ll1 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l1llll1.append(l1ll11l11)
            if l1l1llll1:
                l1l1lll1 = l111ll1 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l111ll1 (u"ࠧ࠲ࠠࠣऒ").join(l1l1llll1))
                raise l1111lll(l111ll1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l1lll1)
    def l1ll1l111(self, params):
        l111ll1 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1111111l = True
        for param in self._1l11l1ll:
            if not params.get(param.lower()):
                l1111111l = False
        return l1111111l
class l1l1ll1l1():
    def __init__(self, l11ll1lll):
        self.l11ll1l1l = l1l1lll.l1ll1l1l()
        self.l11l1l1ll = self.l11lll1ll()
        self.l1l1111l1 = self.l1ll11ll1()
        self.l11ll1lll = l11ll1lll
        self._1l11ll11 = [l111ll1 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l111ll1 (u"ࠤࡑࡳࡳ࡫ࠢख"), l111ll1 (u"ࠥࡅࡱࡲࠢग"), l111ll1 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l111ll1 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l111ll1 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l111ll1 (u"ࠢࡊࡇࠥछ"), l111ll1 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1ll1111l = [l111ll1 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l111ll1 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l111ll1 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l111ll1 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11111l1l = None
    def l11lll1ll(self):
        l1lll111l = l111ll1 (u"ࠨࡎࡰࡰࡨࠦड")
        return l1lll111l
    def l1ll11ll1(self):
        l11ll1l11 = 0
        return l11ll1l11
    def l1ll1ll1l(self):
        l1l1lll1 = l111ll1 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1l1111l1)
        l1l1lll1 += l111ll1 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l1l111l(l1l1ll11, l1l1lll1, t=1)
        return res
    def run(self):
        l1l1l1lll = True
        self._111l1111()
        result = []
        try:
            for cookie in l11l11111(l11l11l1=self.l11ll1lll.cookies).run():
                result.append(cookie)
        except l1lllll1l as e:
            logger.exception(l111ll1 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11l111ll = self._111ll1l1(result)
            if l11l111ll:
                logger.info(l111ll1 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11l111ll)
                self.l11111l1l = l11l111ll
            else:
                logger.info(l111ll1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11l111ll)
            l1l1l1lll = True
        else:
            l1l1l1lll = False
        return l1l1l1lll
    def _111ll1l1(self, l11l1ll11):
        res = False
        l1ll1l1 = os.path.join(os.environ[l111ll1 (u"ࠬࡎࡏࡎࡇࠪध")], l111ll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l111ll1 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11l111l1 = {}
        for cookies in l11l1ll11:
            l11l111l1[cookies.name] = cookies.value
        l11111ll1 = l111ll1 (u"ࠣࠤप")
        for key in list(l11l111l1.keys()):
            l11111ll1 += l111ll1 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11l111l1[key].strip())
        if not os.path.exists(os.path.dirname(l1ll1l1)):
            os.makedirs(os.path.dirname(l1ll1l1))
        vers = int(l111ll1 (u"ࠥࠦब").join(self.l11ll1l1l.split(l111ll1 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1l1l1ll1 = [l111ll1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l111ll1 (u"ࠨࠣࠡࠤय") + l111ll1 (u"ࠢ࠮ࠤर") * 60,
                              l111ll1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l111ll1 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l111ll1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11111ll1),
                              l111ll1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1l1l1ll1 = [l111ll1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l111ll1 (u"ࠨࠣࠡࠤश") + l111ll1 (u"ࠢ࠮ࠤष") * 60,
                              l111ll1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l111ll1 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l111ll1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11111ll1),
                              l111ll1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1ll1l1, l111ll1 (u"ࠧࡽ़ࠢ")) as l111l1lll:
            data = l111ll1 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1l1l1ll1)
            l111l1lll.write(data)
            l111l1lll.write(l111ll1 (u"ࠢ࡝ࡰࠥा"))
        res = l1ll1l1
        return res
    def _111l1111(self):
        self._11l1lll1(l111ll1 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11111111()
    def _11l1lll1(self, l1ll1lll1):
        l11l11l11 = self.l11ll1lll.dict[l1ll1lll1.lower()]
        if l11l11l11:
            if isinstance(l11l11l11, list):
                l1l1lll11 = l11l11l11
            else:
                l1l1lll11 = [l11l11l11]
            if l111ll1 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1ll1lll1.lower():
                    for l1l11l11l in l1l1lll11:
                        l11l1l1l1 = [l1111l1l1.upper() for l1111l1l1 in self._1l11ll11]
                        if not l1l11l11l.upper() in l11l1l1l1:
                            l1lll11l1 = l111ll1 (u"ࠥ࠰ࠥࠨु").join(self._1l11ll11)
                            l1ll1l11l = l111ll1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1ll1lll1, l11l11l11, l1lll11l1, )
                            raise l1lll1l11(l1ll1l11l)
    def _11111111(self):
        l1l11l111 = []
        l111l111l = self.l11ll1lll.l1l11llll
        for l1lll1111 in self._1l11ll11:
            if not l1lll1111 in [l111ll1 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l111ll1 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1l11l111.append(l1lll1111)
        for l1111ll11 in self.l11ll1lll.l111lll1l:
            if l1111ll11 in l1l11l111 and not l111l111l:
                l1ll1l11l = l111ll1 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lll1l11(l1ll1l11l)
def l11l1l11l(title, message, l111l1l1l, l1111lll1=None):
    l11llll1l = l11llllll()
    l11llll1l.l1l1l1111(message, title, l111l1l1l, l1111lll1)
def l1l1lll1l(title, message, l111l1l1l):
    l111l1l11 = l1111l111()
    l111l1l11.l11ll11ll(title, message, l111l1l1l)
    res = l111l1l11.result
    return res
def main():
    try:
        logger.info(l111ll1 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1ll1l)
        system.l11lll111()
        logger.info(l111ll1 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l11111l1(
                l111ll1 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1l111ll1 = l1ll1llll()
        l1l111ll1.l1llllllll(l111ll1 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l111lll = [item.upper() for item in l1l111ll1.l111lll1l]
        l111l11ll = l111ll1 (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l111lll
        if l111l11ll:
            logger.info(l111ll1 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l11l1l111 = l1l111ll1.l1l1lllll
            for l1lll1ll in l11l1l111:
                logger.debug(l111ll1 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1lll1ll))
                opener = l1l11l(l1l111ll1.l1l1ll1ll, l1lll1ll, l1ll1l1=None, l1lll111=l1l1ll1l)
                opener.open()
                logger.info(l111ll1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11l1ll1l = l1l1ll1l1(l1l111ll1)
            l11lllll1 = l11l1ll1l.run()
            l11l1l111 = l1l111ll1.l1l1lllll
            for l1lll1ll in l11l1l111:
                logger.info(l111ll1 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1lll1ll))
                opener = l1l11l(l1l111ll1.l1l1ll1ll, l1lll1ll, l1ll1l1=l11l1ll1l.l11111l1l,
                                l1lll111=l1l1ll1l)
                opener.open()
                logger.info(l111ll1 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1lll as e:
        title = l111ll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1ll11
        logger.exception(l111ll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1ll111l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll111l1 = el
        l111llll1 = l111ll1 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1l11ll, message.strip())
        l11l1l11l(title, l111llll1, l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l111ll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1111lll1=l1ll111l1)
        sys.exit(2)
    except l1lllllll as e:
        title = l111ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1ll11
        logger.exception(l111ll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1ll111l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll111l1 = el
        l111llll1 = l111ll1 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l11l1l11l(title, l111llll1, l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l111ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1111lll1=l1ll111l1)
        sys.exit(2)
    except l11111l1 as e:
        title = l111ll1 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1ll11
        logger.exception(l111ll1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l11l1l11l(title, str(e), l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l111ll1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l111ll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1ll11
        logger.exception(l111ll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l11l1l11l(title, l111ll1 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l111ll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lll1l11 as e:
        title = l111ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1ll11
        logger.exception(l111ll1 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l11l1l11l(title, l111ll1 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l111ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lllll11 as e:
        title = l111ll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1ll11
        logger.exception(l111ll1 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l11l1l11l(title, l111ll1 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l111ll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll11:
        logger.info(l111ll1 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l111ll1 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1ll11
        logger.exception(l111ll1 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l11l1l11l(title, l111ll1 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l111l1l1l=l1l1ll1l.get_value(l111ll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l111ll1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l111ll1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()