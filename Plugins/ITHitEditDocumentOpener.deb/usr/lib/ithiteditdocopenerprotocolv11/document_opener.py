#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111 = sys.version_info [0] == 2
l111 = 2048
l1ll1l1l = 7
def l11l1ll (l1ll1l11):
    global ll
    l1ll111 = ord (l1ll1l11 [-1])
    l1llll1l = l1ll1l11 [:-1]
    l1lll = l1ll111 % len (l1llll1l)
    l1 = l1llll1l [:l1lll] + l1llll1l [l1lll:]
    if l11111:
        l1ll1lll = l11l11 () .join ([unichr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    else:
        l1ll1lll = str () .join ([chr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    return eval (l1ll1lll)
import sys, json
import os
import urllib
import l1l11l1
from l1111 import *
import platform
from urllib.parse import urlparse, ParseResult
from l11lllll import l11lll1l, logger, l1l1llll
from cookies import l111ll1l as l1l1lll1l
from l1lll111 import l1l1ll1
l11llll11 = None
from l111l import *
class l1l111lll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l11l1ll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1llll1):
        self.config = l1l1llll1
        self.l1ll111ll = l1l11l1.l1lllll1()
    def l1l1ll1ll(self):
        data = platform.uname()
        logger.info(l11l1ll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l11l1ll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l11l1ll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l11l1ll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll1l1l1():
    def __init__(self, encode = True):
        self._encode = encode
        self._1111l1ll = [l11l1ll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1111llll = None
        self.l1ll111l1 = None
        self.l1l111l11 = None
        self.l1ll11l11 = None
        self.l1l1ll = None
        self.l111111l1 = None
        self.l1l111l1l = None
        self.l111lll11 = None
        self.cookies = None
    def l1ll1l111(self, url):
        l11l1ll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l11l1ll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l1lllll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1ll1ll1l(url)
        self.dict = self._111ll11l(params)
        logger.info(l11l1ll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l111ll111(self.dict):
            raise l1111l11(l11l1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1111l1ll)
        self._11ll111l(self.dict)
        if self._encode:
            self.l111l1ll1()
        self._1l111ll1()
        self._11l1111l()
        self._1ll11lll()
        self._111llll1()
        self.l1111ll11()
        logger.info(l11l1ll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l11l1ll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1111llll))
        logger.info(l11l1ll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1ll111l1))
        logger.info(l11l1ll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1l111l11))
        logger.info(l11l1ll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1ll11l11))
        logger.info(l11l1ll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1l1ll))
        logger.info(l11l1ll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l111111l1))
        logger.info(l11l1ll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l111l1l))
        logger.info(l11l1ll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l111lll11))
    def _11ll111l(self, l1l1l1l11):
        self.l1111llll = l1l1l1l11.get(l11l1ll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1ll111l1 = l1l1l1l11.get(l11l1ll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l11l1ll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1l111l11 = l1l1l1l11.get(l11l1ll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1ll11l11 = l1l1l1l11.get(l11l1ll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1l1ll = l1l1l1l11.get(l11l1ll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l111111l1 = l1l1l1l11.get(l11l1ll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l111l1l = l1l1l1l11.get(l11l1ll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l11l1ll (u"ࠣࠤ࣏"))
        self.l111lll11 = l1l1l1l11.get(l11l1ll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l11l1ll (u"࣑ࠥࠦ"))
        self.cookies = l1l1l1l11.get(l11l1ll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1111ll11(self):
        l11lll11l = False
        if self.l1l1ll:
            if self.l1l1ll.upper() == l11l1ll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1l1ll = l11l1ll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1l1ll.upper() == l11l1ll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1l1ll = l11l1ll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1l1ll.upper() == l11l1ll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1l1ll = l11l1ll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1l1ll.upper() == l11l1ll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1l1ll = l11l1ll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1l1ll == l11l1ll (u"ࠨࠢࣛ"):
                l11lll11l = True
            else:
                self.l1l1ll = self.l1l1ll.lower()
        else:
            l11lll11l = True
        if l11lll11l:
            self.l1l1ll = l11l1ll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l111l1ll1(self):
        l11l1ll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l11l1ll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11ll1ll1 = []
                    for el in self.__dict__.get(key):
                        l11ll1ll1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11ll1ll1
    def l11llll1l(self, l1lll1111):
        res = l1lll1111
        if self._encode:
            res = urllib.parse.quote(l1lll1111, safe=l11l1ll (u"ࠥࠦࣟ"))
        return res
    def _1l1lllll(self, url):
        l11l1ll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l11l1ll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l11l1ll (u"ࠨ࠺ࠣ࣢")), l11l1ll (u"ࠧࠨࣣ"), url)
        return url
    def _1ll1ll1l(self, url):
        l11l1ll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11l11ll1 = url.split(l11l1ll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l11l1ll (u"ࠥ࠿ࣦࠧ")))
        result = l11l11ll1
        if len(result) == 0:
            raise l1llll11l(l11l1ll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _111ll11l(self, params):
        l11l1ll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l11l1ll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l11l1ll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l1l1ll1 = data.group(l11l1ll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l1l1ll1 in (l11l1ll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l11l1ll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l11l1ll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l11l1ll (u"ࠧ࠲࣯ࠢ"))
                elif l1l1l1ll1 == l11l1ll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l11l1ll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l11l1ll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l1l1ll1] = value
        return result
    def _1l1ll1l1(self, url, scheme):
        l11l1ll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l11llllll = {l11l1ll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l11l1ll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1ll1l1ll = url.split(l11l1ll (u"ࠧࡀࣶࠢ"))
        if len(l1ll1l1ll) == 1:
            for l1l1111ll in list(l11llllll.keys()):
                if l1l1111ll == scheme:
                    url += l11l1ll (u"ࠨ࠺ࠣࣷ") + str(l11llllll[l1l1111ll])
                    break
        return url
    def _1l111ll1(self):
        l11l1ll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1ll11l11:
            l1lll111l = self.l1ll11l11[0]
            l11l1llll = urlparse(l1lll111l)
        if self.l1111llll:
            l111l1l1l = urlparse(self.l1111llll)
            if l111l1l1l.scheme:
                l1l1ll11l = l111l1l1l.scheme
            else:
                if l11l1llll.scheme:
                    l1l1ll11l = l11l1llll.scheme
                else:
                    raise l1llll1ll(
                        l11l1ll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l111l1l1l.netloc:
                l111l11l1 = l111l1l1l.netloc
            else:
                if l11l1llll.netloc:
                    l111l11l1 = l11l1llll.netloc
                else:
                    raise l1llll1ll(
                        l11l1ll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l111l11l1 = self._1l1ll1l1(l111l11l1, l1l1ll11l)
            path = l111l1l1l.path
            if not path.endswith(l11l1ll (u"ࠪ࠳ࠬࣻ")):
                path += l11l1ll (u"ࠫ࠴࠭ࣼ")
            l1ll11111 = ParseResult(scheme=l1l1ll11l, netloc=l111l11l1, path=path,
                                         params=l111l1l1l.params, query=l111l1l1l.query,
                                         fragment=l111l1l1l.fragment)
            self.l1111llll = l1ll11111.geturl()
        else:
            if not l11l1llll.netloc:
                raise l1llll1ll(l11l1ll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l11lll1 = l11l1llll.path
            l1111l1l1 = l11l1ll (u"ࠨ࠯ࠣࣾ").join(l1l11lll1.split(l11l1ll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l11l1ll (u"ࠣ࠱ࠥऀ")
            l1ll11111 = ParseResult(scheme=l11l1llll.scheme,
                                         netloc=self._1l1ll1l1(l11l1llll.netloc, l11l1llll.scheme),
                                         path=l1111l1l1,
                                         params=l11l1ll (u"ࠤࠥँ"),
                                         query=l11l1ll (u"ࠥࠦं"),
                                         fragment=l11l1ll (u"ࠦࠧः")
                                         )
            self.l1111llll = l1ll11111.geturl()
    def _1ll11lll(self):
        l11l1ll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1ll11l11:
            l1lll111l = self.l1ll11l11[0]
            l11l1llll = urlparse(l1lll111l)
        if self.l111111l1:
            l111l1lll = urlparse(self.l111111l1)
            if l111l1lll.scheme:
                l111lll1l = l111l1lll.scheme
            else:
                l111lll1l = l11l1llll.scheme
            if l111l1lll.netloc:
                l11111111 = l111l1lll.netloc
            else:
                l11111111 = l11l1llll.netloc
            l11l11111 = ParseResult(scheme=l111lll1l, netloc=l11111111, path=l111l1lll.path,
                                      params=l111l1lll.params, query=l111l1lll.query,
                                      fragment=l111l1lll.fragment)
            self.l111111l1 = l11l11111.geturl()
    def _11l1111l(self):
        l11l1ll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1ll11l11
        self.l1ll11l11 = []
        for item in items:
            l11ll1l1l = urlparse(item.strip(), scheme=l11l1ll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11ll1l1l.path[-1] == l11l1ll (u"ࠣ࠱ࠥइ"):
                l11111lll = l11ll1l1l.path
            else:
                path_list = l11ll1l1l.path.split(l11l1ll (u"ࠤ࠲ࠦई"))
                l11111lll = l11l1ll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l11l1ll (u"ࠦ࠴ࠨऊ")
            l1l11l1l1 = urlparse(self.l1111llll, scheme=l11l1ll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11ll1l1l.scheme:
                scheme = l11ll1l1l.scheme
            elif l1l11l1l1.scheme:
                scheme = l1l11l1l1.scheme
            else:
                scheme = l11l1ll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11ll1l1l.netloc and not l1l11l1l1.netloc:
                l11l111ll = l11ll1l1l.netloc
            elif not l11ll1l1l.netloc and l1l11l1l1.netloc:
                l11l111ll = l1l11l1l1.netloc
            elif not l11ll1l1l.netloc and not l1l11l1l1.netloc and len(self.l1ll11l11) > 0:
                l1l11ll11 = urlparse(self.l1ll11l11[len(self.l1ll11l11) - 1])
                l11l111ll = l1l11ll11.netloc
            elif l1l11l1l1.netloc:
                l11l111ll = l11ll1l1l.netloc
            elif not l1l11l1l1.netloc:
                l11l111ll = l11ll1l1l.netloc
            if l11ll1l1l.path:
                l1111lll1 = l11ll1l1l.path
            if l11l111ll:
                l11l111ll = self._1l1ll1l1(l11l111ll, scheme)
                l11ll11ll = ParseResult(scheme=scheme, netloc=l11l111ll, path=l1111lll1,
                                          params=l11ll1l1l.params,
                                          query=l11ll1l1l.query,
                                          fragment=l11ll1l1l.fragment)
                self.l1ll11l11.append(l11ll11ll.geturl())
    def _111llll1(self):
        l11l1ll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1l11111l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l11l1ll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1l11111l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l11l1ll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1l111l11:
            l1l1ll111 = []
            for l11l11lll in self.l1l111l11:
                if l11l11lll not in [x[l11l1ll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l1ll111.append(l11l11lll)
            if l1l1ll111:
                l11ll11l = l11l1ll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l11l1ll (u"ࠧ࠲ࠠࠣऒ").join(l1l1ll111))
                raise l111ll11(l11l1ll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11ll11l)
    def l111ll111(self, params):
        l11l1ll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l111lllll = True
        for param in self._1111l1ll:
            if not params.get(param.lower()):
                l111lllll = False
        return l111lllll
class l1ll1l11l():
    def __init__(self, l1l11l11l):
        self.l1111l111 = l1l11l1.l1lllll1()
        self.l1ll1llll = self.l1ll1ll11()
        self.l1ll11l1l = self.l111l11ll()
        self.l1l11l11l = l1l11l11l
        self._11l1l1l1 = [l11l1ll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l11l1ll (u"ࠤࡑࡳࡳ࡫ࠢख"), l11l1ll (u"ࠥࡅࡱࡲࠢग"), l11l1ll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l11l1ll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l11l1ll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l11l1ll (u"ࠢࡊࡇࠥछ"), l11l1ll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._111ll1ll = [l11l1ll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l11l1ll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l11l1ll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l11l1ll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l1l1l1l = None
    def l1ll1ll11(self):
        l11ll1111 = l11l1ll (u"ࠨࡎࡰࡰࡨࠦड")
        return l11ll1111
    def l111l11ll(self):
        l1lll11l1 = 0
        return l1lll11l1
    def l1l1l111l(self):
        l11ll11l = l11l1ll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1ll11l1l)
        l11ll11l += l11l1ll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l111ll1l1(l11lll1l, l11ll11l, t=1)
        return res
    def run(self):
        l1l1111l1 = True
        self._1llllllll()
        result = []
        try:
            for cookie in l1l1lll1l(l111l1ll=self.l1l11l11l.cookies).run():
                result.append(cookie)
        except l111111l as e:
            logger.exception(l11l1ll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l111l1111 = self._11l1l11l(result)
            if l111l1111:
                logger.info(l11l1ll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l111l1111)
                self.l1l1l1l1l = l111l1111
            else:
                logger.info(l11l1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l111l1111)
            l1l1111l1 = True
        else:
            l1l1111l1 = False
        return l1l1111l1
    def _11l1l11l(self, l1l1l1111):
        res = False
        l1llll1 = os.path.join(os.environ[l11l1ll (u"ࠬࡎࡏࡎࡇࠪध")], l11l1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l11l1ll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1111111l = {}
        for cookies in l1l1l1111:
            l1111111l[cookies.name] = cookies.value
        l1l111111 = l11l1ll (u"ࠣࠤप")
        for key in list(l1111111l.keys()):
            l1l111111 += l11l1ll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1111111l[key].strip())
        if not os.path.exists(os.path.dirname(l1llll1)):
            os.makedirs(os.path.dirname(l1llll1))
        vers = int(l11l1ll (u"ࠥࠦब").join(self.l1111l111.split(l11l1ll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11ll1lll = [l11l1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l11l1ll (u"ࠨࠣࠡࠤय") + l11l1ll (u"ࠢ࠮ࠤर") * 60,
                              l11l1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l11l1ll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l11l1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l111111),
                              l11l1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11ll1lll = [l11l1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l11l1ll (u"ࠨࠣࠡࠤश") + l11l1ll (u"ࠢ࠮ࠤष") * 60,
                              l11l1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l11l1ll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l11l1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l111111),
                              l11l1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1llll1, l11l1ll (u"ࠧࡽ़ࠢ")) as l11l1l1ll:
            data = l11l1ll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11ll1lll)
            l11l1l1ll.write(data)
            l11l1l1ll.write(l11l1ll (u"ࠢ࡝ࡰࠥा"))
        res = l1llll1
        return res
    def _1llllllll(self):
        self._1111l11l(l11l1ll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11111l11()
    def _1111l11l(self, l1l1l11l1):
        l1111ll1l = self.l1l11l11l.dict[l1l1l11l1.lower()]
        if l1111ll1l:
            if isinstance(l1111ll1l, list):
                l11lllll1 = l1111ll1l
            else:
                l11lllll1 = [l1111ll1l]
            if l11l1ll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1l1l11l1.lower():
                    for l1l1lll11 in l11lllll1:
                        l11111ll1 = [l111111ll.upper() for l111111ll in self._11l1l1l1]
                        if not l1l1lll11.upper() in l11111ll1:
                            l11l11l11 = l11l1ll (u"ࠥ࠰ࠥࠨु").join(self._11l1l1l1)
                            l11lll1ll = l11l1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1l1l11l1, l1111ll1l, l11l11l11, )
                            raise l1lll1lll(l11lll1ll)
    def _11111l11(self):
        l11l1ll11 = []
        l1ll1111l = self.l1l11l11l.l1l111l11
        for l11l1l111 in self._11l1l1l1:
            if not l11l1l111 in [l11l1ll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l11l1ll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11l1ll11.append(l11l1l111)
        for l1l1l11ll in self.l1l11l11l.l1ll111l1:
            if l1l1l11ll in l11l1ll11 and not l1ll1111l:
                l11lll1ll = l11l1ll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lll1lll(l11lll1ll)
def l11ll11l1(title, message, l1l11llll, l11l1lll1=None):
    l1l11l111 = l11l1ll1l()
    l1l11l111.l1l1l1lll(message, title, l1l11llll, l11l1lll1)
def l1l11l1ll(title, message, l1l11llll):
    l1ll1lll1 = l111l111l()
    l1ll1lll1.l11111l1l(title, message, l1l11llll)
    res = l1ll1lll1.result
    return res
def main():
    try:
        logger.info(l11l1ll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1llll)
        system.l1l1ll1ll()
        logger.info(l11l1ll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1111l11(
                l11l1ll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111l1l11 = l1ll1l1l1()
        l111l1l11.l1ll1l111(l11l1ll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l11ll1l = [item.upper() for item in l111l1l11.l1ll111l1]
        l11l111l1 = l11l1ll (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l11ll1l
        if l11l111l1:
            logger.info(l11l1ll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l11lll1l1 = l111l1l11.l1ll11l11
            for l1ll1 in l11lll1l1:
                logger.debug(l11l1ll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1ll1))
                opener = l1l1ll1(l111l1l11.l1111llll, l1ll1, l1llll1=None, l1lll11=l1l1llll)
                opener.open()
                logger.info(l11l1ll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11ll1l11 = l1ll1l11l(l111l1l11)
            l11l11l1l = l11ll1l11.run()
            l11lll1l1 = l111l1l11.l1ll11l11
            for l1ll1 in l11lll1l1:
                logger.info(l11l1ll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1ll1))
                opener = l1l1ll1(l111l1l11.l1111llll, l1ll1, l1llll1=l11ll1l11.l1l1l1l1l,
                                l1lll11=l1l1llll)
                opener.open()
                logger.info(l11l1ll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11ll1l as e:
        title = l11l1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11lll1l
        logger.exception(l11l1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11lll111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11lll111 = el
        l1ll11ll1 = l11l1ll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11ll11, message.strip())
        l11ll11l1(title, l1ll11ll1, l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l11l1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l11l1lll1=l11lll111)
        sys.exit(2)
    except l1lllllll as e:
        title = l11l1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11lll1l
        logger.exception(l11l1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11lll111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11lll111 = el
        l1ll11ll1 = l11l1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l11ll11l1(title, l1ll11ll1, l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l11l1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l11l1lll1=l11lll111)
        sys.exit(2)
    except l1111l11 as e:
        title = l11l1ll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11lll1l
        logger.exception(l11l1ll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l11ll11l1(title, str(e), l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l11l1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l11l1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11lll1l
        logger.exception(l11l1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l11ll11l1(title, l11l1ll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l11l1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lll1lll as e:
        title = l11l1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11lll1l
        logger.exception(l11l1ll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l11ll11l1(title, l11l1ll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l11l1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lllll1l as e:
        title = l11l1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11lll1l
        logger.exception(l11l1ll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l11ll11l1(title, l11l1ll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l11l1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1l1lll:
        logger.info(l11l1ll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l11l1ll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11lll1l
        logger.exception(l11l1ll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l11ll11l1(title, l11l1ll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1l11llll=l1l1llll.get_value(l11l1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l11l1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l11l1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()