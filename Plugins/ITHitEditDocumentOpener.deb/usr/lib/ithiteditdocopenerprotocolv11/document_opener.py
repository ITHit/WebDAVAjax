#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11ll = sys.version_info [0] == 2
l111ll1 = 2048
l1l1l = 7
def l1l1 (l111ll):
    global l1lllll
    l1ll1l1l = ord (l111ll [-1])
    l11llll = l111ll [:-1]
    l1111 = l1ll1l1l % len (l11llll)
    l1llllll = l11llll [:l1111] + l11llll [l1111:]
    if l1ll11ll:
        l1ll1l11 = l11l1l1 () .join ([unichr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    else:
        l1ll1l11 = str () .join ([chr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    return eval (l1ll1l11)
import sys, json
import os
import urllib
import l1l1ll
from l1l11l import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1llll import l1l1l111, logger, l1l1111l
from cookies import l111llll as l111lll11
from l1llll import l1lll1ll
l11l1l1l1 = None
from l111l import *
class l111llll1():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l1 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l111l111l):
        self.config = l111l111l
        self.l1111ll1l = l1l1ll.l111lll()
    def l11ll1ll1(self):
        data = platform.uname()
        logger.info(l1l1 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1l1 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1l1 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1l1 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l111l1111():
    def __init__(self, encode = True):
        self._encode = encode
        self._111ll11l = [l1l1 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1lll1111 = None
        self.l1ll1l1ll = None
        self.l1ll1lll1 = None
        self.l11ll11ll = None
        self.l1l11l1 = None
        self.l11111l1l = None
        self.l1l11l1ll = None
        self.l11111lll = None
        self.cookies = None
    def l1l1l1ll1(self, url):
        l1l1 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1l1 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l1llll1(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1ll1ll1l(url)
        self.dict = self._11111111(params)
        logger.info(l1l1 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1111llll(self.dict):
            raise l11111l1(l1l1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._111ll11l)
        self._1111ll11(self.dict)
        if self._encode:
            self.l11l11lll()
        self._1lll111l()
        self._111ll1ll()
        self._11l1l111()
        self._1ll1llll()
        self.l1l1lll11()
        logger.info(l1l1 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1l1 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1lll1111))
        logger.info(l1l1 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1ll1l1ll))
        logger.info(l1l1 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1ll1lll1))
        logger.info(l1l1 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l11ll11ll))
        logger.info(l1l1 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1l11l1))
        logger.info(l1l1 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11111l1l))
        logger.info(l1l1 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l11l1ll))
        logger.info(l1l1 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l11111lll))
    def _1111ll11(self, l1l11111l):
        self.l1lll1111 = l1l11111l.get(l1l1 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1ll1l1ll = l1l11111l.get(l1l1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1l1 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1ll1lll1 = l1l11111l.get(l1l1 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l11ll11ll = l1l11111l.get(l1l1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1l11l1 = l1l11111l.get(l1l1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11111l1l = l1l11111l.get(l1l1 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l11l1ll = l1l11111l.get(l1l1 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1l1 (u"ࠣࠤ࣏"))
        self.l11111lll = l1l11111l.get(l1l1 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1l1 (u"࣑ࠥࠦ"))
        self.cookies = l1l11111l.get(l1l1 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l1lll11(self):
        l1111111l = False
        if self.l1l11l1:
            if self.l1l11l1.upper() == l1l1 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1l11l1 = l1l1 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1l11l1.upper() == l1l1 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1l11l1 = l1l1 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1l11l1.upper() == l1l1 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1l11l1 = l1l1 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1l11l1.upper() == l1l1 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1l11l1 = l1l1 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1l11l1 == l1l1 (u"ࠨࠢࣛ"):
                l1111111l = True
            else:
                self.l1l11l1 = self.l1l11l1.lower()
        else:
            l1111111l = True
        if l1111111l:
            self.l1l11l1 = l1l1 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l11l11lll(self):
        l1l1 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l1 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l1l1111 = []
                    for el in self.__dict__.get(key):
                        l1l1l1111.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l1l1111
    def l11ll1lll(self, l111l1lll):
        res = l111l1lll
        if self._encode:
            res = urllib.parse.quote(l111l1lll, safe=l1l1 (u"ࠥࠦࣟ"))
        return res
    def _1l1llll1(self, url):
        l1l1 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1l1 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1l1 (u"ࠨ࠺ࠣ࣢")), l1l1 (u"ࠧࠨࣣ"), url)
        return url
    def _1ll1ll1l(self, url):
        l1l1 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11l1l1ll = url.split(l1l1 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1l1 (u"ࠥ࠿ࣦࠧ")))
        result = l11l1l1ll
        if len(result) == 0:
            raise l1lll1lll(l1l1 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11111111(self, params):
        l1l1 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1l1 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1l1 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11l1111l = data.group(l1l1 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11l1111l in (l1l1 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1l1 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1l1 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1l1 (u"ࠧ࠲࣯ࠢ"))
                elif l11l1111l == l1l1 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1l1 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l1 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11l1111l] = value
        return result
    def _1l1lllll(self, url, scheme):
        l1l1 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l11llll11 = {l1l1 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1l1 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l111lll1l = url.split(l1l1 (u"ࠧࡀࣶࠢ"))
        if len(l111lll1l) == 1:
            for l11ll11l1 in list(l11llll11.keys()):
                if l11ll11l1 == scheme:
                    url += l1l1 (u"ࠨ࠺ࠣࣷ") + str(l11llll11[l11ll11l1])
                    break
        return url
    def _1lll111l(self):
        l1l1 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l11ll11ll:
            l111l11l1 = self.l11ll11ll[0]
            l1ll1ll11 = urlparse(l111l11l1)
        if self.l1lll1111:
            l111l1l11 = urlparse(self.l1lll1111)
            if l111l1l11.scheme:
                l111ll1l1 = l111l1l11.scheme
            else:
                if l1ll1ll11.scheme:
                    l111ll1l1 = l1ll1ll11.scheme
                else:
                    raise l1lllll11(
                        l1l1 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l111l1l11.netloc:
                l1l1l1l1l = l111l1l11.netloc
            else:
                if l1ll1ll11.netloc:
                    l1l1l1l1l = l1ll1ll11.netloc
                else:
                    raise l1lllll11(
                        l1l1 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l1l1l1l = self._1l1lllll(l1l1l1l1l, l111ll1l1)
            path = l111l1l11.path
            if not path.endswith(l1l1 (u"ࠪ࠳ࠬࣻ")):
                path += l1l1 (u"ࠫ࠴࠭ࣼ")
            l11l11l11 = ParseResult(scheme=l111ll1l1, netloc=l1l1l1l1l, path=path,
                                         params=l111l1l11.params, query=l111l1l11.query,
                                         fragment=l111l1l11.fragment)
            self.l1lll1111 = l11l11l11.geturl()
        else:
            if not l1ll1ll11.netloc:
                raise l1lllll11(l1l1 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l111l1l = l1ll1ll11.path
            l1l1l1lll = l1l1 (u"ࠨ࠯ࠣࣾ").join(l1l111l1l.split(l1l1 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1l1 (u"ࠣ࠱ࠥऀ")
            l11l11l11 = ParseResult(scheme=l1ll1ll11.scheme,
                                         netloc=self._1l1lllll(l1ll1ll11.netloc, l1ll1ll11.scheme),
                                         path=l1l1l1lll,
                                         params=l1l1 (u"ࠤࠥँ"),
                                         query=l1l1 (u"ࠥࠦं"),
                                         fragment=l1l1 (u"ࠦࠧः")
                                         )
            self.l1lll1111 = l11l11l11.geturl()
    def _11l1l111(self):
        l1l1 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l11ll11ll:
            l111l11l1 = self.l11ll11ll[0]
            l1ll1ll11 = urlparse(l111l11l1)
        if self.l11111l1l:
            l11l111ll = urlparse(self.l11111l1l)
            if l11l111ll.scheme:
                l11lll111 = l11l111ll.scheme
            else:
                l11lll111 = l1ll1ll11.scheme
            if l11l111ll.netloc:
                l1l111l11 = l11l111ll.netloc
            else:
                l1l111l11 = l1ll1ll11.netloc
            l1l1ll1l1 = ParseResult(scheme=l11lll111, netloc=l1l111l11, path=l11l111ll.path,
                                      params=l11l111ll.params, query=l11l111ll.query,
                                      fragment=l11l111ll.fragment)
            self.l11111l1l = l1l1ll1l1.geturl()
    def _111ll1ll(self):
        l1l1 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l11ll11ll
        self.l11ll11ll = []
        for item in items:
            l1llllllll = urlparse(item.strip(), scheme=l1l1 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1llllllll.path[-1] == l1l1 (u"ࠣ࠱ࠥइ"):
                l1l1111ll = l1llllllll.path
            else:
                path_list = l1llllllll.path.split(l1l1 (u"ࠤ࠲ࠦई"))
                l1l1111ll = l1l1 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1l1 (u"ࠦ࠴ࠨऊ")
            l1l11ll1l = urlparse(self.l1lll1111, scheme=l1l1 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1llllllll.scheme:
                scheme = l1llllllll.scheme
            elif l1l11ll1l.scheme:
                scheme = l1l11ll1l.scheme
            else:
                scheme = l1l1 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1llllllll.netloc and not l1l11ll1l.netloc:
                l1ll11ll1 = l1llllllll.netloc
            elif not l1llllllll.netloc and l1l11ll1l.netloc:
                l1ll11ll1 = l1l11ll1l.netloc
            elif not l1llllllll.netloc and not l1l11ll1l.netloc and len(self.l11ll11ll) > 0:
                l11l1lll1 = urlparse(self.l11ll11ll[len(self.l11ll11ll) - 1])
                l1ll11ll1 = l11l1lll1.netloc
            elif l1l11ll1l.netloc:
                l1ll11ll1 = l1llllllll.netloc
            elif not l1l11ll1l.netloc:
                l1ll11ll1 = l1llllllll.netloc
            if l1llllllll.path:
                l11l1llll = l1llllllll.path
            if l1ll11ll1:
                l1ll11ll1 = self._1l1lllll(l1ll11ll1, scheme)
                l11ll1l1l = ParseResult(scheme=scheme, netloc=l1ll11ll1, path=l11l1llll,
                                          params=l1llllllll.params,
                                          query=l1llllllll.query,
                                          fragment=l1llllllll.fragment)
                self.l11ll11ll.append(l11ll1l1l.geturl())
    def _1ll1llll(self):
        l1l1 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l111l11ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll1l(l1l1 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l111l11ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll1l(l1l1 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1ll1lll1:
            l11lll1ll = []
            for l111111ll in self.l1ll1lll1:
                if l111111ll not in [x[l1l1 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l11lll1ll.append(l111111ll)
            if l11lll1ll:
                l1l111l1 = l1l1 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1l1 (u"ࠧ࠲ࠠࠣऒ").join(l11lll1ll))
                raise l111ll1l(l1l1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l111l1)
    def l1111llll(self, params):
        l1l1 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1l11l11l = True
        for param in self._111ll11l:
            if not params.get(param.lower()):
                l1l11l11l = False
        return l1l11l11l
class l11l1l11l():
    def __init__(self, l1lll11l1):
        self.l11l11111 = l1l1ll.l111lll()
        self.l1l1111l1 = self.l11llll1l()
        self.l11l1ll11 = self.l1ll111ll()
        self.l1lll11l1 = l1lll11l1
        self._1111l1l1 = [l1l1 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1l1 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1l1 (u"ࠥࡅࡱࡲࠢग"), l1l1 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1l1 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1l1 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1l1 (u"ࠢࡊࡇࠥछ"), l1l1 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1ll11l1l = [l1l1 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1l1 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1l1 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1l1 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1ll11l11 = None
    def l11llll1l(self):
        l111lllll = l1l1 (u"ࠨࡎࡰࡰࡨࠦड")
        return l111lllll
    def l1ll111ll(self):
        l1l1l11l1 = 0
        return l1l1l11l1
    def l111l1l1l(self):
        l1l111l1 = l1l1 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11l1ll11)
        l1l111l1 += l1l1 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l11llll(l1l1l111, l1l111l1, t=1)
        return res
    def run(self):
        l1l1l1l11 = True
        self._1l1l11ll()
        result = []
        try:
            for cookie in l111lll11(l111ll11=self.l1lll11l1.cookies).run():
                result.append(cookie)
        except l1llll111 as e:
            logger.exception(l1l1 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11ll1l11 = self._11llllll(result)
            if l11ll1l11:
                logger.info(l1l1 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11ll1l11)
                self.l1ll11l11 = l11ll1l11
            else:
                logger.info(l1l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11ll1l11)
            l1l1l1l11 = True
        else:
            l1l1l1l11 = False
        return l1l1l1l11
    def _11llllll(self, l11lll1l1):
        res = False
        l1l1lll = os.path.join(os.environ[l1l1 (u"ࠬࡎࡏࡎࡇࠪध")], l1l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1l1 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1ll11111 = {}
        for cookies in l11lll1l1:
            l1ll11111[cookies.name] = cookies.value
        l1111l111 = l1l1 (u"ࠣࠤप")
        for key in list(l1ll11111.keys()):
            l1111l111 += l1l1 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1ll11111[key].strip())
        if not os.path.exists(os.path.dirname(l1l1lll)):
            os.makedirs(os.path.dirname(l1l1lll))
        vers = int(l1l1 (u"ࠥࠦब").join(self.l11l11111.split(l1l1 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1ll11lll = [l1l1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1l1 (u"ࠨࠣࠡࠤय") + l1l1 (u"ࠢ࠮ࠤर") * 60,
                              l1l1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1l1 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1l1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1111l111),
                              l1l1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1ll11lll = [l1l1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1l1 (u"ࠨࠣࠡࠤश") + l1l1 (u"ࠢ࠮ࠤष") * 60,
                              l1l1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1l1 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1l1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1111l111),
                              l1l1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1l1lll, l1l1 (u"ࠧࡽ़ࠢ")) as l111111l1:
            data = l1l1 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1ll11lll)
            l111111l1.write(data)
            l111111l1.write(l1l1 (u"ࠢ࡝ࡰࠥा"))
        res = l1l1lll
        return res
    def _1l1l11ll(self):
        self._1l111lll(l1l1 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11l11ll1()
    def _1l111lll(self, l11l11l1l):
        l1l11l1l1 = self.l1lll11l1.dict[l11l11l1l.lower()]
        if l1l11l1l1:
            if isinstance(l1l11l1l1, list):
                l11ll111l = l1l11l1l1
            else:
                l11ll111l = [l1l11l1l1]
            if l1l1 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11l11l1l.lower():
                    for l1ll1l11l in l11ll111l:
                        l111ll111 = [l1ll1111l.upper() for l1ll1111l in self._1111l1l1]
                        if not l1ll1l11l.upper() in l111ll111:
                            l1ll1l1l1 = l1l1 (u"ࠥ࠰ࠥࠨु").join(self._1111l1l1)
                            l1l1ll111 = l1l1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11l11l1l, l1l11l1l1, l1ll1l1l1, )
                            raise l1lll11ll(l1l1ll111)
    def _11l11ll1(self):
        l1111l1ll = []
        l1l1lll1l = self.l1lll11l1.l1ll1lll1
        for l1l111111 in self._1111l1l1:
            if not l1l111111 in [l1l1 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1l1 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1111l1ll.append(l1l111111)
        for l11lllll1 in self.l1lll11l1.l1ll1l1ll:
            if l11lllll1 in l1111l1ll and not l1l1lll1l:
                l1l1ll111 = l1l1 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lll11ll(l1l1ll111)
def l1l11l111(title, message, l1ll111l1, l1111l11l=None):
    l11l1ll1l = l11ll1111()
    l11l1ll1l.l1l111ll1(message, title, l1ll111l1, l1111l11l)
def l11l111l1(title, message, l1ll111l1):
    l1l11lll1 = l11lll11l()
    l1l11lll1.l1ll1l111(title, message, l1ll111l1)
    res = l1l11lll1.result
    return res
def main():
    try:
        logger.info(l1l1 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1111l)
        system.l11ll1ll1()
        logger.info(l1l1 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l11111l1(
                l1l1 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1l1ll1ll = l111l1111()
        l1l1ll1ll.l1l1l1ll1(l1l1 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l1ll11l = [item.upper() for item in l1l1ll1ll.l1ll1l1ll]
        l111l1ll1 = l1l1 (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l1ll11l
        if l111l1ll1:
            logger.info(l1l1 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1l11ll11 = l1l1ll1ll.l11ll11ll
            for l11 in l1l11ll11:
                logger.debug(l1l1 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l11))
                opener = l1lll1ll(l1l1ll1ll.l1lll1111, l11, l1l1lll=None, l1l=l1l1111l)
                opener.open()
                logger.info(l1l1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l1111lll1 = l11l1l11l(l1l1ll1ll)
            l11111l11 = l1111lll1.run()
            l1l11ll11 = l1l1ll1ll.l11ll11ll
            for l11 in l1l11ll11:
                logger.info(l1l1 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l11))
                opener = l1lll1ll(l1l1ll1ll.l1lll1111, l11, l1l1lll=l1111lll1.l1ll11l11,
                                l1l=l1l1111l)
                opener.open()
                logger.info(l1l1 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1l11 as e:
        title = l1l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1l111
        logger.exception(l1l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11111ll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11111ll1 = el
        l1l1l111l = l1l1 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1ll1lll, message.strip())
        l1l11l111(title, l1l1l111l, l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1111l11l=l11111ll1)
        sys.exit(2)
    except l1llll1ll as e:
        title = l1l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1l111
        logger.exception(l1l1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11111ll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11111ll1 = el
        l1l1l111l = l1l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1l11l111(title, l1l1l111l, l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1111l11l=l11111ll1)
        sys.exit(2)
    except l11111l1 as e:
        title = l1l1 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1l111
        logger.exception(l1l1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1l11l111(title, str(e), l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1l1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1l111
        logger.exception(l1l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1l11l111(title, l1l1 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lll11ll as e:
        title = l1l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1l111
        logger.exception(l1l1 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1l11l111(title, l1l1 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1llll1l1 as e:
        title = l1l1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1l111
        logger.exception(l1l1 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1l11l111(title, l1l1 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1l1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except ll:
        logger.info(l1l1 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1l1 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1l111
        logger.exception(l1l1 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1l11l111(title, l1l1 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1ll111l1=l1l1111l.get_value(l1l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1l1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()