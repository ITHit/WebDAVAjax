#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1111 = 7
def l1lll1ll (l1llll):
    global l1ll111l
    l1l1lll = ord (l1llll [-1])
    l11l1l = l1llll [:-1]
    l1ll1l1l = l1l1lll % len (l11l1l)
    l1l111l = l11l1l [:l1ll1l1l] + l11l1l [l1ll1l1l:]
    if l1ll1lll:
        l11ll11 = l1111 () .join ([unichr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    return eval (l11ll11)
import sys, json
import os
import urllib
import ll
from l1111ll import *
import platform
from urllib.parse import urlparse, ParseResult
from l11ll111 import l1l11111, logger, l1l11l1l
from cookies import l111ll1l as l1l11l1l1
from l1l11l1 import l1lllll1
l11l1111l = None
from l11111l import *
class l1111l111():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1lll1ll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1l1111):
        self.config = l1l1l1111
        self.l1ll11111 = ll.l1l111()
    def l111ll11l(self):
        data = platform.uname()
        logger.info(l1lll1ll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1lll1ll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1lll1ll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1lll1ll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1lll1111():
    def __init__(self, encode = True):
        self._encode = encode
        self._11111ll1 = [l1lll1ll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1111ll1l = None
        self.l1l11l11l = None
        self.l1ll1lll1 = None
        self.l111l11ll = None
        self.l1l1ll = None
        self.l1l1l11ll = None
        self.l1l1ll1ll = None
        self.l1l1llll1 = None
        self.cookies = None
    def l1l111lll(self, url):
        l1lll1ll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1lll1ll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11llll1l(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111llll1(url)
        self.dict = self._11l11l11(params)
        logger.info(l1lll1ll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1l11l111(self.dict):
            raise l1lllll1l(l1lll1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._11111ll1)
        self._1l1111ll(self.dict)
        if self._encode:
            self.l1l11111l()
        self._11lll111()
        self._11ll1111()
        self._1l1lllll()
        self._1111111l()
        self.l1l111l1l()
        logger.info(l1lll1ll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1lll1ll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1111ll1l))
        logger.info(l1lll1ll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1l11l11l))
        logger.info(l1lll1ll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1ll1lll1))
        logger.info(l1lll1ll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l111l11ll))
        logger.info(l1lll1ll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1l1ll))
        logger.info(l1lll1ll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1l1l11ll))
        logger.info(l1lll1ll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l1ll1ll))
        logger.info(l1lll1ll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1l1llll1))
    def _1l1111ll(self, l1l1l111l):
        self.l1111ll1l = l1l1l111l.get(l1lll1ll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1l11l11l = l1l1l111l.get(l1lll1ll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1lll1ll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1ll1lll1 = l1l1l111l.get(l1lll1ll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l111l11ll = l1l1l111l.get(l1lll1ll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1l1ll = l1l1l111l.get(l1lll1ll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1l1l11ll = l1l1l111l.get(l1lll1ll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l1ll1ll = l1l1l111l.get(l1lll1ll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1lll1ll (u"ࠣࠤ࣏"))
        self.l1l1llll1 = l1l1l111l.get(l1lll1ll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1lll1ll (u"࣑ࠥࠦ"))
        self.cookies = l1l1l111l.get(l1lll1ll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l111l1l(self):
        l1l1l1l11 = False
        if self.l1l1ll:
            if self.l1l1ll.upper() == l1lll1ll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1l1ll = l1lll1ll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1l1ll.upper() == l1lll1ll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1l1ll = l1lll1ll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1l1ll.upper() == l1lll1ll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1l1ll = l1lll1ll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1l1ll.upper() == l1lll1ll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1l1ll = l1lll1ll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1l1ll == l1lll1ll (u"ࠨࠢࣛ"):
                l1l1l1l11 = True
            else:
                self.l1l1ll = self.l1l1ll.lower()
        else:
            l1l1l1l11 = True
        if l1l1l1l11:
            self.l1l1ll = l1lll1ll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1l11111l(self):
        l1lll1ll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1lll1ll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11l11lll = []
                    for el in self.__dict__.get(key):
                        l11l11lll.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11l11lll
    def l11l1l1ll(self, l1l1l1l1l):
        res = l1l1l1l1l
        if self._encode:
            res = urllib.parse.quote(l1l1l1l1l, safe=l1lll1ll (u"ࠥࠦࣟ"))
        return res
    def _11llll1l(self, url):
        l1lll1ll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1lll1ll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1lll1ll (u"ࠨ࠺ࠣ࣢")), l1lll1ll (u"ࠧࠨࣣ"), url)
        return url
    def _111llll1(self, url):
        l1lll1ll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1111l11l = url.split(l1lll1ll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1lll1ll (u"ࠥ࠿ࣦࠧ")))
        result = l1111l11l
        if len(result) == 0:
            raise l111111l(l1lll1ll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11l11l11(self, params):
        l1lll1ll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1lll1ll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1lll1ll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l11ll11 = data.group(l1lll1ll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l11ll11 in (l1lll1ll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1lll1ll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1lll1ll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1lll1ll (u"ࠧ࠲࣯ࠢ"))
                elif l1l11ll11 == l1lll1ll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1lll1ll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1lll1ll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l11ll11] = value
        return result
    def _1ll11l1l(self, url, scheme):
        l1lll1ll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l11l11111 = {l1lll1ll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1lll1ll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l111l1l1l = url.split(l1lll1ll (u"ࠧࡀࣶࠢ"))
        if len(l111l1l1l) == 1:
            for l111ll1ll in list(l11l11111.keys()):
                if l111ll1ll == scheme:
                    url += l1lll1ll (u"ࠨ࠺ࠣࣷ") + str(l11l11111[l111ll1ll])
                    break
        return url
    def _11lll111(self):
        l1lll1ll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l111l11ll:
            l11111111 = self.l111l11ll[0]
            l11l11ll1 = urlparse(l11111111)
        if self.l1111ll1l:
            l1l1ll1l1 = urlparse(self.l1111ll1l)
            if l1l1ll1l1.scheme:
                l1l1ll111 = l1l1ll1l1.scheme
            else:
                if l11l11ll1.scheme:
                    l1l1ll111 = l11l11ll1.scheme
                else:
                    raise l1lllll11(
                        l1lll1ll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1ll1l1.netloc:
                l1l11llll = l1l1ll1l1.netloc
            else:
                if l11l11ll1.netloc:
                    l1l11llll = l11l11ll1.netloc
                else:
                    raise l1lllll11(
                        l1lll1ll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l11llll = self._1ll11l1l(l1l11llll, l1l1ll111)
            path = l1l1ll1l1.path
            if not path.endswith(l1lll1ll (u"ࠪ࠳ࠬࣻ")):
                path += l1lll1ll (u"ࠫ࠴࠭ࣼ")
            l11l111ll = ParseResult(scheme=l1l1ll111, netloc=l1l11llll, path=path,
                                         params=l1l1ll1l1.params, query=l1l1ll1l1.query,
                                         fragment=l1l1ll1l1.fragment)
            self.l1111ll1l = l11l111ll.geturl()
        else:
            if not l11l11ll1.netloc:
                raise l1lllll11(l1lll1ll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1ll1111l = l11l11ll1.path
            l11llllll = l1lll1ll (u"ࠨ࠯ࠣࣾ").join(l1ll1111l.split(l1lll1ll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1lll1ll (u"ࠣ࠱ࠥऀ")
            l11l111ll = ParseResult(scheme=l11l11ll1.scheme,
                                         netloc=self._1ll11l1l(l11l11ll1.netloc, l11l11ll1.scheme),
                                         path=l11llllll,
                                         params=l1lll1ll (u"ࠤࠥँ"),
                                         query=l1lll1ll (u"ࠥࠦं"),
                                         fragment=l1lll1ll (u"ࠦࠧः")
                                         )
            self.l1111ll1l = l11l111ll.geturl()
    def _1l1lllll(self):
        l1lll1ll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l111l11ll:
            l11111111 = self.l111l11ll[0]
            l11l11ll1 = urlparse(l11111111)
        if self.l1l1l11ll:
            l11lll1l1 = urlparse(self.l1l1l11ll)
            if l11lll1l1.scheme:
                l111ll111 = l11lll1l1.scheme
            else:
                l111ll111 = l11l11ll1.scheme
            if l11lll1l1.netloc:
                l1ll1l1l1 = l11lll1l1.netloc
            else:
                l1ll1l1l1 = l11l11ll1.netloc
            l1ll1l1ll = ParseResult(scheme=l111ll111, netloc=l1ll1l1l1, path=l11lll1l1.path,
                                      params=l11lll1l1.params, query=l11lll1l1.query,
                                      fragment=l11lll1l1.fragment)
            self.l1l1l11ll = l1ll1l1ll.geturl()
    def _11ll1111(self):
        l1lll1ll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l111l11ll
        self.l111l11ll = []
        for item in items:
            l11lllll1 = urlparse(item.strip(), scheme=l1lll1ll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11lllll1.path[-1] == l1lll1ll (u"ࠣ࠱ࠥइ"):
                l11lll1ll = l11lllll1.path
            else:
                path_list = l11lllll1.path.split(l1lll1ll (u"ࠤ࠲ࠦई"))
                l11lll1ll = l1lll1ll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1lll1ll (u"ࠦ࠴ࠨऊ")
            l1l1l1lll = urlparse(self.l1111ll1l, scheme=l1lll1ll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11lllll1.scheme:
                scheme = l11lllll1.scheme
            elif l1l1l1lll.scheme:
                scheme = l1l1l1lll.scheme
            else:
                scheme = l1lll1ll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11lllll1.netloc and not l1l1l1lll.netloc:
                l11111l1l = l11lllll1.netloc
            elif not l11lllll1.netloc and l1l1l1lll.netloc:
                l11111l1l = l1l1l1lll.netloc
            elif not l11lllll1.netloc and not l1l1l1lll.netloc and len(self.l111l11ll) > 0:
                l11111lll = urlparse(self.l111l11ll[len(self.l111l11ll) - 1])
                l11111l1l = l11111lll.netloc
            elif l1l1l1lll.netloc:
                l11111l1l = l11lllll1.netloc
            elif not l1l1l1lll.netloc:
                l11111l1l = l11lllll1.netloc
            if l11lllll1.path:
                l11ll11l1 = l11lllll1.path
            if l11111l1l:
                l11111l1l = self._1ll11l1l(l11111l1l, scheme)
                l1l1l11l1 = ParseResult(scheme=scheme, netloc=l11111l1l, path=l11ll11l1,
                                          params=l11lllll1.params,
                                          query=l11lllll1.query,
                                          fragment=l11lllll1.fragment)
                self.l111l11ll.append(l1l1l11l1.geturl())
    def _1111111l(self):
        l1lll1ll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1lll11l1 = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1111(l1lll1ll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1lll11l1)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1111(l1lll1ll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1ll1lll1:
            l11ll1ll1 = []
            for l1l1l1ll1 in self.l1ll1lll1:
                if l1l1l1ll1 not in [x[l1lll1ll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l11ll1ll1.append(l1l1l1ll1)
            if l11ll1ll1:
                l1l11ll1 = l1lll1ll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1lll1ll (u"ࠧ࠲ࠠࠣऒ").join(l11ll1ll1))
                raise l11l1111(l1lll1ll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l11ll1)
    def l1l11l111(self, params):
        l1lll1ll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l111lll1l = True
        for param in self._11111ll1:
            if not params.get(param.lower()):
                l111lll1l = False
        return l111lll1l
class l1lll111l():
    def __init__(self, l111lllll):
        self.l111l11l1 = ll.l1l111()
        self.l1l111l11 = self.l111l1l11()
        self.l11l1llll = self.l111l1111()
        self.l111lllll = l111lllll
        self._1l111111 = [l1lll1ll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1lll1ll (u"ࠤࡑࡳࡳ࡫ࠢख"), l1lll1ll (u"ࠥࡅࡱࡲࠢग"), l1lll1ll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1lll1ll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1lll1ll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1lll1ll (u"ࠢࡊࡇࠥछ"), l1lll1ll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._111111l1 = [l1lll1ll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1lll1ll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1lll1ll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1lll1ll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11l1l11l = None
    def l111l1l11(self):
        l111111ll = l1lll1ll (u"ࠨࡎࡰࡰࡨࠦड")
        return l111111ll
    def l111l1111(self):
        l1111l1ll = 0
        return l1111l1ll
    def l1ll111ll(self):
        l1l11ll1 = l1lll1ll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11l1llll)
        l1l11ll1 += l1lll1ll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l11l1ll(l1l11111, l1l11ll1, t=1)
        return res
    def run(self):
        l1llllllll = True
        self._11l11l1l()
        result = []
        try:
            for cookie in l1l11l1l1(l1111lll=self.l111lllll.cookies).run():
                result.append(cookie)
        except l1llll1l1 as e:
            logger.exception(l1lll1ll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1l1ll11l = self._1111l1l1(result)
            if l1l1ll11l:
                logger.info(l1lll1ll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1l1ll11l)
                self.l11l1l11l = l1l1ll11l
            else:
                logger.info(l1lll1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1l1ll11l)
            l1llllllll = True
        else:
            l1llllllll = False
        return l1llllllll
    def _1111l1l1(self, l1l1lll1l):
        res = False
        l1llll11 = os.path.join(os.environ[l1lll1ll (u"ࠬࡎࡏࡎࡇࠪध")], l1lll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1lll1ll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1ll1ll11 = {}
        for cookies in l1l1lll1l:
            l1ll1ll11[cookies.name] = cookies.value
        l1l111ll1 = l1lll1ll (u"ࠣࠤप")
        for key in list(l1ll1ll11.keys()):
            l1l111ll1 += l1lll1ll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1ll1ll11[key].strip())
        if not os.path.exists(os.path.dirname(l1llll11)):
            os.makedirs(os.path.dirname(l1llll11))
        vers = int(l1lll1ll (u"ࠥࠦब").join(self.l111l11l1.split(l1lll1ll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11l1l1l1 = [l1lll1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1lll1ll (u"ࠨࠣࠡࠤय") + l1lll1ll (u"ࠢ࠮ࠤर") * 60,
                              l1lll1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1lll1ll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1lll1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l111ll1),
                              l1lll1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11l1l1l1 = [l1lll1ll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1lll1ll (u"ࠨࠣࠡࠤश") + l1lll1ll (u"ࠢ࠮ࠤष") * 60,
                              l1lll1ll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1lll1ll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1lll1ll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l111ll1),
                              l1lll1ll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1llll11, l1lll1ll (u"ࠧࡽ़ࠢ")) as l11l1ll11:
            data = l1lll1ll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11l1l1l1)
            l11l1ll11.write(data)
            l11l1ll11.write(l1lll1ll (u"ࠢ࡝ࡰࠥा"))
        res = l1llll11
        return res
    def _11l11l1l(self):
        self._1ll11ll1(l1lll1ll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11l1ll1l()
    def _1ll11ll1(self, l1l1lll11):
        l11l1l111 = self.l111lllll.dict[l1l1lll11.lower()]
        if l11l1l111:
            if isinstance(l11l1l111, list):
                l1ll1l11l = l11l1l111
            else:
                l1ll1l11l = [l11l1l111]
            if l1lll1ll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1l1lll11.lower():
                    for l11111l11 in l1ll1l11l:
                        l11ll11ll = [l111l1ll1.upper() for l111l1ll1 in self._1l111111]
                        if not l11111l11.upper() in l11ll11ll:
                            l111l111l = l1lll1ll (u"ࠥ࠰ࠥࠨु").join(self._1l111111)
                            l1l1111l1 = l1lll1ll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1l1lll11, l11l1l111, l111l111l, )
                            raise l1111111(l1l1111l1)
    def _11l1ll1l(self):
        l1l11ll1l = []
        l1111ll11 = self.l111lllll.l1ll1lll1
        for l1ll1l111 in self._1l111111:
            if not l1ll1l111 in [l1lll1ll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1lll1ll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1l11ll1l.append(l1ll1l111)
        for l1ll1llll in self.l111lllll.l1l11l11l:
            if l1ll1llll in l1l11ll1l and not l1111ll11:
                l1l1111l1 = l1lll1ll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1111111(l1l1111l1)
def l111ll1l1(title, message, l111l1lll, l1ll11lll=None):
    l1111lll1 = l11ll1l1l()
    l1111lll1.l1ll11l11(message, title, l111l1lll, l1ll11lll)
def l11ll111l(title, message, l111l1lll):
    l11ll1lll = l11l1lll1()
    l11ll1lll.l11lll11l(title, message, l111l1lll)
    res = l11ll1lll.result
    return res
def main():
    try:
        logger.info(l1lll1ll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l11l1l)
        system.l111ll11l()
        logger.info(l1lll1ll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1lllll1l(
                l1lll1ll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l11l111l1 = l1lll1111()
        l11l111l1.l1l111lll(l1lll1ll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11llll11 = [item.upper() for item in l11l111l1.l1l11l11l]
        l111lll11 = l1lll1ll (u"ࠧࡔࡏࡏࡇࠥॊ") in l11llll11
        if l111lll11:
            logger.info(l1lll1ll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1l11lll1 = l11l111l1.l111l11ll
            for l1l1ll1 in l1l11lll1:
                logger.debug(l1lll1ll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1l1ll1))
                opener = l1lllll1(l11l111l1.l1111ll1l, l1l1ll1, l1llll11=None, l1lll111=l1l11l1l)
                opener.open()
                logger.info(l1lll1ll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l1ll111l1 = l1lll111l(l11l111l1)
            l1ll1ll1l = l1ll111l1.run()
            l1l11lll1 = l11l111l1.l111l11ll
            for l1l1ll1 in l1l11lll1:
                logger.info(l1lll1ll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1l1ll1))
                opener = l1lllll1(l11l111l1.l1111ll1l, l1l1ll1, l1llll11=l1ll111l1.l11l1l11l,
                                l1lll111=l1l11l1l)
                opener.open()
                logger.info(l1lll1ll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11ll as e:
        title = l1lll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l11111
        logger.exception(l1lll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11ll1l11 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll1l11 = el
        l1111llll = l1lll1ll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l111l, message.strip())
        l111ll1l1(title, l1111llll, l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1ll11lll=l11ll1l11)
        sys.exit(2)
    except l1lll1l11 as e:
        title = l1lll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l11111
        logger.exception(l1lll1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11ll1l11 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll1l11 = el
        l1111llll = l1lll1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l111ll1l1(title, l1111llll, l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1lll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1ll11lll=l11ll1l11)
        sys.exit(2)
    except l1lllll1l as e:
        title = l1lll1ll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l11111
        logger.exception(l1lll1ll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l111ll1l1(title, str(e), l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1lll1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1lll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l11111
        logger.exception(l1lll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l111ll1l1(title, l1lll1ll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1111111 as e:
        title = l1lll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l11111
        logger.exception(l1lll1ll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l111ll1l1(title, l1lll1ll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1lll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1llll1ll as e:
        title = l1lll1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l11111
        logger.exception(l1lll1ll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l111ll1l1(title, l1lll1ll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1lll1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll1l1:
        logger.info(l1lll1ll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1lll1ll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l11111
        logger.exception(l1lll1ll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l111ll1l1(title, l1lll1ll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l111l1lll=l1l11l1l.get_value(l1lll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1lll1ll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1lll1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()