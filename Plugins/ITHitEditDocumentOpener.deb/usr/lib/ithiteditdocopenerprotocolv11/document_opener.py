#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import sys, json
import os
import urllib
import l11111l
from l1ll111 import *
import platform
from urllib.parse import urlparse, ParseResult
from l11llll1 import l1l1llll, logger, l1l11ll1
from cookies import l111l11l as l1l1llll1
from l1 import l11ll
l1ll1l1ll = None
from l111l1l import *
class l1l1ll1ll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l111l (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1111l111):
        self.config = l1111l111
        self.l1111ll11 = l11111l.l1ll1ll1()
    def l1111ll1l(self):
        data = platform.uname()
        logger.info(l111l (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l111l (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l111l (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l111l (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll1l111():
    def __init__(self, encode = True):
        self._encode = encode
        self._1ll1ll1l = [l111l (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l111ll1ll = None
        self.l11lll111 = None
        self.l11ll1111 = None
        self.l1l111111 = None
        self.l1l11ll = None
        self.l11l1ll1l = None
        self.l11ll111l = None
        self.l1ll111ll = None
        self.cookies = None
    def l1ll1llll(self, url):
        l111l (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l111l (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l1l11l1(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111l11l1(url)
        self.dict = self._11llll11(params)
        logger.info(l111l (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l111l1l11(self.dict):
            raise l11111l1(l111l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1ll1ll1l)
        self._1l11111l(self.dict)
        if self._encode:
            self.l1ll11l11()
        self._1111111l()
        self._1l1l1111()
        self._1ll1lll1()
        self._11l1111l()
        self.l1111l11l()
        logger.info(l111l (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l111l (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l111ll1ll))
        logger.info(l111l (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11lll111))
        logger.info(l111l (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11ll1111))
        logger.info(l111l (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1l111111))
        logger.info(l111l (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1l11ll))
        logger.info(l111l (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11l1ll1l))
        logger.info(l111l (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l11ll111l))
        logger.info(l111l (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1ll111ll))
    def _1l11111l(self, l1ll1ll11):
        self.l111ll1ll = l1ll1ll11.get(l111l (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11lll111 = l1ll1ll11.get(l111l (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l111l (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11ll1111 = l1ll1ll11.get(l111l (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1l111111 = l1ll1ll11.get(l111l (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1l11ll = l1ll1ll11.get(l111l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11l1ll1l = l1ll1ll11.get(l111l (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l11ll111l = l1ll1ll11.get(l111l (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l111l (u"ࠣࠤ࣏"))
        self.l1ll111ll = l1ll1ll11.get(l111l (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l111l (u"࣑ࠥࠦ"))
        self.cookies = l1ll1ll11.get(l111l (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1111l11l(self):
        l111ll1l1 = False
        if self.l1l11ll:
            if self.l1l11ll.upper() == l111l (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1l11ll = l111l (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1l11ll.upper() == l111l (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1l11ll = l111l (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1l11ll.upper() == l111l (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1l11ll = l111l (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1l11ll.upper() == l111l (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1l11ll = l111l (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1l11ll == l111l (u"ࠨࠢࣛ"):
                l111ll1l1 = True
            else:
                self.l1l11ll = self.l1l11ll.lower()
        else:
            l111ll1l1 = True
        if l111ll1l1:
            self.l1l11ll = l111l (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1ll11l11(self):
        l111l (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l111l (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l1lll1l = []
                    for el in self.__dict__.get(key):
                        l1l1lll1l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l1lll1l
    def l11111111(self, l111l1111):
        res = l111l1111
        if self._encode:
            res = urllib.parse.quote(l111l1111, safe=l111l (u"ࠥࠦࣟ"))
        return res
    def _1l1l11l1(self, url):
        l111l (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l111l (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l111l (u"ࠨ࠺ࠣ࣢")), l111l (u"ࠧࠨࣣ"), url)
        return url
    def _111l11l1(self, url):
        l111l (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11l111l1 = url.split(l111l (u"ࠤࡾ࠴ࢂࠨࣥ").format(l111l (u"ࠥ࠿ࣦࠧ")))
        result = l11l111l1
        if len(result) == 0:
            raise l1lllll11(l111l (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11llll11(self, params):
        l111l (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l111l (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l111l (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11l1l111 = data.group(l111l (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11l1l111 in (l111l (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l111l (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l111l (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l111l (u"ࠧ࠲࣯ࠢ"))
                elif l11l1l111 == l111l (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l111l (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l111l (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11l1l111] = value
        return result
    def _11l11l11(self, url, scheme):
        l111l (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l111ll11l = {l111l (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l111l (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1l111l1l = url.split(l111l (u"ࠧࡀࣶࠢ"))
        if len(l1l111l1l) == 1:
            for l1111l1l1 in list(l111ll11l.keys()):
                if l1111l1l1 == scheme:
                    url += l111l (u"ࠨ࠺ࠣࣷ") + str(l111ll11l[l1111l1l1])
                    break
        return url
    def _1111111l(self):
        l111l (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1l111111:
            l111l111l = self.l1l111111[0]
            l11lll1l1 = urlparse(l111l111l)
        if self.l111ll1ll:
            l1l1lllll = urlparse(self.l111ll1ll)
            if l1l1lllll.scheme:
                l11111ll1 = l1l1lllll.scheme
            else:
                if l11lll1l1.scheme:
                    l11111ll1 = l11lll1l1.scheme
                else:
                    raise l1111l11(
                        l111l (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1lllll.netloc:
                l1111lll1 = l1l1lllll.netloc
            else:
                if l11lll1l1.netloc:
                    l1111lll1 = l11lll1l1.netloc
                else:
                    raise l1111l11(
                        l111l (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1111lll1 = self._11l11l11(l1111lll1, l11111ll1)
            path = l1l1lllll.path
            if not path.endswith(l111l (u"ࠪ࠳ࠬࣻ")):
                path += l111l (u"ࠫ࠴࠭ࣼ")
            l11l11lll = ParseResult(scheme=l11111ll1, netloc=l1111lll1, path=path,
                                         params=l1l1lllll.params, query=l1l1lllll.query,
                                         fragment=l1l1lllll.fragment)
            self.l111ll1ll = l11l11lll.geturl()
        else:
            if not l11lll1l1.netloc:
                raise l1111l11(l111l (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l11lll1 = l11lll1l1.path
            l11llllll = l111l (u"ࠨ࠯ࠣࣾ").join(l1l11lll1.split(l111l (u"ࠢ࠰ࠤࣿ"))[:-1]) + l111l (u"ࠣ࠱ࠥऀ")
            l11l11lll = ParseResult(scheme=l11lll1l1.scheme,
                                         netloc=self._11l11l11(l11lll1l1.netloc, l11lll1l1.scheme),
                                         path=l11llllll,
                                         params=l111l (u"ࠤࠥँ"),
                                         query=l111l (u"ࠥࠦं"),
                                         fragment=l111l (u"ࠦࠧः")
                                         )
            self.l111ll1ll = l11l11lll.geturl()
    def _1ll1lll1(self):
        l111l (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1l111111:
            l111l111l = self.l1l111111[0]
            l11lll1l1 = urlparse(l111l111l)
        if self.l11l1ll1l:
            l1l1l111l = urlparse(self.l11l1ll1l)
            if l1l1l111l.scheme:
                l1lll11l1 = l1l1l111l.scheme
            else:
                l1lll11l1 = l11lll1l1.scheme
            if l1l1l111l.netloc:
                l11ll1l11 = l1l1l111l.netloc
            else:
                l11ll1l11 = l11lll1l1.netloc
            l11l111ll = ParseResult(scheme=l1lll11l1, netloc=l11ll1l11, path=l1l1l111l.path,
                                      params=l1l1l111l.params, query=l1l1l111l.query,
                                      fragment=l1l1l111l.fragment)
            self.l11l1ll1l = l11l111ll.geturl()
    def _1l1l1111(self):
        l111l (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1l111111
        self.l1l111111 = []
        for item in items:
            l1l111lll = urlparse(item.strip(), scheme=l111l (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1l111lll.path[-1] == l111l (u"ࠣ࠱ࠥइ"):
                l1ll11111 = l1l111lll.path
            else:
                path_list = l1l111lll.path.split(l111l (u"ࠤ࠲ࠦई"))
                l1ll11111 = l111l (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l111l (u"ࠦ࠴ࠨऊ")
            l11ll11l1 = urlparse(self.l111ll1ll, scheme=l111l (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1l111lll.scheme:
                scheme = l1l111lll.scheme
            elif l11ll11l1.scheme:
                scheme = l11ll11l1.scheme
            else:
                scheme = l111l (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1l111lll.netloc and not l11ll11l1.netloc:
                l1l1111ll = l1l111lll.netloc
            elif not l1l111lll.netloc and l11ll11l1.netloc:
                l1l1111ll = l11ll11l1.netloc
            elif not l1l111lll.netloc and not l11ll11l1.netloc and len(self.l1l111111) > 0:
                l1111l1ll = urlparse(self.l1l111111[len(self.l1l111111) - 1])
                l1l1111ll = l1111l1ll.netloc
            elif l11ll11l1.netloc:
                l1l1111ll = l1l111lll.netloc
            elif not l11ll11l1.netloc:
                l1l1111ll = l1l111lll.netloc
            if l1l111lll.path:
                l1l1l1ll1 = l1l111lll.path
            if l1l1111ll:
                l1l1111ll = self._11l11l11(l1l1111ll, scheme)
                l1l1ll11l = ParseResult(scheme=scheme, netloc=l1l1111ll, path=l1l1l1ll1,
                                          params=l1l111lll.params,
                                          query=l1l111lll.query,
                                          fragment=l1l111lll.fragment)
                self.l1l111111.append(l1l1ll11l.geturl())
    def _11l1111l(self):
        l111l (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l111lll11 = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l111l (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l111lll11)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l111l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11ll1111:
            l111ll111 = []
            for l1ll11ll1 in self.l11ll1111:
                if l1ll11ll1 not in [x[l111l (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l111ll111.append(l1ll11ll1)
            if l111ll111:
                l11lll11 = l111l (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l111l (u"ࠧ࠲ࠠࠣऒ").join(l111ll111))
                raise l111l111(l111l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11lll11)
    def l111l1l11(self, params):
        l111l (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l11111l11 = True
        for param in self._1ll1ll1l:
            if not params.get(param.lower()):
                l11111l11 = False
        return l11111l11
class l11l1l11l():
    def __init__(self, l11l1ll11):
        self.l11l1l1l1 = l11111l.l1ll1ll1()
        self.l1lll111l = self.l11lll11l()
        self.l1l11ll1l = self.l1l1l1l11()
        self.l11l1ll11 = l11l1ll11
        self._1l11ll11 = [l111l (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l111l (u"ࠤࡑࡳࡳ࡫ࠢख"), l111l (u"ࠥࡅࡱࡲࠢग"), l111l (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l111l (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l111l (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l111l (u"ࠢࡊࡇࠥछ"), l111l (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1ll11lll = [l111l (u"ࠤ࡙࡭ࡪࡽࠢझ"), l111l (u"ࠥࡉࡩ࡯ࡴࠣञ"), l111l (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l111l (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l111l1lll = None
    def l11lll11l(self):
        l111l1l1l = l111l (u"ࠨࡎࡰࡰࡨࠦड")
        return l111l1l1l
    def l1l1l1l11(self):
        l1l11l1l1 = 0
        return l1l11l1l1
    def l1ll111l1(self):
        l11lll11 = l111l (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1l11ll1l)
        l11lll11 += l111l (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11l11ll1(l1l1llll, l11lll11, t=1)
        return res
    def run(self):
        l1l1ll111 = True
        self._11l1llll()
        result = []
        try:
            for cookie in l1l1llll1(l111ll1l=self.l11l1ll11.cookies).run():
                result.append(cookie)
        except l1llll11l as e:
            logger.exception(l111l (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1ll1l1l1 = self._1l111l11(result)
            if l1ll1l1l1:
                logger.info(l111l (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1ll1l1l1)
                self.l111l1lll = l1ll1l1l1
            else:
                logger.info(l111l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1ll1l1l1)
            l1l1ll111 = True
        else:
            l1l1ll111 = False
        return l1l1ll111
    def _1l111l11(self, l1l111ll1):
        res = False
        l111111 = os.path.join(os.environ[l111l (u"ࠬࡎࡏࡎࡇࠪध")], l111l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l111l (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1l11llll = {}
        for cookies in l1l111ll1:
            l1l11llll[cookies.name] = cookies.value
        l1l11l1ll = l111l (u"ࠣࠤप")
        for key in list(l1l11llll.keys()):
            l1l11l1ll += l111l (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1l11llll[key].strip())
        if not os.path.exists(os.path.dirname(l111111)):
            os.makedirs(os.path.dirname(l111111))
        vers = int(l111l (u"ࠥࠦब").join(self.l11l1l1l1.split(l111l (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1ll11l1l = [l111l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l111l (u"ࠨࠣࠡࠤय") + l111l (u"ࠢ࠮ࠤर") * 60,
                              l111l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l111l (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l111l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l11l1ll),
                              l111l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1ll11l1l = [l111l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l111l (u"ࠨࠣࠡࠤश") + l111l (u"ࠢ࠮ࠤष") * 60,
                              l111l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l111l (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l111l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l11l1ll),
                              l111l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l111111, l111l (u"ࠧࡽ़ࠢ")) as l11l1l1ll:
            data = l111l (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1ll11l1l)
            l11l1l1ll.write(data)
            l11l1l1ll.write(l111l (u"ࠢ࡝ࡰࠥा"))
        res = l111111
        return res
    def _11l1llll(self):
        self._11l11l1l(l111l (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11ll11ll()
    def _11l11l1l(self, l111l1ll1):
        l1l1111l1 = self.l11l1ll11.dict[l111l1ll1.lower()]
        if l1l1111l1:
            if isinstance(l1l1111l1, list):
                l111111ll = l1l1111l1
            else:
                l111111ll = [l1l1111l1]
            if l111l (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l111l1ll1.lower():
                    for l1l11l11l in l111111ll:
                        l111l11ll = [l1llllllll.upper() for l1llllllll in self._1l11ll11]
                        if not l1l11l11l.upper() in l111l11ll:
                            l111llll1 = l111l (u"ࠥ࠰ࠥࠨु").join(self._1l11ll11)
                            l1ll1l11l = l111l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l111l1ll1, l1l1111l1, l111llll1, )
                            raise l1llll1ll(l1ll1l11l)
    def _11ll11ll(self):
        l11ll1ll1 = []
        l1ll1111l = self.l11l1ll11.l11ll1111
        for l1l1ll1l1 in self._1l11ll11:
            if not l1l1ll1l1 in [l111l (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l111l (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11ll1ll1.append(l1l1ll1l1)
        for l1lll1111 in self.l11l1ll11.l11lll111:
            if l1lll1111 in l11ll1ll1 and not l1ll1111l:
                l1ll1l11l = l111l (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1llll1ll(l1ll1l11l)
def l11lllll1(title, message, l11lll1ll, l11l11111=None):
    l111lll1l = l11111lll()
    l111lll1l.l111111l1(message, title, l11lll1ll, l11l11111)
def l111lllll(title, message, l11lll1ll):
    l1l1lll11 = l11l1lll1()
    l1l1lll11.l1l11l111(title, message, l11lll1ll)
    res = l1l1lll11.result
    return res
def main():
    try:
        logger.info(l111l (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l11ll1)
        system.l1111ll1l()
        logger.info(l111l (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l11111l1(
                l111l (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1l1l1l1l = l1ll1l111()
        l1l1l1l1l.l1ll1llll(l111l (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11llll1l = [item.upper() for item in l1l1l1l1l.l11lll111]
        l11ll1lll = l111l (u"ࠧࡔࡏࡏࡇࠥॊ") in l11llll1l
        if l11ll1lll:
            logger.info(l111l (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1111llll = l1l1l1l1l.l1l111111
            for l1l111 in l1111llll:
                logger.debug(l111l (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1l111))
                opener = l11ll(l1l1l1l1l.l111ll1ll, l1l111, l111111=None, l1111ll=l1l11ll1)
                opener.open()
                logger.info(l111l (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11111l1l = l11l1l11l(l1l1l1l1l)
            l11ll1l1l = l11111l1l.run()
            l1111llll = l1l1l1l1l.l1l111111
            for l1l111 in l1111llll:
                logger.info(l111l (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1l111))
                opener = l11ll(l1l1l1l1l.l111ll1ll, l1l111, l111111=l11111l1l.l111l1lll,
                                l1111ll=l1l11ll1)
                opener.open()
                logger.info(l111l (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11l1ll as e:
        title = l111l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1llll
        logger.exception(l111l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1l1l11ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1l11ll = el
        l1l1l1lll = l111l (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1ll1l11, message.strip())
        l11lllll1(title, l1l1l1lll, l11lll1ll=l1l11ll1.get_value(l111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l11l11111=l1l1l11ll)
        sys.exit(2)
    except l1llll111 as e:
        title = l111l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1llll
        logger.exception(l111l (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1l1l11ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1l11ll = el
        l1l1l1lll = l111l (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l11lllll1(title, l1l1l1lll, l11lll1ll=l1l11ll1.get_value(l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l111l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l11l11111=l1l1l11ll)
        sys.exit(2)
    except l11111l1 as e:
        title = l111l (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1llll
        logger.exception(l111l (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l11lllll1(title, str(e), l11lll1ll=l1l11ll1.get_value(l111l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l111l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l111l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1llll
        logger.exception(l111l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l11lllll1(title, l111l (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11lll1ll=l1l11ll1.get_value(l111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1llll1ll as e:
        title = l111l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1llll
        logger.exception(l111l (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l11lllll1(title, l111l (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11lll1ll=l1l11ll1.get_value(l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l111l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l11111ll as e:
        title = l111l (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1llll
        logger.exception(l111l (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l11lllll1(title, l111l (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11lll1ll=l1l11ll1.get_value(l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l111l (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll1111:
        logger.info(l111l (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l111l (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1llll
        logger.exception(l111l (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l11lllll1(title, l111l (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11lll1ll=l1l11ll1.get_value(l111l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l111l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l111l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()