#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11l = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l111 (l11lll):
    global l1ll111
    l11l1l = ord (l11lll [-1])
    l1l11l1 = l11lll [:-1]
    l1ll1l = l11l1l % len (l1l11l1)
    l1lll111 = l1l11l1 [:l1ll1l] + l1l11l1 [l1ll1l:]
    if l11l11l:
        l111 = l1l11 () .join ([unichr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    else:
        l111 = str () .join ([chr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    return eval (l111)
import sys, json
import os
import urllib
import l1111l1
from l11lll1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1l111 import l11ll11l, logger, l1l11l1l
from cookies import l111lll1 as l11l11l1l
from l1l1l import l1111ll
l11111lll = None
from l1l1 import *
class l1111111l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l111 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1111l1ll):
        self.config = l1111l1ll
        self.l11llll11 = l1111l1.l1lll11l()
    def l11ll1l11(self):
        data = platform.uname()
        logger.info(l1l111 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1l111 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1l111 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1l111 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1l1l1l11():
    def __init__(self, encode = True):
        self._encode = encode
        self._111lll1l = [l1l111 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l111ll11l = None
        self.l1llllllll = None
        self.l1l1l1ll1 = None
        self.l1ll11l1l = None
        self.l1llllll = None
        self.l11lllll1 = None
        self.l1l111l11 = None
        self.l1lll1111 = None
        self.cookies = None
    def l11lll1l1(self, url):
        l1l111 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1l111 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._111lllll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111lll11(url)
        self.dict = self._11l1llll(params)
        logger.info(l1l111 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1ll1lll1(self.dict):
            raise l111111l(l1l111 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._111lll1l)
        self._11111ll1(self.dict)
        if self._encode:
            self.l1ll1ll1l()
        self._111l11ll()
        self._1ll11111()
        self._1l11l1l1()
        self._11lll11l()
        self.l1l1l11l1()
        logger.info(l1l111 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1l111 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l111ll11l))
        logger.info(l1l111 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1llllllll))
        logger.info(l1l111 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1l1l1ll1))
        logger.info(l1l111 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1ll11l1l))
        logger.info(l1l111 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1llllll))
        logger.info(l1l111 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11lllll1))
        logger.info(l1l111 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l111l11))
        logger.info(l1l111 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1lll1111))
    def _11111ll1(self, l1ll1l1ll):
        self.l111ll11l = l1ll1l1ll.get(l1l111 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1llllllll = l1ll1l1ll.get(l1l111 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1l111 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1l1l1ll1 = l1ll1l1ll.get(l1l111 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1ll11l1l = l1ll1l1ll.get(l1l111 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1llllll = l1ll1l1ll.get(l1l111 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11lllll1 = l1ll1l1ll.get(l1l111 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l111l11 = l1ll1l1ll.get(l1l111 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1l111 (u"ࠣࠤ࣏"))
        self.l1lll1111 = l1ll1l1ll.get(l1l111 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1l111 (u"࣑ࠥࠦ"))
        self.cookies = l1ll1l1ll.get(l1l111 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l1l11l1(self):
        l11l11l11 = False
        if self.l1llllll:
            if self.l1llllll.upper() == l1l111 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1llllll = l1l111 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1llllll.upper() == l1l111 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1llllll = l1l111 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1llllll.upper() == l1l111 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1llllll = l1l111 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1llllll.upper() == l1l111 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1llllll = l1l111 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1llllll == l1l111 (u"ࠨࠢࣛ"):
                l11l11l11 = True
            else:
                self.l1llllll = self.l1llllll.lower()
        else:
            l11l11l11 = True
        if l11l11l11:
            self.l1llllll = l1l111 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1ll1ll1l(self):
        l1l111 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l111 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l1111l1 = []
                    for el in self.__dict__.get(key):
                        l1l1111l1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l1111l1
    def l11111111(self, l11ll1l1l):
        res = l11ll1l1l
        if self._encode:
            res = urllib.parse.quote(l11ll1l1l, safe=l1l111 (u"ࠥࠦࣟ"))
        return res
    def _111lllll(self, url):
        l1l111 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1l111 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1l111 (u"ࠨ࠺ࠣ࣢")), l1l111 (u"ࠧࠨࣣ"), url)
        return url
    def _111lll11(self, url):
        l1l111 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1l1lll1l = url.split(l1l111 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1l111 (u"ࠥ࠿ࣦࠧ")))
        result = l1l1lll1l
        if len(result) == 0:
            raise l1llllll1(l1l111 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11l1llll(self, params):
        l1l111 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1l111 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1l111 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11l1l11l = data.group(l1l111 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11l1l11l in (l1l111 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1l111 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1l111 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1l111 (u"ࠧ࠲࣯ࠢ"))
                elif l11l1l11l == l1l111 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1l111 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l111 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11l1l11l] = value
        return result
    def _1l1l1l1l(self, url, scheme):
        l1l111 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l11l1l1ll = {l1l111 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1l111 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11111l1l = url.split(l1l111 (u"ࠧࡀࣶࠢ"))
        if len(l11111l1l) == 1:
            for l1ll1l11l in list(l11l1l1ll.keys()):
                if l1ll1l11l == scheme:
                    url += l1l111 (u"ࠨ࠺ࠣࣷ") + str(l11l1l1ll[l1ll1l11l])
                    break
        return url
    def _111l11ll(self):
        l1l111 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1ll11l1l:
            l111ll1l1 = self.l1ll11l1l[0]
            l11l11lll = urlparse(l111ll1l1)
        if self.l111ll11l:
            l1l1ll111 = urlparse(self.l111ll11l)
            if l1l1ll111.scheme:
                l11ll11ll = l1l1ll111.scheme
            else:
                if l11l11lll.scheme:
                    l11ll11ll = l11l11lll.scheme
                else:
                    raise l1lll1l11(
                        l1l111 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1ll111.netloc:
                l111l1111 = l1l1ll111.netloc
            else:
                if l11l11lll.netloc:
                    l111l1111 = l11l11lll.netloc
                else:
                    raise l1lll1l11(
                        l1l111 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l111l1111 = self._1l1l1l1l(l111l1111, l11ll11ll)
            path = l1l1ll111.path
            if not path.endswith(l1l111 (u"ࠪ࠳ࠬࣻ")):
                path += l1l111 (u"ࠫ࠴࠭ࣼ")
            l111llll1 = ParseResult(scheme=l11ll11ll, netloc=l111l1111, path=path,
                                         params=l1l1ll111.params, query=l1l1ll111.query,
                                         fragment=l1l1ll111.fragment)
            self.l111ll11l = l111llll1.geturl()
        else:
            if not l11l11lll.netloc:
                raise l1lll1l11(l1l111 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11l111ll = l11l11lll.path
            l1l11ll11 = l1l111 (u"ࠨ࠯ࠣࣾ").join(l11l111ll.split(l1l111 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1l111 (u"ࠣ࠱ࠥऀ")
            l111llll1 = ParseResult(scheme=l11l11lll.scheme,
                                         netloc=self._1l1l1l1l(l11l11lll.netloc, l11l11lll.scheme),
                                         path=l1l11ll11,
                                         params=l1l111 (u"ࠤࠥँ"),
                                         query=l1l111 (u"ࠥࠦं"),
                                         fragment=l1l111 (u"ࠦࠧः")
                                         )
            self.l111ll11l = l111llll1.geturl()
    def _1l11l1l1(self):
        l1l111 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1ll11l1l:
            l111ll1l1 = self.l1ll11l1l[0]
            l11l11lll = urlparse(l111ll1l1)
        if self.l11lllll1:
            l111ll111 = urlparse(self.l11lllll1)
            if l111ll111.scheme:
                l1l111111 = l111ll111.scheme
            else:
                l1l111111 = l11l11lll.scheme
            if l111ll111.netloc:
                l1ll1llll = l111ll111.netloc
            else:
                l1ll1llll = l11l11lll.netloc
            l1l1l11ll = ParseResult(scheme=l1l111111, netloc=l1ll1llll, path=l111ll111.path,
                                      params=l111ll111.params, query=l111ll111.query,
                                      fragment=l111ll111.fragment)
            self.l11lllll1 = l1l1l11ll.geturl()
    def _1ll11111(self):
        l1l111 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1ll11l1l
        self.l1ll11l1l = []
        for item in items:
            l11l1l111 = urlparse(item.strip(), scheme=l1l111 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11l1l111.path[-1] == l1l111 (u"ࠣ࠱ࠥइ"):
                l11llllll = l11l1l111.path
            else:
                path_list = l11l1l111.path.split(l1l111 (u"ࠤ࠲ࠦई"))
                l11llllll = l1l111 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1l111 (u"ࠦ࠴ࠨऊ")
            l1111l11l = urlparse(self.l111ll11l, scheme=l1l111 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11l1l111.scheme:
                scheme = l11l1l111.scheme
            elif l1111l11l.scheme:
                scheme = l1111l11l.scheme
            else:
                scheme = l1l111 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11l1l111.netloc and not l1111l11l.netloc:
                l1ll111l1 = l11l1l111.netloc
            elif not l11l1l111.netloc and l1111l11l.netloc:
                l1ll111l1 = l1111l11l.netloc
            elif not l11l1l111.netloc and not l1111l11l.netloc and len(self.l1ll11l1l) > 0:
                l1l11ll1l = urlparse(self.l1ll11l1l[len(self.l1ll11l1l) - 1])
                l1ll111l1 = l1l11ll1l.netloc
            elif l1111l11l.netloc:
                l1ll111l1 = l11l1l111.netloc
            elif not l1111l11l.netloc:
                l1ll111l1 = l11l1l111.netloc
            if l11l1l111.path:
                l111l1lll = l11l1l111.path
            if l1ll111l1:
                l1ll111l1 = self._1l1l1l1l(l1ll111l1, scheme)
                l1l1l1lll = ParseResult(scheme=scheme, netloc=l1ll111l1, path=l111l1lll,
                                          params=l11l1l111.params,
                                          query=l11l1l111.query,
                                          fragment=l11l1l111.fragment)
                self.l1ll11l1l.append(l1l1l1lll.geturl())
    def _11lll11l(self):
        l1l111 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1l11l11l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111l1l(l1l111 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1l11l11l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111l1l(l1l111 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1l1l1ll1:
            l111l111l = []
            for l1111llll in self.l1l1l1ll1:
                if l1111llll not in [x[l1l111 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l111l111l.append(l1111llll)
            if l111l111l:
                l11lllll = l1l111 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1l111 (u"ࠧ࠲ࠠࠣऒ").join(l111l111l))
                raise l1111l1l(l1l111 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11lllll)
    def l1ll1lll1(self, params):
        l1l111 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l11ll1lll = True
        for param in self._111lll1l:
            if not params.get(param.lower()):
                l11ll1lll = False
        return l11ll1lll
class l1l11l1ll():
    def __init__(self, l1l1ll11l):
        self.l1l1llll1 = l1111l1.l1lll11l()
        self.l1111l111 = self.l11l11111()
        self.l11l1111l = self.l111ll1ll()
        self.l1l1ll11l = l1l1ll11l
        self._1l1lllll = [l1l111 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1l111 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1l111 (u"ࠥࡅࡱࡲࠢग"), l1l111 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1l111 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1l111 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1l111 (u"ࠢࡊࡇࠥछ"), l1l111 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l11l111 = [l1l111 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1l111 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1l111 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1l111 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11lll111 = None
    def l11l11111(self):
        l1lll111l = l1l111 (u"ࠨࡎࡰࡰࡨࠦड")
        return l1lll111l
    def l111ll1ll(self):
        l111l1l11 = 0
        return l111l1l11
    def l1lll11l1(self):
        l11lllll = l1l111 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11l1111l)
        l11lllll += l1l111 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11lll1ll(l11ll11l, l11lllll, t=1)
        return res
    def run(self):
        l111l1ll1 = True
        self._11111l11()
        result = []
        try:
            for cookie in l11l11l1l(l111l1l1=self.l1l1ll11l.cookies).run():
                result.append(cookie)
        except l1111111 as e:
            logger.exception(l1l111 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1l1l1111 = self._1ll1111l(result)
            if l1l1l1111:
                logger.info(l1l111 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1l1l1111)
                self.l11lll111 = l1l1l1111
            else:
                logger.info(l1l111 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1l1l1111)
            l111l1ll1 = True
        else:
            l111l1ll1 = False
        return l111l1ll1
    def _1ll1111l(self, l11l111l1):
        res = False
        ll = os.path.join(os.environ[l1l111 (u"ࠬࡎࡏࡎࡇࠪध")], l1l111 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1l111 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1ll1l111 = {}
        for cookies in l11l111l1:
            l1ll1l111[cookies.name] = cookies.value
        l1111ll11 = l1l111 (u"ࠣࠤप")
        for key in list(l1ll1l111.keys()):
            l1111ll11 += l1l111 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1ll1l111[key].strip())
        if not os.path.exists(os.path.dirname(ll)):
            os.makedirs(os.path.dirname(ll))
        vers = int(l1l111 (u"ࠥࠦब").join(self.l1l1llll1.split(l1l111 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1l1111ll = [l1l111 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1l111 (u"ࠨࠣࠡࠤय") + l1l111 (u"ࠢ࠮ࠤर") * 60,
                              l1l111 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1l111 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1l111 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1111ll11),
                              l1l111 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1l1111ll = [l1l111 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1l111 (u"ࠨࠣࠡࠤश") + l1l111 (u"ࠢ࠮ࠤष") * 60,
                              l1l111 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1l111 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1l111 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1111ll11),
                              l1l111 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(ll, l1l111 (u"ࠧࡽ़ࠢ")) as l1l1l111l:
            data = l1l111 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1l1111ll)
            l1l1l111l.write(data)
            l1l1l111l.write(l1l111 (u"ࠢ࡝ࡰࠥा"))
        res = ll
        return res
    def _11111l11(self):
        self._1111lll1(l1l111 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1ll11lll()
    def _1111lll1(self, l1l111ll1):
        l1l111lll = self.l1l1ll11l.dict[l1l111ll1.lower()]
        if l1l111lll:
            if isinstance(l1l111lll, list):
                l11ll11l1 = l1l111lll
            else:
                l11ll11l1 = [l1l111lll]
            if l1l111 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1l111ll1.lower():
                    for l1l11lll1 in l11ll11l1:
                        l1l1ll1ll = [l1ll1l1l1.upper() for l1ll1l1l1 in self._1l1lllll]
                        if not l1l11lll1.upper() in l1l1ll1ll:
                            l1l111l1l = l1l111 (u"ࠥ࠰ࠥࠨु").join(self._1l1lllll)
                            l1ll111ll = l1l111 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1l111ll1, l1l111lll, l1l111l1l, )
                            raise l1llll1l1(l1ll111ll)
    def _1ll11lll(self):
        l11ll111l = []
        l111111l1 = self.l1l1ll11l.l1l1l1ll1
        for l11ll1ll1 in self._1l1lllll:
            if not l11ll1ll1 in [l1l111 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1l111 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11ll111l.append(l11ll1ll1)
        for l11l1l1l1 in self.l1l1ll11l.l1llllllll:
            if l11l1l1l1 in l11ll111l and not l111111l1:
                l1ll111ll = l1l111 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1llll1l1(l1ll111ll)
def l111l11l1(title, message, l11l1ll11, l1111ll1l=None):
    l111l1l1l = l11llll1l()
    l111l1l1l.l1111l1l1(message, title, l11l1ll11, l1111ll1l)
def l111111ll(title, message, l11l1ll11):
    l1ll11l11 = l1l11111l()
    l1ll11l11.l11l11ll1(title, message, l11l1ll11)
    res = l1ll11l11.result
    return res
def main():
    try:
        logger.info(l1l111 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l11l1l)
        system.l11ll1l11()
        logger.info(l1l111 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l111111l(
                l1l111 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l11l1ll1l = l1l1l1l11()
        l11l1ll1l.l11lll1l1(l1l111 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11ll1111 = [item.upper() for item in l11l1ll1l.l1llllllll]
        l1ll11ll1 = l1l111 (u"ࠧࡔࡏࡏࡇࠥॊ") in l11ll1111
        if l1ll11ll1:
            logger.info(l1l111 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1ll1ll11 = l11l1ll1l.l1ll11l1l
            for l1lllll1 in l1ll1ll11:
                logger.debug(l1l111 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1lllll1))
                opener = l1111ll(l11l1ll1l.l111ll11l, l1lllll1, ll=None, l1l11ll=l1l11l1l)
                opener.open()
                logger.info(l1l111 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l1l1lll11 = l1l11l1ll(l11l1ll1l)
            l1l11llll = l1l1lll11.run()
            l1ll1ll11 = l11l1ll1l.l1ll11l1l
            for l1lllll1 in l1ll1ll11:
                logger.info(l1l111 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1lllll1))
                opener = l1111ll(l11l1ll1l.l111ll11l, l1lllll1, ll=l1l1lll11.l11lll111,
                                l1l11ll=l1l11l1l)
                opener.open()
                logger.info(l1l111 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1ll11 as e:
        title = l1l111 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11ll11l
        logger.exception(l1l111 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11l1lll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1lll1 = el
        l1l1ll1l1 = l1l111 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11ll11, message.strip())
        l111l11l1(title, l1l1ll1l1, l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1l111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1111ll1l=l11l1lll1)
        sys.exit(2)
    except l1lllll1l as e:
        title = l1l111 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11ll11l
        logger.exception(l1l111 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11l1lll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1lll1 = el
        l1l1ll1l1 = l1l111 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l111l11l1(title, l1l1ll1l1, l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1l111 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1111ll1l=l11l1lll1)
        sys.exit(2)
    except l111111l as e:
        title = l1l111 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11ll11l
        logger.exception(l1l111 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l111l11l1(title, str(e), l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1l111 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1l111 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11ll11l
        logger.exception(l1l111 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l111l11l1(title, l1l111 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1l111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1llll1l1 as e:
        title = l1l111 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11ll11l
        logger.exception(l1l111 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l111l11l1(title, l1l111 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1l111 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1ll1 as e:
        title = l1l111 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11ll11l
        logger.exception(l1l111 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l111l11l1(title, l1l111 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1l111 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1lllll:
        logger.info(l1l111 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1l111 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11ll11l
        logger.exception(l1l111 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l111l11l1(title, l1l111 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11l1ll11=l1l11l1l.get_value(l1l111 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1l111 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l111 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()