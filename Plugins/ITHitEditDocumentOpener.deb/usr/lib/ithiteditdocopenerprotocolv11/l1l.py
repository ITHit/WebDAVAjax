#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll11l = 2048
l111 = 7
def l1l1 (l1ll1l11):
    global l11l11l
    l1111l = ord (l1ll1l11 [-1])
    l1111 = l1ll1l11 [:-1]
    l1lll1l = l1111l % len (l1111)
    l1llll11 = l1111 [:l1lll1l] + l1111 [l1lll1l:]
    if l11ll:
        l1lll1l1 = l111lll () .join ([unichr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    else:
        l1lll1l1 = str () .join ([chr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    return eval (l1lll1l1)
import hashlib
import os
import l11111
from l1ll1lll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11111 import l1ll1ll
from l1ll1111 import l1l1l1, l1l1l1l
import logging
logger = logging.getLogger(l1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll111l():
    def __init__(self, l1,l1l1lll, l1lllll= None, l1ll=None):
        self.l1111ll=False
        self.l1llll1 = self._1ll111()
        self.l1l1lll = l1l1lll
        self.l1lllll = l1lllll
        self.l111ll = l1
        if l1lllll:
            self.l11l111 = True
        else:
            self.l11l111 = False
        self.l1ll = l1ll
    def _1ll111(self):
        try:
            return l11111.l1l1111() is not None
        except:
            return False
    def open(self):
        l1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1llll1:
            raise NotImplementedError(l1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l11ll = self.l111ll
        if self.l1l1lll.lower().startswith(self.l111ll.lower()):
            l11l1l1 = re.compile(re.escape(self.l111ll), re.IGNORECASE)
            l1l1lll = l11l1l1.sub(l1l1 (u"ࠨࠩࠄ"), self.l1l1lll)
            l1l1lll = l1l1lll.replace(l1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11l(self.l111ll, l1l11ll, l1l1lll, self.l1lllll)
    def l11l(self,l111ll, l1l11ll, l1l1lll, l1lllll):
        l1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111l11 = l1ll1l(l111ll)
        l111ll1 = self.l111l1(l111l11)
        logger.info(l1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111l11)
        if l111ll1:
            logger.info(l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1ll(l111l11)
            l111l11 = l1lll1(l111ll, l1l11ll, l1lllll, self.l1ll)
        logger.debug(l1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll=l111l11 + l1l1 (u"ࠤ࠲ࠦࠌ") + l1l1lll
        l1llll1l = l1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll+ l1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1llll1l)
        l1l111 = os.system(l1llll1l)
        if (l1l111 != 0):
            raise IOError(l1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll, l1l111))
    def l111l1(self, l111l11):
        if os.path.exists(l111l11):
            if os.path.islink(l111l11):
                l111l11 = os.readlink(l111l11)
            if os.path.ismount(l111l11):
                return True
        return False
def l1ll1l(l111ll):
    l1llll = l111ll.replace(l1l1 (u"࠭࡜࡝ࠩࠐ"), l1l1 (u"ࠧࡠࠩࠑ")).replace(l1l1 (u"ࠨ࠱ࠪࠒ"), l1l1 (u"ࠩࡢࠫࠓ"))
    l1lll11 = l1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll1l=os.environ[l1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll11l=os.path.join(l11ll1l,l1lll11, l1llll)
    l1l1ll1=os.path.abspath(l1lll11l)
    return l1l1ll1
def l11lll(l1ll1l1l):
    if not os.path.exists(l1ll1l1l):
        os.makedirs(l1ll1l1l)
def l11ll11(l111ll, l1l11ll, l1l111l=None, password=None):
    l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll1l1l = l1ll1l(l111ll)
    l11lll(l1ll1l1l)
    if not l1l111l:
        l1lll1ll = l1ll1()
        l1ll11ll =l1lll1ll.l11ll1(l1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l11ll + l1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l11ll + l1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11ll, str):
            l1l111l, password = l1ll11ll
        else:
            raise l1l1l1l()
        logger.info(l1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll1l1l))
    l111l1l = pwd.getpwuid( os.getuid())[0]
    l1l11l=os.environ[l1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lllll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll111={l1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111l1l, l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111ll, l1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll1l1l, l1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l11l, l1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l111l, l1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll111, temp_file)
        if not os.path.exists(os.path.join(l1lllll1, l1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l1ll=l1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1l1 (u"ࠧࠨࠤ")
        else:
            l1l1ll=l1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1l=l1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l1ll,temp_file.name)
        l1ll1l1=[l1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lllll1, l1l1l)]
        p = subprocess.Popen(l1ll1l1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll1l1l
    logger.debug(l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1ll1=os.path.abspath(l1ll1l1l)
    logger.debug(l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1ll1)
    return l1l1ll1
def l1lll1(l111ll, l1l11ll, l1lllll, l1ll):
    l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l1(title):
        l1111l1=30
        if len(title)>l1111l1:
            l1l1l11=title.split(l1l1 (u"ࠨ࠯ࠣ࠳"))
            l1ll1ll1=l1l1 (u"ࠧࠨ࠴")
            for block in l1l1l11:
                l1ll1ll1+=block+l1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l1ll1ll1) > l1111l1:
                    l1ll1ll1+=l1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll1ll1
        return title
    def l111l(l11llll, password):
        l1l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l1 (u"ࠧࠦࠢ࠹").join(l11llll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l1l = l1l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l1l.encode())
        l11lll1 = [l1l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1llllll = l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1llllll)
            for e in l11lll1:
                if e in l1llllll: return False
            raise l1l1l1(l1llllll, l1lll1=l11111.l1l1111(), l1l11ll=l1l11ll)
        logger.info(l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l111l = l1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l1 (u"ࠦࠧ࠿")
    os.system(l1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l111111 = l1ll1l(l111ll)
    l1ll1l1l = l1ll1l(hashlib.sha1(l111ll.encode()).hexdigest()[:10])
    l11lll(l1ll1l1l)
    logger.info(l1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll1l1l))
    if l1lllll:
        l11llll = [l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l111l, l1lllll),
                    urllib.parse.unquote(l1l11ll), os.path.abspath(l1ll1l1l)]
        l111l(l11llll, password)
    else:
        while True:
            l1l111l, password = ll(l1ll1l1l, l1l11ll, l1ll)
            if l1l111l.lower() != l1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11llll = [l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l1 (u"ࠤ࠰ࡸࠧࡋ"), l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l1 (u"ࠫ࠲ࡵࠧࡍ"), l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l111l,
                            urllib.parse.unquote(l1l11ll), os.path.abspath(l1ll1l1l)]
            else:
                raise l1l1l1l()
            if l111l(l11llll, password): break
    os.system(l1l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll1l1l, l111111))
    l1l1ll1=os.path.abspath(l111111)
    return l1l1ll1
def ll(l111ll, l1l11ll, l1ll):
    l11l11 = os.path.join(os.environ[l1l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l11)):
       os.makedirs(os.path.dirname(l11l11))
    l11 = l1ll.get_value(l1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1lll1ll = l1ll1(l111ll, l11)
    l1l111l, password = l1lll1ll.l11ll1(l1l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l11ll + l1l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l11ll + l1l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l111l != l1l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll11l1(l111ll, l1l111l):
        l1l11 = l1l1 (u"ࠤ࡙ࠣࠦ").join([l111ll, l1l111l, l1l1 (u"࡚ࠪࠦࠬ") + password + l1l1 (u"࡛ࠫࠧ࠭"), l1l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l11, l1l1 (u"࠭ࡷࠬࠩ࡝")) as l11111l:
            l11111l.write(l1l11)
        os.chmod(l11l11, 0o600)
    return l1l111l, password
def l1ll11l1(l111ll, l1l111l):
    l11l11 = l11l1ll = os.path.join(os.environ[l1l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l11):
        with open(l11l11, l1l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll11 = data[0].split(l1l1 (u"ࠦࠥࠨࡢ"))
            if l111ll == l1ll11[0] and l1l111l == l1ll11[1]:
                return True
    return False