#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111 = sys.version_info [0] == 2
l111 = 2048
l1ll1l1l = 7
def l11l1ll (l1ll1l11):
    global ll
    l1ll111 = ord (l1ll1l11 [-1])
    l1llll1l = l1ll1l11 [:-1]
    l1lll = l1ll111 % len (l1llll1l)
    l1 = l1llll1l [:l1lll] + l1llll1l [l1lll:]
    if l11111:
        l1ll1lll = l11l11 () .join ([unichr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    else:
        l1ll1lll = str () .join ([chr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    return eval (l1ll1lll)
import logging
import os
import re
from l111l import l1lllllll
logger = logging.getLogger(l11l1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1lll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11l1ll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lllll1():
    try:
        out = os.popen(l11l1ll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11l1ll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11l1ll (u"ࠤࠥॸ").join(result)
                logger.info(l11l1ll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11l1ll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11l1ll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11l1ll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lllllll(l11l1ll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11l1ll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1lll1(l11l1ll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))