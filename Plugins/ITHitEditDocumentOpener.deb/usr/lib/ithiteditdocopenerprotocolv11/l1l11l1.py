#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1111 = 7
def l1lll1ll (l1llll):
    global l1ll111l
    l1l1lll = ord (l1llll [-1])
    l11l1l = l1llll [:-1]
    l1ll1l1l = l1l1lll % len (l11l1l)
    l1l111l = l11l1l [:l1ll1l1l] + l11l1l [l1ll1l1l:]
    if l1ll1lll:
        l11ll11 = l1111 () .join ([unichr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    return eval (l11ll11)
import hashlib
import os
import ll
from l1111ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from ll import l1lll11
from l11111l import l11ll, l1ll1l1
import logging
logger = logging.getLogger(l1lll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1lllll1():
    def __init__(self, l1l,l1l1ll1, l1llll11= None, l1lll111=None):
        self.l1l1l1=False
        self.l11ll1l = self._111111()
        self.l1l1ll1 = l1l1ll1
        self.l1llll11 = l1llll11
        self.l11l111 = l1l
        if l1llll11:
            self.l11ll1 = True
        else:
            self.l11ll1 = False
        self.l1lll111 = l1lll111
    def _111111(self):
        try:
            return ll.l1l111() is not None
        except:
            return False
    def open(self):
        l1lll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11ll1l:
            raise NotImplementedError(l1lll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l111l = self.l11l111
        if self.l1l1ll1.lower().startswith(self.l11l111.lower()):
            l1l1l11 = re.compile(re.escape(self.l11l111), re.IGNORECASE)
            l1l1ll1 = l1l1l11.sub(l1lll1ll (u"ࠨࠩࠄ"), self.l1l1ll1)
            l1l1ll1 = l1l1ll1.replace(l1lll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1l11(self.l11l111, l111l, l1l1ll1, self.l1llll11)
    def l1ll1l11(self,l11l111, l111l, l1l1ll1, l1llll11):
        l1lll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111l1l = l1111l(l11l111)
        l1l1l1l = self.l1ll111(l111l1l)
        logger.info(l1lll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111l1l)
        if l1l1l1l:
            logger.info(l1lll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll11(l111l1l)
            l111l1l = l1lll(l11l111, l111l, l1llll11, self.l1lll111)
        logger.debug(l1lll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll=l111l1l + l1lll1ll (u"ࠤ࠲ࠦࠌ") + l1l1ll1
        l1l1l = l1lll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll+ l1lll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1l)
        l11l1ll = os.system(l1l1l)
        if (l11l1ll != 0):
            raise IOError(l1lll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll, l11l1ll))
    def l1ll111(self, l111l1l):
        if os.path.exists(l111l1l):
            if os.path.islink(l111l1l):
                l111l1l = os.readlink(l111l1l)
            if os.path.ismount(l111l1l):
                return True
        return False
def l1111l(l11l111):
    l1l11l = l11l111.replace(l1lll1ll (u"࠭࡜࡝ࠩࠐ"), l1lll1ll (u"ࠧࡠࠩࠑ")).replace(l1lll1ll (u"ࠨ࠱ࠪࠒ"), l1lll1ll (u"ࠩࡢࠫࠓ"))
    l1lll1l = l1lll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111l11=os.environ[l1lll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1111l1=os.path.join(l111l11,l1lll1l, l1l11l)
    l11=os.path.abspath(l1111l1)
    return l11
def l111ll(l1lll1l1):
    if not os.path.exists(l1lll1l1):
        os.makedirs(l1lll1l1)
def l11l11l(l11l111, l111l, l11llll=None, password=None):
    l1lll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll1l1 = l1111l(l11l111)
    l111ll(l1lll1l1)
    if not l11llll:
        l1l11ll = l11l1()
        l1lll11l =l1l11ll.l11l1l1(l1lll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l111l + l1lll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l111l + l1lll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll11l, str):
            l11llll, password = l1lll11l
        else:
            raise l1ll1l1()
        logger.info(l1lll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll1l1))
    l1ll1 = pwd.getpwuid( os.getuid())[0]
    l1ll11l1=os.environ[l1lll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llllll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11lll={l1lll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1, l1lll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l111, l1lll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll1l1, l1lll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11l1, l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11llll, l1lll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11lll, temp_file)
        if not os.path.exists(os.path.join(l1llllll, l1lll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111=l1lll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1ll (u"ࠧࠨࠤ")
        else:
            l111=l1lll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l=l1lll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111,temp_file.name)
        l1l1ll=[l1lll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llllll, l1ll1l)]
        p = subprocess.Popen(l1l1ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll1l1
    logger.debug(l1lll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11=os.path.abspath(l1lll1l1)
    logger.debug(l1lll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11)
    return l11
def l1lll(l11l111, l111l, l1llll11, l1lll111):
    l1lll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1(title):
        l1lllll=30
        if len(title)>l1lllll:
            l11111=title.split(l1lll1ll (u"ࠨ࠯ࠣ࠳"))
            l111ll1=l1lll1ll (u"ࠧࠨ࠴")
            for block in l11111:
                l111ll1+=block+l1lll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l111ll1) > l1lllll:
                    l111ll1+=l1lll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111ll1
        return title
    def l1llll1l(l1llll1, password):
        l1lll1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll1ll (u"ࠧࠦࠢ࠹").join(l1llll1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11lll1 = l1lll1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11lll1.encode())
        l111l1 = [l1lll1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l11 = l1lll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l11)
            for e in l111l1:
                if e in l1l11: return False
            raise l11ll(l1l11, l1lll=ll.l1l111(), l111l=l111l)
        logger.info(l1lll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11llll = l1lll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll1ll (u"ࠦࠧ࠿")
    os.system(l1lll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1ll1 = l1111l(l11l111)
    l1lll1l1 = l1111l(hashlib.sha1(l11l111.encode()).hexdigest()[:10])
    l111ll(l1lll1l1)
    logger.info(l1lll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1lll1l1))
    if l1llll11:
        l1llll1 = [l1lll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1lll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1lll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11llll, l1llll11),
                    urllib.parse.unquote(l111l), os.path.abspath(l1lll1l1)]
        l1llll1l(l1llll1, password)
    else:
        while True:
            l11llll, password = l111lll(l1lll1l1, l111l, l1lll111)
            if l11llll.lower() != l1lll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1llll1 = [l1lll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll1ll (u"ࠤ࠰ࡸࠧࡋ"), l1lll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll1ll (u"ࠫ࠲ࡵࠧࡍ"), l1lll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11llll,
                            urllib.parse.unquote(l111l), os.path.abspath(l1lll1l1)]
            else:
                raise l1ll1l1()
            if l1llll1l(l1llll1, password): break
    os.system(l1lll1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1lll1l1, l1ll1ll1))
    l11=os.path.abspath(l1ll1ll1)
    return l11
def l111lll(l11l111, l111l, l1lll111):
    l11l = os.path.join(os.environ[l1lll1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l)):
       os.makedirs(os.path.dirname(l11l))
    l1ll1ll = l1lll111.get_value(l1lll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l11ll = l11l1(l11l111, l1ll1ll)
    l11llll, password = l1l11ll.l11l1l1(l1lll1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l111l + l1lll1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l111l + l1lll1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11llll != l1lll1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll11ll(l11l111, l11llll):
        l11l11 = l1lll1ll (u"ࠤ࡙ࠣࠦ").join([l11l111, l11llll, l1lll1ll (u"࡚ࠪࠦࠬ") + password + l1lll1ll (u"࡛ࠫࠧ࠭"), l1lll1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l, l1lll1ll (u"࠭ࡷࠬࠩ࡝")) as l1ll11:
            l1ll11.write(l11l11)
        os.chmod(l11l, 0o600)
    return l11llll, password
def l1ll11ll(l11l111, l11llll):
    l11l = l1ll11l = os.path.join(os.environ[l1lll1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l):
        with open(l11l, l1lll1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1 = data[0].split(l1lll1ll (u"ࠦࠥࠨࡢ"))
            if l11l111 == l1[0] and l11llll == l1[1]:
                return True
    return False