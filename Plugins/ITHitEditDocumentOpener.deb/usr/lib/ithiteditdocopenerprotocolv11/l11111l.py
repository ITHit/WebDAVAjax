#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import logging
import os
import re
from l111l1l import l1llll111
logger = logging.getLogger(l111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1ll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1ll1():
    try:
        out = os.popen(l111l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l111l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l111l (u"ࠤࠥॸ").join(result)
                logger.info(l111l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l111l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l111l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l111l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll111(l111l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l111l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1ll1(l111l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))