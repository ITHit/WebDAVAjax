#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1111ll = 2048
l1l1111 = 7
def l1ll11ll (l1l11ll):
    global l1111
    l11ll11 = ord (l1l11ll [-1])
    l1lll11 = l1l11ll [:-1]
    l1l = l11ll11 % len (l1lll11)
    l1l111l = l1lll11 [:l1l] + l1lll11 [l1l:]
    if l11l111:
        l11lll = l1ll11 () .join ([unichr (ord (char) - l1111ll - (l1l1l + l11ll11) % l1l1111) for l1l1l, char in enumerate (l1l111l)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1111ll - (l1l1l + l11ll11) % l1l1111) for l1l1l, char in enumerate (l1l111l)])
    return eval (l11lll)
import re
class l1lll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll11ll = kwargs.get(l1ll11ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1llll1 = kwargs.get(l1ll11ll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllll11 = self.l1lll1l1l(args)
        if l1lllll11:
            args=args+ l1lllll11
        self.args = [a for a in args]
    def l1lll1l1l(self, *args):
        l1lllll11=None
        l11llll1 = args[0][0]
        if re.search(l1ll11ll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11llll1):
            l1lllll11 = (l1ll11ll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll11ll
                            ,)
        return l1lllll11
class l11111ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll11 = self.l1lll1l1l(args)
        if l1lllll11:
            args = args + l1lllll11
        self.args = [a for a in args]
    def l1lll1l1l(self, *args):
        s = l1ll11ll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll11ll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1111111(Exception):
    pass
class l1ll1(Exception):
    pass
class l1llll1l1(Exception):
    def __init__(self, message, l1111l11, url):
        super(l1llll1l1,self).__init__(message)
        self.l1111l11 = l1111l11
        self.url = url
class l1lll1ll1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l11111l1(Exception):
    pass
class l111111l(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l11l111l(Exception):
    pass