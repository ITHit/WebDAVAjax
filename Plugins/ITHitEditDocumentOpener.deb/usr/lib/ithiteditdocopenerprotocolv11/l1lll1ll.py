#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import hashlib
import os
import l11l111
from l1ll1l11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11l111 import l11l1
from l1llll1l import l1lllll, l11ll1l
import logging
logger = logging.getLogger(l1l1l1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111():
    def __init__(self, l1lll1l,l1ll1, l111ll= None, l111ll1=None):
        self.l1llll1=False
        self.l1ll1ll = self._1ll1lll()
        self.l1ll1 = l1ll1
        self.l111ll = l111ll
        self.l1l1ll = l1lll1l
        if l111ll:
            self.l111l = True
        else:
            self.l111l = False
        self.l111ll1 = l111ll1
    def _1ll1lll(self):
        try:
            return l11l111.l1ll11() is not None
        except:
            return False
    def open(self):
        l1l1l1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1ll:
            raise NotImplementedError(l1l1l1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1l1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1ll1 = self.l1l1ll
        if self.l1ll1.lower().startswith(self.l1l1ll.lower()):
            l111l1 = re.compile(re.escape(self.l1l1ll), re.IGNORECASE)
            l1ll1 = l111l1.sub(l1l1l1l (u"ࠨࠩࠄ"), self.l1ll1)
            l1ll1 = l1ll1.replace(l1l1l1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1l1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll(self.l1l1ll, l1l1ll1, l1ll1, self.l111ll)
    def l11ll(self,l1l1ll, l1l1ll1, l1ll1, l111ll):
        l1l1l1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1l1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111l11 = l1l1lll(l1l1ll)
        l1llll11 = self.l1111l(l111l11)
        logger.info(l1l1l1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111l11)
        if l1llll11:
            logger.info(l1l1l1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l1(l111l11)
            l111l11 = l1l11ll(l1l1ll, l1l1ll1, l111ll, self.l111ll1)
        logger.debug(l1l1l1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1=l111l11 + l1l1l1l (u"ࠤ࠲ࠦࠌ") + l1ll1
        l1l1l1 = l1l1l1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1+ l1l1l1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1l1)
        l11111 = os.system(l1l1l1)
        if (l11111 != 0):
            raise IOError(l1l1l1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1, l11111))
    def l1111l(self, l111l11):
        if os.path.exists(l111l11):
            if os.path.islink(l111l11):
                l111l11 = os.readlink(l111l11)
            if os.path.ismount(l111l11):
                return True
        return False
def l1l1lll(l1l1ll):
    l1ll11l1 = l1l1ll.replace(l1l1l1l (u"࠭࡜࡝ࠩࠐ"), l1l1l1l (u"ࠧࡠࠩࠑ")).replace(l1l1l1l (u"ࠨ࠱ࠪࠒ"), l1l1l1l (u"ࠩࡢࠫࠓ"))
    l1llll = l1l1l1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll1l1l=os.environ[l1l1l1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1l=os.path.join(l1ll1l1l,l1llll, l1ll11l1)
    l11l1ll=os.path.abspath(l1l1l)
    return l11l1ll
def l111(l111l1l):
    if not os.path.exists(l111l1l):
        os.makedirs(l111l1l)
def l11l1l1(l1l1ll, l1l1ll1, l11ll11=None, password=None):
    l1l1l1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111l1l = l1l1lll(l1l1ll)
    l111(l111l1l)
    if not l11ll11:
        l1ll11l = l111lll()
        l11l1l =l1ll11l.l1ll1l1(l1l1l1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1ll1 + l1l1l1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1ll1 + l1l1l1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l1l, str):
            l11ll11, password = l11l1l
        else:
            raise l11ll1l()
        logger.info(l1l1l1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111l1l))
    l1l11 = pwd.getpwuid( os.getuid())[0]
    l1lllll1=os.environ[l1l1l1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll11l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll11={l1l1l1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l11, l1l1l1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1ll, l1l1l1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111l1l, l1l1l1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lllll1, l1l1l1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11ll11, l1l1l1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll11, temp_file)
        if not os.path.exists(os.path.join(l1lll11l, l1l1l1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll11ll=l1l1l1l (u"ࠦࡵࡿࠢࠣ")
            key=l1l1l1l (u"ࠧࠨࠤ")
        else:
            l1ll11ll=l1l1l1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1l1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11=l1l1l1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll11ll,temp_file.name)
        l1111ll=[l1l1l1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1l1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll11l, l11)]
        p = subprocess.Popen(l1111ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1l1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1l1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1l1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111l1l
    logger.debug(l1l1l1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1l1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1l1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1l1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11l1ll=os.path.abspath(l111l1l)
    logger.debug(l1l1l1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11l1ll)
    return l11l1ll
def l1l11ll(l1l1ll, l1l1ll1, l111ll, l111ll1):
    l1l1l1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11lll1(title):
        l1ll1l=30
        if len(title)>l1ll1l:
            l1l1111=title.split(l1l1l1l (u"ࠨ࠯ࠣ࠳"))
            l1ll111l=l1l1l1l (u"ࠧࠨ࠴")
            for block in l1l1111:
                l1ll111l+=block+l1l1l1l (u"ࠣ࠱ࠥ࠵")
                if len(l1ll111l) > l1ll1l:
                    l1ll111l+=l1l1l1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll111l
        return title
    def ll(l11llll, password):
        l1l1l1l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l1l1l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l1l1l (u"ࠧࠦࠢ࠹").join(l11llll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1 = l1l1l1l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1.encode())
        l1lll1l1 = [l1l1l1l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll1111 = l1l1l1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll1111)
            for e in l1lll1l1:
                if e in l1ll1111: return False
            raise l1lllll(l1ll1111, l1l11ll=l11l111.l1ll11(), l1l1ll1=l1l1ll1)
        logger.info(l1l1l1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11ll11 = l1l1l1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l1l1l (u"ࠦࠧ࠿")
    os.system(l1l1l1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l111111 = l1l1lll(l1l1ll)
    l111l1l = l1l1lll(hashlib.sha1(l1l1ll.encode()).hexdigest()[:10])
    l111(l111l1l)
    logger.info(l1l1l1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111l1l))
    if l111ll:
        l11llll = [l1l1l1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1l1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1l1l (u"ࠤ࠰ࡸࠧࡄ"), l1l1l1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1l1l (u"ࠫ࠲ࡵࠧࡆ"), l1l1l1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11ll11, l111ll),
                    urllib.parse.unquote(l1l1ll1), os.path.abspath(l111l1l)]
        ll(l11llll, password)
    else:
        while True:
            l11ll11, password = l11ll1(l111l1l, l1l1ll1, l111ll1)
            if l11ll11.lower() != l1l1l1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11llll = [l1l1l1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l1l1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l1l1l (u"ࠤ࠰ࡸࠧࡋ"), l1l1l1l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l1l1l (u"ࠫ࠲ࡵࠧࡍ"), l1l1l1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11ll11,
                            urllib.parse.unquote(l1l1ll1), os.path.abspath(l111l1l)]
            else:
                raise l11ll1l()
            if ll(l11llll, password): break
    os.system(l1l1l1l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111l1l, l111111))
    l11l1ll=os.path.abspath(l111111)
    return l11l1ll
def l11ll1(l1l1ll, l1l1ll1, l111ll1):
    l1l111l = os.path.join(os.environ[l1l1l1l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l1l1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l1l1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l111l)):
       os.makedirs(os.path.dirname(l1l111l))
    l11l11 = l111ll1.get_value(l1l1l1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l1l1l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll11l = l111lll(l1l1ll, l11l11)
    l11ll11, password = l1ll11l.l1ll1l1(l1l1l1l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1ll1 + l1l1l1l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1ll1 + l1l1l1l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11ll11 != l1l1l1l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll111(l1l1ll, l11ll11):
        l1lll = l1l1l1l (u"ࠤ࡙ࠣࠦ").join([l1l1ll, l11ll11, l1l1l1l (u"࡚ࠪࠦࠬ") + password + l1l1l1l (u"࡛ࠫࠧ࠭"), l1l1l1l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l111l, l1l1l1l (u"࠭ࡷࠬࠩ࡝")) as l1l11l:
            l1l11l.write(l1lll)
        os.chmod(l1l111l, 0o600)
    return l11ll11, password
def l1ll111(l1l1ll, l11ll11):
    l1l111l = l1l11l1 = os.path.join(os.environ[l1l1l1l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l1l1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l1l1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l111l):
        with open(l1l111l, l1l1l1l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1111l1 = data[0].split(l1l1l1l (u"ࠦࠥࠨࡢ"))
            if l1l1ll == l1111l1[0] and l11ll11 == l1111l1[1]:
                return True
    return False