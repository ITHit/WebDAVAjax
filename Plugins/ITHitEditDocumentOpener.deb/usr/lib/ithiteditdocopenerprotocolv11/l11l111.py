#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import logging
import os
import re
from l1llll1l import l1lll11ll
logger = logging.getLogger(l1l1l1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1l1l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll11():
    try:
        out = os.popen(l1l1l1l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l1l1l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l1l1l (u"ࠤࠥॸ").join(result)
                logger.info(l1l1l1l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l1l1l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l1l1l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l1l1l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll11ll(l1l1l1l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l1l1l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l1(l1l1l1l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))