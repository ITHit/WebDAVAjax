#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll11l1 = 7
def l1lll1l (l1l11ll):
    global l1ll
    l1111l1 = ord (l1l11ll [-1])
    l1llll1l = l1l11ll [:-1]
    l11l11 = l1111l1 % len (l1llll1l)
    l1l1lll = l1llll1l [:l11l11] + l1llll1l [l11l11:]
    if l1ll1ll1:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    return eval (l1ll1l1)
import re
class l1llllll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111111 = kwargs.get(l1lll1l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll11l = kwargs.get(l1lll1l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll1l11 = self.l1llll1l1(args)
        if l1lll1l11:
            args=args+ l1lll1l11
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        l1lll1l11=None
        l1l11l11 = args[0][0]
        if re.search(l1lll1l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11l11):
            l1lll1l11 = (l1lll1l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1111111
                            ,)
        return l1lll1l11
class l11111ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lll1l11 = self.l1llll1l1(args)
        if l1lll1l11:
            args = args + l1lll1l11
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        s = l1lll1l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll1l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l11111l1(Exception):
    pass
class l1l111l(Exception):
    pass
class l1111l11(Exception):
    def __init__(self, message, l1lll11ll, url):
        super(l1111l11,self).__init__(message)
        self.l1lll11ll = l1lll11ll
        self.url = url
class l1lllll1l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111111l(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1111ll1(Exception):
    pass