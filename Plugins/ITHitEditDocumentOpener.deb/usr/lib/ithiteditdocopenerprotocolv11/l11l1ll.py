#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l11ll = 2048
l1ll1l11 = 7
def l1l111 (l111l11):
    global l1l1l1
    l111ll1 = ord (l111l11 [-1])
    l111l1l = l111l11 [:-1]
    l1ll11l = l111ll1 % len (l111l1l)
    l1l1l1l = l111l1l [:l1ll11l] + l111l1l [l1ll11l:]
    if l1lll111:
        l1l1l11 = l1l11 () .join ([unichr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    else:
        l1l1l11 = str () .join ([chr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    return eval (l1l1l11)
import re
class l1llll1l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllllll = kwargs.get(l1l111 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll11 = kwargs.get(l1l111 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllll1l = self.l1111111(args)
        if l1lllll1l:
            args=args+ l1lllll1l
        self.args = [a for a in args]
    def l1111111(self, *args):
        l1lllll1l=None
        l11lll11 = args[0][0]
        if re.search(l1l111 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11lll11):
            l1lllll1l = (l1l111 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lllllll
                            ,)
        return l1lllll1l
class l1llll1ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll1l = self.l1111111(args)
        if l1lllll1l:
            args = args + l1lllll1l
        self.args = [a for a in args]
    def l1111111(self, *args):
        s = l1l111 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l111 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll1l1(Exception):
    pass
class l1lll1l(Exception):
    pass
class l1lll1lll(Exception):
    def __init__(self, message, l1llll111, url):
        super(l1lll1lll,self).__init__(message)
        self.l1llll111 = l1llll111
        self.url = url
class l1lll1l11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l111111l(Exception):
    pass
class l1111l11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1111ll1(Exception):
    pass