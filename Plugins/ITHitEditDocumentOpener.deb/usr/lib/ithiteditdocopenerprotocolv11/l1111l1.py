#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11l = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l111 (l11lll):
    global l1ll111
    l11l1l = ord (l11lll [-1])
    l1l11l1 = l11lll [:-1]
    l1ll1l = l11l1l % len (l1l11l1)
    l1lll111 = l1l11l1 [:l1ll1l] + l1l11l1 [l1ll1l:]
    if l11l11l:
        l111 = l1l11 () .join ([unichr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    else:
        l111 = str () .join ([chr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    return eval (l111)
import logging
import os
import re
from l1l1 import l1lllll1l
logger = logging.getLogger(l1l111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l111 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll11l():
    try:
        out = os.popen(l1l111 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l111 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l111 (u"ࠤࠥॸ").join(result)
                logger.info(l1l111 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l111 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l111 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l111 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lllll1l(l1l111 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l111 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l(l1l111 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))