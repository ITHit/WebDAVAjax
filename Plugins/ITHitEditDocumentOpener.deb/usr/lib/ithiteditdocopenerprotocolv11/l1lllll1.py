#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111111 = sys.version_info [0] == 2
l111 = 2048
l1ll11 = 7
def l1ll1l1 (l1111ll):
    global l1ll1l11
    l1l1ll = ord (l1111ll [-1])
    l1111 = l1111ll [:-1]
    l11l1 = l1l1ll % len (l1111)
    l111lll = l1111 [:l11l1] + l1111 [l11l1:]
    if l111111:
        l111l1 = l11lll () .join ([unichr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    return eval (l111l1)
import hashlib
import os
import ll
from l1l1lll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from ll import l11ll1l
from l111ll import l1ll111, l1lll11
import logging
logger = logging.getLogger(l1ll1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll1ll():
    def __init__(self, l1l111l,l1111l1, l1l1l11= None, l1ll11ll=None):
        self.l1l1l=False
        self.l1llll11 = self._11111()
        self.l1111l1 = l1111l1
        self.l1l1l11 = l1l1l11
        self.l1llll1l = l1l111l
        if l1l1l11:
            self.l1111l = True
        else:
            self.l1111l = False
        self.l1ll11ll = l1ll11ll
    def _11111(self):
        try:
            return ll.l1l111() is not None
        except:
            return False
    def open(self):
        l1ll1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1llll11:
            raise NotImplementedError(l1ll1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1 = self.l1llll1l
        if self.l1111l1.lower().startswith(self.l1llll1l.lower()):
            l1ll1ll1 = re.compile(re.escape(self.l1llll1l), re.IGNORECASE)
            l1111l1 = l1ll1ll1.sub(l1ll1l1 (u"ࠨࠩࠄ"), self.l1111l1)
            l1111l1 = l1111l1.replace(l1ll1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11(self.l1llll1l, l1l1, l1111l1, self.l1l1l11)
    def l11(self,l1llll1l, l1l1, l1111l1, l1l1l11):
        l1ll1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll111l = l1lll1l1(l1llll1l)
        l1l11l1 = self.l1lll1l(l1ll111l)
        logger.info(l1ll1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll111l)
        if l1l11l1:
            logger.info(l1ll1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11ll1l(l1ll111l)
            l1ll111l = l1l1l1l(l1llll1l, l1l1, l1l1l11, self.l1ll11ll)
        logger.debug(l1ll1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1llllll=l1ll111l + l1ll1l1 (u"ࠤ࠲ࠦࠌ") + l1111l1
        l1l1ll1 = l1ll1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1llllll+ l1ll1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1ll1)
        l1lllll = os.system(l1l1ll1)
        if (l1lllll != 0):
            raise IOError(l1ll1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1llllll, l1lllll))
    def l1lll1l(self, l1ll111l):
        if os.path.exists(l1ll111l):
            if os.path.islink(l1ll111l):
                l1ll111l = os.readlink(l1ll111l)
            if os.path.ismount(l1ll111l):
                return True
        return False
def l1lll1l1(l1llll1l):
    l1lll11l = l1llll1l.replace(l1ll1l1 (u"࠭࡜࡝ࠩࠐ"), l1ll1l1 (u"ࠧࡠࠩࠑ")).replace(l1ll1l1 (u"ࠨ࠱ࠪࠒ"), l1ll1l1 (u"ࠩࡢࠫࠓ"))
    l11111l = l1ll1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11lll1=os.environ[l1ll1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1l1=os.path.join(l11lll1,l11111l, l1lll11l)
    l1l11=os.path.abspath(l1l1l1)
    return l1l11
def l1ll1lll(l1l11ll):
    if not os.path.exists(l1l11ll):
        os.makedirs(l1l11ll)
def l11llll(l1llll1l, l1l1, l1l=None, password=None):
    l1ll1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l11ll = l1lll1l1(l1llll1l)
    l1ll1lll(l1l11ll)
    if not l1l:
        l11ll1 = l11l1l1()
        l1ll11l =l11ll1.l1lll111(l1ll1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1 + l1ll1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1 + l1ll1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11l, str):
            l1l, password = l1ll11l
        else:
            raise l1lll11()
        logger.info(l1ll1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l11ll))
    l11l11l = pwd.getpwuid( os.getuid())[0]
    l11ll11=os.environ[l1ll1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11ll={l1ll1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11l, l1ll1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1llll1l, l1ll1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l11ll, l1ll1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11ll11, l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l, l1ll1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11ll, temp_file)
        if not os.path.exists(os.path.join(l1llll1, l1ll1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll=l1ll1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1l1 (u"ࠧࠨࠤ")
        else:
            l1ll=l1ll1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l1l=l1ll1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll,temp_file.name)
        l1ll11l1=[l1ll1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll1, l1ll1l1l)]
        p = subprocess.Popen(l1ll11l1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l11ll
    logger.debug(l1ll1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l11=os.path.abspath(l1l11ll)
    logger.debug(l1ll1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l11)
    return l1l11
def l1l1l1l(l1llll1l, l1l1, l1l1l11, l1ll11ll):
    l1ll1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l11l(title):
        l1llll=30
        if len(title)>l1llll:
            l11l11=title.split(l1ll1l1 (u"ࠨ࠯ࠣ࠳"))
            l111ll1=l1ll1l1 (u"ࠧࠨ࠴")
            for block in l11l11:
                l111ll1+=block+l1ll1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l111ll1) > l1llll:
                    l111ll1+=l1ll1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111ll1
        return title
    def l1ll1111(l11l1l, password):
        l1ll1l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1l1 (u"ࠧࠦࠢ࠹").join(l11l1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l111l11 = l1ll1l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l111l11.encode())
        l1l1111 = [l1ll1l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll1 = l1ll1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll1)
            for e in l1l1111:
                if e in l1lll1: return False
            raise l1ll111(l1lll1, l1l1l1l=ll.l1l111(), l1l1=l1l1)
        logger.info(l1ll1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l = l1ll1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1l1 (u"ࠦࠧ࠿")
    os.system(l1ll1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1 = l1lll1l1(l1llll1l)
    l1l11ll = l1lll1l1(hashlib.sha1(l1llll1l.encode()).hexdigest()[:10])
    l1ll1lll(l1l11ll)
    logger.info(l1ll1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l11ll))
    if l1l1l11:
        l11l1l = [l1ll1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1ll1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1ll1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l, l1l1l11),
                    urllib.parse.unquote(l1l1), os.path.abspath(l1l11ll)]
        l1ll1111(l11l1l, password)
    else:
        while True:
            l1l, password = l1ll1l(l1l11ll, l1l1, l1ll11ll)
            if l1l.lower() != l1ll1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l1l = [l1ll1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1l1 (u"ࠤ࠰ࡸࠧࡋ"), l1ll1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1l1 (u"ࠫ࠲ࡵࠧࡍ"), l1ll1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l,
                            urllib.parse.unquote(l1l1), os.path.abspath(l1l11ll)]
            else:
                raise l1lll11()
            if l1ll1111(l11l1l, password): break
    os.system(l1ll1l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l11ll, l1))
    l1l11=os.path.abspath(l1)
    return l1l11
def l1ll1l(l1llll1l, l1l1, l1ll11ll):
    l11l111 = os.path.join(os.environ[l1ll1l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l111)):
       os.makedirs(os.path.dirname(l11l111))
    l111l = l1ll11ll.get_value(l1ll1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11ll1 = l11l1l1(l1llll1l, l111l)
    l1l, password = l11ll1.l1lll111(l1ll1l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1 + l1ll1l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1 + l1ll1l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l != l1ll1l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1lll(l1llll1l, l1l):
        l11l1ll = l1ll1l1 (u"ࠤ࡙ࠣࠦ").join([l1llll1l, l1l, l1ll1l1 (u"࡚ࠪࠦࠬ") + password + l1ll1l1 (u"࡛ࠫࠧ࠭"), l1ll1l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l111, l1ll1l1 (u"࠭ࡷࠬࠩ࡝")) as l1ll1:
            l1ll1.write(l11l1ll)
        os.chmod(l11l111, 0o600)
    return l1l, password
def l1lll(l1llll1l, l1l):
    l11l111 = l11l = os.path.join(os.environ[l1ll1l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l111):
        with open(l11l111, l1ll1l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lll1ll = data[0].split(l1ll1l1 (u"ࠦࠥࠨࡢ"))
            if l1llll1l == l1lll1ll[0] and l1l == l1lll1ll[1]:
                return True
    return False