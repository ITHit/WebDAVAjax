#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1llllll = 2048
l11llll = 7
def l1 (l1lllll1):
    global l111111
    l1ll11 = ord (l1lllll1 [-1])
    l11ll1l = l1lllll1 [:-1]
    l1ll1l1l = l1ll11 % len (l11ll1l)
    l11l111 = l11ll1l [:l1ll1l1l] + l11ll1l [l1ll1l1l:]
    if l111ll:
        l11l1ll = l1ll1ll () .join ([unichr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    return eval (l11l1ll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1111 import l111ll1
from configobj import ConfigObj
l1l1llll = l1 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l11ll1 = l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠶࠹࠲࠵ࠨࡤ")
l11ll1l1 = l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1 (u"ࠣ࠸࠱࠴࠳࠾࠷࠵࠸࠱࠴ࠧࡦ")
l11ll1ll=os.path.join(os.environ.get(l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll1l1.replace(l1 (u"ࠦࠥࠨࡩ"), l1 (u"ࠧࡥࠢࡪ")).lower())
l1l11111=os.environ.get(l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lllll=l1l11ll1.replace(l1 (u"ࠣࠢࠥ࡭"), l1 (u"ࠤࡢࠦ࡮"))+l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1ll11=os.path.join(os.environ.get(l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lllll)
elif platform.system() == l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l1ll=l111ll1(l11ll1ll+l1 (u"ࠢ࠰ࠤࡳ"))
    l1l1ll11 = os.path.join(l1l1l1ll, l11lllll)
else:
    l1l1ll11 = os.path.join( l11lllll)
l1l11111=l1l11111.upper()
if l1l11111 == l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11llll1=logging.DEBUG
elif l1l11111 == l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11llll1 = logging.INFO
elif l1l11111 == l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11llll1 = logging.WARNING
elif l1l11111 == l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11llll1 = logging.ERROR
elif l1l11111 == l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11llll1 = logging.CRITICAL
elif l1l11111 == l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11llll1 = logging.NOTSET
logger = logging.getLogger(l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11llll1)
l1l111ll = logging.FileHandler(l1l1ll11, mode=l1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l111ll.setLevel(l11llll1)
formatter = logging.Formatter(l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l111ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11llll1)
l11ll11l = SysLogHandler(address=l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll11l.setFormatter(formatter)
logger.addHandler(l1l111ll)
logger.addHandler(ch)
logger.addHandler(l11ll11l)
class Settings():
    l1l1111l = l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1l111 = l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l11l11 = l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l11ll1):
        self.l1l11lll = self._11lll11(l1l11ll1)
        self._1l1l11l()
    def _11lll11(self, l1l11ll1):
        l1l11l1l = l1l11ll1.split(l1 (u"ࠣࠢࠥࢂ"))
        l1l11l1l = l1 (u"ࠤࠣࠦࢃ").join(l1l11l1l)
        if platform.system() == l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11lll = os.path.join(l11ll1ll, l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11l1l + l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11lll
    def l11lll1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l111l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1lll1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1l11l(self):
        if not os.path.exists(os.path.dirname(self.l1l11lll)):
            os.makedirs(os.path.dirname(self.l1l11lll))
        if not os.path.exists(self.l1l11lll):
            self.config = ConfigObj(self.l1l11lll)
            self.config[l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l11l11
            self.config[l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1l111
            self.config[l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1111l
            self.config[l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11lll)
            self.l1l11l11 = self.get_value(l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1l111 = self.get_value(l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1111l = self.get_value(l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l1l1(self):
        l1l1ll1l = l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1111l
        l1l1ll1l += l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1l111
        l1l1ll1l += l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l11l11
        return l1l1ll1l
    def __unicode__(self):
        return self._1l1l1l1()
    def __str__(self):
        return self._1l1l1l1()
    def __del__(self):
        self.config.write()
l11ll111 = Settings(l1l11ll1)