#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll11l = 2048
l111 = 7
def l1l1 (l1ll1l11):
    global l11l11l
    l1111l = ord (l1ll1l11 [-1])
    l1111 = l1ll1l11 [:-1]
    l1lll1l = l1111l % len (l1111)
    l1llll11 = l1111 [:l1lll1l] + l1111 [l1lll1l:]
    if l11ll:
        l1lll1l1 = l111lll () .join ([unichr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    else:
        l1lll1l1 = str () .join ([chr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    return eval (l1lll1l1)
import logging
import os
import re
from l1ll1111 import l1lllll1l
logger = logging.getLogger(l1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1ll1ll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1111():
    try:
        out = os.popen(l1l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l1 (u"ࠤࠥॸ").join(result)
                logger.info(l1l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lllll1l(l1l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1ll1ll(l1l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))