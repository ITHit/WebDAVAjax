#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l11l=logging.WARNING
logger = logging.getLogger(l1lll11 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l11l)
l1l1l11l = SysLogHandler(address=l1lll11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll11 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1l11l.setFormatter(formatter)
logger.addHandler(l1l1l11l)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l11l)
logger.addHandler(ch)
class l1lll11111(io.FileIO):
    l1lll11 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll11 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11ll1, l1llllll11,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11ll1 = l1lll11ll1
            self.l1llllll11 = l1llllll11
            if not options:
                options = l1lll11 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll11 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11ll1,
                                              self.l1llllll11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1ll1 = os.path.join(os.path.sep, l1lll11 (u"ࠪࡩࡹࡩࠧই"), l1lll11 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll11l1l = path
        else:
            self._1lll11l1l = self.l1llll1ll1
        super(l1lll11111, self).__init__(self._1lll11l1l, l1lll11 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1ll1l(self, line):
        return l1lll11111.Entry(*[x for x in line.strip(l1lll11 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll11 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll11 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll11 (u"ࠤࠦࠦ঍")):
                    yield self._1lll1ll1l(line)
            except ValueError:
                pass
    def l1lll1ll11(self, attr, value):
        for entry in self.entries:
            l1lll111l1 = getattr(entry, attr)
            if l1lll111l1 == value:
                return entry
        return None
    def l1lll11lll(self, entry):
        if self.l1lll1ll11(l1lll11 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll11 (u"ࠫࡡࡴࠧএ")).encode(l1lll11 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllll11l(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll11 (u"ࠢࠤࠤ঒")):
                if self._1lll1ll1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll11 (u"ࠨࠩও").join(lines).encode(l1lll11 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llll1l11(cls, l1lll11ll1, path=None):
        l1llll1lll = cls(path=path)
        entry = l1llll1lll.l1lll1ll11(l1lll11 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11ll1)
        if entry:
            return l1llll1lll.l1lllll11l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11ll1, l1llllll11, options=None, path=None):
        return cls(path=path).l1lll11lll(l1lll11111.Entry(device,
                                                    l1lll11ll1, l1llllll11,
                                                    options=options))
class l1lll1111l(object):
    def __init__(self, l1lllll1ll):
        self.l1lll1l1ll=l1lll11 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1lll1=l1lll11 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll1ll=l1lllll1ll
        self.l1lll1l111()
        self.l1llll1111()
        self.l1lll1llll()
        self.l1llll11ll()
        self.l1lll1l1l1()
    def l1lll1l111(self):
        temp_file=open(l1lllllll1,l1lll11 (u"࠭ࡲࠨঘ"))
        l111l1l=temp_file.read()
        data=json.loads(l111l1l)
        self.user=data[l1lll11 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11ll1=data[l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11=data[l1lll11 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11111=data[l1lll11 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll111l=data[l1lll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llllll1l=data[l1lll11 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1llll(self):
        l1ll=os.path.join(l1lll11 (u"ࠨ࠯ࠣট"),l1lll11 (u"ࠢࡶࡵࡵࠦঠ"),l1lll11 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll11 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll11 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll)
    def l1lll1l1l1(self):
        logger.info(l1lll11 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11=os.path.join(self.l11111,self.l1lll1l1ll)
        l1lllll111 = pwd.getpwnam(self.user).pw_uid
        l1llll11l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11):
            os.makedirs(l11)
            os.system(l1lll11 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11))
            logger.debug(l1lll11 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11)
        else:
            logger.debug(l1lll11 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11)
        l1ll=os.path.join(l11, self.l1lll1lll1)
        print(l1ll)
        logger.debug(l1lll11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll)
        with open(l1ll, l1lll11 (u"ࠤࡺ࠯ࠧ঩")) as l1lllll1l1:
            logger.debug(self.l11ll1 + l1lll11 (u"ࠪࠤࠬপ")+self.l1llll111l+l1lll11 (u"ࠫࠥࠨࠧফ")+self.l1llllll1l+l1lll11 (u"ࠬࠨࠧব"))
            l1lllll1l1.writelines(self.l11ll1 + l1lll11 (u"࠭ࠠࠨভ")+self.l1llll111l+l1lll11 (u"ࠧࠡࠤࠪম")+self.l1llllll1l+l1lll11 (u"ࠨࠤࠪয"))
        os.chmod(l1ll, 0o600)
        os.chown(l1ll, l1lllll111, l1llll11l1)
    def l1llll1111(self, l1llll1l1l=l1lll11 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll11 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll1l1l in groups:
            logger.info(l1lll11 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll1l1l))
        else:
            logger.warning(l1lll11 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll1l1l))
            ll=l1lll11 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll1l1l,self.user)
            logger.debug(l1lll11 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %ll)
            os.system(ll)
            logger.debug(l1lll11 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll11ll(self):
        logger.debug(l1lll11 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1lll=l1lll11111()
        l1llll1lll.add(self.l11ll1, self.l11, l1llllll11=l1lll11 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll11 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll11 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllllll1 = urllib.parse.unquote(sys.argv[1])
        if l1lllllll1:
            l1lll111ll=l1lll1111l(l1lllllll1)
        else:
            raise (l1lll11 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll11 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise