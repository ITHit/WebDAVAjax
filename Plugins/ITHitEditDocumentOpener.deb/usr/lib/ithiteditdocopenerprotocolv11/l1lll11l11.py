#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111 = sys.version_info [0] == 2
l111 = 2048
l1ll1l1l = 7
def l11l1ll (l1ll1l11):
    global ll
    l1ll111 = ord (l1ll1l11 [-1])
    l1llll1l = l1ll1l11 [:-1]
    l1lll = l1ll111 % len (l1llll1l)
    l1 = l1llll1l [:l1lll] + l1llll1l [l1lll:]
    if l11111:
        l1ll1lll = l11l11 () .join ([unichr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    else:
        l1ll1lll = str () .join ([chr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    return eval (l1ll1lll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l1ll=logging.WARNING
logger = logging.getLogger(l11l1ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l1ll)
l11ll111 = SysLogHandler(address=l11l1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11l1ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll111.setFormatter(formatter)
logger.addHandler(l11ll111)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l1ll)
logger.addHandler(ch)
class l1lllll11l(io.FileIO):
    l11l1ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11l1ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1ll1, l1lll1llll,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1ll1 = l1llll1ll1
            self.l1lll1llll = l1lll1llll
            if not options:
                options = l11l1ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11l1ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1ll1,
                                              self.l1lll1llll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1lll = os.path.join(os.path.sep, l11l1ll (u"ࠪࡩࡹࡩࠧই"), l11l1ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l11l = path
        else:
            self._1lll1l11l = self.l1llll1lll
        super(l1lllll11l, self).__init__(self._1lll1l11l, l11l1ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l11(self, line):
        return l1lllll11l.Entry(*[x for x in line.strip(l11l1ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11l1ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11l1ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11l1ll (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l11(line)
            except ValueError:
                pass
    def l1lllllll1(self, attr, value):
        for entry in self.entries:
            l1lllll1l1 = getattr(entry, attr)
            if l1lllll1l1 == value:
                return entry
        return None
    def l1lll1lll1(self, entry):
        if self.l1lllllll1(l11l1ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11l1ll (u"ࠫࡡࡴࠧএ")).encode(l11l1ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll11111(self, entry):
        self.seek(0)
        lines = [l.decode(l11l1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11l1ll (u"ࠢࠤࠤ঒")):
                if self._1llll1l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11l1ll (u"ࠨࠩও").join(lines).encode(l11l1ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llllll11(cls, l1llll1ll1, path=None):
        l1lll11ll1 = cls(path=path)
        entry = l1lll11ll1.l1lllllll1(l11l1ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1ll1)
        if entry:
            return l1lll11ll1.l1lll11111(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1ll1, l1lll1llll, options=None, path=None):
        return cls(path=path).l1lll1lll1(l1lllll11l.Entry(device,
                                                    l1llll1ll1, l1lll1llll,
                                                    options=options))
class l1lll1111l(object):
    def __init__(self, l1llll11l1):
        self.l1lllll111=l11l1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1ll1l=l11l1ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll11l1=l1llll11l1
        self.l1lllll1ll()
        self.l1lll11lll()
        self.l1llll1111()
        self.l1llllll1l()
        self.l1lll1l1l1()
    def l1lllll1ll(self):
        temp_file=open(l1lll1l111,l11l1ll (u"࠭ࡲࠨঘ"))
        l1llll=temp_file.read()
        data=json.loads(l1llll)
        self.user=data[l11l1ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l1l1l=data[l11l1ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11l=data[l11l1ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1111l=data[l11l1ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll111l=data[l11l1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1l1l=data[l11l1ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1111(self):
        l111l11=os.path.join(l11l1ll (u"ࠨ࠯ࠣট"),l11l1ll (u"ࠢࡶࡵࡵࠦঠ"),l11l1ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l11l1ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11l1ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111l11)
    def l1lll1l1l1(self):
        logger.info(l11l1ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11l=os.path.join(self.l1111l,self.l1lllll111)
        l1lll11l1l = pwd.getpwnam(self.user).pw_uid
        l1lll111l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l):
            os.makedirs(l11l)
            os.system(l11l1ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11l))
            logger.debug(l11l1ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11l)
        else:
            logger.debug(l11l1ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11l)
        l111l11=os.path.join(l11l, self.l1lll1ll1l)
        print(l111l11)
        logger.debug(l11l1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111l11)
        with open(l111l11, l11l1ll (u"ࠤࡺ࠯ࠧ঩")) as l1lll111ll:
            logger.debug(self.l1l1l1l + l11l1ll (u"ࠪࠤࠬপ")+self.l1llll111l+l11l1ll (u"ࠫࠥࠨࠧফ")+self.l1llll1l1l+l11l1ll (u"ࠬࠨࠧব"))
            l1lll111ll.writelines(self.l1l1l1l + l11l1ll (u"࠭ࠠࠨভ")+self.l1llll111l+l11l1ll (u"ࠧࠡࠤࠪম")+self.l1llll1l1l+l11l1ll (u"ࠨࠤࠪয"))
        os.chmod(l111l11, 0o600)
        os.chown(l111l11, l1lll11l1l, l1lll111l1)
    def l1lll11lll(self, l1llll11ll=l11l1ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11l1ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11ll in groups:
            logger.info(l11l1ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll11ll))
        else:
            logger.warning(l11l1ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll11ll))
            l1l1ll=l11l1ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll11ll,self.user)
            logger.debug(l11l1ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l1ll)
            os.system(l1l1ll)
            logger.debug(l11l1ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llllll1l(self):
        logger.debug(l11l1ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll11ll1=l1lllll11l()
        l1lll11ll1.add(self.l1l1l1l, self.l11l, l1lll1llll=l11l1ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11l1ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11l1ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1l111 = urllib.parse.unquote(sys.argv[1])
        if l1lll1l111:
            l1lll1ll11=l1lll1111l(l1lll1l111)
        else:
            raise (l11l1ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11l1ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise