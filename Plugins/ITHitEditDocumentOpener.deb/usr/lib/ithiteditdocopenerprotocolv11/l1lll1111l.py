#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l11lll1 = 2048
l1ll111l = 7
def l111111 (l1111ll):
    global l1lll111
    l1lllll1 = ord (l1111ll [-1])
    l1lll1ll = l1111ll [:-1]
    l1111l1 = l1lllll1 % len (l1lll1ll)
    l1l11ll = l1lll1ll [:l1111l1] + l1lll1ll [l1111l1:]
    if l1ll1lll:
        l1l1l1l = l1l111 () .join ([unichr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    else:
        l1l1l1l = str () .join ([chr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    return eval (l1l1l1l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11ll=logging.WARNING
logger = logging.getLogger(l111111 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll11ll)
l1l11l11 = SysLogHandler(address=l111111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l111111 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l11l11)
ch = logging.StreamHandler()
ch.setLevel(l1llll11ll)
logger.addHandler(ch)
class l1lll11l1l(io.FileIO):
    l111111 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l111111 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11l11, l1llll1ll1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11l11 = l1lll11l11
            self.l1llll1ll1 = l1llll1ll1
            if not options:
                options = l111111 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l111111 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11l11,
                                              self.l1llll1ll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll111l = os.path.join(os.path.sep, l111111 (u"ࠪࡩࡹࡩࠧই"), l111111 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1ll = path
        else:
            self._1lll1l1ll = self.l1llll111l
        super(l1lll11l1l, self).__init__(self._1lll1l1ll, l111111 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1l11l(self, line):
        return l1lll11l1l.Entry(*[x for x in line.strip(l111111 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l111111 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l111111 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l111111 (u"ࠤࠦࠦ঍")):
                    yield self._1lll1l11l(line)
            except ValueError:
                pass
    def l1lll111ll(self, attr, value):
        for entry in self.entries:
            l1llllll1l = getattr(entry, attr)
            if l1llllll1l == value:
                return entry
        return None
    def l1llll1l1l(self, entry):
        if self.l1lll111ll(l111111 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l111111 (u"ࠫࡡࡴࠧএ")).encode(l111111 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1ll11(self, entry):
        self.seek(0)
        lines = [l.decode(l111111 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l111111 (u"ࠢࠤࠤ঒")):
                if self._1lll1l11l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l111111 (u"ࠨࠩও").join(lines).encode(l111111 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l111(cls, l1lll11l11, path=None):
        l1lll111l1 = cls(path=path)
        entry = l1lll111l1.l1lll111ll(l111111 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11l11)
        if entry:
            return l1lll111l1.l1lll1ll11(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11l11, l1llll1ll1, options=None, path=None):
        return cls(path=path).l1llll1l1l(l1lll11l1l.Entry(device,
                                                    l1lll11l11, l1llll1ll1,
                                                    options=options))
class l1lllll11l(object):
    def __init__(self, l1lll11lll):
        self.l1lllll111=l111111 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lllllll1=l111111 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll11lll=l1lll11lll
        self.l1lll1ll1l()
        self.l1llll1lll()
        self.l1llll11l1()
        self.l1llllll11()
        self.l1lll11ll1()
    def l1lll1ll1l(self):
        temp_file=open(l1lll1lll1,l111111 (u"࠭ࡲࠨঘ"))
        l1ll=temp_file.read()
        data=json.loads(l1ll)
        self.user=data[l111111 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11ll1l=data[l111111 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l1111=data[l111111 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11111l=data[l111111 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll1l1=data[l111111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l1l1=data[l111111 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll11l1(self):
        l1llll=os.path.join(l111111 (u"ࠨ࠯ࠣট"),l111111 (u"ࠢࡶࡵࡵࠦঠ"),l111111 (u"ࠣࡵࡥ࡭ࡳࠨড"),l111111 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l111111 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1llll)
    def l1lll11ll1(self):
        logger.info(l111111 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l1111=os.path.join(self.l11111l,self.l1lllll111)
        l1llll1l11 = pwd.getpwnam(self.user).pw_uid
        l1lll11111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l1111):
            os.makedirs(l1l1111)
            os.system(l111111 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l1111))
            logger.debug(l111111 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l1111)
        else:
            logger.debug(l111111 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l1111)
        l1llll=os.path.join(l1l1111, self.l1lllllll1)
        print(l1llll)
        logger.debug(l111111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1llll)
        with open(l1llll, l111111 (u"ࠤࡺ࠯ࠧ঩")) as l1lllll1ll:
            logger.debug(self.l11ll1l + l111111 (u"ࠪࠤࠬপ")+self.l1lllll1l1+l111111 (u"ࠫࠥࠨࠧফ")+self.l1lll1l1l1+l111111 (u"ࠬࠨࠧব"))
            l1lllll1ll.writelines(self.l11ll1l + l111111 (u"࠭ࠠࠨভ")+self.l1lllll1l1+l111111 (u"ࠧࠡࠤࠪম")+self.l1lll1l1l1+l111111 (u"ࠨࠤࠪয"))
        os.chmod(l1llll, 0o600)
        os.chown(l1llll, l1llll1l11, l1lll11111)
    def l1llll1lll(self, l1lll1llll=l111111 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l111111 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1llll in groups:
            logger.info(l111111 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1llll))
        else:
            logger.warning(l111111 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1llll))
            l1ll11ll=l111111 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1llll,self.user)
            logger.debug(l111111 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll11ll)
            os.system(l1ll11ll)
            logger.debug(l111111 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llllll11(self):
        logger.debug(l111111 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll111l1=l1lll11l1l()
        l1lll111l1.add(self.l11ll1l, self.l1l1111, l1llll1ll1=l111111 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l111111 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l111111 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1lll1 = urllib.parse.unquote(sys.argv[1])
        if l1lll1lll1:
            l1llll1111=l1lllll11l(l1lll1lll1)
        else:
            raise (l111111 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l111111 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise