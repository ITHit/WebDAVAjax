#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l11 = sys.version_info [0] == 2
l1l11l = 2048
l1llll1 = 7
def l1lll111 (l11ll):
    global l111ll
    l1 = ord (l11ll [-1])
    l1ll1l1 = l11ll [:-1]
    l11l1 = l1 % len (l1ll1l1)
    l1l11 = l1ll1l1 [:l11l1] + l1ll1l1 [l11l1:]
    if l111l11:
        l11l111 = l1llll11 () .join ([unichr (ord (char) - l1l11l - (l1ll11l1 + l1) % l1llll1) for l1ll11l1, char in enumerate (l1l11)])
    else:
        l11l111 = str () .join ([chr (ord (char) - l1l11l - (l1ll11l1 + l1) % l1llll1) for l1ll11l1, char in enumerate (l1l11)])
    return eval (l11l111)
import re
class l111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1lll = kwargs.get(l1lll111 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1111ll = kwargs.get(l1lll111 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll111 = self.l1lll1l11(args)
        if l1llll111:
            args=args+ l1llll111
        self.args = [a for a in args]
    def l1lll1l11(self, *args):
        l1llll111=None
        l1l11lll = args[0][0]
        if re.search(l1lll111 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11lll):
            l1llll111 = (l1lll111 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1lll
                            ,)
        return l1llll111
class l1111l11(Exception):
    def __init__(self, *args, **kwargs):
        l1llll111 = self.l1lll1l11(args)
        if l1llll111:
            args = args + l1llll111
        self.args = [a for a in args]
    def l1lll1l11(self, *args):
        s = l1lll111 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll111 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lllll11(Exception):
    pass
class l1ll1lll(Exception):
    pass
class l111111l(Exception):
    def __init__(self, message, l1lll11ll, url):
        super(l111111l,self).__init__(message)
        self.l1lll11ll = l1lll11ll
        self.url = url
class l1llll1l1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111111(Exception):
    pass
class l11111l1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1111ll1(Exception):
    pass