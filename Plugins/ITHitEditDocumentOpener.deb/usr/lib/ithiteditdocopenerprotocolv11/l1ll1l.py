#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import gi
gi.require_version(l1lll11 (u"ࠨࡉࡷ࡯ࠬঽ"), l1lll11 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l11l1l
import logging
logger = logging.getLogger(l1lll11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l111l(Gtk.Window):
    def __init__(self, l1ll1l1l11, l1l11ll11l):
        Gtk.Window.__init__(self)
        self.l1lll1l=30
        self.l1l1l1l1l1 = False
        self.service = l1ll1l1l11
        self.l11l1l=l1l11ll11l
        self.l1111ll=l1l11l1l.l1l11lll
        self.l1ll11l1ll = Gtk.ListStore(str)
        self.l1l11l1ll1()
    def l1ll111111(self, service):
        l1ll1111ll = self.l1111ll.l1l1lll1(l1lll11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll1111ll
    def l1l11l1ll1(self, l1ll1l1l11=None):
        if l1ll1l1l11:
            self.l1ll11l1ll.clear()
            l1l11lll11=self.l1ll111111(l1ll1l1l11)
            self.l1ll11l1ll.append([l1lll11 (u"ࠧࠨু")])
            for l11l1l in l1l11lll11:
                self.l1ll11l1ll.append([l11l1l])
        else:
            self.l1ll11l1ll.clear()
            self.l1ll11l1ll.append([l1lll11 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll1l1111(self, widget, data=None):
        l1ll1ll1ll= widget.get_active()
        if data == l1lll11 (u"ࠢ࠲ࠤৃ") and l1ll1ll1ll:
            self.l1l11l1ll1()
            self.l1l1llll11.set_active(0)
            self.l1l1l11lll.set_text(l1lll11 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l11lll.set_sensitive(False)
            self.l1l1llll11.set_sensitive(False)
        else:
            self.l1l11l1ll1(l1ll1l1l11=self.service)
            self.l1l1llll11.set_active(0)
            self.l1l1l11lll.set_text(l1lll11 (u"ࠤࠥ৅"))
            self.l1l1llll11.set_sensitive(True)
            self.l1l1l11lll.set_sensitive(True)
    def l1l1lll1l1(self, widget):
        if widget.get_active():
            l11l1l = widget.get_child().get_text()
        else:
            l11l1l = self.l1ll11l1ll[widget.get_active()][0]
        password = self.l1l1ll111l(self.service, l11l1l)
        if password:
            self.l1l1l11lll.set_text(password)
        else:
            self.l1l1l11lll.set_text(l1lll11 (u"ࠥࠦ৆"))
    def l1l11lll1l(self, l11l1l, pwd, service):
        keyring.set_password(service, l11l1l, pwd)
        l1ll1111ll=self.l1111ll.l1l1lll1(l1lll11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11l1l in l1ll1111ll:
            value = self.l1111ll.get_value(l1lll11 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1111ll.l11llll1(l1lll11 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1lll11 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11l1l))
    def l1l1ll111l(self, service, l11l1l):
        l1ll11111l = keyring.get_password(service, l11l1l)
        return l1ll11111l
    def l1l1lll1ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll11l111(self, widget, data=None):
        self.l1l1l1l1l1=widget.get_active()
    def l11llll(self, message, title=l1lll11 (u"ࠨࠩো"), l11111lll=True):
        if l11111lll:
            l1ll1lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1lll11l = Gtk.MessageDialog(self,
            l1ll1lllll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1lll11l.set_title(title)
        l1l1lll11l.set_default_response(Gtk.ResponseType.OK)
        l1ll11l1l1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l11l1l = Gtk.VBox()
        l1l1l11111 = Gtk.Box(spacing=1)
        l1l1l11111.set_homogeneous(False)
        l1l1l1ll1l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1ll1l.set_homogeneous(False)
        l1l11l1l11 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l1l11.set_homogeneous(False)
        l1l1l11111.pack_start(l1l1l1ll1l, True, True, 0)
        l1l1l11111.pack_start(l1l11l1l11, True, True, 0)
        l1ll1l11ll = l1l1lll11l.get_content_area()
        l1ll111l11 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll1l11ll.pack_start(l1ll111l11, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1ll11l = Gtk.Label()
        l1ll11lll1 = Gtk.Label()
        l1ll11lll1.set_text(l1lll11 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1ll11lll1, True, True, 0)
        l1ll1ll11l.set_text(l1lll11 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll1ll11l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1ll11l, 0, 1, 0, 1)
        l1l1ll1ll1 = Gtk.RadioButton.new_with_label_from_widget(None, l1lll11 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1ll1ll1.connect(l1lll11 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll1l1111, l1lll11 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1ll1ll1, 1, 2, 0, 1)
        l1ll11ll11 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1ll1, l1lll11 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll11ll11.connect(l1lll11 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll1l1111, l1lll11 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll11ll11, 1, 2, 1, 2)
        l1l1llllll = Gtk.Label()
        l1l1llllll.set_text(l1lll11 (u"ࠥࠤࠧ৔"))
        table.attach(l1l1llllll, 0, 1, 4, 6)
        l1l11l1lll = Gtk.Label()
        l1l11l1lll.set_text(l1lll11 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l11l1lll.set_justify(Gtk.Justification.RIGHT)
        l1l11l1lll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1llll11 = Gtk.ComboBox.new_with_model_and_entry(self.l1ll11l1ll)
        self.l1l1llll11.set_entry_text_column(0)
        table.attach(l1l11l1lll, 0, 1, 6, 8)
        table.attach(self.l1l1llll11, 1, 3, 6, 8)
        self.l1l1llll11.connect(l1lll11 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1lll1l1)
        l1ll1ll111 = Gtk.Label()
        l1ll1ll111.set_text(l1lll11 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1ll111.set_justify(Gtk.Justification.RIGHT)
        l1ll1ll111.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l11lll = Gtk.Entry()
        self.l1l1l11lll.set_visibility(False)
        self.l1l1l11lll.connect(l1lll11 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1lll1ll, l1l1lll11l)
        table.attach(l1ll1ll111, 0, 1, 8, 10)
        table.attach(self.l1l1l11lll, 1, 3, 8, 10)
        l1l1ll1l11 = Gtk.CheckButton(l1lll11 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll1l11.connect(l1lll11 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll11l111, l1l1ll1l11)
        l1l1ll1l11.set_active(False)
        table.attach(l1l1ll1l11, 1, 3, 12, 14)
        l1ll111l1l = Gtk.Label()
        l1ll111l1l.set_text(l1lll11 (u"ࠥࠤࠧ৛") * 5)
        l1l1l11l1l.pack_start(l1ll111l1l, True, True, 0)
        if self.l11l1l:
            l1ll11ll11.set_active(True)
            self.l1l1llll11.set_active(0)
            self.l1l1llll11.set_sensitive(True)
            self.l1l1l11lll.set_text(l1lll11 (u"ࠦࠧড়"))
            self.l1l1l11lll.set_sensitive(True)
        else:
            self.l1l1llll11.set_active(0)
            self.l1l1llll11.set_sensitive(False)
            self.l1l1l11lll.set_text(l1lll11 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l11lll.set_sensitive(False)
        l1ll11l1l1.pack_start(vbox, True, True, 0)
        l1ll11l1l1.pack_start(table, True, True, 0)
        l1ll11l1l1.pack_end(l1l1l11l1l, True, True, 0)
        l1ll111l11.pack_start(l1ll11l1l1, True, True, 0)
        l1l1lll11l.show_all()
        response = l1l1lll11l.run()
        if self.l1l1llll11.get_active():
            l11l1l = self.l1l1llll11.get_child().get_text()
        else:
            l11l1l = self.l1ll11l1ll[self.l1l1llll11.get_active()][0]
        pwd = self.l1l1l11lll.get_text()
        l1l1lll11l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1l1l1l1:
                self.l1l11lll1l(l11l1l, pwd, self.service)
            return l11l1l, pwd
        else:
            return l1lll11 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1lll11 (u"ࠧࠨয়")
class l1l11l11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1llll1(self, l1l111l1):
        l1l1ll1lll = Gtk.ScrolledWindow()
        l1l1ll1lll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1l111ll=None
        self.l1l1llll1l = Gtk.TextBuffer()
        self.l1l1llll1l.set_text(l1l111l1)
        self.set_style()
        regexp= l1lll11 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l1ll1111 = self._1ll11llll(l1l111l1, regexp)
        self.l1ll1l11l1(l1l1ll1111, self.l1l1llll1l.get_start_iter())
        self.l1l1l1ll11 = Gtk.TextView(buffer=self.l1l1llll1l)
        self.l1l1l1ll11.set_property(l1lll11 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1l1ll11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l1ll11.connect(l1lll11 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1lll111)
        self.l1l1l1ll11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1ll1lll.set_size_request(300,100)
        self.l1l1l1ll11.show()
        l1l1ll1lll.add(self.l1l1l1ll11)
        l1l1ll1lll.show()
        return l1l1ll1lll
    def _1l1lll111(self, *args, **kwargs):
        l1l1l111l1, l1l1ll1l1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l111l1, l1l1ll1l1l).get_tags()
        if not self.l1l1l111ll:
            self.l1l1l111ll = args[1].window.get_cursor()
            self.l1l11ll1l1 = Gdk.Cursor(Gdk.CursorType.l1ll1l1l1l)
        elif tag:
            args[1].window.set_cursor(self.l1l11ll1l1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1l111ll:
                args[1].window.set_cursor(self.l1l1l111ll)
    def _1ll11llll(self, l1l111l1, l1ll1111l1):
        res=[]
        l1ll11ll1l=re.findall(l1ll1111l1,l1l111l1)
        for l1ll1l1ll1 in l1ll11ll1l:
            for el in l1ll1l1ll1:
                if el:
                    res.append(el)
        return res
    def l1ll1l11l1(self, l1l1ll1111, start):
        l1ll1lll11=0
        for text in l1l1ll1111:
            end = self.l1l1llll1l.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1lll11+=1
                l1l1l1l1ll, l1l1l1l111 = match
                tag = self.l1l1llll1l.create_tag(str(l1ll1lll11), foreground=l1lll11 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1lll11 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l11llll1, text)
                self.l1l1llll1l.apply_tag(tag, l1l1l1l1ll, l1l1l1l111)
                self.l1ll1l11l1(l1l1ll1111, l1l1l1l111)
    def _1l11llll1(self, tag, widget, l1ll1ll1l1, _1l11ll1ll, text):
        _1l1l1lll1 = l1ll1ll1l1.type
        _1l11ll111 = l1ll1ll1l1.window
        if _1l1l1lll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l1lll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll1ll1l1.button
            self.l1l1l111ll = Gdk.Cursor(Gdk.CursorType.l1ll1l1l1l)
            if _1l1l1lll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1lll11 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l111111ll(self, message, title=l1lll11 (u"ࠧࠨ০"), l11111lll=True, l1ll1lll1l=None):
        if l11111lll:
            l1ll1lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll1lllll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll1lll1l:
            l1ll1l11ll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1l11111 = Gtk.HBox(spacing=0)
            l1l11l11ll = Gtk.HBox(spacing=5)
            l1l11lllll = Gtk.Label()
            l1l11lllll.set_markup(l1lll11 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l11lllll.set_line_wrap(True)
            l1l11lllll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1lll11 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1l1lll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1lll.show()
            l1l1ll11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11ll.show()
            l1ll111lll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111lll.show()
            l1l1l11111.pack_start(separator, True, True, 0)
            l1l1l11111.pack_start(l1ll1l1lll, True, True, 0)
            l1l1l11111.pack_start(l1l1ll11ll, True, True, 0)
            l1l1l11111.pack_start(l1ll111lll, True, True, 0)
            l1l1l11111.pack_start(l1l11lllll, False, True, 0)
            l1l1l11ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11ll1.show()
            l1l1l11111.pack_end(l1l1l11ll1, True, True, 0)
            l1l1lllll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lllll1.show()
            vbox.pack_start(l1l1l11111, True, True, 0)
            l1l1ll1lll=self.__1ll1llll1(l1l111l1=l1ll1lll1l)
            vbox.pack_start(l1l1ll1lll, False, False, 0)
            vbox.pack_end(l1l1lllll1, False, False, 0)
            l1l11l11ll.pack_start(vbox, True, True,5)
            l1l11l11ll.show()
            l1ll1l11ll.pack_end(l1l11l11ll, False, False, 0)
            vbox.show()
            l1l1l11111.show()
        window.run()
class l1ll11l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111ll1(self, widget, l1l1l1111l):
        if l1l1l1111l == Gtk.ResponseType.OK:
            self.result = l1lll11 (u"ࠥࡓࡐࠨ৩")
        elif l1l1l1111l == Gtk.ResponseType.CANCEL:
            self.result = l1lll11 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1l1111l == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1lll11 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1111lll1(self, title=l1lll11 (u"ࠨࠢ৬"), message=l1lll11 (u"ࠢࠣ৭") , l11111lll=True):
        if l11111lll:
            l1ll1lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1lllll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1lll11 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll111ll1)
        window.run()
class l1l11l1l1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1l11l=None
        self.result = None
    def l1ll111ll1(self, widget, l1l1l1111l):
        print(widget, l1l1l1111l)
        if l1l1l1111l == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l1111l == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l1111l == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll11l111(self, widget, l1l1l1llll):
        if l1l1l1llll.get_active():
            self.l1l1l1l11l = 1
        else:
            self.l1l1l1l11l = 0
    def l1ll11l11l(self, title=l1lll11 (u"ࠤࠥ৯"), message=l1lll11 (u"ࠥࠦৰ"), l1ll1l111l =l1lll11 (u"ࠦࠧৱ"),l11111lll=True):
        if l11111lll:
            l1ll1lllll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1lllll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1lll11 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll111ll1)
        l1l1ll1l11 = Gtk.CheckButton(l1ll1l111l)
        l1l1ll1l11.connect(l1lll11 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll11l111, l1l1ll1l11)
        l1l1ll1l11.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll1l11, expand=True, fill=True, padding=0)
        l1l1ll1l11.show()
        window.run()
def l1l1l1l11(title, msg, l1ll1l111l=l1lll11 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11111lll=True):
    result=None
    try:
        l1l1l11l11 = l1l11l1l1l()
        l1l1l11l11.l1ll11l11l(title, msg, l1ll1l111l, l11111lll)
        result = {l1lll11 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1l11l11.result,  l1lll11 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1l11l11.l1l1l1l11l}
    except Exception as e:
        logger.exception(l1lll11 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1lll11 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11l11lll = l1l11l11l()
    message= l1lll11 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1ll11l1 = l1lll11 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11l11lll.l111111ll(message, l1lll11 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11111lll=True, l1ll1lll1l=l1l1ll11l1)