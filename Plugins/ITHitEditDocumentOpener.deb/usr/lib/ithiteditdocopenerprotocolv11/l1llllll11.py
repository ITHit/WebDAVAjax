#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll11l1 = 7
def l1lll1l (l1l11ll):
    global l1ll
    l1111l1 = ord (l1l11ll [-1])
    l1llll1l = l1l11ll [:-1]
    l11l11 = l1111l1 % len (l1llll1l)
    l1l1lll = l1llll1l [:l11l11] + l1llll1l [l11l11:]
    if l1ll1ll1:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    return eval (l1ll1l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll111ll=logging.WARNING
logger = logging.getLogger(l1lll1l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll111ll)
l1l1ll1l = SysLogHandler(address=l1lll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll1l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l1l1ll1l)
ch = logging.StreamHandler()
ch.setLevel(l1lll111ll)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l1lll1l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll1l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11lll, l1lll1l111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11lll = l1lll11lll
            self.l1lll1l111 = l1lll1l111
            if not options:
                options = l1lll1l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11lll,
                                              self.l1lll1l111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1ll1 = os.path.join(os.path.sep, l1lll1l (u"ࠪࡩࡹࡩࠧই"), l1lll1l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1l1 = path
        else:
            self._1lll1l1l1 = self.l1llll1ll1
        super(l1llll1l1l, self).__init__(self._1lll1l1l1, l1lll1l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lllllll1(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l1lll1l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll1l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1l (u"ࠤࠦࠦ঍")):
                    yield self._1lllllll1(line)
            except ValueError:
                pass
    def l1llll11ll(self, attr, value):
        for entry in self.entries:
            l1lll111l1 = getattr(entry, attr)
            if l1lll111l1 == value:
                return entry
        return None
    def l1lllll1ll(self, entry):
        if self.l1llll11ll(l1lll1l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll1l (u"ࠫࡡࡴࠧএ")).encode(l1lll1l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1llll(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1l (u"ࠢࠤࠤ঒")):
                if self._1lllllll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1l (u"ࠨࠩও").join(lines).encode(l1lll1l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll11(cls, l1lll11lll, path=None):
        l1lll1l1ll = cls(path=path)
        entry = l1lll1l1ll.l1llll11ll(l1lll1l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11lll)
        if entry:
            return l1lll1l1ll.l1lll1llll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11lll, l1lll1l111, options=None, path=None):
        return cls(path=path).l1lllll1ll(l1llll1l1l.Entry(device,
                                                    l1lll11lll, l1lll1l111,
                                                    options=options))
class l1lll1lll1(object):
    def __init__(self, l1llll1111):
        self.l1lll1l11l=l1lll1l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lllll11l=l1lll1l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll1111=l1llll1111
        self.l1lllll1l1()
        self.l1lll11l1l()
        self.l1llllll1l()
        self.l1lll11111()
        self.l1lll11l11()
    def l1lllll1l1(self):
        temp_file=open(l1llll111l,l1lll1l (u"࠭ࡲࠨঘ"))
        l1l1=temp_file.read()
        data=json.loads(l1l1)
        self.user=data[l1lll1l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l11l=data[l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l111ll1=data[l1lll1l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l1l1l=data[l1lll1l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll1lll=data[l1lll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1ll1l=data[l1lll1l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llllll1l(self):
        l1llll=os.path.join(l1lll1l (u"ࠨ࠯ࠣট"),l1lll1l (u"ࠢࡶࡵࡵࠦঠ"),l1lll1l (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll1l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll1l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1llll)
    def l1lll11l11(self):
        logger.info(l1lll1l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l111ll1=os.path.join(self.l1l1l1l,self.l1lll1l11l)
        l1lllll111 = pwd.getpwnam(self.user).pw_uid
        l1lll11ll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l111ll1):
            os.makedirs(l111ll1)
            os.system(l1lll1l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l111ll1))
            logger.debug(l1lll1l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l111ll1)
        else:
            logger.debug(l1lll1l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l111ll1)
        l1llll=os.path.join(l111ll1, self.l1lllll11l)
        print(l1llll)
        logger.debug(l1lll1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1llll)
        with open(l1llll, l1lll1l (u"ࠤࡺ࠯ࠧ঩")) as l1lll1111l:
            logger.debug(self.l11l11l + l1lll1l (u"ࠪࠤࠬপ")+self.l1llll1lll+l1lll1l (u"ࠫࠥࠨࠧফ")+self.l1lll1ll1l+l1lll1l (u"ࠬࠨࠧব"))
            l1lll1111l.writelines(self.l11l11l + l1lll1l (u"࠭ࠠࠨভ")+self.l1llll1lll+l1lll1l (u"ࠧࠡࠤࠪম")+self.l1lll1ll1l+l1lll1l (u"ࠨࠤࠪয"))
        os.chmod(l1llll, 0o600)
        os.chown(l1llll, l1lllll111, l1lll11ll1)
    def l1lll11l1l(self, l1llll11l1=l1lll1l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll1l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11l1 in groups:
            logger.info(l1lll1l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll11l1))
        else:
            logger.warning(l1lll1l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll11l1))
            l1l111=l1lll1l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll11l1,self.user)
            logger.debug(l1lll1l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l111)
            os.system(l1l111)
            logger.debug(l1lll1l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll11111(self):
        logger.debug(l1lll1l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l1ll=l1llll1l1l()
        l1lll1l1ll.add(self.l11l11l, self.l111ll1, l1lll1l111=l1lll1l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll1l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll1l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll111l = urllib.parse.unquote(sys.argv[1])
        if l1llll111l:
            l1llll1l11=l1lll1lll1(l1llll111l)
        else:
            raise (l1lll1l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll1l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise