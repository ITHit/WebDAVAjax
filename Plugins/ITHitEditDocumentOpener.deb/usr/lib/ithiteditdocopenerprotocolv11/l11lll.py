#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111ll = sys.version_info [0] == 2
l11l1l = 2048
l1llll11 = 7
def l11lll1 (l1ll11l1):
    global l1l1ll
    l1l1lll = ord (l1ll11l1 [-1])
    l1lll = l1ll11l1 [:-1]
    l1llll1 = l1l1lll % len (l1lll)
    l1l1l = l1lll [:l1llll1] + l1lll [l1llll1:]
    if l1111ll:
        l1lll111 = l11ll1l () .join ([unichr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    else:
        l1lll111 = str () .join ([chr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    return eval (l1lll111)
import logging
import os
import re
from l11ll1 import l1lllll1l
logger = logging.getLogger(l11lll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11lll1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lllll():
    try:
        out = os.popen(l11lll1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11lll1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11lll1 (u"ࠤࠥॸ").join(result)
                logger.info(l11lll1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11lll1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11lll1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11lll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lllll1l(l11lll1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11lll1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l1(l11lll1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))