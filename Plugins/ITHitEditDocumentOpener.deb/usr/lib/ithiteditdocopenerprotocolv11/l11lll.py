#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l1 = sys.version_info [0] == 2
l111lll = 2048
l1l = 7
def l1ll1ll (l11l1ll):
    global l1lll11
    l1l1111 = ord (l11l1ll [-1])
    l1111l = l11l1ll [:-1]
    l1l1 = l1l1111 % len (l1111l)
    l1l1l1 = l1111l [:l1l1] + l1111l [l1l1:]
    if l1111l1:
        l11l1l1 = l11 () .join ([unichr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    else:
        l11l1l1 = str () .join ([chr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    return eval (l11l1l1)
import gi
gi.require_version(l1ll1ll (u"ࠨࡉࡷ࡯ࠬঽ"), l1ll1ll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1l1l1
import logging
logger = logging.getLogger(l1ll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1ll1l1(Gtk.Window):
    def __init__(self, l1l11ll1l1, l1l1l1ll11):
        Gtk.Window.__init__(self)
        self.l11l11l=30
        self.l1l1l1ll1l = False
        self.service = l1l11ll1l1
        self.l1llllll=l1l1l1ll11
        self.l1ll1=l1l1l1l1.l1l111ll
        self.l1l1lll1ll = Gtk.ListStore(str)
        self.l1ll11l111()
    def l1l1ll1l11(self, service):
        l1l1l111l1 = self.l1ll1.l11ll11l(l1ll1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1l111l1
    def l1ll11l111(self, l1l11ll1l1=None):
        if l1l11ll1l1:
            self.l1l1lll1ll.clear()
            l1l1l11111=self.l1l1ll1l11(l1l11ll1l1)
            self.l1l1lll1ll.append([l1ll1ll (u"ࠧࠨু")])
            for l1llllll in l1l1l11111:
                self.l1l1lll1ll.append([l1llllll])
        else:
            self.l1l1lll1ll.clear()
            self.l1l1lll1ll.append([l1ll1ll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll11lll1(self, widget, data=None):
        l1ll1111l1= widget.get_active()
        if data == l1ll1ll (u"ࠢ࠲ࠤৃ") and l1ll1111l1:
            self.l1ll11l111()
            self.l1ll1ll111.set_active(0)
            self.l1l1l1111l.set_text(l1ll1ll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l1111l.set_sensitive(False)
            self.l1ll1ll111.set_sensitive(False)
        else:
            self.l1ll11l111(l1l11ll1l1=self.service)
            self.l1ll1ll111.set_active(0)
            self.l1l1l1111l.set_text(l1ll1ll (u"ࠤࠥ৅"))
            self.l1ll1ll111.set_sensitive(True)
            self.l1l1l1111l.set_sensitive(True)
    def l1l1ll11l1(self, widget):
        if widget.get_active():
            l1llllll = widget.get_child().get_text()
        else:
            l1llllll = self.l1l1lll1ll[widget.get_active()][0]
        password = self.l1l1l1l1ll(self.service, l1llllll)
        if password:
            self.l1l1l1111l.set_text(password)
        else:
            self.l1l1l1111l.set_text(l1ll1ll (u"ࠥࠦ৆"))
    def l1ll1l1lll(self, l1llllll, pwd, service):
        keyring.set_password(service, l1llllll, pwd)
        l1l1l111l1=self.l1ll1.l11ll11l(l1ll1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1llllll in l1l1l111l1:
            value = self.l1ll1.get_value(l1ll1ll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1ll1.l11ll1ll(l1ll1ll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1ll1ll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1llllll))
    def l1l1l1l1ll(self, service, l1llllll):
        l1l11llll1 = keyring.get_password(service, l1llllll)
        return l1l11llll1
    def l1l1l11l11(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l11lllll(self, widget, data=None):
        self.l1l1l1ll1l=widget.get_active()
    def l1lll11l(self, message, title=l1ll1ll (u"ࠨࠩো"), l11l1l1l1=True):
        if l11l1l1l1:
            l1l1ll1111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1l11ll1 = Gtk.MessageDialog(self,
            l1l1ll1111,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1l11ll1.set_title(title)
        l1l1l11ll1.set_default_response(Gtk.ResponseType.OK)
        l1l1ll1lll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l11l1l = Gtk.VBox()
        l1l1lll111 = Gtk.Box(spacing=1)
        l1l1lll111.set_homogeneous(False)
        l1l1l1lll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1lll1.set_homogeneous(False)
        l1l1lll11l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll11l.set_homogeneous(False)
        l1l1lll111.pack_start(l1l1l1lll1, True, True, 0)
        l1l1lll111.pack_start(l1l1lll11l, True, True, 0)
        l1ll1l1l1l = l1l1l11ll1.get_content_area()
        l1l1l1llll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll1l1l1l.pack_start(l1l1l1llll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1l1ll1 = Gtk.Label()
        l1l1ll111l = Gtk.Label()
        l1l1ll111l.set_text(l1ll1ll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1ll111l, True, True, 0)
        l1ll1l1ll1.set_text(l1ll1ll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll1l1ll1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1l1ll1, 0, 1, 0, 1)
        l1ll111l1l = Gtk.RadioButton.new_with_label_from_widget(None, l1ll1ll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll111l1l.connect(l1ll1ll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll11lll1, l1ll1ll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll111l1l, 1, 2, 0, 1)
        l1ll1lll1l = Gtk.RadioButton.new_with_label_from_widget(l1ll111l1l, l1ll1ll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll1lll1l.connect(l1ll1ll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll11lll1, l1ll1ll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll1lll1l, 1, 2, 1, 2)
        l1l11l1l1l = Gtk.Label()
        l1l11l1l1l.set_text(l1ll1ll (u"ࠥࠤࠧ৔"))
        table.attach(l1l11l1l1l, 0, 1, 4, 6)
        l1l1lll1l1 = Gtk.Label()
        l1l1lll1l1.set_text(l1ll1ll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1lll1l1.set_justify(Gtk.Justification.RIGHT)
        l1l1lll1l1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1ll111 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1lll1ll)
        self.l1ll1ll111.set_entry_text_column(0)
        table.attach(l1l1lll1l1, 0, 1, 6, 8)
        table.attach(self.l1ll1ll111, 1, 3, 6, 8)
        self.l1ll1ll111.connect(l1ll1ll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1ll11l1)
        l1ll11ll1l = Gtk.Label()
        l1ll11ll1l.set_text(l1ll1ll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll11ll1l.set_justify(Gtk.Justification.RIGHT)
        l1ll11ll1l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l1111l = Gtk.Entry()
        self.l1l1l1111l.set_visibility(False)
        self.l1l1l1111l.connect(l1ll1ll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1l11l11, l1l1l11ll1)
        table.attach(l1ll11ll1l, 0, 1, 8, 10)
        table.attach(self.l1l1l1111l, 1, 3, 8, 10)
        l1l1ll1ll1 = Gtk.CheckButton(l1ll1ll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll1ll1.connect(l1ll1ll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l11lllll, l1l1ll1ll1)
        l1l1ll1ll1.set_active(False)
        table.attach(l1l1ll1ll1, 1, 3, 12, 14)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l1ll1ll (u"ࠥࠤࠧ৛") * 5)
        l1l1l11l1l.pack_start(l1ll1111ll, True, True, 0)
        if self.l1llllll:
            l1ll1lll1l.set_active(True)
            self.l1ll1ll111.set_active(0)
            self.l1ll1ll111.set_sensitive(True)
            self.l1l1l1111l.set_text(l1ll1ll (u"ࠦࠧড়"))
            self.l1l1l1111l.set_sensitive(True)
        else:
            self.l1ll1ll111.set_active(0)
            self.l1ll1ll111.set_sensitive(False)
            self.l1l1l1111l.set_text(l1ll1ll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l1111l.set_sensitive(False)
        l1l1ll1lll.pack_start(vbox, True, True, 0)
        l1l1ll1lll.pack_start(table, True, True, 0)
        l1l1ll1lll.pack_end(l1l1l11l1l, True, True, 0)
        l1l1l1llll.pack_start(l1l1ll1lll, True, True, 0)
        l1l1l11ll1.show_all()
        response = l1l1l11ll1.run()
        if self.l1ll1ll111.get_active():
            l1llllll = self.l1ll1ll111.get_child().get_text()
        else:
            l1llllll = self.l1l1lll1ll[self.l1ll1ll111.get_active()][0]
        pwd = self.l1l1l1111l.get_text()
        l1l1l11ll1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1l1ll1l:
                self.l1ll1l1lll(l1llllll, pwd, self.service)
            return l1llllll, pwd
        else:
            return l1ll1ll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1ll1ll (u"ࠧࠨয়")
class l1ll1l1l1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1l1l11(self, l1l1l111):
        l1l11lll11 = Gtk.ScrolledWindow()
        l1l11lll11.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11l1ll=None
        self.l1l1l1l111 = Gtk.TextBuffer()
        self.l1l1l1l111.set_text(l1l1l111)
        self.set_style()
        regexp= l1ll1ll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l11ll11l = self._1ll11l1l1(l1l1l111, regexp)
        self.l1ll1l1111(l1l11ll11l, self.l1l1l1l111.get_start_iter())
        self.l1l1l11lll = Gtk.TextView(buffer=self.l1l1l1l111)
        self.l1l1l11lll.set_property(l1ll1ll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1l11lll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l11lll.connect(l1ll1ll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1l1l1l1)
        self.l1l1l11lll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l11lll11.set_size_request(300,100)
        self.l1l1l11lll.show()
        l1l11lll11.add(self.l1l1l11lll)
        l1l11lll11.show()
        return l1l11lll11
    def _1l1l1l1l1(self, *args, **kwargs):
        l1ll1ll1ll, l1ll1l11ll=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1ll1ll, l1ll1l11ll).get_tags()
        if not self.l1ll11l1ll:
            self.l1ll11l1ll = args[1].window.get_cursor()
            self.l1l11lll1l = Gdk.Cursor(Gdk.CursorType.l1l1l1l11l)
        elif tag:
            args[1].window.set_cursor(self.l1l11lll1l)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11l1ll:
                args[1].window.set_cursor(self.l1ll11l1ll)
    def _1ll11l1l1(self, l1l1l111, l1l1llll1l):
        res=[]
        l1ll1lll11=re.findall(l1l1llll1l,l1l1l111)
        for l1ll1l111l in l1ll1lll11:
            for el in l1ll1l111l:
                if el:
                    res.append(el)
        return res
    def l1ll1l1111(self, l1l11ll11l, start):
        l1ll11llll=0
        for text in l1l11ll11l:
            end = self.l1l1l1l111.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll11llll+=1
                l1l11l11ll, l1l11ll1ll = match
                tag = self.l1l1l1l111.create_tag(str(l1ll11llll), foreground=l1ll1ll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1ll1ll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll111ll1, text)
                self.l1l1l1l111.apply_tag(tag, l1l11l11ll, l1l11ll1ll)
                self.l1ll1l1111(l1l11ll11l, l1l11ll1ll)
    def _1ll111ll1(self, tag, widget, l1l1ll1l1l, _1ll1ll11l, text):
        _1ll1ll1l1 = l1l1ll1l1l.type
        _1l1lllll1 = l1l1ll1l1l.window
        if _1ll1ll1l1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll1ll1l1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1ll1l1l.button
            self.l1ll11l1ll = Gdk.Cursor(Gdk.CursorType.l1l1l1l11l)
            if _1ll1ll1l1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1ll1ll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1lll11l1(self, message, title=l1ll1ll (u"ࠧࠨ০"), l11l1l1l1=True, l1ll11111l=None):
        if l11l1l1l1:
            l1l1ll1111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1ll1111,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll11111l:
            l1ll1l1l1l = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1lll111 = Gtk.HBox(spacing=0)
            l1l11l1lll = Gtk.HBox(spacing=5)
            l1l11l1ll1 = Gtk.Label()
            l1l11l1ll1.set_markup(l1ll1ll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l11l1ll1.set_line_wrap(True)
            l1l11l1ll1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1ll1ll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1ll11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11ll.show()
            l1l1llllll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1llllll.show()
            l1ll111lll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111lll.show()
            l1l1lll111.pack_start(separator, True, True, 0)
            l1l1lll111.pack_start(l1l1ll11ll, True, True, 0)
            l1l1lll111.pack_start(l1l1llllll, True, True, 0)
            l1l1lll111.pack_start(l1ll111lll, True, True, 0)
            l1l1lll111.pack_start(l1l11l1ll1, False, True, 0)
            l1l1l111ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l111ll.show()
            l1l1lll111.pack_end(l1l1l111ll, True, True, 0)
            l1ll1lllll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1lllll.show()
            vbox.pack_start(l1l1lll111, True, True, 0)
            l1l11lll11=self.__1ll1l1l11(l1l1l111=l1ll11111l)
            vbox.pack_start(l1l11lll11, False, False, 0)
            vbox.pack_end(l1ll1lllll, False, False, 0)
            l1l11l1lll.pack_start(vbox, True, True,5)
            l1l11l1lll.show()
            l1ll1l1l1l.pack_end(l1l11l1lll, False, False, 0)
            vbox.show()
            l1l1lll111.show()
        window.run()
class l11l11l1l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111111(self, widget, l1ll111l11):
        if l1ll111l11 == Gtk.ResponseType.OK:
            self.result = l1ll1ll (u"ࠥࡓࡐࠨ৩")
        elif l1ll111l11 == Gtk.ResponseType.CANCEL:
            self.result = l1ll1ll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll111l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1ll1ll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11l1ll1l(self, title=l1ll1ll (u"ࠨࠢ৬"), message=l1ll1ll (u"ࠢࠣ৭") , l11l1l1l1=True):
        if l11l1l1l1:
            l1l1ll1111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll1111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1ll1ll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll111111)
        window.run()
class l1l11ll111(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1llll11=None
        self.result = None
    def l1ll111111(self, widget, l1ll111l11):
        print(widget, l1ll111l11)
        if l1ll111l11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll111l11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll111l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l11lllll(self, widget, l1l11l1l11):
        if l1l11l1l11.get_active():
            self.l1l1llll11 = 1
        else:
            self.l1l1llll11 = 0
    def l1ll1llll1(self, title=l1ll1ll (u"ࠤࠥ৯"), message=l1ll1ll (u"ࠥࠦৰ"), l1ll1l11l1 =l1ll1ll (u"ࠦࠧৱ"),l11l1l1l1=True):
        if l11l1l1l1:
            l1l1ll1111= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll1111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1ll1ll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll111111)
        l1l1ll1ll1 = Gtk.CheckButton(l1ll1l11l1)
        l1l1ll1ll1.connect(l1ll1ll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l11lllll, l1l1ll1ll1)
        l1l1ll1ll1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll1ll1, expand=True, fill=True, padding=0)
        l1l1ll1ll1.show()
        window.run()
def l111l1ll1(title, msg, l1ll1l11l1=l1ll1ll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11l1l1l1=True):
    result=None
    try:
        l1ll11ll11 = l1l11ll111()
        l1ll11ll11.l1ll1llll1(title, msg, l1ll1l11l1, l11l1l1l1)
        result = {l1ll1ll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll11ll11.result,  l1ll1ll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll11ll11.l1l1llll11}
    except Exception as e:
        logger.exception(l1ll1ll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1ll1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1l1l1l11 = l1ll1l1l1()
    message= l1ll1ll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll11l11l = l1ll1ll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1l1l1l11.l1lll11l1(message, l1ll1ll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11l1l1l1=True, l1ll11111l=l1ll11l11l)