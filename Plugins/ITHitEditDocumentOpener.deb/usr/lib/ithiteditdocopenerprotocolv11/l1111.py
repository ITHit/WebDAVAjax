#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1llllll = 2048
l11llll = 7
def l1 (l1lllll1):
    global l111111
    l1ll11 = ord (l1lllll1 [-1])
    l11ll1l = l1lllll1 [:-1]
    l1ll1l1l = l1ll11 % len (l11ll1l)
    l11l111 = l11ll1l [:l1ll1l1l] + l11ll1l [l1ll1l1l:]
    if l111ll:
        l11l1ll = l1ll1ll () .join ([unichr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    return eval (l11l1ll)
import logging
import os
import re
from l11lll import l1lll1l1l
logger = logging.getLogger(l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111ll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l1():
    try:
        out = os.popen(l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1 (u"ࠤࠥॸ").join(result)
                logger.info(l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll1l1l(l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111ll1(l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))