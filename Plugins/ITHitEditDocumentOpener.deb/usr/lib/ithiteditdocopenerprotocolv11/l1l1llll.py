#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11ll = sys.version_info [0] == 2
l111ll1 = 2048
l1l1l = 7
def l1l1 (l111ll):
    global l1lllll
    l1ll1l1l = ord (l111ll [-1])
    l11llll = l111ll [:-1]
    l1111 = l1ll1l1l % len (l11llll)
    l1llllll = l11llll [:l1111] + l11llll [l1111:]
    if l1ll11ll:
        l1ll1l11 = l11l1l1 () .join ([unichr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    else:
        l1ll1l11 = str () .join ([chr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    return eval (l1ll1l11)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l1ll import l1111l
from configobj import ConfigObj
l11ll111 = l1l1 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1l111 = l1l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠷࠴࠸࠺࠵࠸࠲࠵ࠨࡤ")
l1l1l11l = l1l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l1 (u"ࠣ࠸࠱࠶࠳࠾࠹࠴࠷࠱࠴ࠧࡦ")
l1l1l1l1=os.path.join(os.environ.get(l1l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1l11l.replace(l1l1 (u"ࠦࠥࠨࡩ"), l1l1 (u"ࠧࡥࠢࡪ")).lower())
l1l11111=os.environ.get(l1l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1lll1=l1l1l111.replace(l1l1 (u"ࠣࠢࠥ࡭"), l1l1 (u"ࠤࡢࠦ࡮"))+l1l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11l11=os.path.join(os.environ.get(l1l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1lll1)
elif platform.system() == l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11llll1=l1111l(l1l1l1l1+l1l1 (u"ࠢ࠰ࠤࡳ"))
    l1l11l11 = os.path.join(l11llll1, l1l1lll1)
else:
    l1l11l11 = os.path.join( l1l1lll1)
l1l11111=l1l11111.upper()
if l1l11111 == l1l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11l1l=logging.DEBUG
elif l1l11111 == l1l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11l1l = logging.INFO
elif l1l11111 == l1l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11l1l = logging.WARNING
elif l1l11111 == l1l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11l1l = logging.ERROR
elif l1l11111 == l1l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11l1l = logging.CRITICAL
elif l1l11111 == l1l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11l1l = logging.NOTSET
logger = logging.getLogger(l1l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11l1l)
l11ll1ll = logging.FileHandler(l1l11l11, mode=l1l1 (u"ࠣࡹ࠮ࠦࡻ"))
l11ll1ll.setLevel(l1l11l1l)
formatter = logging.Formatter(l1l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11ll1ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11l1l)
l11ll11l = SysLogHandler(address=l1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll11l.setFormatter(formatter)
logger.addHandler(l11ll1ll)
logger.addHandler(ch)
logger.addHandler(l11ll11l)
class Settings():
    l1l1ll1l = l1l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1ll11 = l1l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l11ll1 = l1l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l111):
        self.l11lll1l = self._1l111ll(l1l1l111)
        self._1l11lll()
    def _1l111ll(self, l1l1l111):
        l11l1lll = l1l1l111.split(l1l1 (u"ࠣࠢࠥࢂ"))
        l11l1lll = l1l1 (u"ࠤࠣࠦࢃ").join(l11l1lll)
        if platform.system() == l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11lll1l = os.path.join(l1l1l1l1, l1l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11l1lll + l1l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11lll1l
    def l11lllll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l1ll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11lll(self):
        if not os.path.exists(os.path.dirname(self.l11lll1l)):
            os.makedirs(os.path.dirname(self.l11lll1l))
        if not os.path.exists(self.l11lll1l):
            self.config = ConfigObj(self.l11lll1l)
            self.config[l1l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l11ll1
            self.config[l1l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1ll11
            self.config[l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1ll1l
            self.config[l1l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lll1l)
            self.l1l11ll1 = self.get_value(l1l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1ll11 = self.get_value(l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1ll1l = self.get_value(l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11ll1l1(self):
        l1l111l1 = l1l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1ll1l
        l1l111l1 += l1l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1ll11
        l1l111l1 += l1l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l11ll1
        return l1l111l1
    def __unicode__(self):
        return self._11ll1l1()
    def __str__(self):
        return self._11ll1l1()
    def __del__(self):
        self.config.write()
l1l1111l = Settings(l1l1l111)