#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111ll = sys.version_info [0] == 2
l11l1l = 2048
l1llll11 = 7
def l11lll1 (l1ll11l1):
    global l1l1ll
    l1l1lll = ord (l1ll11l1 [-1])
    l1lll = l1ll11l1 [:-1]
    l1llll1 = l1l1lll % len (l1lll)
    l1l1l = l1lll [:l1llll1] + l1lll [l1llll1:]
    if l1111ll:
        l1lll111 = l11ll1l () .join ([unichr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    else:
        l1lll111 = str () .join ([chr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    return eval (l1lll111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11lll import l11l1
from configobj import ConfigObj
l1l11111 = l11lll1 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l11lll11 = l11lll1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠷࠷࠲࠵ࠨࡤ")
l1l1ll1l = l11lll1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11lll1 (u"ࠣ࠸࠱࠴࠳࠾࠷࠶࠶࠱࠴ࠧࡦ")
l11lll1l=os.path.join(os.environ.get(l11lll1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11lll1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1ll1l.replace(l11lll1 (u"ࠦࠥࠨࡩ"), l11lll1 (u"ࠧࡥࠢࡪ")).lower())
l1l111l1=os.environ.get(l11lll1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11lll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1111l=l11lll11.replace(l11lll1 (u"ࠣࠢࠥ࡭"), l11lll1 (u"ࠤࡢࠦ࡮"))+l11lll1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11lll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11l1lll=os.path.join(os.environ.get(l11lll1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1111l)
elif platform.system() == l11lll1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l11ll1=l11l1(l11lll1l+l11lll1 (u"ࠢ࠰ࠤࡳ"))
    l11l1lll = os.path.join(l1l11ll1, l1l1111l)
else:
    l11l1lll = os.path.join( l1l1111l)
l1l111l1=l1l111l1.upper()
if l1l111l1 == l11lll1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1ll11=logging.DEBUG
elif l1l111l1 == l11lll1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1ll11 = logging.INFO
elif l1l111l1 == l11lll1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1ll11 = logging.WARNING
elif l1l111l1 == l11lll1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1ll11 = logging.ERROR
elif l1l111l1 == l11lll1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1ll11 = logging.CRITICAL
elif l1l111l1 == l11lll1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1ll11 = logging.NOTSET
logger = logging.getLogger(l11lll1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1ll11)
l1l1l1ll = logging.FileHandler(l11l1lll, mode=l11lll1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l1ll.setLevel(l1l1ll11)
formatter = logging.Formatter(l11lll1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11lll1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l1ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1ll11)
l1l111ll = SysLogHandler(address=l11lll1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l111ll.setFormatter(formatter)
logger.addHandler(l1l1l1ll)
logger.addHandler(ch)
logger.addHandler(l1l111ll)
class Settings():
    l11ll1l1 = l11lll1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1lll1 = l11lll1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11ll111 = l11lll1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11lll11):
        self.l1l11lll = self._1l11l11(l11lll11)
        self._11llll1()
    def _1l11l11(self, l11lll11):
        l11ll11l = l11lll11.split(l11lll1 (u"ࠣࠢࠥࢂ"))
        l11ll11l = l11lll1 (u"ࠤࠣࠦࢃ").join(l11ll11l)
        if platform.system() == l11lll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11lll = os.path.join(l11lll1l, l11lll1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11ll11l + l11lll1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11lll
    def l11lllll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11lll1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11lll1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l1l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11llll1(self):
        if not os.path.exists(os.path.dirname(self.l1l11lll)):
            os.makedirs(os.path.dirname(self.l1l11lll))
        if not os.path.exists(self.l1l11lll):
            self.config = ConfigObj(self.l1l11lll)
            self.config[l11lll1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11lll1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11lll1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11ll111
            self.config[l11lll1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11lll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11lll1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1lll1
            self.config[l11lll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11lll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll1l1
            self.config[l11lll1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11lll)
            self.l11ll111 = self.get_value(l11lll1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11lll1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1lll1 = self.get_value(l11lll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11lll1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll1l1 = self.get_value(l11lll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11lll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l11l(self):
        l1l1l111 = l11lll1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll1l1
        l1l1l111 += l11lll1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1lll1
        l1l1l111 += l11lll1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11ll111
        return l1l1l111
    def __unicode__(self):
        return self._1l1l11l()
    def __str__(self):
        return self._1l1l11l()
    def __del__(self):
        self.config.write()
l11ll1ll = Settings(l11lll11)