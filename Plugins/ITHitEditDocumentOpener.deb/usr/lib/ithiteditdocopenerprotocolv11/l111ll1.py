#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111l = sys.version_info [0] == 2
l1ll1lll = 2048
l1l1l = 7
def l1l1 (l11ll11):
    global l111l11
    l1l111 = ord (l11ll11 [-1])
    l1lll1ll = l11ll11 [:-1]
    l1l1111 = l1l111 % len (l1lll1ll)
    l11 = l1lll1ll [:l1l1111] + l1lll1ll [l1l1111:]
    if l1l111l:
        l11l1l = l1ll () .join ([unichr (ord (char) - l1ll1lll - (l1lllll + l1l111) % l1l1l) for l1lllll, char in enumerate (l11)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll1lll - (l1lllll + l1l111) % l1l1l) for l1lllll, char in enumerate (l11)])
    return eval (l11l1l)
import hashlib
import os
import l11lll1
from l1111l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11lll1 import l1lll11l
from l1111ll import l111111, l1111
import logging
logger = logging.getLogger(l1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111l1l():
    def __init__(self, l1lll11,l111ll, l111lll= None, l11l1l1=None):
        self.l1ll1l1l=False
        self.l1l1ll = self._1l11()
        self.l111ll = l111ll
        self.l111lll = l111lll
        self.l1l = l1lll11
        if l111lll:
            self.l11ll = True
        else:
            self.l11ll = False
        self.l11l1l1 = l11l1l1
    def _1l11(self):
        try:
            return l11lll1.l11l11() is not None
        except:
            return False
    def open(self):
        l1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1ll:
            raise NotImplementedError(l1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1l = self.l1l
        if self.l111ll.lower().startswith(self.l1l.lower()):
            l1ll1l1 = re.compile(re.escape(self.l1l), re.IGNORECASE)
            l111ll = l1ll1l1.sub(l1l1 (u"ࠨࠩࠄ"), self.l111ll)
            l111ll = l111ll.replace(l1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1l11(self.l1l, l1ll1l, l111ll, self.l111lll)
    def l1ll1l11(self,l1l, l1ll1l, l111ll, l111lll):
        l1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1l1l = l1lll1l(l1l)
        l1ll11l = self.l111l(l1l1l1l)
        logger.info(l1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1l1l)
        if l1ll11l:
            logger.info(l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll11l(l1l1l1l)
            l1l1l1l = l1ll11(l1l, l1ll1l, l111lll, self.l11l1l1)
        logger.debug(l1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11ll1l=l1l1l1l + l1l1 (u"ࠤ࠲ࠦࠌ") + l111ll
        l1ll11l1 = l1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11ll1l+ l1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll11l1)
        l1lll111 = os.system(l1ll11l1)
        if (l1lll111 != 0):
            raise IOError(l1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11ll1l, l1lll111))
    def l111l(self, l1l1l1l):
        if os.path.exists(l1l1l1l):
            if os.path.islink(l1l1l1l):
                l1l1l1l = os.readlink(l1l1l1l)
            if os.path.ismount(l1l1l1l):
                return True
        return False
def l1lll1l(l1l):
    l1ll1ll1 = l1l.replace(l1l1 (u"࠭࡜࡝ࠩࠐ"), l1l1 (u"ࠧࡠࠩࠑ")).replace(l1l1 (u"ࠨ࠱ࠪࠒ"), l1l1 (u"ࠩࡢࠫࠓ"))
    l1llll11 = l1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l11l=os.environ[l1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l11l=os.path.join(l11l11l,l1llll11, l1ll1ll1)
    l1ll111l=os.path.abspath(l1l11l)
    return l1ll111l
def l1ll1ll(l11l1):
    if not os.path.exists(l11l1):
        os.makedirs(l11l1)
def l1ll11ll(l1l, l1ll1l, l1=None, password=None):
    l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l1 = l1lll1l(l1l)
    l1ll1ll(l11l1)
    if not l1:
        l1l1l1 = l1lllll1()
        l1l1ll1 =l1l1l1.l111(l1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1l + l1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1l + l1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l1ll1, str):
            l1, password = l1l1ll1
        else:
            raise l1111()
        logger.info(l1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l1))
    l11111 = pwd.getpwuid( os.getuid())[0]
    l1l1l11=os.environ[l1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l111=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1llll1={l1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11111, l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l, l1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l1, l1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1l11, l1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1, l1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1llll1, temp_file)
        if not os.path.exists(os.path.join(l11l111, l1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll1=l1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1l1 (u"ࠧࠨࠤ")
        else:
            l1lll1=l1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1l1=l1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll1,temp_file.name)
        l111l1=[l1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l111, l1lll1l1)]
        p = subprocess.Popen(l111l1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l1
    logger.debug(l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll111l=os.path.abspath(l11l1)
    logger.debug(l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll111l)
    return l1ll111l
def l1ll11(l1l, l1ll1l, l111lll, l11l1l1):
    l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1111(title):
        ll=30
        if len(title)>ll:
            l11llll=title.split(l1l1 (u"ࠨ࠯ࠣ࠳"))
            l1llllll=l1l1 (u"ࠧࠨ࠴")
            for block in l11llll:
                l1llllll+=block+l1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l1llllll) > ll:
                    l1llllll+=l1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1llllll
        return title
    def l1l1lll(l1111l1, password):
        l1l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l1 (u"ࠧࠦࠢ࠹").join(l1111l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1llll1l = l1l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1llll1l.encode())
        l11ll1 = [l1l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l11ll = l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l11ll)
            for e in l11ll1:
                if e in l1l11ll: return False
            raise l111111(l1l11ll, l1ll11=l11lll1.l11l11(), l1ll1l=l1ll1l)
        logger.info(l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1 = l1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l1 (u"ࠦࠧ࠿")
    os.system(l1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1llll = l1lll1l(l1l)
    l11l1 = l1lll1l(hashlib.sha1(l1l.encode()).hexdigest()[:10])
    l1ll1ll(l11l1)
    logger.info(l1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11l1))
    if l111lll:
        l1111l1 = [l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1, l111lll),
                    urllib.parse.unquote(l1ll1l), os.path.abspath(l11l1)]
        l1l1lll(l1111l1, password)
    else:
        while True:
            l1, password = l11lll(l11l1, l1ll1l, l11l1l1)
            if l1.lower() != l1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1111l1 = [l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l1 (u"ࠤ࠰ࡸࠧࡋ"), l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l1 (u"ࠫ࠲ࡵࠧࡍ"), l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1,
                            urllib.parse.unquote(l1ll1l), os.path.abspath(l11l1)]
            else:
                raise l1111()
            if l1l1lll(l1111l1, password): break
    os.system(l1l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11l1, l1llll))
    l1ll111l=os.path.abspath(l1llll)
    return l1ll111l
def l11lll(l1l, l1ll1l, l11l1l1):
    l1ll111 = os.path.join(os.environ[l1l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll111)):
       os.makedirs(os.path.dirname(l1ll111))
    l1l11l1 = l11l1l1.get_value(l1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l1l1 = l1lllll1(l1l, l1l11l1)
    l1, password = l1l1l1.l111(l1l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1l + l1l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1l + l1l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1 != l1l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11l(l1l, l1):
        l1lll = l1l1 (u"ࠤ࡙ࠣࠦ").join([l1l, l1, l1l1 (u"࡚ࠪࠦࠬ") + password + l1l1 (u"࡛ࠫࠧ࠭"), l1l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll111, l1l1 (u"࠭ࡷࠬࠩ࡝")) as l11111l:
            l11111l.write(l1lll)
        os.chmod(l1ll111, 0o600)
    return l1, password
def l11l(l1l, l1):
    l1ll111 = l11l1ll = os.path.join(os.environ[l1l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll111):
        with open(l1ll111, l1l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll1 = data[0].split(l1l1 (u"ࠦࠥࠨࡢ"))
            if l1l == l1ll1[0] and l1 == l1ll1[1]:
                return True
    return False