#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1llll1l = 7
def l1lllll1 (l11ll1l):
    global l1l1ll
    l1ll1 = ord (l11ll1l [-1])
    l1l11ll = l11ll1l [:-1]
    l111111 = l1ll1 % len (l1l11ll)
    l1ll11l1 = l1l11ll [:l111111] + l1l11ll [l111111:]
    if l11ll1:
        l1lllll = l11l111 () .join ([unichr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    else:
        l1lllll = str () .join ([chr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    return eval (l1lllll)
import hashlib
import os
import l111l1
from l1lll111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111l1 import l11l11
from l1ll11l import l1ll1111, l1
import logging
logger = logging.getLogger(l1lllll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll1ll1():
    def __init__(self, l11,l1lll11l, l11lll1= None, l1l=None):
        self.l1l1l1l=False
        self.l11ll11 = self._1ll1l1()
        self.l1lll11l = l1lll11l
        self.l11lll1 = l11lll1
        self.l11l = l11
        if l11lll1:
            self.l1ll1l11 = True
        else:
            self.l1ll1l11 = False
        self.l1l = l1l
    def _1ll1l1(self):
        try:
            return l111l1.l1l11l() is not None
        except:
            return False
    def open(self):
        l1lllll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11ll11:
            raise NotImplementedError(l1lllll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lllll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11llll = self.l11l
        if self.l1lll11l.lower().startswith(self.l11l.lower()):
            l111lll = re.compile(re.escape(self.l11l), re.IGNORECASE)
            l1lll11l = l111lll.sub(l1lllll1 (u"ࠨࠩࠄ"), self.l1lll11l)
            l1lll11l = l1lll11l.replace(l1lllll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lllll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll(self.l11l, l11llll, l1lll11l, self.l11lll1)
    def l11ll(self,l11l, l11llll, l1lll11l, l11lll1):
        l1lllll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lllll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll1l1 = l111ll1(l11l)
        ll = self.l1l1l(l1lll1l1)
        logger.info(l1lllll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll1l1)
        if ll:
            logger.info(l1lllll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l11(l1lll1l1)
            l1lll1l1 = l11111l(l11l, l11llll, l11lll1, self.l1l)
        logger.debug(l1lllll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111l11=l1lll1l1 + l1lllll1 (u"ࠤ࠲ࠦࠌ") + l1lll11l
        l111l = l1lllll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111l11+ l1lllll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111l)
        l1llll1 = os.system(l111l)
        if (l1llll1 != 0):
            raise IOError(l1lllll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111l11, l1llll1))
    def l1l1l(self, l1lll1l1):
        if os.path.exists(l1lll1l1):
            if os.path.islink(l1lll1l1):
                l1lll1l1 = os.readlink(l1lll1l1)
            if os.path.ismount(l1lll1l1):
                return True
        return False
def l111ll1(l11l):
    l1l1 = l11l.replace(l1lllll1 (u"࠭࡜࡝ࠩࠐ"), l1lllll1 (u"ࠧࡠࠩࠑ")).replace(l1lllll1 (u"ࠨ࠱ࠪࠒ"), l1lllll1 (u"ࠩࡢࠫࠓ"))
    l1l1111 = l1lllll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l1ll=os.environ[l1lllll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1111ll=os.path.join(l11l1ll,l1l1111, l1l1)
    l111=os.path.abspath(l1111ll)
    return l111
def l1ll1ll(l1l1l11):
    if not os.path.exists(l1l1l11):
        os.makedirs(l1l1l11)
def l11111(l11l, l11llll, l1lll11=None, password=None):
    l1lllll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l1l11 = l111ll1(l11l)
    l1ll1ll(l1l1l11)
    if not l1lll11:
        l1l11l1 = l1l1lll()
        l1lll1l =l1l11l1.l11l1l1(l1lllll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11llll + l1lllll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11llll + l1lllll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll1l, str):
            l1lll11, password = l1lll1l
        else:
            raise l1()
        logger.info(l1lllll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l1l11))
    l11l11l = pwd.getpwuid( os.getuid())[0]
    l1lll=os.environ[l1lllll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l111l1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l1l={l1lllll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11l, l1lllll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l, l1lllll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l1l11, l1lllll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll, l1lllll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll11, l1lllll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l1l, temp_file)
        if not os.path.exists(os.path.join(l111l1l, l1lllll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1111=l1lllll1 (u"ࠦࡵࡿࠢࠣ")
            key=l1lllll1 (u"ࠧࠨࠤ")
        else:
            l1111=l1lllll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lllll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1ll=l1lllll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1111,temp_file.name)
        l1ll111l=[l1lllll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lllll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l111l1l, l1lll1ll)]
        p = subprocess.Popen(l1ll111l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lllll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lllll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lllll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l1l11
    logger.debug(l1lllll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lllll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lllll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lllll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111=os.path.abspath(l1l1l11)
    logger.debug(l1lllll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111)
    return l111
def l11111l(l11l, l11llll, l11lll1, l1l):
    l1lllll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1l1(title):
        l11lll=30
        if len(title)>l11lll:
            l1ll1l=title.split(l1lllll1 (u"ࠨ࠯ࠣ࠳"))
            l1ll1l1l=l1lllll1 (u"ࠧࠨ࠴")
            for block in l1ll1l:
                l1ll1l1l+=block+l1lllll1 (u"ࠣ࠱ࠥ࠵")
                if len(l1ll1l1l) > l11lll:
                    l1ll1l1l+=l1lllll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll1l1l
        return title
    def l1ll1lll(l1111l, password):
        l1lllll1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lllll1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lllll1 (u"ࠧࠦࠢ࠹").join(l1111l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1111l1 = l1lllll1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1111l1.encode())
        l1ll11 = [l1lllll1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll111 = l1lllll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll111)
            for e in l1ll11:
                if e in l1ll111: return False
            raise l1ll1111(l1ll111, l11111l=l111l1.l1l11l(), l11llll=l11llll)
        logger.info(l1lllll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll11 = l1lllll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lllll1 (u"ࠦࠧ࠿")
    os.system(l1lllll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll1 = l111ll1(l11l)
    l1l1l11 = l111ll1(hashlib.sha1(l11l.encode()).hexdigest()[:10])
    l1ll1ll(l1l1l11)
    logger.info(l1lllll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l1l11))
    if l11lll1:
        l1111l = [l1lllll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lllll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lllll1 (u"ࠤ࠰ࡸࠧࡄ"), l1lllll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lllll1 (u"ࠫ࠲ࡵࠧࡆ"), l1lllll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll11, l11lll1),
                    urllib.parse.unquote(l11llll), os.path.abspath(l1l1l11)]
        l1ll1lll(l1111l, password)
    else:
        while True:
            l1lll11, password = l1l111(l1l1l11, l11llll, l1l)
            if l1lll11.lower() != l1lllll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1111l = [l1lllll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lllll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lllll1 (u"ࠤ࠰ࡸࠧࡋ"), l1lllll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lllll1 (u"ࠫ࠲ࡵࠧࡍ"), l1lllll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll11,
                            urllib.parse.unquote(l11llll), os.path.abspath(l1l1l11)]
            else:
                raise l1()
            if l1ll1lll(l1111l, password): break
    os.system(l1lllll1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l1l11, l1lll1))
    l111=os.path.abspath(l1lll1)
    return l111
def l1l111(l11l, l11llll, l1l):
    l1l11 = os.path.join(os.environ[l1lllll1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lllll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lllll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l11)):
       os.makedirs(os.path.dirname(l1l11))
    l1ll = l1l.get_value(l1lllll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lllll1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l11l1 = l1l1lll(l11l, l1ll)
    l1lll11, password = l1l11l1.l11l1l1(l1lllll1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11llll + l1lllll1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11llll + l1lllll1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll11 != l1lllll1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l1ll1(l11l, l1lll11):
        l1llll11 = l1lllll1 (u"ࠤ࡙ࠣࠦ").join([l11l, l1lll11, l1lllll1 (u"࡚ࠪࠦࠬ") + password + l1lllll1 (u"࡛ࠫࠧ࠭"), l1lllll1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l11, l1lllll1 (u"࠭ࡷࠬࠩ࡝")) as l1ll11ll:
            l1ll11ll.write(l1llll11)
        os.chmod(l1l11, 0o600)
    return l1lll11, password
def l1l1ll1(l11l, l1lll11):
    l1l11 = l1llllll = os.path.join(os.environ[l1lllll1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lllll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lllll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l11):
        with open(l1l11, l1lllll1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l111ll = data[0].split(l1lllll1 (u"ࠦࠥࠨࡢ"))
            if l11l == l111ll[0] and l1lll11 == l111ll[1]:
                return True
    return False