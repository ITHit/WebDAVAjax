#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1llll1 = 2048
l11111l = 7
def l1lll1l (l11):
    global l1l1111
    ll = ord (l11 [-1])
    l1l1ll1 = l11 [:-1]
    l1l1l = ll % len (l1l1ll1)
    l1l1l11 = l1l1ll1 [:l1l1l] + l1l1ll1 [l1l1l:]
    if l1ll1ll1:
        l11l = l1llllll () .join ([unichr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    return eval (l11l)
import re
class l1ll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1lll = kwargs.get(l1lll1l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11l1ll = kwargs.get(l1lll1l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllllll = self.l1lll11ll(args)
        if l1lllllll:
            args=args+ l1lllllll
        self.args = [a for a in args]
    def l1lll11ll(self, *args):
        l1lllllll=None
        l11lll1l = args[0][0]
        if re.search(l1lll1l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11lll1l):
            l1lllllll = (l1lll1l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1lll
                            ,)
        return l1lllllll
class l1llllll1(Exception):
    def __init__(self, *args, **kwargs):
        l1lllllll = self.l1lll11ll(args)
        if l1lllllll:
            args = args + l1lllllll
        self.args = [a for a in args]
    def l1lll11ll(self, *args):
        s = l1lll1l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll1l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll1ll(Exception):
    pass
class l1lll1l1(Exception):
    pass
class l1lll1l1l(Exception):
    def __init__(self, message, l11111ll, url):
        super(l1lll1l1l,self).__init__(message)
        self.l11111ll = l11111ll
        self.url = url
class l1llll111(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1111l11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l111111l(Exception):
    pass
class l1111111(Exception):
    pass
class l111ll11(Exception):
    pass