#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11ll = sys.version_info [0] == 2
l111ll1 = 2048
l1l1l = 7
def l1l1 (l111ll):
    global l1lllll
    l1ll1l1l = ord (l111ll [-1])
    l11llll = l111ll [:-1]
    l1111 = l1ll1l1l % len (l11llll)
    l1llllll = l11llll [:l1111] + l11llll [l1111:]
    if l1ll11ll:
        l1ll1l11 = l11l1l1 () .join ([unichr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    else:
        l1ll1l11 = str () .join ([chr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    return eval (l1ll1l11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1111l=logging.WARNING
logger = logging.getLogger(l1l1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1111l)
l11ll11l = SysLogHandler(address=l1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll11l.setFormatter(formatter)
logger.addHandler(l11ll11l)
ch = logging.StreamHandler()
ch.setLevel(l1lll1111l)
logger.addHandler(ch)
class l1llll11ll(io.FileIO):
    l1l1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1ll1l, l1llll1l11,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll1l = l1lll1ll1l
            self.l1llll1l11 = l1llll1l11
            if not options:
                options = l1l1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1ll1l,
                                              self.l1llll1l11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llllll1l = os.path.join(os.path.sep, l1l1 (u"ࠪࡩࡹࡩࠧই"), l1l1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1lll1 = path
        else:
            self._1lll1lll1 = self.l1llllll1l
        super(l1llll11ll, self).__init__(self._1lll1lll1, l1l1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11ll1(self, line):
        return l1llll11ll.Entry(*[x for x in line.strip(l1l1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1 (u"ࠤࠦࠦ঍")):
                    yield self._1lll11ll1(line)
            except ValueError:
                pass
    def l1lllll1ll(self, attr, value):
        for entry in self.entries:
            l1lll11lll = getattr(entry, attr)
            if l1lll11lll == value:
                return entry
        return None
    def l1lllll111(self, entry):
        if self.l1lllll1ll(l1l1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l1 (u"ࠫࡡࡴࠧএ")).encode(l1l1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1ll1(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1 (u"ࠢࠤࠤ঒")):
                if self._1lll11ll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1 (u"ࠨࠩও").join(lines).encode(l1l1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l11l(cls, l1lll1ll1l, path=None):
        l1lll1llll = cls(path=path)
        entry = l1lll1llll.l1lllll1ll(l1l1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1ll1l)
        if entry:
            return l1lll1llll.l1llll1ll1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll1l, l1llll1l11, options=None, path=None):
        return cls(path=path).l1lllll111(l1llll11ll.Entry(device,
                                                    l1lll1ll1l, l1llll1l11,
                                                    options=options))
class l1llll111l(object):
    def __init__(self, l1lll111ll):
        self.l1lll1l1l1=l1l1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1l1ll=l1l1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll111ll=l1lll111ll
        self.l1lllll11l()
        self.l1llll1l1l()
        self.l1lll1ll11()
        self.l1lll1l111()
        self.l1lll11l1l()
    def l1lllll11l(self):
        temp_file=open(l1lllllll1,l1l1 (u"࠭ࡲࠨঘ"))
        l111l1=temp_file.read()
        data=json.loads(l111l1)
        self.user=data[l1l1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11111=data[l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l111l=data[l1l1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11l11=data[l1l1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11l11=data[l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllll1l1=data[l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1ll11(self):
        l1ll1=os.path.join(l1l1 (u"ࠨ࠯ࠣট"),l1l1 (u"ࠢࡶࡵࡵࠦঠ"),l1l1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll1)
    def l1lll11l1l(self):
        logger.info(l1l1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l111l=os.path.join(self.l11l11,self.l1lll1l1l1)
        l1llllll11 = pwd.getpwnam(self.user).pw_uid
        l1llll11l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l111l):
            os.makedirs(l1l111l)
            os.system(l1l1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l111l))
            logger.debug(l1l1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l111l)
        else:
            logger.debug(l1l1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l111l)
        l1ll1=os.path.join(l1l111l, self.l1lll1l1ll)
        print(l1ll1)
        logger.debug(l1l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll1)
        with open(l1ll1, l1l1 (u"ࠤࡺ࠯ࠧ঩")) as l1lll11111:
            logger.debug(self.l11111 + l1l1 (u"ࠪࠤࠬপ")+self.l1lll11l11+l1l1 (u"ࠫࠥࠨࠧফ")+self.l1lllll1l1+l1l1 (u"ࠬࠨࠧব"))
            l1lll11111.writelines(self.l11111 + l1l1 (u"࠭ࠠࠨভ")+self.l1lll11l11+l1l1 (u"ࠧࠡࠤࠪম")+self.l1lllll1l1+l1l1 (u"ࠨࠤࠪয"))
        os.chmod(l1ll1, 0o600)
        os.chown(l1ll1, l1llllll11, l1llll11l1)
    def l1llll1l1l(self, l1lll111l1=l1l1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll111l1 in groups:
            logger.info(l1l1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll111l1))
        else:
            logger.warning(l1l1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll111l1))
            l1l11l1=l1l1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll111l1,self.user)
            logger.debug(l1l1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l11l1)
            os.system(l1l11l1)
            logger.debug(l1l1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l111(self):
        logger.debug(l1l1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1llll=l1llll11ll()
        l1lll1llll.add(self.l11111, self.l1l111l, l1llll1l11=l1l1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllllll1 = urllib.parse.unquote(sys.argv[1])
        if l1lllllll1:
            l1llll1111=l1llll111l(l1lllllll1)
        else:
            raise (l1l1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise