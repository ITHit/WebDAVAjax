#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111l1 = 2048
l1l11l = 7
def l1ll1ll (l11111l):
    global l1ll1
    l1ll1111 = ord (l11111l [-1])
    l11ll1l = l11111l [:-1]
    l11llll = l1ll1111 % len (l11ll1l)
    l1lll111 = l11ll1l [:l11llll] + l11ll1l [l11llll:]
    if l1lll1:
        l1ll11l = l11111 () .join ([unichr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    else:
        l1ll11l = str () .join ([chr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    return eval (l1ll11l)
import hashlib
import os
import l1l11
from l1l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l11 import l11l11l
from l1l1ll import l1ll1l1, l1ll111
import logging
logger = logging.getLogger(l1ll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l111():
    def __init__(self, l1ll11,l1l1ll1, l1l111l= None, l1llll=None):
        self.l11ll=False
        self.l1ll1ll1 = self._1lll()
        self.l1l1ll1 = l1l1ll1
        self.l1l111l = l1l111l
        self.l111l1l = l1ll11
        if l1l111l:
            self.l11lll1 = True
        else:
            self.l11lll1 = False
        self.l1llll = l1llll
    def _1lll(self):
        try:
            return l1l11.l11l11() is not None
        except:
            return False
    def open(self):
        l1ll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1ll1:
            raise NotImplementedError(l1ll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1l = self.l111l1l
        if self.l1l1ll1.lower().startswith(self.l111l1l.lower()):
            l1lllll = re.compile(re.escape(self.l111l1l), re.IGNORECASE)
            l1l1ll1 = l1lllll.sub(l1ll1ll (u"ࠨࠩࠄ"), self.l1l1ll1)
            l1l1ll1 = l1l1ll1.replace(l1ll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l111ll(self.l111l1l, l1ll1l, l1l1ll1, self.l1l111l)
    def l111ll(self,l111l1l, l1ll1l, l1l1ll1, l1l111l):
        l1ll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l = l111l(l111l1l)
        l1lll11 = self.l1(l1l)
        logger.info(l1ll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l)
        if l1lll11:
            logger.info(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l11l(l1l)
            l1l = l1l1111(l111l1l, l1ll1l, l1l111l, self.l1llll)
        logger.debug(l1ll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1lll=l1l + l1ll1ll (u"ࠤ࠲ࠦࠌ") + l1l1ll1
        l1ll11ll = l1ll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1lll+ l1ll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll11ll)
        ll = os.system(l1ll11ll)
        if (ll != 0):
            raise IOError(l1ll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1lll, ll))
    def l1(self, l1l):
        if os.path.exists(l1l):
            if os.path.islink(l1l):
                l1l = os.readlink(l1l)
            if os.path.ismount(l1l):
                return True
        return False
def l111l(l111l1l):
    l1ll1l11 = l111l1l.replace(l1ll1ll (u"࠭࡜࡝ࠩࠐ"), l1ll1ll (u"ࠧࡠࠩࠑ")).replace(l1ll1ll (u"ࠨ࠱ࠪࠒ"), l1ll1ll (u"ࠩࡢࠫࠓ"))
    l1l11ll = l1ll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1111l=os.environ[l1ll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llll1=os.path.join(l1111l,l1l11ll, l1ll1l11)
    l1l1l=os.path.abspath(l1llll1)
    return l1l1l
def l11l1ll(l1l111):
    if not os.path.exists(l1l111):
        os.makedirs(l1l111)
def l11l(l111l1l, l1ll1l, l1l1lll=None, password=None):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l111 = l111l(l111l1l)
    l11l1ll(l1l111)
    if not l1l1lll:
        l111lll = l1111ll()
        l1lll11l =l111lll.l1llllll(l1ll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1l + l1ll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1l + l1ll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll11l, str):
            l1l1lll, password = l1lll11l
        else:
            raise l1ll111()
        logger.info(l1ll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l111))
    l11 = pwd.getpwuid( os.getuid())[0]
    l11ll1=os.environ[l1ll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l1l1l={l1ll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11, l1ll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111l1l, l1ll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l111, l1ll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11ll1, l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1lll, l1ll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l1l1l, temp_file)
        if not os.path.exists(os.path.join(l11l1l, l1ll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll11l1=l1ll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1ll (u"ࠧࠨࠤ")
        else:
            l1ll11l1=l1ll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1l1=l1ll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll11l1,temp_file.name)
        l1lllll1=[l1ll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l1l, l1lll1l1)]
        p = subprocess.Popen(l1lllll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l111
    logger.debug(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1l=os.path.abspath(l1l111)
    logger.debug(l1ll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1l)
    return l1l1l
def l1l1111(l111l1l, l1ll1l, l1l111l, l1llll):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l1l1(title):
        l1llll1l=30
        if len(title)>l1llll1l:
            l111ll1=title.split(l1ll1ll (u"ࠨ࠯ࠣ࠳"))
            l11ll11=l1ll1ll (u"ࠧࠨ࠴")
            for block in l111ll1:
                l11ll11+=block+l1ll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l11ll11) > l1llll1l:
                    l11ll11+=l1ll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11ll11
        return title
    def l1111l1(l1lll1l, password):
        l1ll1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1ll (u"ࠧࠦࠢ࠹").join(l1lll1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l11l1 = l1ll1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l11l1.encode())
        l1ll = [l1ll1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l111l11 = l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l111l11)
            for e in l1ll:
                if e in l111l11: return False
            raise l1ll1l1(l111l11, l1l1111=l1l11.l11l11(), l1ll1l=l1ll1l)
        logger.info(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l1lll = l1ll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1ll (u"ࠦࠧ࠿")
    os.system(l1ll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l1l11 = l111l(l111l1l)
    l1l111 = l111l(hashlib.sha1(l111l1l.encode()).hexdigest()[:10])
    l11l1ll(l1l111)
    logger.info(l1ll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l111))
    if l1l111l:
        l1lll1l = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l1lll, l1l111l),
                    urllib.parse.unquote(l1ll1l), os.path.abspath(l1l111)]
        l1111l1(l1lll1l, password)
    else:
        while True:
            l1l1lll, password = l1ll111l(l1l111, l1ll1l, l1llll)
            if l1l1lll.lower() != l1ll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1lll1l = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡋ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡍ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l1lll,
                            urllib.parse.unquote(l1ll1l), os.path.abspath(l1l111)]
            else:
                raise l1ll111()
            if l1111l1(l1lll1l, password): break
    os.system(l1ll1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l111, l1l1l11))
    l1l1l=os.path.abspath(l1l1l11)
    return l1l1l
def l1ll111l(l111l1l, l1ll1l, l1llll):
    l11l1 = os.path.join(os.environ[l1ll1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l1)):
       os.makedirs(os.path.dirname(l11l1))
    l11lll = l1llll.get_value(l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l111lll = l1111ll(l111l1l, l11lll)
    l1l1lll, password = l111lll.l1llllll(l1ll1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1l + l1ll1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1l + l1ll1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l1lll != l1ll1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111111(l111l1l, l1l1lll):
        l1lll1ll = l1ll1ll (u"ࠤ࡙ࠣࠦ").join([l111l1l, l1l1lll, l1ll1ll (u"࡚ࠪࠦࠬ") + password + l1ll1ll (u"࡛ࠫࠧ࠭"), l1ll1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l1, l1ll1ll (u"࠭ࡷࠬࠩ࡝")) as l1ll1l1l:
            l1ll1l1l.write(l1lll1ll)
        os.chmod(l11l1, 0o600)
    return l1l1lll, password
def l111111(l111l1l, l1l1lll):
    l11l1 = l1llll11 = os.path.join(os.environ[l1ll1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l1):
        with open(l11l1, l1ll1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l111 = data[0].split(l1ll1ll (u"ࠦࠥࠨࡢ"))
            if l111l1l == l111[0] and l1l1lll == l111[1]:
                return True
    return False