#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll1l = 2048
l1lll111 = 7
def l11l (l1l11ll):
    global l11llll
    l1l1l1 = ord (l1l11ll [-1])
    l1ll1l1 = l1l11ll [:-1]
    l111 = l1l1l1 % len (l1ll1l1)
    l1l1ll = l1ll1l1 [:l111] + l1ll1l1 [l111:]
    if l1ll111:
        l1111l1 = l11ll11 () .join ([unichr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    return eval (l1111l1)
import hashlib
import os
import l1llll
from l11l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1llll import l11111
from l111ll import l1llll1, l1l11l1
import logging
logger = logging.getLogger(l11l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l11():
    def __init__(self, l11lll1,l1l111l, l111l1= None, l11l1ll=None):
        self.ll=False
        self.l1l1111 = self._1ll11ll()
        self.l1l111l = l1l111l
        self.l111l1 = l111l1
        self.l1llll1l = l11lll1
        if l111l1:
            self.l111l = True
        else:
            self.l111l = False
        self.l11l1ll = l11l1ll
    def _1ll11ll(self):
        try:
            return l1llll.l1ll111l() is not None
        except:
            return False
    def open(self):
        l11l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1111:
            raise NotImplementedError(l11l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l111111 = self.l1llll1l
        if self.l1l111l.lower().startswith(self.l1llll1l.lower()):
            l11111l = re.compile(re.escape(self.l1llll1l), re.IGNORECASE)
            l1l111l = l11111l.sub(l11l (u"ࠨࠩࠄ"), self.l1l111l)
            l1l111l = l1l111l.replace(l11l (u"ࠩࡧࡥࡻ࠭ࠅ"), l11l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll1ll(self.l1llll1l, l111111, l1l111l, self.l111l1)
    def l1lll1ll(self,l1llll1l, l111111, l1l111l, l111l1):
        l11l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111lll = l1l1l(l1llll1l)
        l111ll1 = self.l11l1l1(l111lll)
        logger.info(l11l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111lll)
        if l111ll1:
            logger.info(l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11111(l111lll)
            l111lll = l1l1(l1llll1l, l111111, l111l1, self.l11l1ll)
        logger.debug(l11l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1l11=l111lll + l11l (u"ࠤ࠲ࠦࠌ") + l1l111l
        l1ll1111 = l11l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1l11+ l11l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1111)
        l1ll = os.system(l1ll1111)
        if (l1ll != 0):
            raise IOError(l11l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1l11, l1ll))
    def l11l1l1(self, l111lll):
        if os.path.exists(l111lll):
            if os.path.islink(l111lll):
                l111lll = os.readlink(l111lll)
            if os.path.ismount(l111lll):
                return True
        return False
def l1l1l(l1llll1l):
    l1llllll = l1llll1l.replace(l11l (u"࠭࡜࡝ࠩࠐ"), l11l (u"ࠧࡠࠩࠑ")).replace(l11l (u"ࠨ࠱ࠪࠒ"), l11l (u"ࠩࡢࠫࠓ"))
    l1ll1 = l11l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l111=os.environ[l11l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1l11=os.path.join(l1l111,l1ll1, l1llllll)
    l1l11=os.path.abspath(l1l1l11)
    return l1l11
def l1111l(l1ll11l1):
    if not os.path.exists(l1ll11l1):
        os.makedirs(l1ll11l1)
def l1ll1ll(l1llll1l, l111111, l1l=None, password=None):
    l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll11l1 = l1l1l(l1llll1l)
    l1111l(l1ll11l1)
    if not l1l:
        l1111 = l11lll()
        l11l11l =l1111.l1lllll1(l11l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l111111 + l11l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l111111 + l11l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l11l, str):
            l1l, password = l11l11l
        else:
            raise l1l11l1()
        logger.info(l11l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll11l1))
    l11 = pwd.getpwuid( os.getuid())[0]
    l111l11=os.environ[l11l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1l1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll11l={l11l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11, l11l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1llll1l, l11l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll11l1, l11l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l111l11, l11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l, l11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll11l, temp_file)
        if not os.path.exists(os.path.join(l1l1l1l, l11l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lllll=l11l (u"ࠦࡵࡿࠢࠣ")
            key=l11l (u"ࠧࠨࠤ")
        else:
            l1lllll=l11l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11ll1=l11l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lllll,temp_file.name)
        l1lll1l1=[l11l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1l1l, l11ll1)]
        p = subprocess.Popen(l1lll1l1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll11l1
    logger.debug(l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l11=os.path.abspath(l1ll11l1)
    logger.debug(l11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l11)
    return l1l11
def l1l1(l1llll1l, l111111, l111l1, l11l1ll):
    l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1l1l(title):
        l1ll1ll1=30
        if len(title)>l1ll1ll1:
            l1ll1lll=title.split(l11l (u"ࠨ࠯ࠣ࠳"))
            l11ll1l=l11l (u"ࠧࠨ࠴")
            for block in l1ll1lll:
                l11ll1l+=block+l11l (u"ࠣ࠱ࠥ࠵")
                if len(l11ll1l) > l1ll1ll1:
                    l11ll1l+=l11l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11ll1l
        return title
    def l111l1l(l1ll1l, password):
        l11l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11l (u"ࠧࠦࠢ࠹").join(l1ll1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1111ll = l11l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1111ll.encode())
        l11l1l = [l11l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll11 = l11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll11)
            for e in l11l1l:
                if e in l1lll11: return False
            raise l1llll1(l1lll11, l1l1=l1llll.l1ll111l(), l111111=l111111)
        logger.info(l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l = l11l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11l (u"ࠦࠧ࠿")
    os.system(l11l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l1ll1 = l1l1l(l1llll1l)
    l1ll11l1 = l1l1l(hashlib.sha1(l1llll1l.encode()).hexdigest()[:10])
    l1111l(l1ll11l1)
    logger.info(l11l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll11l1))
    if l111l1:
        l1ll1l = [l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11l (u"ࠤ࠰ࡸࠧࡄ"), l11l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11l (u"ࠫ࠲ࡵࠧࡆ"), l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l, l111l1),
                    urllib.parse.unquote(l111111), os.path.abspath(l1ll11l1)]
        l111l1l(l1ll1l, password)
    else:
        while True:
            l1l, password = l1lll(l1ll11l1, l111111, l11l1ll)
            if l1l.lower() != l11l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll1l = [l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11l (u"ࠤ࠰ࡸࠧࡋ"), l11l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11l (u"ࠫ࠲ࡵࠧࡍ"), l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l,
                            urllib.parse.unquote(l111111), os.path.abspath(l1ll11l1)]
            else:
                raise l1l11l1()
            if l111l1l(l1ll1l, password): break
    os.system(l11l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll11l1, l1l1ll1))
    l1l11=os.path.abspath(l1l1ll1)
    return l1l11
def l1lll(l1llll1l, l111111, l11l1ll):
    l1ll11l = os.path.join(os.environ[l11l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll11l)):
       os.makedirs(os.path.dirname(l1ll11l))
    l1lll1 = l11l1ll.get_value(l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1111 = l11lll(l1llll1l, l1lll1)
    l1l, password = l1111.l1lllll1(l11l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l111111 + l11l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l111111 + l11l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l != l11l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1(l1llll1l, l1l):
        l1ll11 = l11l (u"ࠤ࡙ࠣࠦ").join([l1llll1l, l1l, l11l (u"࡚ࠪࠦࠬ") + password + l11l (u"࡛ࠫࠧ࠭"), l11l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll11l, l11l (u"࠭ࡷࠬࠩ࡝")) as l11l111:
            l11l111.write(l1ll11)
        os.chmod(l1ll11l, 0o600)
    return l1l, password
def l1(l1llll1l, l1l):
    l1ll11l = l1llll11 = os.path.join(os.environ[l11l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll11l):
        with open(l1ll11l, l11l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l1lll = data[0].split(l11l (u"ࠦࠥࠨࡢ"))
            if l1llll1l == l1l1lll[0] and l1l == l1l1lll[1]:
                return True
    return False