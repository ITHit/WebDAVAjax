#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1llll1l = 7
def l1lllll1 (l11ll1l):
    global l1l1ll
    l1ll1 = ord (l11ll1l [-1])
    l1l11ll = l11ll1l [:-1]
    l111111 = l1ll1 % len (l1l11ll)
    l1ll11l1 = l1l11ll [:l111111] + l1l11ll [l111111:]
    if l11ll1:
        l1lllll = l11l111 () .join ([unichr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    else:
        l1lllll = str () .join ([chr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    return eval (l1lllll)
import re
class l1ll1111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllll11 = kwargs.get(l1lllll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11llll = kwargs.get(l1lllll1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llllll1 = self.l1lllll1l(args)
        if l1llllll1:
            args=args+ l1llllll1
        self.args = [a for a in args]
    def l1lllll1l(self, *args):
        l1llllll1=None
        l11lll1l = args[0][0]
        if re.search(l1lllll1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11lll1l):
            l1llllll1 = (l1lllll1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lllll11
                            ,)
        return l1llllll1
class l11111ll(Exception):
    def __init__(self, *args, **kwargs):
        l1llllll1 = self.l1lllll1l(args)
        if l1llllll1:
            args = args + l1llllll1
        self.args = [a for a in args]
    def l1lllll1l(self, *args):
        s = l1lllll1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lllll1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll11ll(Exception):
    pass
class l1(Exception):
    pass
class l1111111(Exception):
    def __init__(self, message, l1lll1lll, url):
        super(l1111111,self).__init__(message)
        self.l1lll1lll = l1lll1lll
        self.url = url
class l1llll11l(Exception):
    pass
class l111111l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1111l11(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111llll(Exception):
    pass