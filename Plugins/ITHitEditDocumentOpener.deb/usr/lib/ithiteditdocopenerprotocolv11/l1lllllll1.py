#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1llll1 = 2048
l11111l = 7
def l1lll1l (l11):
    global l1l1111
    ll = ord (l11 [-1])
    l1l1ll1 = l11 [:-1]
    l1l1l = ll % len (l1l1ll1)
    l1l1l11 = l1l1ll1 [:l1l1l] + l1l1ll1 [l1l1l:]
    if l1ll1ll1:
        l11l = l1llllll () .join ([unichr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    return eval (l11l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11l11=logging.WARNING
logger = logging.getLogger(l1lll1l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11l11)
l11lll11 = SysLogHandler(address=l1lll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll1l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11lll11.setFormatter(formatter)
logger.addHandler(l11lll11)
ch = logging.StreamHandler()
ch.setLevel(l1lll11l11)
logger.addHandler(ch)
class l1lll11l1l(io.FileIO):
    l1lll1l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll1l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1ll1l, l1lllll1ll,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll1l = l1lll1ll1l
            self.l1lllll1ll = l1lllll1ll
            if not options:
                options = l1lll1l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1ll1l,
                                              self.l1lllll1ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11ll1 = os.path.join(os.path.sep, l1lll1l (u"ࠪࡩࡹࡩࠧই"), l1lll1l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1llll = path
        else:
            self._1lll1llll = self.l1lll11ll1
        super(l1lll11l1l, self).__init__(self._1lll1llll, l1lll1l (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l1l(self, line):
        return l1lll11l1l.Entry(*[x for x in line.strip(l1lll1l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll1l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1l (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l1l(line)
            except ValueError:
                pass
    def l1lll1l111(self, attr, value):
        for entry in self.entries:
            l1llll11l1 = getattr(entry, attr)
            if l1llll11l1 == value:
                return entry
        return None
    def l1lll1l11l(self, entry):
        if self.l1lll1l111(l1lll1l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll1l (u"ࠫࡡࡴࠧএ")).encode(l1lll1l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll111l(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1l (u"ࠢࠤࠤ঒")):
                if self._1llll1l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1l (u"ࠨࠩও").join(lines).encode(l1lll1l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll11(cls, l1lll1ll1l, path=None):
        l1llllll11 = cls(path=path)
        entry = l1llllll11.l1lll1l111(l1lll1l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1ll1l)
        if entry:
            return l1llllll11.l1llll111l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll1l, l1lllll1ll, options=None, path=None):
        return cls(path=path).l1lll1l11l(l1lll11l1l.Entry(device,
                                                    l1lll1ll1l, l1lllll1ll,
                                                    options=options))
class l1lllll111(object):
    def __init__(self, l1lllll1l1):
        self.l1llll1lll=l1lll1l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll1l11=l1lll1l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll1l1=l1lllll1l1
        self.l1llll1111()
        self.l1lll11111()
        self.l1lll1111l()
        self.l1llllll1l()
        self.l1lll1lll1()
    def l1llll1111(self):
        temp_file=open(l1llll11ll,l1lll1l (u"࠭ࡲࠨঘ"))
        l1l11l=temp_file.read()
        data=json.loads(l1l11l)
        self.user=data[l1lll1l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l111=data[l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11l1=data[l1lll1l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1111=data[l1lll1l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll11l=data[l1lll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1ll1=data[l1lll1l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1111l(self):
        l1l11ll=os.path.join(l1lll1l (u"ࠨ࠯ࠣট"),l1lll1l (u"ࠢࡶࡵࡵࠦঠ"),l1lll1l (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll1l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll1l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l11ll)
    def l1lll1lll1(self):
        logger.info(l1lll1l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11l1=os.path.join(self.l1111,self.l1llll1lll)
        l1lll11lll = pwd.getpwnam(self.user).pw_uid
        l1lll1l1l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l1):
            os.makedirs(l11l1)
            os.system(l1lll1l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11l1))
            logger.debug(l1lll1l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11l1)
        else:
            logger.debug(l1lll1l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11l1)
        l1l11ll=os.path.join(l11l1, self.l1llll1l11)
        print(l1l11ll)
        logger.debug(l1lll1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l11ll)
        with open(l1l11ll, l1lll1l (u"ࠤࡺ࠯ࠧ঩")) as l1lll111ll:
            logger.debug(self.l1l111 + l1lll1l (u"ࠪࠤࠬপ")+self.l1lllll11l+l1lll1l (u"ࠫࠥࠨࠧফ")+self.l1llll1ll1+l1lll1l (u"ࠬࠨࠧব"))
            l1lll111ll.writelines(self.l1l111 + l1lll1l (u"࠭ࠠࠨভ")+self.l1lllll11l+l1lll1l (u"ࠧࠡࠤࠪম")+self.l1llll1ll1+l1lll1l (u"ࠨࠤࠪয"))
        os.chmod(l1l11ll, 0o600)
        os.chown(l1l11ll, l1lll11lll, l1lll1l1l1)
    def l1lll11111(self, l1lll111l1=l1lll1l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll1l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll111l1 in groups:
            logger.info(l1lll1l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll111l1))
        else:
            logger.warning(l1lll1l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll111l1))
            l111l=l1lll1l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll111l1,self.user)
            logger.debug(l1lll1l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l111l)
            os.system(l111l)
            logger.debug(l1lll1l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llllll1l(self):
        logger.debug(l1lll1l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llllll11=l1lll11l1l()
        l1llllll11.add(self.l1l111, self.l11l1, l1lllll1ll=l1lll1l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll1l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll1l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll11ll = urllib.parse.unquote(sys.argv[1])
        if l1llll11ll:
            l1lll1l1ll=l1lllll111(l1llll11ll)
        else:
            raise (l1lll1l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll1l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise