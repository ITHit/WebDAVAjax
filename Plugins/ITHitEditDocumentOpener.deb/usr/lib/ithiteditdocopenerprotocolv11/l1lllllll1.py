#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllll111=logging.WARNING
logger = logging.getLogger(l1l1l1l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lllll111)
l11ll111 = SysLogHandler(address=l1l1l1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l1l1l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll111.setFormatter(formatter)
logger.addHandler(l11ll111)
ch = logging.StreamHandler()
ch.setLevel(l1lllll111)
logger.addHandler(ch)
class l1lll1l1ll(io.FileIO):
    l1l1l1l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l1l1l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1111l, l1lllll11l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1111l = l1lll1111l
            self.l1lllll11l = l1lllll11l
            if not options:
                options = l1l1l1l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1l1l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1111l,
                                              self.l1lllll11l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll1l = os.path.join(os.path.sep, l1l1l1l (u"ࠪࡩࡹࡩࠧই"), l1l1l1l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1lll1 = path
        else:
            self._1lll1lll1 = self.l1lll1ll1l
        super(l1lll1l1ll, self).__init__(self._1lll1lll1, l1l1l1l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1llll(self, line):
        return l1lll1l1ll.Entry(*[x for x in line.strip(l1l1l1l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l1l1l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1l1l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1l1l (u"ࠤࠦࠦ঍")):
                    yield self._1lll1llll(line)
            except ValueError:
                pass
    def l1llll1l1l(self, attr, value):
        for entry in self.entries:
            l1lll11lll = getattr(entry, attr)
            if l1lll11lll == value:
                return entry
        return None
    def l1llll1lll(self, entry):
        if self.l1llll1l1l(l1l1l1l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l1l1l (u"ࠫࡡࡴࠧএ")).encode(l1l1l1l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1l1l1(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1l1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1l1l (u"ࠢࠤࠤ঒")):
                if self._1lll1llll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1l1l (u"ࠨࠩও").join(lines).encode(l1l1l1l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llll1l11(cls, l1lll1111l, path=None):
        l1lll11l1l = cls(path=path)
        entry = l1lll11l1l.l1llll1l1l(l1l1l1l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1111l)
        if entry:
            return l1lll11l1l.l1lll1l1l1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1111l, l1lllll11l, options=None, path=None):
        return cls(path=path).l1llll1lll(l1lll1l1ll.Entry(device,
                                                    l1lll1111l, l1lllll11l,
                                                    options=options))
class l1lll1ll11(object):
    def __init__(self, l1llll1111):
        self.l1llllll11=l1l1l1l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll11ll=l1l1l1l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll1111=l1llll1111
        self.l1lll111l1()
        self.l1llllll1l()
        self.l1lll1l11l()
        self.l1llll11l1()
        self.l1lll11l11()
    def l1lll111l1(self):
        temp_file=open(l1lll1l111,l1l1l1l (u"࠭ࡲࠨঘ"))
        l1l11l=temp_file.read()
        data=json.loads(l1l11l)
        self.user=data[l1l1l1l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l1ll=data[l1l1l1l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l111l1l=data[l1l1l1l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1lllll1=data[l1l1l1l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll1ll=data[l1l1l1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111ll=data[l1l1l1l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l11l(self):
        l1l11l1=os.path.join(l1l1l1l (u"ࠨ࠯ࠣট"),l1l1l1l (u"ࠢࡶࡵࡵࠦঠ"),l1l1l1l (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l1l1l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l1l1l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l11l1)
    def l1lll11l11(self):
        logger.info(l1l1l1l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l111l1l=os.path.join(self.l1lllll1,self.l1llllll11)
        l1lll11111 = pwd.getpwnam(self.user).pw_uid
        l1llll1ll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l111l1l):
            os.makedirs(l111l1l)
            os.system(l1l1l1l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l111l1l))
            logger.debug(l1l1l1l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l111l1l)
        else:
            logger.debug(l1l1l1l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l111l1l)
        l1l11l1=os.path.join(l111l1l, self.l1llll11ll)
        print(l1l11l1)
        logger.debug(l1l1l1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l11l1)
        with open(l1l11l1, l1l1l1l (u"ࠤࡺ࠯ࠧ঩")) as l1lll11ll1:
            logger.debug(self.l1l1ll + l1l1l1l (u"ࠪࠤࠬপ")+self.l1lllll1ll+l1l1l1l (u"ࠫࠥࠨࠧফ")+self.l1lll111ll+l1l1l1l (u"ࠬࠨࠧব"))
            l1lll11ll1.writelines(self.l1l1ll + l1l1l1l (u"࠭ࠠࠨভ")+self.l1lllll1ll+l1l1l1l (u"ࠧࠡࠤࠪম")+self.l1lll111ll+l1l1l1l (u"ࠨࠤࠪয"))
        os.chmod(l1l11l1, 0o600)
        os.chown(l1l11l1, l1lll11111, l1llll1ll1)
    def l1llllll1l(self, l1llll111l=l1l1l1l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l1l1l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll111l in groups:
            logger.info(l1l1l1l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll111l))
        else:
            logger.warning(l1l1l1l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll111l))
            l1111ll=l1l1l1l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll111l,self.user)
            logger.debug(l1l1l1l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1111ll)
            os.system(l1111ll)
            logger.debug(l1l1l1l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll11l1(self):
        logger.debug(l1l1l1l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll11l1l=l1lll1l1ll()
        l1lll11l1l.add(self.l1l1ll, self.l111l1l, l1lllll11l=l1l1l1l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l1l1l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l1l1l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1l111 = urllib.parse.unquote(sys.argv[1])
        if l1lll1l111:
            l1lllll1l1=l1lll1ll11(l1lll1l111)
        else:
            raise (l1l1l1l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l1l1l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise