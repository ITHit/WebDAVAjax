#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll11l = 2048
l111 = 7
def l1l1 (l1ll1l11):
    global l11l11l
    l1111l = ord (l1ll1l11 [-1])
    l1111 = l1ll1l11 [:-1]
    l1lll1l = l1111l % len (l1111)
    l1llll11 = l1111 [:l1lll1l] + l1111 [l1lll1l:]
    if l11ll:
        l1lll1l1 = l111lll () .join ([unichr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    else:
        l1lll1l1 = str () .join ([chr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    return eval (l1lll1l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11111 import l1ll1ll
from configobj import ConfigObj
l1l11lll = l1l1 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1ll1l = l1l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠷࠵࠲࠵ࠨࡤ")
l11lll11 = l1l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l1 (u"ࠣ࠸࠱࠴࠳࠾࠷࠶࠴࠱࠴ࠧࡦ")
l1l1l1ll=os.path.join(os.environ.get(l1l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11lll11.replace(l1l1 (u"ࠦࠥࠨࡩ"), l1l1 (u"ࠧࡥࠢࡪ")).lower())
l11lll1l=os.environ.get(l1l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1lll1=l1l1ll1l.replace(l1l1 (u"ࠣࠢࠥ࡭"), l1l1 (u"ࠤࡢࠦ࡮"))+l1l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11lllll=os.path.join(os.environ.get(l1l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1lll1)
elif platform.system() == l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l11111=l1ll1ll(l1l1l1ll+l1l1 (u"ࠢ࠰ࠤࡳ"))
    l11lllll = os.path.join(l1l11111, l1l1lll1)
else:
    l11lllll = os.path.join( l1l1lll1)
l11lll1l=l11lll1l.upper()
if l11lll1l == l1l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11ll11l=logging.DEBUG
elif l11lll1l == l1l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11ll11l = logging.INFO
elif l11lll1l == l1l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11ll11l = logging.WARNING
elif l11lll1l == l1l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11ll11l = logging.ERROR
elif l11lll1l == l1l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11ll11l = logging.CRITICAL
elif l11lll1l == l1l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11ll11l = logging.NOTSET
logger = logging.getLogger(l1l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11ll11l)
l1l1ll11 = logging.FileHandler(l11lllll, mode=l1l1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1ll11.setLevel(l11ll11l)
formatter = logging.Formatter(l1l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1ll11.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll11l)
l11llll1 = SysLogHandler(address=l1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11llll1.setFormatter(formatter)
logger.addHandler(l1l1ll11)
logger.addHandler(ch)
logger.addHandler(l11llll1)
class Settings():
    l1l11ll1 = l1l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1l11l = l1l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11l1lll = l1l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1ll1l):
        self.l1l111ll = self._1l1l1l1(l1l1ll1l)
        self._11ll1l1()
    def _1l1l1l1(self, l1l1ll1l):
        l1l11l1l = l1l1ll1l.split(l1l1 (u"ࠣࠢࠥࢂ"))
        l1l11l1l = l1l1 (u"ࠤࠣࠦࢃ").join(l1l11l1l)
        if platform.system() == l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l111ll = os.path.join(l1l1l1ll, l1l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11l1l + l1l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l111ll
    def l1l11l11(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l111l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll1ll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll1l1(self):
        if not os.path.exists(os.path.dirname(self.l1l111ll)):
            os.makedirs(os.path.dirname(self.l1l111ll))
        if not os.path.exists(self.l1l111ll):
            self.config = ConfigObj(self.l1l111ll)
            self.config[l1l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11l1lll
            self.config[l1l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1l11l
            self.config[l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l11ll1
            self.config[l1l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l111ll)
            self.l11l1lll = self.get_value(l1l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1l11l = self.get_value(l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l11ll1 = self.get_value(l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1llll(self):
        l1l1111l = l1l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l11ll1
        l1l1111l += l1l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1l11l
        l1l1111l += l1l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11l1lll
        return l1l1111l
    def __unicode__(self):
        return self._1l1llll()
    def __str__(self):
        return self._1l1llll()
    def __del__(self):
        self.config.write()
l11ll111 = Settings(l1l1ll1l)