#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11l = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l111 (l11lll):
    global l1ll111
    l11l1l = ord (l11lll [-1])
    l1l11l1 = l11lll [:-1]
    l1ll1l = l11l1l % len (l1l11l1)
    l1lll111 = l1l11l1 [:l1ll1l] + l1l11l1 [l1ll1l:]
    if l11l11l:
        l111 = l1l11 () .join ([unichr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    else:
        l111 = str () .join ([chr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    return eval (l111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1111l1 import l11l
from configobj import ConfigObj
l11lll11 = l1l111 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l11ll11l = l1l111 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠺࠳࠶࠲࠵ࠨࡤ")
l1l11111 = l1l111 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l111 (u"ࠣ࠸࠱࠴࠳࠾࠹࠲࠵࠱࠴ࠧࡦ")
l1l1ll1l=os.path.join(os.environ.get(l1l111 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l111 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11111.replace(l1l111 (u"ࠦࠥࠨࡩ"), l1l111 (u"ࠧࡥࠢࡪ")).lower())
l1l1l11l=os.environ.get(l1l111 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l11lll=l11ll11l.replace(l1l111 (u"ࠣࠢࠥ࡭"), l1l111 (u"ࠤࡢࠦ࡮"))+l1l111 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll1l1=os.path.join(os.environ.get(l1l111 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l11lll)
elif platform.system() == l1l111 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l111ll=l11l(l1l1ll1l+l1l111 (u"ࠢ࠰ࠤࡳ"))
    l11ll1l1 = os.path.join(l1l111ll, l1l11lll)
else:
    l11ll1l1 = os.path.join( l1l11lll)
l1l1l11l=l1l1l11l.upper()
if l1l1l11l == l1l111 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11l11=logging.DEBUG
elif l1l1l11l == l1l111 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11l11 = logging.INFO
elif l1l1l11l == l1l111 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11l11 = logging.WARNING
elif l1l1l11l == l1l111 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11l11 = logging.ERROR
elif l1l1l11l == l1l111 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11l11 = logging.CRITICAL
elif l1l1l11l == l1l111 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11l11 = logging.NOTSET
logger = logging.getLogger(l1l111 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11l11)
l1l1lll1 = logging.FileHandler(l11ll1l1, mode=l1l111 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1lll1.setLevel(l1l11l11)
formatter = logging.Formatter(l1l111 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l111 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1lll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11l11)
l11ll1ll = SysLogHandler(address=l1l111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l1l1lll1)
logger.addHandler(ch)
logger.addHandler(l11ll1ll)
class Settings():
    l1l1llll = l1l111 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11l1lll = l1l111 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11lll1l = l1l111 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11ll11l):
        self.l1l1l1ll = self._1l1111l(l11ll11l)
        self._1l1ll11()
    def _1l1111l(self, l11ll11l):
        l1l1l1l1 = l11ll11l.split(l1l111 (u"ࠣࠢࠥࢂ"))
        l1l1l1l1 = l1l111 (u"ࠤࠣࠦࢃ").join(l1l1l1l1)
        if platform.system() == l1l111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l1ll = os.path.join(l1l1ll1l, l1l111 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l1l1 + l1l111 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l1ll
    def l1l11ll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11llll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l111 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l111 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1ll11(self):
        if not os.path.exists(os.path.dirname(self.l1l1l1ll)):
            os.makedirs(os.path.dirname(self.l1l1l1ll))
        if not os.path.exists(self.l1l1l1ll):
            self.config = ConfigObj(self.l1l1l1ll)
            self.config[l1l111 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l111 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l111 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11lll1l
            self.config[l1l111 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11l1lll
            self.config[l1l111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1llll
            self.config[l1l111 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l1ll)
            self.l11lll1l = self.get_value(l1l111 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l111 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11l1lll = self.get_value(l1l111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1llll = self.get_value(l1l111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l111l1(self):
        l11lllll = l1l111 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1llll
        l11lllll += l1l111 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11l1lll
        l11lllll += l1l111 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11lll1l
        return l11lllll
    def __unicode__(self):
        return self._1l111l1()
    def __str__(self):
        return self._1l111l1()
    def __del__(self):
        self.config.write()
l1l11l1l = Settings(l11ll11l)