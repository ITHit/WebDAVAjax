#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l1lllll1 = 2048
l1lll1 = 7
def l1ll1ll (l11l1ll):
    global l11l1l
    l1llllll = ord (l11l1ll [-1])
    l111111 = l11l1ll [:-1]
    l1ll1ll1 = l1llllll % len (l111111)
    l1l1ll = l111111 [:l1ll1ll1] + l111111 [l1ll1ll1:]
    if l1lllll:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    return eval (l1111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111lll import l1111l1
from configobj import ConfigObj
l1l11l11 = l1ll1ll (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1llll = l1ll1ll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠵࠹࠲࠵ࠨࡤ")
l11ll111 = l1ll1ll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll1ll (u"ࠣ࠸࠱࠴࠳࠾࠷࠴࠸࠱࠴ࠧࡦ")
l11lll1l=os.path.join(os.environ.get(l1ll1ll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll1ll (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll111.replace(l1ll1ll (u"ࠦࠥࠨࡩ"), l1ll1ll (u"ࠧࡥࠢࡪ")).lower())
l11ll11l=os.environ.get(l1ll1ll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11llll1=l1l1llll.replace(l1ll1ll (u"ࠣࠢࠥ࡭"), l1ll1ll (u"ࠤࡢࠦ࡮"))+l1ll1ll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1l1l1=os.path.join(os.environ.get(l1ll1ll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11llll1)
elif platform.system() == l1ll1ll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll1l1=l1111l1(l11lll1l+l1ll1ll (u"ࠢ࠰ࠤࡳ"))
    l1l1l1l1 = os.path.join(l11ll1l1, l11llll1)
else:
    l1l1l1l1 = os.path.join( l11llll1)
l11ll11l=l11ll11l.upper()
if l11ll11l == l1ll1ll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l111ll=logging.DEBUG
elif l11ll11l == l1ll1ll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l111ll = logging.INFO
elif l11ll11l == l1ll1ll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l111ll = logging.WARNING
elif l11ll11l == l1ll1ll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l111ll = logging.ERROR
elif l11ll11l == l1ll1ll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l111ll = logging.CRITICAL
elif l11ll11l == l1ll1ll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l111ll = logging.NOTSET
logger = logging.getLogger(l1ll1ll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l111ll)
l1l1l11l = logging.FileHandler(l1l1l1l1, mode=l1ll1ll (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l11l.setLevel(l1l111ll)
formatter = logging.Formatter(l1ll1ll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll1ll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l111ll)
l1l11lll = SysLogHandler(address=l1ll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11lll.setFormatter(formatter)
logger.addHandler(l1l1l11l)
logger.addHandler(ch)
logger.addHandler(l1l11lll)
class Settings():
    l1l1ll11 = l1ll1ll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11l1l = l1ll1ll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111l1 = l1ll1ll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1llll):
        self.l11ll1ll = self._1l11111(l1l1llll)
        self._1l1111l()
    def _1l11111(self, l1l1llll):
        l11lllll = l1l1llll.split(l1ll1ll (u"ࠣࠢࠥࢂ"))
        l11lllll = l1ll1ll (u"ࠤࠣࠦࢃ").join(l11lllll)
        if platform.system() == l1ll1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11ll1ll = os.path.join(l11lll1l, l1ll1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11lllll + l1ll1ll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11ll1ll
    def l1l1l1ll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1lll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1ll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1ll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11l1lll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1111l(self):
        if not os.path.exists(os.path.dirname(self.l11ll1ll)):
            os.makedirs(os.path.dirname(self.l11ll1ll))
        if not os.path.exists(self.l11ll1ll):
            self.config = ConfigObj(self.l11ll1ll)
            self.config[l1ll1ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll1ll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll1ll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111l1
            self.config[l1ll1ll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11l1l
            self.config[l1ll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1ll11
            self.config[l1ll1ll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll1ll)
            self.l1l111l1 = self.get_value(l1ll1ll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll1ll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11l1l = self.get_value(l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1ll11 = self.get_value(l1ll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1ll1l(self):
        l1l11ll1 = l1ll1ll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1ll11
        l1l11ll1 += l1ll1ll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11l1l
        l1l11ll1 += l1ll1ll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111l1
        return l1l11ll1
    def __unicode__(self):
        return self._1l1ll1l()
    def __str__(self):
        return self._1l1ll1l()
    def __del__(self):
        self.config.write()
l11lll11 = Settings(l1l1llll)