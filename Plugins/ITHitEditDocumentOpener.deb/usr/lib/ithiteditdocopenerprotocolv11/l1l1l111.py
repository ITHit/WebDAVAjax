#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l11lll1 = 2048
l1ll111l = 7
def l111111 (l1111ll):
    global l1lll111
    l1lllll1 = ord (l1111ll [-1])
    l1lll1ll = l1111ll [:-1]
    l1111l1 = l1lllll1 % len (l1lll1ll)
    l1l11ll = l1lll1ll [:l1111l1] + l1lll1ll [l1111l1:]
    if l1ll1lll:
        l1l1l1l = l1l111 () .join ([unichr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    else:
        l1l1l1l = str () .join ([chr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    return eval (l1l1l1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111l11 import l1ll1ll1
from configobj import ConfigObj
l1l1ll1l = l111111 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l11lll1l = l111111 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠷࠻࠲࠵ࠨࡤ")
l1l1l1l1 = l111111 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l111111 (u"ࠣ࠸࠱࠴࠳࠾࠷࠶࠺࠱࠴ࠧࡦ")
l11lllll=os.path.join(os.environ.get(l111111 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l111111 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1l1l1.replace(l111111 (u"ࠦࠥࠨࡩ"), l111111 (u"ࠧࡥࠢࡪ")).lower())
l1l1111l=os.environ.get(l111111 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l111111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l11ll1=l11lll1l.replace(l111111 (u"ࠣࠢࠥ࡭"), l111111 (u"ࠤࡢࠦ࡮"))+l111111 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l111111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11l1l=os.path.join(os.environ.get(l111111 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l11ll1)
elif platform.system() == l111111 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll1l1=l1ll1ll1(l11lllll+l111111 (u"ࠢ࠰ࠤࡳ"))
    l1l11l1l = os.path.join(l11ll1l1, l1l11ll1)
else:
    l1l11l1l = os.path.join( l1l11ll1)
l1l1111l=l1l1111l.upper()
if l1l1111l == l111111 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11111=logging.DEBUG
elif l1l1111l == l111111 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11111 = logging.INFO
elif l1l1111l == l111111 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11111 = logging.WARNING
elif l1l1111l == l111111 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11111 = logging.ERROR
elif l1l1111l == l111111 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11111 = logging.CRITICAL
elif l1l1111l == l111111 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11111 = logging.NOTSET
logger = logging.getLogger(l111111 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11111)
l1l111l1 = logging.FileHandler(l1l11l1l, mode=l111111 (u"ࠣࡹ࠮ࠦࡻ"))
l1l111l1.setLevel(l1l11111)
formatter = logging.Formatter(l111111 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l111111 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l111l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11111)
l1l11l11 = SysLogHandler(address=l111111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l111l1)
logger.addHandler(ch)
logger.addHandler(l1l11l11)
class Settings():
    l11ll11l = l111111 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11lll11 = l111111 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l11l = l111111 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11lll1l):
        self.l1l1ll11 = self._1l11lll(l11lll1l)
        self._11l1lll()
    def _1l11lll(self, l11lll1l):
        l1l1lll1 = l11lll1l.split(l111111 (u"ࠣࠢࠥࢂ"))
        l1l1lll1 = l111111 (u"ࠤࠣࠦࢃ").join(l1l1lll1)
        if platform.system() == l111111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1ll11 = os.path.join(l11lllll, l111111 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1lll1 + l111111 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1ll11
    def l1l1llll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111111 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111111 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l111ll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11l1lll(self):
        if not os.path.exists(os.path.dirname(self.l1l1ll11)):
            os.makedirs(os.path.dirname(self.l1l1ll11))
        if not os.path.exists(self.l1l1ll11):
            self.config = ConfigObj(self.l1l1ll11)
            self.config[l111111 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l111111 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l111111 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l11l
            self.config[l111111 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l111111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11lll11
            self.config[l111111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l111111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll11l
            self.config[l111111 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1ll11)
            self.l1l1l11l = self.get_value(l111111 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l111111 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11lll11 = self.get_value(l111111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll11l = self.get_value(l111111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l111111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11llll1(self):
        l11ll111 = l111111 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll11l
        l11ll111 += l111111 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11lll11
        l11ll111 += l111111 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l11l
        return l11ll111
    def __unicode__(self):
        return self._11llll1()
    def __str__(self):
        return self._11llll1()
    def __del__(self):
        self.config.write()
l11ll1ll = Settings(l11lll1l)