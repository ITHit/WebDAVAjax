#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l111l = 2048
l11llll = 7
def l11 (l1ll11):
    global l111l
    l1lll1l = ord (l1ll11 [-1])
    l1ll1l = l1ll11 [:-1]
    l1ll1l1 = l1lll1l % len (l1ll1l)
    l1111 = l1ll1l [:l1ll1l1] + l1ll1l [l1ll1l1:]
    if l1l111:
        l1ll1 = l1l11ll () .join ([unichr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    else:
        l1ll1 = str () .join ([chr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    return eval (l1ll1)
import re
class l1l11l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1lll = kwargs.get(l11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1llll1l = kwargs.get(l11 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllll1l = self.l1111111(args)
        if l1lllll1l:
            args=args+ l1lllll1l
        self.args = [a for a in args]
    def l1111111(self, *args):
        l1lllll1l=None
        l11l1lll = args[0][0]
        if re.search(l11 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11l1lll):
            l1lllll1l = (l11 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1lll
                            ,)
        return l1lllll1l
class l1llllll1(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll1l = self.l1111111(args)
        if l1lllll1l:
            args = args + l1lllll1l
        self.args = [a for a in args]
    def l1111111(self, *args):
        s = l11 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1l1l(Exception):
    pass
class l11ll1(Exception):
    pass
class l1lll11ll(Exception):
    def __init__(self, message, l1llll11l, url):
        super(l1lll11ll,self).__init__(message)
        self.l1llll11l = l1llll11l
        self.url = url
class l111111l(Exception):
    pass
class l11111l1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1111lll(Exception):
    pass