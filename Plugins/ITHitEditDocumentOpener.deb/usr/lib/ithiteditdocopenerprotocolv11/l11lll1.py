#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111l = sys.version_info [0] == 2
l1ll1lll = 2048
l1l1l = 7
def l1l1 (l11ll11):
    global l111l11
    l1l111 = ord (l11ll11 [-1])
    l1lll1ll = l11ll11 [:-1]
    l1l1111 = l1l111 % len (l1lll1ll)
    l11 = l1lll1ll [:l1l1111] + l1lll1ll [l1l1111:]
    if l1l111l:
        l11l1l = l1ll () .join ([unichr (ord (char) - l1ll1lll - (l1lllll + l1l111) % l1l1l) for l1lllll, char in enumerate (l11)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll1lll - (l1lllll + l1l111) % l1l1l) for l1lllll, char in enumerate (l11)])
    return eval (l11l1l)
import logging
import os
import re
from l1111ll import l111111l
logger = logging.getLogger(l1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1lll11l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l11():
    try:
        out = os.popen(l1l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l1 (u"ࠤࠥॸ").join(result)
                logger.info(l1l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l111111l(l1l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1lll11l(l1l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))