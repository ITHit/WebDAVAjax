#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l1 import l1l1l
from configobj import ConfigObj
l11ll1ll = l1lll11 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l11lll11 = l1lll11 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠷࠴࠸࠺࠶࠷࠲࠵ࠨࡤ")
l11ll1l1 = l1lll11 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lll11 (u"ࠣ࠸࠱࠶࠳࠾࠹࠵࠶࠱࠴ࠧࡦ")
l1l1ll1l=os.path.join(os.environ.get(l1lll11 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lll11 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll1l1.replace(l1lll11 (u"ࠦࠥࠨࡩ"), l1lll11 (u"ࠧࡥࠢࡪ")).lower())
l1l11ll1=os.environ.get(l1lll11 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lll11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lllll=l11lll11.replace(l1lll11 (u"ࠣࠢࠥ࡭"), l1lll11 (u"ࠤࡢࠦ࡮"))+l1lll11 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lll11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11lll1l=os.path.join(os.environ.get(l1lll11 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lllll)
elif platform.system() == l1lll11 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l111=l1l1l(l1l1ll1l+l1lll11 (u"ࠢ࠰ࠤࡳ"))
    l11lll1l = os.path.join(l1l1l111, l11lllll)
else:
    l11lll1l = os.path.join( l11lllll)
l1l11ll1=l1l11ll1.upper()
if l1l11ll1 == l1lll11 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l111ll=logging.DEBUG
elif l1l11ll1 == l1lll11 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l111ll = logging.INFO
elif l1l11ll1 == l1lll11 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l111ll = logging.WARNING
elif l1l11ll1 == l1lll11 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l111ll = logging.ERROR
elif l1l11ll1 == l1lll11 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l111ll = logging.CRITICAL
elif l1l11ll1 == l1lll11 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l111ll = logging.NOTSET
logger = logging.getLogger(l1lll11 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l111ll)
l1l11l11 = logging.FileHandler(l11lll1l, mode=l1lll11 (u"ࠣࡹ࠮ࠦࡻ"))
l1l11l11.setLevel(l1l111ll)
formatter = logging.Formatter(l1lll11 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lll11 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11l11.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l111ll)
l1l1l11l = SysLogHandler(address=l1lll11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1l11l.setFormatter(formatter)
logger.addHandler(l1l11l11)
logger.addHandler(ch)
logger.addHandler(l1l1l11l)
class Settings():
    l1l1111l = l1lll11 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1ll11 = l1lll11 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1llll = l1lll11 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11lll11):
        self.l1l1l1ll = self._11ll11l(l11lll11)
        self._11ll111()
    def _11ll11l(self, l11lll11):
        l11l1lll = l11lll11.split(l1lll11 (u"ࠣࠢࠥࢂ"))
        l11l1lll = l1lll11 (u"ࠤࠣࠦࢃ").join(l11l1lll)
        if platform.system() == l1lll11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l1ll = os.path.join(l1l1ll1l, l1lll11 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11l1lll + l1lll11 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l1ll
    def l11llll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1lll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll11 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll11 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll111(self):
        if not os.path.exists(os.path.dirname(self.l1l1l1ll)):
            os.makedirs(os.path.dirname(self.l1l1l1ll))
        if not os.path.exists(self.l1l1l1ll):
            self.config = ConfigObj(self.l1l1l1ll)
            self.config[l1lll11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lll11 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lll11 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1llll
            self.config[l1lll11 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1ll11
            self.config[l1lll11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lll11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1111l
            self.config[l1lll11 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l1ll)
            self.l1l1llll = self.get_value(l1lll11 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lll11 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1ll11 = self.get_value(l1lll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1111l = self.get_value(l1lll11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lll11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l1l1(self):
        l1l111l1 = l1lll11 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1111l
        l1l111l1 += l1lll11 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1ll11
        l1l111l1 += l1lll11 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1llll
        return l1l111l1
    def __unicode__(self):
        return self._1l1l1l1()
    def __str__(self):
        return self._1l1l1l1()
    def __del__(self):
        self.config.write()
l1l11lll = Settings(l11lll11)