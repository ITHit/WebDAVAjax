#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1llll1 = 2048
l11111l = 7
def l1lll1l (l11):
    global l1l1111
    ll = ord (l11 [-1])
    l1l1ll1 = l11 [:-1]
    l1l1l = ll % len (l1l1ll1)
    l1l1l11 = l1l1ll1 [:l1l1l] + l1l1ll1 [l1l1l:]
    if l1ll1ll1:
        l11l = l1llllll () .join ([unichr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    return eval (l11l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11ll1 import l1111l1
from configobj import ConfigObj
l1l1llll = l1lll1l (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1ll11 = l1lll1l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠷࠼࠲࠵ࠨࡤ")
l1l11ll1 = l1lll1l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lll1l (u"ࠣ࠸࠱࠴࠳࠾࠷࠶࠻࠱࠴ࠧࡦ")
l1l1l1l1=os.path.join(os.environ.get(l1lll1l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lll1l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11ll1.replace(l1lll1l (u"ࠦࠥࠨࡩ"), l1lll1l (u"ࠧࡥࠢࡪ")).lower())
l11ll1l1=os.environ.get(l1lll1l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lll1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l111l1=l1l1ll11.replace(l1lll1l (u"ࠣࠢࠥ࡭"), l1lll1l (u"ࠤࡢࠦ࡮"))+l1lll1l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lll1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11111=os.path.join(os.environ.get(l1lll1l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l111l1)
elif platform.system() == l1lll1l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l1ll=l1111l1(l1l1l1l1+l1lll1l (u"ࠢ࠰ࠤࡳ"))
    l1l11111 = os.path.join(l1l1l1ll, l1l111l1)
else:
    l1l11111 = os.path.join( l1l111l1)
l11ll1l1=l11ll1l1.upper()
if l11ll1l1 == l1lll1l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lllll=logging.DEBUG
elif l11ll1l1 == l1lll1l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lllll = logging.INFO
elif l11ll1l1 == l1lll1l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lllll = logging.WARNING
elif l11ll1l1 == l1lll1l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lllll = logging.ERROR
elif l11ll1l1 == l1lll1l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lllll = logging.CRITICAL
elif l11ll1l1 == l1lll1l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lllll = logging.NOTSET
logger = logging.getLogger(l1lll1l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lllll)
l1l11lll = logging.FileHandler(l1l11111, mode=l1lll1l (u"ࠣࡹ࠮ࠦࡻ"))
l1l11lll.setLevel(l11lllll)
formatter = logging.Formatter(l1lll1l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lll1l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lllll)
l11lll11 = SysLogHandler(address=l1lll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11lll11.setFormatter(formatter)
logger.addHandler(l1l11lll)
logger.addHandler(ch)
logger.addHandler(l11lll11)
class Settings():
    l11ll11l = l1lll1l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l111ll = l1lll1l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l11l = l1lll1l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1ll11):
        self.l1l1l111 = self._11ll111(l1l1ll11)
        self._11ll1ll()
    def _11ll111(self, l1l1ll11):
        l11l1lll = l1l1ll11.split(l1lll1l (u"ࠣࠢࠥࢂ"))
        l11l1lll = l1lll1l (u"ࠤࠣࠦࢃ").join(l11l1lll)
        if platform.system() == l1lll1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l111 = os.path.join(l1l1l1l1, l1lll1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11l1lll + l1lll1l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l111
    def l1l1lll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1111l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll1l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll1l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11l11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll1ll(self):
        if not os.path.exists(os.path.dirname(self.l1l1l111)):
            os.makedirs(os.path.dirname(self.l1l1l111))
        if not os.path.exists(self.l1l1l111):
            self.config = ConfigObj(self.l1l1l111)
            self.config[l1lll1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lll1l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lll1l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l11l
            self.config[l1lll1l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l111ll
            self.config[l1lll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll11l
            self.config[l1lll1l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l111)
            self.l1l1l11l = self.get_value(l1lll1l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lll1l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l111ll = self.get_value(l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll11l = self.get_value(l1lll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1ll1l(self):
        l11lll1l = l1lll1l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll11l
        l11lll1l += l1lll1l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l111ll
        l11lll1l += l1lll1l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l11l
        return l11lll1l
    def __unicode__(self):
        return self._1l1ll1l()
    def __str__(self):
        return self._1l1ll1l()
    def __del__(self):
        self.config.write()
l11llll1 = Settings(l1l1ll11)