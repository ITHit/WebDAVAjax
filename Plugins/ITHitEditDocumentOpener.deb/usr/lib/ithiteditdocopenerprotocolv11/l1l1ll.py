#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1llllll = 2048
l11llll = 7
def l1 (l1lllll1):
    global l111111
    l1ll11 = ord (l1lllll1 [-1])
    l11ll1l = l1lllll1 [:-1]
    l1ll1l1l = l1ll11 % len (l11ll1l)
    l11l111 = l11ll1l [:l1ll1l1l] + l11ll1l [l1ll1l1l:]
    if l111ll:
        l11l1ll = l1ll1ll () .join ([unichr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    return eval (l11l1ll)
import gi
gi.require_version(l1 (u"ࠨࡉࡷ࡯ࠬঽ"), l1 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11l1lll
import logging
logger = logging.getLogger(l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l111l1l(Gtk.Window):
    def __init__(self, l1ll1lll1l, l1l1lllll1):
        Gtk.Window.__init__(self)
        self.l1ll11l=30
        self.l1l1ll1l11 = False
        self.service = l1ll1lll1l
        self.l11l1l1=l1l1lllll1
        self.l1l1l=l11l1lll.l11ll111
        self.l1ll11lll1 = Gtk.ListStore(str)
        self.l1ll111l11()
    def l1ll1l11l1(self, service):
        l1l1l1llll = self.l1l1l.l1l111l1(l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1l1llll
    def l1ll111l11(self, l1ll1lll1l=None):
        if l1ll1lll1l:
            self.l1ll11lll1.clear()
            l1l1lll1l1=self.l1ll1l11l1(l1ll1lll1l)
            self.l1ll11lll1.append([l1 (u"ࠧࠨু")])
            for l11l1l1 in l1l1lll1l1:
                self.l1ll11lll1.append([l11l1l1])
        else:
            self.l1ll11lll1.clear()
            self.l1ll11lll1.append([l1 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1l1lll1(self, widget, data=None):
        l1ll111ll1= widget.get_active()
        if data == l1 (u"ࠢ࠲ࠤৃ") and l1ll111ll1:
            self.l1ll111l11()
            self.l1l11ll11l.set_active(0)
            self.l1l11llll1.set_text(l1 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l11llll1.set_sensitive(False)
            self.l1l11ll11l.set_sensitive(False)
        else:
            self.l1ll111l11(l1ll1lll1l=self.service)
            self.l1l11ll11l.set_active(0)
            self.l1l11llll1.set_text(l1 (u"ࠤࠥ৅"))
            self.l1l11ll11l.set_sensitive(True)
            self.l1l11llll1.set_sensitive(True)
    def l1l1lll11l(self, widget):
        if widget.get_active():
            l11l1l1 = widget.get_child().get_text()
        else:
            l11l1l1 = self.l1ll11lll1[widget.get_active()][0]
        password = self.l1ll1l1lll(self.service, l11l1l1)
        if password:
            self.l1l11llll1.set_text(password)
        else:
            self.l1l11llll1.set_text(l1 (u"ࠥࠦ৆"))
    def l1l1l1ll1l(self, l11l1l1, pwd, service):
        keyring.set_password(service, l11l1l1, pwd)
        l1l1l1llll=self.l1l1l.l1l111l1(l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11l1l1 in l1l1l1llll:
            value = self.l1l1l.get_value(l1 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l1l.l11lll1l(l1 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11l1l1))
    def l1ll1l1lll(self, service, l11l1l1):
        l1ll111l1l = keyring.get_password(service, l11l1l1)
        return l1ll111l1l
    def l1l1ll1l1l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1ll111(self, widget, data=None):
        self.l1l1ll1l11=widget.get_active()
    def l1111l(self, message, title=l1 (u"ࠨࠩো"), l11l1ll11=True):
        if l11l1ll11:
            l1l1llll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1l11l1l = Gtk.MessageDialog(self,
            l1l1llll11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1l11l1l.set_title(title)
        l1l1l11l1l.set_default_response(Gtk.ResponseType.OK)
        l1l11l1l1l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll1llll1 = Gtk.VBox()
        l1l1lll111 = Gtk.Box(spacing=1)
        l1l1lll111.set_homogeneous(False)
        l1ll1ll1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1ll1l1.set_homogeneous(False)
        l1l1ll11l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1ll11l1.set_homogeneous(False)
        l1l1lll111.pack_start(l1ll1ll1l1, True, True, 0)
        l1l1lll111.pack_start(l1l1ll11l1, True, True, 0)
        l1ll11ll1l = l1l1l11l1l.get_content_area()
        l1ll11llll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll11ll1l.pack_start(l1ll11llll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l111ll = Gtk.Label()
        l1l1ll1ll1 = Gtk.Label()
        l1l1ll1ll1.set_text(l1 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1ll1ll1, True, True, 0)
        l1l1l111ll.set_text(l1 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1l111ll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l111ll, 0, 1, 0, 1)
        l1l1ll1111 = Gtk.RadioButton.new_with_label_from_widget(None, l1 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1ll1111.connect(l1 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1l1lll1, l1 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1ll1111, 1, 2, 0, 1)
        l1l11ll1l1 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1111, l1 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l11ll1l1.connect(l1 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1l1lll1, l1 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l11ll1l1, 1, 2, 1, 2)
        l1ll1lll11 = Gtk.Label()
        l1ll1lll11.set_text(l1 (u"ࠥࠤࠧ৔"))
        table.attach(l1ll1lll11, 0, 1, 4, 6)
        l1l11l11ll = Gtk.Label()
        l1l11l11ll.set_text(l1 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l11l11ll.set_justify(Gtk.Justification.RIGHT)
        l1l11l11ll.set_alignment(xalign=1, yalign=0.5)
        self.l1l11ll11l = Gtk.ComboBox.new_with_model_and_entry(self.l1ll11lll1)
        self.l1l11ll11l.set_entry_text_column(0)
        table.attach(l1l11l11ll, 0, 1, 6, 8)
        table.attach(self.l1l11ll11l, 1, 3, 6, 8)
        self.l1l11ll11l.connect(l1 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1lll11l)
        l1ll1ll11l = Gtk.Label()
        l1ll1ll11l.set_text(l1 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1ll11l.set_justify(Gtk.Justification.RIGHT)
        l1ll1ll11l.set_alignment(xalign=1, yalign=0.5)
        self.l1l11llll1 = Gtk.Entry()
        self.l1l11llll1.set_visibility(False)
        self.l1l11llll1.connect(l1 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1ll1l1l, l1l1l11l1l)
        table.attach(l1ll1ll11l, 0, 1, 8, 10)
        table.attach(self.l1l11llll1, 1, 3, 8, 10)
        l1ll11l11l = Gtk.CheckButton(l1 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll11l11l.connect(l1 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll1ll111, l1ll11l11l)
        l1ll11l11l.set_active(False)
        table.attach(l1ll11l11l, 1, 3, 12, 14)
        l1l1l111l1 = Gtk.Label()
        l1l1l111l1.set_text(l1 (u"ࠥࠤࠧ৛") * 5)
        l1ll1llll1.pack_start(l1l1l111l1, True, True, 0)
        if self.l11l1l1:
            l1l11ll1l1.set_active(True)
            self.l1l11ll11l.set_active(0)
            self.l1l11ll11l.set_sensitive(True)
            self.l1l11llll1.set_text(l1 (u"ࠦࠧড়"))
            self.l1l11llll1.set_sensitive(True)
        else:
            self.l1l11ll11l.set_active(0)
            self.l1l11ll11l.set_sensitive(False)
            self.l1l11llll1.set_text(l1 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l11llll1.set_sensitive(False)
        l1l11l1l1l.pack_start(vbox, True, True, 0)
        l1l11l1l1l.pack_start(table, True, True, 0)
        l1l11l1l1l.pack_end(l1ll1llll1, True, True, 0)
        l1ll11llll.pack_start(l1l11l1l1l, True, True, 0)
        l1l1l11l1l.show_all()
        response = l1l1l11l1l.run()
        if self.l1l11ll11l.get_active():
            l11l1l1 = self.l1l11ll11l.get_child().get_text()
        else:
            l11l1l1 = self.l1ll11lll1[self.l1l11ll11l.get_active()][0]
        pwd = self.l1l11llll1.get_text()
        l1l1l11l1l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1ll1l11:
                self.l1l1l1ll1l(l11l1l1, pwd, self.service)
            return l11l1l1, pwd
        else:
            return l1 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1 (u"ࠧࠨয়")
class l1l1l111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll11ll11(self, l1l1ll1l):
        l1l1llllll = Gtk.ScrolledWindow()
        l1l1llllll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll1l1111=None
        self.l1ll1l1l1l = Gtk.TextBuffer()
        self.l1ll1l1l1l.set_text(l1l1ll1l)
        self.set_style()
        regexp= l1 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l1lll1ll = self._1l1l1111l(l1l1ll1l, regexp)
        self.l1l11lll1l(l1l1lll1ll, self.l1ll1l1l1l.get_start_iter())
        self.l1l11l1ll1 = Gtk.TextView(buffer=self.l1ll1l1l1l)
        self.l1l11l1ll1.set_property(l1 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l11l1ll1.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11l1ll1.connect(l1 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1l1l1l1)
        self.l1l11l1ll1.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1llllll.set_size_request(300,100)
        self.l1l11l1ll1.show()
        l1l1llllll.add(self.l1l11l1ll1)
        l1l1llllll.show()
        return l1l1llllll
    def _1l1l1l1l1(self, *args, **kwargs):
        l1l1l1ll11, l1l1l1l111=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l1ll11, l1l1l1l111).get_tags()
        if not self.l1ll1l1111:
            self.l1ll1l1111 = args[1].window.get_cursor()
            self.l1l11lll11 = Gdk.Cursor(Gdk.CursorType.l1l1l11ll1)
        elif tag:
            args[1].window.set_cursor(self.l1l11lll11)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll1l1111:
                args[1].window.set_cursor(self.l1ll1l1111)
    def _1l1l1111l(self, l1l1ll1l, l1l1l11lll):
        res=[]
        l1ll1111ll=re.findall(l1l1l11lll,l1l1ll1l)
        for l1ll1ll1ll in l1ll1111ll:
            for el in l1ll1ll1ll:
                if el:
                    res.append(el)
        return res
    def l1l11lll1l(self, l1l1lll1ll, start):
        l1l1llll1l=0
        for text in l1l1lll1ll:
            end = self.l1ll1l1l1l.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1llll1l+=1
                l1ll1111l1, l1l1l11111 = match
                tag = self.l1ll1l1l1l.create_tag(str(l1l1llll1l), foreground=l1 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l11l1l11, text)
                self.l1ll1l1l1l.apply_tag(tag, l1ll1111l1, l1l1l11111)
                self.l1l11lll1l(l1l1lll1ll, l1l1l11111)
    def _1l11l1l11(self, tag, widget, l1ll1lllll, _1ll1l11ll, text):
        _1l11ll1ll = l1ll1lllll.type
        _1ll11l1l1 = l1ll1lllll.window
        if _1l11ll1ll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11ll1ll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll1lllll.button
            self.l1ll1l1111 = Gdk.Cursor(Gdk.CursorType.l1l1l11ll1)
            if _1l11ll1ll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l11l11l1l(self, message, title=l1 (u"ࠧࠨ০"), l11l1ll11=True, l1ll111111=None):
        if l11l1ll11:
            l1l1llll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1llll11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll111111:
            l1ll11ll1l = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1lll111 = Gtk.HBox(spacing=0)
            l1ll11l111 = Gtk.HBox(spacing=5)
            l1l11lllll = Gtk.Label()
            l1l11lllll.set_markup(l1 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l11lllll.set_line_wrap(True)
            l1l11lllll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l11ll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll111.show()
            l1ll1l111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l111l.show()
            l1l1ll111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll111l.show()
            l1l1lll111.pack_start(separator, True, True, 0)
            l1l1lll111.pack_start(l1l11ll111, True, True, 0)
            l1l1lll111.pack_start(l1ll1l111l, True, True, 0)
            l1l1lll111.pack_start(l1l1ll111l, True, True, 0)
            l1l1lll111.pack_start(l1l11lllll, False, True, 0)
            l1ll1l1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l11.show()
            l1l1lll111.pack_end(l1ll1l1l11, True, True, 0)
            l1ll1l1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1ll1.show()
            vbox.pack_start(l1l1lll111, True, True, 0)
            l1l1llllll=self.__1ll11ll11(l1l1ll1l=l1ll111111)
            vbox.pack_start(l1l1llllll, False, False, 0)
            vbox.pack_end(l1ll1l1ll1, False, False, 0)
            l1ll11l111.pack_start(vbox, True, True,5)
            l1ll11l111.show()
            l1ll11ll1l.pack_end(l1ll11l111, False, False, 0)
            vbox.show()
            l1l1lll111.show()
        window.run()
class l11ll1111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111lll(self, widget, l1l1l11l11):
        if l1l1l11l11 == Gtk.ResponseType.OK:
            self.result = l1 (u"ࠥࡓࡐࠨ৩")
        elif l1l1l11l11 == Gtk.ResponseType.CANCEL:
            self.result = l1 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1l11l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1111111l(self, title=l1 (u"ࠨࠢ৬"), message=l1 (u"ࠢࠣ৭") , l11l1ll11=True):
        if l11l1ll11:
            l1l1llll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1llll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll111lll)
        window.run()
class l1l1l1l1ll(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll11111l=None
        self.result = None
    def l1ll111lll(self, widget, l1l1l11l11):
        print(widget, l1l1l11l11)
        if l1l1l11l11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l11l11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l11l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1ll111(self, widget, l1l11l1lll):
        if l1l11l1lll.get_active():
            self.l1ll11111l = 1
        else:
            self.l1ll11111l = 0
    def l1l1ll1lll(self, title=l1 (u"ࠤࠥ৯"), message=l1 (u"ࠥࠦৰ"), l1l1l1l11l =l1 (u"ࠦࠧৱ"),l11l1ll11=True):
        if l11l1ll11:
            l1l1llll11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1llll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll111lll)
        l1ll11l11l = Gtk.CheckButton(l1l1l1l11l)
        l1ll11l11l.connect(l1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll1ll111, l1ll11l11l)
        l1ll11l11l.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll11l11l, expand=True, fill=True, padding=0)
        l1ll11l11l.show()
        window.run()
def l1l1111l1(title, msg, l1l1l1l11l=l1 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11l1ll11=True):
    result=None
    try:
        l1l1ll11ll = l1l1l1l1ll()
        l1l1ll11ll.l1l1ll1lll(title, msg, l1l1l1l11l, l11l1ll11)
        result = {l1 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1ll11ll.result,  l1 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1ll11ll.l1ll11111l}
    except Exception as e:
        logger.exception(l1 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1l11llll = l1l1l111l()
    message= l1 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll11l1ll = l1 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1l11llll.l11l11l1l(message, l1 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11l1ll11=True, l1ll111111=l1ll11l1ll)