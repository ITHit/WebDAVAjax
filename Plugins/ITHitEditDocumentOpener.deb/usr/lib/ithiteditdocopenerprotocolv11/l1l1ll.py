#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111l1 = 2048
l1l11l = 7
def l1ll1ll (l11111l):
    global l1ll1
    l1ll1111 = ord (l11111l [-1])
    l11ll1l = l11111l [:-1]
    l11llll = l1ll1111 % len (l11ll1l)
    l1lll111 = l11ll1l [:l11llll] + l11ll1l [l11llll:]
    if l1lll1:
        l1ll11l = l11111 () .join ([unichr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    else:
        l1ll11l = str () .join ([chr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    return eval (l1ll11l)
import re
class l1ll1l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111l1 = kwargs.get(l1ll1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll1l = kwargs.get(l1ll1ll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllll11 = self.l1llll111(args)
        if l1lllll11:
            args=args+ l1lllll11
        self.args = [a for a in args]
    def l1llll111(self, *args):
        l1lllll11=None
        l1l1llll = args[0][0]
        if re.search(l1ll1ll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1llll):
            l1lllll11 = (l1ll1ll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l11111l1
                            ,)
        return l1lllll11
class l1111l11(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll11 = self.l1llll111(args)
        if l1lllll11:
            args = args + l1lllll11
        self.args = [a for a in args]
    def l1llll111(self, *args):
        s = l1ll1ll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll1ll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll1l1(Exception):
    pass
class l1ll111(Exception):
    pass
class l1111111(Exception):
    def __init__(self, message, l1lll1ll1, url):
        super(l1111111,self).__init__(message)
        self.l1lll1ll1 = l1lll1ll1
        self.url = url
class l1llllll1(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111111l(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1111l1l(Exception):
    pass