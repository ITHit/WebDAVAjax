#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11ll = sys.version_info [0] == 2
l111ll1 = 2048
l1l1l = 7
def l1l1 (l111ll):
    global l1lllll
    l1ll1l1l = ord (l111ll [-1])
    l11llll = l111ll [:-1]
    l1111 = l1ll1l1l % len (l11llll)
    l1llllll = l11llll [:l1111] + l11llll [l1111:]
    if l1ll11ll:
        l1ll1l11 = l11l1l1 () .join ([unichr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    else:
        l1ll1l11 = str () .join ([chr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    return eval (l1ll1l11)
import logging
import os
import re
from l111l import l1llll1ll
logger = logging.getLogger(l1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1111l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111lll():
    try:
        out = os.popen(l1l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l1 (u"ࠤࠥॸ").join(result)
                logger.info(l1l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll1ll(l1l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1111l(l1l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))