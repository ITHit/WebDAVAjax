#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l11lll1 = 2048
l1ll111l = 7
def l111111 (l1111ll):
    global l1lll111
    l1lllll1 = ord (l1111ll [-1])
    l1lll1ll = l1111ll [:-1]
    l1111l1 = l1lllll1 % len (l1lll1ll)
    l1l11ll = l1lll1ll [:l1111l1] + l1lll1ll [l1111l1:]
    if l1ll1lll:
        l1l1l1l = l1l111 () .join ([unichr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    else:
        l1l1l1l = str () .join ([chr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    return eval (l1l1l1l)
import hashlib
import os
import l111l11
from l1llll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111l11 import l1ll1ll1
from l11llll import l1ll11l1, l1ll1l1
import logging
logger = logging.getLogger(l111111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l():
    def __init__(self, l111l,l1111l, l1lll= None, l1l1lll=None):
        self.l1l11l1=False
        self.l1111 = self._1lll1()
        self.l1111l = l1111l
        self.l1lll = l1lll
        self.l11ll1l = l111l
        if l1lll:
            self.l1l1 = True
        else:
            self.l1l1 = False
        self.l1l1lll = l1l1lll
    def _1lll1(self):
        try:
            return l111l11.l111ll1() is not None
        except:
            return False
    def open(self):
        l111111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1111:
            raise NotImplementedError(l111111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1 = self.l11ll1l
        if self.l1111l.lower().startswith(self.l11ll1l.lower()):
            l11l = re.compile(re.escape(self.l11ll1l), re.IGNORECASE)
            l1111l = l11l.sub(l111111 (u"ࠨࠩࠄ"), self.l1111l)
            l1111l = l1111l.replace(l111111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l111111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1l(self.l11ll1l, l1, l1111l, self.l1lll)
    def l1ll1l(self,l11ll1l, l1, l1111l, l1lll):
        l111111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1llll1l = l11l1(l11ll1l)
        l1ll11 = self.l1lllll(l1llll1l)
        logger.info(l111111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1llll1l)
        if l1ll11:
            logger.info(l111111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1ll1(l1llll1l)
            l1llll1l = l1l1l11(l11ll1l, l1, l1lll, self.l1l1lll)
        logger.debug(l111111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1l1=l1llll1l + l111111 (u"ࠤ࠲ࠦࠌ") + l1111l
        l1ll1l11 = l111111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1l1+ l111111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1l11)
        l11ll = os.system(l1ll1l11)
        if (l11ll != 0):
            raise IOError(l111111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1l1, l11ll))
    def l1lllll(self, l1llll1l):
        if os.path.exists(l1llll1l):
            if os.path.islink(l1llll1l):
                l1llll1l = os.readlink(l1llll1l)
            if os.path.ismount(l1llll1l):
                return True
        return False
def l11l1(l11ll1l):
    l1l1ll1 = l11ll1l.replace(l111111 (u"࠭࡜࡝ࠩࠐ"), l111111 (u"ࠧࡠࠩࠑ")).replace(l111111 (u"ࠨ࠱ࠪࠒ"), l111111 (u"ࠩࡢࠫࠓ"))
    l1l1l = l111111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1llllll=os.environ[l111111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll1l=os.path.join(l1llllll,l1l1l, l1l1ll1)
    l11l11l=os.path.abspath(l1lll1l)
    return l11l11l
def l111l1l(l1l1111):
    if not os.path.exists(l1l1111):
        os.makedirs(l1l1111)
def l1l11l(l11ll1l, l1, l11l1l=None, password=None):
    l111111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l1111 = l11l1(l11ll1l)
    l111l1l(l1l1111)
    if not l11l1l:
        l11ll11 = l1l111l()
        l1lll11l =l11ll11.ll(l111111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1 + l111111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1 + l111111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll11l, str):
            l11l1l, password = l1lll11l
        else:
            raise l1ll1l1()
        logger.info(l111111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l1111))
    l11l1l1 = pwd.getpwuid( os.getuid())[0]
    l11111l=os.environ[l111111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l111=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l111l1={l111111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l1l1, l111111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll1l, l111111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l1111, l111111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11111l, l111111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l1l, l111111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l111l1, temp_file)
        if not os.path.exists(os.path.join(l111, l111111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11ll1=l111111 (u"ࠦࡵࡿࠢࠣ")
            key=l111111 (u"ࠧࠨࠤ")
        else:
            l11ll1=l111111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111lll=l111111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11ll1,temp_file.name)
        l1ll11ll=[l111111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l111, l111lll)]
        p = subprocess.Popen(l1ll11ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l1111
    logger.debug(l111111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11l11l=os.path.abspath(l1l1111)
    logger.debug(l111111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11l11l)
    return l11l11l
def l1l1l11(l11ll1l, l1, l1lll, l1l1lll):
    l111111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1ll(title):
        l1ll1111=30
        if len(title)>l1ll1111:
            l1ll11l=title.split(l111111 (u"ࠨ࠯ࠣ࠳"))
            l11=l111111 (u"ࠧࠨ࠴")
            for block in l1ll11l:
                l11+=block+l111111 (u"ࠣ࠱ࠥ࠵")
                if len(l11) > l1ll1111:
                    l11+=l111111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11
        return title
    def l111ll(l1ll111, password):
        l111111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111111 (u"ࠧࠦࠢ࠹").join(l1ll111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1llll11 = l111111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1llll11.encode())
        l1l11 = [l111111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11111 = l111111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11111)
            for e in l1l11:
                if e in l11111: return False
            raise l1ll11l1(l11111, l1l1l11=l111l11.l111ll1(), l1=l1)
        logger.info(l111111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11l1l = l111111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111111 (u"ࠦࠧ࠿")
    os.system(l111111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll1l1 = l11l1(l11ll1l)
    l1l1111 = l11l1(hashlib.sha1(l11ll1l.encode()).hexdigest()[:10])
    l111l1l(l1l1111)
    logger.info(l111111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l1111))
    if l1lll:
        l1ll111 = [l111111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111111 (u"ࠤ࠰ࡸࠧࡄ"), l111111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111111 (u"ࠫ࠲ࡵࠧࡆ"), l111111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11l1l, l1lll),
                    urllib.parse.unquote(l1), os.path.abspath(l1l1111)]
        l111ll(l1ll111, password)
    else:
        while True:
            l11l1l, password = l11l111(l1l1111, l1, l1l1lll)
            if l11l1l.lower() != l111111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll111 = [l111111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111111 (u"ࠤ࠰ࡸࠧࡋ"), l111111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111111 (u"ࠫ࠲ࡵࠧࡍ"), l111111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11l1l,
                            urllib.parse.unquote(l1), os.path.abspath(l1l1111)]
            else:
                raise l1ll1l1()
            if l111ll(l1ll111, password): break
    os.system(l111111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l1111, l1lll1l1))
    l11l11l=os.path.abspath(l1lll1l1)
    return l11l11l
def l11l111(l11ll1l, l1, l1l1lll):
    l1lll11 = os.path.join(os.environ[l111111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll11)):
       os.makedirs(os.path.dirname(l1lll11))
    l1ll1 = l1l1lll.get_value(l111111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11ll11 = l1l111l(l11ll1l, l1ll1)
    l11l1l, password = l11ll11.ll(l111111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1 + l111111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1 + l111111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11l1l != l111111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11lll(l11ll1l, l11l1l):
        l1ll1l1l = l111111 (u"ࠤ࡙ࠣࠦ").join([l11ll1l, l11l1l, l111111 (u"࡚ࠪࠦࠬ") + password + l111111 (u"࡛ࠫࠧ࠭"), l111111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll11, l111111 (u"࠭ࡷࠬࠩ࡝")) as l1ll:
            l1ll.write(l1ll1l1l)
        os.chmod(l1lll11, 0o600)
    return l11l1l, password
def l11lll(l11ll1l, l11l1l):
    l1lll11 = l1llll = os.path.join(os.environ[l111111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll11):
        with open(l1lll11, l111111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l1ll = data[0].split(l111111 (u"ࠦࠥࠨࡢ"))
            if l11ll1l == l11l1ll[0] and l11l1l == l11l1ll[1]:
                return True
    return False