#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll1l = 2048
l1lll111 = 7
def l11l (l1l11ll):
    global l11llll
    l1l1l1 = ord (l1l11ll [-1])
    l1ll1l1 = l1l11ll [:-1]
    l111 = l1l1l1 % len (l1ll1l1)
    l1l1ll = l1ll1l1 [:l111] + l1ll1l1 [l111:]
    if l1ll111:
        l1111l1 = l11ll11 () .join ([unichr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1lll1l - (l1l11l + l1l1l1) % l1lll111) for l1l11l, char in enumerate (l1l1ll)])
    return eval (l1111l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l1ll=logging.WARNING
logger = logging.getLogger(l11l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l1ll)
l1l111ll = SysLogHandler(address=l11l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l111ll.setFormatter(formatter)
logger.addHandler(l1l111ll)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l1ll)
logger.addHandler(ch)
class l1lllll1l1(io.FileIO):
    l11l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lllll1ll, l1lll11l11,
                     options, d=0, p=0):
            self.device = device
            self.l1lllll1ll = l1lllll1ll
            self.l1lll11l11 = l1lll11l11
            if not options:
                options = l11l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lllll1ll,
                                              self.l1lll11l11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lllll11l = os.path.join(os.path.sep, l11l (u"ࠪࡩࡹࡩࠧই"), l11l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1llll = path
        else:
            self._1lll1llll = self.l1lllll11l
        super(l1lllll1l1, self).__init__(self._1lll1llll, l11l (u"ࠬࡸࡢࠬࠩউ"))
    def _1llllll1l(self, line):
        return l1lllll1l1.Entry(*[x for x in line.strip(l11l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11l (u"ࠤࠦࠦ঍")):
                    yield self._1llllll1l(line)
            except ValueError:
                pass
    def l1lll111l1(self, attr, value):
        for entry in self.entries:
            l1llll1lll = getattr(entry, attr)
            if l1llll1lll == value:
                return entry
        return None
    def l1llll11ll(self, entry):
        if self.l1lll111l1(l11l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11l (u"ࠫࡡࡴࠧএ")).encode(l11l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll111l(self, entry):
        self.seek(0)
        lines = [l.decode(l11l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11l (u"ࠢࠤࠤ঒")):
                if self._1llllll1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11l (u"ࠨࠩও").join(lines).encode(l11l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll1l(cls, l1lllll1ll, path=None):
        l1lll1l1l1 = cls(path=path)
        entry = l1lll1l1l1.l1lll111l1(l11l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lllll1ll)
        if entry:
            return l1lll1l1l1.l1llll111l(entry)
        return False
    @classmethod
    def add(cls, device, l1lllll1ll, l1lll11l11, options=None, path=None):
        return cls(path=path).l1llll11ll(l1lllll1l1.Entry(device,
                                                    l1lllll1ll, l1lll11l11,
                                                    options=options))
class l1lllllll1(object):
    def __init__(self, l1lll1ll11):
        self.l1lll1111l=l11l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11l1l=l11l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1ll11=l1lll1ll11
        self.l1llll1l11()
        self.l1lll11ll1()
        self.l1llll1111()
        self.l1lll1l11l()
        self.l1llll1ll1()
    def l1llll1l11(self):
        temp_file=open(l1lllll111,l11l (u"࠭ࡲࠨঘ"))
        l11l111=temp_file.read()
        data=json.loads(l11l111)
        self.user=data[l11l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1llll1l=data[l11l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll11l1=data[l11l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l111l11=data[l11l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll1l1l=data[l11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l111=data[l11l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1111(self):
        l1llll11=os.path.join(l11l (u"ࠨ࠯ࠣট"),l11l (u"ࠢࡶࡵࡵࠦঠ"),l11l (u"ࠣࡵࡥ࡭ࡳࠨড"),l11l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1llll11)
    def l1llll1ll1(self):
        logger.info(l11l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll11l1=os.path.join(self.l111l11,self.l1lll1111l)
        l1lll1lll1 = pwd.getpwnam(self.user).pw_uid
        l1lll111ll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll11l1):
            os.makedirs(l1ll11l1)
            os.system(l11l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll11l1))
            logger.debug(l11l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll11l1)
        else:
            logger.debug(l11l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll11l1)
        l1llll11=os.path.join(l1ll11l1, self.l1lll11l1l)
        print(l1llll11)
        logger.debug(l11l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1llll11)
        with open(l1llll11, l11l (u"ࠤࡺ࠯ࠧ঩")) as l1lll11lll:
            logger.debug(self.l1llll1l + l11l (u"ࠪࠤࠬপ")+self.l1llll1l1l+l11l (u"ࠫࠥࠨࠧফ")+self.l1lll1l111+l11l (u"ࠬࠨࠧব"))
            l1lll11lll.writelines(self.l1llll1l + l11l (u"࠭ࠠࠨভ")+self.l1llll1l1l+l11l (u"ࠧࠡࠤࠪম")+self.l1lll1l111+l11l (u"ࠨࠤࠪয"))
        os.chmod(l1llll11, 0o600)
        os.chown(l1llll11, l1lll1lll1, l1lll111ll)
    def l1lll11ll1(self, l1llllll11=l11l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll11 in groups:
            logger.info(l11l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llllll11))
        else:
            logger.warning(l11l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llllll11))
            l1lll1l1=l11l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llllll11,self.user)
            logger.debug(l11l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1lll1l1)
            os.system(l1lll1l1)
            logger.debug(l11l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l11l(self):
        logger.debug(l11l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l1l1=l1lllll1l1()
        l1lll1l1l1.add(self.l1llll1l, self.l1ll11l1, l1lll11l11=l11l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll111 = urllib.parse.unquote(sys.argv[1])
        if l1lllll111:
            l1llll11l1=l1lllllll1(l1lllll111)
        else:
            raise (l11l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise