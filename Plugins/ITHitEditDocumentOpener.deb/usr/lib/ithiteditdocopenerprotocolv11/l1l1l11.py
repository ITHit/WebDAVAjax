#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1lll = 7
def l111ll1 (l11l111):
    global l1lll11l
    l1111ll = ord (l11l111 [-1])
    l1lll1l1 = l11l111 [:-1]
    l1lll1l = l1111ll % len (l1lll1l1)
    l1llll = l1lll1l1 [:l1lll1l] + l1lll1l1 [l1lll1l:]
    if l1l1111:
        l11l1ll = l1lllll () .join ([unichr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    return eval (l11l1ll)
import re
class l1lll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111l11 = kwargs.get(l111ll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l11ll = kwargs.get(l111ll1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1111111 = self.l1lll1l1l(args)
        if l1111111:
            args=args+ l1111111
        self.args = [a for a in args]
    def l1lll1l1l(self, *args):
        l1111111=None
        l1l1lll1 = args[0][0]
        if re.search(l111ll1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1lll1):
            l1111111 = (l111ll1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1111l11
                            ,)
        return l1111111
class l1lllllll(Exception):
    def __init__(self, *args, **kwargs):
        l1111111 = self.l1lll1l1l(args)
        if l1111111:
            args = args + l1111111
        self.args = [a for a in args]
    def l1lll1l1l(self, *args):
        s = l111ll1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l111ll1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll11ll(Exception):
    pass
class l1ll11(Exception):
    pass
class l1llll1ll(Exception):
    def __init__(self, message, l111111l, url):
        super(l1llll1ll,self).__init__(message)
        self.l111111l = l111111l
        self.url = url
class l11111l1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1111lll(Exception):
    pass