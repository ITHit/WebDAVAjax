#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111 = sys.version_info [0] == 2
l111 = 2048
l1ll1l1l = 7
def l11l1ll (l1ll1l11):
    global ll
    l1ll111 = ord (l1ll1l11 [-1])
    l1llll1l = l1ll1l11 [:-1]
    l1lll = l1ll111 % len (l1llll1l)
    l1 = l1llll1l [:l1lll] + l1llll1l [l1lll:]
    if l11111:
        l1ll1lll = l11l11 () .join ([unichr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    else:
        l1ll1lll = str () .join ([chr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    return eval (l1ll1lll)
import re
class l11ll1l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111111 = kwargs.get(l11l1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11ll11 = kwargs.get(l11l1ll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll1l1 = self.l1lll1l11(args)
        if l1llll1l1:
            args=args+ l1llll1l1
        self.args = [a for a in args]
    def l1lll1l11(self, *args):
        l1llll1l1=None
        l11ll11l = args[0][0]
        if re.search(l11l1ll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11ll11l):
            l1llll1l1 = (l11l1ll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1111111
                            ,)
        return l1llll1l1
class l1lllllll(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1l1 = self.l1lll1l11(args)
        if l1llll1l1:
            args = args + l1llll1l1
        self.args = [a for a in args]
    def l1lll1l11(self, *args):
        s = l11l1ll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11l1ll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1l1l(Exception):
    pass
class l1l1lll(Exception):
    pass
class l1llllll1(Exception):
    def __init__(self, message, l1lllll11, url):
        super(l1llllll1,self).__init__(message)
        self.l1lllll11 = l1lllll11
        self.url = url
class l1111l11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l111111l(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l111ll11(Exception):
    pass