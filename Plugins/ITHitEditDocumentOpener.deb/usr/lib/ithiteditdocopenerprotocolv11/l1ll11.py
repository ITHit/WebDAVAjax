#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l11 = sys.version_info [0] == 2
l1ll1l = 2048
l11ll11 = 7
def l1llllll (l11l111):
    global l11l11
    l1ll1l11 = ord (l11l111 [-1])
    l1llll = l11l111 [:-1]
    ll = l1ll1l11 % len (l1llll)
    l1ll1 = l1llll [:ll] + l1llll [ll:]
    if l1l1l11:
        l1l111 = l1llll1l () .join ([unichr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    return eval (l1l111)
import hashlib
import os
import l1lll11
from l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll11 import l11ll1
from l1ll import l11l1l, l11l1ll
import logging
logger = logging.getLogger(l1llllll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll11l():
    def __init__(self, l1l11,l1ll11ll, l1ll1111= None, l1l1l=None):
        self.l1ll1ll=False
        self.l1lllll1 = self._11llll()
        self.l1ll11ll = l1ll11ll
        self.l1ll1111 = l1ll1111
        self.l11 = l1l11
        if l1ll1111:
            self.l1l11l = True
        else:
            self.l1l11l = False
        self.l1l1l = l1l1l
    def _11llll(self):
        try:
            return l1lll11.l1111l1() is not None
        except:
            return False
    def open(self):
        l1llllll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lllll1:
            raise NotImplementedError(l1llllll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1llllll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l111l11 = self.l11
        if self.l1ll11ll.lower().startswith(self.l11.lower()):
            l1ll1ll1 = re.compile(re.escape(self.l11), re.IGNORECASE)
            l1ll11ll = l1ll1ll1.sub(l1llllll (u"ࠨࠩࠄ"), self.l1ll11ll)
            l1ll11ll = l1ll11ll.replace(l1llllll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1llllll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11111(self.l11, l111l11, l1ll11ll, self.l1ll1111)
    def l11111(self,l11, l111l11, l1ll11ll, l1ll1111):
        l1llllll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1llllll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll1l1 = l1ll1l1(l11)
        l1111 = self.l1l1lll(l1lll1l1)
        logger.info(l1llllll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll1l1)
        if l1111:
            logger.info(l1llllll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11ll1(l1lll1l1)
            l1lll1l1 = l11l1(l11, l111l11, l1ll1111, self.l1l1l)
        logger.debug(l1llllll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11111l=l1lll1l1 + l1llllll (u"ࠤ࠲ࠦࠌ") + l1ll11ll
        l111ll1 = l1llllll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11111l+ l1llllll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111ll1)
        l1lll1ll = os.system(l111ll1)
        if (l1lll1ll != 0):
            raise IOError(l1llllll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11111l, l1lll1ll))
    def l1l1lll(self, l1lll1l1):
        if os.path.exists(l1lll1l1):
            if os.path.islink(l1lll1l1):
                l1lll1l1 = os.readlink(l1lll1l1)
            if os.path.ismount(l1lll1l1):
                return True
        return False
def l1ll1l1(l11):
    l1l1ll = l11.replace(l1llllll (u"࠭࡜࡝ࠩࠐ"), l1llllll (u"ࠧࡠࠩࠑ")).replace(l1llllll (u"ࠨ࠱ࠪࠒ"), l1llllll (u"ࠩࡢࠫࠓ"))
    l11l1l1 = l1llllll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll111l=os.environ[l1llllll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1111l=os.path.join(l1ll111l,l11l1l1, l1l1ll)
    l1ll11l1=os.path.abspath(l1111l)
    return l1ll11l1
def l111l1l(l1lll1):
    if not os.path.exists(l1lll1):
        os.makedirs(l1lll1)
def l1lll111(l11, l111l11, l1l1l1=None, password=None):
    l1llllll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll1 = l1ll1l1(l11)
    l111l1l(l1lll1)
    if not l1l1l1:
        l1llll11 = l1l1()
        l111111 =l1llll11.l1lllll(l1llllll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l111l11 + l1llllll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l111l11 + l1llllll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l111111, str):
            l1l1l1, password = l111111
        else:
            raise l11l1ll()
        logger.info(l1llllll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll1))
    l1111ll = pwd.getpwuid( os.getuid())[0]
    l111l1=os.environ[l1llllll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1111=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l11l={l1llllll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1111ll, l1llllll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11, l1llllll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll1, l1llllll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l111l1, l1llllll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1l1, l1llllll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l11l, temp_file)
        if not os.path.exists(os.path.join(l1l1111, l1llllll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1lll=l1llllll (u"ࠦࡵࡿࠢࠣ")
            key=l1llllll (u"ࠧࠨࠤ")
        else:
            l1ll1lll=l1llllll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1llllll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll11l=l1llllll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1lll,temp_file.name)
        l11lll=[l1llllll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1llllll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1111, l1lll11l)]
        p = subprocess.Popen(l11lll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1llllll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1llllll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1llllll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll1
    logger.debug(l1llllll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1llllll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1llllll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1llllll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11l1=os.path.abspath(l1lll1)
    logger.debug(l1llllll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11l1)
    return l1ll11l1
def l11l1(l11, l111l11, l1ll1111, l1l1l):
    l1llllll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l111l(title):
        l111l=30
        if len(title)>l111l:
            l1l1l1l=title.split(l1llllll (u"ࠨ࠯ࠣ࠳"))
            l11l=l1llllll (u"ࠧࠨ࠴")
            for block in l1l1l1l:
                l11l+=block+l1llllll (u"ࠣ࠱ࠥ࠵")
                if len(l11l) > l111l:
                    l11l+=l1llllll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l
        return title
    def l111(l1lll, password):
        l1llllll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1llllll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1llllll (u"ࠧࠦࠢ࠹").join(l1lll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l1ll1 = l1llllll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l1ll1.encode())
        l111ll = [l1llllll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll111 = l1llllll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll111)
            for e in l111ll:
                if e in l1ll111: return False
            raise l11l1l(l1ll111, l11l1=l1lll11.l1111l1(), l111l11=l111l11)
        logger.info(l1llllll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l1l1 = l1llllll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1llllll (u"ࠦࠧ࠿")
    os.system(l1llllll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l11l1 = l1ll1l1(l11)
    l1lll1 = l1ll1l1(hashlib.sha1(l11.encode()).hexdigest()[:10])
    l111l1l(l1lll1)
    logger.info(l1llllll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1lll1))
    if l1ll1111:
        l1lll = [l1llllll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1llllll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1llllll (u"ࠤ࠰ࡸࠧࡄ"), l1llllll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1llllll (u"ࠫ࠲ࡵࠧࡆ"), l1llllll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l1l1, l1ll1111),
                    urllib.parse.unquote(l111l11), os.path.abspath(l1lll1)]
        l111(l1lll, password)
    else:
        while True:
            l1l1l1, password = l1l11ll(l1lll1, l111l11, l1l1l)
            if l1l1l1.lower() != l1llllll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1lll = [l1llllll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1llllll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1llllll (u"ࠤ࠰ࡸࠧࡋ"), l1llllll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1llllll (u"ࠫ࠲ࡵࠧࡍ"), l1llllll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l1l1,
                            urllib.parse.unquote(l111l11), os.path.abspath(l1lll1)]
            else:
                raise l11l1ll()
            if l111(l1lll, password): break
    os.system(l1llllll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1lll1, l1l11l1))
    l1ll11l1=os.path.abspath(l1l11l1)
    return l1ll11l1
def l1l11ll(l11, l111l11, l1l1l):
    l11lll1 = os.path.join(os.environ[l1llllll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1llllll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1llllll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11lll1)):
       os.makedirs(os.path.dirname(l11lll1))
    l1ll1l1l = l1l1l.get_value(l1llllll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1llllll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1llll11 = l1l1(l11, l1ll1l1l)
    l1l1l1, password = l1llll11.l1lllll(l1llllll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l111l11 + l1llllll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l111l11 + l1llllll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l1l1 != l1llllll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11ll(l11, l1l1l1):
        l1lll1l = l1llllll (u"ࠤ࡙ࠣࠦ").join([l11, l1l1l1, l1llllll (u"࡚ࠪࠦࠬ") + password + l1llllll (u"࡛ࠫࠧ࠭"), l1llllll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11lll1, l1llllll (u"࠭ࡷࠬࠩ࡝")) as l111lll:
            l111lll.write(l1lll1l)
        os.chmod(l11lll1, 0o600)
    return l1l1l1, password
def l11ll(l11, l1l1l1):
    l11lll1 = l1llll1 = os.path.join(os.environ[l1llllll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1llllll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1llllll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11lll1):
        with open(l11lll1, l1llllll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11ll1l = data[0].split(l1llllll (u"ࠦࠥࠨࡢ"))
            if l11 == l11ll1l[0] and l1l1l1 == l11ll1l[1]:
                return True
    return False