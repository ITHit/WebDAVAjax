#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l111l = 2048
l11llll = 7
def l11 (l1ll11):
    global l111l
    l1lll1l = ord (l1ll11 [-1])
    l1ll1l = l1ll11 [:-1]
    l1ll1l1 = l1lll1l % len (l1ll1l)
    l1111 = l1ll1l [:l1ll1l1] + l1ll1l [l1ll1l1:]
    if l1l111:
        l1ll1 = l1l11ll () .join ([unichr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    else:
        l1ll1 = str () .join ([chr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    return eval (l1ll1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111ll1 import l11l11
from configobj import ConfigObj
l11ll1ll = l11 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l11lll = l11 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠷࠴࠸࠺࠶࠹࠲࠵ࠨࡤ")
l11lll1l = l11 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11 (u"ࠣ࠸࠱࠶࠳࠾࠹࠵࠸࠱࠴ࠧࡦ")
l1l111l1=os.path.join(os.environ.get(l11 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11lll1l.replace(l11 (u"ࠦࠥࠨࡩ"), l11 (u"ࠧࡥࠢࡪ")).lower())
l1l1lll1=os.environ.get(l11 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1l1l1=l1l11lll.replace(l11 (u"ࠣࠢࠥ࡭"), l11 (u"ࠤࡢࠦ࡮"))+l11 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll1l1=os.path.join(os.environ.get(l11 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1l1l1)
elif platform.system() == l11 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll11l=l11l11(l1l111l1+l11 (u"ࠢ࠰ࠤࡳ"))
    l11ll1l1 = os.path.join(l11ll11l, l1l1l1l1)
else:
    l11ll1l1 = os.path.join( l1l1l1l1)
l1l1lll1=l1l1lll1.upper()
if l1l1lll1 == l11 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1l1ll=logging.DEBUG
elif l1l1lll1 == l11 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1l1ll = logging.INFO
elif l1l1lll1 == l11 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1l1ll = logging.WARNING
elif l1l1lll1 == l11 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1l1ll = logging.ERROR
elif l1l1lll1 == l11 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1l1ll = logging.CRITICAL
elif l1l1lll1 == l11 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1l1ll = logging.NOTSET
logger = logging.getLogger(l11 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1l1ll)
l1l11l11 = logging.FileHandler(l11ll1l1, mode=l11 (u"ࠣࡹ࠮ࠦࡻ"))
l1l11l11.setLevel(l1l1l1ll)
formatter = logging.Formatter(l11 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11l11.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l1ll)
l11llll1 = SysLogHandler(address=l11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11llll1.setFormatter(formatter)
logger.addHandler(l1l11l11)
logger.addHandler(ch)
logger.addHandler(l11llll1)
class Settings():
    l1l1ll1l = l11 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1l11l = l11 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1ll11 = l11 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l11lll):
        self.l1l111ll = self._1l11111(l1l11lll)
        self._1l1111l()
    def _1l11111(self, l1l11lll):
        l1l11ll1 = l1l11lll.split(l11 (u"ࠣࠢࠥࢂ"))
        l1l11ll1 = l11 (u"ࠤࠣࠦࢃ").join(l1l11ll1)
        if platform.system() == l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l111ll = os.path.join(l1l111l1, l11 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11ll1 + l11 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l111ll
    def l1l11l1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l111(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11lll11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1111l(self):
        if not os.path.exists(os.path.dirname(self.l1l111ll)):
            os.makedirs(os.path.dirname(self.l1l111ll))
        if not os.path.exists(self.l1l111ll):
            self.config = ConfigObj(self.l1l111ll)
            self.config[l11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1ll11
            self.config[l11 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1l11l
            self.config[l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1ll1l
            self.config[l11 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l111ll)
            self.l1l1ll11 = self.get_value(l11 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1l11l = self.get_value(l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1ll1l = self.get_value(l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lllll(self):
        l11l1lll = l11 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1ll1l
        l11l1lll += l11 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1l11l
        l11l1lll += l11 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1ll11
        return l11l1lll
    def __unicode__(self):
        return self._11lllll()
    def __str__(self):
        return self._11lllll()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l1l11lll)