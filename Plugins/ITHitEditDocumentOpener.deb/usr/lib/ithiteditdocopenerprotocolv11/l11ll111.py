#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1111 = 7
def l1lll1ll (l1llll):
    global l1ll111l
    l1l1lll = ord (l1llll [-1])
    l11l1l = l1llll [:-1]
    l1ll1l1l = l1l1lll % len (l11l1l)
    l1l111l = l11l1l [:l1ll1l1l] + l11l1l [l1ll1l1l:]
    if l1ll1lll:
        l11ll11 = l1111 () .join ([unichr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    return eval (l11ll11)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from ll import l1lll11
from configobj import ConfigObj
l11ll1l1 = l1lll1ll (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l11111 = l1lll1ll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠺࠴࠳࠲࠵ࠨࡤ")
l1l11l11 = l1lll1ll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lll1ll (u"ࠣ࠸࠱࠴࠳࠾࠹࠳࠲࠱࠴ࠧࡦ")
l11l1lll=os.path.join(os.environ.get(l1lll1ll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lll1ll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11l11.replace(l1lll1ll (u"ࠦࠥࠨࡩ"), l1lll1ll (u"ࠧࡥࠢࡪ")).lower())
l11lll1l=os.environ.get(l1lll1ll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lll1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1111l=l1l11111.replace(l1lll1ll (u"ࠣࠢࠥ࡭"), l1lll1ll (u"ࠤࡢࠦ࡮"))+l1lll1ll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lll1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11lll11=os.path.join(os.environ.get(l1lll1ll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1111l)
elif platform.system() == l1lll1ll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l111ll=l1lll11(l11l1lll+l1lll1ll (u"ࠢ࠰ࠤࡳ"))
    l11lll11 = os.path.join(l1l111ll, l1l1111l)
else:
    l11lll11 = os.path.join( l1l1111l)
l11lll1l=l11lll1l.upper()
if l11lll1l == l1lll1ll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1l1l1=logging.DEBUG
elif l11lll1l == l1lll1ll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1l1l1 = logging.INFO
elif l11lll1l == l1lll1ll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1l1l1 = logging.WARNING
elif l11lll1l == l1lll1ll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1l1l1 = logging.ERROR
elif l11lll1l == l1lll1ll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1l1l1 = logging.CRITICAL
elif l11lll1l == l1lll1ll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1l1l1 = logging.NOTSET
logger = logging.getLogger(l1lll1ll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1l1l1)
l11ll1ll = logging.FileHandler(l11lll11, mode=l1lll1ll (u"ࠣࡹ࠮ࠦࡻ"))
l11ll1ll.setLevel(l1l1l1l1)
formatter = logging.Formatter(l1lll1ll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lll1ll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11ll1ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l1l1)
l1l111l1 = SysLogHandler(address=l1lll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l111l1.setFormatter(formatter)
logger.addHandler(l11ll1ll)
logger.addHandler(ch)
logger.addHandler(l1l111l1)
class Settings():
    l1l1ll11 = l1lll1ll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1llll = l1lll1ll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l11l = l1lll1ll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l11111):
        self.l1l11lll = self._11lllll(l1l11111)
        self._1l1ll1l()
    def _11lllll(self, l1l11111):
        l1l1l111 = l1l11111.split(l1lll1ll (u"ࠣࠢࠥࢂ"))
        l1l1l111 = l1lll1ll (u"ࠤࠣࠦࢃ").join(l1l1l111)
        if platform.system() == l1lll1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11lll = os.path.join(l11l1lll, l1lll1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l111 + l1lll1ll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11lll
    def l1l1lll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11llll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll1ll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll1ll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1ll1l(self):
        if not os.path.exists(os.path.dirname(self.l1l11lll)):
            os.makedirs(os.path.dirname(self.l1l11lll))
        if not os.path.exists(self.l1l11lll):
            self.config = ConfigObj(self.l1l11lll)
            self.config[l1lll1ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lll1ll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lll1ll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l11l
            self.config[l1lll1ll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1llll
            self.config[l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1ll11
            self.config[l1lll1ll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11lll)
            self.l1l1l11l = self.get_value(l1lll1ll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lll1ll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1llll = self.get_value(l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1ll11 = self.get_value(l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l1ll(self):
        l1l11ll1 = l1lll1ll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1ll11
        l1l11ll1 += l1lll1ll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1llll
        l1l11ll1 += l1lll1ll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l11l
        return l1l11ll1
    def __unicode__(self):
        return self._1l1l1ll()
    def __str__(self):
        return self._1l1l1ll()
    def __del__(self):
        self.config.write()
l1l11l1l = Settings(l1l11111)