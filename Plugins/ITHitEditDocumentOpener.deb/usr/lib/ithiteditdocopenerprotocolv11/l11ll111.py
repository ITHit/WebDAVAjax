#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll11l1 = 7
def l1lll1l (l1l11ll):
    global l1ll
    l1111l1 = ord (l1l11ll [-1])
    l1llll1l = l1l11ll [:-1]
    l11l11 = l1111l1 % len (l1llll1l)
    l1l1lll = l1llll1l [:l11l11] + l1llll1l [l11l11:]
    if l1ll1ll1:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    return eval (l1ll1l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111ll import l1l11l1
from configobj import ConfigObj
l11l1lll = l1lll1l (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1lll1 = l1lll1l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠶࠴࠸࠺࠴࠺࠲࠵ࠨࡤ")
l1l1111l = l1lll1l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lll1l (u"ࠣ࠸࠱࠵࠳࠾࠹࠳࠹࠱࠴ࠧࡦ")
l11ll1l1=os.path.join(os.environ.get(l1lll1l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lll1l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1111l.replace(l1lll1l (u"ࠦࠥࠨࡩ"), l1lll1l (u"ࠧࡥࠢࡪ")).lower())
l1l1l11l=os.environ.get(l1lll1l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lll1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11ll1ll=l1l1lll1.replace(l1lll1l (u"ࠣࠢࠥ࡭"), l1lll1l (u"ࠤࡢࠦ࡮"))+l1lll1l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lll1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11l1l=os.path.join(os.environ.get(l1lll1l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11ll1ll)
elif platform.system() == l1lll1l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11lllll=l1l11l1(l11ll1l1+l1lll1l (u"ࠢ࠰ࠤࡳ"))
    l1l11l1l = os.path.join(l11lllll, l11ll1ll)
else:
    l1l11l1l = os.path.join( l11ll1ll)
l1l1l11l=l1l1l11l.upper()
if l1l1l11l == l1lll1l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lll11=logging.DEBUG
elif l1l1l11l == l1lll1l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lll11 = logging.INFO
elif l1l1l11l == l1lll1l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lll11 = logging.WARNING
elif l1l1l11l == l1lll1l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lll11 = logging.ERROR
elif l1l1l11l == l1lll1l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lll11 = logging.CRITICAL
elif l1l1l11l == l1lll1l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lll11 = logging.NOTSET
logger = logging.getLogger(l1lll1l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lll11)
l1l1l1ll = logging.FileHandler(l1l11l1l, mode=l1lll1l (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l1ll.setLevel(l11lll11)
formatter = logging.Formatter(l1lll1l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lll1l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l1ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll11)
l1l1ll1l = SysLogHandler(address=l1lll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l1l1l1ll)
logger.addHandler(ch)
logger.addHandler(l1l1ll1l)
class Settings():
    l1l111l1 = l1lll1l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l111ll = l1lll1l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11llll1 = l1lll1l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1lll1):
        self.l1l1l1l1 = self._1l11ll1(l1l1lll1)
        self._11lll1l()
    def _1l11ll1(self, l1l1lll1):
        l1l1llll = l1l1lll1.split(l1lll1l (u"ࠣࠢࠥࢂ"))
        l1l1llll = l1lll1l (u"ࠤࠣࠦࢃ").join(l1l1llll)
        if platform.system() == l1lll1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l1l1 = os.path.join(l11ll1l1, l1lll1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1llll + l1lll1l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l1l1
    def l1l11111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1ll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll1l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll1l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll1l(self):
        if not os.path.exists(os.path.dirname(self.l1l1l1l1)):
            os.makedirs(os.path.dirname(self.l1l1l1l1))
        if not os.path.exists(self.l1l1l1l1):
            self.config = ConfigObj(self.l1l1l1l1)
            self.config[l1lll1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lll1l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lll1l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11llll1
            self.config[l1lll1l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l111ll
            self.config[l1lll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l111l1
            self.config[l1lll1l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l1l1)
            self.l11llll1 = self.get_value(l1lll1l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lll1l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l111ll = self.get_value(l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l111l1 = self.get_value(l1lll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11lll(self):
        l1l11l11 = l1lll1l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l111l1
        l1l11l11 += l1lll1l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l111ll
        l1l11l11 += l1lll1l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11llll1
        return l1l11l11
    def __unicode__(self):
        return self._1l11lll()
    def __str__(self):
        return self._1l11lll()
    def __del__(self):
        self.config.write()
l1l1l111 = Settings(l1l1lll1)