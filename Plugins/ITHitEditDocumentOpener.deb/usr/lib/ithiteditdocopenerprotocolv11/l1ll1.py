#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111ll = sys.version_info [0] == 2
l11l1l = 2048
l1llll11 = 7
def l11lll1 (l1ll11l1):
    global l1l1ll
    l1l1lll = ord (l1ll11l1 [-1])
    l1lll = l1ll11l1 [:-1]
    l1llll1 = l1l1lll % len (l1lll)
    l1l1l = l1lll [:l1llll1] + l1lll [l1llll1:]
    if l1111ll:
        l1lll111 = l11ll1l () .join ([unichr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    else:
        l1lll111 = str () .join ([chr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    return eval (l1lll111)
import hashlib
import os
import l11lll
from l1lllll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11lll import l11l1
from l11ll1 import l1ll1lll, l1lll1ll
import logging
logger = logging.getLogger(l11lll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l111():
    def __init__(self, l1ll1l,l1l11, l1ll11ll= None, l1111=None):
        self.l1l1ll1=False
        self.l1l1l1l = self._1ll1ll1()
        self.l1l11 = l1l11
        self.l1ll11ll = l1ll11ll
        self.l111 = l1ll1l
        if l1ll11ll:
            self.l1l11l1 = True
        else:
            self.l1l11l1 = False
        self.l1111 = l1111
    def _1ll1ll1(self):
        try:
            return l11lll.l1lllll() is not None
        except:
            return False
    def open(self):
        l11lll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1l1l:
            raise NotImplementedError(l11lll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11lll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1l1 = self.l111
        if self.l1l11.lower().startswith(self.l111.lower()):
            l1llllll = re.compile(re.escape(self.l111), re.IGNORECASE)
            l1l11 = l1llllll.sub(l11lll1 (u"ࠨࠩࠄ"), self.l1l11)
            l1l11 = l1l11.replace(l11lll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11lll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1l11(self.l111, l1l1l1, l1l11, self.l1ll11ll)
    def l1l1l11(self,l111, l1l1l1, l1l11, l1ll11ll):
        l11lll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11lll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1111 = l11l1l1(l111)
        l1l1 = self.l111ll(l1ll1111)
        logger.info(l11lll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1111)
        if l1l1:
            logger.info(l11lll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l1(l1ll1111)
            l1ll1111 = l11l11(l111, l1l1l1, l1ll11ll, self.l1111)
        logger.debug(l11lll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11=l1ll1111 + l11lll1 (u"ࠤ࠲ࠦࠌ") + l1l11
        ll = l11lll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11+ l11lll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(ll)
        l1ll111 = os.system(ll)
        if (l1ll111 != 0):
            raise IOError(l11lll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11, l1ll111))
    def l111ll(self, l1ll1111):
        if os.path.exists(l1ll1111):
            if os.path.islink(l1ll1111):
                l1ll1111 = os.readlink(l1ll1111)
            if os.path.ismount(l1ll1111):
                return True
        return False
def l11l1l1(l111):
    l1ll1l1 = l111.replace(l11lll1 (u"࠭࡜࡝ࠩࠐ"), l11lll1 (u"ࠧࡠࠩࠑ")).replace(l11lll1 (u"ࠨ࠱ࠪࠒ"), l11lll1 (u"ࠩࡢࠫࠓ"))
    l111l11 = l11lll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l11l=os.environ[l11lll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll1l=os.path.join(l11l11l,l111l11, l1ll1l1)
    l1l=os.path.abspath(l1lll1l)
    return l1l
def l1ll1ll(l1):
    if not os.path.exists(l1):
        os.makedirs(l1)
def l111111(l111, l1l1l1, l1l11l=None, password=None):
    l11lll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1 = l11l1l1(l111)
    l1ll1ll(l1)
    if not l1l11l:
        l111ll1 = l1lll11()
        l1ll1l1l =l111ll1.l1ll111l(l11lll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1l1 + l11lll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1l1 + l11lll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll1l1l, str):
            l1l11l, password = l1ll1l1l
        else:
            raise l1lll1ll()
        logger.info(l11lll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1))
    l1111l1 = pwd.getpwuid( os.getuid())[0]
    l1ll1l11=os.environ[l11lll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l11ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11={l11lll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1111l1, l11lll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111, l11lll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1, l11lll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll1l11, l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l11l, l11lll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11, temp_file)
        if not os.path.exists(os.path.join(l1l11ll, l11lll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l1111=l11lll1 (u"ࠦࡵࡿࠢࠣ")
            key=l11lll1 (u"ࠧࠨࠤ")
        else:
            l1l1111=l11lll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11lll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111l=l11lll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l1111,temp_file.name)
        l1llll1l=[l11lll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11lll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l11ll, l111l)]
        p = subprocess.Popen(l1llll1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11lll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11lll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11lll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1
    logger.debug(l11lll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11lll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11lll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11lll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l=os.path.abspath(l1)
    logger.debug(l11lll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l)
    return l1l
def l11l11(l111, l1l1l1, l1ll11ll, l1111):
    l11lll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11ll11(title):
        l1ll=30
        if len(title)>l1ll:
            l11l=title.split(l11lll1 (u"ࠨ࠯ࠣ࠳"))
            l1lll11l=l11lll1 (u"ࠧࠨ࠴")
            for block in l11l:
                l1lll11l+=block+l11lll1 (u"ࠣ࠱ࠥ࠵")
                if len(l1lll11l) > l1ll:
                    l1lll11l+=l11lll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll11l
        return title
    def l1llll(l11ll, password):
        l11lll1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11lll1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11lll1 (u"ࠧࠦࠢ࠹").join(l11ll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l1ll = l11lll1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l1ll.encode())
        l111l1 = [l11lll1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1111l = l11lll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1111l)
            for e in l111l1:
                if e in l1111l: return False
            raise l1ll1lll(l1111l, l11l11=l11lll.l1lllll(), l1l1l1=l1l1l1)
        logger.info(l11lll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l11l = l11lll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11lll1 (u"ࠦࠧ࠿")
    os.system(l11lll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l111l1l = l11l1l1(l111)
    l1 = l11l1l1(hashlib.sha1(l111.encode()).hexdigest()[:10])
    l1ll1ll(l1)
    logger.info(l11lll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1))
    if l1ll11ll:
        l11ll = [l11lll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11lll1 (u"ࠤ࠰ࡸࠧࡄ"), l11lll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11lll1 (u"ࠫ࠲ࡵࠧࡆ"), l11lll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l11l, l1ll11ll),
                    urllib.parse.unquote(l1l1l1), os.path.abspath(l1)]
        l1llll(l11ll, password)
    else:
        while True:
            l1l11l, password = l111lll(l1, l1l1l1, l1111)
            if l1l11l.lower() != l11lll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11ll = [l11lll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11lll1 (u"ࠤ࠰ࡸࠧࡋ"), l11lll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11lll1 (u"ࠫ࠲ࡵࠧࡍ"), l11lll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l11l,
                            urllib.parse.unquote(l1l1l1), os.path.abspath(l1)]
            else:
                raise l1lll1ll()
            if l1llll(l11ll, password): break
    os.system(l11lll1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1, l111l1l))
    l1l=os.path.abspath(l111l1l)
    return l1l
def l111lll(l111, l1l1l1, l1111):
    l1lll1 = os.path.join(os.environ[l11lll1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11lll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11lll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll1)):
       os.makedirs(os.path.dirname(l1lll1))
    l1l111l = l1111.get_value(l11lll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11lll1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l111ll1 = l1lll11(l111, l1l111l)
    l1l11l, password = l111ll1.l1ll111l(l11lll1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1l1 + l11lll1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1l1 + l11lll1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l11l != l11lll1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11111(l111, l1l11l):
        l1ll11l = l11lll1 (u"ࠤ࡙ࠣࠦ").join([l111, l1l11l, l11lll1 (u"࡚ࠪࠦࠬ") + password + l11lll1 (u"࡛ࠫࠧ࠭"), l11lll1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll1, l11lll1 (u"࠭ࡷࠬࠩ࡝")) as l11111l:
            l11111l.write(l1ll11l)
        os.chmod(l1lll1, 0o600)
    return l1l11l, password
def l11111(l111, l1l11l):
    l1lll1 = l1l111 = os.path.join(os.environ[l11lll1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11lll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11lll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll1):
        with open(l1lll1, l11lll1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lll1l1 = data[0].split(l11lll1 (u"ࠦࠥࠨࡢ"))
            if l111 == l1lll1l1[0] and l1l11l == l1lll1l1[1]:
                return True
    return False