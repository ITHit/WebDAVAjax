#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l = 2048
l11l1ll = 7
def l1l11 (l1lll):
    global l1lll1
    l1ll11l1 = ord (l1lll [-1])
    l1ll1ll = l1lll [:-1]
    l1l1ll1 = l1ll11l1 % len (l1ll1ll)
    l1llll1 = l1ll1ll [:l1l1ll1] + l1ll1ll [l1l1ll1:]
    if l1ll1l:
        l1ll1111 = l1lll1l1 () .join ([unichr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    else:
        l1ll1111 = str () .join ([chr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    return eval (l1ll1111)
import hashlib
import os
import l1l11l
from l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l11l import l111ll1
from l11l1l import l11111, l1ll11
import logging
logger = logging.getLogger(l1l11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l1():
    def __init__(self, l111l11,l1llll11, l1l11l1= None, l11ll11=None):
        self.l1l1=False
        self.l1lllll = self._11ll()
        self.l1llll11 = l1llll11
        self.l1l11l1 = l1l11l1
        self.l1l11ll = l111l11
        if l1l11l1:
            self.l1l1111 = True
        else:
            self.l1l1111 = False
        self.l11ll11 = l11ll11
    def _11ll(self):
        try:
            return l1l11l.l1l1l11() is not None
        except:
            return False
    def open(self):
        l1l11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lllll:
            raise NotImplementedError(l1l11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11lll = self.l1l11ll
        if self.l1llll11.lower().startswith(self.l1l11ll.lower()):
            l1111l = re.compile(re.escape(self.l1l11ll), re.IGNORECASE)
            l1llll11 = l1111l.sub(l1l11 (u"ࠨࠩࠄ"), self.l1llll11)
            l1llll11 = l1llll11.replace(l1l11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1l11(self.l1l11ll, l11lll, l1llll11, self.l1l11l1)
    def l1ll1l11(self,l1l11ll, l11lll, l1llll11, l1l11l1):
        l1l11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1l1l = l1llll(l1l11ll)
        l111lll = self.l111l1(l1l1l1l)
        logger.info(l1l11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1l1l)
        if l111lll:
            logger.info(l1l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111ll1(l1l1l1l)
            l1l1l1l = l1ll1ll1(l1l11ll, l11lll, l1l11l1, self.l11ll11)
        logger.debug(l1l11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1llll1l=l1l1l1l + l1l11 (u"ࠤ࠲ࠦࠌ") + l1llll11
        l1111 = l1l11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1llll1l+ l1l11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1111)
        l11ll1 = os.system(l1111)
        if (l11ll1 != 0):
            raise IOError(l1l11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1llll1l, l11ll1))
    def l111l1(self, l1l1l1l):
        if os.path.exists(l1l1l1l):
            if os.path.islink(l1l1l1l):
                l1l1l1l = os.readlink(l1l1l1l)
            if os.path.ismount(l1l1l1l):
                return True
        return False
def l1llll(l1l11ll):
    l11llll = l1l11ll.replace(l1l11 (u"࠭࡜࡝ࠩࠐ"), l1l11 (u"ࠧࡠࠩࠑ")).replace(l1l11 (u"ࠨ࠱ࠪࠒ"), l1l11 (u"ࠩࡢࠫࠓ"))
    l1ll1l1 = l1l11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l1l=os.environ[l1l11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l11l=os.path.join(l1l1l,l1ll1l1, l11llll)
    l1l111l=os.path.abspath(l11l11l)
    return l1l111l
def l1l111(l1ll11l):
    if not os.path.exists(l1ll11l):
        os.makedirs(l1ll11l)
def l1l1ll(l1l11ll, l11lll, l1lll111=None, password=None):
    l1l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll11l = l1llll(l1l11ll)
    l1l111(l1ll11l)
    if not l1lll111:
        ll = l1llllll()
        l1ll11ll =ll.l1lll1l(l1l11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11lll + l1l11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11lll + l1l11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11ll, str):
            l1lll111, password = l1ll11ll
        else:
            raise l1ll11()
        logger.info(l1l11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll11l))
    l1ll = pwd.getpwuid( os.getuid())[0]
    l1lllll1=os.environ[l1l11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11111l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll111l={l1l11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll, l1l11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l11ll, l1l11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll11l, l1l11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lllll1, l1l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll111, l1l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll111l, temp_file)
        if not os.path.exists(os.path.join(l11111l, l1l11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111ll=l1l11 (u"ࠦࡵࡿࠢࠣ")
            key=l1l11 (u"ࠧࠨࠤ")
        else:
            l111ll=l1l11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11l1l1=l1l11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111ll,temp_file.name)
        l11ll1l=[l1l11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11111l, l11l1l1)]
        p = subprocess.Popen(l11ll1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll11l
    logger.debug(l1l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l111l=os.path.abspath(l1ll11l)
    logger.debug(l1l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l111l)
    return l1l111l
def l1ll1ll1(l1l11ll, l11lll, l1l11l1, l11ll11):
    l1l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1lll(title):
        l111=30
        if len(title)>l111:
            l11l111=title.split(l1l11 (u"ࠨ࠯ࠣ࠳"))
            l1l1l1=l1l11 (u"ࠧࠨ࠴")
            for block in l11l111:
                l1l1l1+=block+l1l11 (u"ࠣ࠱ࠥ࠵")
                if len(l1l1l1) > l111:
                    l1l1l1+=l1l11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l1l1
        return title
    def l111l1l(l11l, password):
        l1l11 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l11 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l11 (u"ࠧࠦࠢ࠹").join(l11l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll1l1l = l1l11 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll1l1l.encode())
        l111111 = [l1l11 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11lll1 = l1l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11lll1)
            for e in l111111:
                if e in l11lll1: return False
            raise l11111(l11lll1, l1ll1ll1=l1l11l.l1l1l11(), l11lll=l11lll)
        logger.info(l1l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll111 = l1l11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l11 (u"ࠦࠧ࠿")
    os.system(l1l11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1111ll = l1llll(l1l11ll)
    l1ll11l = l1llll(hashlib.sha1(l1l11ll.encode()).hexdigest()[:10])
    l1l111(l1ll11l)
    logger.info(l1l11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll11l))
    if l1l11l1:
        l11l = [l1l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l11 (u"ࠤ࠰ࡸࠧࡄ"), l1l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l11 (u"ࠫ࠲ࡵࠧࡆ"), l1l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll111, l1l11l1),
                    urllib.parse.unquote(l11lll), os.path.abspath(l1ll11l)]
        l111l1l(l11l, password)
    else:
        while True:
            l1lll111, password = l1lll11l(l1ll11l, l11lll, l11ll11)
            if l1lll111.lower() != l1l11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l = [l1l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l11 (u"ࠤ࠰ࡸࠧࡋ"), l1l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l11 (u"ࠫ࠲ࡵࠧࡍ"), l1l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll111,
                            urllib.parse.unquote(l11lll), os.path.abspath(l1ll11l)]
            else:
                raise l1ll11()
            if l111l1l(l11l, password): break
    os.system(l1l11 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll11l, l1111ll))
    l1l111l=os.path.abspath(l1111ll)
    return l1l111l
def l1lll11l(l1l11ll, l11lll, l11ll11):
    l1lll1ll = os.path.join(os.environ[l1l11 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll1ll)):
       os.makedirs(os.path.dirname(l1lll1ll))
    l1ll1lll = l11ll11.get_value(l1l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l11 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    ll = l1llllll(l1l11ll, l1ll1lll)
    l1lll111, password = ll.l1lll1l(l1l11 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11lll + l1l11 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11lll + l1l11 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll111 != l1l11 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11l11(l1l11ll, l1lll111):
        l1lll11 = l1l11 (u"ࠤ࡙ࠣࠦ").join([l1l11ll, l1lll111, l1l11 (u"࡚ࠪࠦࠬ") + password + l1l11 (u"࡛ࠫࠧ࠭"), l1l11 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll1ll, l1l11 (u"࠭ࡷࠬࠩ࡝")) as l11:
            l11.write(l1lll11)
        os.chmod(l1lll1ll, 0o600)
    return l1lll111, password
def l11l11(l1l11ll, l1lll111):
    l1lll1ll = l1ll111 = os.path.join(os.environ[l1l11 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll1ll):
        with open(l1lll1ll, l1l11 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l = data[0].split(l1l11 (u"ࠦࠥࠨࡢ"))
            if l1l11ll == l1l[0] and l1lll111 == l1l[1]:
                return True
    return False