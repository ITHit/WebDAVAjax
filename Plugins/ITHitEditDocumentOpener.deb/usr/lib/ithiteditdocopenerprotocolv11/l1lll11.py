#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1l1l1l = 2048
l111l = 7
def l1111 (l1ll1l11):
    global l11l111
    l1lll11l = ord (l1ll1l11 [-1])
    l1l11ll = l1ll1l11 [:-1]
    l111lll = l1lll11l % len (l1l11ll)
    l1l111l = l1l11ll [:l111lll] + l1l11ll [l111lll:]
    if l11ll1:
        l11l1ll = l1l111 () .join ([unichr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    return eval (l11l1ll)
import logging
import os
import re
from l1ll1ll1 import l1lll11ll
logger = logging.getLogger(l1111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1llll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1111 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll11():
    try:
        out = os.popen(l1111 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1111 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1111 (u"ࠤࠥॸ").join(result)
                logger.info(l1111 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1111 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1111 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1111 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll11ll(l1111 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1111 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1llll1(l1111 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))