#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l = 2048
l11l1ll = 7
def l1l11 (l1lll):
    global l1lll1
    l1ll11l1 = ord (l1lll [-1])
    l1ll1ll = l1lll [:-1]
    l1l1ll1 = l1ll11l1 % len (l1ll1ll)
    l1llll1 = l1ll1ll [:l1l1ll1] + l1ll1ll [l1l1ll1:]
    if l1ll1l:
        l1ll1111 = l1lll1l1 () .join ([unichr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    else:
        l1ll1111 = str () .join ([chr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    return eval (l1ll1111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l11l import l111ll1
from configobj import ConfigObj
l1l1ll11 = l1l11 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l11lllll = l1l11 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠷࠸࠲࠵ࠨࡤ")
l11llll1 = l1l11 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l11 (u"ࠣ࠸࠱࠴࠳࠾࠷࠶࠷࠱࠴ࠧࡦ")
l1l1llll=os.path.join(os.environ.get(l1l11 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l11 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11llll1.replace(l1l11 (u"ࠦࠥࠨࡩ"), l1l11 (u"ࠧࡥࠢࡪ")).lower())
l11ll1ll=os.environ.get(l1l11 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1ll1l=l11lllll.replace(l1l11 (u"ࠣࠢࠥ࡭"), l1l11 (u"ࠤࡢࠦ࡮"))+l1l11 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11111=os.path.join(os.environ.get(l1l11 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1ll1l)
elif platform.system() == l1l11 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l111l1=l111ll1(l1l1llll+l1l11 (u"ࠢ࠰ࠤࡳ"))
    l1l11111 = os.path.join(l1l111l1, l1l1ll1l)
else:
    l1l11111 = os.path.join( l1l1ll1l)
l11ll1ll=l11ll1ll.upper()
if l11ll1ll == l1l11 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11ll11l=logging.DEBUG
elif l11ll1ll == l1l11 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11ll11l = logging.INFO
elif l11ll1ll == l1l11 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11ll11l = logging.WARNING
elif l11ll1ll == l1l11 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11ll11l = logging.ERROR
elif l11ll1ll == l1l11 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11ll11l = logging.CRITICAL
elif l11ll1ll == l1l11 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11ll11l = logging.NOTSET
logger = logging.getLogger(l1l11 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11ll11l)
l1l11ll1 = logging.FileHandler(l1l11111, mode=l1l11 (u"ࠣࡹ࠮ࠦࡻ"))
l1l11ll1.setLevel(l11ll11l)
formatter = logging.Formatter(l1l11 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l11 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11ll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll11l)
l11l1lll = SysLogHandler(address=l1l11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11l1lll.setFormatter(formatter)
logger.addHandler(l1l11ll1)
logger.addHandler(ch)
logger.addHandler(l11l1lll)
class Settings():
    l1l111ll = l1l11 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1lll1 = l1l11 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1111l = l1l11 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11lllll):
        self.l11ll111 = self._1l1l1ll(l11lllll)
        self._1l11lll()
    def _1l1l1ll(self, l11lllll):
        l1l1l1l1 = l11lllll.split(l1l11 (u"ࠣࠢࠥࢂ"))
        l1l1l1l1 = l1l11 (u"ࠤࠣࠦࢃ").join(l1l1l1l1)
        if platform.system() == l1l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11ll111 = os.path.join(l1l1llll, l1l11 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l1l1 + l1l11 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11ll111
    def l1l11l1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l11 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l11 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll1l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11lll(self):
        if not os.path.exists(os.path.dirname(self.l11ll111)):
            os.makedirs(os.path.dirname(self.l11ll111))
        if not os.path.exists(self.l11ll111):
            self.config = ConfigObj(self.l11ll111)
            self.config[l1l11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l11 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l11 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1111l
            self.config[l1l11 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1lll1
            self.config[l1l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l111ll
            self.config[l1l11 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll111)
            self.l1l1111l = self.get_value(l1l11 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l11 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1lll1 = self.get_value(l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l111ll = self.get_value(l1l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lll11(self):
        l1l1l11l = l1l11 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l111ll
        l1l1l11l += l1l11 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1lll1
        l1l1l11l += l1l11 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1111l
        return l1l1l11l
    def __unicode__(self):
        return self._11lll11()
    def __str__(self):
        return self._11lll11()
    def __del__(self):
        self.config.write()
l1l1l111 = Settings(l11lllll)