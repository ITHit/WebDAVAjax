#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l111l = 2048
l11llll = 7
def l11 (l1ll11):
    global l111l
    l1lll1l = ord (l1ll11 [-1])
    l1ll1l = l1ll11 [:-1]
    l1ll1l1 = l1lll1l % len (l1ll1l)
    l1111 = l1ll1l [:l1ll1l1] + l1ll1l [l1ll1l1:]
    if l1l111:
        l1ll1 = l1l11ll () .join ([unichr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    else:
        l1ll1 = str () .join ([chr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    return eval (l1ll1)
import gi
gi.require_version(l11 (u"ࠨࡉࡷ࡯ࠬঽ"), l11 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11ll111
import logging
logger = logging.getLogger(l11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1lll11l(Gtk.Window):
    def __init__(self, l1ll1l1l11, l1l1l1llll):
        Gtk.Window.__init__(self)
        self.l11111=30
        self.l1ll1ll1ll = False
        self.service = l1ll1l1l11
        self.l1lll1=l1l1l1llll
        self.l1l1ll=l11ll111.l1l1llll
        self.l1l1ll111l = Gtk.ListStore(str)
        self.l1l11ll111()
    def l1l1l11l1l(self, service):
        l1l11lll1l = self.l1l1ll.l1l1l111(l11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l11lll1l
    def l1l11ll111(self, l1ll1l1l11=None):
        if l1ll1l1l11:
            self.l1l1ll111l.clear()
            l1ll1ll1l1=self.l1l1l11l1l(l1ll1l1l11)
            self.l1l1ll111l.append([l11 (u"ࠧࠨু")])
            for l1lll1 in l1ll1ll1l1:
                self.l1l1ll111l.append([l1lll1])
        else:
            self.l1l1ll111l.clear()
            self.l1l1ll111l.append([l11 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1l11lll(self, widget, data=None):
        l1l1l111ll= widget.get_active()
        if data == l11 (u"ࠢ࠲ࠤৃ") and l1l1l111ll:
            self.l1l11ll111()
            self.l1l1lll1ll.set_active(0)
            self.l1ll1llll1.set_text(l11 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1llll1.set_sensitive(False)
            self.l1l1lll1ll.set_sensitive(False)
        else:
            self.l1l11ll111(l1ll1l1l11=self.service)
            self.l1l1lll1ll.set_active(0)
            self.l1ll1llll1.set_text(l11 (u"ࠤࠥ৅"))
            self.l1l1lll1ll.set_sensitive(True)
            self.l1ll1llll1.set_sensitive(True)
    def l1l1llllll(self, widget):
        if widget.get_active():
            l1lll1 = widget.get_child().get_text()
        else:
            l1lll1 = self.l1l1ll111l[widget.get_active()][0]
        password = self.l1ll11llll(self.service, l1lll1)
        if password:
            self.l1ll1llll1.set_text(password)
        else:
            self.l1ll1llll1.set_text(l11 (u"ࠥࠦ৆"))
    def l1l1llll1l(self, l1lll1, pwd, service):
        keyring.set_password(service, l1lll1, pwd)
        l1l11lll1l=self.l1l1ll.l1l1l111(l11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1lll1 in l1l11lll1l:
            value = self.l1l1ll.get_value(l11 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l1ll.l1l11l1l(l11 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l11 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1lll1))
    def l1ll11llll(self, service, l1lll1):
        l1ll1l1lll = keyring.get_password(service, l1lll1)
        return l1ll1l1lll
    def l1l11ll1ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1l1lll1(self, widget, data=None):
        self.l1ll1ll1ll=widget.get_active()
    def l1l11(self, message, title=l11 (u"ࠨࠩো"), l111ll11l=True):
        if l111ll11l:
            l1l1l1ll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1ll11l1 = Gtk.MessageDialog(self,
            l1l1l1ll11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1ll11l1.set_title(title)
        l1l1ll11l1.set_default_response(Gtk.ResponseType.OK)
        l1l1l1l1l1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1ll1l1l = Gtk.VBox()
        l1ll111111 = Gtk.Box(spacing=1)
        l1ll111111.set_homogeneous(False)
        l1l1lll11l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll11l.set_homogeneous(False)
        l1l11l11ll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l11ll.set_homogeneous(False)
        l1ll111111.pack_start(l1l1lll11l, True, True, 0)
        l1ll111111.pack_start(l1l11l11ll, True, True, 0)
        l1l1ll1l11 = l1l1ll11l1.get_content_area()
        l1ll1l11ll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1ll1l11.pack_start(l1ll1l11ll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1ll1lll = Gtk.Label()
        l1l1l1l1ll = Gtk.Label()
        l1l1l1l1ll.set_text(l11 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1l1l1ll, True, True, 0)
        l1l1ll1lll.set_text(l11 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1ll1lll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1ll1lll, 0, 1, 0, 1)
        l1l1llll11 = Gtk.RadioButton.new_with_label_from_widget(None, l11 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1llll11.connect(l11 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1l11lll, l11 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1llll11, 1, 2, 0, 1)
        l1ll1ll11l = Gtk.RadioButton.new_with_label_from_widget(l1l1llll11, l11 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll1ll11l.connect(l11 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1l11lll, l11 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll1ll11l, 1, 2, 1, 2)
        l1ll111ll1 = Gtk.Label()
        l1ll111ll1.set_text(l11 (u"ࠥࠤࠧ৔"))
        table.attach(l1ll111ll1, 0, 1, 4, 6)
        l1l1l1ll1l = Gtk.Label()
        l1l1l1ll1l.set_text(l11 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1l1ll1l.set_justify(Gtk.Justification.RIGHT)
        l1l1l1ll1l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1lll1ll = Gtk.ComboBox.new_with_model_and_entry(self.l1l1ll111l)
        self.l1l1lll1ll.set_entry_text_column(0)
        table.attach(l1l1l1ll1l, 0, 1, 6, 8)
        table.attach(self.l1l1lll1ll, 1, 3, 6, 8)
        self.l1l1lll1ll.connect(l11 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1llllll)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l11 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1111ll.set_justify(Gtk.Justification.RIGHT)
        l1ll1111ll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1llll1 = Gtk.Entry()
        self.l1ll1llll1.set_visibility(False)
        self.l1ll1llll1.connect(l11 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l11ll1ll, l1l1ll11l1)
        table.attach(l1ll1111ll, 0, 1, 8, 10)
        table.attach(self.l1ll1llll1, 1, 3, 8, 10)
        l1ll111lll = Gtk.CheckButton(l11 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll111lll.connect(l11 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1l1lll1, l1ll111lll)
        l1ll111lll.set_active(False)
        table.attach(l1ll111lll, 1, 3, 12, 14)
        l1l11ll11l = Gtk.Label()
        l1l11ll11l.set_text(l11 (u"ࠥࠤࠧ৛") * 5)
        l1l1ll1l1l.pack_start(l1l11ll11l, True, True, 0)
        if self.l1lll1:
            l1ll1ll11l.set_active(True)
            self.l1l1lll1ll.set_active(0)
            self.l1l1lll1ll.set_sensitive(True)
            self.l1ll1llll1.set_text(l11 (u"ࠦࠧড়"))
            self.l1ll1llll1.set_sensitive(True)
        else:
            self.l1l1lll1ll.set_active(0)
            self.l1l1lll1ll.set_sensitive(False)
            self.l1ll1llll1.set_text(l11 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1llll1.set_sensitive(False)
        l1l1l1l1l1.pack_start(vbox, True, True, 0)
        l1l1l1l1l1.pack_start(table, True, True, 0)
        l1l1l1l1l1.pack_end(l1l1ll1l1l, True, True, 0)
        l1ll1l11ll.pack_start(l1l1l1l1l1, True, True, 0)
        l1l1ll11l1.show_all()
        response = l1l1ll11l1.run()
        if self.l1l1lll1ll.get_active():
            l1lll1 = self.l1l1lll1ll.get_child().get_text()
        else:
            l1lll1 = self.l1l1ll111l[self.l1l1lll1ll.get_active()][0]
        pwd = self.l1ll1llll1.get_text()
        l1l1ll11l1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll1ll1ll:
                self.l1l1llll1l(l1lll1, pwd, self.service)
            return l1lll1, pwd
        else:
            return l11 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l11 (u"ࠧࠨয়")
class l111l11ll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1l1111l(self, l11l1lll):
        l1ll1lll1l = Gtk.ScrolledWindow()
        l1ll1lll1l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll111l11=None
        self.l1l1ll11ll = Gtk.TextBuffer()
        self.l1l1ll11ll.set_text(l11l1lll)
        self.set_style()
        regexp= l11 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll11ll11 = self._1l1l11l11(l11l1lll, regexp)
        self.l1ll1111l1(l1ll11ll11, self.l1l1ll11ll.get_start_iter())
        self.l1ll1l1ll1 = Gtk.TextView(buffer=self.l1l1ll11ll)
        self.l1ll1l1ll1.set_property(l11 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll1l1ll1.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll1l1ll1.connect(l11 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll1ll111)
        self.l1ll1l1ll1.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1lll1l.set_size_request(300,100)
        self.l1ll1l1ll1.show()
        l1ll1lll1l.add(self.l1ll1l1ll1)
        l1ll1lll1l.show()
        return l1ll1lll1l
    def _1ll1ll111(self, *args, **kwargs):
        l1l11ll1l1, l1l1l1l111=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l11ll1l1, l1l1l1l111).get_tags()
        if not self.l1ll111l11:
            self.l1ll111l11 = args[1].window.get_cursor()
            self.l1l1ll1ll1 = Gdk.Cursor(Gdk.CursorType.l1l11l1lll)
        elif tag:
            args[1].window.set_cursor(self.l1l1ll1ll1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll111l11:
                args[1].window.set_cursor(self.l1ll111l11)
    def _1l1l11l11(self, l11l1lll, l1l11l1l11):
        res=[]
        l1ll1l11l1=re.findall(l1l11l1l11,l11l1lll)
        for l1l1l11ll1 in l1ll1l11l1:
            for el in l1l1l11ll1:
                if el:
                    res.append(el)
        return res
    def l1ll1111l1(self, l1ll11ll11, start):
        l1ll11l11l=0
        for text in l1ll11ll11:
            end = self.l1l1ll11ll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll11l11l+=1
                l1ll1l1l1l, l1ll1lllll = match
                tag = self.l1l1ll11ll.create_tag(str(l1ll11l11l), foreground=l11 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l11 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1lll111, text)
                self.l1l1ll11ll.apply_tag(tag, l1ll1l1l1l, l1ll1lllll)
                self.l1ll1111l1(l1ll11ll11, l1ll1lllll)
    def _1l1lll111(self, tag, widget, l1ll11l111, _1ll11l1ll, text):
        _1l11lllll = l1ll11l111.type
        _1ll1lll11 = l1ll11l111.window
        if _1l11lllll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11lllll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll11l111.button
            self.l1ll111l11 = Gdk.Cursor(Gdk.CursorType.l1l11l1lll)
            if _1l11lllll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l11 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l111l1111(self, message, title=l11 (u"ࠧࠨ০"), l111ll11l=True, l1l1lllll1=None):
        if l111ll11l:
            l1l1l1ll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1l1ll11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1lllll1:
            l1l1ll1l11 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll111111 = Gtk.HBox(spacing=0)
            l1l1l1l11l = Gtk.HBox(spacing=5)
            l1ll11l1l1 = Gtk.Label()
            l1ll11l1l1.set_markup(l11 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll11l1l1.set_line_wrap(True)
            l1ll11l1l1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l11 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll111l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111l1l.show()
            l1l1lll1l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll1l1.show()
            l1l1l11111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11111.show()
            l1ll111111.pack_start(separator, True, True, 0)
            l1ll111111.pack_start(l1ll111l1l, True, True, 0)
            l1ll111111.pack_start(l1l1lll1l1, True, True, 0)
            l1ll111111.pack_start(l1l1l11111, True, True, 0)
            l1ll111111.pack_start(l1ll11l1l1, False, True, 0)
            l1l1ll1111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1111.show()
            l1ll111111.pack_end(l1l1ll1111, True, True, 0)
            l1ll11lll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11lll1.show()
            vbox.pack_start(l1ll111111, True, True, 0)
            l1ll1lll1l=self.__1l1l1111l(l11l1lll=l1l1lllll1)
            vbox.pack_start(l1ll1lll1l, False, False, 0)
            vbox.pack_end(l1ll11lll1, False, False, 0)
            l1l1l1l11l.pack_start(vbox, True, True,5)
            l1l1l1l11l.show()
            l1l1ll1l11.pack_end(l1l1l1l11l, False, False, 0)
            vbox.show()
            l1ll111111.show()
        window.run()
class l11ll11ll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l111l1(self, widget, l1ll11ll1l):
        if l1ll11ll1l == Gtk.ResponseType.OK:
            self.result = l11 (u"ࠥࡓࡐࠨ৩")
        elif l1ll11ll1l == Gtk.ResponseType.CANCEL:
            self.result = l11 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll11ll1l == Gtk.ResponseType.DELETE_EVENT:
            self.result = l11 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1l11l1l1(self, title=l11 (u"ࠨࠢ৬"), message=l11 (u"ࠢࠣ৭") , l111ll11l=True):
        if l111ll11l:
            l1l1l1ll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l1ll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l11 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1l111l1)
        window.run()
class l1l11l1l1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l11lll11=None
        self.result = None
    def l1l1l111l1(self, widget, l1ll11ll1l):
        print(widget, l1ll11ll1l)
        if l1ll11ll1l == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll11ll1l == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll11ll1l == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1l1lll1(self, widget, l1ll1l111l):
        if l1ll1l111l.get_active():
            self.l1l11lll11 = 1
        else:
            self.l1l11lll11 = 0
    def l1ll1l1111(self, title=l11 (u"ࠤࠥ৯"), message=l11 (u"ࠥࠦৰ"), l1l11llll1 =l11 (u"ࠦࠧৱ"),l111ll11l=True):
        if l111ll11l:
            l1l1l1ll11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l1ll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l11 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1l111l1)
        l1ll111lll = Gtk.CheckButton(l1l11llll1)
        l1ll111lll.connect(l11 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1l1lll1, l1ll111lll)
        l1ll111lll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll111lll, expand=True, fill=True, padding=0)
        l1ll111lll.show()
        window.run()
def l11l11111(title, msg, l1l11llll1=l11 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l111ll11l=True):
    result=None
    try:
        l1l11l1ll1 = l1l11l1l1l()
        l1l11l1ll1.l1ll1l1111(title, msg, l1l11llll1, l111ll11l)
        result = {l11 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l11l1ll1.result,  l11 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l11l1ll1.l1l11lll11}
    except Exception as e:
        logger.exception(l11 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l11 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11l1llll = l111l11ll()
    message= l11 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll11111l = l11 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11l1llll.l111l1111(message, l11 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l111ll11l=True, l1l1lllll1=l1ll11111l)