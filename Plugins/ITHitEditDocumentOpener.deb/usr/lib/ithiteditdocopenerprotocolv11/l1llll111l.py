#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l111l = 2048
l11llll = 7
def l11 (l1ll11):
    global l111l
    l1lll1l = ord (l1ll11 [-1])
    l1ll1l = l1ll11 [:-1]
    l1ll1l1 = l1lll1l % len (l1ll1l)
    l1111 = l1ll1l [:l1ll1l1] + l1ll1l [l1ll1l1:]
    if l1l111:
        l1ll1 = l1l11ll () .join ([unichr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    else:
        l1ll1 = str () .join ([chr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    return eval (l1ll1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11ll=logging.WARNING
logger = logging.getLogger(l11 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll11ll)
l11llll1 = SysLogHandler(address=l11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11llll1.setFormatter(formatter)
logger.addHandler(l11llll1)
ch = logging.StreamHandler()
ch.setLevel(l1llll11ll)
logger.addHandler(ch)
class l1lllll111(io.FileIO):
    l11 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1ll1l, l1llllll1l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll1l = l1lll1ll1l
            self.l1llllll1l = l1llllll1l
            if not options:
                options = l11 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1ll1l,
                                              self.l1llllll1l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11ll1 = os.path.join(os.path.sep, l11 (u"ࠪࡩࡹࡩࠧই"), l11 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1llll = path
        else:
            self._1lll1llll = self.l1lll11ll1
        super(l1lllll111, self).__init__(self._1lll1llll, l11 (u"ࠬࡸࡢࠬࠩউ"))
    def _1llllll11(self, line):
        return l1lllll111.Entry(*[x for x in line.strip(l11 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11 (u"ࠤࠦࠦ঍")):
                    yield self._1llllll11(line)
            except ValueError:
                pass
    def l1llll1111(self, attr, value):
        for entry in self.entries:
            l1llll1l1l = getattr(entry, attr)
            if l1llll1l1l == value:
                return entry
        return None
    def l1lllll11l(self, entry):
        if self.l1llll1111(l11 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11 (u"ࠫࡡࡴࠧএ")).encode(l11 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllllll1(self, entry):
        self.seek(0)
        lines = [l.decode(l11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11 (u"ࠢࠤࠤ঒")):
                if self._1llllll11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11 (u"ࠨࠩও").join(lines).encode(l11 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1lll1(cls, l1lll1ll1l, path=None):
        l1lll1ll11 = cls(path=path)
        entry = l1lll1ll11.l1llll1111(l11 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1ll1l)
        if entry:
            return l1lll1ll11.l1lllllll1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll1l, l1llllll1l, options=None, path=None):
        return cls(path=path).l1lllll11l(l1lllll111.Entry(device,
                                                    l1lll1ll1l, l1llllll1l,
                                                    options=options))
class l1lll1l1l1(object):
    def __init__(self, l1lllll1ll):
        self.l1llll1ll1=l11 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11l11=l11 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll1ll=l1lllll1ll
        self.l1lll1111l()
        self.l1lll111l1()
        self.l1lll1l11l()
        self.l1lllll1l1()
        self.l1lll111ll()
    def l1lll1111l(self):
        temp_file=open(l1lll1l1ll,l11 (u"࠭ࡲࠨঘ"))
        l11l1l1=temp_file.read()
        data=json.loads(l11l1l1)
        self.user=data[l11 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1lll11=data[l11 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l111l1=data[l11 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1111l=data[l11 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11l1l=data[l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll11111=data[l11 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l11l(self):
        l11l=os.path.join(l11 (u"ࠨ࠯ࠣট"),l11 (u"ࠢࡶࡵࡵࠦঠ"),l11 (u"ࠣࡵࡥ࡭ࡳࠨড"),l11 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11l)
    def l1lll111ll(self):
        logger.info(l11 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l111l1=os.path.join(self.l1111l,self.l1llll1ll1)
        l1llll1lll = pwd.getpwnam(self.user).pw_uid
        l1lll11lll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l111l1):
            os.makedirs(l111l1)
            os.system(l11 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l111l1))
            logger.debug(l11 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l111l1)
        else:
            logger.debug(l11 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l111l1)
        l11l=os.path.join(l111l1, self.l1lll11l11)
        print(l11l)
        logger.debug(l11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11l)
        with open(l11l, l11 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l111:
            logger.debug(self.l1lll11 + l11 (u"ࠪࠤࠬপ")+self.l1lll11l1l+l11 (u"ࠫࠥࠨࠧফ")+self.l1lll11111+l11 (u"ࠬࠨࠧব"))
            l1lll1l111.writelines(self.l1lll11 + l11 (u"࠭ࠠࠨভ")+self.l1lll11l1l+l11 (u"ࠧࠡࠤࠪম")+self.l1lll11111+l11 (u"ࠨࠤࠪয"))
        os.chmod(l11l, 0o600)
        os.chown(l11l, l1llll1lll, l1lll11lll)
    def l1lll111l1(self, l1llll11l1=l11 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11l1 in groups:
            logger.info(l11 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll11l1))
        else:
            logger.warning(l11 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll11l1))
            l1111ll=l11 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll11l1,self.user)
            logger.debug(l11 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1111ll)
            os.system(l1111ll)
            logger.debug(l11 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lllll1l1(self):
        logger.debug(l11 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1ll11=l1lllll111()
        l1lll1ll11.add(self.l1lll11, self.l111l1, l1llllll1l=l11 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1l1ll = urllib.parse.unquote(sys.argv[1])
        if l1lll1l1ll:
            l1llll1l11=l1lll1l1l1(l1lll1l1ll)
        else:
            raise (l11 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise