#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1lll = 7
def l111ll1 (l11l111):
    global l1lll11l
    l1111ll = ord (l11l111 [-1])
    l1lll1l1 = l11l111 [:-1]
    l1lll1l = l1111ll % len (l1lll1l1)
    l1llll = l1lll1l1 [:l1lll1l] + l1lll1l1 [l1lll1l:]
    if l1l1111:
        l11l1ll = l1lllll () .join ([unichr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    return eval (l11l1ll)
import hashlib
import os
import l1l1lll
from l1l111l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1lll import l111111
from l1l1l11 import l1lll, l1ll11
import logging
logger = logging.getLogger(l111ll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l11l():
    def __init__(self, l1l1l1l,l1lll1ll, l1ll1l1= None, l1lll111=None):
        self.l1ll1l11=False
        self.l111l1 = self._1lllll1()
        self.l1lll1ll = l1lll1ll
        self.l1ll1l1 = l1ll1l1
        self.l111 = l1l1l1l
        if l1ll1l1:
            self.l1l111 = True
        else:
            self.l1l111 = False
        self.l1lll111 = l1lll111
    def _1lllll1(self):
        try:
            return l1l1lll.l1ll1l1l() is not None
        except:
            return False
    def open(self):
        l111ll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111l1:
            raise NotImplementedError(l111ll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111ll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l11ll = self.l111
        if self.l1lll1ll.lower().startswith(self.l111.lower()):
            l11lll1 = re.compile(re.escape(self.l111), re.IGNORECASE)
            l1lll1ll = l11lll1.sub(l111ll1 (u"ࠨࠩࠄ"), self.l1lll1ll)
            l1lll1ll = l1lll1ll.replace(l111ll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l111ll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll(self.l111, l1l11ll, l1lll1ll, self.l1ll1l1)
    def l11ll(self,l111, l1l11ll, l1lll1ll, l1ll1l1):
        l111ll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111ll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll111l = l1llllll(l111)
        l1ll1 = self.l11l1l(l1ll111l)
        logger.info(l111ll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll111l)
        if l1ll1:
            logger.info(l111ll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111111(l1ll111l)
            l1ll111l = l1ll11l(l111, l1l11ll, l1ll1l1, self.l1lll111)
        logger.debug(l111ll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1ll1=l1ll111l + l111ll1 (u"ࠤ࠲ࠦࠌ") + l1lll1ll
        l11l11 = l111ll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1ll1+ l111ll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11l11)
        l1lll11 = os.system(l11l11)
        if (l1lll11 != 0):
            raise IOError(l111ll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1ll1, l1lll11))
    def l11l1l(self, l1ll111l):
        if os.path.exists(l1ll111l):
            if os.path.islink(l1ll111l):
                l1ll111l = os.readlink(l1ll111l)
            if os.path.ismount(l1ll111l):
                return True
        return False
def l1llllll(l111):
    l1l1ll1 = l111.replace(l111ll1 (u"࠭࡜࡝ࠩࠐ"), l111ll1 (u"ࠧࡠࠩࠑ")).replace(l111ll1 (u"ࠨ࠱ࠪࠒ"), l111ll1 (u"ࠩࡢࠫࠓ"))
    l1111l1 = l111ll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l1l1=os.environ[l111ll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11111=os.path.join(l1l1l1,l1111l1, l1l1ll1)
    l1l1ll=os.path.abspath(l11111)
    return l1l1ll
def l11(l1l11l1):
    if not os.path.exists(l1l11l1):
        os.makedirs(l1l11l1)
def l1ll111(l111, l1l11ll, l1ll=None, password=None):
    l111ll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l11l1 = l1llllll(l111)
    l11(l1l11l1)
    if not l1ll:
        l1ll1ll = l11ll11()
        l1llll1l =l1ll1ll.l111l(l111ll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l11ll + l111ll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l11ll + l111ll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll1l, str):
            l1ll, password = l1llll1l
        else:
            raise l1ll11()
        logger.info(l111ll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l11l1))
    l1111l = pwd.getpwuid( os.getuid())[0]
    l1llll1=os.environ[l111ll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l11l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11l1={l111ll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1111l, l111ll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111, l111ll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l11l1, l111ll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1llll1, l111ll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll, l111ll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11l1, temp_file)
        if not os.path.exists(os.path.join(l11l11l, l111ll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l11=l111ll1 (u"ࠦࡵࡿࠢࠣ")
            key=l111ll1 (u"ࠧࠨࠤ")
        else:
            l1l11=l111ll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111ll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1=l111ll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l11,temp_file.name)
        l111l1l=[l111ll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111ll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l11l, l1l1)]
        p = subprocess.Popen(l111l1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111ll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111ll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111ll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l11l1
    logger.debug(l111ll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111ll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111ll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111ll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1ll=os.path.abspath(l1l11l1)
    logger.debug(l111ll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1ll)
    return l1l1ll
def l1ll11l(l111, l1l11ll, l1ll1l1, l1lll111):
    l111ll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1111(title):
        l11l1l1=30
        if len(title)>l11l1l1:
            l11111l=title.split(l111ll1 (u"ࠨ࠯ࠣ࠳"))
            ll=l111ll1 (u"ࠧࠨ࠴")
            for block in l11111l:
                ll+=block+l111ll1 (u"ࠣ࠱ࠥ࠵")
                if len(ll) > l11l1l1:
                    ll+=l111ll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=ll
        return title
    def l1l(l1, password):
        l111ll1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111ll1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111ll1 (u"ࠧࠦࠢ࠹").join(l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l111l11 = l111ll1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l111l11.encode())
        l11ll1 = [l111ll1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11lll = l111ll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11lll)
            for e in l11ll1:
                if e in l11lll: return False
            raise l1lll(l11lll, l1ll11l=l1l1lll.l1ll1l1l(), l1l11ll=l1l11ll)
        logger.info(l111ll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1ll = l111ll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111ll1 (u"ࠦࠧ࠿")
    os.system(l111ll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll1 = l1llllll(l111)
    l1l11l1 = l1llllll(hashlib.sha1(l111.encode()).hexdigest()[:10])
    l11(l1l11l1)
    logger.info(l111ll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l11l1))
    if l1ll1l1:
        l1 = [l111ll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111ll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111ll1 (u"ࠤ࠰ࡸࠧࡄ"), l111ll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111ll1 (u"ࠫ࠲ࡵࠧࡆ"), l111ll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1ll, l1ll1l1),
                    urllib.parse.unquote(l1l11ll), os.path.abspath(l1l11l1)]
        l1l(l1, password)
    else:
        while True:
            l1ll, password = l1ll1l(l1l11l1, l1l11ll, l1lll111)
            if l1ll.lower() != l111ll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1 = [l111ll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111ll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111ll1 (u"ࠤ࠰ࡸࠧࡋ"), l111ll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111ll1 (u"ࠫ࠲ࡵࠧࡍ"), l111ll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1ll,
                            urllib.parse.unquote(l1l11ll), os.path.abspath(l1l11l1)]
            else:
                raise l1ll11()
            if l1l(l1, password): break
    os.system(l111ll1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l11l1, l1lll1))
    l1l1ll=os.path.abspath(l1lll1)
    return l1l1ll
def l1ll1l(l111, l1l11ll, l1lll111):
    l1l1l = os.path.join(os.environ[l111ll1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111ll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111ll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l1l)):
       os.makedirs(os.path.dirname(l1l1l))
    l1ll1111 = l1lll111.get_value(l111ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111ll1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll1ll = l11ll11(l111, l1ll1111)
    l1ll, password = l1ll1ll.l111l(l111ll1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l11ll + l111ll1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l11ll + l111ll1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1ll != l111ll1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11ll1l(l111, l1ll):
        l11l = l111ll1 (u"ࠤ࡙ࠣࠦ").join([l111, l1ll, l111ll1 (u"࡚ࠪࠦࠬ") + password + l111ll1 (u"࡛ࠫࠧ࠭"), l111ll1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l1l, l111ll1 (u"࠭ࡷࠬࠩ࡝")) as l1llll11:
            l1llll11.write(l11l)
        os.chmod(l1l1l, 0o600)
    return l1ll, password
def l11ll1l(l111, l1ll):
    l1l1l = l11llll = os.path.join(os.environ[l111ll1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111ll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111ll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l1l):
        with open(l1l1l, l111ll1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l111lll = data[0].split(l111ll1 (u"ࠦࠥࠨࡢ"))
            if l111 == l111lll[0] and l1ll == l111lll[1]:
                return True
    return False