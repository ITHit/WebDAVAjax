#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import logging
import os
import re
from l1l1111 import l1llll111
logger = logging.getLogger(l1lll11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1l1l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll11 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll():
    try:
        out = os.popen(l1lll11 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll11 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll11 (u"ࠤࠥॸ").join(result)
                logger.info(l1lll11 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll11 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll11 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll11 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll111(l1lll11 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll11 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1l1l(l1lll11 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))