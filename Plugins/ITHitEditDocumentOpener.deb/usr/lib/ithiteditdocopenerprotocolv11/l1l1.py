#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11l = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l111 (l11lll):
    global l1ll111
    l11l1l = ord (l11lll [-1])
    l1l11l1 = l11lll [:-1]
    l1ll1l = l11l1l % len (l1l11l1)
    l1lll111 = l1l11l1 [:l1ll1l] + l1l11l1 [l1ll1l:]
    if l11l11l:
        l111 = l1l11 () .join ([unichr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    else:
        l111 = str () .join ([chr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    return eval (l111)
import re
class l1ll11(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111l1 = kwargs.get(l1l111 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11ll11 = kwargs.get(l1l111 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllllll = self.l1lllll11(args)
        if l1lllllll:
            args=args+ l1lllllll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        l1lllllll=None
        l11lllll = args[0][0]
        if re.search(l1l111 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11lllll):
            l1lllllll = (l1l111 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l11111l1
                            ,)
        return l1lllllll
class l1lllll1l(Exception):
    def __init__(self, *args, **kwargs):
        l1lllllll = self.l1lllll11(args)
        if l1lllllll:
            args = args + l1lllllll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        s = l1l111 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l111 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l11111ll(Exception):
    pass
class l1lllll(Exception):
    pass
class l1lll11ll(Exception):
    def __init__(self, message, l1111l11, url):
        super(l1lll11ll,self).__init__(message)
        self.l1111l11 = l1111l11
        self.url = url
class l111111l(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1111l1l(Exception):
    pass