#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111l1 = 2048
l1l11l = 7
def l1ll1ll (l11111l):
    global l1ll1
    l1ll1111 = ord (l11111l [-1])
    l11ll1l = l11111l [:-1]
    l11llll = l1ll1111 % len (l11ll1l)
    l1lll111 = l11ll1l [:l11llll] + l11ll1l [l11llll:]
    if l1lll1:
        l1ll11l = l11111 () .join ([unichr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    else:
        l1ll11l = str () .join ([chr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    return eval (l1ll11l)
import gi
gi.require_version(l1ll1ll (u"ࠨࡉࡷ࡯ࠬঽ"), l1ll1ll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l11111
import logging
logger = logging.getLogger(l1ll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1111ll(Gtk.Window):
    def __init__(self, l1ll11lll1, l1ll1l1l11):
        Gtk.Window.__init__(self)
        self.l1llll1l=30
        self.l1ll11l111 = False
        self.service = l1ll11lll1
        self.l1l1lll=l1ll1l1l11
        self.l1llll=l1l11111.l1l1lll1
        self.l1ll1111ll = Gtk.ListStore(str)
        self.l1l11ll1ll()
    def l1l1ll1l11(self, service):
        l1l1l111ll = self.l1llll.l11ll1l1(l1ll1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1l111ll
    def l1l11ll1ll(self, l1ll11lll1=None):
        if l1ll11lll1:
            self.l1ll1111ll.clear()
            l1l1lllll1=self.l1l1ll1l11(l1ll11lll1)
            self.l1ll1111ll.append([l1ll1ll (u"ࠧࠨু")])
            for l1l1lll in l1l1lllll1:
                self.l1ll1111ll.append([l1l1lll])
        else:
            self.l1ll1111ll.clear()
            self.l1ll1111ll.append([l1ll1ll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll1lllll(self, widget, data=None):
        l1l1l11ll1= widget.get_active()
        if data == l1ll1ll (u"ࠢ࠲ࠤৃ") and l1l1l11ll1:
            self.l1l11ll1ll()
            self.l1ll1111l1.set_active(0)
            self.l1l1lll1ll.set_text(l1ll1ll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1lll1ll.set_sensitive(False)
            self.l1ll1111l1.set_sensitive(False)
        else:
            self.l1l11ll1ll(l1ll11lll1=self.service)
            self.l1ll1111l1.set_active(0)
            self.l1l1lll1ll.set_text(l1ll1ll (u"ࠤࠥ৅"))
            self.l1ll1111l1.set_sensitive(True)
            self.l1l1lll1ll.set_sensitive(True)
    def l1l11l1lll(self, widget):
        if widget.get_active():
            l1l1lll = widget.get_child().get_text()
        else:
            l1l1lll = self.l1ll1111ll[widget.get_active()][0]
        password = self.l1ll1l11ll(self.service, l1l1lll)
        if password:
            self.l1l1lll1ll.set_text(password)
        else:
            self.l1l1lll1ll.set_text(l1ll1ll (u"ࠥࠦ৆"))
    def l1l11lll1l(self, l1l1lll, pwd, service):
        keyring.set_password(service, l1l1lll, pwd)
        l1l1l111ll=self.l1llll.l11ll1l1(l1ll1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1l1lll in l1l1l111ll:
            value = self.l1llll.get_value(l1ll1ll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1llll.l11lll1l(l1ll1ll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1ll1ll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1l1lll))
    def l1ll1l11ll(self, service, l1l1lll):
        l1l1l1l11l = keyring.get_password(service, l1l1lll)
        return l1l1l1l11l
    def l1ll1lll11(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll11111l(self, widget, data=None):
        self.l1ll11l111=widget.get_active()
    def l1llllll(self, message, title=l1ll1ll (u"ࠨࠩো"), l11ll111l=True):
        if l11ll111l:
            l1l11lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1ll11l1 = Gtk.MessageDialog(self,
            l1l11lllll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1ll11l1.set_title(title)
        l1l1ll11l1.set_default_response(Gtk.ResponseType.OK)
        l1ll1l1111 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l1llll = Gtk.VBox()
        l1ll111lll = Gtk.Box(spacing=1)
        l1ll111lll.set_homogeneous(False)
        l1l1l111l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l111l1.set_homogeneous(False)
        l1l1l11lll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l11lll.set_homogeneous(False)
        l1ll111lll.pack_start(l1l1l111l1, True, True, 0)
        l1ll111lll.pack_start(l1l1l11lll, True, True, 0)
        l1l1l1l1ll = l1l1ll11l1.get_content_area()
        l1ll1ll111 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l1ll.pack_start(l1ll1ll111, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l11lll11 = Gtk.Label()
        l1l1ll111l = Gtk.Label()
        l1l1ll111l.set_text(l1ll1ll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1ll111l, True, True, 0)
        l1l11lll11.set_text(l1ll1ll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l11lll11.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l11lll11, 0, 1, 0, 1)
        l1ll11l1ll = Gtk.RadioButton.new_with_label_from_widget(None, l1ll1ll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll11l1ll.connect(l1ll1ll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll1lllll, l1ll1ll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll11l1ll, 1, 2, 0, 1)
        l1l1llll11 = Gtk.RadioButton.new_with_label_from_widget(l1ll11l1ll, l1ll1ll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1llll11.connect(l1ll1ll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll1lllll, l1ll1ll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1llll11, 1, 2, 1, 2)
        l1l1l1l1l1 = Gtk.Label()
        l1l1l1l1l1.set_text(l1ll1ll (u"ࠥࠤࠧ৔"))
        table.attach(l1l1l1l1l1, 0, 1, 4, 6)
        l1l1ll1111 = Gtk.Label()
        l1l1ll1111.set_text(l1ll1ll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1ll1111.set_justify(Gtk.Justification.RIGHT)
        l1l1ll1111.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1111l1 = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1111ll)
        self.l1ll1111l1.set_entry_text_column(0)
        table.attach(l1l1ll1111, 0, 1, 6, 8)
        table.attach(self.l1ll1111l1, 1, 3, 6, 8)
        self.l1ll1111l1.connect(l1ll1ll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l11l1lll)
        l1l1l11l1l = Gtk.Label()
        l1l1l11l1l.set_text(l1ll1ll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l1l11l1l.set_justify(Gtk.Justification.RIGHT)
        l1l1l11l1l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1lll1ll = Gtk.Entry()
        self.l1l1lll1ll.set_visibility(False)
        self.l1l1lll1ll.connect(l1ll1ll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1ll1lll11, l1l1ll11l1)
        table.attach(l1l1l11l1l, 0, 1, 8, 10)
        table.attach(self.l1l1lll1ll, 1, 3, 8, 10)
        l1ll111ll1 = Gtk.CheckButton(l1ll1ll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll111ll1.connect(l1ll1ll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll11111l, l1ll111ll1)
        l1ll111ll1.set_active(False)
        table.attach(l1ll111ll1, 1, 3, 12, 14)
        l1ll1ll11l = Gtk.Label()
        l1ll1ll11l.set_text(l1ll1ll (u"ࠥࠤࠧ৛") * 5)
        l1l1l1llll.pack_start(l1ll1ll11l, True, True, 0)
        if self.l1l1lll:
            l1l1llll11.set_active(True)
            self.l1ll1111l1.set_active(0)
            self.l1ll1111l1.set_sensitive(True)
            self.l1l1lll1ll.set_text(l1ll1ll (u"ࠦࠧড়"))
            self.l1l1lll1ll.set_sensitive(True)
        else:
            self.l1ll1111l1.set_active(0)
            self.l1ll1111l1.set_sensitive(False)
            self.l1l1lll1ll.set_text(l1ll1ll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1lll1ll.set_sensitive(False)
        l1ll1l1111.pack_start(vbox, True, True, 0)
        l1ll1l1111.pack_start(table, True, True, 0)
        l1ll1l1111.pack_end(l1l1l1llll, True, True, 0)
        l1ll1ll111.pack_start(l1ll1l1111, True, True, 0)
        l1l1ll11l1.show_all()
        response = l1l1ll11l1.run()
        if self.l1ll1111l1.get_active():
            l1l1lll = self.l1ll1111l1.get_child().get_text()
        else:
            l1l1lll = self.l1ll1111ll[self.l1ll1111l1.get_active()][0]
        pwd = self.l1l1lll1ll.get_text()
        l1l1ll11l1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll11l111:
                self.l1l11lll1l(l1l1lll, pwd, self.service)
            return l1l1lll, pwd
        else:
            return l1ll1ll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1ll1ll (u"ࠧࠨয়")
class l111l1l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l11ll1l1(self, l1l1llll):
        l1l1ll1ll1 = Gtk.ScrolledWindow()
        l1l1ll1ll1.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11l11l=None
        self.l1ll111l1l = Gtk.TextBuffer()
        self.l1ll111l1l.set_text(l1l1llll)
        self.set_style()
        regexp= l1ll1ll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l11l1l11 = self._1ll1l1ll1(l1l1llll, regexp)
        self.l1ll11ll1l(l1l11l1l11, self.l1ll111l1l.get_start_iter())
        self.l1l11ll11l = Gtk.TextView(buffer=self.l1ll111l1l)
        self.l1l11ll11l.set_property(l1ll1ll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l11ll11l.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11ll11l.connect(l1ll1ll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll11llll)
        self.l1l11ll11l.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1ll1ll1.set_size_request(300,100)
        self.l1l11ll11l.show()
        l1l1ll1ll1.add(self.l1l11ll11l)
        l1l1ll1ll1.show()
        return l1l1ll1ll1
    def _1ll11llll(self, *args, **kwargs):
        l1l1l11111, l1ll1ll1l1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l11111, l1ll1ll1l1).get_tags()
        if not self.l1ll11l11l:
            self.l1ll11l11l = args[1].window.get_cursor()
            self.l1l1l1lll1 = Gdk.Cursor(Gdk.CursorType.l1ll1l111l)
        elif tag:
            args[1].window.set_cursor(self.l1l1l1lll1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11l11l:
                args[1].window.set_cursor(self.l1ll11l11l)
    def _1ll1l1ll1(self, l1l1llll, l1l11ll111):
        res=[]
        l1ll1l1l1l=re.findall(l1l11ll111,l1l1llll)
        for l1ll1l11l1 in l1ll1l1l1l:
            for el in l1ll1l11l1:
                if el:
                    res.append(el)
        return res
    def l1ll11ll1l(self, l1l11l1l11, start):
        l1ll1llll1=0
        for text in l1l11l1l11:
            end = self.l1ll111l1l.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1llll1+=1
                l1ll11l1l1, l1l1lll1l1 = match
                tag = self.l1ll111l1l.create_tag(str(l1ll1llll1), foreground=l1ll1ll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1ll1ll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll111111, text)
                self.l1ll111l1l.apply_tag(tag, l1ll11l1l1, l1l1lll1l1)
                self.l1ll11ll1l(l1l11l1l11, l1l1lll1l1)
    def _1ll111111(self, tag, widget, l1l1ll1l1l, _1l1lll11l, text):
        _1l1l11l11 = l1l1ll1l1l.type
        _1l11l1ll1 = l1l1ll1l1l.window
        if _1l1l11l11 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l11l11 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1ll1l1l.button
            self.l1ll11l11l = Gdk.Cursor(Gdk.CursorType.l1ll1l111l)
            if _1l1l11l11 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1ll1ll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1ll1llll(self, message, title=l1ll1ll (u"ࠧࠨ০"), l11ll111l=True, l1l1lll111=None):
        if l11ll111l:
            l1l11lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l11lllll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1lll111:
            l1l1l1l1ll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll111lll = Gtk.HBox(spacing=0)
            l1l1ll11ll = Gtk.HBox(spacing=5)
            l1ll1ll1ll = Gtk.Label()
            l1ll1ll1ll.set_markup(l1ll1ll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll1ll1ll.set_line_wrap(True)
            l1ll1ll1ll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1ll1ll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll11ll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11ll11.show()
            l1l1l1l111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l111.show()
            l1l1l1ll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1ll1l.show()
            l1ll111lll.pack_start(separator, True, True, 0)
            l1ll111lll.pack_start(l1ll11ll11, True, True, 0)
            l1ll111lll.pack_start(l1l1l1l111, True, True, 0)
            l1ll111lll.pack_start(l1l1l1ll1l, True, True, 0)
            l1ll111lll.pack_start(l1ll1ll1ll, False, True, 0)
            l1l1ll1lll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1lll.show()
            l1ll111lll.pack_end(l1l1ll1lll, True, True, 0)
            l1l11l11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11l11ll.show()
            vbox.pack_start(l1ll111lll, True, True, 0)
            l1l1ll1ll1=self.__1l11ll1l1(l1l1llll=l1l1lll111)
            vbox.pack_start(l1l1ll1ll1, False, False, 0)
            vbox.pack_end(l1l11l11ll, False, False, 0)
            l1l1ll11ll.pack_start(vbox, True, True,5)
            l1l1ll11ll.show()
            l1l1l1l1ll.pack_end(l1l1ll11ll, False, False, 0)
            vbox.show()
            l1ll111lll.show()
        window.run()
class l1lll111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111l11(self, widget, l1l1l1111l):
        if l1l1l1111l == Gtk.ResponseType.OK:
            self.result = l1ll1ll (u"ࠥࡓࡐࠨ৩")
        elif l1l1l1111l == Gtk.ResponseType.CANCEL:
            self.result = l1ll1ll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1l1111l == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1ll1ll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1ll11ll1(self, title=l1ll1ll (u"ࠨࠢ৬"), message=l1ll1ll (u"ࠢࠣ৭") , l11ll111l=True):
        if l11ll111l:
            l1l11lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11lllll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1ll1ll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll111l11)
        window.run()
class l1l11llll1(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1l1lll=None
        self.result = None
    def l1ll111l11(self, widget, l1l1l1111l):
        print(widget, l1l1l1111l)
        if l1l1l1111l == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l1111l == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l1111l == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll11111l(self, widget, l1l1llll1l):
        if l1l1llll1l.get_active():
            self.l1ll1l1lll = 1
        else:
            self.l1ll1l1lll = 0
    def l1l1l1ll11(self, title=l1ll1ll (u"ࠤࠥ৯"), message=l1ll1ll (u"ࠥࠦৰ"), l1ll1lll1l =l1ll1ll (u"ࠦࠧৱ"),l11ll111l=True):
        if l11ll111l:
            l1l11lllll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11lllll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1ll1ll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll111l11)
        l1ll111ll1 = Gtk.CheckButton(l1ll1lll1l)
        l1ll111ll1.connect(l1ll1ll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll11111l, l1ll111ll1)
        l1ll111ll1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll111ll1, expand=True, fill=True, padding=0)
        l1ll111ll1.show()
        window.run()
def l1l1llll1(title, msg, l1ll1lll1l=l1ll1ll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11ll111l=True):
    result=None
    try:
        l1l1llllll = l1l11llll1()
        l1l1llllll.l1l1l1ll11(title, msg, l1ll1lll1l, l11ll111l)
        result = {l1ll1ll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1llllll.result,  l1ll1ll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1llllll.l1ll1l1lll}
    except Exception as e:
        logger.exception(l1ll1ll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1ll1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11111l1l = l111l1l11()
    message= l1ll1ll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l11l1l1l = l1ll1ll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11111l1l.l1ll1llll(message, l1ll1ll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11ll111l=True, l1l1lll111=l1l11l1l1l)