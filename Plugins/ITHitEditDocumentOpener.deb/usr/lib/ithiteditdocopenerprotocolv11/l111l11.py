#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l11lll1 = 2048
l1ll111l = 7
def l111111 (l1111ll):
    global l1lll111
    l1lllll1 = ord (l1111ll [-1])
    l1lll1ll = l1111ll [:-1]
    l1111l1 = l1lllll1 % len (l1lll1ll)
    l1l11ll = l1lll1ll [:l1111l1] + l1lll1ll [l1111l1:]
    if l1ll1lll:
        l1l1l1l = l1l111 () .join ([unichr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    else:
        l1l1l1l = str () .join ([chr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    return eval (l1l1l1l)
import logging
import os
import re
from l11llll import l1llll111
logger = logging.getLogger(l111111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1ll1ll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111111 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111ll1():
    try:
        out = os.popen(l111111 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l111111 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l111111 (u"ࠤࠥॸ").join(result)
                logger.info(l111111 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l111111 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l111111 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l111111 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll111(l111111 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l111111 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1ll1ll1(l111111 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))