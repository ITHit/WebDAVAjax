#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l11ll1 = 2048
l1l1l1l = 7
def l1ll1111 (l111ll):
    global l1lll
    l1l11 = ord (l111ll [-1])
    l11l111 = l111ll [:-1]
    l1l1111 = l1l11 % len (l11l111)
    l1lllll = l11l111 [:l1l1111] + l11l111 [l1l1111:]
    if l1l1l1:
        l11l11 = l1ll1ll () .join ([unichr (ord (char) - l11ll1 - (l1111l + l1l11) % l1l1l1l) for l1111l, char in enumerate (l1lllll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll1 - (l1111l + l1l11) % l1l1l1l) for l1111l, char in enumerate (l1lllll)])
    return eval (l11l11)
import hashlib
import os
import l11l1
from l1ll1l11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11l1 import l11ll11
from l1ll1l1l import l1l1, l1lll1
import logging
logger = logging.getLogger(l1ll1111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l111l():
    def __init__(self, l1111ll,l1l11l1, l1l1lll= None, l1ll11l1=None):
        self.l1lllll1=False
        self.l11l = self._1l()
        self.l1l11l1 = l1l11l1
        self.l1l1lll = l1l1lll
        self.l11lll = l1111ll
        if l1l1lll:
            self.l11lll1 = True
        else:
            self.l11lll1 = False
        self.l1ll11l1 = l1ll11l1
    def _1l(self):
        try:
            return l11l1.l1ll1l1() is not None
        except:
            return False
    def open(self):
        l1ll1111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l:
            raise NotImplementedError(l1ll1111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1ll1 = self.l11lll
        if self.l1l11l1.lower().startswith(self.l11lll.lower()):
            l1ll11ll = re.compile(re.escape(self.l11lll), re.IGNORECASE)
            l1l11l1 = l1ll11ll.sub(l1ll1111 (u"ࠨࠩࠄ"), self.l1l11l1)
            l1l11l1 = l1l11l1.replace(l1ll1111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.ll(self.l11lll, l1l1ll1, l1l11l1, self.l1l1lll)
    def ll(self,l11lll, l1l1ll1, l1l11l1, l1l1lll):
        l1ll1111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11 = l1ll11(l11lll)
        l1llllll = self.l11ll1l(l11)
        logger.info(l1ll1111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11)
        if l1llllll:
            logger.info(l1ll1111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11ll11(l11)
            l11 = l11ll(l11lll, l1l1ll1, l1l1lll, self.l1ll11l1)
        logger.debug(l1ll1111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1111l1=l11 + l1ll1111 (u"ࠤ࠲ࠦࠌ") + l1l11l1
        l1111 = l1ll1111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1111l1+ l1ll1111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1111)
        l111ll1 = os.system(l1111)
        if (l111ll1 != 0):
            raise IOError(l1ll1111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1111l1, l111ll1))
    def l11ll1l(self, l11):
        if os.path.exists(l11):
            if os.path.islink(l11):
                l11 = os.readlink(l11)
            if os.path.ismount(l11):
                return True
        return False
def l1ll11(l11lll):
    l1lll1ll = l11lll.replace(l1ll1111 (u"࠭࡜࡝ࠩࠐ"), l1ll1111 (u"ࠧࡠࠩࠑ")).replace(l1ll1111 (u"ࠨ࠱ࠪࠒ"), l1ll1111 (u"ࠩࡢࠫࠓ"))
    l1ll11l = l1ll1111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1llll1=os.environ[l1ll1111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llll11=os.path.join(l1llll1,l1ll11l, l1lll1ll)
    l1lll111=os.path.abspath(l1llll11)
    return l1lll111
def l1lll1l(l1l111):
    if not os.path.exists(l1l111):
        os.makedirs(l1l111)
def l111111(l11lll, l1l1ll1, l111l1=None, password=None):
    l1ll1111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l111 = l1ll11(l11lll)
    l1lll1l(l1l111)
    if not l111l1:
        l1lll1l1 = l11111l()
        l11l11l =l1lll1l1.l1ll111l(l1ll1111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1ll1 + l1ll1111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1ll1 + l1ll1111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l11l, str):
            l111l1, password = l11l11l
        else:
            raise l1lll1()
        logger.info(l1ll1111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l111))
    l11l1ll = pwd.getpwuid( os.getuid())[0]
    l1l1ll=os.environ[l1ll1111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll1l={l1ll1111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l1ll, l1ll1111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11lll, l1ll1111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l111, l1ll1111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1ll, l1ll1111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111l1, l1ll1111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll1l, temp_file)
        if not os.path.exists(os.path.join(l1llll, l1ll1111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11l1l=l1ll1111 (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1111 (u"ࠧࠨࠤ")
        else:
            l11l1l=l1ll1111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111l1l=l1ll1111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11l1l,temp_file.name)
        l111lll=[l1ll1111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll, l111l1l)]
        p = subprocess.Popen(l111lll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l111
    logger.debug(l1ll1111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll111=os.path.abspath(l1l111)
    logger.debug(l1ll1111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll111)
    return l1lll111
def l11ll(l11lll, l1l1ll1, l1l1lll, l1ll11l1):
    l1ll1111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll11l(title):
        l111=30
        if len(title)>l111:
            l1l1l=title.split(l1ll1111 (u"ࠨ࠯ࠣ࠳"))
            l1l1l11=l1ll1111 (u"ࠧࠨ࠴")
            for block in l1l1l:
                l1l1l11+=block+l1ll1111 (u"ࠣ࠱ࠥ࠵")
                if len(l1l1l11) > l111:
                    l1l1l11+=l1ll1111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l1l11
        return title
    def l11l1l1(l111l, password):
        l1ll1111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1111 (u"ࠧࠦࠢ࠹").join(l111l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l11ll = l1ll1111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l11ll.encode())
        l1 = [l1ll1111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11llll = l1ll1111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11llll)
            for e in l1:
                if e in l11llll: return False
            raise l1l1(l11llll, l11ll=l11l1.l1ll1l1(), l1l1ll1=l1l1ll1)
        logger.info(l1ll1111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l111l1 = l1ll1111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1111 (u"ࠦࠧ࠿")
    os.system(l1ll1111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1llll1l = l1ll11(l11lll)
    l1l111 = l1ll11(hashlib.sha1(l11lll.encode()).hexdigest()[:10])
    l1lll1l(l1l111)
    logger.info(l1ll1111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l111))
    if l1l1lll:
        l111l = [l1ll1111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1111 (u"ࠤ࠰ࡸࠧࡄ"), l1ll1111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1111 (u"ࠫ࠲ࡵࠧࡆ"), l1ll1111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l111l1, l1l1lll),
                    urllib.parse.unquote(l1l1ll1), os.path.abspath(l1l111)]
        l11l1l1(l111l, password)
    else:
        while True:
            l111l1, password = l1ll1(l1l111, l1l1ll1, l1ll11l1)
            if l111l1.lower() != l1ll1111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l111l = [l1ll1111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1111 (u"ࠤ࠰ࡸࠧࡋ"), l1ll1111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1111 (u"ࠫ࠲ࡵࠧࡍ"), l1ll1111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l111l1,
                            urllib.parse.unquote(l1l1ll1), os.path.abspath(l1l111)]
            else:
                raise l1lll1()
            if l11l1l1(l111l, password): break
    os.system(l1ll1111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l111, l1llll1l))
    l1lll111=os.path.abspath(l1llll1l)
    return l1lll111
def l1ll1(l11lll, l1l1ll1, l1ll11l1):
    l1ll1ll1 = os.path.join(os.environ[l1ll1111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1ll1)):
       os.makedirs(os.path.dirname(l1ll1ll1))
    l1lll11 = l1ll11l1.get_value(l1ll1111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1lll1l1 = l11111l(l11lll, l1lll11)
    l111l1, password = l1lll1l1.l1ll111l(l1ll1111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1ll1 + l1ll1111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1ll1 + l1ll1111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l111l1 != l1ll1111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11111(l11lll, l111l1):
        l1ll1lll = l1ll1111 (u"ࠤ࡙ࠣࠦ").join([l11lll, l111l1, l1ll1111 (u"࡚ࠪࠦࠬ") + password + l1ll1111 (u"࡛ࠫࠧ࠭"), l1ll1111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1ll1, l1ll1111 (u"࠭ࡷࠬࠩ࡝")) as l1ll:
            l1ll.write(l1ll1lll)
        os.chmod(l1ll1ll1, 0o600)
    return l111l1, password
def l11111(l11lll, l111l1):
    l1ll1ll1 = l1l11l = os.path.join(os.environ[l1ll1111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1ll1):
        with open(l1ll1ll1, l1ll1111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll111 = data[0].split(l1ll1111 (u"ࠦࠥࠨࡢ"))
            if l11lll == l1ll111[0] and l111l1 == l1ll111[1]:
                return True
    return False