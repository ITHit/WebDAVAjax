#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1l1l1l = 2048
l111l = 7
def l1111 (l1ll1l11):
    global l11l111
    l1lll11l = ord (l1ll1l11 [-1])
    l1l11ll = l1ll1l11 [:-1]
    l111lll = l1lll11l % len (l1l11ll)
    l1l111l = l1l11ll [:l111lll] + l1l11ll [l111lll:]
    if l11ll1:
        l11l1ll = l1l111 () .join ([unichr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    return eval (l11l1ll)
import hashlib
import os
import l1lll11
from l11l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll11 import l1llll1
from l1ll1ll1 import l1lll1l1, l1ll1
import logging
logger = logging.getLogger(l1111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll1lll():
    def __init__(self, l1lllll1,l111111, l1= None, l1ll111l=None):
        self.l111ll1=False
        self.l1l1ll1 = self._11l1l()
        self.l111111 = l111111
        self.l1 = l1
        self.l111l1 = l1lllll1
        if l1:
            self.l1ll11l1 = True
        else:
            self.l1ll11l1 = False
        self.l1ll111l = l1ll111l
    def _11l1l(self):
        try:
            return l1lll11.l11ll11() is not None
        except:
            return False
    def open(self):
        l1111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1ll1:
            raise NotImplementedError(l1111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1l11 = self.l111l1
        if self.l111111.lower().startswith(self.l111l1.lower()):
            l1ll1111 = re.compile(re.escape(self.l111l1), re.IGNORECASE)
            l111111 = l1ll1111.sub(l1111 (u"ࠨࠩࠄ"), self.l111111)
            l111111 = l111111.replace(l1111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1ll(self.l111l1, l1l1l11, l111111, self.l1)
    def l1l1ll(self,l111l1, l1l1l11, l111111, l1):
        l1111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll111 = l1l11(l111l1)
        l1lllll = self.l1llll11(l1lll111)
        logger.info(l1111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll111)
        if l1lllll:
            logger.info(l1111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1llll1(l1lll111)
            l1lll111 = l1lll(l111l1, l1l1l11, l1, self.l1ll111l)
        logger.debug(l1111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l11l=l1lll111 + l1111 (u"ࠤ࠲ࠦࠌ") + l111111
        l111ll = l1111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l11l+ l1111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111ll)
        l1l11l1 = os.system(l111ll)
        if (l1l11l1 != 0):
            raise IOError(l1111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l11l, l1l11l1))
    def l1llll11(self, l1lll111):
        if os.path.exists(l1lll111):
            if os.path.islink(l1lll111):
                l1lll111 = os.readlink(l1lll111)
            if os.path.ismount(l1lll111):
                return True
        return False
def l1l11(l111l1):
    l1lll1 = l111l1.replace(l1111 (u"࠭࡜࡝ࠩࠐ"), l1111 (u"ࠧࡠࠩࠑ")).replace(l1111 (u"ࠨ࠱ࠪࠒ"), l1111 (u"ࠩࡢࠫࠓ"))
    l1ll1l1l = l1111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll11=os.environ[l1111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11llll=os.path.join(l1ll11,l1ll1l1l, l1lll1)
    l11lll1=os.path.abspath(l11llll)
    return l11lll1
def l1l1l(l1l1):
    if not os.path.exists(l1l1):
        os.makedirs(l1l1)
def l111l1l(l111l1, l1l1l11, l11ll=None, password=None):
    l1111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l1 = l1l11(l111l1)
    l1l1l(l1l1)
    if not l11ll:
        l1l1l1 = l11l1l1()
        l1llllll =l1l1l1.l1111l1(l1111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1l11 + l1111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1l11 + l1111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llllll, str):
            l11ll, password = l1llllll
        else:
            raise l1ll1()
        logger.info(l1111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l1))
    l1ll = pwd.getpwuid( os.getuid())[0]
    l1ll11l=os.environ[l1111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11ll1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll1l1={l1111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll, l1111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111l1, l1111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l1, l1111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11l, l1111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11ll, l1111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll1l1, temp_file)
        if not os.path.exists(os.path.join(l11ll1l, l1111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1111l=l1111 (u"ࠦࡵࡿࠢࠣ")
            key=l1111 (u"ࠧࠨࠤ")
        else:
            l1111l=l1111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1ll=l1111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1111l,temp_file.name)
        l1ll1l=[l1111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11ll1l, l1lll1ll)]
        p = subprocess.Popen(l1ll1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l1
    logger.debug(l1111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11lll1=os.path.abspath(l1l1)
    logger.debug(l1111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11lll1)
    return l11lll1
def l1lll(l111l1, l1l1l11, l1, l1ll111l):
    l1111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll111(title):
        l111=30
        if len(title)>l111:
            l11lll=title.split(l1111 (u"ࠨ࠯ࠣ࠳"))
            l11l=l1111 (u"ࠧࠨ࠴")
            for block in l11lll:
                l11l+=block+l1111 (u"ࠣ࠱ࠥ࠵")
                if len(l11l) > l111:
                    l11l+=l1111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l
        return title
    def l11l11l(l1llll1l, password):
        l1111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1111 (u"ࠧࠦࠢ࠹").join(l1llll1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll11ll = l1111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll11ll.encode())
        l1lll1l = [l1111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11l11 = l1111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11l11)
            for e in l1lll1l:
                if e in l11l11: return False
            raise l1lll1l1(l11l11, l1lll=l1lll11.l11ll11(), l1l1l11=l1l1l11)
        logger.info(l1111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11ll = l1111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1111 (u"ࠦࠧ࠿")
    os.system(l1111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1111ll = l1l11(l111l1)
    l1l1 = l1l11(hashlib.sha1(l111l1.encode()).hexdigest()[:10])
    l1l1l(l1l1)
    logger.info(l1111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l1))
    if l1:
        l1llll1l = [l1111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1111 (u"ࠤ࠰ࡸࠧࡄ"), l1111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1111 (u"ࠫ࠲ࡵࠧࡆ"), l1111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11ll, l1),
                    urllib.parse.unquote(l1l1l11), os.path.abspath(l1l1)]
        l11l11l(l1llll1l, password)
    else:
        while True:
            l11ll, password = l11111(l1l1, l1l1l11, l1ll111l)
            if l11ll.lower() != l1111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1llll1l = [l1111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1111 (u"ࠤ࠰ࡸࠧࡋ"), l1111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1111 (u"ࠫ࠲ࡵࠧࡍ"), l1111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11ll,
                            urllib.parse.unquote(l1l1l11), os.path.abspath(l1l1)]
            else:
                raise l1ll1()
            if l11l11l(l1llll1l, password): break
    os.system(l1111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l1, l1111ll))
    l11lll1=os.path.abspath(l1111ll)
    return l11lll1
def l11111(l111l1, l1l1l11, l1ll111l):
    l1ll1ll = os.path.join(os.environ[l1111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1ll)):
       os.makedirs(os.path.dirname(l1ll1ll))
    l11111l = l1ll111l.get_value(l1111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l1l1 = l11l1l1(l111l1, l11111l)
    l11ll, password = l1l1l1.l1111l1(l1111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1l11 + l1111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1l11 + l1111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11ll != l1111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not ll(l111l1, l11ll):
        l11 = l1111 (u"ࠤ࡙ࠣࠦ").join([l111l1, l11ll, l1111 (u"࡚ࠪࠦࠬ") + password + l1111 (u"࡛ࠫࠧ࠭"), l1111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1ll, l1111 (u"࠭ࡷࠬࠩ࡝")) as l1llll:
            l1llll.write(l11)
        os.chmod(l1ll1ll, 0o600)
    return l11ll, password
def ll(l111l1, l11ll):
    l1ll1ll = l1l1lll = os.path.join(os.environ[l1111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1ll):
        with open(l1ll1ll, l1111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l1111 = data[0].split(l1111 (u"ࠦࠥࠨࡢ"))
            if l111l1 == l1l1111[0] and l11ll == l1l1111[1]:
                return True
    return False