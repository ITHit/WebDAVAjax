#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111 = sys.version_info [0] == 2
l111 = 2048
l1ll1l1l = 7
def l11l1ll (l1ll1l11):
    global ll
    l1ll111 = ord (l1ll1l11 [-1])
    l1llll1l = l1ll1l11 [:-1]
    l1lll = l1ll111 % len (l1llll1l)
    l1 = l1llll1l [:l1lll] + l1llll1l [l1lll:]
    if l11111:
        l1ll1lll = l11l11 () .join ([unichr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    else:
        l1ll1lll = str () .join ([chr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    return eval (l1ll1lll)
import logging
logger = logging.getLogger(l11l1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l111l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll1l(object):
    def __init__(self, l111l1ll=None):
        self.l11l1111 = 0x019db1ded53e8000
        self.l111l1ll = l111l1ll
    def run(self):
        if self.l111l1ll:
            l11l111l = self.l1111lll()
        else:
            logger.error(l11l1ll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111ll11(l11l1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l111l
    def l11l1ll1(self, host, path, secure, expires, name, value, l111llll=None, l111l111=None, session=None):
        __doc__ = l11l1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11l1ll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l11l1ll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11l1ll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111llll, l11l1ll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111l111, l11l1ll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111lll1(self, l111l11l):
        if l111l11l < self.l11l1111:
            raise ValueError(l11l1ll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111l11l, self.l11l1111))
        return divmod((l111l11l - self.l11l1111), 10000000)[0]
    def _11l11l1(self, l111l1l1):
        l11l1ll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111l1l1:
            l11l1l11 = l111l1l1 - self.l11l1111
            res = l11l1l11 / 1000000
        return res
    def _1111l1l(self, string, initial):
        res = l11l1ll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l1111lll(self):
        l11l111l = http.cookiejar.CookieJar()
        if self.l111l1ll:
            for l11l1l1l in self.l111l1ll:
                l11l111l.set_cookie(self.l11l11ll(l11l1l1l))
        return l11l111l
    def l11l11ll(self, l1111ll1):
        now = int(time.time())
        flags = l1111ll1[l11l1ll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111llll = ((flags & (1 << 2)) != 0)
        l111l111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11l1ll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l1111ll1:
            l111l11l = l1111ll1[l11l1ll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1111
            expires = self.l111lll1(l111l11l)
        else:
            expires = None
        domain = l1111ll1[l11l1ll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l1111ll1[l11l1ll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l1ll1(domain, path, secure, expires, l1111ll1[l11l1ll (u"ࠣࡍࡈ࡝ࠧࢬ")], l1111ll1[l11l1ll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111llll,
                               l111l111, session)
        return c