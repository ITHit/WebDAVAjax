#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l1lllll1 = 2048
l1lll1 = 7
def l1ll1ll (l11l1ll):
    global l11l1l
    l1llllll = ord (l11l1ll [-1])
    l111111 = l11l1ll [:-1]
    l1ll1ll1 = l1llllll % len (l111111)
    l1l1ll = l111111 [:l1ll1ll1] + l111111 [l1ll1ll1:]
    if l1lllll:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    return eval (l1111)
import logging
logger = logging.getLogger(l1ll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l1l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l1111ll1(object):
    def __init__(self, l1111l1l=None):
        self.l11l1l1l = 0x019db1ded53e8000
        self.l1111l1l = l1111l1l
    def run(self):
        if self.l1111l1l:
            l111l1l1 = self.l11l11ll()
        else:
            logger.error(l1ll1ll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l111(l1ll1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111l1l1
    def l11l11l1(self, host, path, secure, expires, name, value, l111lll1=None, l111llll=None, session=None):
        __doc__ = l1ll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll1ll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1ll1ll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll1ll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111lll1, l1ll1ll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111llll, l1ll1ll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l11l1l11(self, l11l1ll1):
        if l11l1ll1 < self.l11l1l1l:
            raise ValueError(l1ll1ll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1ll1, self.l11l1l1l))
        return divmod((l11l1ll1 - self.l11l1l1l), 10000000)[0]
    def _11l1111(self, l11l111l):
        l1ll1ll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l111l:
            l1111lll = l11l111l - self.l11l1l1l
            res = l1111lll / 1000000
        return res
    def _111ll11(self, string, initial):
        res = l1ll1ll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11ll(self):
        l111l1l1 = http.cookiejar.CookieJar()
        if self.l1111l1l:
            for l111l11l in self.l1111l1l:
                l111l1l1.set_cookie(self.l111ll1l(l111l11l))
        return l111l1l1
    def l111ll1l(self, l111l1ll):
        now = int(time.time())
        flags = l111l1ll[l1ll1ll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111lll1 = ((flags & (1 << 2)) != 0)
        l111llll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll1ll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111l1ll:
            l11l1ll1 = l111l1ll[l1ll1ll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1l1l
            expires = self.l11l1l11(l11l1ll1)
        else:
            expires = None
        domain = l111l1ll[l1ll1ll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111l1ll[l1ll1ll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l11l1(domain, path, secure, expires, l111l1ll[l1ll1ll (u"ࠣࡍࡈ࡝ࠧࢬ")], l111l1ll[l1ll1ll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111lll1,
                               l111llll, session)
        return c