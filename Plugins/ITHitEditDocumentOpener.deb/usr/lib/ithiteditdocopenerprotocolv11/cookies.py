#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l11lll1 = 2048
l1ll111l = 7
def l111111 (l1111ll):
    global l1lll111
    l1lllll1 = ord (l1111ll [-1])
    l1lll1ll = l1111ll [:-1]
    l1111l1 = l1lllll1 % len (l1lll1ll)
    l1l11ll = l1lll1ll [:l1111l1] + l1lll1ll [l1111l1:]
    if l1ll1lll:
        l1l1l1l = l1l111 () .join ([unichr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    else:
        l1l1l1l = str () .join ([chr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    return eval (l1l1l1l)
import logging
logger = logging.getLogger(l111111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11llll import *
try:
    import json
except ImportError:
    import simplejson as json
class l1111lll(object):
    def __init__(self, l11l1111=None):
        self.l1111l1l = 0x019db1ded53e8000
        self.l11l1111 = l11l1111
    def run(self):
        if self.l11l1111:
            l111llll = self.l111l11l()
        else:
            logger.error(l111111 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l11l1l11(l111111 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111llll
    def l11l11l1(self, host, path, secure, expires, name, value, l111lll1=None, l11l111l=None, session=None):
        __doc__ = l111111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l111111 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l111111 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l111111 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111lll1, l111111 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l111l, l111111 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l111(self, l11l11ll):
        if l11l11ll < self.l1111l1l:
            raise ValueError(l111111 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l11ll, self.l1111l1l))
        return divmod((l11l11ll - self.l1111l1l), 10000000)[0]
    def _1111ll1(self, l111ll1l):
        l111111 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111ll1l:
            l111ll11 = l111ll1l - self.l1111l1l
            res = l111ll11 / 1000000
        return res
    def _11l1l1l(self, string, initial):
        res = l111111 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l11l(self):
        l111llll = http.cookiejar.CookieJar()
        if self.l11l1111:
            for l11l1ll1 in self.l11l1111:
                l111llll.set_cookie(self.l111l1ll(l11l1ll1))
        return l111llll
    def l111l1ll(self, l111l1l1):
        now = int(time.time())
        flags = l111l1l1[l111111 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111lll1 = ((flags & (1 << 2)) != 0)
        l11l111l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l111111 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111l1l1:
            l11l11ll = l111l1l1[l111111 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l1111l1l
            expires = self.l111l111(l11l11ll)
        else:
            expires = None
        domain = l111l1l1[l111111 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111l1l1[l111111 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l11l1(domain, path, secure, expires, l111l1l1[l111111 (u"ࠣࡍࡈ࡝ࠧࢬ")], l111l1l1[l111111 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111lll1,
                               l11l111l, session)
        return c