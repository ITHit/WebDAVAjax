#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import logging
logger = logging.getLogger(l111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l111l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l11l(object):
    def __init__(self, l111ll1l=None):
        self.l1111lll = 0x019db1ded53e8000
        self.l111ll1l = l111ll1l
    def run(self):
        if self.l111ll1l:
            l11l111l = self.l11l1l11()
        else:
            logger.error(l111l (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l111(l111l (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l111l
    def l11l11ll(self, host, path, secure, expires, name, value, l111l1l1=None, l111l1ll=None, session=None):
        __doc__ = l111l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l111l (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l111l (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l111l (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111l1l1, l111l (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111l1ll, l111l (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111ll11(self, l1111l1l):
        if l1111l1l < self.l1111lll:
            raise ValueError(l111l (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l1111l1l, self.l1111lll))
        return divmod((l1111l1l - self.l1111lll), 10000000)[0]
    def _11l1l1l(self, l11l11l1):
        l111l (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l11l1:
            l11l1111 = l11l11l1 - self.l1111lll
            res = l11l1111 / 1000000
        return res
    def _111llll(self, string, initial):
        res = l111l (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l11(self):
        l11l111l = http.cookiejar.CookieJar()
        if self.l111ll1l:
            for l111lll1 in self.l111ll1l:
                l11l111l.set_cookie(self.l11l1ll1(l111lll1))
        return l11l111l
    def l11l1ll1(self, l1111ll1):
        now = int(time.time())
        flags = l1111ll1[l111l (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l1l1 = ((flags & (1 << 2)) != 0)
        l111l1ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l111l (u"ࠦࡍࡏࡘࡑࠤࢨ") in l1111ll1:
            l1111l1l = l1111ll1[l111l (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l1111lll
            expires = self.l111ll11(l1111l1l)
        else:
            expires = None
        domain = l1111ll1[l111l (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l1111ll1[l111l (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l11ll(domain, path, secure, expires, l1111ll1[l111l (u"ࠣࡍࡈ࡝ࠧࢬ")], l1111ll1[l111l (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111l1l1,
                               l111l1ll, session)
        return c