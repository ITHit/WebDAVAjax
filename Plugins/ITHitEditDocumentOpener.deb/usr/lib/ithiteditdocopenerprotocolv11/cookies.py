#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l11 = 2048
l11111 = 7
def l1l1l1 (l111):
    global l1l1
    l1llll1 = ord (l111 [-1])
    l1ll11l = l111 [:-1]
    l1lll111 = l1llll1 % len (l1ll11l)
    l1lll = l1ll11l [:l1lll111] + l1ll11l [l1lll111:]
    if l1lllll:
        l1l111 = l111lll () .join ([unichr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    return eval (l1l111)
import logging
logger = logging.getLogger(l1l1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1llll11 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111llll(object):
    def __init__(self, l111l1l1=None):
        self.l1111ll1 = 0x019db1ded53e8000
        self.l111l1l1 = l111l1l1
    def run(self):
        if self.l111l1l1:
            l111lll1 = self.l11l111l()
        else:
            logger.error(l1l1l1 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l11l(l1l1l1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111lll1
    def l111ll1l(self, host, path, secure, expires, name, value, l1111lll=None, l11l11ll=None, session=None):
        __doc__ = l1l1l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l1l1 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l1l1 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l1l1 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l1111lll, l1l1l1 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l11ll, l1l1l1 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l111(self, l111ll11):
        if l111ll11 < self.l1111ll1:
            raise ValueError(l1l1l1 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111ll11, self.l1111ll1))
        return divmod((l111ll11 - self.l1111ll1), 10000000)[0]
    def _11l1l11(self, l11l1ll1):
        l1l1l1 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l1ll1:
            l111l1ll = l11l1ll1 - self.l1111ll1
            res = l111l1ll / 1000000
        return res
    def _11l11l1(self, string, initial):
        res = l1l1l1 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l111l(self):
        l111lll1 = http.cookiejar.CookieJar()
        if self.l111l1l1:
            for l1111l1l in self.l111l1l1:
                l111lll1.set_cookie(self.l11l1l1l(l1111l1l))
        return l111lll1
    def l11l1l1l(self, l11l1111):
        now = int(time.time())
        flags = l11l1111[l1l1l1 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l1111lll = ((flags & (1 << 2)) != 0)
        l11l11ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l1l1 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1111:
            l111ll11 = l11l1111[l1l1l1 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l1111ll1
            expires = self.l111l111(l111ll11)
        else:
            expires = None
        domain = l11l1111[l1l1l1 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1111[l1l1l1 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111ll1l(domain, path, secure, expires, l11l1111[l1l1l1 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1111[l1l1l1 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l1111lll,
                               l11l11ll, session)
        return c