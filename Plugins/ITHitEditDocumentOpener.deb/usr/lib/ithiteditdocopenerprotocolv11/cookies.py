#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1lll = 7
def l111ll1 (l11l111):
    global l1lll11l
    l1111ll = ord (l11l111 [-1])
    l1lll1l1 = l11l111 [:-1]
    l1lll1l = l1111ll % len (l1lll1l1)
    l1llll = l1lll1l1 [:l1lll1l] + l1lll1l1 [l1lll1l:]
    if l1l1111:
        l11l1ll = l1lllll () .join ([unichr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    return eval (l11l1ll)
import logging
logger = logging.getLogger(l111ll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l1l11 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l1l1(object):
    def __init__(self, l11l11l1=None):
        self.l111ll11 = 0x019db1ded53e8000
        self.l11l11l1 = l11l11l1
    def run(self):
        if self.l11l11l1:
            l111l111 = self.l11l1l11()
        else:
            logger.error(l111ll1 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111lll(l111ll1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111l111
    def l1111l1l(self, host, path, secure, expires, name, value, l111l11l=None, l11l11ll=None, session=None):
        __doc__ = l111ll1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l111ll1 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l111ll1 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l111ll1 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111l11l, l111ll1 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l11ll, l111ll1 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111lll1(self, l11l1111):
        if l11l1111 < self.l111ll11:
            raise ValueError(l111ll1 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1111, self.l111ll11))
        return divmod((l11l1111 - self.l111ll11), 10000000)[0]
    def _111l1ll(self, l1111ll1):
        l111ll1 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l1111ll1:
            l111llll = l1111ll1 - self.l111ll11
            res = l111llll / 1000000
        return res
    def _11l111l(self, string, initial):
        res = l111ll1 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l11(self):
        l111l111 = http.cookiejar.CookieJar()
        if self.l11l11l1:
            for l11l1ll1 in self.l11l11l1:
                l111l111.set_cookie(self.l111ll1l(l11l1ll1))
        return l111l111
    def l111ll1l(self, l11l1l1l):
        now = int(time.time())
        flags = l11l1l1l[l111ll1 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l11l = ((flags & (1 << 2)) != 0)
        l11l11ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l111ll1 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l1l:
            l11l1111 = l11l1l1l[l111ll1 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111ll11
            expires = self.l111lll1(l11l1111)
        else:
            expires = None
        domain = l11l1l1l[l111ll1 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l1l[l111ll1 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l1111l1l(domain, path, secure, expires, l11l1l1l[l111ll1 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l1l[l111ll1 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111l11l,
                               l11l11ll, session)
        return c