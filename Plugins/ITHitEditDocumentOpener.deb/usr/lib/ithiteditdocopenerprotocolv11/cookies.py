#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l111l = 2048
l11llll = 7
def l11 (l1ll11):
    global l111l
    l1lll1l = ord (l1ll11 [-1])
    l1ll1l = l1ll11 [:-1]
    l1ll1l1 = l1lll1l % len (l1ll1l)
    l1111 = l1ll1l [:l1ll1l1] + l1ll1l [l1ll1l1:]
    if l1l111:
        l1ll1 = l1l11ll () .join ([unichr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    else:
        l1ll1 = str () .join ([chr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    return eval (l1ll1)
import logging
logger = logging.getLogger(l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l111 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l11ll(object):
    def __init__(self, l111lll1=None):
        self.l111ll1l = 0x019db1ded53e8000
        self.l111lll1 = l111lll1
    def run(self):
        if self.l111lll1:
            l111l1l1 = self.l11l111l()
        else:
            logger.error(l11 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111lll(l11 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111l1l1
    def l111l111(self, host, path, secure, expires, name, value, l111l11l=None, l1111ll1=None, session=None):
        __doc__ = l11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l11 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111l11l, l11 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l1111ll1, l11 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l11l1ll1(self, l11l1l11):
        if l11l1l11 < self.l111ll1l:
            raise ValueError(l11 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1l11, self.l111ll1l))
        return divmod((l11l1l11 - self.l111ll1l), 10000000)[0]
    def _11l11l1(self, l111ll11):
        l11 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111ll11:
            l11l1111 = l111ll11 - self.l111ll1l
            res = l11l1111 / 1000000
        return res
    def _111l1ll(self, string, initial):
        res = l11 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l111l(self):
        l111l1l1 = http.cookiejar.CookieJar()
        if self.l111lll1:
            for l111llll in self.l111lll1:
                l111l1l1.set_cookie(self.l1111l1l(l111llll))
        return l111l1l1
    def l1111l1l(self, l11l1l1l):
        now = int(time.time())
        flags = l11l1l1l[l11 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l11l = ((flags & (1 << 2)) != 0)
        l1111ll1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l1l:
            l11l1l11 = l11l1l1l[l11 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111ll1l
            expires = self.l11l1ll1(l11l1l11)
        else:
            expires = None
        domain = l11l1l1l[l11 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l1l[l11 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l111(domain, path, secure, expires, l11l1l1l[l11 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l1l[l11 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111l11l,
                               l1111ll1, session)
        return c