#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l11ll = 2048
l1ll1l11 = 7
def l1l111 (l111l11):
    global l1l1l1
    l111ll1 = ord (l111l11 [-1])
    l111l1l = l111l11 [:-1]
    l1ll11l = l111ll1 % len (l111l1l)
    l1l1l1l = l111l1l [:l1ll11l] + l111l1l [l1ll11l:]
    if l1lll111:
        l1l1l11 = l1l11 () .join ([unichr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    else:
        l1l1l11 = str () .join ([chr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    return eval (l1l1l11)
import logging
logger = logging.getLogger(l1l111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11l1ll import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l11l(object):
    def __init__(self, l11l111l=None):
        self.l111l1ll = 0x019db1ded53e8000
        self.l11l111l = l11l111l
    def run(self):
        if self.l11l111l:
            l11l1ll1 = self.l11l11l1()
        else:
            logger.error(l1l111 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111ll1(l1l111 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l1ll1
    def l1111l1l(self, host, path, secure, expires, name, value, l11l1l11=None, l11l1111=None, session=None):
        __doc__ = l1l111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l111 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l111 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l111 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l1l11, l1l111 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l1111, l1l111 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111ll1l(self, l11l11ll):
        if l11l11ll < self.l111l1ll:
            raise ValueError(l1l111 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l11ll, self.l111l1ll))
        return divmod((l11l11ll - self.l111l1ll), 10000000)[0]
    def _1111lll(self, l111ll11):
        l1l111 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111ll11:
            l111lll1 = l111ll11 - self.l111l1ll
            res = l111lll1 / 1000000
        return res
    def _111llll(self, string, initial):
        res = l1l111 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11l1(self):
        l11l1ll1 = http.cookiejar.CookieJar()
        if self.l11l111l:
            for l111l111 in self.l11l111l:
                l11l1ll1.set_cookie(self.l11l1l1l(l111l111))
        return l11l1ll1
    def l11l1l1l(self, l111l1l1):
        now = int(time.time())
        flags = l111l1l1[l1l111 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1l11 = ((flags & (1 << 2)) != 0)
        l11l1111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l111 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111l1l1:
            l11l11ll = l111l1l1[l1l111 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111l1ll
            expires = self.l111ll1l(l11l11ll)
        else:
            expires = None
        domain = l111l1l1[l1l111 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111l1l1[l1l111 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l1111l1l(domain, path, secure, expires, l111l1l1[l1l111 (u"ࠣࡍࡈ࡝ࠧࢬ")], l111l1l1[l1l111 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l1l11,
                               l11l1111, session)
        return c