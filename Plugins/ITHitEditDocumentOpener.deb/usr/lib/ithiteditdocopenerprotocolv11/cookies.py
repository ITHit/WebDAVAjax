#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111ll = sys.version_info [0] == 2
l11l1l = 2048
l1llll11 = 7
def l11lll1 (l1ll11l1):
    global l1l1ll
    l1l1lll = ord (l1ll11l1 [-1])
    l1lll = l1ll11l1 [:-1]
    l1llll1 = l1l1lll % len (l1lll)
    l1l1l = l1lll [:l1llll1] + l1lll [l1llll1:]
    if l1111ll:
        l1lll111 = l11ll1l () .join ([unichr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    else:
        l1lll111 = str () .join ([chr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    return eval (l1lll111)
import logging
logger = logging.getLogger(l11lll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11ll1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l111l(object):
    def __init__(self, l111l111=None):
        self.l11l1ll1 = 0x019db1ded53e8000
        self.l111l111 = l111l111
    def run(self):
        if self.l111l111:
            l11l1l1l = self.l11l11l1()
        else:
            logger.error(l11lll1 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111lll(l11lll1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l1l1l
    def l111l1l1(self, host, path, secure, expires, name, value, l11l11ll=None, l11l1111=None, session=None):
        __doc__ = l11lll1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11lll1 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l11lll1 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11lll1 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l11ll, l11lll1 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l1111, l11lll1 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l11l(self, l111ll11):
        if l111ll11 < self.l11l1ll1:
            raise ValueError(l11lll1 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111ll11, self.l11l1ll1))
        return divmod((l111ll11 - self.l11l1ll1), 10000000)[0]
    def _111llll(self, l111ll1l):
        l11lll1 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111ll1l:
            l111l1ll = l111ll1l - self.l11l1ll1
            res = l111l1ll / 1000000
        return res
    def _111lll1(self, string, initial):
        res = l11lll1 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11l1(self):
        l11l1l1l = http.cookiejar.CookieJar()
        if self.l111l111:
            for l1111ll1 in self.l111l111:
                l11l1l1l.set_cookie(self.l1111l1l(l1111ll1))
        return l11l1l1l
    def l1111l1l(self, l11l1l11):
        now = int(time.time())
        flags = l11l1l11[l11lll1 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l11ll = ((flags & (1 << 2)) != 0)
        l11l1111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11lll1 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l11:
            l111ll11 = l11l1l11[l11lll1 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1ll1
            expires = self.l111l11l(l111ll11)
        else:
            expires = None
        domain = l11l1l11[l11lll1 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l11[l11lll1 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l1l1(domain, path, secure, expires, l11l1l11[l11lll1 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l11[l11lll1 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l11ll,
                               l11l1111, session)
        return c