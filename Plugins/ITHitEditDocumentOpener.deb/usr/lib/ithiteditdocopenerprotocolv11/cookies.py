#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import logging
logger = logging.getLogger(l1l1l1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1llll1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1ll1(object):
    def __init__(self, l111l1l1=None):
        self.l11l1l1l = 0x019db1ded53e8000
        self.l111l1l1 = l111l1l1
    def run(self):
        if self.l111l1l1:
            l1111l1l = self.l1111lll()
        else:
            logger.error(l1l1l1l (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l111(l1l1l1l (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l1111l1l
    def l111l11l(self, host, path, secure, expires, name, value, l11l11l1=None, l111llll=None, session=None):
        __doc__ = l1l1l1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l1l1l (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l1l1l (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l1l1l (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l11l1, l1l1l1l (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111llll, l1l1l1l (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111lll1(self, l111ll1l):
        if l111ll1l < self.l11l1l1l:
            raise ValueError(l1l1l1l (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111ll1l, self.l11l1l1l))
        return divmod((l111ll1l - self.l11l1l1l), 10000000)[0]
    def _11l11ll(self, l11l1111):
        l1l1l1l (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l1111:
            l11l111l = l11l1111 - self.l11l1l1l
            res = l11l111l / 1000000
        return res
    def _1111ll1(self, string, initial):
        res = l1l1l1l (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l1111lll(self):
        l1111l1l = http.cookiejar.CookieJar()
        if self.l111l1l1:
            for l111ll11 in self.l111l1l1:
                l1111l1l.set_cookie(self.l111l1ll(l111ll11))
        return l1111l1l
    def l111l1ll(self, l11l1l11):
        now = int(time.time())
        flags = l11l1l11[l1l1l1l (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l11l1 = ((flags & (1 << 2)) != 0)
        l111llll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l1l1l (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l11:
            l111ll1l = l11l1l11[l1l1l1l (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1l1l
            expires = self.l111lll1(l111ll1l)
        else:
            expires = None
        domain = l11l1l11[l1l1l1l (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l11[l1l1l1l (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l11l(domain, path, secure, expires, l11l1l11[l1l1l1l (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l11[l1l1l1l (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l11l1,
                               l111llll, session)
        return c