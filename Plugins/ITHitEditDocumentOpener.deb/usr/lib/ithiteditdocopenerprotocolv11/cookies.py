#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1111 = 7
def l1lll1ll (l1llll):
    global l1ll111l
    l1l1lll = ord (l1llll [-1])
    l11l1l = l1llll [:-1]
    l1ll1l1l = l1l1lll % len (l11l1l)
    l1l111l = l11l1l [:l1ll1l1l] + l11l1l [l1ll1l1l:]
    if l1ll1lll:
        l11ll11 = l1111 () .join ([unichr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    return eval (l11ll11)
import logging
logger = logging.getLogger(l1lll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11111l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll1l(object):
    def __init__(self, l1111lll=None):
        self.l111l1ll = 0x019db1ded53e8000
        self.l1111lll = l1111lll
    def run(self):
        if self.l1111lll:
            l11l111l = self.l11l1l1l()
        else:
            logger.error(l1lll1ll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l11l1111(l1lll1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l111l
    def l111lll1(self, host, path, secure, expires, name, value, l11l1ll1=None, l1111l1l=None, session=None):
        __doc__ = l1lll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lll1ll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1lll1ll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lll1ll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l1ll1, l1lll1ll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l1111l1l, l1lll1ll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l11l11l1(self, l11l1l11):
        if l11l1l11 < self.l111l1ll:
            raise ValueError(l1lll1ll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1l11, self.l111l1ll))
        return divmod((l11l1l11 - self.l111l1ll), 10000000)[0]
    def _11l11ll(self, l111l1l1):
        l1lll1ll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111l1l1:
            l111l111 = l111l1l1 - self.l111l1ll
            res = l111l111 / 1000000
        return res
    def _111l11l(self, string, initial):
        res = l1lll1ll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l1l(self):
        l11l111l = http.cookiejar.CookieJar()
        if self.l1111lll:
            for l111ll11 in self.l1111lll:
                l11l111l.set_cookie(self.l1111ll1(l111ll11))
        return l11l111l
    def l1111ll1(self, l111llll):
        now = int(time.time())
        flags = l111llll[l1lll1ll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1ll1 = ((flags & (1 << 2)) != 0)
        l1111l1l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lll1ll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111llll:
            l11l1l11 = l111llll[l1lll1ll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111l1ll
            expires = self.l11l11l1(l11l1l11)
        else:
            expires = None
        domain = l111llll[l1lll1ll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111llll[l1lll1ll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111lll1(domain, path, secure, expires, l111llll[l1lll1ll (u"ࠣࡍࡈ࡝ࠧࢬ")], l111llll[l1lll1ll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l1ll1,
                               l1111l1l, session)
        return c