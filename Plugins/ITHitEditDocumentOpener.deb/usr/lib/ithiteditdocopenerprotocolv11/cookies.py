#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l1 = sys.version_info [0] == 2
l111lll = 2048
l1l = 7
def l1ll1ll (l11l1ll):
    global l1lll11
    l1l1111 = ord (l11l1ll [-1])
    l1111l = l11l1ll [:-1]
    l1l1 = l1l1111 % len (l1111l)
    l1l1l1 = l1111l [:l1l1] + l1111l [l1l1:]
    if l1111l1:
        l11l1l1 = l11 () .join ([unichr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    else:
        l11l1l1 = str () .join ([chr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    return eval (l11l1l1)
import logging
logger = logging.getLogger(l1ll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1ll1ll1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll1l(object):
    def __init__(self, l111l111=None):
        self.l111l1ll = 0x019db1ded53e8000
        self.l111l111 = l111l111
    def run(self):
        if self.l111l111:
            l1111lll = self.l1111l1l()
        else:
            logger.error(l1ll1ll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111lll1(l1ll1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l1111lll
    def l11l1l1l(self, host, path, secure, expires, name, value, l11l1l11=None, l111llll=None, session=None):
        __doc__ = l1ll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll1ll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1ll1ll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll1ll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l1l11, l1ll1ll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111llll, l1ll1ll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l11l11ll(self, l111l1l1):
        if l111l1l1 < self.l111l1ll:
            raise ValueError(l1ll1ll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111l1l1, self.l111l1ll))
        return divmod((l111l1l1 - self.l111l1ll), 10000000)[0]
    def _11l1ll1(self, l1111ll1):
        l1ll1ll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l1111ll1:
            l11l111l = l1111ll1 - self.l111l1ll
            res = l11l111l / 1000000
        return res
    def _11l11l1(self, string, initial):
        res = l1ll1ll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l1111l1l(self):
        l1111lll = http.cookiejar.CookieJar()
        if self.l111l111:
            for l11l1111 in self.l111l111:
                l1111lll.set_cookie(self.l111l11l(l11l1111))
        return l1111lll
    def l111l11l(self, l111ll11):
        now = int(time.time())
        flags = l111ll11[l1ll1ll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1l11 = ((flags & (1 << 2)) != 0)
        l111llll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll1ll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111ll11:
            l111l1l1 = l111ll11[l1ll1ll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111l1ll
            expires = self.l11l11ll(l111l1l1)
        else:
            expires = None
        domain = l111ll11[l1ll1ll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111ll11[l1ll1ll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l1l1l(domain, path, secure, expires, l111ll11[l1ll1ll (u"ࠣࡍࡈ࡝ࠧࢬ")], l111ll11[l1ll1ll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l1l11,
                               l111llll, session)
        return c