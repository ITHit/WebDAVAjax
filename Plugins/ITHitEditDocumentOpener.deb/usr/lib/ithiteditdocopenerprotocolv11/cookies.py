#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import logging
logger = logging.getLogger(l1lll11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l1111 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l11l(object):
    def __init__(self, l111ll11=None):
        self.l111lll1 = 0x019db1ded53e8000
        self.l111ll11 = l111ll11
    def run(self):
        if self.l111ll11:
            l111l1l1 = self.l11l1l1l()
        else:
            logger.error(l1lll11 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111ll1l(l1lll11 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111l1l1
    def l11l11l1(self, host, path, secure, expires, name, value, l111l1ll=None, l11l11ll=None, session=None):
        __doc__ = l1lll11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lll11 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1lll11 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lll11 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111l1ll, l1lll11 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l11ll, l1lll11 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l111(self, l11l1ll1):
        if l11l1ll1 < self.l111lll1:
            raise ValueError(l1lll11 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1ll1, self.l111lll1))
        return divmod((l11l1ll1 - self.l111lll1), 10000000)[0]
    def _11l1l11(self, l1111lll):
        l1lll11 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l1111lll:
            l11l111l = l1111lll - self.l111lll1
            res = l11l111l / 1000000
        return res
    def _11l1111(self, string, initial):
        res = l1lll11 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l1l(self):
        l111l1l1 = http.cookiejar.CookieJar()
        if self.l111ll11:
            for l1111ll1 in self.l111ll11:
                l111l1l1.set_cookie(self.l111llll(l1111ll1))
        return l111l1l1
    def l111llll(self, l1111l1l):
        now = int(time.time())
        flags = l1111l1l[l1lll11 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l1ll = ((flags & (1 << 2)) != 0)
        l11l11ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lll11 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l1111l1l:
            l11l1ll1 = l1111l1l[l1lll11 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111lll1
            expires = self.l111l111(l11l1ll1)
        else:
            expires = None
        domain = l1111l1l[l1lll11 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l1111l1l[l1lll11 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l11l1(domain, path, secure, expires, l1111l1l[l1lll11 (u"ࠣࡍࡈ࡝ࠧࢬ")], l1111l1l[l1lll11 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111l1ll,
                               l11l11ll, session)
        return c