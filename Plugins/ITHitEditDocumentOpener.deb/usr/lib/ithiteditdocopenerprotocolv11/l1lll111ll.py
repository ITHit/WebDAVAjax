#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11lll=logging.WARNING
logger = logging.getLogger(l111l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11lll)
l1l11l11 = SysLogHandler(address=l111l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l111l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l11l11)
ch = logging.StreamHandler()
ch.setLevel(l1lll11lll)
logger.addHandler(ch)
class l1lll11111(io.FileIO):
    l111l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l111l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1llll, l1lll1lll1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1llll = l1lll1llll
            self.l1lll1lll1 = l1lll1lll1
            if not options:
                options = l111l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l111l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1llll,
                                              self.l1lll1lll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll1l = os.path.join(os.path.sep, l111l (u"ࠪࡩࡹࡩࠧই"), l111l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1111l = path
        else:
            self._1lll1111l = self.l1lll1ll1l
        super(l1lll11111, self).__init__(self._1lll1111l, l111l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1l111(self, line):
        return l1lll11111.Entry(*[x for x in line.strip(l111l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l111l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l111l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l111l (u"ࠤࠦࠦ঍")):
                    yield self._1lll1l111(line)
            except ValueError:
                pass
    def l1lll11l1l(self, attr, value):
        for entry in self.entries:
            l1llllll11 = getattr(entry, attr)
            if l1llllll11 == value:
                return entry
        return None
    def l1lllll11l(self, entry):
        if self.l1lll11l1l(l111l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l111l (u"ࠫࡡࡴࠧএ")).encode(l111l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1l11(self, entry):
        self.seek(0)
        lines = [l.decode(l111l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l111l (u"ࠢࠤࠤ঒")):
                if self._1lll1l111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l111l (u"ࠨࠩও").join(lines).encode(l111l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllllll1(cls, l1lll1llll, path=None):
        l1llll111l = cls(path=path)
        entry = l1llll111l.l1lll11l1l(l111l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1llll)
        if entry:
            return l1llll111l.l1llll1l11(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1llll, l1lll1lll1, options=None, path=None):
        return cls(path=path).l1lllll11l(l1lll11111.Entry(device,
                                                    l1lll1llll, l1lll1lll1,
                                                    options=options))
class l1lll111l1(object):
    def __init__(self, l1llll1111):
        self.l1lll1l1l1=l111l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1l1ll=l111l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll1111=l1llll1111
        self.l1lllll111()
        self.l1lll11l11()
        self.l1llll1lll()
        self.l1llll11l1()
        self.l1lll1l11l()
    def l1lllll111(self):
        temp_file=open(l1llll1l1l,l111l (u"࠭ࡲࠨঘ"))
        l1ll11=temp_file.read()
        data=json.loads(l1ll11)
        self.user=data[l111l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll1lll=data[l111l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll1ll=data[l111l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1111=data[l111l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11ll1=data[l111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllll1ll=data[l111l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1lll(self):
        l111l11=os.path.join(l111l (u"ࠨ࠯ࠣট"),l111l (u"ࠢࡶࡵࡵࠦঠ"),l111l (u"ࠣࡵࡥ࡭ࡳࠨড"),l111l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l111l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111l11)
    def l1lll1l11l(self):
        logger.info(l111l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll1ll=os.path.join(self.l1111,self.l1lll1l1l1)
        l1llll11ll = pwd.getpwnam(self.user).pw_uid
        l1lll1ll11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll1ll):
            os.makedirs(l1ll1ll)
            os.system(l111l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll1ll))
            logger.debug(l111l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll1ll)
        else:
            logger.debug(l111l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll1ll)
        l111l11=os.path.join(l1ll1ll, self.l1lll1l1ll)
        print(l111l11)
        logger.debug(l111l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111l11)
        with open(l111l11, l111l (u"ࠤࡺ࠯ࠧ঩")) as l1llll1ll1:
            logger.debug(self.l1ll1lll + l111l (u"ࠪࠤࠬপ")+self.l1lll11ll1+l111l (u"ࠫࠥࠨࠧফ")+self.l1lllll1ll+l111l (u"ࠬࠨࠧব"))
            l1llll1ll1.writelines(self.l1ll1lll + l111l (u"࠭ࠠࠨভ")+self.l1lll11ll1+l111l (u"ࠧࠡࠤࠪম")+self.l1lllll1ll+l111l (u"ࠨࠤࠪয"))
        os.chmod(l111l11, 0o600)
        os.chown(l111l11, l1llll11ll, l1lll1ll11)
    def l1lll11l11(self, l1lllll1l1=l111l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l111l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lllll1l1 in groups:
            logger.info(l111l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lllll1l1))
        else:
            logger.warning(l111l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lllll1l1))
            l1l11ll=l111l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lllll1l1,self.user)
            logger.debug(l111l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l11ll)
            os.system(l1l11ll)
            logger.debug(l111l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll11l1(self):
        logger.debug(l111l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll111l=l1lll11111()
        l1llll111l.add(self.l1ll1lll, self.l1ll1ll, l1lll1lll1=l111l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l111l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l111l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll1l1l = urllib.parse.unquote(sys.argv[1])
        if l1llll1l1l:
            l1llllll1l=l1lll111l1(l1llll1l1l)
        else:
            raise (l111l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l111l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise