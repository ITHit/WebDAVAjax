#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111111 = sys.version_info [0] == 2
l111 = 2048
l1ll11 = 7
def l1ll1l1 (l1111ll):
    global l1ll1l11
    l1l1ll = ord (l1111ll [-1])
    l1111 = l1111ll [:-1]
    l11l1 = l1l1ll % len (l1111)
    l111lll = l1111 [:l11l1] + l1111 [l11l1:]
    if l111111:
        l111l1 = l11lll () .join ([unichr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    return eval (l111l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1ll1=logging.WARNING
logger = logging.getLogger(l1ll1l1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll1ll1)
l1l11l11 = SysLogHandler(address=l1ll1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll1l1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l11l11)
ch = logging.StreamHandler()
ch.setLevel(l1llll1ll1)
logger.addHandler(ch)
class l1lll1lll1(io.FileIO):
    l1ll1l1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll1l1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll11ll, l1llll111l,
                     options, d=0, p=0):
            self.device = device
            self.l1llll11ll = l1llll11ll
            self.l1llll111l = l1llll111l
            if not options:
                options = l1ll1l1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll1l1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll11ll,
                                              self.l1llll111l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11l11 = os.path.join(os.path.sep, l1ll1l1 (u"ࠪࡩࡹࡩࠧই"), l1ll1l1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lllll1l1 = path
        else:
            self._1lllll1l1 = self.l1lll11l11
        super(l1lll1lll1, self).__init__(self._1lllll1l1, l1ll1l1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1111l(self, line):
        return l1lll1lll1.Entry(*[x for x in line.strip(l1ll1l1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll1l1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll1l1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll1l1 (u"ࠤࠦࠦ঍")):
                    yield self._1lll1111l(line)
            except ValueError:
                pass
    def l1lll11ll1(self, attr, value):
        for entry in self.entries:
            l1lll1llll = getattr(entry, attr)
            if l1lll1llll == value:
                return entry
        return None
    def l1llll1l1l(self, entry):
        if self.l1lll11ll1(l1ll1l1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll1l1 (u"ࠫࡡࡴࠧএ")).encode(l1ll1l1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllllll1(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll1l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll1l1 (u"ࠢࠤࠤ঒")):
                if self._1lll1111l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll1l1 (u"ࠨࠩও").join(lines).encode(l1ll1l1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l11l(cls, l1llll11ll, path=None):
        l1lll111l1 = cls(path=path)
        entry = l1lll111l1.l1lll11ll1(l1ll1l1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll11ll)
        if entry:
            return l1lll111l1.l1lllllll1(entry)
        return False
    @classmethod
    def add(cls, device, l1llll11ll, l1llll111l, options=None, path=None):
        return cls(path=path).l1llll1l1l(l1lll1lll1.Entry(device,
                                                    l1llll11ll, l1llll111l,
                                                    options=options))
class l1lll1l1l1(object):
    def __init__(self, l1llllll11):
        self.l1lll11l1l=l1ll1l1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll1l11=l1ll1l1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llllll11=l1llllll11
        self.l1lll1l111()
        self.l1lllll11l()
        self.l1lllll1ll()
        self.l1lll1l1ll()
        self.l1llll11l1()
    def l1lll1l111(self):
        temp_file=open(l1llll1111,l1ll1l1 (u"࠭ࡲࠨঘ"))
        l1ll1=temp_file.read()
        data=json.loads(l1ll1)
        self.user=data[l1ll1l1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1llll1l=data[l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l11ll=data[l1ll1l1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11ll11=data[l1ll1l1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11111=data[l1ll1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1lll=data[l1ll1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lllll1ll(self):
        l11l=os.path.join(l1ll1l1 (u"ࠨ࠯ࠣট"),l1ll1l1 (u"ࠢࡶࡵࡵࠦঠ"),l1ll1l1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll1l1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll1l1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11l)
    def l1llll11l1(self):
        logger.info(l1ll1l1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l11ll=os.path.join(self.l11ll11,self.l1lll11l1l)
        l1lll11lll = pwd.getpwnam(self.user).pw_uid
        l1lllll111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l11ll):
            os.makedirs(l1l11ll)
            os.system(l1ll1l1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l11ll))
            logger.debug(l1ll1l1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l11ll)
        else:
            logger.debug(l1ll1l1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l11ll)
        l11l=os.path.join(l1l11ll, self.l1llll1l11)
        print(l11l)
        logger.debug(l1ll1l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11l)
        with open(l11l, l1ll1l1 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1ll1l:
            logger.debug(self.l1llll1l + l1ll1l1 (u"ࠪࠤࠬপ")+self.l1lll11111+l1ll1l1 (u"ࠫࠥࠨࠧফ")+self.l1llll1lll+l1ll1l1 (u"ࠬࠨࠧব"))
            l1lll1ll1l.writelines(self.l1llll1l + l1ll1l1 (u"࠭ࠠࠨভ")+self.l1lll11111+l1ll1l1 (u"ࠧࠡࠤࠪম")+self.l1llll1lll+l1ll1l1 (u"ࠨࠤࠪয"))
        os.chmod(l11l, 0o600)
        os.chown(l11l, l1lll11lll, l1lllll111)
    def l1lllll11l(self, l1lll1ll11=l1ll1l1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll1l1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1ll11 in groups:
            logger.info(l1ll1l1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1ll11))
        else:
            logger.warning(l1ll1l1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1ll11))
            l1ll11l1=l1ll1l1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1ll11,self.user)
            logger.debug(l1ll1l1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll11l1)
            os.system(l1ll11l1)
            logger.debug(l1ll1l1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l1ll(self):
        logger.debug(l1ll1l1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll111l1=l1lll1lll1()
        l1lll111l1.add(self.l1llll1l, self.l1l11ll, l1llll111l=l1ll1l1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll1l1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll1l1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll1111 = urllib.parse.unquote(sys.argv[1])
        if l1llll1111:
            l1llllll1l=l1lll1l1l1(l1llll1111)
        else:
            raise (l1ll1l1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll1l1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise