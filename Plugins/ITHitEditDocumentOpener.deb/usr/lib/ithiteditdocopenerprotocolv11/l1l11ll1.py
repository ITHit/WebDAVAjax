#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11l111 import l11l1
from configobj import ConfigObj
l1l111l1 = l1l1l1l (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1l111 = l1l1l1l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠷࠴࠸࠺࠵࠼࠲࠵ࠨࡤ")
l1l11l1l = l1l1l1l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l1l1l (u"ࠣ࠸࠱࠶࠳࠾࠹࠴࠻࠱࠴ࠧࡦ")
l1l1llll=os.path.join(os.environ.get(l1l1l1l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l1l1l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11l1l.replace(l1l1l1l (u"ࠦࠥࠨࡩ"), l1l1l1l (u"ࠧࡥࠢࡪ")).lower())
l11ll1l1=os.environ.get(l1l1l1l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l1l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11llll1=l1l1l111.replace(l1l1l1l (u"ࠣࠢࠥ࡭"), l1l1l1l (u"ࠤࡢࠦ࡮"))+l1l1l1l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l1l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1ll1l=os.path.join(os.environ.get(l1l1l1l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11llll1)
elif platform.system() == l1l1l1l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll11l=l11l1(l1l1llll+l1l1l1l (u"ࠢ࠰ࠤࡳ"))
    l1l1ll1l = os.path.join(l11ll11l, l11llll1)
else:
    l1l1ll1l = os.path.join( l11llll1)
l11ll1l1=l11ll1l1.upper()
if l11ll1l1 == l1l1l1l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1ll11=logging.DEBUG
elif l11ll1l1 == l1l1l1l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1ll11 = logging.INFO
elif l11ll1l1 == l1l1l1l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1ll11 = logging.WARNING
elif l11ll1l1 == l1l1l1l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1ll11 = logging.ERROR
elif l11ll1l1 == l1l1l1l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1ll11 = logging.CRITICAL
elif l11ll1l1 == l1l1l1l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1ll11 = logging.NOTSET
logger = logging.getLogger(l1l1l1l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1ll11)
l1l1l11l = logging.FileHandler(l1l1ll1l, mode=l1l1l1l (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l11l.setLevel(l1l1ll11)
formatter = logging.Formatter(l1l1l1l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l1l1l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1ll11)
l11ll111 = SysLogHandler(address=l1l1l1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll111.setFormatter(formatter)
logger.addHandler(l1l1l11l)
logger.addHandler(ch)
logger.addHandler(l11ll111)
class Settings():
    l1l1lll1 = l1l1l1l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11l11 = l1l1l1l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111ll = l1l1l1l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l111):
        self.l11lll11 = self._1l1111l(l1l1l111)
        self._1l1l1l1()
    def _1l1111l(self, l1l1l111):
        l1l11lll = l1l1l111.split(l1l1l1l (u"ࠣࠢࠥࢂ"))
        l1l11lll = l1l1l1l (u"ࠤࠣࠦࢃ").join(l1l11lll)
        if platform.system() == l1l1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11lll11 = os.path.join(l1l1llll, l1l1l1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11lll + l1l1l1l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11lll11
    def l1l1l1ll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1l1l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1l1l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11lllll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1l1l1(self):
        if not os.path.exists(os.path.dirname(self.l11lll11)):
            os.makedirs(os.path.dirname(self.l11lll11))
        if not os.path.exists(self.l11lll11):
            self.config = ConfigObj(self.l11lll11)
            self.config[l1l1l1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l1l1l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l1l1l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111ll
            self.config[l1l1l1l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1l1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11l11
            self.config[l1l1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1lll1
            self.config[l1l1l1l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lll11)
            self.l1l111ll = self.get_value(l1l1l1l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l1l1l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11l11 = self.get_value(l1l1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1l1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1lll1 = self.get_value(l1l1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11ll1ll(self):
        l11l1lll = l1l1l1l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1lll1
        l11l1lll += l1l1l1l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11l11
        l11l1lll += l1l1l1l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111ll
        return l11l1lll
    def __unicode__(self):
        return self._11ll1ll()
    def __str__(self):
        return self._11ll1ll()
    def __del__(self):
        self.config.write()
l1l11111 = Settings(l1l1l111)