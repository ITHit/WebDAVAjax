#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l11 = sys.version_info [0] == 2
l1ll1l = 2048
l11ll11 = 7
def l1llllll (l11l111):
    global l11l11
    l1ll1l11 = ord (l11l111 [-1])
    l1llll = l11l111 [:-1]
    ll = l1ll1l11 % len (l1llll)
    l1ll1 = l1llll [:ll] + l1llll [ll:]
    if l1l1l11:
        l1l111 = l1llll1l () .join ([unichr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    return eval (l1l111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll11 import l11ll1
from configobj import ConfigObj
l1l1l1l1 = l1llllll (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l11lllll = l1llllll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠺࠳࠴࠲࠵ࠨࡤ")
l1l11l11 = l1llllll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1llllll (u"ࠣ࠸࠱࠴࠳࠾࠹࠲࠳࠱࠴ࠧࡦ")
l1l1111l=os.path.join(os.environ.get(l1llllll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1llllll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11l11.replace(l1llllll (u"ࠦࠥࠨࡩ"), l1llllll (u"ࠧࡥࠢࡪ")).lower())
l1l111l1=os.environ.get(l1llllll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1llllll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l111ll=l11lllll.replace(l1llllll (u"ࠣࠢࠥ࡭"), l1llllll (u"ࠤࡢࠦ࡮"))+l1llllll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1llllll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1l111=os.path.join(os.environ.get(l1llllll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l111ll)
elif platform.system() == l1llllll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l11l=l11ll1(l1l1111l+l1llllll (u"ࠢ࠰ࠤࡳ"))
    l1l1l111 = os.path.join(l1l1l11l, l1l111ll)
else:
    l1l1l111 = os.path.join( l1l111ll)
l1l111l1=l1l111l1.upper()
if l1l111l1 == l1llllll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lll1l=logging.DEBUG
elif l1l111l1 == l1llllll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lll1l = logging.INFO
elif l1l111l1 == l1llllll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lll1l = logging.WARNING
elif l1l111l1 == l1llllll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lll1l = logging.ERROR
elif l1l111l1 == l1llllll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lll1l = logging.CRITICAL
elif l1l111l1 == l1llllll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lll1l = logging.NOTSET
logger = logging.getLogger(l1llllll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lll1l)
l11ll111 = logging.FileHandler(l1l1l111, mode=l1llllll (u"ࠣࡹ࠮ࠦࡻ"))
l11ll111.setLevel(l11lll1l)
formatter = logging.Formatter(l1llllll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1llllll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11ll111.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll1l)
l1l1l1ll = SysLogHandler(address=l1llllll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1l1ll.setFormatter(formatter)
logger.addHandler(l11ll111)
logger.addHandler(ch)
logger.addHandler(l1l1l1ll)
class Settings():
    l11ll11l = l1llllll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1ll1l = l1llllll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l11lll = l1llllll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11lllll):
        self.l1l11ll1 = self._11ll1ll(l11lllll)
        self._11ll1l1()
    def _11ll1ll(self, l11lllll):
        l1l1llll = l11lllll.split(l1llllll (u"ࠣࠢࠥࢂ"))
        l1l1llll = l1llllll (u"ࠤࠣࠦࢃ").join(l1l1llll)
        if platform.system() == l1llllll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11ll1 = os.path.join(l1l1111l, l1llllll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1llll + l1llllll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11ll1
    def l11llll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1ll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1llllll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1llllll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11l1l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll1l1(self):
        if not os.path.exists(os.path.dirname(self.l1l11ll1)):
            os.makedirs(os.path.dirname(self.l1l11ll1))
        if not os.path.exists(self.l1l11ll1):
            self.config = ConfigObj(self.l1l11ll1)
            self.config[l1llllll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1llllll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1llllll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l11lll
            self.config[l1llllll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1llllll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1llllll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1ll1l
            self.config[l1llllll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1llllll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll11l
            self.config[l1llllll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11ll1)
            self.l1l11lll = self.get_value(l1llllll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1llllll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1ll1l = self.get_value(l1llllll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1llllll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll11l = self.get_value(l1llllll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1llllll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1lll1(self):
        l1l11111 = l1llllll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll11l
        l1l11111 += l1llllll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1ll1l
        l1l11111 += l1llllll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l11lll
        return l1l11111
    def __unicode__(self):
        return self._1l1lll1()
    def __str__(self):
        return self._1l1lll1()
    def __del__(self):
        self.config.write()
l11l1lll = Settings(l11lllll)