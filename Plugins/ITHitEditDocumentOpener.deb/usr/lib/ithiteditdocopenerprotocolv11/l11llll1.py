#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11111l import l1ll1
from configobj import ConfigObj
l1l11lll = l111l (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1llll = l111l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠷࠴࠸࠺࠵࠺࠲࠵ࠨࡤ")
l1l1l11l = l111l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l111l (u"ࠣ࠸࠱࠶࠳࠾࠹࠴࠹࠱࠴ࠧࡦ")
l1l1ll11=os.path.join(os.environ.get(l111l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l111l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1l11l.replace(l111l (u"ࠦࠥࠨࡩ"), l111l (u"ࠧࡥࠢࡪ")).lower())
l1l111l1=os.environ.get(l111l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lllll=l1l1llll.replace(l111l (u"ࠣࠢࠥ࡭"), l111l (u"ࠤࡢࠦ࡮"))+l111l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11l1l=os.path.join(os.environ.get(l111l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lllll)
elif platform.system() == l111l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1lll1=l1ll1(l1l1ll11+l111l (u"ࠢ࠰ࠤࡳ"))
    l1l11l1l = os.path.join(l1l1lll1, l11lllll)
else:
    l1l11l1l = os.path.join( l11lllll)
l1l111l1=l1l111l1.upper()
if l1l111l1 == l111l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lll1l=logging.DEBUG
elif l1l111l1 == l111l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lll1l = logging.INFO
elif l1l111l1 == l111l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lll1l = logging.WARNING
elif l1l111l1 == l111l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lll1l = logging.ERROR
elif l1l111l1 == l111l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lll1l = logging.CRITICAL
elif l1l111l1 == l111l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lll1l = logging.NOTSET
logger = logging.getLogger(l111l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lll1l)
l11ll1l1 = logging.FileHandler(l1l11l1l, mode=l111l (u"ࠣࡹ࠮ࠦࡻ"))
l11ll1l1.setLevel(l11lll1l)
formatter = logging.Formatter(l111l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l111l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11ll1l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll1l)
l1l11l11 = SysLogHandler(address=l111l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l11ll1l1)
logger.addHandler(ch)
logger.addHandler(l1l11l11)
class Settings():
    l1l111ll = l111l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11l1lll = l111l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l111 = l111l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1llll):
        self.l11ll11l = self._1l1ll1l(l1l1llll)
        self._1l1111l()
    def _1l1ll1l(self, l1l1llll):
        l1l11111 = l1l1llll.split(l111l (u"ࠣࠢࠥࢂ"))
        l1l11111 = l111l (u"ࠤࠣࠦࢃ").join(l1l11111)
        if platform.system() == l111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11ll11l = os.path.join(l1l1ll11, l111l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11111 + l111l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11ll11l
    def l11ll111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll1ll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1111l(self):
        if not os.path.exists(os.path.dirname(self.l11ll11l)):
            os.makedirs(os.path.dirname(self.l11ll11l))
        if not os.path.exists(self.l11ll11l):
            self.config = ConfigObj(self.l11ll11l)
            self.config[l111l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l111l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l111l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l111
            self.config[l111l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11l1lll
            self.config[l111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l111ll
            self.config[l111l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll11l)
            self.l1l1l111 = self.get_value(l111l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l111l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11l1lll = self.get_value(l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l111ll = self.get_value(l111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l1l1(self):
        l11lll11 = l111l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l111ll
        l11lll11 += l111l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11l1lll
        l11lll11 += l111l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l111
        return l11lll11
    def __unicode__(self):
        return self._1l1l1l1()
    def __str__(self):
        return self._1l1l1l1()
    def __del__(self):
        self.config.write()
l1l11ll1 = Settings(l1l1llll)