#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l11ll = 2048
l1ll1l11 = 7
def l1l111 (l111l11):
    global l1l1l1
    l111ll1 = ord (l111l11 [-1])
    l111l1l = l111l11 [:-1]
    l1ll11l = l111ll1 % len (l111l1l)
    l1l1l1l = l111l1l [:l1ll11l] + l111l1l [l1ll11l:]
    if l1lll111:
        l1l1l11 = l1l11 () .join ([unichr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    else:
        l1l1l11 = str () .join ([chr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    return eval (l1l1l11)
import hashlib
import os
import l111lll
from l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111lll import l1l1ll1
from l11l1ll import l1llll1l, l1lll1l
import logging
logger = logging.getLogger(l1l111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll11ll():
    def __init__(self, l1l11l1,ll, l1lll11= None, l1llll1=None):
        self.l11l11=False
        self.l11l1l = self._11l()
        self.ll = ll
        self.l1lll11 = l1lll11
        self.l111ll = l1l11l1
        if l1lll11:
            self.l111l1 = True
        else:
            self.l111l1 = False
        self.l1llll1 = l1llll1
    def _11l(self):
        try:
            return l111lll.l11llll() is not None
        except:
            return False
    def open(self):
        l1l111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l1l:
            raise NotImplementedError(l1l111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll11 = self.l111ll
        if self.ll.lower().startswith(self.l111ll.lower()):
            l1llll11 = re.compile(re.escape(self.l111ll), re.IGNORECASE)
            ll = l1llll11.sub(l1l111 (u"ࠨࠩࠄ"), self.ll)
            ll = ll.replace(l1l111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1111l1(self.l111ll, l1ll11, ll, self.l1lll11)
    def l1111l1(self,l111ll, l1ll11, ll, l1lll11):
        l1l111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll1l1 = l11lll(l111ll)
        l1lllll = self.l1l1l(l1lll1l1)
        logger.info(l1l111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll1l1)
        if l1lllll:
            logger.info(l1l111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1ll1(l1lll1l1)
            l1lll1l1 = l11ll(l111ll, l1ll11, l1lll11, self.l1llll1)
        logger.debug(l1l111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11lll1=l1lll1l1 + l1l111 (u"ࠤ࠲ࠦࠌ") + ll
        l1lllll1 = l1l111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11lll1+ l1l111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1lllll1)
        l111l = os.system(l1lllll1)
        if (l111l != 0):
            raise IOError(l1l111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11lll1, l111l))
    def l1l1l(self, l1lll1l1):
        if os.path.exists(l1lll1l1):
            if os.path.islink(l1lll1l1):
                l1lll1l1 = os.readlink(l1lll1l1)
            if os.path.ismount(l1lll1l1):
                return True
        return False
def l11lll(l111ll):
    l1ll111l = l111ll.replace(l1l111 (u"࠭࡜࡝ࠩࠐ"), l1l111 (u"ࠧࡠࠩࠑ")).replace(l1l111 (u"ࠨ࠱ࠪࠒ"), l1l111 (u"ࠩࡢࠫࠓ"))
    l1ll1ll1 = l1l111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1111l=os.environ[l1l111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11=os.path.join(l1111l,l1ll1ll1, l1ll111l)
    l1l=os.path.abspath(l11)
    return l1l
def l1l111l(l1l1111):
    if not os.path.exists(l1l1111):
        os.makedirs(l1l1111)
def l111(l111ll, l1ll11, l11l111=None, password=None):
    l1l111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l1111 = l11lll(l111ll)
    l1l111l(l1l1111)
    if not l11l111:
        l1ll11l1 = l1ll1lll()
        l1l1lll =l1ll11l1.l11ll11(l1l111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll11 + l1l111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll11 + l1l111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l1lll, str):
            l11l111, password = l1l1lll
        else:
            raise l1lll1l()
        logger.info(l1l111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l1111))
    l1111ll = pwd.getpwuid( os.getuid())[0]
    l1llll=os.environ[l1l111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll111={l1l111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1111ll, l1l111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111ll, l1l111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l1111, l1l111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1llll, l1l111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l111, l1l111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll111, temp_file)
        if not os.path.exists(os.path.join(l1lll1, l1l111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l1ll=l1l111 (u"ࠦࡵࡿࠢࠣ")
            key=l1l111 (u"ࠧࠨࠤ")
        else:
            l1l1ll=l1l111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11111l=l1l111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l1ll,temp_file.name)
        l1ll=[l1l111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll1, l11111l)]
        p = subprocess.Popen(l1ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l1111
    logger.debug(l1l111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l=os.path.abspath(l1l1111)
    logger.debug(l1l111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l)
    return l1l
def l11ll(l111ll, l1ll11, l1lll11, l1llll1):
    l1l111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll1ll(title):
        l1ll1l=30
        if len(title)>l1ll1l:
            l1ll1l1l=title.split(l1l111 (u"ࠨ࠯ࠣ࠳"))
            l11ll1=l1l111 (u"ࠧࠨ࠴")
            for block in l1ll1l1l:
                l11ll1+=block+l1l111 (u"ࠣ࠱ࠥ࠵")
                if len(l11ll1) > l1ll1l:
                    l11ll1+=l1l111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11ll1
        return title
    def l1l1(l1llllll, password):
        l1l111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l111 (u"ࠧࠦࠢ࠹").join(l1llllll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l1 = l1l111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l1.encode())
        l111111 = [l1l111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11111 = l1l111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11111)
            for e in l111111:
                if e in l11111: return False
            raise l1llll1l(l11111, l11ll=l111lll.l11llll(), l1ll11=l1ll11)
        logger.info(l1l111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11l111 = l1l111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l111 (u"ࠦࠧ࠿")
    os.system(l1l111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1 = l11lll(l111ll)
    l1l1111 = l11lll(hashlib.sha1(l111ll.encode()).hexdigest()[:10])
    l1l111l(l1l1111)
    logger.info(l1l111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l1111))
    if l1lll11:
        l1llllll = [l1l111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l111 (u"ࠤ࠰ࡸࠧࡄ"), l1l111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l111 (u"ࠫ࠲ࡵࠧࡆ"), l1l111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11l111, l1lll11),
                    urllib.parse.unquote(l1ll11), os.path.abspath(l1l1111)]
        l1l1(l1llllll, password)
    else:
        while True:
            l11l111, password = l1111(l1l1111, l1ll11, l1llll1)
            if l11l111.lower() != l1l111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1llllll = [l1l111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l111 (u"ࠤ࠰ࡸࠧࡋ"), l1l111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l111 (u"ࠫ࠲ࡵࠧࡍ"), l1l111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11l111,
                            urllib.parse.unquote(l1ll11), os.path.abspath(l1l1111)]
            else:
                raise l1lll1l()
            if l1l1(l1llllll, password): break
    os.system(l1l111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l1111, l1ll1))
    l1l=os.path.abspath(l1ll1)
    return l1l
def l1111(l111ll, l1ll11, l1llll1):
    l1ll1ll = os.path.join(os.environ[l1l111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1ll)):
       os.makedirs(os.path.dirname(l1ll1ll))
    l1l11l = l1llll1.get_value(l1l111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll11l1 = l1ll1lll(l111ll, l1l11l)
    l11l111, password = l1ll11l1.l11ll11(l1l111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll11 + l1l111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll11 + l1l111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11l111 != l1l111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll1111(l111ll, l11l111):
        l1lll11l = l1l111 (u"ࠤ࡙ࠣࠦ").join([l111ll, l11l111, l1l111 (u"࡚ࠪࠦࠬ") + password + l1l111 (u"࡛ࠫࠧ࠭"), l1l111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1ll, l1l111 (u"࠭ࡷࠬࠩ࡝")) as l1lll:
            l1lll.write(l1lll11l)
        os.chmod(l1ll1ll, 0o600)
    return l11l111, password
def l1ll1111(l111ll, l11l111):
    l1ll1ll = l1ll1l1 = os.path.join(os.environ[l1l111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1ll):
        with open(l1ll1ll, l1l111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l1l1 = data[0].split(l1l111 (u"ࠦࠥࠨࡢ"))
            if l111ll == l11l1l1[0] and l11l111 == l11l1l1[1]:
                return True
    return False