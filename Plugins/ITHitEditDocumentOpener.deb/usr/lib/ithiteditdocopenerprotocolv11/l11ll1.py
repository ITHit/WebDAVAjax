#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111ll = sys.version_info [0] == 2
l11l1l = 2048
l1llll11 = 7
def l11lll1 (l1ll11l1):
    global l1l1ll
    l1l1lll = ord (l1ll11l1 [-1])
    l1lll = l1ll11l1 [:-1]
    l1llll1 = l1l1lll % len (l1lll)
    l1l1l = l1lll [:l1llll1] + l1lll [l1llll1:]
    if l1111ll:
        l1lll111 = l11ll1l () .join ([unichr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    else:
        l1lll111 = str () .join ([chr (ord (char) - l11l1l - (l11llll + l1l1lll) % l1llll11) for l11llll, char in enumerate (l1l1l)])
    return eval (l1lll111)
import re
class l1ll1lll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llll1ll = kwargs.get(l11lll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l1l1 = kwargs.get(l11lll1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l11111ll = self.l1llll1l1(args)
        if l11111ll:
            args=args+ l11111ll
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        l11111ll=None
        l1l1l111 = args[0][0]
        if re.search(l11lll1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1l111):
            l11111ll = (l11lll1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1llll1ll
                            ,)
        return l11111ll
class l1lllll1l(Exception):
    def __init__(self, *args, **kwargs):
        l11111ll = self.l1llll1l1(args)
        if l11111ll:
            args = args + l11111ll
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        s = l11lll1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11lll1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1111l11(Exception):
    pass
class l1lll1ll(Exception):
    pass
class l1lllllll(Exception):
    def __init__(self, message, l1lllll11, url):
        super(l1lllllll,self).__init__(message)
        self.l1lllll11 = l1lllll11
        self.url = url
class l1llllll1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l111111l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll11l(Exception):
    pass
class l11111l1(Exception):
    pass
class l1111111(Exception):
    pass
class l1111lll(Exception):
    pass