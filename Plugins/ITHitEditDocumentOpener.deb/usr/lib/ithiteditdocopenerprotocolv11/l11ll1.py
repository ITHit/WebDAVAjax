#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1llll1 = 2048
l11111l = 7
def l1lll1l (l11):
    global l1l1111
    ll = ord (l11 [-1])
    l1l1ll1 = l11 [:-1]
    l1l1l = ll % len (l1l1ll1)
    l1l1l11 = l1l1ll1 [:l1l1l] + l1l1ll1 [l1l1l:]
    if l1ll1ll1:
        l11l = l1llllll () .join ([unichr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    return eval (l11l)
import logging
import os
import re
from l1ll11l1 import l1llllll1
logger = logging.getLogger(l1lll1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1111l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll1l():
    try:
        out = os.popen(l1lll1l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll1l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll1l (u"ࠤࠥॸ").join(result)
                logger.info(l1lll1l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll1l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll1l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll1l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llllll1(l1lll1l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll1l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1111l1(l1lll1l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))