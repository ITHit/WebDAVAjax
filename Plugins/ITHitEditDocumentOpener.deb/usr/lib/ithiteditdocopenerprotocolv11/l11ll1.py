#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1llllll = 2048
l11llll = 7
def l1 (l1lllll1):
    global l111111
    l1ll11 = ord (l1lllll1 [-1])
    l11ll1l = l1lllll1 [:-1]
    l1ll1l1l = l1ll11 % len (l11ll1l)
    l11l111 = l11ll1l [:l1ll1l1l] + l11ll1l [l1ll1l1l:]
    if l111ll:
        l11l1ll = l1ll1ll () .join ([unichr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1llllll - (l1llll1l + l1ll11) % l11llll) for l1llll1l, char in enumerate (l11l111)])
    return eval (l11l1ll)
import hashlib
import os
import l1111
from l1l1ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1111 import l111ll1
from l11lll import l11111l, l11ll11
import logging
logger = logging.getLogger(l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll111l():
    def __init__(self, l111l11,l1ll, l1llll11= None, l1l1l=None):
        self.l1llll=False
        self.l111 = self._11l()
        self.l1ll = l1ll
        self.l1llll11 = l1llll11
        self.l1llll1 = l111l11
        if l1llll11:
            self.l11l1l = True
        else:
            self.l11l1l = False
        self.l1l1l = l1l1l
    def _11l(self):
        try:
            return l1111.l111l1() is not None
        except:
            return False
    def open(self):
        l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111:
            raise NotImplementedError(l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1l1l = self.l1llll1
        if self.l1ll.lower().startswith(self.l1llll1.lower()):
            l1ll11l1 = re.compile(re.escape(self.l1llll1), re.IGNORECASE)
            l1ll = l1ll11l1.sub(l1 (u"ࠨࠩࠄ"), self.l1ll)
            l1ll = l1ll.replace(l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll(self.l1llll1, l1l1l1l, l1ll, self.l1llll11)
    def l1lll(self,l1llll1, l1l1l1l, l1ll, l1llll11):
        l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1l1 = l11ll(l1llll1)
        l1l111l = self.l1lll1l(l1ll1l1)
        logger.info(l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1l1)
        if l1l111l:
            logger.info(l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111ll1(l1ll1l1)
            l1ll1l1 = l11(l1llll1, l1l1l1l, l1llll11, self.l1l1l)
        logger.debug(l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll111=l1ll1l1 + l1 (u"ࠤ࠲ࠦࠌ") + l1ll
        l1l111 = l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll111+ l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l111)
        l1ll1lll = os.system(l1l111)
        if (l1ll1lll != 0):
            raise IOError(l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll111, l1ll1lll))
    def l1lll1l(self, l1ll1l1):
        if os.path.exists(l1ll1l1):
            if os.path.islink(l1ll1l1):
                l1ll1l1 = os.readlink(l1ll1l1)
            if os.path.ismount(l1ll1l1):
                return True
        return False
def l11ll(l1llll1):
    l1l1lll = l1llll1.replace(l1 (u"࠭࡜࡝ࠩࠐ"), l1 (u"ࠧࡠࠩࠑ")).replace(l1 (u"ࠨ࠱ࠪࠒ"), l1 (u"ࠩࡢࠫࠓ"))
    l1111l1 = l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1lll11l=os.environ[l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1l=os.path.join(l1lll11l,l1111l1, l1l1lll)
    ll=os.path.abspath(l1ll1l)
    return ll
def l1111ll(l1lll1):
    if not os.path.exists(l1lll1):
        os.makedirs(l1lll1)
def l1l11(l1llll1, l1l1l1l, l11l1l1=None, password=None):
    l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll1 = l11ll(l1llll1)
    l1111ll(l1lll1)
    if not l11l1l1:
        l1l11l1 = l111l1l()
        l1lll111 =l1l11l1.l1111l(l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1l1l + l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1l1l + l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll111, str):
            l11l1l1, password = l1lll111
        else:
            raise l11ll11()
        logger.info(l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll1))
    l11l11 = pwd.getpwuid( os.getuid())[0]
    l1l1=os.environ[l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1ll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll1ll={l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11, l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1llll1, l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll1, l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1, l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l1l1, l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll1ll, temp_file)
        if not os.path.exists(os.path.join(l1l1ll1, l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l=l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1 (u"ࠧࠨࠤ")
        else:
            l1l=l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll11=l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l,temp_file.name)
        l1ll1l11=[l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1ll1, l1lll11)]
        p = subprocess.Popen(l1ll1l11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll1
    logger.debug(l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    ll=os.path.abspath(l1lll1)
    logger.debug(l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+ll)
    return ll
def l11(l1llll1, l1l1l1l, l1llll11, l1l1l):
    l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1(title):
        l1ll11l=30
        if len(title)>l1ll11l:
            l11111=title.split(l1 (u"ࠨ࠯ࠣ࠳"))
            l11l11l=l1 (u"ࠧࠨ࠴")
            for block in l11111:
                l11l11l+=block+l1 (u"ࠣ࠱ࠥ࠵")
                if len(l11l11l) > l1ll11l:
                    l11l11l+=l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l11l
        return title
    def l1l11l(l11l1, password):
        l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1 (u"ࠧࠦࠢ࠹").join(l11l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l111l = l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l111l.encode())
        l1l11ll = [l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll11ll = l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll11ll)
            for e in l1l11ll:
                if e in l1ll11ll: return False
            raise l11111l(l1ll11ll, l11=l1111.l111l1(), l1l1l1l=l1l1l1l)
        logger.info(l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11l1l1 = l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1 (u"ࠦࠧ࠿")
    os.system(l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll1l1 = l11ll(l1llll1)
    l1lll1 = l11ll(hashlib.sha1(l1llll1.encode()).hexdigest()[:10])
    l1111ll(l1lll1)
    logger.info(l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1lll1))
    if l1llll11:
        l11l1 = [l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1 (u"ࠤ࠰ࡸࠧࡄ"), l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1 (u"ࠫ࠲ࡵࠧࡆ"), l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11l1l1, l1llll11),
                    urllib.parse.unquote(l1l1l1l), os.path.abspath(l1lll1)]
        l1l11l(l11l1, password)
    else:
        while True:
            l11l1l1, password = l1l1l1(l1lll1, l1l1l1l, l1l1l)
            if l11l1l1.lower() != l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l1 = [l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1 (u"ࠤ࠰ࡸࠧࡋ"), l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1 (u"ࠫ࠲ࡵࠧࡍ"), l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11l1l1,
                            urllib.parse.unquote(l1l1l1l), os.path.abspath(l1lll1)]
            else:
                raise l11ll11()
            if l1l11l(l11l1, password): break
    os.system(l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1lll1, l1lll1l1))
    ll=os.path.abspath(l1lll1l1)
    return ll
def l1l1l1(l1llll1, l1l1l1l, l1l1l):
    l1ll1ll1 = os.path.join(os.environ[l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1ll1)):
       os.makedirs(os.path.dirname(l1ll1ll1))
    l11lll1 = l1l1l.get_value(l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l11l1 = l111l1l(l1llll1, l11lll1)
    l11l1l1, password = l1l11l1.l1111l(l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1l1l + l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1l1l + l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11l1l1 != l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1lllll(l1llll1, l11l1l1):
        l1ll1111 = l1 (u"ࠤ࡙ࠣࠦ").join([l1llll1, l11l1l1, l1 (u"࡚ࠪࠦࠬ") + password + l1 (u"࡛ࠫࠧ࠭"), l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1ll1, l1 (u"࠭ࡷࠬࠩ࡝")) as l1l1l11:
            l1l1l11.write(l1ll1111)
        os.chmod(l1ll1ll1, 0o600)
    return l11l1l1, password
def l1lllll(l1llll1, l11l1l1):
    l1ll1ll1 = l111lll = os.path.join(os.environ[l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1ll1):
        with open(l1ll1ll1, l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l1111 = data[0].split(l1 (u"ࠦࠥࠨࡢ"))
            if l1llll1 == l1l1111[0] and l11l1l1 == l1l1111[1]:
                return True
    return False