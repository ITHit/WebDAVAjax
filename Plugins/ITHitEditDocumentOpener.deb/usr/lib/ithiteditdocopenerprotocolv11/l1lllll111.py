#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1111ll = 2048
l1l1111 = 7
def l1ll11ll (l1l11ll):
    global l1111
    l11ll11 = ord (l1l11ll [-1])
    l1lll11 = l1l11ll [:-1]
    l1l = l11ll11 % len (l1lll11)
    l1l111l = l1lll11 [:l1l] + l1lll11 [l1l:]
    if l11l111:
        l11lll = l1ll11 () .join ([unichr (ord (char) - l1111ll - (l1l1l + l11ll11) % l1l1111) for l1l1l, char in enumerate (l1l111l)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1111ll - (l1l1l + l11ll11) % l1l1111) for l1l1l, char in enumerate (l1l111l)])
    return eval (l11lll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l11l=logging.WARNING
logger = logging.getLogger(l1ll11ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l11l)
l11lllll = SysLogHandler(address=l1ll11ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll11ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11lllll.setFormatter(formatter)
logger.addHandler(l11lllll)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l11l)
logger.addHandler(ch)
class l1lll1ll11(io.FileIO):
    l1ll11ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll11ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1111, l1lllll11l,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1111 = l1llll1111
            self.l1lllll11l = l1lllll11l
            if not options:
                options = l1ll11ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll11ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1111,
                                              self.l1lllll11l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1lll1 = os.path.join(os.path.sep, l1ll11ll (u"ࠪࡩࡹࡩࠧই"), l1ll11ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l111 = path
        else:
            self._1lll1l111 = self.l1lll1lll1
        super(l1lll1ll11, self).__init__(self._1lll1l111, l1ll11ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11ll1(self, line):
        return l1lll1ll11.Entry(*[x for x in line.strip(l1ll11ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll11ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll11ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll11ll (u"ࠤࠦࠦ঍")):
                    yield self._1lll11ll1(line)
            except ValueError:
                pass
    def l1lllll1l1(self, attr, value):
        for entry in self.entries:
            l1lll11lll = getattr(entry, attr)
            if l1lll11lll == value:
                return entry
        return None
    def l1llll1l1l(self, entry):
        if self.l1lllll1l1(l1ll11ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll11ll (u"ࠫࡡࡴࠧএ")).encode(l1ll11ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll11l1(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll11ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll11ll (u"ࠢࠤࠤ঒")):
                if self._1lll11ll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll11ll (u"ࠨࠩও").join(lines).encode(l1ll11ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll1l(cls, l1llll1111, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1lllll1l1(l1ll11ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1111)
        if entry:
            return l1llll1ll1.l1llll11l1(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1111, l1lllll11l, options=None, path=None):
        return cls(path=path).l1llll1l1l(l1lll1ll11.Entry(device,
                                                    l1llll1111, l1lllll11l,
                                                    options=options))
class l1llll111l(object):
    def __init__(self, l1lll1llll):
        self.l1lll1l1l1=l1ll11ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11l1l=l1ll11ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1llll=l1lll1llll
        self.l1llll11ll()
        self.l1lll11111()
        self.l1llllll1l()
        self.l1lll1111l()
        self.l1lllllll1()
    def l1llll11ll(self):
        temp_file=open(l1llllll11,l1ll11ll (u"࠭ࡲࠨঘ"))
        l1l1l1l=temp_file.read()
        data=json.loads(l1l1l1l)
        self.user=data[l1ll11ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll111l=data[l1ll11ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11=data[l1ll11ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11l11=data[l1ll11ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11l11=data[l1ll11ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111l1=data[l1ll11ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llllll1l(self):
        l11ll1l=os.path.join(l1ll11ll (u"ࠨ࠯ࠣট"),l1ll11ll (u"ࠢࡶࡵࡵࠦঠ"),l1ll11ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll11ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll11ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11ll1l)
    def l1lllllll1(self):
        logger.info(l1ll11ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11=os.path.join(self.l11l11,self.l1lll1l1l1)
        l1llll1lll = pwd.getpwnam(self.user).pw_uid
        l1llll1l11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11):
            os.makedirs(l11)
            os.system(l1ll11ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11))
            logger.debug(l1ll11ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11)
        else:
            logger.debug(l1ll11ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11)
        l11ll1l=os.path.join(l11, self.l1lll11l1l)
        print(l11ll1l)
        logger.debug(l1ll11ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11ll1l)
        with open(l11ll1l, l1ll11ll (u"ࠤࡺ࠯ࠧ঩")) as l1lllll1ll:
            logger.debug(self.l1ll111l + l1ll11ll (u"ࠪࠤࠬপ")+self.l1lll11l11+l1ll11ll (u"ࠫࠥࠨࠧফ")+self.l1lll111l1+l1ll11ll (u"ࠬࠨࠧব"))
            l1lllll1ll.writelines(self.l1ll111l + l1ll11ll (u"࠭ࠠࠨভ")+self.l1lll11l11+l1ll11ll (u"ࠧࠡࠤࠪম")+self.l1lll111l1+l1ll11ll (u"ࠨࠤࠪয"))
        os.chmod(l11ll1l, 0o600)
        os.chown(l11ll1l, l1llll1lll, l1llll1l11)
    def l1lll11111(self, l1lll1l1ll=l1ll11ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll11ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1l1ll in groups:
            logger.info(l1ll11ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1l1ll))
        else:
            logger.warning(l1ll11ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1l1ll))
            l1l1=l1ll11ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1l1ll,self.user)
            logger.debug(l1ll11ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l1)
            os.system(l1l1)
            logger.debug(l1ll11ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1111l(self):
        logger.debug(l1ll11ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1ll1=l1lll1ll11()
        l1llll1ll1.add(self.l1ll111l, self.l11, l1lllll11l=l1ll11ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll11ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll11ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llllll11 = urllib.parse.unquote(sys.argv[1])
        if l1llllll11:
            l1lll111ll=l1llll111l(l1llllll11)
        else:
            raise (l1ll11ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll11ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise