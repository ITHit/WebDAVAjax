#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1111 = 7
def l1lll1ll (l1llll):
    global l1ll111l
    l1l1lll = ord (l1llll [-1])
    l11l1l = l1llll [:-1]
    l1ll1l1l = l1l1lll % len (l11l1l)
    l1l111l = l11l1l [:l1ll1l1l] + l11l1l [l1ll1l1l:]
    if l1ll1lll:
        l11ll11 = l1111 () .join ([unichr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    return eval (l11ll11)
import gi
gi.require_version(l1lll1ll (u"ࠨࡉࡷ࡯ࠬঽ"), l1lll1ll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11ll111
import logging
logger = logging.getLogger(l1lll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l11l1(Gtk.Window):
    def __init__(self, l1l11ll1l1, l1l11ll111):
        Gtk.Window.__init__(self)
        self.l1lllll=30
        self.l1ll11l1l1 = False
        self.service = l1l11ll1l1
        self.l11llll=l1l11ll111
        self.l1lll111=l11ll111.l1l11l1l
        self.l1l1l11lll = Gtk.ListStore(str)
        self.l1ll1l1lll()
    def l1l1ll1lll(self, service):
        l1ll11l1ll = self.l1lll111.l11llll1(l1lll1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll11l1ll
    def l1ll1l1lll(self, l1l11ll1l1=None):
        if l1l11ll1l1:
            self.l1l1l11lll.clear()
            l1ll1lll11=self.l1l1ll1lll(l1l11ll1l1)
            self.l1l1l11lll.append([l1lll1ll (u"ࠧࠨু")])
            for l11llll in l1ll1lll11:
                self.l1l1l11lll.append([l11llll])
        else:
            self.l1l1l11lll.clear()
            self.l1l1l11lll.append([l1lll1ll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1l1l1l1(self, widget, data=None):
        l1ll1ll111= widget.get_active()
        if data == l1lll1ll (u"ࠢ࠲ࠤৃ") and l1ll1ll111:
            self.l1ll1l1lll()
            self.l1ll1111l1.set_active(0)
            self.l1l11l11ll.set_text(l1lll1ll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l11l11ll.set_sensitive(False)
            self.l1ll1111l1.set_sensitive(False)
        else:
            self.l1ll1l1lll(l1l11ll1l1=self.service)
            self.l1ll1111l1.set_active(0)
            self.l1l11l11ll.set_text(l1lll1ll (u"ࠤࠥ৅"))
            self.l1ll1111l1.set_sensitive(True)
            self.l1l11l11ll.set_sensitive(True)
    def l1l1l1lll1(self, widget):
        if widget.get_active():
            l11llll = widget.get_child().get_text()
        else:
            l11llll = self.l1l1l11lll[widget.get_active()][0]
        password = self.l1l11l1lll(self.service, l11llll)
        if password:
            self.l1l11l11ll.set_text(password)
        else:
            self.l1l11l11ll.set_text(l1lll1ll (u"ࠥࠦ৆"))
    def l1ll111ll1(self, l11llll, pwd, service):
        keyring.set_password(service, l11llll, pwd)
        l1ll11l1ll=self.l1lll111.l11llll1(l1lll1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11llll in l1ll11l1ll:
            value = self.l1lll111.get_value(l1lll1ll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1lll111.l1l1lll1(l1lll1ll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1lll1ll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11llll))
    def l1l11l1lll(self, service, l11llll):
        l1l1ll1l1l = keyring.get_password(service, l11llll)
        return l1l1ll1l1l
    def l1l1ll111l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1l111l(self, widget, data=None):
        self.l1ll11l1l1=widget.get_active()
    def l11l1l1(self, message, title=l1lll1ll (u"ࠨࠩো"), l111l1lll=True):
        if l111l1lll:
            l1ll111lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1ll11l = Gtk.MessageDialog(self,
            l1ll111lll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1ll11l.set_title(title)
        l1ll1ll11l.set_default_response(Gtk.ResponseType.OK)
        l1l11l1l1l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll1lll1l = Gtk.VBox()
        l1ll1l1111 = Gtk.Box(spacing=1)
        l1ll1l1111.set_homogeneous(False)
        l1l1l1l111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l111.set_homogeneous(False)
        l1ll11l111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11l111.set_homogeneous(False)
        l1ll1l1111.pack_start(l1l1l1l111, True, True, 0)
        l1ll1l1111.pack_start(l1ll11l111, True, True, 0)
        l1l1lll1ll = l1ll1ll11l.get_content_area()
        l1ll1ll1l1 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1lll1ll.pack_start(l1ll1ll1l1, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1l1l1l = Gtk.Label()
        l1l11ll11l = Gtk.Label()
        l1l11ll11l.set_text(l1lll1ll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l11ll11l, True, True, 0)
        l1ll1l1l1l.set_text(l1lll1ll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll1l1l1l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1l1l1l, 0, 1, 0, 1)
        l1l1ll1l11 = Gtk.RadioButton.new_with_label_from_widget(None, l1lll1ll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1ll1l11.connect(l1lll1ll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1l1l1l1, l1lll1ll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1ll1l11, 1, 2, 0, 1)
        l1l1lll111 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1l11, l1lll1ll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1lll111.connect(l1lll1ll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1l1l1l1, l1lll1ll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1lll111, 1, 2, 1, 2)
        l1l1l1l1ll = Gtk.Label()
        l1l1l1l1ll.set_text(l1lll1ll (u"ࠥࠤࠧ৔"))
        table.attach(l1l1l1l1ll, 0, 1, 4, 6)
        l1l1l11111 = Gtk.Label()
        l1l1l11111.set_text(l1lll1ll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1l11111.set_justify(Gtk.Justification.RIGHT)
        l1l1l11111.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1111l1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l11lll)
        self.l1ll1111l1.set_entry_text_column(0)
        table.attach(l1l1l11111, 0, 1, 6, 8)
        table.attach(self.l1ll1111l1, 1, 3, 6, 8)
        self.l1ll1111l1.connect(l1lll1ll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1l1lll1)
        l1ll1llll1 = Gtk.Label()
        l1ll1llll1.set_text(l1lll1ll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1llll1.set_justify(Gtk.Justification.RIGHT)
        l1ll1llll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l11l11ll = Gtk.Entry()
        self.l1l11l11ll.set_visibility(False)
        self.l1l11l11ll.connect(l1lll1ll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1ll111l, l1ll1ll11l)
        table.attach(l1ll1llll1, 0, 1, 8, 10)
        table.attach(self.l1l11l11ll, 1, 3, 8, 10)
        l1l1llll1l = Gtk.CheckButton(l1lll1ll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1llll1l.connect(l1lll1ll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll1l111l, l1l1llll1l)
        l1l1llll1l.set_active(False)
        table.attach(l1l1llll1l, 1, 3, 12, 14)
        l1ll11ll11 = Gtk.Label()
        l1ll11ll11.set_text(l1lll1ll (u"ࠥࠤࠧ৛") * 5)
        l1ll1lll1l.pack_start(l1ll11ll11, True, True, 0)
        if self.l11llll:
            l1l1lll111.set_active(True)
            self.l1ll1111l1.set_active(0)
            self.l1ll1111l1.set_sensitive(True)
            self.l1l11l11ll.set_text(l1lll1ll (u"ࠦࠧড়"))
            self.l1l11l11ll.set_sensitive(True)
        else:
            self.l1ll1111l1.set_active(0)
            self.l1ll1111l1.set_sensitive(False)
            self.l1l11l11ll.set_text(l1lll1ll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l11l11ll.set_sensitive(False)
        l1l11l1l1l.pack_start(vbox, True, True, 0)
        l1l11l1l1l.pack_start(table, True, True, 0)
        l1l11l1l1l.pack_end(l1ll1lll1l, True, True, 0)
        l1ll1ll1l1.pack_start(l1l11l1l1l, True, True, 0)
        l1ll1ll11l.show_all()
        response = l1ll1ll11l.run()
        if self.l1ll1111l1.get_active():
            l11llll = self.l1ll1111l1.get_child().get_text()
        else:
            l11llll = self.l1l1l11lll[self.l1ll1111l1.get_active()][0]
        pwd = self.l1l11l11ll.get_text()
        l1ll1ll11l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll11l1l1:
                self.l1ll111ll1(l11llll, pwd, self.service)
            return l11llll, pwd
        else:
            return l1lll1ll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1lll1ll (u"ࠧࠨয়")
class l11ll1l1l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll11l11l(self, l1l11ll1):
        l1l11lll11 = Gtk.ScrolledWindow()
        l1l11lll11.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1l111l1=None
        self.l1l1llllll = Gtk.TextBuffer()
        self.l1l1llllll.set_text(l1l11ll1)
        self.set_style()
        regexp= l1lll1ll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll111111 = self._1l11lllll(l1l11ll1, regexp)
        self.l1l11l1l11(l1ll111111, self.l1l1llllll.get_start_iter())
        self.l1ll1111ll = Gtk.TextView(buffer=self.l1l1llllll)
        self.l1ll1111ll.set_property(l1lll1ll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll1111ll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll1111ll.connect(l1lll1ll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll111l1l)
        self.l1ll1111ll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l11lll11.set_size_request(300,100)
        self.l1ll1111ll.show()
        l1l11lll11.add(self.l1ll1111ll)
        l1l11lll11.show()
        return l1l11lll11
    def _1ll111l1l(self, *args, **kwargs):
        l1ll1l11ll, l1ll11ll1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1l11ll, l1ll11ll1l).get_tags()
        if not self.l1l1l111l1:
            self.l1l1l111l1 = args[1].window.get_cursor()
            self.l1l1l1111l = Gdk.Cursor(Gdk.CursorType.l1ll1l1ll1)
        elif tag:
            args[1].window.set_cursor(self.l1l1l1111l)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1l111l1:
                args[1].window.set_cursor(self.l1l1l111l1)
    def _1l11lllll(self, l1l11ll1, l1l1l1ll1l):
        res=[]
        l1l1lllll1=re.findall(l1l1l1ll1l,l1l11ll1)
        for l1ll1l11l1 in l1l1lllll1:
            for el in l1ll1l11l1:
                if el:
                    res.append(el)
        return res
    def l1l11l1l11(self, l1ll111111, start):
        l1l11lll1l=0
        for text in l1ll111111:
            end = self.l1l1llllll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l11lll1l+=1
                l1ll1ll1ll, l1l1l11l1l = match
                tag = self.l1l1llllll.create_tag(str(l1l11lll1l), foreground=l1lll1ll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1lll1ll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1ll1111, text)
                self.l1l1llllll.apply_tag(tag, l1ll1ll1ll, l1l1l11l1l)
                self.l1l11l1l11(l1ll111111, l1l1l11l1l)
    def _1l1ll1111(self, tag, widget, l1l1l11l11, _1l11l1ll1, text):
        _1l1l11ll1 = l1l1l11l11.type
        _1ll11lll1 = l1l1l11l11.window
        if _1l1l11ll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l11ll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1l11l11.button
            self.l1l1l111l1 = Gdk.Cursor(Gdk.CursorType.l1ll1l1ll1)
            if _1l1l11ll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1lll1ll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1ll11l11(self, message, title=l1lll1ll (u"ࠧࠨ০"), l111l1lll=True, l1l1ll11ll=None):
        if l111l1lll:
            l1ll111lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll111lll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1ll11ll:
            l1l1lll1ll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1l1111 = Gtk.HBox(spacing=0)
            l1ll111l11 = Gtk.HBox(spacing=5)
            l1l11ll1ll = Gtk.Label()
            l1l11ll1ll.set_markup(l1lll1ll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l11ll1ll.set_line_wrap(True)
            l1l11ll1ll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1lll1ll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1ll11l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11l1.show()
            l1ll11111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11111l.show()
            l1l1l1llll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1llll.show()
            l1ll1l1111.pack_start(separator, True, True, 0)
            l1ll1l1111.pack_start(l1l1ll11l1, True, True, 0)
            l1ll1l1111.pack_start(l1ll11111l, True, True, 0)
            l1ll1l1111.pack_start(l1l1l1llll, True, True, 0)
            l1ll1l1111.pack_start(l1l11ll1ll, False, True, 0)
            l1l1lll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll11l.show()
            l1ll1l1111.pack_end(l1l1lll11l, True, True, 0)
            l1l1llll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1llll11.show()
            vbox.pack_start(l1ll1l1111, True, True, 0)
            l1l11lll11=self.__1ll11l11l(l1l11ll1=l1l1ll11ll)
            vbox.pack_start(l1l11lll11, False, False, 0)
            vbox.pack_end(l1l1llll11, False, False, 0)
            l1ll111l11.pack_start(vbox, True, True,5)
            l1ll111l11.show()
            l1l1lll1ll.pack_end(l1ll111l11, False, False, 0)
            vbox.show()
            l1ll1l1111.show()
        window.run()
class l11l1lll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll11llll(self, widget, l1l1l1ll11):
        if l1l1l1ll11 == Gtk.ResponseType.OK:
            self.result = l1lll1ll (u"ࠥࡓࡐࠨ৩")
        elif l1l1l1ll11 == Gtk.ResponseType.CANCEL:
            self.result = l1lll1ll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1l1ll11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1lll1ll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11lll11l(self, title=l1lll1ll (u"ࠨࠢ৬"), message=l1lll1ll (u"ࠢࠣ৭") , l111l1lll=True):
        if l111l1lll:
            l1ll111lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll111lll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1lll1ll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll11llll)
        window.run()
class l1l1ll1ll1(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1lllll=None
        self.result = None
    def l1ll11llll(self, widget, l1l1l1ll11):
        print(widget, l1l1l1ll11)
        if l1l1l1ll11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l1ll11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l1ll11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1l111l(self, widget, l1l1l111ll):
        if l1l1l111ll.get_active():
            self.l1ll1lllll = 1
        else:
            self.l1ll1lllll = 0
    def l1l11llll1(self, title=l1lll1ll (u"ࠤࠥ৯"), message=l1lll1ll (u"ࠥࠦৰ"), l1l1lll1l1 =l1lll1ll (u"ࠦࠧৱ"),l111l1lll=True):
        if l111l1lll:
            l1ll111lll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll111lll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1lll1ll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll11llll)
        l1l1llll1l = Gtk.CheckButton(l1l1lll1l1)
        l1l1llll1l.connect(l1lll1ll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll1l111l, l1l1llll1l)
        l1l1llll1l.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1llll1l, expand=True, fill=True, padding=0)
        l1l1llll1l.show()
        window.run()
def l1l11l1ll(title, msg, l1l1lll1l1=l1lll1ll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l111l1lll=True):
    result=None
    try:
        l1ll1l1l11 = l1l1ll1ll1()
        l1ll1l1l11.l1l11llll1(title, msg, l1l1lll1l1, l111l1lll)
        result = {l1lll1ll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll1l1l11.result,  l1lll1ll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll1l1l11.l1ll1lllll}
    except Exception as e:
        logger.exception(l1lll1ll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1lll1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1111lll1 = l11ll1l1l()
    message= l1lll1ll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1l1l11l = l1lll1ll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1111lll1.l1ll11l11(message, l1lll1ll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l111l1lll=True, l1l1ll11ll=l1l1l1l11l)