#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111l = sys.version_info [0] == 2
l1ll1lll = 2048
l1l1l = 7
def l1l1 (l11ll11):
    global l111l11
    l1l111 = ord (l11ll11 [-1])
    l1lll1ll = l11ll11 [:-1]
    l1l1111 = l1l111 % len (l1lll1ll)
    l11 = l1lll1ll [:l1l1111] + l1lll1ll [l1l1111:]
    if l1l111l:
        l11l1l = l1ll () .join ([unichr (ord (char) - l1ll1lll - (l1lllll + l1l111) % l1l1l) for l1lllll, char in enumerate (l11)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll1lll - (l1lllll + l1l111) % l1l1l) for l1lllll, char in enumerate (l11)])
    return eval (l11l1l)
import re
class l111111(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111l1 = kwargs.get(l1l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll1l = kwargs.get(l1l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll1l1 = self.l1lll1ll1(args)
        if l1llll1l1:
            args=args+ l1llll1l1
        self.args = [a for a in args]
    def l1lll1ll1(self, *args):
        l1llll1l1=None
        l1l1ll1l = args[0][0]
        if re.search(l1l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1ll1l):
            l1llll1l1 = (l1l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l11111l1
                            ,)
        return l1llll1l1
class l111111l(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1l1 = self.l1lll1ll1(args)
        if l1llll1l1:
            args = args + l1llll1l1
        self.args = [a for a in args]
    def l1lll1ll1(self, *args):
        s = l1l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1l11(Exception):
    pass
class l1111(Exception):
    pass
class l1llll11l(Exception):
    def __init__(self, message, l1llllll1, url):
        super(l1llll11l,self).__init__(message)
        self.l1llllll1 = l1llllll1
        self.url = url
class l1111l11(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll111(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111111(Exception):
    pass
class l111ll11(Exception):
    pass