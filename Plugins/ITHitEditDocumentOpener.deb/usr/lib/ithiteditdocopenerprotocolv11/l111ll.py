#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111111 = sys.version_info [0] == 2
l111 = 2048
l1ll11 = 7
def l1ll1l1 (l1111ll):
    global l1ll1l11
    l1l1ll = ord (l1111ll [-1])
    l1111 = l1111ll [:-1]
    l11l1 = l1l1ll % len (l1111)
    l111lll = l1111 [:l11l1] + l1111 [l11l1:]
    if l111111:
        l111l1 = l11lll () .join ([unichr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    return eval (l111l1)
import re
class l1ll111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llll1l1 = kwargs.get(l1ll1l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l1 = kwargs.get(l1ll1l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llllll1 = self.l1111l11(args)
        if l1llllll1:
            args=args+ l1llllll1
        self.args = [a for a in args]
    def l1111l11(self, *args):
        l1llllll1=None
        l1l1ll11 = args[0][0]
        if re.search(l1ll1l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1ll11):
            l1llllll1 = (l1ll1l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1llll1l1
                            ,)
        return l1llllll1
class l1llll11l(Exception):
    def __init__(self, *args, **kwargs):
        l1llllll1 = self.l1111l11(args)
        if l1llllll1:
            args = args + l1llllll1
        self.args = [a for a in args]
    def l1111l11(self, *args):
        s = l1ll1l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll1l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lllllll(Exception):
    pass
class l1lll11(Exception):
    pass
class l1llll1ll(Exception):
    def __init__(self, message, l1lll11ll, url):
        super(l1llll1ll,self).__init__(message)
        self.l1lll11ll = l1lll11ll
        self.url = url
class l11111ll(Exception):
    pass
class l1111111(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l111111l(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l11l1111(Exception):
    pass