#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll11l1 = 7
def l1lll1l (l1l11ll):
    global l1ll
    l1111l1 = ord (l1l11ll [-1])
    l1llll1l = l1l11ll [:-1]
    l11l11 = l1111l1 % len (l1llll1l)
    l1l1lll = l1llll1l [:l11l11] + l1llll1l [l11l11:]
    if l1ll1ll1:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    return eval (l1ll1l1)
import logging
import os
import re
from l11l111 import l11111ll
logger = logging.getLogger(l1lll1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1l11l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll1():
    try:
        out = os.popen(l1lll1l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll1l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll1l (u"ࠤࠥॸ").join(result)
                logger.info(l1lll1l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll1l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll1l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll1l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111ll(l1lll1l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll1l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1l11l1(l1lll1l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))