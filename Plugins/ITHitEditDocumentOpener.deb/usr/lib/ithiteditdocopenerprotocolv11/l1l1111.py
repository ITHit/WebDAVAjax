#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l11 = 2048
l11111 = 7
def l1l1l1 (l111):
    global l1l1
    l1llll1 = ord (l111 [-1])
    l1ll11l = l111 [:-1]
    l1lll111 = l1llll1 % len (l1ll11l)
    l1lll = l1ll11l [:l1lll111] + l1ll11l [l1lll111:]
    if l1lllll:
        l1l111 = l111lll () .join ([unichr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    return eval (l1l111)
import hashlib
import os
import l1ll1l1
from l11l1l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll1l1 import l1l111l
from l1llll11 import l1l, l1lll1ll
import logging
logger = logging.getLogger(l1l1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l1():
    def __init__(self, l11l11l,l1l1l1l, ll= None, l1ll1111=None):
        self.l1111l=False
        self.l111l11 = self._1l1ll1()
        self.l1l1l1l = l1l1l1l
        self.ll = ll
        self.l1ll = l11l11l
        if ll:
            self.l1ll1l = True
        else:
            self.l1ll1l = False
        self.l1ll1111 = l1ll1111
    def _1l1ll1(self):
        try:
            return l1ll1l1.l111111() is not None
        except:
            return False
    def open(self):
        l1l1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111l11:
            raise NotImplementedError(l1l1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1ll = self.l1ll
        if self.l1l1l1l.lower().startswith(self.l1ll.lower()):
            l1ll11 = re.compile(re.escape(self.l1ll), re.IGNORECASE)
            l1l1l1l = l1ll11.sub(l1l1l1 (u"ࠨࠩࠄ"), self.l1l1l1l)
            l1l1l1l = l1l1l1l.replace(l1l1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll1l(self.l1ll, l1ll1ll, l1l1l1l, self.ll)
    def l11ll1l(self,l1ll, l1ll1ll, l1l1l1l, ll):
        l1l1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1111ll = l1ll1lll(l1ll)
        l1l1lll = self.l11ll1(l1111ll)
        logger.info(l1l1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1111ll)
        if l1l1lll:
            logger.info(l1l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l111l(l1111ll)
            l1111ll = l1l1ll(l1ll, l1ll1ll, ll, self.l1ll1111)
        logger.debug(l1l1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111ll1=l1111ll + l1l1l1 (u"ࠤ࠲ࠦࠌ") + l1l1l1l
        l11llll = l1l1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111ll1+ l1l1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11llll)
        l1lll1l = os.system(l11llll)
        if (l1lll1l != 0):
            raise IOError(l1l1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111ll1, l1lll1l))
    def l11ll1(self, l1111ll):
        if os.path.exists(l1111ll):
            if os.path.islink(l1111ll):
                l1111ll = os.readlink(l1111ll)
            if os.path.ismount(l1111ll):
                return True
        return False
def l1ll1lll(l1ll):
    l1l11l = l1ll.replace(l1l1l1 (u"࠭࡜࡝ࠩࠐ"), l1l1l1 (u"ࠧࡠࠩࠑ")).replace(l1l1l1 (u"ࠨ࠱ࠪࠒ"), l1l1l1 (u"ࠩࡢࠫࠓ"))
    l11l1ll = l1l1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l1l1=os.environ[l1l1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll111l=os.path.join(l11l1l1,l11l1ll, l1l11l)
    l1llll=os.path.abspath(l1ll111l)
    return l1llll
def l1ll1ll1(l11l111):
    if not os.path.exists(l11l111):
        os.makedirs(l11l111)
def l1l11(l1ll, l1ll1ll, l1lll11=None, password=None):
    l1l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l111 = l1ll1lll(l1ll)
    l1ll1ll1(l11l111)
    if not l1lll11:
        l1ll11ll = l1lll1()
        l11ll =l1ll11ll.l1111l1(l1l1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1ll + l1l1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1ll + l1l1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11ll, str):
            l1lll11, password = l11ll
        else:
            raise l1lll1ll()
        logger.info(l1l1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l111))
    l1ll1l1l = pwd.getpwuid( os.getuid())[0]
    l1ll111=os.environ[l1l1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1={l1l1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1l1l, l1l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll, l1l1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l111, l1l1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll111, l1l1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll11, l1l1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1, temp_file)
        if not os.path.exists(os.path.join(l1llll1l, l1l1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1llllll=l1l1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1l1l1 (u"ࠧࠨࠤ")
        else:
            l1llllll=l1l1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11111l=l1l1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1llllll,temp_file.name)
        l11l=[l1l1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll1l, l11111l)]
        p = subprocess.Popen(l11l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l111
    logger.debug(l1l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llll=os.path.abspath(l11l111)
    logger.debug(l1l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llll)
    return l1llll
def l1l1ll(l1ll, l1ll1ll, ll, l1ll1111):
    l1l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l111l1(title):
        l1l11l1=30
        if len(title)>l1l11l1:
            l11ll11=title.split(l1l1l1 (u"ࠨ࠯ࠣ࠳"))
            l1lll1l1=l1l1l1 (u"ࠧࠨ࠴")
            for block in l11ll11:
                l1lll1l1+=block+l1l1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l1lll1l1) > l1l11l1:
                    l1lll1l1+=l1l1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll1l1
        return title
    def l11lll1(l111l, password):
        l1l1l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l1l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l1l1 (u"ࠧࠦࠢ࠹").join(l111l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11lll = l1l1l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11lll.encode())
        l1l1l = [l1l1l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll1l11 = l1l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll1l11)
            for e in l1l1l:
                if e in l1ll1l11: return False
            raise l1l(l1ll1l11, l1l1ll=l1ll1l1.l111111(), l1ll1ll=l1ll1ll)
        logger.info(l1l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll11 = l1l1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l1l1 (u"ࠦࠧ࠿")
    os.system(l1l1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1 = l1ll1lll(l1ll)
    l11l111 = l1ll1lll(hashlib.sha1(l1ll.encode()).hexdigest()[:10])
    l1ll1ll1(l11l111)
    logger.info(l1l1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11l111))
    if ll:
        l111l = [l1l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll11, ll),
                    urllib.parse.unquote(l1ll1ll), os.path.abspath(l11l111)]
        l11lll1(l111l, password)
    else:
        while True:
            l1lll11, password = l111ll(l11l111, l1ll1ll, l1ll1111)
            if l1lll11.lower() != l1l1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l111l = [l1l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l1l1 (u"ࠤ࠰ࡸࠧࡋ"), l1l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l1l1 (u"ࠫ࠲ࡵࠧࡍ"), l1l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll11,
                            urllib.parse.unquote(l1ll1ll), os.path.abspath(l11l111)]
            else:
                raise l1lll1ll()
            if l11lll1(l111l, password): break
    os.system(l1l1l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11l111, l1ll1))
    l1llll=os.path.abspath(l1ll1)
    return l1llll
def l111ll(l1ll, l1ll1ll, l1ll1111):
    l1111 = os.path.join(os.environ[l1l1l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1111)):
       os.makedirs(os.path.dirname(l1111))
    l111l1l = l1ll1111.get_value(l1l1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l1l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll11ll = l1lll1(l1ll, l111l1l)
    l1lll11, password = l1ll11ll.l1111l1(l1l1l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1ll + l1l1l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1ll + l1l1l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll11 != l1l1l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11l11(l1ll, l1lll11):
        l1l11ll = l1l1l1 (u"ࠤ࡙ࠣࠦ").join([l1ll, l1lll11, l1l1l1 (u"࡚ࠪࠦࠬ") + password + l1l1l1 (u"࡛ࠫࠧ࠭"), l1l1l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1111, l1l1l1 (u"࠭ࡷࠬࠩ࡝")) as l1l1l11:
            l1l1l11.write(l1l11ll)
        os.chmod(l1111, 0o600)
    return l1lll11, password
def l11l11(l1ll, l1lll11):
    l1111 = l1lllll1 = os.path.join(os.environ[l1l1l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1111):
        with open(l1111, l1l1l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lll11l = data[0].split(l1l1l1 (u"ࠦࠥࠨࡢ"))
            if l1ll == l1lll11l[0] and l1lll11 == l1lll11l[1]:
                return True
    return False