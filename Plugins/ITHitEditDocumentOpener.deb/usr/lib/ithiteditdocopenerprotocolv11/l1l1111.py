#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll11l1 = 7
def l1lll1l (l1l11ll):
    global l1ll
    l1111l1 = ord (l1l11ll [-1])
    l1llll1l = l1l11ll [:-1]
    l11l11 = l1111l1 % len (l1llll1l)
    l1l1lll = l1llll1l [:l11l11] + l1llll1l [l11l11:]
    if l1ll1ll1:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    return eval (l1ll1l1)
import gi
gi.require_version(l1lll1l (u"ࠨࡉࡷ࡯ࠬঽ"), l1lll1l (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11ll111
import logging
logger = logging.getLogger(l1lll1l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1ll1ll(Gtk.Window):
    def __init__(self, l1l1l1111l, l1l1llllll):
        Gtk.Window.__init__(self)
        self.l111l11=30
        self.l1l11ll1ll = False
        self.service = l1l1l1111l
        self.l1111=l1l1llllll
        self.l11ll11=l11ll111.l1l1l111
        self.l1ll1ll11l = Gtk.ListStore(str)
        self.l1ll11l1l1()
    def l1l1l1llll(self, service):
        l1l1llll11 = self.l11ll11.l1l1ll11(l1lll1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1llll11
    def l1ll11l1l1(self, l1l1l1111l=None):
        if l1l1l1111l:
            self.l1ll1ll11l.clear()
            l1l1ll1lll=self.l1l1l1llll(l1l1l1111l)
            self.l1ll1ll11l.append([l1lll1l (u"ࠧࠨু")])
            for l1111 in l1l1ll1lll:
                self.l1ll1ll11l.append([l1111])
        else:
            self.l1ll1ll11l.clear()
            self.l1ll1ll11l.append([l1lll1l (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l11ll1l1(self, widget, data=None):
        l1ll1ll1l1= widget.get_active()
        if data == l1lll1l (u"ࠢ࠲ࠤৃ") and l1ll1ll1l1:
            self.l1ll11l1l1()
            self.l1l1ll11l1.set_active(0)
            self.l1ll11111l.set_text(l1lll1l (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll11111l.set_sensitive(False)
            self.l1l1ll11l1.set_sensitive(False)
        else:
            self.l1ll11l1l1(l1l1l1111l=self.service)
            self.l1l1ll11l1.set_active(0)
            self.l1ll11111l.set_text(l1lll1l (u"ࠤࠥ৅"))
            self.l1l1ll11l1.set_sensitive(True)
            self.l1ll11111l.set_sensitive(True)
    def l1l1l1l1l1(self, widget):
        if widget.get_active():
            l1111 = widget.get_child().get_text()
        else:
            l1111 = self.l1ll1ll11l[widget.get_active()][0]
        password = self.l1l1l11lll(self.service, l1111)
        if password:
            self.l1ll11111l.set_text(password)
        else:
            self.l1ll11111l.set_text(l1lll1l (u"ࠥࠦ৆"))
    def l1l11lllll(self, l1111, pwd, service):
        keyring.set_password(service, l1111, pwd)
        l1l1llll11=self.l11ll11.l1l1ll11(l1lll1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1111 in l1l1llll11:
            value = self.l11ll11.get_value(l1lll1l (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l11ll11.l1l11111(l1lll1l (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1lll1l (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1111))
    def l1l1l11lll(self, service, l1111):
        l1ll11ll1l = keyring.get_password(service, l1111)
        return l1ll11ll1l
    def l1l11l11ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1l1ll1(self, widget, data=None):
        self.l1l11ll1ll=widget.get_active()
    def l1ll11(self, message, title=l1lll1l (u"ࠨࠩো"), l1l11l11l=True):
        if l1l11l11l:
            l1l1l1ll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1llll1 = Gtk.MessageDialog(self,
            l1l1l1ll11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1llll1.set_title(title)
        l1ll1llll1.set_default_response(Gtk.ResponseType.OK)
        l1l1lll11l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l11ll11l = Gtk.VBox()
        l1l1l11ll1 = Gtk.Box(spacing=1)
        l1l1l11ll1.set_homogeneous(False)
        l1l1l1l1ll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l1ll.set_homogeneous(False)
        l1l1ll1l11 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1ll1l11.set_homogeneous(False)
        l1l1l11ll1.pack_start(l1l1l1l1ll, True, True, 0)
        l1l1l11ll1.pack_start(l1l1ll1l11, True, True, 0)
        l1ll1l11l1 = l1ll1llll1.get_content_area()
        l1ll1l1111 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll1l11l1.pack_start(l1ll1l1111, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1ll111 = Gtk.Label()
        l1ll1lll11 = Gtk.Label()
        l1ll1lll11.set_text(l1lll1l (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1ll1lll11, True, True, 0)
        l1ll1ll111.set_text(l1lll1l (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll1ll111.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1ll111, 0, 1, 0, 1)
        l1ll1111ll = Gtk.RadioButton.new_with_label_from_widget(None, l1lll1l (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll1111ll.connect(l1lll1l (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l11ll1l1, l1lll1l (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll1111ll, 1, 2, 0, 1)
        l1l11llll1 = Gtk.RadioButton.new_with_label_from_widget(l1ll1111ll, l1lll1l (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l11llll1.connect(l1lll1l (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l11ll1l1, l1lll1l (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l11llll1, 1, 2, 1, 2)
        l1ll11l111 = Gtk.Label()
        l1ll11l111.set_text(l1lll1l (u"ࠥࠤࠧ৔"))
        table.attach(l1ll11l111, 0, 1, 4, 6)
        l1l1lll1l1 = Gtk.Label()
        l1l1lll1l1.set_text(l1lll1l (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1lll1l1.set_justify(Gtk.Justification.RIGHT)
        l1l1lll1l1.set_alignment(xalign=1, yalign=0.5)
        self.l1l1ll11l1 = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1ll11l)
        self.l1l1ll11l1.set_entry_text_column(0)
        table.attach(l1l1lll1l1, 0, 1, 6, 8)
        table.attach(self.l1l1ll11l1, 1, 3, 6, 8)
        self.l1l1ll11l1.connect(l1lll1l (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1l1l1l1)
        l1ll111l1l = Gtk.Label()
        l1ll111l1l.set_text(l1lll1l (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll111l1l.set_justify(Gtk.Justification.RIGHT)
        l1ll111l1l.set_alignment(xalign=1, yalign=0.5)
        self.l1ll11111l = Gtk.Entry()
        self.l1ll11111l.set_visibility(False)
        self.l1ll11111l.connect(l1lll1l (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l11l11ll, l1ll1llll1)
        table.attach(l1ll111l1l, 0, 1, 8, 10)
        table.attach(self.l1ll11111l, 1, 3, 8, 10)
        l1l11l1lll = Gtk.CheckButton(l1lll1l (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l11l1lll.connect(l1lll1l (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll1l1ll1, l1l11l1lll)
        l1l11l1lll.set_active(False)
        table.attach(l1l11l1lll, 1, 3, 12, 14)
        l1l11lll1l = Gtk.Label()
        l1l11lll1l.set_text(l1lll1l (u"ࠥࠤࠧ৛") * 5)
        l1l11ll11l.pack_start(l1l11lll1l, True, True, 0)
        if self.l1111:
            l1l11llll1.set_active(True)
            self.l1l1ll11l1.set_active(0)
            self.l1l1ll11l1.set_sensitive(True)
            self.l1ll11111l.set_text(l1lll1l (u"ࠦࠧড়"))
            self.l1ll11111l.set_sensitive(True)
        else:
            self.l1l1ll11l1.set_active(0)
            self.l1l1ll11l1.set_sensitive(False)
            self.l1ll11111l.set_text(l1lll1l (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll11111l.set_sensitive(False)
        l1l1lll11l.pack_start(vbox, True, True, 0)
        l1l1lll11l.pack_start(table, True, True, 0)
        l1l1lll11l.pack_end(l1l11ll11l, True, True, 0)
        l1ll1l1111.pack_start(l1l1lll11l, True, True, 0)
        l1ll1llll1.show_all()
        response = l1ll1llll1.run()
        if self.l1l1ll11l1.get_active():
            l1111 = self.l1l1ll11l1.get_child().get_text()
        else:
            l1111 = self.l1ll1ll11l[self.l1l1ll11l1.get_active()][0]
        pwd = self.l1ll11111l.get_text()
        l1ll1llll1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l11ll1ll:
                self.l1l11lllll(l1111, pwd, self.service)
            return l1111, pwd
        else:
            return l1lll1l (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1lll1l (u"ࠧࠨয়")
class l1l1l1lll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l11l1l11(self, l1l11l11):
        l1l1lllll1 = Gtk.ScrolledWindow()
        l1l1lllll1.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11llll=None
        self.l1ll11l11l = Gtk.TextBuffer()
        self.l1ll11l11l.set_text(l1l11l11)
        self.set_style()
        regexp= l1lll1l (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l11l1l1l = self._1ll1l1l1l(l1l11l11, regexp)
        self.l1l1l11111(l1l11l1l1l, self.l1ll11l11l.get_start_iter())
        self.l1l11l1ll1 = Gtk.TextView(buffer=self.l1ll11l11l)
        self.l1l11l1ll1.set_property(l1lll1l (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l11l1ll1.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11l1ll1.connect(l1lll1l (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll111lll)
        self.l1l11l1ll1.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1lllll1.set_size_request(300,100)
        self.l1l11l1ll1.show()
        l1l1lllll1.add(self.l1l11l1ll1)
        l1l1lllll1.show()
        return l1l1lllll1
    def _1ll111lll(self, *args, **kwargs):
        l1ll1l111l, l1l1llll1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1l111l, l1l1llll1l).get_tags()
        if not self.l1ll11llll:
            self.l1ll11llll = args[1].window.get_cursor()
            self.l1l1l1l111 = Gdk.Cursor(Gdk.CursorType.l1l1ll1l1l)
        elif tag:
            args[1].window.set_cursor(self.l1l1l1l111)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11llll:
                args[1].window.set_cursor(self.l1ll11llll)
    def _1ll1l1l1l(self, l1l11l11, l1ll1lll1l):
        res=[]
        l1ll11ll11=re.findall(l1ll1lll1l,l1l11l11)
        for l1ll1l1lll in l1ll11ll11:
            for el in l1ll1l1lll:
                if el:
                    res.append(el)
        return res
    def l1l1l11111(self, l1l11l1l1l, start):
        l1ll11l1ll=0
        for text in l1l11l1l1l:
            end = self.l1ll11l11l.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll11l1ll+=1
                l1ll111ll1, l1l1l11l1l = match
                tag = self.l1ll11l11l.create_tag(str(l1ll11l1ll), foreground=l1lll1l (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1lll1l (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1l1lll1, text)
                self.l1ll11l11l.apply_tag(tag, l1ll111ll1, l1l1l11l1l)
                self.l1l1l11111(l1l11l1l1l, l1l1l11l1l)
    def _1l1l1lll1(self, tag, widget, l1l1l1l11l, _1l1ll1111, text):
        _1l1ll111l = l1l1l1l11l.type
        _1ll1l11ll = l1l1l1l11l.window
        if _1l1ll111l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1ll111l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1l1l11l.button
            self.l1ll11llll = Gdk.Cursor(Gdk.CursorType.l1l1ll1l1l)
            if _1l1ll111l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1lll1l (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l11ll1l11(self, message, title=l1lll1l (u"ࠧࠨ০"), l1l11l11l=True, l1l1l111ll=None):
        if l1l11l11l:
            l1l1l1ll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1l1ll11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1l111ll:
            l1ll1l11l1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1l11ll1 = Gtk.HBox(spacing=0)
            l1ll111111 = Gtk.HBox(spacing=5)
            l1ll1ll1ll = Gtk.Label()
            l1ll1ll1ll.set_markup(l1lll1l (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll1ll1ll.set_line_wrap(True)
            l1ll1ll1ll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1lll1l (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1l11l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11l11.show()
            l1l1ll11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11ll.show()
            l1l11ll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll111.show()
            l1l1l11ll1.pack_start(separator, True, True, 0)
            l1l1l11ll1.pack_start(l1l1l11l11, True, True, 0)
            l1l1l11ll1.pack_start(l1l1ll11ll, True, True, 0)
            l1l1l11ll1.pack_start(l1l11ll111, True, True, 0)
            l1l1l11ll1.pack_start(l1ll1ll1ll, False, True, 0)
            l1l1lll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll111.show()
            l1l1l11ll1.pack_end(l1l1lll111, True, True, 0)
            l1ll11lll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11lll1.show()
            vbox.pack_start(l1l1l11ll1, True, True, 0)
            l1l1lllll1=self.__1l11l1l11(l1l11l11=l1l1l111ll)
            vbox.pack_start(l1l1lllll1, False, False, 0)
            vbox.pack_end(l1ll11lll1, False, False, 0)
            l1ll111111.pack_start(vbox, True, True,5)
            l1ll111111.show()
            l1ll1l11l1.pack_end(l1ll111111, False, False, 0)
            vbox.show()
            l1l1l11ll1.show()
        window.run()
class l1l1ll111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11lll11(self, widget, l1ll1l1l11):
        if l1ll1l1l11 == Gtk.ResponseType.OK:
            self.result = l1lll1l (u"ࠥࡓࡐࠨ৩")
        elif l1ll1l1l11 == Gtk.ResponseType.CANCEL:
            self.result = l1lll1l (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll1l1l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1lll1l (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11l11111(self, title=l1lll1l (u"ࠨࠢ৬"), message=l1lll1l (u"ࠢࠣ৭") , l1l11l11l=True):
        if l1l11l11l:
            l1l1l1ll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l1ll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1lll1l (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l11lll11)
        window.run()
class l1l1l1ll1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1ll1ll1=None
        self.result = None
    def l1l11lll11(self, widget, l1ll1l1l11):
        print(widget, l1ll1l1l11)
        if l1ll1l1l11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll1l1l11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll1l1l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1l1ll1(self, widget, l1ll111l11):
        if l1ll111l11.get_active():
            self.l1l1ll1ll1 = 1
        else:
            self.l1l1ll1ll1 = 0
    def l1ll1111l1(self, title=l1lll1l (u"ࠤࠥ৯"), message=l1lll1l (u"ࠥࠦৰ"), l1l1lll1ll =l1lll1l (u"ࠦࠧৱ"),l1l11l11l=True):
        if l1l11l11l:
            l1l1l1ll11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1ll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l1ll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1lll1l (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l11lll11)
        l1l11l1lll = Gtk.CheckButton(l1l1lll1ll)
        l1l11l1lll.connect(l1lll1l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll1l1ll1, l1l11l1lll)
        l1l11l1lll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l11l1lll, expand=True, fill=True, padding=0)
        l1l11l1lll.show()
        window.run()
def l11l11ll1(title, msg, l1l1lll1ll=l1lll1l (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1l11l11l=True):
    result=None
    try:
        l1ll1lllll = l1l1l1ll1l()
        l1ll1lllll.l1ll1111l1(title, msg, l1l1lll1ll, l1l11l11l)
        result = {l1lll1l (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll1lllll.result,  l1lll1l (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll1lllll.l1l1ll1ll1}
    except Exception as e:
        logger.exception(l1lll1l (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1lll1l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1ll1lll1 = l1l1l1lll()
    message= l1lll1l (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1l111l1 = l1lll1l (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1ll1lll1.l11ll1l11(message, l1lll1l (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1l11l11l=True, l1l1l111ll=l1l1l111l1)