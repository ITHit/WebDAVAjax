#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import re
class l1l111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1l1l = kwargs.get(l1lll11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll1 = kwargs.get(l1lll11 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l111111l = self.l11111ll(args)
        if l111111l:
            args=args+ l111111l
        self.args = [a for a in args]
    def l11111ll(self, *args):
        l111111l=None
        l1l111l1 = args[0][0]
        if re.search(l1lll11 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l111l1):
            l111111l = (l1lll11 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1l1l
                            ,)
        return l111111l
class l1llll111(Exception):
    def __init__(self, *args, **kwargs):
        l111111l = self.l11111ll(args)
        if l111111l:
            args = args + l111111l
        self.args = [a for a in args]
    def l11111ll(self, *args):
        s = l1lll11 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll11 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll1l1(Exception):
    pass
class l1lll(Exception):
    pass
class l1lllll11(Exception):
    def __init__(self, message, l1lll1ll1, url):
        super(l1lllll11,self).__init__(message)
        self.l1lll1ll1 = l1lll1ll1
        self.url = url
class l11111l1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111111(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l111ll1l(Exception):
    pass