#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1111 = 7
def l1lll1ll (l1llll):
    global l1ll111l
    l1l1lll = ord (l1llll [-1])
    l11l1l = l1llll [:-1]
    l1ll1l1l = l1l1lll % len (l11l1l)
    l1l111l = l11l1l [:l1ll1l1l] + l11l1l [l1ll1l1l:]
    if l1ll1lll:
        l11ll11 = l1111 () .join ([unichr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1l1111 - (l1lll1 + l1l1lll) % l1ll1111) for l1lll1, char in enumerate (l1l111l)])
    return eval (l11ll11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11l1=logging.WARNING
logger = logging.getLogger(l1lll1ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll11l1)
l1l111l1 = SysLogHandler(address=l1lll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll1ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l111l1.setFormatter(formatter)
logger.addHandler(l1l111l1)
ch = logging.StreamHandler()
ch.setLevel(l1llll11l1)
logger.addHandler(ch)
class l1lllll1ll(io.FileIO):
    l1lll1ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll1ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11111, l1lll1ll1l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11111 = l1lll11111
            self.l1lll1ll1l = l1lll1ll1l
            if not options:
                options = l1lll1ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11111,
                                              self.l1lll1ll1l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llllll1l = os.path.join(os.path.sep, l1lll1ll (u"ࠪࡩࡹࡩࠧই"), l1lll1ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1l1 = path
        else:
            self._1lll1l1l1 = self.l1llllll1l
        super(l1lllll1ll, self).__init__(self._1lll1l1l1, l1lll1ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1l1ll(self, line):
        return l1lllll1ll.Entry(*[x for x in line.strip(l1lll1ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll1ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1ll (u"ࠤࠦࠦ঍")):
                    yield self._1lll1l1ll(line)
            except ValueError:
                pass
    def l1llll1l1l(self, attr, value):
        for entry in self.entries:
            l1lll1lll1 = getattr(entry, attr)
            if l1lll1lll1 == value:
                return entry
        return None
    def l1lll111ll(self, entry):
        if self.l1llll1l1l(l1lll1ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll1ll (u"ࠫࡡࡴࠧএ")).encode(l1lll1ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllll1l1(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1ll (u"ࠢࠤࠤ঒")):
                if self._1lll1l1ll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1ll (u"ࠨࠩও").join(lines).encode(l1lll1ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llllll11(cls, l1lll11111, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1llll1l1l(l1lll1ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11111)
        if entry:
            return l1llll1ll1.l1lllll1l1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11111, l1lll1ll1l, options=None, path=None):
        return cls(path=path).l1lll111ll(l1lllll1ll.Entry(device,
                                                    l1lll11111, l1lll1ll1l,
                                                    options=options))
class l1lll11l11(object):
    def __init__(self, l1lll11lll):
        self.l1lllllll1=l1lll1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1ll11=l1lll1ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll11lll=l1lll11lll
        self.l1lll1111l()
        self.l1llll111l()
        self.l1lllll111()
        self.l1lll1l111()
        self.l1llll1lll()
    def l1lll1111l(self):
        temp_file=open(l1llll11ll,l1lll1ll (u"࠭ࡲࠨঘ"))
        l1ll11=temp_file.read()
        data=json.loads(l1ll11)
        self.user=data[l1lll1ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l111=data[l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1lll1l1=data[l1lll1ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll11l1=data[l1lll1ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1l11l=data[l1lll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111l1=data[l1lll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lllll111(self):
        l1ll11l=os.path.join(l1lll1ll (u"ࠨ࠯ࠣট"),l1lll1ll (u"ࠢࡶࡵࡵࠦঠ"),l1lll1ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll1ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll1ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll11l)
    def l1llll1lll(self):
        logger.info(l1lll1ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1lll1l1=os.path.join(self.l1ll11l1,self.l1lllllll1)
        l1llll1111 = pwd.getpwnam(self.user).pw_uid
        l1llll1l11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1lll1l1):
            os.makedirs(l1lll1l1)
            os.system(l1lll1ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1lll1l1))
            logger.debug(l1lll1ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1lll1l1)
        else:
            logger.debug(l1lll1ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1lll1l1)
        l1ll11l=os.path.join(l1lll1l1, self.l1lll1ll11)
        print(l1ll11l)
        logger.debug(l1lll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll11l)
        with open(l1ll11l, l1lll1ll (u"ࠤࡺ࠯ࠧ঩")) as l1lll1llll:
            logger.debug(self.l11l111 + l1lll1ll (u"ࠪࠤࠬপ")+self.l1lll1l11l+l1lll1ll (u"ࠫࠥࠨࠧফ")+self.l1lll111l1+l1lll1ll (u"ࠬࠨࠧব"))
            l1lll1llll.writelines(self.l11l111 + l1lll1ll (u"࠭ࠠࠨভ")+self.l1lll1l11l+l1lll1ll (u"ࠧࠡࠤࠪম")+self.l1lll111l1+l1lll1ll (u"ࠨࠤࠪয"))
        os.chmod(l1ll11l, 0o600)
        os.chown(l1ll11l, l1llll1111, l1llll1l11)
    def l1llll111l(self, l1lll11l1l=l1lll1ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll1ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11l1l in groups:
            logger.info(l1lll1ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11l1l))
        else:
            logger.warning(l1lll1ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11l1l))
            l1l1ll=l1lll1ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11l1l,self.user)
            logger.debug(l1lll1ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l1ll)
            os.system(l1l1ll)
            logger.debug(l1lll1ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l111(self):
        logger.debug(l1lll1ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1ll1=l1lllll1ll()
        l1llll1ll1.add(self.l11l111, self.l1lll1l1, l1lll1ll1l=l1lll1ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll1ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll1ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll11ll = urllib.parse.unquote(sys.argv[1])
        if l1llll11ll:
            l1lll11ll1=l1lll11l11(l1llll11ll)
        else:
            raise (l1lll1ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll1ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise