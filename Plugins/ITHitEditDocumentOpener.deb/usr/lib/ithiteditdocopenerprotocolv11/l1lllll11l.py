#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1l1l1l = 2048
l111l = 7
def l1111 (l1ll1l11):
    global l11l111
    l1lll11l = ord (l1ll1l11 [-1])
    l1l11ll = l1ll1l11 [:-1]
    l111lll = l1lll11l % len (l1l11ll)
    l1l111l = l1l11ll [:l111lll] + l1l11ll [l111lll:]
    if l11ll1:
        l11l1ll = l1l111 () .join ([unichr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    return eval (l11l1ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l1ll=logging.WARNING
logger = logging.getLogger(l1111 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l1ll)
l11llll1 = SysLogHandler(address=l1111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1111 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11llll1.setFormatter(formatter)
logger.addHandler(l11llll1)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l1ll)
logger.addHandler(ch)
class l1llll1lll(io.FileIO):
    l1111 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1111 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll11ll, l1lll1l11l,
                     options, d=0, p=0):
            self.device = device
            self.l1llll11ll = l1llll11ll
            self.l1lll1l11l = l1lll1l11l
            if not options:
                options = l1111 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1111 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll11ll,
                                              self.l1lll1l11l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll111l = os.path.join(os.path.sep, l1111 (u"ࠪࡩࡹࡩࠧই"), l1111 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llll1l1l = path
        else:
            self._1llll1l1l = self.l1llll111l
        super(l1llll1lll, self).__init__(self._1llll1l1l, l1111 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11l11(self, line):
        return l1llll1lll.Entry(*[x for x in line.strip(l1111 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1111 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1111 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1111 (u"ࠤࠦࠦ঍")):
                    yield self._1lll11l11(line)
            except ValueError:
                pass
    def l1lll111l1(self, attr, value):
        for entry in self.entries:
            l1lllll111 = getattr(entry, attr)
            if l1lllll111 == value:
                return entry
        return None
    def l1lll1l1l1(self, entry):
        if self.l1lll111l1(l1111 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1111 (u"ࠫࡡࡴࠧএ")).encode(l1111 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1l11(self, entry):
        self.seek(0)
        lines = [l.decode(l1111 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1111 (u"ࠢࠤࠤ঒")):
                if self._1lll11l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1111 (u"ࠨࠩও").join(lines).encode(l1111 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llllll11(cls, l1llll11ll, path=None):
        l1lll111ll = cls(path=path)
        entry = l1lll111ll.l1lll111l1(l1111 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll11ll)
        if entry:
            return l1lll111ll.l1llll1l11(entry)
        return False
    @classmethod
    def add(cls, device, l1llll11ll, l1lll1l11l, options=None, path=None):
        return cls(path=path).l1lll1l1l1(l1llll1lll.Entry(device,
                                                    l1llll11ll, l1lll1l11l,
                                                    options=options))
class l1lllllll1(object):
    def __init__(self, l1lll1ll11):
        self.l1lllll1l1=l1111 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll1ll1=l1111 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1ll11=l1lll1ll11
        self.l1lll1111l()
        self.l1lllll1ll()
        self.l1lll1llll()
        self.l1lll1l111()
        self.l1lll1ll1l()
    def l1lll1111l(self):
        temp_file=open(l1llll11l1,l1111 (u"࠭ࡲࠨঘ"))
        l1llll=temp_file.read()
        data=json.loads(l1llll)
        self.user=data[l1111 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l111l1=data[l1111 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l1=data[l1111 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll11l=data[l1111 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1lll1=data[l1111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1111=data[l1111 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1llll(self):
        l1l1lll=os.path.join(l1111 (u"ࠨ࠯ࠣট"),l1111 (u"ࠢࡶࡵࡵࠦঠ"),l1111 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1111 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1111 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l1lll)
    def l1lll1ll1l(self):
        logger.info(l1111 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l1=os.path.join(self.l1ll11l,self.l1lllll1l1)
        l1lll11ll1 = pwd.getpwnam(self.user).pw_uid
        l1lll11lll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l1):
            os.makedirs(l1l1)
            os.system(l1111 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l1))
            logger.debug(l1111 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l1)
        else:
            logger.debug(l1111 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l1)
        l1l1lll=os.path.join(l1l1, self.l1llll1ll1)
        print(l1l1lll)
        logger.debug(l1111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l1lll)
        with open(l1l1lll, l1111 (u"ࠤࡺ࠯ࠧ঩")) as l1lll11111:
            logger.debug(self.l111l1 + l1111 (u"ࠪࠤࠬপ")+self.l1lll1lll1+l1111 (u"ࠫࠥࠨࠧফ")+self.l1llll1111+l1111 (u"ࠬࠨࠧব"))
            l1lll11111.writelines(self.l111l1 + l1111 (u"࠭ࠠࠨভ")+self.l1lll1lll1+l1111 (u"ࠧࠡࠤࠪম")+self.l1llll1111+l1111 (u"ࠨࠤࠪয"))
        os.chmod(l1l1lll, 0o600)
        os.chown(l1l1lll, l1lll11ll1, l1lll11lll)
    def l1lllll1ll(self, l1llllll1l=l1111 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1111 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll1l in groups:
            logger.info(l1111 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llllll1l))
        else:
            logger.warning(l1111 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llllll1l))
            l1ll1l=l1111 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llllll1l,self.user)
            logger.debug(l1111 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll1l)
            os.system(l1ll1l)
            logger.debug(l1111 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l111(self):
        logger.debug(l1111 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll111ll=l1llll1lll()
        l1lll111ll.add(self.l111l1, self.l1l1, l1lll1l11l=l1111 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1111 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1111 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll11l1 = urllib.parse.unquote(sys.argv[1])
        if l1llll11l1:
            l1lll11l1l=l1lllllll1(l1llll11l1)
        else:
            raise (l1111 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1111 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise