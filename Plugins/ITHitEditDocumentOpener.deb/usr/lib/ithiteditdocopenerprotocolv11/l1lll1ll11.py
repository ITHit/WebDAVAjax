#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l11ll = 2048
l1ll1l11 = 7
def l1l111 (l111l11):
    global l1l1l1
    l111ll1 = ord (l111l11 [-1])
    l111l1l = l111l11 [:-1]
    l1ll11l = l111ll1 % len (l111l1l)
    l1l1l1l = l111l1l [:l1ll11l] + l111l1l [l1ll11l:]
    if l1lll111:
        l1l1l11 = l1l11 () .join ([unichr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    else:
        l1l1l11 = str () .join ([chr (ord (char) - l1l11ll - (l11ll1l + l111ll1) % l1ll1l11) for l11ll1l, char in enumerate (l1l1l1l)])
    return eval (l1l1l11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11ll=logging.WARNING
logger = logging.getLogger(l1l111 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll11ll)
l1l1ll1l = SysLogHandler(address=l1l111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l111 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l1l1ll1l)
ch = logging.StreamHandler()
ch.setLevel(l1llll11ll)
logger.addHandler(ch)
class l1lll1llll(io.FileIO):
    l1l111 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l111 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1ll1l, l1llll1111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll1l = l1lll1ll1l
            self.l1llll1111 = l1llll1111
            if not options:
                options = l1l111 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l111 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1ll1l,
                                              self.l1llll1111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11l1l = os.path.join(os.path.sep, l1l111 (u"ࠪࡩࡹࡩࠧই"), l1l111 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llllll11 = path
        else:
            self._1llllll11 = self.l1lll11l1l
        super(l1lll1llll, self).__init__(self._1llllll11, l1l111 (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l11(self, line):
        return l1lll1llll.Entry(*[x for x in line.strip(l1l111 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l111 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l111 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l111 (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l11(line)
            except ValueError:
                pass
    def l1lllll1ll(self, attr, value):
        for entry in self.entries:
            l1llll111l = getattr(entry, attr)
            if l1llll111l == value:
                return entry
        return None
    def l1lllll111(self, entry):
        if self.l1lllll1ll(l1l111 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l111 (u"ࠫࡡࡴࠧএ")).encode(l1l111 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1lll(self, entry):
        self.seek(0)
        lines = [l.decode(l1l111 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l111 (u"ࠢࠤࠤ঒")):
                if self._1llll1l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l111 (u"ࠨࠩও").join(lines).encode(l1l111 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll11l11(cls, l1lll1ll1l, path=None):
        l1llllll1l = cls(path=path)
        entry = l1llllll1l.l1lllll1ll(l1l111 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1ll1l)
        if entry:
            return l1llllll1l.l1llll1lll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll1l, l1llll1111, options=None, path=None):
        return cls(path=path).l1lllll111(l1lll1llll.Entry(device,
                                                    l1lll1ll1l, l1llll1111,
                                                    options=options))
class l1lll1lll1(object):
    def __init__(self, l1lll1l111):
        self.l1lll11ll1=l1l111 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll111ll=l1l111 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1l111=l1lll1l111
        self.l1llll11l1()
        self.l1lllllll1()
        self.l1llll1ll1()
        self.l1llll1l1l()
        self.l1lll1l1l1()
    def l1llll11l1(self):
        temp_file=open(l1lllll11l,l1l111 (u"࠭ࡲࠨঘ"))
        l1lll=temp_file.read()
        data=json.loads(l1lll)
        self.user=data[l1l111 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l111ll=data[l1l111 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l1111=data[l1l111 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1llll=data[l1l111 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11111=data[l1l111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllll1l1=data[l1l111 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1ll1(self):
        l1ll1l1=os.path.join(l1l111 (u"ࠨ࠯ࠣট"),l1l111 (u"ࠢࡶࡵࡵࠦঠ"),l1l111 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l111 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l111 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll1l1)
    def l1lll1l1l1(self):
        logger.info(l1l111 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l1111=os.path.join(self.l1llll,self.l1lll11ll1)
        l1lll1111l = pwd.getpwnam(self.user).pw_uid
        l1lll111l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l1111):
            os.makedirs(l1l1111)
            os.system(l1l111 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l1111))
            logger.debug(l1l111 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l1111)
        else:
            logger.debug(l1l111 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l1111)
        l1ll1l1=os.path.join(l1l1111, self.l1lll111ll)
        print(l1ll1l1)
        logger.debug(l1l111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll1l1)
        with open(l1ll1l1, l1l111 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l1ll:
            logger.debug(self.l111ll + l1l111 (u"ࠪࠤࠬপ")+self.l1lll11111+l1l111 (u"ࠫࠥࠨࠧফ")+self.l1lllll1l1+l1l111 (u"ࠬࠨࠧব"))
            l1lll1l1ll.writelines(self.l111ll + l1l111 (u"࠭ࠠࠨভ")+self.l1lll11111+l1l111 (u"ࠧࠡࠤࠪম")+self.l1lllll1l1+l1l111 (u"ࠨࠤࠪয"))
        os.chmod(l1ll1l1, 0o600)
        os.chown(l1ll1l1, l1lll1111l, l1lll111l1)
    def l1lllllll1(self, l1lll11lll=l1l111 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l111 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11lll in groups:
            logger.info(l1l111 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11lll))
        else:
            logger.warning(l1l111 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11lll))
            l1ll=l1l111 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11lll,self.user)
            logger.debug(l1l111 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll)
            os.system(l1ll)
            logger.debug(l1l111 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll1l1l(self):
        logger.debug(l1l111 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llllll1l=l1lll1llll()
        l1llllll1l.add(self.l111ll, self.l1l1111, l1llll1111=l1l111 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l111 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l111 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll11l = urllib.parse.unquote(sys.argv[1])
        if l1lllll11l:
            l1lll1l11l=l1lll1lll1(l1lllll11l)
        else:
            raise (l1l111 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l111 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise