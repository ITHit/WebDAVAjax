#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1llll1l = 7
def l1lllll1 (l11ll1l):
    global l1l1ll
    l1ll1 = ord (l11ll1l [-1])
    l1l11ll = l11ll1l [:-1]
    l111111 = l1ll1 % len (l1l11ll)
    l1ll11l1 = l1l11ll [:l111111] + l1l11ll [l111111:]
    if l11ll1:
        l1lllll = l11l111 () .join ([unichr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    else:
        l1lllll = str () .join ([chr (ord (char) - l11l1 - (l1llll + l1ll1) % l1llll1l) for l1llll, char in enumerate (l1ll11l1)])
    return eval (l1lllll)
import logging
import os
import re
from l1ll11l import l11111ll
logger = logging.getLogger(l1lllll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lllll1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l11l():
    try:
        out = os.popen(l1lllll1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lllll1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lllll1 (u"ࠤࠥॸ").join(result)
                logger.info(l1lllll1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lllll1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lllll1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lllll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111ll(l1lllll1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lllll1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l11(l1lllll1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))