#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1l1l1l = 2048
l111l = 7
def l1111 (l1ll1l11):
    global l11l111
    l1lll11l = ord (l1ll1l11 [-1])
    l1l11ll = l1ll1l11 [:-1]
    l111lll = l1lll11l % len (l1l11ll)
    l1l111l = l1l11ll [:l111lll] + l1l11ll [l111lll:]
    if l11ll1:
        l11l1ll = l1l111 () .join ([unichr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    return eval (l11l1ll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll11 import l1llll1
from configobj import ConfigObj
l11l1lll = l1111 (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1l1ll = l1111 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠸࠸࠵࠲࠵ࠨࡤ")
l1l1ll1l = l1111 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1111 (u"ࠣ࠸࠱࠴࠳࠾࠷࠷࠴࠱࠴ࠧࡦ")
l11ll111=os.path.join(os.environ.get(l1111 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1111 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1ll1l.replace(l1111 (u"ࠦࠥࠨࡩ"), l1111 (u"ࠧࡥࠢࡪ")).lower())
l11ll1ll=os.environ.get(l1111 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l11lll=l1l1l1ll.replace(l1111 (u"ࠣࠢࠥ࡭"), l1111 (u"ࠤࡢࠦ࡮"))+l1111 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1l1l1=os.path.join(os.environ.get(l1111 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l11lll)
elif platform.system() == l1111 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11lll1l=l1llll1(l11ll111+l1111 (u"ࠢ࠰ࠤࡳ"))
    l1l1l1l1 = os.path.join(l11lll1l, l1l11lll)
else:
    l1l1l1l1 = os.path.join( l1l11lll)
l11ll1ll=l11ll1ll.upper()
if l11ll1ll == l1111 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l111ll=logging.DEBUG
elif l11ll1ll == l1111 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l111ll = logging.INFO
elif l11ll1ll == l1111 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l111ll = logging.WARNING
elif l11ll1ll == l1111 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l111ll = logging.ERROR
elif l11ll1ll == l1111 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l111ll = logging.CRITICAL
elif l11ll1ll == l1111 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l111ll = logging.NOTSET
logger = logging.getLogger(l1111 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l111ll)
l1l11ll1 = logging.FileHandler(l1l1l1l1, mode=l1111 (u"ࠣࡹ࠮ࠦࡻ"))
l1l11ll1.setLevel(l1l111ll)
formatter = logging.Formatter(l1111 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1111 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11ll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l111ll)
l11llll1 = SysLogHandler(address=l1111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11llll1.setFormatter(formatter)
logger.addHandler(l1l11ll1)
logger.addHandler(ch)
logger.addHandler(l11llll1)
class Settings():
    l11lllll = l1111 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11111 = l1111 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l111 = l1111 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l1ll):
        self.l1l1lll1 = self._1l1ll11(l1l1l1ll)
        self._11ll1l1()
    def _1l1ll11(self, l1l1l1ll):
        l1l111l1 = l1l1l1ll.split(l1111 (u"ࠣࠢࠥࢂ"))
        l1l111l1 = l1111 (u"ࠤࠣࠦࢃ").join(l1l111l1)
        if platform.system() == l1111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1lll1 = os.path.join(l11ll111, l1111 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l111l1 + l1111 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1lll1
    def l1l11l11(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1111 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1111 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll1l1(self):
        if not os.path.exists(os.path.dirname(self.l1l1lll1)):
            os.makedirs(os.path.dirname(self.l1l1lll1))
        if not os.path.exists(self.l1l1lll1):
            self.config = ConfigObj(self.l1l1lll1)
            self.config[l1111 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1111 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1111 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l111
            self.config[l1111 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11111
            self.config[l1111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11lllll
            self.config[l1111 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1lll1)
            self.l1l1l111 = self.get_value(l1111 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1111 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11111 = self.get_value(l1111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11lllll = self.get_value(l1111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lll11(self):
        l1l1111l = l1111 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11lllll
        l1l1111l += l1111 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11111
        l1l1111l += l1111 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l111
        return l1l1111l
    def __unicode__(self):
        return self._11lll11()
    def __str__(self):
        return self._11lll11()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l1l1l1ll)