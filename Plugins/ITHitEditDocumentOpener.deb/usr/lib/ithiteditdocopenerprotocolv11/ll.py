#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111111 = sys.version_info [0] == 2
l111 = 2048
l1ll11 = 7
def l1ll1l1 (l1111ll):
    global l1ll1l11
    l1l1ll = ord (l1111ll [-1])
    l1111 = l1111ll [:-1]
    l11l1 = l1l1ll % len (l1111)
    l111lll = l1111 [:l11l1] + l1111 [l11l1:]
    if l111111:
        l111l1 = l11lll () .join ([unichr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l111 - (l111l1l + l1l1ll) % l1ll11) for l111l1l, char in enumerate (l111lll)])
    return eval (l111l1)
import logging
import os
import re
from l111ll import l1llll11l
logger = logging.getLogger(l1ll1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11ll1l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l111():
    try:
        out = os.popen(l1ll1l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1l1 (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll11l(l1ll1l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11ll1l(l1ll1l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))