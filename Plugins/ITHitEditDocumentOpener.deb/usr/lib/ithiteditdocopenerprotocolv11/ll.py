#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll11l1 = 7
def l1lll1l (l1l11ll):
    global l1ll
    l1111l1 = ord (l1l11ll [-1])
    l1llll1l = l1l11ll [:-1]
    l11l11 = l1111l1 % len (l1llll1l)
    l1l1lll = l1llll1l [:l11l11] + l1llll1l [l11l11:]
    if l1ll1ll1:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l11 - (l11l1l1 + l1111l1) % l1ll11l1) for l11l1l1, char in enumerate (l1l1lll)])
    return eval (l1ll1l1)
import hashlib
import os
import l111ll
from l1l1111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111ll import l1l11l1
from l11l111 import l1llllll, l1l111l
import logging
logger = logging.getLogger(l1lll1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1llll1():
    def __init__(self, l111l,l111111, l1ll1= None, l11ll11=None):
        self.l1lll1=False
        self.l1l11l = self._1l1l1()
        self.l111111 = l111111
        self.l1ll1 = l1ll1
        self.l11l11l = l111l
        if l1ll1:
            self.l11l = True
        else:
            self.l11l = False
        self.l11ll11 = l11ll11
    def _1l1l1(self):
        try:
            return l111ll.l11ll1() is not None
        except:
            return False
    def open(self):
        l1lll1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l11l:
            raise NotImplementedError(l1lll1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll11l = self.l11l11l
        if self.l111111.lower().startswith(self.l11l11l.lower()):
            l1ll1lll = re.compile(re.escape(self.l11l11l), re.IGNORECASE)
            l111111 = l1ll1lll.sub(l1lll1l (u"ࠨࠩࠄ"), self.l111111)
            l111111 = l111111.replace(l1lll1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll1l1(self.l11l11l, l1ll11l, l111111, self.l1ll1)
    def l1lll1l1(self,l11l11l, l1ll11l, l111111, l1ll1):
        l1lll1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111 = l11ll1l(l11l11l)
        l1lllll = self.l1ll1l11(l111)
        logger.info(l1lll1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111)
        if l1lllll:
            logger.info(l1lll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l11l1(l111)
            l111 = l1ll1111(l11l11l, l1ll11l, l1ll1, self.l11ll11)
        logger.debug(l1lll1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111l1l=l111 + l1lll1l (u"ࠤ࠲ࠦࠌ") + l111111
        l11111l = l1lll1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111l1l+ l1lll1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11111l)
        l11llll = os.system(l11111l)
        if (l11llll != 0):
            raise IOError(l1lll1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111l1l, l11llll))
    def l1ll1l11(self, l111):
        if os.path.exists(l111):
            if os.path.islink(l111):
                l111 = os.readlink(l111)
            if os.path.ismount(l111):
                return True
        return False
def l11ll1l(l11l11l):
    l1lllll1 = l11l11l.replace(l1lll1l (u"࠭࡜࡝ࠩࠐ"), l1lll1l (u"ࠧࡠࠩࠑ")).replace(l1lll1l (u"ࠨ࠱ࠪࠒ"), l1lll1l (u"ࠩࡢࠫࠓ"))
    l1 = l1lll1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11=os.environ[l1lll1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll11ll=os.path.join(l11,l1, l1lllll1)
    l11ll=os.path.abspath(l1ll11ll)
    return l11ll
def l1lll11(l111ll1):
    if not os.path.exists(l111ll1):
        os.makedirs(l111ll1)
def l1lll111(l11l11l, l1ll11l, l1111=None, password=None):
    l1lll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111ll1 = l11ll1l(l11l11l)
    l1lll11(l111ll1)
    if not l1111:
        l1111l = l1ll1ll()
        l1l =l1111l.l1ll11(l1lll1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll11l + l1lll1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll11l + l1lll1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l, str):
            l1111, password = l1l
        else:
            raise l1l111l()
        logger.info(l1lll1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111ll1))
    l1ll1l1l = pwd.getpwuid( os.getuid())[0]
    l1l1l1l=os.environ[l1lll1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1ll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll={l1lll1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1l1l, l1lll1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l11l, l1lll1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111ll1, l1lll1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1l1l, l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1111, l1lll1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll, temp_file)
        if not os.path.exists(os.path.join(l1l1ll1, l1lll1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11l1ll=l1lll1l (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1l (u"ࠧࠨࠤ")
        else:
            l11l1ll=l1lll1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1ll=l1lll1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11l1ll,temp_file.name)
        l1l111=[l1lll1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1ll1, l1l1ll)]
        p = subprocess.Popen(l1l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111ll1
    logger.debug(l1lll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11ll=os.path.abspath(l111ll1)
    logger.debug(l1lll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11ll)
    return l11ll
def l1ll1111(l11l11l, l1ll11l, l1ll1, l11ll11):
    l1lll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll1ll(title):
        l111l11=30
        if len(title)>l111l11:
            l111l1=title.split(l1lll1l (u"ࠨ࠯ࠣ࠳"))
            l1ll111=l1lll1l (u"ࠧࠨ࠴")
            for block in l111l1:
                l1ll111+=block+l1lll1l (u"ࠣ࠱ࠥ࠵")
                if len(l1ll111) > l111l11:
                    l1ll111+=l1lll1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll111
        return title
    def l11lll(l1lll11l, password):
        l1lll1l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll1l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll1l (u"ࠧࠦࠢ࠹").join(l1lll11l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l1l11 = l1lll1l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l1l11.encode())
        l1llll11 = [l1lll1l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l1l = l1lll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l1l)
            for e in l1llll11:
                if e in l1l1l: return False
            raise l1llllll(l1l1l, l1ll1111=l111ll.l11ll1(), l1ll11l=l1ll11l)
        logger.info(l1lll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1111 = l1lll1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll1l (u"ࠦࠧ࠿")
    os.system(l1lll1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l111lll = l11ll1l(l11l11l)
    l111ll1 = l11ll1l(hashlib.sha1(l11l11l.encode()).hexdigest()[:10])
    l1lll11(l111ll1)
    logger.info(l1lll1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111ll1))
    if l1ll1:
        l1lll11l = [l1lll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1l (u"ࠤ࠰ࡸࠧࡄ"), l1lll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1l (u"ࠫ࠲ࡵࠧࡆ"), l1lll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1111, l1ll1),
                    urllib.parse.unquote(l1ll11l), os.path.abspath(l111ll1)]
        l11lll(l1lll11l, password)
    else:
        while True:
            l1111, password = l11lll1(l111ll1, l1ll11l, l11ll11)
            if l1111.lower() != l1lll1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1lll11l = [l1lll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll1l (u"ࠤ࠰ࡸࠧࡋ"), l1lll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll1l (u"ࠫ࠲ࡵࠧࡍ"), l1lll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1111,
                            urllib.parse.unquote(l1ll11l), os.path.abspath(l111ll1)]
            else:
                raise l1l111l()
            if l11lll(l1lll11l, password): break
    os.system(l1lll1l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111ll1, l111lll))
    l11ll=os.path.abspath(l111lll)
    return l11ll
def l11lll1(l11l11l, l1ll11l, l11ll11):
    l1ll111l = os.path.join(os.environ[l1lll1l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll111l)):
       os.makedirs(os.path.dirname(l1ll111l))
    l11l1l = l11ll11.get_value(l1lll1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll1l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1111l = l1ll1ll(l11l11l, l11l1l)
    l1111, password = l1111l.l1ll11(l1lll1l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll11l + l1lll1l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll11l + l1lll1l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1111 != l1lll1l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11l1(l11l11l, l1111):
        l11111 = l1lll1l (u"ࠤ࡙ࠣࠦ").join([l11l11l, l1111, l1lll1l (u"࡚ࠪࠦࠬ") + password + l1lll1l (u"࡛ࠫࠧ࠭"), l1lll1l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll111l, l1lll1l (u"࠭ࡷࠬࠩ࡝")) as l1l1:
            l1l1.write(l11111)
        os.chmod(l1ll111l, 0o600)
    return l1111, password
def l11l1(l11l11l, l1111):
    l1ll111l = l1llll = os.path.join(os.environ[l1lll1l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll111l):
        with open(l1ll111l, l1lll1l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1111ll = data[0].split(l1lll1l (u"ࠦࠥࠨࡢ"))
            if l11l11l == l1111ll[0] and l1111 == l1111ll[1]:
                return True
    return False