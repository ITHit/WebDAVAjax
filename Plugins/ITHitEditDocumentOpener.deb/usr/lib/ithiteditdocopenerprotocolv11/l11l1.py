#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l11ll1 = 2048
l1l1l1l = 7
def l1ll1111 (l111ll):
    global l1lll
    l1l11 = ord (l111ll [-1])
    l11l111 = l111ll [:-1]
    l1l1111 = l1l11 % len (l11l111)
    l1lllll = l11l111 [:l1l1111] + l11l111 [l1l1111:]
    if l1l1l1:
        l11l11 = l1ll1ll () .join ([unichr (ord (char) - l11ll1 - (l1111l + l1l11) % l1l1l1l) for l1111l, char in enumerate (l1lllll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll1 - (l1111l + l1l11) % l1l1l1l) for l1111l, char in enumerate (l1lllll)])
    return eval (l11l11)
import logging
import os
import re
from l1ll1l1l import l11111ll
logger = logging.getLogger(l1ll1111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11ll11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1111 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    try:
        out = os.popen(l1ll1111 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1111 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1111 (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1111 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1111 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1111 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1111 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111ll(l1ll1111 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1111 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11ll11(l1ll1111 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))