#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll1 = sys.version_info [0] == 2
l1llll1 = 2048
l11111l = 7
def l1lll1l (l11):
    global l1l1111
    ll = ord (l11 [-1])
    l1l1ll1 = l11 [:-1]
    l1l1l = ll % len (l1l1ll1)
    l1l1l11 = l1l1ll1 [:l1l1l] + l1l1ll1 [l1l1l:]
    if l1ll1ll1:
        l11l = l1llllll () .join ([unichr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll1 - (l11l1l1 + ll) % l11111l) for l11l1l1, char in enumerate (l1l1l11)])
    return eval (l11l)
import hashlib
import os
import l11ll1
from l1lll11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11ll1 import l1111l1
from l1ll11l1 import l1ll1, l1lll1l1
import logging
logger = logging.getLogger(l1lll1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l11l1():
    def __init__(self, l1l1l1,l1lll, l1l1l1l= None, l1ll1111=None):
        self.l1l1=False
        self.l1ll11l = self._1111ll()
        self.l1lll = l1lll
        self.l1l1l1l = l1l1l1l
        self.l1l111 = l1l1l1
        if l1l1l1l:
            self.l1l = True
        else:
            self.l1l = False
        self.l1ll1111 = l1ll1111
    def _1111ll(self):
        try:
            return l11ll1.l11ll1l() is not None
        except:
            return False
    def open(self):
        l1lll1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll11l:
            raise NotImplementedError(l1lll1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11l1ll = self.l1l111
        if self.l1lll.lower().startswith(self.l1l111.lower()):
            l111lll = re.compile(re.escape(self.l1l111), re.IGNORECASE)
            l1lll = l111lll.sub(l1lll1l (u"ࠨࠩࠄ"), self.l1lll)
            l1lll = l1lll.replace(l1lll1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l111l1l(self.l1l111, l11l1ll, l1lll, self.l1l1l1l)
    def l111l1l(self,l1l111, l11l1ll, l1lll, l1l1l1l):
        l1lll1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11lll1 = l1l11(l1l111)
        l1l1lll = self.l1lll1(l11lll1)
        logger.info(l1lll1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11lll1)
        if l1l1lll:
            logger.info(l1lll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111l1(l11lll1)
            l11lll1 = l1ll111(l1l111, l11l1ll, l1l1l1l, self.l1ll1111)
        logger.debug(l1lll1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1=l11lll1 + l1lll1l (u"ࠤ࠲ࠦࠌ") + l1lll
        l11111 = l1lll1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1+ l1lll1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11111)
        l1ll1l11 = os.system(l11111)
        if (l1ll1l11 != 0):
            raise IOError(l1lll1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1, l1ll1l11))
    def l1lll1(self, l11lll1):
        if os.path.exists(l11lll1):
            if os.path.islink(l11lll1):
                l11lll1 = os.readlink(l11lll1)
            if os.path.ismount(l11lll1):
                return True
        return False
def l1l11(l1l111):
    l1llll = l1l111.replace(l1lll1l (u"࠭࡜࡝ࠩࠐ"), l1lll1l (u"ࠧࡠࠩࠑ")).replace(l1lll1l (u"ࠨ࠱ࠪࠒ"), l1lll1l (u"ࠩࡢࠫࠓ"))
    l1ll1l = l1lll1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll11=os.environ[l1lll1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll=os.path.join(l1ll11,l1ll1l, l1llll)
    l1l111l=os.path.abspath(l1ll)
    return l1l111l
def l11l111(l11l1):
    if not os.path.exists(l11l1):
        os.makedirs(l11l1)
def l1lllll1(l1l111, l11l1ll, l111111=None, password=None):
    l1lll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l1 = l1l11(l1l111)
    l11l111(l11l1)
    if not l111111:
        l11ll11 = l1ll1l1l()
        l1ll11ll =l11ll11.l1lll111(l1lll1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11l1ll + l1lll1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11l1ll + l1lll1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11ll, str):
            l111111, password = l1ll11ll
        else:
            raise l1lll1l1()
        logger.info(l1lll1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l1))
    l111l1 = pwd.getpwuid( os.getuid())[0]
    l1111=os.environ[l1lll1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l11=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l111ll={l1lll1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111l1, l1lll1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l111, l1lll1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l1, l1lll1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1111, l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111111, l1lll1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l111ll, temp_file)
        if not os.path.exists(os.path.join(l11l11, l1lll1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11ll=l1lll1l (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1l (u"ࠧࠨࠤ")
        else:
            l11ll=l1lll1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1lll=l1lll1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11ll,temp_file.name)
        l111l=[l1lll1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l11, l1ll1lll)]
        p = subprocess.Popen(l111l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l1
    logger.debug(l1lll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l111l=os.path.abspath(l11l1)
    logger.debug(l1lll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l111l)
    return l1l111l
def l1ll111(l1l111, l11l1ll, l1l1l1l, l1ll1111):
    l1lll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l11l(title):
        l1ll111l=30
        if len(title)>l1ll111l:
            l111l11=title.split(l1lll1l (u"ࠨ࠯ࠣ࠳"))
            l11lll=l1lll1l (u"ࠧࠨ࠴")
            for block in l111l11:
                l11lll+=block+l1lll1l (u"ࠣ࠱ࠥ࠵")
                if len(l11lll) > l1ll111l:
                    l11lll+=l1lll1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11lll
        return title
    def l1lll11l(l1111l, password):
        l1lll1l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll1l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll1l (u"ࠧࠦࠢ࠹").join(l1111l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l1ll = l1lll1l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l1ll.encode())
        l1lllll = [l1lll1l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1llll1l = l1lll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1llll1l)
            for e in l1lllll:
                if e in l1llll1l: return False
            raise l1ll1(l1llll1l, l1ll111=l11ll1.l11ll1l(), l11l1ll=l11l1ll)
        logger.info(l1lll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l111111 = l1lll1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll1l (u"ࠦࠧ࠿")
    os.system(l1lll1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l111 = l1l11(l1l111)
    l11l1 = l1l11(hashlib.sha1(l1l111.encode()).hexdigest()[:10])
    l11l111(l11l1)
    logger.info(l1lll1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11l1))
    if l1l1l1l:
        l1111l = [l1lll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1l (u"ࠤ࠰ࡸࠧࡄ"), l1lll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1l (u"ࠫ࠲ࡵࠧࡆ"), l1lll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l111111, l1l1l1l),
                    urllib.parse.unquote(l11l1ll), os.path.abspath(l11l1)]
        l1lll11l(l1111l, password)
    else:
        while True:
            l111111, password = l11l1l(l11l1, l11l1ll, l1ll1111)
            if l111111.lower() != l1lll1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1111l = [l1lll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll1l (u"ࠤ࠰ࡸࠧࡋ"), l1lll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll1l (u"ࠫ࠲ࡵࠧࡍ"), l1lll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l111111,
                            urllib.parse.unquote(l11l1ll), os.path.abspath(l11l1)]
            else:
                raise l1lll1l1()
            if l1lll11l(l1111l, password): break
    os.system(l1lll1l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11l1, l111))
    l1l111l=os.path.abspath(l111)
    return l1l111l
def l11l1l(l1l111, l11l1ll, l1ll1111):
    l1ll1l1 = os.path.join(os.environ[l1lll1l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1l1)):
       os.makedirs(os.path.dirname(l1ll1l1))
    l11llll = l1ll1111.get_value(l1lll1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll1l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11ll11 = l1ll1l1l(l1l111, l11llll)
    l111111, password = l11ll11.l1lll111(l1lll1l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11l1ll + l1lll1l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11l1ll + l1lll1l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l111111 != l1lll1l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111ll1(l1l111, l111111):
        l1lll1ll = l1lll1l (u"ࠤ࡙ࠣࠦ").join([l1l111, l111111, l1lll1l (u"࡚ࠪࠦࠬ") + password + l1lll1l (u"࡛ࠫࠧ࠭"), l1lll1l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1l1, l1lll1l (u"࠭ࡷࠬࠩ࡝")) as l1l11l:
            l1l11l.write(l1lll1ll)
        os.chmod(l1ll1l1, 0o600)
    return l111111, password
def l111ll1(l1l111, l111111):
    l1ll1l1 = l1l11ll = os.path.join(os.environ[l1lll1l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1l1):
        with open(l1ll1l1, l1lll1l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1llll11 = data[0].split(l1lll1l (u"ࠦࠥࠨࡢ"))
            if l1l111 == l1llll11[0] and l111111 == l1llll11[1]:
                return True
    return False