#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l11 = sys.version_info [0] == 2
l1l11l = 2048
l1llll1 = 7
def l1lll111 (l11ll):
    global l111ll
    l1 = ord (l11ll [-1])
    l1ll1l1 = l11ll [:-1]
    l11l1 = l1 % len (l1ll1l1)
    l1l11 = l1ll1l1 [:l11l1] + l1ll1l1 [l11l1:]
    if l111l11:
        l11l111 = l1llll11 () .join ([unichr (ord (char) - l1l11l - (l1ll11l1 + l1) % l1llll1) for l1ll11l1, char in enumerate (l1l11)])
    else:
        l11l111 = str () .join ([chr (ord (char) - l1l11l - (l1ll11l1 + l1) % l1llll1) for l1ll11l1, char in enumerate (l1l11)])
    return eval (l11l111)
import hashlib
import os
import l11111
from l1ll11l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11111 import l1ll1l
from l1lllll import l111, l1ll1lll
import logging
logger = logging.getLogger(l1lll111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111():
    def __init__(self, l1ll11ll,l1l1l1, l11llll= None, l1lllll1=None):
        self.l111ll1=False
        self.l1lll11 = self._1ll111()
        self.l1l1l1 = l1l1l1
        self.l11llll = l11llll
        self.l1l1ll1 = l1ll11ll
        if l11llll:
            self.l11ll1l = True
        else:
            self.l11ll1l = False
        self.l1lllll1 = l1lllll1
    def _1ll111(self):
        try:
            return l11111.l1ll1ll1() is not None
        except:
            return False
    def open(self):
        l1lll111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lll11:
            raise NotImplementedError(l1lll111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1111ll = self.l1l1ll1
        if self.l1l1l1.lower().startswith(self.l1l1ll1.lower()):
            l1l1 = re.compile(re.escape(self.l1l1ll1), re.IGNORECASE)
            l1l1l1 = l1l1.sub(l1lll111 (u"ࠨࠩࠄ"), self.l1l1l1)
            l1l1l1 = l1l1l1.replace(l1lll111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l111l(self.l1l1ll1, l1111ll, l1l1l1, self.l11llll)
    def l1l111l(self,l1l1ll1, l1111ll, l1l1l1, l11llll):
        l1lll111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11ll11 = l1llllll(l1l1ll1)
        l11lll = self.l1l11ll(l11ll11)
        logger.info(l1lll111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11ll11)
        if l11lll:
            logger.info(l1lll111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1l(l11ll11)
            l11ll11 = l11l11(l1l1ll1, l1111ll, l11llll, self.l1lllll1)
        logger.debug(l1lll111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll1l1=l11ll11 + l1lll111 (u"ࠤ࠲ࠦࠌ") + l1l1l1
        l11l1ll = l1lll111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll1l1+ l1lll111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11l1ll)
        l1l1l1l = os.system(l11l1ll)
        if (l1l1l1l != 0):
            raise IOError(l1lll111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll1l1, l1l1l1l))
    def l1l11ll(self, l11ll11):
        if os.path.exists(l11ll11):
            if os.path.islink(l11ll11):
                l11ll11 = os.readlink(l11ll11)
            if os.path.ismount(l11ll11):
                return True
        return False
def l1llllll(l1l1ll1):
    l111lll = l1l1ll1.replace(l1lll111 (u"࠭࡜࡝ࠩࠐ"), l1lll111 (u"ࠧࡠࠩࠑ")).replace(l1lll111 (u"ࠨ࠱ࠪࠒ"), l1lll111 (u"ࠩࡢࠫࠓ"))
    l1ll1l1l = l1lll111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111l1=os.environ[l1lll111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll1=os.path.join(l111l1,l1ll1l1l, l111lll)
    l1l1111=os.path.abspath(l11ll1)
    return l1l1111
def l11lll1(l11l1l):
    if not os.path.exists(l11l1l):
        os.makedirs(l11l1l)
def l1lll11l(l1l1ll1, l1111ll, l1llll=None, password=None):
    l1lll111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l1l = l1llllll(l1l1ll1)
    l11lll1(l11l1l)
    if not l1llll:
        l111l1l = l1ll1()
        l1ll111l =l111l1l.ll(l1lll111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1111ll + l1lll111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1111ll + l1lll111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll111l, str):
            l1llll, password = l1ll111l
        else:
            raise l1ll1lll()
        logger.info(l1lll111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l1l))
    l1l11l1 = pwd.getpwuid( os.getuid())[0]
    l1lll1=os.environ[l1lll111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11111l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l111l={l1lll111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l11l1, l1lll111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1ll1, l1lll111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l1l, l1lll111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll1, l1lll111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1llll, l1lll111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l111l, temp_file)
        if not os.path.exists(os.path.join(l11111l, l1lll111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1111=l1lll111 (u"ࠦࡵࡿࠢࠣ")
            key=l1lll111 (u"ࠧࠨࠤ")
        else:
            l1ll1111=l1lll111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1llll1l=l1lll111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1111,temp_file.name)
        l1lll=[l1lll111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11111l, l1llll1l)]
        p = subprocess.Popen(l1lll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l1l
    logger.debug(l1lll111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1111=os.path.abspath(l11l1l)
    logger.debug(l1lll111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1111)
    return l1l1111
def l11l11(l1l1ll1, l1111ll, l11llll, l1lllll1):
    l1lll111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1111l1(title):
        l11l11l=30
        if len(title)>l11l11l:
            l11l1l1=title.split(l1lll111 (u"ࠨ࠯ࠣ࠳"))
            l1111l=l1lll111 (u"ࠧࠨ࠴")
            for block in l11l1l1:
                l1111l+=block+l1lll111 (u"ࠣ࠱ࠥ࠵")
                if len(l1111l) > l11l11l:
                    l1111l+=l1lll111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1111l
        return title
    def l1ll11(l1l1l, password):
        l1lll111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll111 (u"ࠧࠦࠢ࠹").join(l1l1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll1ll = l1lll111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll1ll.encode())
        l1l1lll = [l1lll111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll1l = l1lll111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll1l)
            for e in l1l1lll:
                if e in l1lll1l: return False
            raise l111(l1lll1l, l11l11=l11111.l1ll1ll1(), l1111ll=l1111ll)
        logger.info(l1lll111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1llll = l1lll111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll111 (u"ࠦࠧ࠿")
    os.system(l1lll111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1l11 = l1llllll(l1l1ll1)
    l11l1l = l1llllll(hashlib.sha1(l1l1ll1.encode()).hexdigest()[:10])
    l11lll1(l11l1l)
    logger.info(l1lll111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11l1l))
    if l11llll:
        l1l1l = [l1lll111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll111 (u"ࠤ࠰ࡸࠧࡄ"), l1lll111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll111 (u"ࠫ࠲ࡵࠧࡆ"), l1lll111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1llll, l11llll),
                    urllib.parse.unquote(l1111ll), os.path.abspath(l11l1l)]
        l1ll11(l1l1l, password)
    else:
        while True:
            l1llll, password = l1ll(l11l1l, l1111ll, l1lllll1)
            if l1llll.lower() != l1lll111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1l1l = [l1lll111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll111 (u"ࠤ࠰ࡸࠧࡋ"), l1lll111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll111 (u"ࠫ࠲ࡵࠧࡍ"), l1lll111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1llll,
                            urllib.parse.unquote(l1111ll), os.path.abspath(l11l1l)]
            else:
                raise l1ll1lll()
            if l1ll11(l1l1l, password): break
    os.system(l1lll111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11l1l, l1ll1l11))
    l1l1111=os.path.abspath(l1ll1l11)
    return l1l1111
def l1ll(l1l1ll1, l1111ll, l1lllll1):
    l1l = os.path.join(os.environ[l1lll111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l)):
       os.makedirs(os.path.dirname(l1l))
    l111111 = l1lllll1.get_value(l1lll111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l111l1l = l1ll1(l1l1ll1, l111111)
    l1llll, password = l111l1l.ll(l1lll111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1111ll + l1lll111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1111ll + l1lll111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1llll != l1lll111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11(l1l1ll1, l1llll):
        l1l1ll = l1lll111 (u"ࠤ࡙ࠣࠦ").join([l1l1ll1, l1llll, l1lll111 (u"࡚ࠪࠦࠬ") + password + l1lll111 (u"࡛ࠫࠧ࠭"), l1lll111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l, l1lll111 (u"࠭ࡷࠬࠩ࡝")) as l1lll1ll:
            l1lll1ll.write(l1l1ll)
        os.chmod(l1l, 0o600)
    return l1llll, password
def l11(l1l1ll1, l1llll):
    l1l = l1l1l11 = os.path.join(os.environ[l1lll111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l):
        with open(l1l, l1lll111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l = data[0].split(l1lll111 (u"ࠦࠥࠨࡢ"))
            if l1l1ll1 == l11l[0] and l1llll == l11l[1]:
                return True
    return False