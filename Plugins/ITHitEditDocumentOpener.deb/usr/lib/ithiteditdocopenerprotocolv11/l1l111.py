#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l1 = sys.version_info [0] == 2
l111lll = 2048
l1l = 7
def l1ll1ll (l11l1ll):
    global l1lll11
    l1l1111 = ord (l11l1ll [-1])
    l1111l = l11l1ll [:-1]
    l1l1 = l1l1111 % len (l1111l)
    l1l1l1 = l1111l [:l1l1] + l1111l [l1l1:]
    if l1111l1:
        l11l1l1 = l11 () .join ([unichr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    else:
        l11l1l1 = str () .join ([chr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    return eval (l11l1l1)
import hashlib
import os
import l1lll111
from l11lll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll111 import l111ll1
from l1ll1ll1 import ll, l1l11ll
import logging
logger = logging.getLogger(l1ll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11lll1():
    def __init__(self, l11l1l,l11llll, l1lllll= None, l1ll1=None):
        self.l1l11l=False
        self.l1ll111 = self._11l11()
        self.l11llll = l11llll
        self.l1lllll = l1lllll
        self.l1ll11l = l11l1l
        if l1lllll:
            self.l1ll1l = True
        else:
            self.l1ll1l = False
        self.l1ll1 = l1ll1
    def _11l11(self):
        try:
            return l1lll111.l111111() is not None
        except:
            return False
    def open(self):
        l1ll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll111:
            raise NotImplementedError(l1ll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1l11 = self.l1ll11l
        if self.l11llll.lower().startswith(self.l1ll11l.lower()):
            l11111 = re.compile(re.escape(self.l1ll11l), re.IGNORECASE)
            l11llll = l11111.sub(l1ll1ll (u"ࠨࠩࠄ"), self.l11llll)
            l11llll = l11llll.replace(l1ll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll1ll(self.l1ll11l, l1l1l11, l11llll, self.l1lllll)
    def l1lll1ll(self,l1ll11l, l1l1l11, l11llll, l1lllll):
        l1ll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111l = l1l1l1l(l1ll11l)
        l1lll1l1 = self.l1l1l(l111l)
        logger.info(l1ll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111l)
        if l1lll1l1:
            logger.info(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111ll1(l111l)
            l111l = l1ll111l(l1ll11l, l1l1l11, l1lllll, self.l1ll1)
        logger.debug(l1ll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll1l=l111l + l1ll1ll (u"ࠤ࠲ࠦࠌ") + l11llll
        l1l111l = l1ll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll1l+ l1ll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l111l)
        l1l1ll = os.system(l1l111l)
        if (l1l1ll != 0):
            raise IOError(l1ll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll1l, l1l1ll))
    def l1l1l(self, l111l):
        if os.path.exists(l111l):
            if os.path.islink(l111l):
                l111l = os.readlink(l111l)
            if os.path.ismount(l111l):
                return True
        return False
def l1l1l1l(l1ll11l):
    l111ll = l1ll11l.replace(l1ll1ll (u"࠭࡜࡝ࠩࠐ"), l1ll1ll (u"ࠧࡠࠩࠑ")).replace(l1ll1ll (u"ࠨ࠱ࠪࠒ"), l1ll1ll (u"ࠩࡢࠫࠓ"))
    l1l11l1 = l1ll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1111=os.environ[l1ll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll11=os.path.join(l1111,l1l11l1, l111ll)
    l1l11=os.path.abspath(l11ll11)
    return l1l11
def l1llll11(l1111ll):
    if not os.path.exists(l1111ll):
        os.makedirs(l1111ll)
def l1ll11ll(l1ll11l, l1l1l11, l1llllll=None, password=None):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1111ll = l1l1l1l(l1ll11l)
    l1llll11(l1111ll)
    if not l1llllll:
        l1ll1111 = l1ll1l1()
        l1ll1l1l =l1ll1111.l1lll11l(l1ll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1l11 + l1ll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1l11 + l1ll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll1l1l, str):
            l1llllll, password = l1ll1l1l
        else:
            raise l1l11ll()
        logger.info(l1ll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1111ll))
    l1ll1lll = pwd.getpwuid( os.getuid())[0]
    l11l=os.environ[l1ll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11111l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11l1={l1ll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1lll, l1ll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll11l, l1ll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1111ll, l1ll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11l, l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1llllll, l1ll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11l1, temp_file)
        if not os.path.exists(os.path.join(l11111l, l1ll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111l11=l1ll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1ll (u"ࠧࠨࠤ")
        else:
            l111l11=l1ll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11ll1l=l1ll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111l11,temp_file.name)
        l11ll1=[l1ll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11111l, l11ll1l)]
        p = subprocess.Popen(l11ll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1111ll
    logger.debug(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l11=os.path.abspath(l1111ll)
    logger.debug(l1ll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l11)
    return l1l11
def l1ll111l(l1ll11l, l1l1l11, l1lllll, l1ll1):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll11(title):
        l11l11l=30
        if len(title)>l11l11l:
            l1=title.split(l1ll1ll (u"ࠨ࠯ࠣ࠳"))
            l1l1ll1=l1ll1ll (u"ࠧࠨ࠴")
            for block in l1:
                l1l1ll1+=block+l1ll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l1l1ll1) > l11l11l:
                    l1l1ll1+=l1ll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l1ll1
        return title
    def l1l1lll(l1llll, password):
        l1ll1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1ll (u"ࠧࠦࠢ࠹").join(l1llll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l111 = l1ll1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l111.encode())
        l1llll1 = [l1ll1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll1 = l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll1)
            for e in l1llll1:
                if e in l1lll1: return False
            raise ll(l1lll1, l1ll111l=l1lll111.l111111(), l1l1l11=l1l1l11)
        logger.info(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1llllll = l1ll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1ll (u"ࠦࠧ࠿")
    os.system(l1ll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l111 = l1l1l1l(l1ll11l)
    l1111ll = l1l1l1l(hashlib.sha1(l1ll11l.encode()).hexdigest()[:10])
    l1llll11(l1111ll)
    logger.info(l1ll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1111ll))
    if l1lllll:
        l1llll = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1llllll, l1lllll),
                    urllib.parse.unquote(l1l1l11), os.path.abspath(l1111ll)]
        l1l1lll(l1llll, password)
    else:
        while True:
            l1llllll, password = l11l1(l1111ll, l1l1l11, l1ll1)
            if l1llllll.lower() != l1ll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1llll = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡋ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡍ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1llllll,
                            urllib.parse.unquote(l1l1l11), os.path.abspath(l1111ll)]
            else:
                raise l1l11ll()
            if l1l1lll(l1llll, password): break
    os.system(l1ll1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1111ll, l111))
    l1l11=os.path.abspath(l111)
    return l1l11
def l11l1(l1ll11l, l1l1l11, l1ll1):
    l1lllll1 = os.path.join(os.environ[l1ll1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lllll1)):
       os.makedirs(os.path.dirname(l1lllll1))
    l11ll = l1ll1.get_value(l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll1111 = l1ll1l1(l1ll11l, l11ll)
    l1llllll, password = l1ll1111.l1lll11l(l1ll1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1l11 + l1ll1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1l11 + l1ll1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1llllll != l1ll1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll(l1ll11l, l1llllll):
        l111l1l = l1ll1ll (u"ࠤ࡙ࠣࠦ").join([l1ll11l, l1llllll, l1ll1ll (u"࡚ࠪࠦࠬ") + password + l1ll1ll (u"࡛ࠫࠧ࠭"), l1ll1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lllll1, l1ll1ll (u"࠭ࡷࠬࠩ࡝")) as l1llll1l:
            l1llll1l.write(l111l1l)
        os.chmod(l1lllll1, 0o600)
    return l1llllll, password
def l1ll(l1ll11l, l1llllll):
    l1lllll1 = l111l1 = os.path.join(os.environ[l1ll1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lllll1):
        with open(l1lllll1, l1ll1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll1l11 = data[0].split(l1ll1ll (u"ࠦࠥࠨࡢ"))
            if l1ll11l == l1ll1l11[0] and l1llllll == l1ll1l11[1]:
                return True
    return False