#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l11 = sys.version_info [0] == 2
l1ll1l = 2048
l11ll11 = 7
def l1llllll (l11l111):
    global l11l11
    l1ll1l11 = ord (l11l111 [-1])
    l1llll = l11l111 [:-1]
    ll = l1ll1l11 % len (l1llll)
    l1ll1 = l1llll [:ll] + l1llll [ll:]
    if l1l1l11:
        l1l111 = l1llll1l () .join ([unichr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    return eval (l1l111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11ll1=logging.WARNING
logger = logging.getLogger(l1llllll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11ll1)
l1l1l1ll = SysLogHandler(address=l1llllll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1llllll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1l1ll.setFormatter(formatter)
logger.addHandler(l1l1l1ll)
ch = logging.StreamHandler()
ch.setLevel(l1lll11ll1)
logger.addHandler(ch)
class l1lllll1l1(io.FileIO):
    l1llllll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1llllll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1l11l, l1lll1l111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1l11l = l1lll1l11l
            self.l1lll1l111 = l1lll1l111
            if not options:
                options = l1llllll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1llllll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1l11l,
                                              self.l1lll1l111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll11 = os.path.join(os.path.sep, l1llllll (u"ࠪࡩࡹࡩࠧই"), l1llllll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llll1lll = path
        else:
            self._1llll1lll = self.l1lll1ll11
        super(l1lllll1l1, self).__init__(self._1llll1lll, l1llllll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l11(self, line):
        return l1lllll1l1.Entry(*[x for x in line.strip(l1llllll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1llllll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1llllll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1llllll (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l11(line)
            except ValueError:
                pass
    def l1lllll111(self, attr, value):
        for entry in self.entries:
            l1lll11111 = getattr(entry, attr)
            if l1lll11111 == value:
                return entry
        return None
    def l1llll111l(self, entry):
        if self.l1lllll111(l1llllll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1llllll (u"ࠫࡡࡴࠧএ")).encode(l1llllll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1ll1l(self, entry):
        self.seek(0)
        lines = [l.decode(l1llllll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1llllll (u"ࠢࠤࠤ঒")):
                if self._1llll1l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1llllll (u"ࠨࠩও").join(lines).encode(l1llllll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll11lll(cls, l1lll1l11l, path=None):
        l1lll1llll = cls(path=path)
        entry = l1lll1llll.l1lllll111(l1llllll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1l11l)
        if entry:
            return l1lll1llll.l1lll1ll1l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1l11l, l1lll1l111, options=None, path=None):
        return cls(path=path).l1llll111l(l1lllll1l1.Entry(device,
                                                    l1lll1l11l, l1lll1l111,
                                                    options=options))
class l1lll1111l(object):
    def __init__(self, l1llll1ll1):
        self.l1lllllll1=l1llllll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11l1l=l1llllll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll1ll1=l1llll1ll1
        self.l1lll1l1l1()
        self.l1lll11l11()
        self.l1llll1l1l()
        self.l1llllll11()
        self.l1lll111l1()
    def l1lll1l1l1(self):
        temp_file=open(l1lllll1ll,l1llllll (u"࠭ࡲࠨঘ"))
        l111lll=temp_file.read()
        data=json.loads(l111lll)
        self.user=data[l1llllll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11=data[l1llllll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1lll1=data[l1llllll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l111l1=data[l1llllll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llllll1l=data[l1llllll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111ll=data[l1llllll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1l1l(self):
        l1llll1=os.path.join(l1llllll (u"ࠨ࠯ࠣট"),l1llllll (u"ࠢࡶࡵࡵࠦঠ"),l1llllll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1llllll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1llllll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1llll1)
    def l1lll111l1(self):
        logger.info(l1llllll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1lll1=os.path.join(self.l111l1,self.l1lllllll1)
        l1lllll11l = pwd.getpwnam(self.user).pw_uid
        l1llll1111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1lll1):
            os.makedirs(l1lll1)
            os.system(l1llllll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1lll1))
            logger.debug(l1llllll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1lll1)
        else:
            logger.debug(l1llllll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1lll1)
        l1llll1=os.path.join(l1lll1, self.l1lll11l1l)
        print(l1llll1)
        logger.debug(l1llllll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1llll1)
        with open(l1llll1, l1llllll (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l1ll:
            logger.debug(self.l11 + l1llllll (u"ࠪࠤࠬপ")+self.l1llllll1l+l1llllll (u"ࠫࠥࠨࠧফ")+self.l1lll111ll+l1llllll (u"ࠬࠨࠧব"))
            l1lll1l1ll.writelines(self.l11 + l1llllll (u"࠭ࠠࠨভ")+self.l1llllll1l+l1llllll (u"ࠧࠡࠤࠪম")+self.l1lll111ll+l1llllll (u"ࠨࠤࠪয"))
        os.chmod(l1llll1, 0o600)
        os.chown(l1llll1, l1lllll11l, l1llll1111)
    def l1lll11l11(self, l1llll11ll=l1llllll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1llllll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11ll in groups:
            logger.info(l1llllll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll11ll))
        else:
            logger.warning(l1llllll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll11ll))
            l11lll=l1llllll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll11ll,self.user)
            logger.debug(l1llllll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l11lll)
            os.system(l11lll)
            logger.debug(l1llllll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llllll11(self):
        logger.debug(l1llllll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1llll=l1lllll1l1()
        l1lll1llll.add(self.l11, self.l1lll1, l1lll1l111=l1llllll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1llllll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1llllll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll1ll = urllib.parse.unquote(sys.argv[1])
        if l1lllll1ll:
            l1llll11l1=l1lll1111l(l1lllll1ll)
        else:
            raise (l1llllll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1llllll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise