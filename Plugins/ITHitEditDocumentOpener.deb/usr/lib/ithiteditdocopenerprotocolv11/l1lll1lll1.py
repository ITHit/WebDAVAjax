#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l1 = sys.version_info [0] == 2
l111lll = 2048
l1l = 7
def l1ll1ll (l11l1ll):
    global l1lll11
    l1l1111 = ord (l11l1ll [-1])
    l1111l = l11l1ll [:-1]
    l1l1 = l1l1111 % len (l1111l)
    l1l1l1 = l1111l [:l1l1] + l1111l [l1l1:]
    if l1111l1:
        l11l1l1 = l11 () .join ([unichr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    else:
        l11l1l1 = str () .join ([chr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    return eval (l11l1l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllllll1=logging.WARNING
logger = logging.getLogger(l1ll1ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lllllll1)
l11llll1 = SysLogHandler(address=l1ll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll1ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11llll1.setFormatter(formatter)
logger.addHandler(l11llll1)
ch = logging.StreamHandler()
ch.setLevel(l1lllllll1)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l1ll1ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll1ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11111, l1llll1lll,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11111 = l1lll11111
            self.l1llll1lll = l1llll1lll
            if not options:
                options = l1ll1ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll1ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11111,
                                              self.l1llll1lll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1llll = os.path.join(os.path.sep, l1ll1ll (u"ࠪࡩࡹࡩࠧই"), l1ll1ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l111 = path
        else:
            self._1lll1l111 = self.l1lll1llll
        super(l1llll1l1l, self).__init__(self._1lll1l111, l1ll1ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1111(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l1ll1ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll1ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll1ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll1ll (u"ࠤࠦࠦ঍")):
                    yield self._1llll1111(line)
            except ValueError:
                pass
    def l1lll1111l(self, attr, value):
        for entry in self.entries:
            l1lllll11l = getattr(entry, attr)
            if l1lllll11l == value:
                return entry
        return None
    def l1lllll111(self, entry):
        if self.l1lll1111l(l1ll1ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll1ll (u"ࠫࡡࡴࠧএ")).encode(l1ll1ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll11ll1(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll1ll (u"ࠢࠤࠤ঒")):
                if self._1llll1111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll1ll (u"ࠨࠩও").join(lines).encode(l1ll1ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllll1l1(cls, l1lll11111, path=None):
        l1llllll1l = cls(path=path)
        entry = l1llllll1l.l1lll1111l(l1ll1ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11111)
        if entry:
            return l1llllll1l.l1lll11ll1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11111, l1llll1lll, options=None, path=None):
        return cls(path=path).l1lllll111(l1llll1l1l.Entry(device,
                                                    l1lll11111, l1llll1lll,
                                                    options=options))
class l1lll11lll(object):
    def __init__(self, l1lll11l1l):
        self.l1llll11ll=l1ll1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll11l1=l1ll1ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll11l1l=l1lll11l1l
        self.l1lll1ll11()
        self.l1lll1ll1l()
        self.l1lll1l11l()
        self.l1llll1ll1()
        self.l1llll1l11()
    def l1lll1ll11(self):
        temp_file=open(l1llll111l,l1ll1ll (u"࠭ࡲࠨঘ"))
        l1llll1l=temp_file.read()
        data=json.loads(l1llll1l)
        self.user=data[l1ll1ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll11l=data[l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1111ll=data[l1ll1ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11l=data[l1ll1ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll1ll=data[l1ll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111ll=data[l1ll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l11l(self):
        l111l1=os.path.join(l1ll1ll (u"ࠨ࠯ࠣট"),l1ll1ll (u"ࠢࡶࡵࡵࠦঠ"),l1ll1ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll1ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll1ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111l1)
    def l1llll1l11(self):
        logger.info(l1ll1ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1111ll=os.path.join(self.l11l,self.l1llll11ll)
        l1lll1l1l1 = pwd.getpwnam(self.user).pw_uid
        l1lll111l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1111ll):
            os.makedirs(l1111ll)
            os.system(l1ll1ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1111ll))
            logger.debug(l1ll1ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1111ll)
        else:
            logger.debug(l1ll1ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1111ll)
        l111l1=os.path.join(l1111ll, self.l1llll11l1)
        print(l111l1)
        logger.debug(l1ll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111l1)
        with open(l111l1, l1ll1ll (u"ࠤࡺ࠯ࠧ঩")) as l1llllll11:
            logger.debug(self.l1ll11l + l1ll1ll (u"ࠪࠤࠬপ")+self.l1lllll1ll+l1ll1ll (u"ࠫࠥࠨࠧফ")+self.l1lll111ll+l1ll1ll (u"ࠬࠨࠧব"))
            l1llllll11.writelines(self.l1ll11l + l1ll1ll (u"࠭ࠠࠨভ")+self.l1lllll1ll+l1ll1ll (u"ࠧࠡࠤࠪম")+self.l1lll111ll+l1ll1ll (u"ࠨࠤࠪয"))
        os.chmod(l111l1, 0o600)
        os.chown(l111l1, l1lll1l1l1, l1lll111l1)
    def l1lll1ll1l(self, l1lll11l11=l1ll1ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll1ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11l11 in groups:
            logger.info(l1ll1ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11l11))
        else:
            logger.warning(l1ll1ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11l11))
            l11ll1=l1ll1ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11l11,self.user)
            logger.debug(l1ll1ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l11ll1)
            os.system(l11ll1)
            logger.debug(l1ll1ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll1ll1(self):
        logger.debug(l1ll1ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llllll1l=l1llll1l1l()
        l1llllll1l.add(self.l1ll11l, self.l1111ll, l1llll1lll=l1ll1ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll1ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll1ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll111l = urllib.parse.unquote(sys.argv[1])
        if l1llll111l:
            l1lll1l1ll=l1lll11lll(l1llll111l)
        else:
            raise (l1ll1ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll1ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise