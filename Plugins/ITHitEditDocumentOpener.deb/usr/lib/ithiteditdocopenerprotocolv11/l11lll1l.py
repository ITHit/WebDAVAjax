#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1111ll = 2048
l1l1111 = 7
def l1ll11ll (l1l11ll):
    global l1111
    l11ll11 = ord (l1l11ll [-1])
    l1lll11 = l1l11ll [:-1]
    l1l = l11ll11 % len (l1lll11)
    l1l111l = l1lll11 [:l1l] + l1lll11 [l1l:]
    if l11l111:
        l11lll = l1ll11 () .join ([unichr (ord (char) - l1111ll - (l1l1l + l11ll11) % l1l1111) for l1l1l, char in enumerate (l1l111l)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1111ll - (l1l1l + l11ll11) % l1l1111) for l1l1l, char in enumerate (l1l111l)])
    return eval (l11lll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111l1 import l111111
from configobj import ConfigObj
l1l1llll = l1ll11ll (u"ࠧࡪࡡࡷ࠳࠴ࠦࡣ")
l1l1l1ll = l1ll11ll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠱ࠪࠢࡇࡅ࡛࠷࠱ࠡࡸ࠹࠲࠵࠴࠸࠺࠳࠳࠲࠵ࠨࡤ")
l11ll1l1 = l1ll11ll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll11ll (u"ࠣ࠸࠱࠴࠳࠾࠹࠲࠲࠱࠴ࠧࡦ")
l1l1l111=os.path.join(os.environ.get(l1ll11ll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll11ll (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll1l1.replace(l1ll11ll (u"ࠦࠥࠨࡩ"), l1ll11ll (u"ࠧࡥࠢࡪ")).lower())
l11ll1ll=os.environ.get(l1ll11ll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll11ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l11111=l1l1l1ll.replace(l1ll11ll (u"ࠣࠢࠥ࡭"), l1ll11ll (u"ࠤࡢࠦ࡮"))+l1ll11ll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll11ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1ll11=os.path.join(os.environ.get(l1ll11ll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l11111)
elif platform.system() == l1ll11ll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll11l=l111111(l1l1l111+l1ll11ll (u"ࠢ࠰ࠤࡳ"))
    l1l1ll11 = os.path.join(l11ll11l, l1l11111)
else:
    l1l1ll11 = os.path.join( l1l11111)
l11ll1ll=l11ll1ll.upper()
if l11ll1ll == l1ll11ll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11ll111=logging.DEBUG
elif l11ll1ll == l1ll11ll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11ll111 = logging.INFO
elif l11ll1ll == l1ll11ll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11ll111 = logging.WARNING
elif l11ll1ll == l1ll11ll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11ll111 = logging.ERROR
elif l11ll1ll == l1ll11ll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11ll111 = logging.CRITICAL
elif l11ll1ll == l1ll11ll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11ll111 = logging.NOTSET
logger = logging.getLogger(l1ll11ll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11ll111)
l11l1lll = logging.FileHandler(l1l1ll11, mode=l1ll11ll (u"ࠣࡹ࠮ࠦࡻ"))
l11l1lll.setLevel(l11ll111)
formatter = logging.Formatter(l1ll11ll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll11ll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11l1lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll111)
l11lllll = SysLogHandler(address=l1ll11ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11lllll.setFormatter(formatter)
logger.addHandler(l11l1lll)
logger.addHandler(ch)
logger.addHandler(l11lllll)
class Settings():
    l1l1ll1l = l1ll11ll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1lll1 = l1ll11ll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111ll = l1ll11ll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l1ll):
        self.l1l11lll = self._1l11l1l(l1l1l1ll)
        self._1l11ll1()
    def _1l11l1l(self, l1l1l1ll):
        l1l1l11l = l1l1l1ll.split(l1ll11ll (u"ࠣࠢࠥࢂ"))
        l1l1l11l = l1ll11ll (u"ࠤࠣࠦࢃ").join(l1l1l11l)
        if platform.system() == l1ll11ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11lll = os.path.join(l1l1l111, l1ll11ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l11l + l1ll11ll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11lll
    def l1l11l11(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll11ll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll11ll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l111l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11ll1(self):
        if not os.path.exists(os.path.dirname(self.l1l11lll)):
            os.makedirs(os.path.dirname(self.l1l11lll))
        if not os.path.exists(self.l1l11lll):
            self.config = ConfigObj(self.l1l11lll)
            self.config[l1ll11ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll11ll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll11ll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111ll
            self.config[l1ll11ll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll11ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll11ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1lll1
            self.config[l1ll11ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll11ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1ll1l
            self.config[l1ll11ll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11lll)
            self.l1l111ll = self.get_value(l1ll11ll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll11ll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1lll1 = self.get_value(l1ll11ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll11ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1ll1l = self.get_value(l1ll11ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll11ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1111l(self):
        l11llll1 = l1ll11ll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1ll1l
        l11llll1 += l1ll11ll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1lll1
        l11llll1 += l1ll11ll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111ll
        return l11llll1
    def __unicode__(self):
        return self._1l1111l()
    def __str__(self):
        return self._1l1111l()
    def __del__(self):
        self.config.write()
l11lll11 = Settings(l1l1l1ll)