#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1lll = 7
def l111ll1 (l11l111):
    global l1lll11l
    l1111ll = ord (l11l111 [-1])
    l1lll1l1 = l11l111 [:-1]
    l1lll1l = l1111ll % len (l1lll1l1)
    l1llll = l1lll1l1 [:l1lll1l] + l1lll1l1 [l1lll1l:]
    if l1l1111:
        l11l1ll = l1lllll () .join ([unichr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l11l1 - (l111ll + l1111ll) % l1ll1lll) for l111ll, char in enumerate (l1llll)])
    return eval (l11l1ll)
import logging
import os
import re
from l1l1l11 import l1lllllll
logger = logging.getLogger(l111ll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111ll1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1l():
    try:
        out = os.popen(l111ll1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l111ll1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l111ll1 (u"ࠤࠥॸ").join(result)
                logger.info(l111ll1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l111ll1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l111ll1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l111ll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lllllll(l111ll1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l111ll1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111111(l111ll1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))