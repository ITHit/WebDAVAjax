#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111l1 = 2048
l1l11l = 7
def l1ll1ll (l11111l):
    global l1ll1
    l1ll1111 = ord (l11111l [-1])
    l11ll1l = l11111l [:-1]
    l11llll = l1ll1111 % len (l11ll1l)
    l1lll111 = l11ll1l [:l11llll] + l11ll1l [l11llll:]
    if l1lll1:
        l1ll11l = l11111 () .join ([unichr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    else:
        l1ll11l = str () .join ([chr (ord (char) - l111l1 - (l1111 + l1ll1111) % l1l11l) for l1111, char in enumerate (l1lll111)])
    return eval (l1ll11l)
import logging
import os
import re
from l1l1ll import l1111l11
logger = logging.getLogger(l1ll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l11l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1ll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l11():
    try:
        out = os.popen(l1ll1ll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1ll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1ll (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1ll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1ll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1ll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1ll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1111l11(l1ll1ll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1ll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l11l(l1ll1ll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))