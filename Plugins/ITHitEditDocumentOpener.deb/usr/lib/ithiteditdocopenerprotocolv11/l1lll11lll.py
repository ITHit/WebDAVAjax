#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11l = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l111 (l11lll):
    global l1ll111
    l11l1l = ord (l11lll [-1])
    l1l11l1 = l11lll [:-1]
    l1ll1l = l11l1l % len (l1l11l1)
    l1lll111 = l1l11l1 [:l1ll1l] + l1l11l1 [l1ll1l:]
    if l11l11l:
        l111 = l1l11 () .join ([unichr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    else:
        l111 = str () .join ([chr (ord (char) - l1lll1 - (l111ll1 + l11l1l) % l1l11l) for l111ll1, char in enumerate (l1lll111)])
    return eval (l111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11ll=logging.WARNING
logger = logging.getLogger(l1l111 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll11ll)
l11ll1ll = SysLogHandler(address=l1l111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l111 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l11ll1ll)
ch = logging.StreamHandler()
ch.setLevel(l1llll11ll)
logger.addHandler(ch)
class l1lllll1l1(io.FileIO):
    l1l111 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l111 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1lll, l1lllllll1,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1lll = l1llll1lll
            self.l1lllllll1 = l1lllllll1
            if not options:
                options = l1l111 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l111 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1lll,
                                              self.l1lllllll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l1l1 = os.path.join(os.path.sep, l1l111 (u"ࠪࡩࡹࡩࠧই"), l1l111 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l111 = path
        else:
            self._1lll1l111 = self.l1lll1l1l1
        super(l1lllll1l1, self).__init__(self._1lll1l111, l1l111 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11l1l(self, line):
        return l1lllll1l1.Entry(*[x for x in line.strip(l1l111 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l111 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l111 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l111 (u"ࠤࠦࠦ঍")):
                    yield self._1lll11l1l(line)
            except ValueError:
                pass
    def l1lllll11l(self, attr, value):
        for entry in self.entries:
            l1llll1l11 = getattr(entry, attr)
            if l1llll1l11 == value:
                return entry
        return None
    def l1llll1l1l(self, entry):
        if self.l1lllll11l(l1l111 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l111 (u"ࠫࡡࡴࠧএ")).encode(l1l111 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1lll1(self, entry):
        self.seek(0)
        lines = [l.decode(l1l111 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l111 (u"ࠢࠤࠤ঒")):
                if self._1lll11l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l111 (u"ࠨࠩও").join(lines).encode(l1l111 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llllll11(cls, l1llll1lll, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1lllll11l(l1l111 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1lll)
        if entry:
            return l1llll1ll1.l1lll1lll1(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1lll, l1lllllll1, options=None, path=None):
        return cls(path=path).l1llll1l1l(l1lllll1l1.Entry(device,
                                                    l1llll1lll, l1lllllll1,
                                                    options=options))
class l1lllll111(object):
    def __init__(self, l1llll11l1):
        self.l1lll1ll1l=l1l111 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1l1ll=l1l111 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll11l1=l1llll11l1
        self.l1lll11l11()
        self.l1lll11111()
        self.l1lll111ll()
        self.l1lll111l1()
        self.l1lll11ll1()
    def l1lll11l11(self):
        temp_file=open(l1lll1ll11,l1l111 (u"࠭ࡲࠨঘ"))
        l1ll1l1l=temp_file.read()
        data=json.loads(l1ll1l1l)
        self.user=data[l1l111 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l111l=data[l1l111 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll=data[l1l111 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l1111=data[l1l111 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll111l=data[l1l111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1111=data[l1l111 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll111ll(self):
        l111l=os.path.join(l1l111 (u"ࠨ࠯ࠣট"),l1l111 (u"ࠢࡶࡵࡵࠦঠ"),l1l111 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l111 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l111 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111l)
    def l1lll11ll1(self):
        logger.info(l1l111 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll=os.path.join(self.l1l1111,self.l1lll1ll1l)
        l1lll1111l = pwd.getpwnam(self.user).pw_uid
        l1llllll1l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll):
            os.makedirs(l1ll)
            os.system(l1l111 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll))
            logger.debug(l1l111 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll)
        else:
            logger.debug(l1l111 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll)
        l111l=os.path.join(l1ll, self.l1lll1l1ll)
        print(l111l)
        logger.debug(l1l111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111l)
        with open(l111l, l1l111 (u"ࠤࡺ࠯ࠧ঩")) as l1lllll1ll:
            logger.debug(self.l1l111l + l1l111 (u"ࠪࠤࠬপ")+self.l1llll111l+l1l111 (u"ࠫࠥࠨࠧফ")+self.l1llll1111+l1l111 (u"ࠬࠨࠧব"))
            l1lllll1ll.writelines(self.l1l111l + l1l111 (u"࠭ࠠࠨভ")+self.l1llll111l+l1l111 (u"ࠧࠡࠤࠪম")+self.l1llll1111+l1l111 (u"ࠨࠤࠪয"))
        os.chmod(l111l, 0o600)
        os.chown(l111l, l1lll1111l, l1llllll1l)
    def l1lll11111(self, l1lll1l11l=l1l111 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l111 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1l11l in groups:
            logger.info(l1l111 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1l11l))
        else:
            logger.warning(l1l111 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1l11l))
            l1llllll=l1l111 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1l11l,self.user)
            logger.debug(l1l111 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1llllll)
            os.system(l1llllll)
            logger.debug(l1l111 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll111l1(self):
        logger.debug(l1l111 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1ll1=l1lllll1l1()
        l1llll1ll1.add(self.l1l111l, self.l1ll, l1lllllll1=l1l111 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l111 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l111 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1ll11 = urllib.parse.unquote(sys.argv[1])
        if l1lll1ll11:
            l1lll1llll=l1lllll111(l1lll1ll11)
        else:
            raise (l1l111 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l111 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise