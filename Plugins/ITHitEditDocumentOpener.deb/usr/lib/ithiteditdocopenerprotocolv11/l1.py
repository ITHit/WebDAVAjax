#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l11 = sys.version_info [0] == 2
l1ll1l = 2048
l11ll11 = 7
def l1llllll (l11l111):
    global l11l11
    l1ll1l11 = ord (l11l111 [-1])
    l1llll = l11l111 [:-1]
    ll = l1ll1l11 % len (l1llll)
    l1ll1 = l1llll [:ll] + l1llll [ll:]
    if l1l1l11:
        l1l111 = l1llll1l () .join ([unichr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    return eval (l1l111)
import gi
gi.require_version(l1llllll (u"ࠨࡉࡷ࡯ࠬঽ"), l1llllll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11lll11
import logging
logger = logging.getLogger(l1llllll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1l1(Gtk.Window):
    def __init__(self, l1l1l11l1l, l1ll1ll1l1):
        Gtk.Window.__init__(self)
        self.l111l=30
        self.l1ll11l1ll = False
        self.service = l1l1l11l1l
        self.l1l1l1=l1ll1ll1l1
        self.l1l1l=l11lll11.l11l1lll
        self.l1l1l1ll1l = Gtk.ListStore(str)
        self.l1ll1lll11()
    def l1ll11ll1l(self, service):
        l1l11lll11 = self.l1l1l.l1l1ll11(l1llllll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l11lll11
    def l1ll1lll11(self, l1l1l11l1l=None):
        if l1l1l11l1l:
            self.l1l1l1ll1l.clear()
            l1ll111l1l=self.l1ll11ll1l(l1l1l11l1l)
            self.l1l1l1ll1l.append([l1llllll (u"ࠧࠨু")])
            for l1l1l1 in l1ll111l1l:
                self.l1l1l1ll1l.append([l1l1l1])
        else:
            self.l1l1l1ll1l.clear()
            self.l1l1l1ll1l.append([l1llllll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1lll1l1(self, widget, data=None):
        l1l1l11ll1= widget.get_active()
        if data == l1llllll (u"ࠢ࠲ࠤৃ") and l1l1l11ll1:
            self.l1ll1lll11()
            self.l1ll111lll.set_active(0)
            self.l1l1l11lll.set_text(l1llllll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l11lll.set_sensitive(False)
            self.l1ll111lll.set_sensitive(False)
        else:
            self.l1ll1lll11(l1l1l11l1l=self.service)
            self.l1ll111lll.set_active(0)
            self.l1l1l11lll.set_text(l1llllll (u"ࠤࠥ৅"))
            self.l1ll111lll.set_sensitive(True)
            self.l1l1l11lll.set_sensitive(True)
    def l1ll1l11l1(self, widget):
        if widget.get_active():
            l1l1l1 = widget.get_child().get_text()
        else:
            l1l1l1 = self.l1l1l1ll1l[widget.get_active()][0]
        password = self.l1l1ll1111(self.service, l1l1l1)
        if password:
            self.l1l1l11lll.set_text(password)
        else:
            self.l1l1l11lll.set_text(l1llllll (u"ࠥࠦ৆"))
    def l1ll111l11(self, l1l1l1, pwd, service):
        keyring.set_password(service, l1l1l1, pwd)
        l1l11lll11=self.l1l1l.l1l1ll11(l1llllll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1l1l1 in l1l11lll11:
            value = self.l1l1l.get_value(l1llllll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l1l.l11llll1(l1llllll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1llllll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1l1l1))
    def l1l1ll1111(self, service, l1l1l1):
        l1l1ll11l1 = keyring.get_password(service, l1l1l1)
        return l1l1ll11l1
    def l1l1lll1ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1llll1(self, widget, data=None):
        self.l1ll11l1ll=widget.get_active()
    def l1lllll(self, message, title=l1llllll (u"ࠨࠩো"), l11111lll=True):
        if l11111lll:
            l1ll1lll1l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lll1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1l1l11l = Gtk.MessageDialog(self,
            l1ll1lll1l,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1l1l11l.set_title(title)
        l1l1l1l11l.set_default_response(Gtk.ResponseType.OK)
        l1l11ll1ll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l11ll111 = Gtk.VBox()
        l1l11l1lll = Gtk.Box(spacing=1)
        l1l11l1lll.set_homogeneous(False)
        l1ll1ll111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1ll111.set_homogeneous(False)
        l1ll111111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll111111.set_homogeneous(False)
        l1l11l1lll.pack_start(l1ll1ll111, True, True, 0)
        l1l11l1lll.pack_start(l1ll111111, True, True, 0)
        l1ll111ll1 = l1l1l1l11l.get_content_area()
        l1l1llllll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll111ll1.pack_start(l1l1llllll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1ll11ll = Gtk.Label()
        l1l11lll1l = Gtk.Label()
        l1l11lll1l.set_text(l1llllll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l11lll1l, True, True, 0)
        l1l1ll11ll.set_text(l1llllll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1ll11ll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1ll11ll, 0, 1, 0, 1)
        l1l1l1l1l1 = Gtk.RadioButton.new_with_label_from_widget(None, l1llllll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1l1l1l1.connect(l1llllll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1lll1l1, l1llllll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1l1l1l1, 1, 2, 0, 1)
        l1ll11l1l1 = Gtk.RadioButton.new_with_label_from_widget(l1l1l1l1l1, l1llllll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll11l1l1.connect(l1llllll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1lll1l1, l1llllll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll11l1l1, 1, 2, 1, 2)
        l1ll1l1ll1 = Gtk.Label()
        l1ll1l1ll1.set_text(l1llllll (u"ࠥࠤࠧ৔"))
        table.attach(l1ll1l1ll1, 0, 1, 4, 6)
        l1l11ll11l = Gtk.Label()
        l1l11ll11l.set_text(l1llllll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l11ll11l.set_justify(Gtk.Justification.RIGHT)
        l1l11ll11l.set_alignment(xalign=1, yalign=0.5)
        self.l1ll111lll = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1ll1l)
        self.l1ll111lll.set_entry_text_column(0)
        table.attach(l1l11ll11l, 0, 1, 6, 8)
        table.attach(self.l1ll111lll, 1, 3, 6, 8)
        self.l1ll111lll.connect(l1llllll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1ll1l11l1)
        l1ll1l1l1l = Gtk.Label()
        l1ll1l1l1l.set_text(l1llllll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1l1l1l.set_justify(Gtk.Justification.RIGHT)
        l1ll1l1l1l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l11lll = Gtk.Entry()
        self.l1l1l11lll.set_visibility(False)
        self.l1l1l11lll.connect(l1llllll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1lll1ll, l1l1l1l11l)
        table.attach(l1ll1l1l1l, 0, 1, 8, 10)
        table.attach(self.l1l1l11lll, 1, 3, 8, 10)
        l1l1ll111l = Gtk.CheckButton(l1llllll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll111l.connect(l1llllll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll1llll1, l1l1ll111l)
        l1l1ll111l.set_active(False)
        table.attach(l1l1ll111l, 1, 3, 12, 14)
        l1l11lllll = Gtk.Label()
        l1l11lllll.set_text(l1llllll (u"ࠥࠤࠧ৛") * 5)
        l1l11ll111.pack_start(l1l11lllll, True, True, 0)
        if self.l1l1l1:
            l1ll11l1l1.set_active(True)
            self.l1ll111lll.set_active(0)
            self.l1ll111lll.set_sensitive(True)
            self.l1l1l11lll.set_text(l1llllll (u"ࠦࠧড়"))
            self.l1l1l11lll.set_sensitive(True)
        else:
            self.l1ll111lll.set_active(0)
            self.l1ll111lll.set_sensitive(False)
            self.l1l1l11lll.set_text(l1llllll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l11lll.set_sensitive(False)
        l1l11ll1ll.pack_start(vbox, True, True, 0)
        l1l11ll1ll.pack_start(table, True, True, 0)
        l1l11ll1ll.pack_end(l1l11ll111, True, True, 0)
        l1l1llllll.pack_start(l1l11ll1ll, True, True, 0)
        l1l1l1l11l.show_all()
        response = l1l1l1l11l.run()
        if self.l1ll111lll.get_active():
            l1l1l1 = self.l1ll111lll.get_child().get_text()
        else:
            l1l1l1 = self.l1l1l1ll1l[self.l1ll111lll.get_active()][0]
        pwd = self.l1l1l11lll.get_text()
        l1l1l1l11l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll11l1ll:
                self.l1ll111l11(l1l1l1, pwd, self.service)
            return l1l1l1, pwd
        else:
            return l1llllll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1llllll (u"ࠧࠨয়")
class l11ll1l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1l1l11(self, l1l11111):
        l1l1lll11l = Gtk.ScrolledWindow()
        l1l1lll11l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1llll11=None
        self.l1l1ll1l1l = Gtk.TextBuffer()
        self.l1l1ll1l1l.set_text(l1l11111)
        self.set_style()
        regexp= l1llllll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll11ll11 = self._1l11l1ll1(l1l11111, regexp)
        self.l1l11ll1l1(l1ll11ll11, self.l1l1ll1l1l.get_start_iter())
        self.l1ll1ll11l = Gtk.TextView(buffer=self.l1l1ll1l1l)
        self.l1ll1ll11l.set_property(l1llllll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll1ll11l.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll1ll11l.connect(l1llllll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll11llll)
        self.l1ll1ll11l.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1lll11l.set_size_request(300,100)
        self.l1ll1ll11l.show()
        l1l1lll11l.add(self.l1ll1ll11l)
        l1l1lll11l.show()
        return l1l1lll11l
    def _1ll11llll(self, *args, **kwargs):
        l1l1l1ll11, l1ll1l111l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l1ll11, l1ll1l111l).get_tags()
        if not self.l1l1llll11:
            self.l1l1llll11 = args[1].window.get_cursor()
            self.l1l1l11l11 = Gdk.Cursor(Gdk.CursorType.l1l11l11ll)
        elif tag:
            args[1].window.set_cursor(self.l1l1l11l11)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1llll11:
                args[1].window.set_cursor(self.l1l1llll11)
    def _1l11l1ll1(self, l1l11111, l1l11l1l1l):
        res=[]
        l1l1l1111l=re.findall(l1l11l1l1l,l1l11111)
        for l1ll11lll1 in l1l1l1111l:
            for el in l1ll11lll1:
                if el:
                    res.append(el)
        return res
    def l1l11ll1l1(self, l1ll11ll11, start):
        l1l11llll1=0
        for text in l1ll11ll11:
            end = self.l1l1ll1l1l.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l11llll1+=1
                l1ll1111ll, l1ll1l1lll = match
                tag = self.l1l1ll1l1l.create_tag(str(l1l11llll1), foreground=l1llllll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1llllll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1l1lll1, text)
                self.l1l1ll1l1l.apply_tag(tag, l1ll1111ll, l1ll1l1lll)
                self.l1l11ll1l1(l1ll11ll11, l1ll1l1lll)
    def _1l1l1lll1(self, tag, widget, l1ll11l111, _1ll1l11ll, text):
        _1l1llll1l = l1ll11l111.type
        _1ll1lllll = l1ll11l111.window
        if _1l1llll1l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1llll1l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll11l111.button
            self.l1l1llll11 = Gdk.Cursor(Gdk.CursorType.l1l11l11ll)
            if _1l1llll1l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1llllll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1111ll11(self, message, title=l1llllll (u"ࠧࠨ০"), l11111lll=True, l1ll11111l=None):
        if l11111lll:
            l1ll1lll1l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lll1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll1lll1l,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll11111l:
            l1ll111ll1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l11l1lll = Gtk.HBox(spacing=0)
            l1l11l1l11 = Gtk.HBox(spacing=5)
            l1l1l111l1 = Gtk.Label()
            l1l1l111l1.set_markup(l1llllll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1l111l1.set_line_wrap(True)
            l1l1l111l1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1llllll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1ll1ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll1ll.show()
            l1l1ll1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1l11.show()
            l1l1l1l1ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l1ll.show()
            l1l11l1lll.pack_start(separator, True, True, 0)
            l1l11l1lll.pack_start(l1ll1ll1ll, True, True, 0)
            l1l11l1lll.pack_start(l1l1ll1l11, True, True, 0)
            l1l11l1lll.pack_start(l1l1l1l1ll, True, True, 0)
            l1l11l1lll.pack_start(l1l1l111l1, False, True, 0)
            l1l1l111ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l111ll.show()
            l1l11l1lll.pack_end(l1l1l111ll, True, True, 0)
            l1ll11l11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11l11l.show()
            vbox.pack_start(l1l11l1lll, True, True, 0)
            l1l1lll11l=self.__1ll1l1l11(l1l11111=l1ll11111l)
            vbox.pack_start(l1l1lll11l, False, False, 0)
            vbox.pack_end(l1ll11l11l, False, False, 0)
            l1l11l1l11.pack_start(vbox, True, True,5)
            l1l11l1l11.show()
            l1ll111ll1.pack_end(l1l11l1l11, False, False, 0)
            vbox.show()
            l1l11l1lll.show()
        window.run()
class l1l1l1l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll1111l1(self, widget, l1l1ll1ll1):
        if l1l1ll1ll1 == Gtk.ResponseType.OK:
            self.result = l1llllll (u"ࠥࡓࡐࠨ৩")
        elif l1l1ll1ll1 == Gtk.ResponseType.CANCEL:
            self.result = l1llllll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1ll1ll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1llllll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11111l11(self, title=l1llllll (u"ࠨࠢ৬"), message=l1llllll (u"ࠢࠣ৭") , l11111lll=True):
        if l11111lll:
            l1ll1lll1l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lll1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1lll1l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1llllll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll1111l1)
        window.run()
class l1l1ll1lll(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1l1111=None
        self.result = None
    def l1ll1111l1(self, widget, l1l1ll1ll1):
        print(widget, l1l1ll1ll1)
        if l1l1ll1ll1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1ll1ll1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1ll1ll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1llll1(self, widget, l1l1l11111):
        if l1l1l11111.get_active():
            self.l1ll1l1111 = 1
        else:
            self.l1ll1l1111 = 0
    def l1l1lll111(self, title=l1llllll (u"ࠤࠥ৯"), message=l1llllll (u"ࠥࠦৰ"), l1l1l1llll =l1llllll (u"ࠦࠧৱ"),l11111lll=True):
        if l11111lll:
            l1ll1lll1l= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lll1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1lll1l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1llllll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll1111l1)
        l1l1ll111l = Gtk.CheckButton(l1l1l1llll)
        l1l1ll111l.connect(l1llllll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll1llll1, l1l1ll111l)
        l1l1ll111l.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll111l, expand=True, fill=True, padding=0)
        l1l1ll111l.show()
        window.run()
def l1ll11l11(title, msg, l1l1l1llll=l1llllll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11111lll=True):
    result=None
    try:
        l1l1lllll1 = l1l1ll1lll()
        l1l1lllll1.l1l1lll111(title, msg, l1l1l1llll, l11111lll)
        result = {l1llllll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1lllll1.result,  l1llllll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1lllll1.l1ll1l1111}
    except Exception as e:
        logger.exception(l1llllll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1llllll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1l11l111 = l11ll1l11()
    message= l1llllll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1l1l111 = l1llllll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1l11l111.l1111ll11(message, l1llllll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11111lll=True, l1ll11111l=l1l1l1l111)