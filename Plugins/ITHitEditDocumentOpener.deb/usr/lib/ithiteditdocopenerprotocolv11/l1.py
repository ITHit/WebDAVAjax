#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll11 = sys.version_info [0] == 2
l1111l = 2048
l11l11l = 7
def l111l (l1lll):
    global l1l11l
    l1lll1l = ord (l1lll [-1])
    l11ll1 = l1lll [:-1]
    l11l = l1lll1l % len (l11ll1)
    l1l = l11ll1 [:l11l] + l11ll1 [l11l:]
    if l1lll11:
        l1lll1 = l1ll11ll () .join ([unichr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l1lll1l) % l11l11l) for l1ll1l, char in enumerate (l1l)])
    return eval (l1lll1)
import hashlib
import os
import l11111l
from l1ll111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11111l import l1ll1
from l111l1l import l11l1ll, l1ll1111
import logging
logger = logging.getLogger(l111l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11ll():
    def __init__(self, l111ll,l1l111, l111111= None, l1111ll=None):
        self.l11l1l1=False
        self.l1l11l1 = self._11l1()
        self.l1l111 = l1l111
        self.l111111 = l111111
        self.l1ll1lll = l111ll
        if l111111:
            self.l11lll1 = True
        else:
            self.l11lll1 = False
        self.l1111ll = l1111ll
    def _11l1(self):
        try:
            return l11111l.l1ll1ll1() is not None
        except:
            return False
    def open(self):
        l111l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l11l1:
            raise NotImplementedError(l111l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1l11 = self.l1ll1lll
        if self.l1l111.lower().startswith(self.l1ll1lll.lower()):
            l1ll = re.compile(re.escape(self.l1ll1lll), re.IGNORECASE)
            l1l111 = l1ll.sub(l111l (u"ࠨࠩࠄ"), self.l1l111)
            l1l111 = l1l111.replace(l111l (u"ࠩࡧࡥࡻ࠭ࠅ"), l111l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l111l1(self.l1ll1lll, l1ll1l11, l1l111, self.l111111)
    def l111l1(self,l1ll1lll, l1ll1l11, l1l111, l111111):
        l111l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1111l1 = l11111(l1ll1lll)
        l111ll1 = self.ll(l1111l1)
        logger.info(l111l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1111l1)
        if l111ll1:
            logger.info(l111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1(l1111l1)
            l1111l1 = l11lll(l1ll1lll, l1ll1l11, l111111, self.l1111ll)
        logger.debug(l111l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1l1=l1111l1 + l111l (u"ࠤ࠲ࠦࠌ") + l1l111
        l111 = l111l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1l1+ l111l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111)
        l1ll11l1 = os.system(l111)
        if (l1ll11l1 != 0):
            raise IOError(l111l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1l1, l1ll11l1))
    def ll(self, l1111l1):
        if os.path.exists(l1111l1):
            if os.path.islink(l1111l1):
                l1111l1 = os.readlink(l1111l1)
            if os.path.ismount(l1111l1):
                return True
        return False
def l11111(l1ll1lll):
    l1lllll = l1ll1lll.replace(l111l (u"࠭࡜࡝ࠩࠐ"), l111l (u"ࠧࡠࠩࠑ")).replace(l111l (u"ࠨ࠱ࠪࠒ"), l111l (u"ࠩࡢࠫࠓ"))
    l11ll1l = l111l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11=os.environ[l111l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llll1l=os.path.join(l11,l11ll1l, l1lllll)
    l1lll1ll=os.path.abspath(l1llll1l)
    return l1lll1ll
def l1l111l(l1ll1ll):
    if not os.path.exists(l1ll1ll):
        os.makedirs(l1ll1ll)
def l1l1(l1ll1lll, l1ll1l11, l1ll111l=None, password=None):
    l111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll1ll = l11111(l1ll1lll)
    l1l111l(l1ll1ll)
    if not l1ll111l:
        l1l1111 = l1ll1l1l()
        l1l1ll1 =l1l1111.l1ll1l1(l111l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1l11 + l111l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1l11 + l111l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l1ll1, str):
            l1ll111l, password = l1l1ll1
        else:
            raise l1ll1111()
        logger.info(l111l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll1ll))
    l11llll = pwd.getpwuid( os.getuid())[0]
    l1111=os.environ[l111l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1l1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l11={l111l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11llll, l111l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1lll, l111l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll1ll, l111l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1111, l111l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll111l, l111l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l11, temp_file)
        if not os.path.exists(os.path.join(l1l1l1l, l111l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll11l=l111l (u"ࠦࡵࡿࠢࠣ")
            key=l111l (u"ࠧࠨࠤ")
        else:
            l1lll11l=l111l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1l11=l111l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll11l,temp_file.name)
        l1l11ll=[l111l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1l1l, l1l1l11)]
        p = subprocess.Popen(l1l11ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll1ll
    logger.debug(l111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll1ll=os.path.abspath(l1ll1ll)
    logger.debug(l111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll1ll)
    return l1lll1ll
def l11lll(l1ll1lll, l1ll1l11, l111111, l1111ll):
    l111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1llll11(title):
        l1l1l=30
        if len(title)>l1l1l:
            l1llll=title.split(l111l (u"ࠨ࠯ࠣ࠳"))
            l111lll=l111l (u"ࠧࠨ࠴")
            for block in l1llll:
                l111lll+=block+l111l (u"ࠣ࠱ࠥ࠵")
                if len(l111lll) > l1l1l:
                    l111lll+=l111l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111lll
        return title
    def l1lll1l1(l1ll11l, password):
        l111l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111l (u"ࠧࠦࠢ࠹").join(l1ll11l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1lllll1 = l111l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1lllll1.encode())
        l1l1ll = [l111l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11l1l = l111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11l1l)
            for e in l1l1ll:
                if e in l11l1l: return False
            raise l11l1ll(l11l1l, l11lll=l11111l.l1ll1ll1(), l1ll1l11=l1ll1l11)
        logger.info(l111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1ll111l = l111l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111l (u"ࠦࠧ࠿")
    os.system(l111l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11l111 = l11111(l1ll1lll)
    l1ll1ll = l11111(hashlib.sha1(l1ll1lll.encode()).hexdigest()[:10])
    l1l111l(l1ll1ll)
    logger.info(l111l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll1ll))
    if l111111:
        l1ll11l = [l111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111l (u"ࠤ࠰ࡸࠧࡄ"), l111l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111l (u"ࠫ࠲ࡵࠧࡆ"), l111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1ll111l, l111111),
                    urllib.parse.unquote(l1ll1l11), os.path.abspath(l1ll1ll)]
        l1lll1l1(l1ll11l, password)
    else:
        while True:
            l1ll111l, password = l1l1lll(l1ll1ll, l1ll1l11, l1111ll)
            if l1ll111l.lower() != l111l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll11l = [l111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111l (u"ࠤ࠰ࡸࠧࡋ"), l111l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111l (u"ࠫ࠲ࡵࠧࡍ"), l111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1ll111l,
                            urllib.parse.unquote(l1ll1l11), os.path.abspath(l1ll1ll)]
            else:
                raise l1ll1111()
            if l1lll1l1(l1ll11l, password): break
    os.system(l111l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll1ll, l11l111))
    l1lll1ll=os.path.abspath(l11l111)
    return l1lll1ll
def l1l1lll(l1ll1lll, l1ll1l11, l1111ll):
    l1llll1 = os.path.join(os.environ[l111l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1llll1)):
       os.makedirs(os.path.dirname(l1llll1))
    l1lll111 = l1111ll.get_value(l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l1111 = l1ll1l1l(l1ll1lll, l1lll111)
    l1ll111l, password = l1l1111.l1ll1l1(l111l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1l11 + l111l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1l11 + l111l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1ll111l != l111l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1llllll(l1ll1lll, l1ll111l):
        l11l11 = l111l (u"ࠤ࡙ࠣࠦ").join([l1ll1lll, l1ll111l, l111l (u"࡚ࠪࠦࠬ") + password + l111l (u"࡛ࠫࠧ࠭"), l111l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1llll1, l111l (u"࠭ࡷࠬࠩ࡝")) as l1ll11:
            l1ll11.write(l11l11)
        os.chmod(l1llll1, 0o600)
    return l1ll111l, password
def l1llllll(l1ll1lll, l1ll111l):
    l1llll1 = l111l11 = os.path.join(os.environ[l111l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1llll1):
        with open(l1llll1, l111l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11ll11 = data[0].split(l111l (u"ࠦࠥࠨࡢ"))
            if l1ll1lll == l11ll11[0] and l1ll111l == l11ll11[1]:
                return True
    return False