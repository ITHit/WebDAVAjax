#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l111 = sys.version_info [0] == 2
l1ll1111 = 2048
l1ll111 = 7
def l1lll11 (l1111l1):
    global l11lll1
    l11l1ll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l1ll1ll1 = l11l1ll % len (l1l1l11)
    l1llll1l = l1l1l11 [:l1ll1ll1] + l1l1l11 [l1ll1ll1:]
    if l11l111:
        l1lll1 = l1111 () .join ([unichr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1ll1111 - (l1l111l + l11l1ll) % l1ll111) for l1l111l, char in enumerate (l1llll1l)])
    return eval (l1lll1)
import hashlib
import os
import l1l1
from l1ll1l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1 import l1l1l
from l1l1111 import l1l111, l1lll
import logging
logger = logging.getLogger(l1lll11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l():
    def __init__(self, l1ll11ll,l1llll, l1llll11= None, l1111ll=None):
        self.l1lll11l=False
        self.l11l1 = self._111ll1()
        self.l1llll = l1llll
        self.l1llll11 = l1llll11
        self.l11ll1 = l1ll11ll
        if l1llll11:
            self.l1l11l1 = True
        else:
            self.l1l11l1 = False
        self.l1111ll = l1111ll
    def _111ll1(self):
        try:
            return l1l1.l11ll() is not None
        except:
            return False
    def open(self):
        l1lll11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l1:
            raise NotImplementedError(l1lll11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1 = self.l11ll1
        if self.l1llll.lower().startswith(self.l11ll1.lower()):
            l1ll1l11 = re.compile(re.escape(self.l11ll1), re.IGNORECASE)
            l1llll = l1ll1l11.sub(l1lll11 (u"ࠨࠩࠄ"), self.l1llll)
            l1llll = l1llll.replace(l1lll11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1ll(self.l11ll1, l1ll1, l1llll, self.l1llll11)
    def l1l1ll(self,l11ll1, l1ll1, l1llll, l1llll11):
        l1lll11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll1ll = l111ll(l11ll1)
        l1l1l1 = self.l1(l1lll1ll)
        logger.info(l1lll11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll1ll)
        if l1l1l1:
            logger.info(l1lll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1l(l1lll1ll)
            l1lll1ll = l111lll(l11ll1, l1ll1, l1llll11, self.l1111ll)
        logger.debug(l1lll11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1ll=l1lll1ll + l1lll11 (u"ࠤ࠲ࠦࠌ") + l1llll
        l1ll11l = l1lll11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1ll+ l1lll11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll11l)
        l11111l = os.system(l1ll11l)
        if (l11111l != 0):
            raise IOError(l1lll11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1ll, l11111l))
    def l1(self, l1lll1ll):
        if os.path.exists(l1lll1ll):
            if os.path.islink(l1lll1ll):
                l1lll1ll = os.readlink(l1lll1ll)
            if os.path.ismount(l1lll1ll):
                return True
        return False
def l111ll(l11ll1):
    l1ll1lll = l11ll1.replace(l1lll11 (u"࠭࡜࡝ࠩࠐ"), l1lll11 (u"ࠧࡠࠩࠑ")).replace(l1lll11 (u"ࠨ࠱ࠪࠒ"), l1lll11 (u"ࠩࡢࠫࠓ"))
    l1l1ll1 = l1lll11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l=os.environ[l1lll11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1l1=os.path.join(l11l,l1l1ll1, l1ll1lll)
    l1ll1l1l=os.path.abspath(l1ll1l1)
    return l1ll1l1l
def l1111l(l11):
    if not os.path.exists(l11):
        os.makedirs(l11)
def l111l11(l11ll1, l1ll1, l11l1l=None, password=None):
    l1lll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11 = l111ll(l11ll1)
    l1111l(l11)
    if not l11l1l:
        l1l11l = l111l()
        l1ll11l1 =l1l11l.l11llll(l1lll11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1 + l1lll11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1 + l1lll11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11l1, str):
            l11l1l, password = l1ll11l1
        else:
            raise l1lll()
        logger.info(l1lll11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11))
    l1llllll = pwd.getpwuid( os.getuid())[0]
    l11111=os.environ[l1lll11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11ll1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l11={l1lll11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1llllll, l1lll11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll1, l1lll11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11, l1lll11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11111, l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l1l, l1lll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l11, temp_file)
        if not os.path.exists(os.path.join(l11ll1l, l1lll11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11lll=l1lll11 (u"ࠦࡵࡿࠢࠣ")
            key=l1lll11 (u"ࠧࠨࠤ")
        else:
            l11lll=l1lll11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111111=l1lll11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11lll,temp_file.name)
        ll=[l1lll11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11ll1l, l111111)]
        p = subprocess.Popen(ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11
    logger.debug(l1lll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll1l1l=os.path.abspath(l11)
    logger.debug(l1lll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll1l1l)
    return l1ll1l1l
def l111lll(l11ll1, l1ll1, l1llll11, l1111ll):
    l1lll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l111(title):
        l1lll1l=30
        if len(title)>l1lll1l:
            l11ll11=title.split(l1lll11 (u"ࠨ࠯ࠣ࠳"))
            l111l1=l1lll11 (u"ࠧࠨ࠴")
            for block in l11ll11:
                l111l1+=block+l1lll11 (u"ࠣ࠱ࠥ࠵")
                if len(l111l1) > l1lll1l:
                    l111l1+=l1lll11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111l1
        return title
    def l11l1l1(l1lllll1, password):
        l1lll11 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll11 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll11 (u"ࠧࠦࠢ࠹").join(l1lllll1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll111l = l1lll11 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll111l.encode())
        l11l11 = [l1lll11 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1llll1 = l1lll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1llll1)
            for e in l11l11:
                if e in l1llll1: return False
            raise l1l111(l1llll1, l111lll=l1l1.l11ll(), l1ll1=l1ll1)
        logger.info(l1lll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11l1l = l1lll11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll11 (u"ࠦࠧ࠿")
    os.system(l1lll11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11l11l = l111ll(l11ll1)
    l11 = l111ll(hashlib.sha1(l11ll1.encode()).hexdigest()[:10])
    l1111l(l11)
    logger.info(l1lll11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11))
    if l1llll11:
        l1lllll1 = [l1lll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll11 (u"ࠤ࠰ࡸࠧࡄ"), l1lll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll11 (u"ࠫ࠲ࡵࠧࡆ"), l1lll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11l1l, l1llll11),
                    urllib.parse.unquote(l1ll1), os.path.abspath(l11)]
        l11l1l1(l1lllll1, password)
    else:
        while True:
            l11l1l, password = l1lll1l1(l11, l1ll1, l1111ll)
            if l11l1l.lower() != l1lll11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1lllll1 = [l1lll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll11 (u"ࠤ࠰ࡸࠧࡋ"), l1lll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll11 (u"ࠫ࠲ࡵࠧࡍ"), l1lll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11l1l,
                            urllib.parse.unquote(l1ll1), os.path.abspath(l11)]
            else:
                raise l1lll()
            if l11l1l1(l1lllll1, password): break
    os.system(l1lll11 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11, l11l11l))
    l1ll1l1l=os.path.abspath(l11l11l)
    return l1ll1l1l
def l1lll1l1(l11ll1, l1ll1, l1111ll):
    l1lllll = os.path.join(os.environ[l1lll11 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lllll)):
       os.makedirs(os.path.dirname(l1lllll))
    l1l1l1l = l1111ll.get_value(l1lll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll11 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l11l = l111l(l11ll1, l1l1l1l)
    l11l1l, password = l1l11l.l11llll(l1lll11 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1 + l1lll11 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1 + l1lll11 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11l1l != l1lll11 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l1lll(l11ll1, l11l1l):
        l1lll111 = l1lll11 (u"ࠤ࡙ࠣࠦ").join([l11ll1, l11l1l, l1lll11 (u"࡚ࠪࠦࠬ") + password + l1lll11 (u"࡛ࠫࠧ࠭"), l1lll11 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lllll, l1lll11 (u"࠭ࡷࠬࠩ࡝")) as l111l1l:
            l111l1l.write(l1lll111)
        os.chmod(l1lllll, 0o600)
    return l11l1l, password
def l1l1lll(l11ll1, l11l1l):
    l1lllll = l1ll = os.path.join(os.environ[l1lll11 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lllll):
        with open(l1lllll, l1lll11 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll11 = data[0].split(l1lll11 (u"ࠦࠥࠨࡢ"))
            if l11ll1 == l1ll11[0] and l11l1l == l1ll11[1]:
                return True
    return False