#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import gi
gi.require_version(l1l1l1l (u"ࠨࡉࡷ࡯ࠬঽ"), l1l1l1l (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l11ll1
import logging
logger = logging.getLogger(l1l1l1l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l111lll(Gtk.Window):
    def __init__(self, l1ll1111ll, l1l1l1l11l):
        Gtk.Window.__init__(self)
        self.l1ll1l=30
        self.l1l11ll111 = False
        self.service = l1ll1111ll
        self.l11ll11=l1l1l1l11l
        self.l111ll1=l1l11ll1.l1l11111
        self.l1ll1111l1 = Gtk.ListStore(str)
        self.l1l1l11l11()
    def l1ll1lll11(self, service):
        l1ll111l11 = self.l111ll1.l11lll1l(l1l1l1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll111l11
    def l1l1l11l11(self, l1ll1111ll=None):
        if l1ll1111ll:
            self.l1ll1111l1.clear()
            l1l1l1lll1=self.l1ll1lll11(l1ll1111ll)
            self.l1ll1111l1.append([l1l1l1l (u"ࠧࠨু")])
            for l11ll11 in l1l1l1lll1:
                self.l1ll1111l1.append([l11ll11])
        else:
            self.l1ll1111l1.clear()
            self.l1ll1111l1.append([l1l1l1l (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll1llll1(self, widget, data=None):
        l1l1l11l1l= widget.get_active()
        if data == l1l1l1l (u"ࠢ࠲ࠤৃ") and l1l1l11l1l:
            self.l1l1l11l11()
            self.l1ll1ll11l.set_active(0)
            self.l1ll1lllll.set_text(l1l1l1l (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1lllll.set_sensitive(False)
            self.l1ll1ll11l.set_sensitive(False)
        else:
            self.l1l1l11l11(l1ll1111ll=self.service)
            self.l1ll1ll11l.set_active(0)
            self.l1ll1lllll.set_text(l1l1l1l (u"ࠤࠥ৅"))
            self.l1ll1ll11l.set_sensitive(True)
            self.l1ll1lllll.set_sensitive(True)
    def l1l1l1l1l1(self, widget):
        if widget.get_active():
            l11ll11 = widget.get_child().get_text()
        else:
            l11ll11 = self.l1ll1111l1[widget.get_active()][0]
        password = self.l1ll11lll1(self.service, l11ll11)
        if password:
            self.l1ll1lllll.set_text(password)
        else:
            self.l1ll1lllll.set_text(l1l1l1l (u"ࠥࠦ৆"))
    def l1ll111111(self, l11ll11, pwd, service):
        keyring.set_password(service, l11ll11, pwd)
        l1ll111l11=self.l111ll1.l11lll1l(l1l1l1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11ll11 in l1ll111l11:
            value = self.l111ll1.get_value(l1l1l1l (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l111ll1.l1l1l1ll(l1l1l1l (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1l1l1l (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11ll11))
    def l1ll11lll1(self, service, l11ll11):
        l1l1ll1111 = keyring.get_password(service, l11ll11)
        return l1l1ll1111
    def l1l1l1l1ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1llllll(self, widget, data=None):
        self.l1l11ll111=widget.get_active()
    def l1ll1l1(self, message, title=l1l1l1l (u"ࠨࠩো"), l11ll1l11=True):
        if l11ll1l11:
            l1l1ll11l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1l1l111 = Gtk.MessageDialog(self,
            l1l1ll11l1,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1l1l111.set_title(title)
        l1l1l1l111.set_default_response(Gtk.ResponseType.OK)
        l1l1ll1l11 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll1l1l1l = Gtk.VBox()
        l1ll11111l = Gtk.Box(spacing=1)
        l1ll11111l.set_homogeneous(False)
        l1l1lllll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lllll1.set_homogeneous(False)
        l1l1ll1ll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1ll1ll1.set_homogeneous(False)
        l1ll11111l.pack_start(l1l1lllll1, True, True, 0)
        l1ll11111l.pack_start(l1l1ll1ll1, True, True, 0)
        l1ll1l1ll1 = l1l1l1l111.get_content_area()
        l1l11l11ll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll1l1ll1.pack_start(l1l11l11ll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1lll1ll = Gtk.Label()
        l1l1ll1lll = Gtk.Label()
        l1l1ll1lll.set_text(l1l1l1l (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1ll1lll, True, True, 0)
        l1l1lll1ll.set_text(l1l1l1l (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1lll1ll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1lll1ll, 0, 1, 0, 1)
        l1l1llll1l = Gtk.RadioButton.new_with_label_from_widget(None, l1l1l1l (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1llll1l.connect(l1l1l1l (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll1llll1, l1l1l1l (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1llll1l, 1, 2, 0, 1)
        l1ll111ll1 = Gtk.RadioButton.new_with_label_from_widget(l1l1llll1l, l1l1l1l (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll111ll1.connect(l1l1l1l (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll1llll1, l1l1l1l (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll111ll1, 1, 2, 1, 2)
        l1l1ll1l1l = Gtk.Label()
        l1l1ll1l1l.set_text(l1l1l1l (u"ࠥࠤࠧ৔"))
        table.attach(l1l1ll1l1l, 0, 1, 4, 6)
        l1l11lll1l = Gtk.Label()
        l1l11lll1l.set_text(l1l1l1l (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l11lll1l.set_justify(Gtk.Justification.RIGHT)
        l1l11lll1l.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1ll11l = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1111l1)
        self.l1ll1ll11l.set_entry_text_column(0)
        table.attach(l1l11lll1l, 0, 1, 6, 8)
        table.attach(self.l1ll1ll11l, 1, 3, 6, 8)
        self.l1ll1ll11l.connect(l1l1l1l (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1l1l1l1)
        l1l1l1ll1l = Gtk.Label()
        l1l1l1ll1l.set_text(l1l1l1l (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l1l1ll1l.set_justify(Gtk.Justification.RIGHT)
        l1l1l1ll1l.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1lllll = Gtk.Entry()
        self.l1ll1lllll.set_visibility(False)
        self.l1ll1lllll.connect(l1l1l1l (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1l1l1ll, l1l1l1l111)
        table.attach(l1l1l1ll1l, 0, 1, 8, 10)
        table.attach(self.l1ll1lllll, 1, 3, 8, 10)
        l1l11ll11l = Gtk.CheckButton(l1l1l1l (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l11ll11l.connect(l1l1l1l (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1llllll, l1l11ll11l)
        l1l11ll11l.set_active(False)
        table.attach(l1l11ll11l, 1, 3, 12, 14)
        l1l1ll111l = Gtk.Label()
        l1l1ll111l.set_text(l1l1l1l (u"ࠥࠤࠧ৛") * 5)
        l1ll1l1l1l.pack_start(l1l1ll111l, True, True, 0)
        if self.l11ll11:
            l1ll111ll1.set_active(True)
            self.l1ll1ll11l.set_active(0)
            self.l1ll1ll11l.set_sensitive(True)
            self.l1ll1lllll.set_text(l1l1l1l (u"ࠦࠧড়"))
            self.l1ll1lllll.set_sensitive(True)
        else:
            self.l1ll1ll11l.set_active(0)
            self.l1ll1ll11l.set_sensitive(False)
            self.l1ll1lllll.set_text(l1l1l1l (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1lllll.set_sensitive(False)
        l1l1ll1l11.pack_start(vbox, True, True, 0)
        l1l1ll1l11.pack_start(table, True, True, 0)
        l1l1ll1l11.pack_end(l1ll1l1l1l, True, True, 0)
        l1l11l11ll.pack_start(l1l1ll1l11, True, True, 0)
        l1l1l1l111.show_all()
        response = l1l1l1l111.run()
        if self.l1ll1ll11l.get_active():
            l11ll11 = self.l1ll1ll11l.get_child().get_text()
        else:
            l11ll11 = self.l1ll1111l1[self.l1ll1ll11l.get_active()][0]
        pwd = self.l1ll1lllll.get_text()
        l1l1l1l111.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l11ll111:
                self.l1ll111111(l11ll11, pwd, self.service)
            return l11ll11, pwd
        else:
            return l1l1l1l (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1l1l1l (u"ࠧࠨয়")
class l1l11ll1l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l11l1lll(self, l11l1lll):
        l1l1ll11ll = Gtk.ScrolledWindow()
        l1l1ll11ll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1l11ll1=None
        self.l1ll1l1l11 = Gtk.TextBuffer()
        self.l1ll1l1l11.set_text(l11l1lll)
        self.set_style()
        regexp= l1l1l1l (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll1lll1l = self._1l11l1l1l(l11l1lll, regexp)
        self.l1l1l111ll(l1ll1lll1l, self.l1ll1l1l11.get_start_iter())
        self.l1l11l1l11 = Gtk.TextView(buffer=self.l1ll1l1l11)
        self.l1l11l1l11.set_property(l1l1l1l (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l11l1l11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11l1l11.connect(l1l1l1l (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll1l1lll)
        self.l1l11l1l11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1ll11ll.set_size_request(300,100)
        self.l1l11l1l11.show()
        l1l1ll11ll.add(self.l1l11l1l11)
        l1l1ll11ll.show()
        return l1l1ll11ll
    def _1ll1l1lll(self, *args, **kwargs):
        l1ll1ll1l1, l1l11llll1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1ll1l1, l1l11llll1).get_tags()
        if not self.l1l1l11ll1:
            self.l1l1l11ll1 = args[1].window.get_cursor()
            self.l1ll1l11l1 = Gdk.Cursor(Gdk.CursorType.l1ll11l11l)
        elif tag:
            args[1].window.set_cursor(self.l1ll1l11l1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1l11ll1:
                args[1].window.set_cursor(self.l1l1l11ll1)
    def _1l11l1l1l(self, l11l1lll, l1l11ll1ll):
        res=[]
        l1ll11l1ll=re.findall(l1l11ll1ll,l11l1lll)
        for l1l11l1ll1 in l1ll11l1ll:
            for el in l1l11l1ll1:
                if el:
                    res.append(el)
        return res
    def l1l1l111ll(self, l1ll1lll1l, start):
        l1ll1ll1ll=0
        for text in l1ll1lll1l:
            end = self.l1ll1l1l11.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1ll1ll+=1
                l1ll11l1l1, l1ll111l1l = match
                tag = self.l1ll1l1l11.create_tag(str(l1ll1ll1ll), foreground=l1l1l1l (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1l1l1l (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll11llll, text)
                self.l1ll1l1l11.apply_tag(tag, l1ll11l1l1, l1ll111l1l)
                self.l1l1l111ll(l1ll1lll1l, l1ll111l1l)
    def _1ll11llll(self, tag, widget, l1ll1l11ll, _1l1l11111, text):
        _1l1l1111l = l1ll1l11ll.type
        _1ll11ll1l = l1ll1l11ll.window
        if _1l1l1111l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l1111l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll1l11ll.button
            self.l1l1l11ll1 = Gdk.Cursor(Gdk.CursorType.l1ll11l11l)
            if _1l1l1111l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1l1l1l (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1ll1111l(self, message, title=l1l1l1l (u"ࠧࠨ০"), l11ll1l11=True, l1l1l11lll=None):
        if l11ll1l11:
            l1l1ll11l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1ll11l1,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1l11lll:
            l1ll1l1ll1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll11111l = Gtk.HBox(spacing=0)
            l1l1lll111 = Gtk.HBox(spacing=5)
            l1l1lll1l1 = Gtk.Label()
            l1l1lll1l1.set_markup(l1l1l1l (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1lll1l1.set_line_wrap(True)
            l1l1lll1l1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1l1l1l (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l11lllll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lllll.show()
            l1l1lll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll11l.show()
            l1ll1ll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll111.show()
            l1ll11111l.pack_start(separator, True, True, 0)
            l1ll11111l.pack_start(l1l11lllll, True, True, 0)
            l1ll11111l.pack_start(l1l1lll11l, True, True, 0)
            l1ll11111l.pack_start(l1ll1ll111, True, True, 0)
            l1ll11111l.pack_start(l1l1lll1l1, False, True, 0)
            l1ll1l111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l111l.show()
            l1ll11111l.pack_end(l1ll1l111l, True, True, 0)
            l1l11ll1l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll1l1.show()
            vbox.pack_start(l1ll11111l, True, True, 0)
            l1l1ll11ll=self.__1l11l1lll(l11l1lll=l1l1l11lll)
            vbox.pack_start(l1l1ll11ll, False, False, 0)
            vbox.pack_end(l1l11ll1l1, False, False, 0)
            l1l1lll111.pack_start(vbox, True, True,5)
            l1l1lll111.show()
            l1ll1l1ll1.pack_end(l1l1lll111, False, False, 0)
            vbox.show()
            l1ll11111l.show()
        window.run()
class l1l11l1ll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll1l1111(self, widget, l1l1l1ll11):
        if l1l1l1ll11 == Gtk.ResponseType.OK:
            self.result = l1l1l1l (u"ࠥࡓࡐࠨ৩")
        elif l1l1l1ll11 == Gtk.ResponseType.CANCEL:
            self.result = l1l1l1l (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1l1ll11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1l1l1l (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11lll111(self, title=l1l1l1l (u"ࠨࠢ৬"), message=l1l1l1l (u"ࠢࠣ৭") , l11ll1l11=True):
        if l11ll1l11:
            l1l1ll11l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll11l1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1l1l1l (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll1l1111)
        window.run()
class l1l11lll11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1llll=None
        self.result = None
    def l1ll1l1111(self, widget, l1l1l1ll11):
        print(widget, l1l1l1ll11)
        if l1l1l1ll11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l1ll11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l1ll11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1llllll(self, widget, l1ll11l111):
        if l1ll11l111.get_active():
            self.l1l1l1llll = 1
        else:
            self.l1l1l1llll = 0
    def l1ll111lll(self, title=l1l1l1l (u"ࠤࠥ৯"), message=l1l1l1l (u"ࠥࠦৰ"), l1l1llll11 =l1l1l1l (u"ࠦࠧৱ"),l11ll1l11=True):
        if l11ll1l11:
            l1l1ll11l1= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll11l1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1l1l1l (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll1l1111)
        l1l11ll11l = Gtk.CheckButton(l1l1llll11)
        l1l11ll11l.connect(l1l1l1l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1llllll, l1l11ll11l)
        l1l11ll11l.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l11ll11l, expand=True, fill=True, padding=0)
        l1l11ll11l.show()
        window.run()
def l1l1111ll(title, msg, l1l1llll11=l1l1l1l (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11ll1l11=True):
    result=None
    try:
        l1l1l111l1 = l1l11lll11()
        l1l1l111l1.l1ll111lll(title, msg, l1l1llll11, l11ll1l11)
        result = {l1l1l1l (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1l111l1.result,  l1l1l1l (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1l111l1.l1l1l1llll}
    except Exception as e:
        logger.exception(l1l1l1l (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1l1l1l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l111lll11 = l1l11ll1l()
    message= l1l1l1l (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll11ll11 = l1l1l1l (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l111lll11.l1ll1111l(message, l1l1l1l (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11ll1l11=True, l1l1l11lll=l1ll11ll11)