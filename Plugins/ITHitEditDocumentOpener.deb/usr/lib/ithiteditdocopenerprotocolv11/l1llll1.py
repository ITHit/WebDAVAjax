#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1lll = sys.version_info [0] == 2
l11lll1 = 2048
l1ll111l = 7
def l111111 (l1111ll):
    global l1lll111
    l1lllll1 = ord (l1111ll [-1])
    l1lll1ll = l1111ll [:-1]
    l1111l1 = l1lllll1 % len (l1lll1ll)
    l1l11ll = l1lll1ll [:l1111l1] + l1lll1ll [l1111l1:]
    if l1ll1lll:
        l1l1l1l = l1l111 () .join ([unichr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    else:
        l1l1l1l = str () .join ([chr (ord (char) - l11lll1 - (l11l11 + l1lllll1) % l1ll111l) for l11l11, char in enumerate (l1l11ll)])
    return eval (l1l1l1l)
import gi
gi.require_version(l111111 (u"ࠨࡉࡷ࡯ࠬঽ"), l111111 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1l111
import logging
logger = logging.getLogger(l111111 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1l111l(Gtk.Window):
    def __init__(self, l1ll1l111l, l1ll1l11l1):
        Gtk.Window.__init__(self)
        self.l1ll1111=30
        self.l1l11l1lll = False
        self.service = l1ll1l111l
        self.l11l1l=l1ll1l11l1
        self.l1l1lll=l1l1l111.l11ll1ll
        self.l1l1l1l1ll = Gtk.ListStore(str)
        self.l1l1llll1l()
    def l1ll11lll1(self, service):
        l1ll1ll1l1 = self.l1l1lll.l1l1l1ll(l111111 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll1ll1l1
    def l1l1llll1l(self, l1ll1l111l=None):
        if l1ll1l111l:
            self.l1l1l1l1ll.clear()
            l1ll1llll1=self.l1ll11lll1(l1ll1l111l)
            self.l1l1l1l1ll.append([l111111 (u"ࠧࠨু")])
            for l11l1l in l1ll1llll1:
                self.l1l1l1l1ll.append([l11l1l])
        else:
            self.l1l1l1l1ll.clear()
            self.l1l1l1l1ll.append([l111111 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll1lll11(self, widget, data=None):
        l1l1l1llll= widget.get_active()
        if data == l111111 (u"ࠢ࠲ࠤৃ") and l1l1l1llll:
            self.l1l1llll1l()
            self.l1l1ll1ll1.set_active(0)
            self.l1l1l1l111.set_text(l111111 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l1l111.set_sensitive(False)
            self.l1l1ll1ll1.set_sensitive(False)
        else:
            self.l1l1llll1l(l1ll1l111l=self.service)
            self.l1l1ll1ll1.set_active(0)
            self.l1l1l1l111.set_text(l111111 (u"ࠤࠥ৅"))
            self.l1l1ll1ll1.set_sensitive(True)
            self.l1l1l1l111.set_sensitive(True)
    def l1l11lll11(self, widget):
        if widget.get_active():
            l11l1l = widget.get_child().get_text()
        else:
            l11l1l = self.l1l1l1l1ll[widget.get_active()][0]
        password = self.l1l11l11ll(self.service, l11l1l)
        if password:
            self.l1l1l1l111.set_text(password)
        else:
            self.l1l1l1l111.set_text(l111111 (u"ࠥࠦ৆"))
    def l1ll111ll1(self, l11l1l, pwd, service):
        keyring.set_password(service, l11l1l, pwd)
        l1ll1ll1l1=self.l1l1lll.l1l1l1ll(l111111 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11l1l in l1ll1ll1l1:
            value = self.l1l1lll.get_value(l111111 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l1lll.l1l1llll(l111111 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l111111 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11l1l))
    def l1l11l11ll(self, service, l11l1l):
        l1ll11l11l = keyring.get_password(service, l11l1l)
        return l1ll11l11l
    def l1ll11l1l1(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1l11ll1(self, widget, data=None):
        self.l1l11l1lll=widget.get_active()
    def ll(self, message, title=l111111 (u"ࠨࠩো"), l1l111l11=True):
        if l1l111l11:
            l1l1ll1lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l11ll111 = Gtk.MessageDialog(self,
            l1l1ll1lll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l11ll111.set_title(title)
        l1l11ll111.set_default_response(Gtk.ResponseType.OK)
        l1ll11111l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1ll1l1l = Gtk.VBox()
        l1l1lll1ll = Gtk.Box(spacing=1)
        l1l1lll1ll.set_homogeneous(False)
        l1l1l1ll1l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1ll1l.set_homogeneous(False)
        l1l11l1l11 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l1l11.set_homogeneous(False)
        l1l1lll1ll.pack_start(l1l1l1ll1l, True, True, 0)
        l1l1lll1ll.pack_start(l1l11l1l11, True, True, 0)
        l1l11llll1 = l1l11ll111.get_content_area()
        l1l11l1ll1 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l11llll1.pack_start(l1l11l1ll1, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l11ll1l1 = Gtk.Label()
        l1ll11l111 = Gtk.Label()
        l1ll11l111.set_text(l111111 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1ll11l111, True, True, 0)
        l1l11ll1l1.set_text(l111111 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l11ll1l1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l11ll1l1, 0, 1, 0, 1)
        l1ll1l1ll1 = Gtk.RadioButton.new_with_label_from_widget(None, l111111 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll1l1ll1.connect(l111111 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll1lll11, l111111 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll1l1ll1, 1, 2, 0, 1)
        l1l1l111l1 = Gtk.RadioButton.new_with_label_from_widget(l1ll1l1ll1, l111111 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1l111l1.connect(l111111 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll1lll11, l111111 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1l111l1, 1, 2, 1, 2)
        l1l1ll11ll = Gtk.Label()
        l1l1ll11ll.set_text(l111111 (u"ࠥࠤࠧ৔"))
        table.attach(l1l1ll11ll, 0, 1, 4, 6)
        l1ll11llll = Gtk.Label()
        l1ll11llll.set_text(l111111 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll11llll.set_justify(Gtk.Justification.RIGHT)
        l1ll11llll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1ll1ll1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1l1ll)
        self.l1l1ll1ll1.set_entry_text_column(0)
        table.attach(l1ll11llll, 0, 1, 6, 8)
        table.attach(self.l1l1ll1ll1, 1, 3, 6, 8)
        self.l1l1ll1ll1.connect(l111111 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l11lll11)
        l1l1ll111l = Gtk.Label()
        l1l1ll111l.set_text(l111111 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l1ll111l.set_justify(Gtk.Justification.RIGHT)
        l1l1ll111l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l1l111 = Gtk.Entry()
        self.l1l1l1l111.set_visibility(False)
        self.l1l1l1l111.connect(l111111 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1ll11l1l1, l1l11ll111)
        table.attach(l1l1ll111l, 0, 1, 8, 10)
        table.attach(self.l1l1l1l111, 1, 3, 8, 10)
        l1l1ll1111 = Gtk.CheckButton(l111111 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll1111.connect(l111111 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1l11ll1, l1l1ll1111)
        l1l1ll1111.set_active(False)
        table.attach(l1l1ll1111, 1, 3, 12, 14)
        l1l1lll11l = Gtk.Label()
        l1l1lll11l.set_text(l111111 (u"ࠥࠤࠧ৛") * 5)
        l1l1ll1l1l.pack_start(l1l1lll11l, True, True, 0)
        if self.l11l1l:
            l1l1l111l1.set_active(True)
            self.l1l1ll1ll1.set_active(0)
            self.l1l1ll1ll1.set_sensitive(True)
            self.l1l1l1l111.set_text(l111111 (u"ࠦࠧড়"))
            self.l1l1l1l111.set_sensitive(True)
        else:
            self.l1l1ll1ll1.set_active(0)
            self.l1l1ll1ll1.set_sensitive(False)
            self.l1l1l1l111.set_text(l111111 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l1l111.set_sensitive(False)
        l1ll11111l.pack_start(vbox, True, True, 0)
        l1ll11111l.pack_start(table, True, True, 0)
        l1ll11111l.pack_end(l1l1ll1l1l, True, True, 0)
        l1l11l1ll1.pack_start(l1ll11111l, True, True, 0)
        l1l11ll111.show_all()
        response = l1l11ll111.run()
        if self.l1l1ll1ll1.get_active():
            l11l1l = self.l1l1ll1ll1.get_child().get_text()
        else:
            l11l1l = self.l1l1l1l1ll[self.l1l1ll1ll1.get_active()][0]
        pwd = self.l1l1l1l111.get_text()
        l1l11ll111.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l11l1lll:
                self.l1ll111ll1(l11l1l, pwd, self.service)
            return l11l1l, pwd
        else:
            return l111111 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l111111 (u"ࠧࠨয়")
class l111ll111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1ll1l11(self, l11ll111):
        l1l11ll11l = Gtk.ScrolledWindow()
        l1l11ll11l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll1ll1ll=None
        self.l1ll111l1l = Gtk.TextBuffer()
        self.l1ll111l1l.set_text(l11ll111)
        self.set_style()
        regexp= l111111 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll111111 = self._1l1l1111l(l11ll111, regexp)
        self.l1ll111l11(l1ll111111, self.l1ll111l1l.get_start_iter())
        self.l1ll111lll = Gtk.TextView(buffer=self.l1ll111l1l)
        self.l1ll111lll.set_property(l111111 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll111lll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll111lll.connect(l111111 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1l1lll1)
        self.l1ll111lll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l11ll11l.set_size_request(300,100)
        self.l1ll111lll.show()
        l1l11ll11l.add(self.l1ll111lll)
        l1l11ll11l.show()
        return l1l11ll11l
    def _1l1l1lll1(self, *args, **kwargs):
        l1l1l11lll, l1ll1ll11l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l11lll, l1ll1ll11l).get_tags()
        if not self.l1ll1ll1ll:
            self.l1ll1ll1ll = args[1].window.get_cursor()
            self.l1l1lll1l1 = Gdk.Cursor(Gdk.CursorType.l1l1lll111)
        elif tag:
            args[1].window.set_cursor(self.l1l1lll1l1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll1ll1ll:
                args[1].window.set_cursor(self.l1ll1ll1ll)
    def _1l1l1111l(self, l11ll111, l1l1l11l11):
        res=[]
        l1ll1l1111=re.findall(l1l1l11l11,l11ll111)
        for l1ll1111l1 in l1ll1l1111:
            for el in l1ll1111l1:
                if el:
                    res.append(el)
        return res
    def l1ll111l11(self, l1ll111111, start):
        l1l11lllll=0
        for text in l1ll111111:
            end = self.l1ll111l1l.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l11lllll+=1
                l1l11ll1ll, l1ll1ll111 = match
                tag = self.l1ll111l1l.create_tag(str(l1l11lllll), foreground=l111111 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l111111 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll1l1l11, text)
                self.l1ll111l1l.apply_tag(tag, l1l11ll1ll, l1ll1ll111)
                self.l1ll111l11(l1ll111111, l1ll1ll111)
    def _1ll1l1l11(self, tag, widget, l1ll11ll11, _1l11l1l1l, text):
        _1ll11l1ll = l1ll11ll11.type
        _1ll1111ll = l1ll11ll11.window
        if _1ll11l1ll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll11l1ll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll11ll11.button
            self.l1ll1ll1ll = Gdk.Cursor(Gdk.CursorType.l1l1lll111)
            if _1ll11l1ll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l111111 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l111lllll(self, message, title=l111111 (u"ࠧࠨ০"), l1l111l11=True, l1l1l11l1l=None):
        if l1l111l11:
            l1l1ll1lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1ll1lll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1l11l1l:
            l1l11llll1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1lll1ll = Gtk.HBox(spacing=0)
            l1l1l11111 = Gtk.HBox(spacing=5)
            l1ll11ll1l = Gtk.Label()
            l1ll11ll1l.set_markup(l111111 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll11ll1l.set_line_wrap(True)
            l1ll11ll1l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l111111 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1l1ll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1ll11.show()
            l1l1ll11l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11l1.show()
            l1ll1l1l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l1l.show()
            l1l1lll1ll.pack_start(separator, True, True, 0)
            l1l1lll1ll.pack_start(l1l1l1ll11, True, True, 0)
            l1l1lll1ll.pack_start(l1l1ll11l1, True, True, 0)
            l1l1lll1ll.pack_start(l1ll1l1l1l, True, True, 0)
            l1l1lll1ll.pack_start(l1ll11ll1l, False, True, 0)
            l1ll1lll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1lll1l.show()
            l1l1lll1ll.pack_end(l1ll1lll1l, True, True, 0)
            l1l1l1l11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l11l.show()
            vbox.pack_start(l1l1lll1ll, True, True, 0)
            l1l11ll11l=self.__1l1ll1l11(l11ll111=l1l1l11l1l)
            vbox.pack_start(l1l11ll11l, False, False, 0)
            vbox.pack_end(l1l1l1l11l, False, False, 0)
            l1l1l11111.pack_start(vbox, True, True,5)
            l1l1l11111.show()
            l1l11llll1.pack_end(l1l1l11111, False, False, 0)
            vbox.show()
            l1l1lll1ll.show()
        window.run()
class l1l11l111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l1l1l1(self, widget, l1ll1l1lll):
        if l1ll1l1lll == Gtk.ResponseType.OK:
            self.result = l111111 (u"ࠥࡓࡐࠨ৩")
        elif l1ll1l1lll == Gtk.ResponseType.CANCEL:
            self.result = l111111 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll1l1lll == Gtk.ResponseType.DELETE_EVENT:
            self.result = l111111 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1ll111l1(self, title=l111111 (u"ࠨࠢ৬"), message=l111111 (u"ࠢࠣ৭") , l1l111l11=True):
        if l1l111l11:
            l1l1ll1lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll1lll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l111111 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1l1l1l1)
        window.run()
class l1ll1lllll(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l111ll=None
        self.result = None
    def l1l1l1l1l1(self, widget, l1ll1l1lll):
        print(widget, l1ll1l1lll)
        if l1ll1l1lll == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll1l1lll == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll1l1lll == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1l11ll1(self, widget, l1l1lllll1):
        if l1l1lllll1.get_active():
            self.l1l1l111ll = 1
        else:
            self.l1l1l111ll = 0
    def l1l11lll1l(self, title=l111111 (u"ࠤࠥ৯"), message=l111111 (u"ࠥࠦৰ"), l1l1llll11 =l111111 (u"ࠦࠧৱ"),l1l111l11=True):
        if l1l111l11:
            l1l1ll1lll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll1lll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l111111 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1l1l1l1)
        l1l1ll1111 = Gtk.CheckButton(l1l1llll11)
        l1l1ll1111.connect(l111111 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1l11ll1, l1l1ll1111)
        l1l1ll1111.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll1111, expand=True, fill=True, padding=0)
        l1l1ll1111.show()
        window.run()
def l1l1lll11(title, msg, l1l1llll11=l111111 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1l111l11=True):
    result=None
    try:
        l1ll1l11ll = l1ll1lllll()
        l1ll1l11ll.l1l11lll1l(title, msg, l1l1llll11, l1l111l11)
        result = {l111111 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll1l11ll.result,  l111111 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll1l11ll.l1l1l111ll}
    except Exception as e:
        logger.exception(l111111 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l111111 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11l11l1l = l111ll111()
    message= l111111 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1llllll = l111111 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11l11l1l.l111lllll(message, l111111 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1l111l11=True, l1l1l11l1l=l1l1llllll)