#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l1lllll1 = 2048
l1lll1 = 7
def l1ll1ll (l11l1ll):
    global l11l1l
    l1llllll = ord (l11l1ll [-1])
    l111111 = l11l1ll [:-1]
    l1ll1ll1 = l1llllll % len (l111111)
    l1l1ll = l111111 [:l1ll1ll1] + l111111 [l1ll1ll1:]
    if l1lllll:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    return eval (l1111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11lll=logging.WARNING
logger = logging.getLogger(l1ll1ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11lll)
l1l11lll = SysLogHandler(address=l1ll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll1ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11lll.setFormatter(formatter)
logger.addHandler(l1l11lll)
ch = logging.StreamHandler()
ch.setLevel(l1lll11lll)
logger.addHandler(ch)
class l1llll111l(io.FileIO):
    l1ll1ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll1ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1ll1, l1lll1ll11,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1ll1 = l1llll1ll1
            self.l1lll1ll11 = l1lll1ll11
            if not options:
                options = l1ll1ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll1ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1ll1,
                                              self.l1lll1ll11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll111l1 = os.path.join(os.path.sep, l1ll1ll (u"ࠪࡩࡹࡩࠧই"), l1ll1ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll11111 = path
        else:
            self._1lll11111 = self.l1lll111l1
        super(l1llll111l, self).__init__(self._1lll11111, l1ll1ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll11ll(self, line):
        return l1llll111l.Entry(*[x for x in line.strip(l1ll1ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll1ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll1ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll1ll (u"ࠤࠦࠦ঍")):
                    yield self._1llll11ll(line)
            except ValueError:
                pass
    def l1llll1l11(self, attr, value):
        for entry in self.entries:
            l1llll1l1l = getattr(entry, attr)
            if l1llll1l1l == value:
                return entry
        return None
    def l1lll1lll1(self, entry):
        if self.l1llll1l11(l1ll1ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll1ll (u"ࠫࡡࡴࠧএ")).encode(l1ll1ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1111(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll1ll (u"ࠢࠤࠤ঒")):
                if self._1llll11ll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll1ll (u"ࠨࠩও").join(lines).encode(l1ll1ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllll1ll(cls, l1llll1ll1, path=None):
        l1lll1ll1l = cls(path=path)
        entry = l1lll1ll1l.l1llll1l11(l1ll1ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1ll1)
        if entry:
            return l1lll1ll1l.l1llll1111(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1ll1, l1lll1ll11, options=None, path=None):
        return cls(path=path).l1lll1lll1(l1llll111l.Entry(device,
                                                    l1llll1ll1, l1lll1ll11,
                                                    options=options))
class l1llllll11(object):
    def __init__(self, l1lllll111):
        self.l1llllll1l=l1ll1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1111l=l1ll1ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll111=l1lllll111
        self.l1lll1l11l()
        self.l1llll11l1()
        self.l1lll11l1l()
        self.l1lll1l1l1()
        self.l1lllll1l1()
    def l1lll1l11l(self):
        temp_file=open(l1lll11ll1,l1ll1ll (u"࠭ࡲࠨঘ"))
        l1ll1lll=temp_file.read()
        data=json.loads(l1ll1lll)
        self.user=data[l1ll1ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11111=data[l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1lll1ll=data[l1ll1ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11l11l=data[l1ll1ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll11l=data[l1ll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllllll1=data[l1ll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll11l1l(self):
        l1l1ll1=os.path.join(l1ll1ll (u"ࠨ࠯ࠣট"),l1ll1ll (u"ࠢࡶࡵࡵࠦঠ"),l1ll1ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll1ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll1ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l1ll1)
    def l1lllll1l1(self):
        logger.info(l1ll1ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1lll1ll=os.path.join(self.l11l11l,self.l1llllll1l)
        l1llll1lll = pwd.getpwnam(self.user).pw_uid
        l1lll1l111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1lll1ll):
            os.makedirs(l1lll1ll)
            os.system(l1ll1ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1lll1ll))
            logger.debug(l1ll1ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1lll1ll)
        else:
            logger.debug(l1ll1ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1lll1ll)
        l1l1ll1=os.path.join(l1lll1ll, self.l1lll1111l)
        print(l1l1ll1)
        logger.debug(l1ll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l1ll1)
        with open(l1l1ll1, l1ll1ll (u"ࠤࡺ࠯ࠧ঩")) as l1lll111ll:
            logger.debug(self.l11111 + l1ll1ll (u"ࠪࠤࠬপ")+self.l1lllll11l+l1ll1ll (u"ࠫࠥࠨࠧফ")+self.l1lllllll1+l1ll1ll (u"ࠬࠨࠧব"))
            l1lll111ll.writelines(self.l11111 + l1ll1ll (u"࠭ࠠࠨভ")+self.l1lllll11l+l1ll1ll (u"ࠧࠡࠤࠪম")+self.l1lllllll1+l1ll1ll (u"ࠨࠤࠪয"))
        os.chmod(l1l1ll1, 0o600)
        os.chown(l1l1ll1, l1llll1lll, l1lll1l111)
    def l1llll11l1(self, l1lll11l11=l1ll1ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll1ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11l11 in groups:
            logger.info(l1ll1ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11l11))
        else:
            logger.warning(l1ll1ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11l11))
            l1l=l1ll1ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11l11,self.user)
            logger.debug(l1ll1ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l)
            os.system(l1l)
            logger.debug(l1ll1ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l1l1(self):
        logger.debug(l1ll1ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1ll1l=l1llll111l()
        l1lll1ll1l.add(self.l11111, self.l1lll1ll, l1lll1ll11=l1ll1ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll1ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll1ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll11ll1 = urllib.parse.unquote(sys.argv[1])
        if l1lll11ll1:
            l1lll1llll=l1llllll11(l1lll11ll1)
        else:
            raise (l1ll1ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll1ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise