#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111 = sys.version_info [0] == 2
l111 = 2048
l1ll1l1l = 7
def l11l1ll (l1ll1l11):
    global ll
    l1ll111 = ord (l1ll1l11 [-1])
    l1llll1l = l1ll1l11 [:-1]
    l1lll = l1ll111 % len (l1llll1l)
    l1 = l1llll1l [:l1lll] + l1llll1l [l1lll:]
    if l11111:
        l1ll1lll = l11l11 () .join ([unichr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    else:
        l1ll1lll = str () .join ([chr (ord (char) - l111 - (l11l11l + l1ll111) % l1ll1l1l) for l11l11l, char in enumerate (l1)])
    return eval (l1ll1lll)
import hashlib
import os
import l1l11l1
from l1111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l11l1 import l1lll1
from l111l import l11ll1l, l1l1lll
import logging
logger = logging.getLogger(l11l1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l1ll1():
    def __init__(self, l1l1l11,l1ll1, l1llll1= None, l1lll11=None):
        self.l1ll111l=False
        self.l1llll11 = self._1ll1l1()
        self.l1ll1 = l1ll1
        self.l1llll1 = l1llll1
        self.l1l1l1l = l1l1l11
        if l1llll1:
            self.l11l1 = True
        else:
            self.l11l1 = False
        self.l1lll11 = l1lll11
    def _1ll1l1(self):
        try:
            return l1l11l1.l1lllll1() is not None
        except:
            return False
    def open(self):
        l11l1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1llll11:
            raise NotImplementedError(l11l1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11l1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll11 = self.l1l1l1l
        if self.l1ll1.lower().startswith(self.l1l1l1l.lower()):
            l11ll = re.compile(re.escape(self.l1l1l1l), re.IGNORECASE)
            l1ll1 = l11ll.sub(l11l1ll (u"ࠨࠩࠄ"), self.l1ll1)
            l1ll1 = l1ll1.replace(l11l1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l11l1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l111(self.l1l1l1l, l11ll11, l1ll1, self.l1llll1)
    def l1l111(self,l1l1l1l, l11ll11, l1ll1, l1llll1):
        l11l1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11l1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1111ll = l11lll1(l1l1l1l)
        l111ll1 = self.l1ll11(l1111ll)
        logger.info(l11l1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1111ll)
        if l111ll1:
            logger.info(l11l1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll1(l1111ll)
            l1111ll = l11l111(l1l1l1l, l11ll11, l1llll1, self.l1lll11)
        logger.debug(l11l1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l=l1111ll + l11l1ll (u"ࠤ࠲ࠦࠌ") + l1ll1
        l11111l = l11l1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l+ l11l1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11111l)
        l1l1l1 = os.system(l11111l)
        if (l1l1l1 != 0):
            raise IOError(l11l1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l, l1l1l1))
    def l1ll11(self, l1111ll):
        if os.path.exists(l1111ll):
            if os.path.islink(l1111ll):
                l1111ll = os.readlink(l1111ll)
            if os.path.ismount(l1111ll):
                return True
        return False
def l11lll1(l1l1l1l):
    l1ll1l = l1l1l1l.replace(l11l1ll (u"࠭࡜࡝ࠩࠐ"), l11l1ll (u"ࠧࡠࠩࠑ")).replace(l11l1ll (u"ࠨ࠱ࠪࠒ"), l11l1ll (u"ࠩࡢࠫࠓ"))
    l1llllll = l11l1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l1l1=os.environ[l11l1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll1l1=os.path.join(l11l1l1,l1llllll, l1ll1l)
    l1ll1ll1=os.path.abspath(l1lll1l1)
    return l1ll1ll1
def l1l11ll(l11l):
    if not os.path.exists(l11l):
        os.makedirs(l11l)
def l1l11l(l1l1l1l, l11ll11, l1l111l=None, password=None):
    l11l1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l = l11lll1(l1l1l1l)
    l1l11ll(l11l)
    if not l1l111l:
        l11ll1 = l1l1l()
        l11 =l11ll1.l1ll(l11l1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll11 + l11l1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll11 + l11l1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11, str):
            l1l111l, password = l11
        else:
            raise l1l1lll()
        logger.info(l11l1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l))
    l11lll = pwd.getpwuid( os.getuid())[0]
    l1111l=os.environ[l11l1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll11ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11llll={l11l1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11lll, l11l1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1l1l, l11l1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l, l11l1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1111l, l11l1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l111l, l11l1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11llll, temp_file)
        if not os.path.exists(os.path.join(l1ll11ll, l11l1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l1111=l11l1ll (u"ࠦࡵࡿࠢࠣ")
            key=l11l1ll (u"ࠧࠨࠤ")
        else:
            l1l1111=l11l1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11l1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll11l=l11l1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l1111,temp_file.name)
        l1l1ll=[l11l1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11l1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll11ll, l1ll11l)]
        p = subprocess.Popen(l1l1ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11l1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11l1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11l1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l
    logger.debug(l11l1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11l1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11l1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11l1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll1ll1=os.path.abspath(l11l)
    logger.debug(l11l1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll1ll1)
    return l1ll1ll1
def l11l111(l1l1l1l, l11ll11, l1llll1, l1lll11):
    l11l1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1ll(title):
        l11l1l=30
        if len(title)>l11l1l:
            l111lll=title.split(l11l1ll (u"ࠨ࠯ࠣ࠳"))
            l1lllll=l11l1ll (u"ࠧࠨ࠴")
            for block in l111lll:
                l1lllll+=block+l11l1ll (u"ࠣ࠱ࠥ࠵")
                if len(l1lllll) > l11l1l:
                    l1lllll+=l11l1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lllll
        return title
    def l111ll(l1ll1111, password):
        l11l1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11l1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11l1ll (u"ࠧࠦࠢ࠹").join(l1ll1111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l111l1 = l11l1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l111l1.encode())
        l1lll1l = [l11l1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll11l = l11l1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll11l)
            for e in l1lll1l:
                if e in l1lll11l: return False
            raise l11ll1l(l1lll11l, l11l111=l1l11l1.l1lllll1(), l11ll11=l11ll11)
        logger.info(l11l1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l111l = l11l1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11l1ll (u"ࠦࠧ࠿")
    os.system(l11l1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll11l1 = l11lll1(l1l1l1l)
    l11l = l11lll1(hashlib.sha1(l1l1l1l.encode()).hexdigest()[:10])
    l1l11ll(l11l)
    logger.info(l11l1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11l))
    if l1llll1:
        l1ll1111 = [l11l1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11l1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11l1ll (u"ࠤ࠰ࡸࠧࡄ"), l11l1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11l1ll (u"ࠫ࠲ࡵࠧࡆ"), l11l1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l111l, l1llll1),
                    urllib.parse.unquote(l11ll11), os.path.abspath(l11l)]
        l111ll(l1ll1111, password)
    else:
        while True:
            l1l111l, password = l1l1(l11l, l11ll11, l1lll11)
            if l1l111l.lower() != l11l1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll1111 = [l11l1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11l1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11l1ll (u"ࠤ࠰ࡸࠧࡋ"), l11l1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11l1ll (u"ࠫ࠲ࡵࠧࡍ"), l11l1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l111l,
                            urllib.parse.unquote(l11ll11), os.path.abspath(l11l)]
            else:
                raise l1l1lll()
            if l111ll(l1ll1111, password): break
    os.system(l11l1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11l, l1ll11l1))
    l1ll1ll1=os.path.abspath(l1ll11l1)
    return l1ll1ll1
def l1l1(l1l1l1l, l11ll11, l1lll11):
    l1lll1ll = os.path.join(os.environ[l11l1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11l1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11l1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll1ll)):
       os.makedirs(os.path.dirname(l1lll1ll))
    l1111l1 = l1lll11.get_value(l11l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11l1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11ll1 = l1l1l(l1l1l1l, l1111l1)
    l1l111l, password = l11ll1.l1ll(l11l1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11ll11 + l11l1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11ll11 + l11l1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l111l != l11l1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111l1l(l1l1l1l, l1l111l):
        l1l11 = l11l1ll (u"ࠤ࡙ࠣࠦ").join([l1l1l1l, l1l111l, l11l1ll (u"࡚ࠪࠦࠬ") + password + l11l1ll (u"࡛ࠫࠧ࠭"), l11l1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll1ll, l11l1ll (u"࠭ࡷࠬࠩ࡝")) as l1llll:
            l1llll.write(l1l11)
        os.chmod(l1lll1ll, 0o600)
    return l1l111l, password
def l111l1l(l1l1l1l, l1l111l):
    l1lll1ll = l111l11 = os.path.join(os.environ[l11l1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11l1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11l1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll1ll):
        with open(l1lll1ll, l11l1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l111111 = data[0].split(l11l1ll (u"ࠦࠥࠨࡢ"))
            if l1l1l1l == l111111[0] and l1l111l == l111111[1]:
                return True
    return False