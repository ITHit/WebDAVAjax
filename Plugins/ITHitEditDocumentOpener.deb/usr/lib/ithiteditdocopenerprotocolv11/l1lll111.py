#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l1 = sys.version_info [0] == 2
l111lll = 2048
l1l = 7
def l1ll1ll (l11l1ll):
    global l1lll11
    l1l1111 = ord (l11l1ll [-1])
    l1111l = l11l1ll [:-1]
    l1l1 = l1l1111 % len (l1111l)
    l1l1l1 = l1111l [:l1l1] + l1111l [l1l1:]
    if l1111l1:
        l11l1l1 = l11 () .join ([unichr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    else:
        l11l1l1 = str () .join ([chr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    return eval (l11l1l1)
import logging
import os
import re
from l1ll1ll1 import l1llll111
logger = logging.getLogger(l1ll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111ll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1ll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111111():
    try:
        out = os.popen(l1ll1ll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1ll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1ll (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1ll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1ll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1ll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1ll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll111(l1ll1ll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1ll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111ll1(l1ll1ll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))