#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll11l = 2048
l111 = 7
def l1l1 (l1ll1l11):
    global l11l11l
    l1111l = ord (l1ll1l11 [-1])
    l1111 = l1ll1l11 [:-1]
    l1lll1l = l1111l % len (l1111)
    l1llll11 = l1111 [:l1lll1l] + l1111 [l1lll1l:]
    if l11ll:
        l1lll1l1 = l111lll () .join ([unichr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    else:
        l1lll1l1 = str () .join ([chr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    return eval (l1lll1l1)
import re
class l1l1l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111ll = kwargs.get(l1l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l11ll = kwargs.get(l1l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llllll1 = self.l1llll1ll(args)
        if l1llllll1:
            args=args+ l1llllll1
        self.args = [a for a in args]
    def l1llll1ll(self, *args):
        l1llllll1=None
        l1l1111l = args[0][0]
        if re.search(l1l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1111l):
            l1llllll1 = (l1l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l11111ll
                            ,)
        return l1llllll1
class l1lllll1l(Exception):
    def __init__(self, *args, **kwargs):
        l1llllll1 = self.l1llll1ll(args)
        if l1llllll1:
            args = args + l1llllll1
        self.args = [a for a in args]
    def l1llll1ll(self, *args):
        s = l1l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1lll(Exception):
    pass
class l1l1l1l(Exception):
    pass
class l1lllll11(Exception):
    def __init__(self, message, l1lll1l1l, url):
        super(l1lllll11,self).__init__(message)
        self.l1lll1l1l = l1lll1l1l
        self.url = url
class l1lll1ll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1llll111(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111111l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1111111(Exception):
    pass
class l1111l11(Exception):
    pass
class l11111l1(Exception):
    pass
class l11l1111(Exception):
    pass