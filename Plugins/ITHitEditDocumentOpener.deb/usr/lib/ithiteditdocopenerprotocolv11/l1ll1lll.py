#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll11l = 2048
l111 = 7
def l1l1 (l1ll1l11):
    global l11l11l
    l1111l = ord (l1ll1l11 [-1])
    l1111 = l1ll1l11 [:-1]
    l1lll1l = l1111l % len (l1111)
    l1llll11 = l1111 [:l1lll1l] + l1111 [l1lll1l:]
    if l11ll:
        l1lll1l1 = l111lll () .join ([unichr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    else:
        l1lll1l1 = str () .join ([chr (ord (char) - l1ll11l - (l1l11l1 + l1111l) % l111) for l1l11l1, char in enumerate (l1llll11)])
    return eval (l1lll1l1)
import gi
gi.require_version(l1l1 (u"ࠨࡉࡷ࡯ࠬঽ"), l1l1 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1l111
import logging
logger = logging.getLogger(l1l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1ll1(Gtk.Window):
    def __init__(self, l1l11ll11l, l1ll111ll1):
        Gtk.Window.__init__(self)
        self.l1111l1=30
        self.l1l1llllll = False
        self.service = l1l11ll11l
        self.l1l111l=l1ll111ll1
        self.l1ll=l1l1l111.l11ll111
        self.l1l11llll1 = Gtk.ListStore(str)
        self.l1l11lllll()
    def l1l11lll11(self, service):
        l1l1ll1l1l = self.l1ll.l1l111l1(l1l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1ll1l1l
    def l1l11lllll(self, l1l11ll11l=None):
        if l1l11ll11l:
            self.l1l11llll1.clear()
            l1l11lll1l=self.l1l11lll11(l1l11ll11l)
            self.l1l11llll1.append([l1l1 (u"ࠧࠨু")])
            for l1l111l in l1l11lll1l:
                self.l1l11llll1.append([l1l111l])
        else:
            self.l1l11llll1.clear()
            self.l1l11llll1.append([l1l1 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll1l1111(self, widget, data=None):
        l1l11l1lll= widget.get_active()
        if data == l1l1 (u"ࠢ࠲ࠤৃ") and l1l11l1lll:
            self.l1l11lllll()
            self.l1ll1l1l1l.set_active(0)
            self.l1l1ll111l.set_text(l1l1 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1ll111l.set_sensitive(False)
            self.l1ll1l1l1l.set_sensitive(False)
        else:
            self.l1l11lllll(l1l11ll11l=self.service)
            self.l1ll1l1l1l.set_active(0)
            self.l1l1ll111l.set_text(l1l1 (u"ࠤࠥ৅"))
            self.l1ll1l1l1l.set_sensitive(True)
            self.l1l1ll111l.set_sensitive(True)
    def l1l1l1111l(self, widget):
        if widget.get_active():
            l1l111l = widget.get_child().get_text()
        else:
            l1l111l = self.l1l11llll1[widget.get_active()][0]
        password = self.l1ll1lll1l(self.service, l1l111l)
        if password:
            self.l1l1ll111l.set_text(password)
        else:
            self.l1l1ll111l.set_text(l1l1 (u"ࠥࠦ৆"))
    def l1ll1l1l11(self, l1l111l, pwd, service):
        keyring.set_password(service, l1l111l, pwd)
        l1l1ll1l1l=self.l1ll.l1l111l1(l1l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1l111l in l1l1ll1l1l:
            value = self.l1ll.get_value(l1l1 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1ll.l1l11l11(l1l1 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1l1 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1l111l))
    def l1ll1lll1l(self, service, l1l111l):
        l1ll111l1l = keyring.get_password(service, l1l111l)
        return l1ll111l1l
    def l1l1l1l111(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1l11ll1(self, widget, data=None):
        self.l1l1llllll=widget.get_active()
    def l11ll1(self, message, title=l1l1 (u"ࠨࠩো"), l1111l111=True):
        if l1111l111:
            l1ll11l1l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll11l1l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll11111l = Gtk.MessageDialog(self,
            l1ll11l1l1,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll11111l.set_title(title)
        l1ll11111l.set_default_response(Gtk.ResponseType.OK)
        l1l1l111ll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l1l1ll = Gtk.VBox()
        l1ll11ll11 = Gtk.Box(spacing=1)
        l1ll11ll11.set_homogeneous(False)
        l1ll11llll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11llll.set_homogeneous(False)
        l1l1ll11l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1ll11l1.set_homogeneous(False)
        l1ll11ll11.pack_start(l1ll11llll, True, True, 0)
        l1ll11ll11.pack_start(l1l1ll11l1, True, True, 0)
        l1l11ll1ll = l1ll11111l.get_content_area()
        l1l1ll11ll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l11ll1ll.pack_start(l1l1ll11ll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1l1lll = Gtk.Label()
        l1ll1ll11l = Gtk.Label()
        l1ll1ll11l.set_text(l1l1 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1ll1ll11l, True, True, 0)
        l1ll1l1lll.set_text(l1l1 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll1l1lll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1l1lll, 0, 1, 0, 1)
        l1l1llll11 = Gtk.RadioButton.new_with_label_from_widget(None, l1l1 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1llll11.connect(l1l1 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll1l1111, l1l1 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1llll11, 1, 2, 0, 1)
        l1l11l1ll1 = Gtk.RadioButton.new_with_label_from_widget(l1l1llll11, l1l1 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l11l1ll1.connect(l1l1 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll1l1111, l1l1 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l11l1ll1, 1, 2, 1, 2)
        l1ll111lll = Gtk.Label()
        l1ll111lll.set_text(l1l1 (u"ࠥࠤࠧ৔"))
        table.attach(l1ll111lll, 0, 1, 4, 6)
        l1ll1lll11 = Gtk.Label()
        l1ll1lll11.set_text(l1l1 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll1lll11.set_justify(Gtk.Justification.RIGHT)
        l1ll1lll11.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1l1l1l = Gtk.ComboBox.new_with_model_and_entry(self.l1l11llll1)
        self.l1ll1l1l1l.set_entry_text_column(0)
        table.attach(l1ll1lll11, 0, 1, 6, 8)
        table.attach(self.l1ll1l1l1l, 1, 3, 6, 8)
        self.l1ll1l1l1l.connect(l1l1 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1l1111l)
        l1ll1l11ll = Gtk.Label()
        l1ll1l11ll.set_text(l1l1 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1l11ll.set_justify(Gtk.Justification.RIGHT)
        l1ll1l11ll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1ll111l = Gtk.Entry()
        self.l1l1ll111l.set_visibility(False)
        self.l1l1ll111l.connect(l1l1 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1l1l111, l1ll11111l)
        table.attach(l1ll1l11ll, 0, 1, 8, 10)
        table.attach(self.l1l1ll111l, 1, 3, 8, 10)
        l1ll1lllll = Gtk.CheckButton(l1l1 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll1lllll.connect(l1l1 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1l11ll1, l1ll1lllll)
        l1ll1lllll.set_active(False)
        table.attach(l1ll1lllll, 1, 3, 12, 14)
        l1l1ll1111 = Gtk.Label()
        l1l1ll1111.set_text(l1l1 (u"ࠥࠤࠧ৛") * 5)
        l1l1l1l1ll.pack_start(l1l1ll1111, True, True, 0)
        if self.l1l111l:
            l1l11l1ll1.set_active(True)
            self.l1ll1l1l1l.set_active(0)
            self.l1ll1l1l1l.set_sensitive(True)
            self.l1l1ll111l.set_text(l1l1 (u"ࠦࠧড়"))
            self.l1l1ll111l.set_sensitive(True)
        else:
            self.l1ll1l1l1l.set_active(0)
            self.l1ll1l1l1l.set_sensitive(False)
            self.l1l1ll111l.set_text(l1l1 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1ll111l.set_sensitive(False)
        l1l1l111ll.pack_start(vbox, True, True, 0)
        l1l1l111ll.pack_start(table, True, True, 0)
        l1l1l111ll.pack_end(l1l1l1l1ll, True, True, 0)
        l1l1ll11ll.pack_start(l1l1l111ll, True, True, 0)
        l1ll11111l.show_all()
        response = l1ll11111l.run()
        if self.l1ll1l1l1l.get_active():
            l1l111l = self.l1ll1l1l1l.get_child().get_text()
        else:
            l1l111l = self.l1l11llll1[self.l1ll1l1l1l.get_active()][0]
        pwd = self.l1l1ll111l.get_text()
        l1ll11111l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1llllll:
                self.l1ll1l1l11(l1l111l, pwd, self.service)
            return l1l111l, pwd
        else:
            return l1l1 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1l1 (u"ࠧࠨয়")
class l1111l1l1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll11l111(self, l1l1111l):
        l1ll1ll111 = Gtk.ScrolledWindow()
        l1ll1ll111.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l11l11ll=None
        self.l1l1ll1l11 = Gtk.TextBuffer()
        self.l1l1ll1l11.set_text(l1l1111l)
        self.set_style()
        regexp= l1l1 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l1l11l1l = self._1l1l1ll1l(l1l1111l, regexp)
        self.l1l1l1lll1(l1l1l11l1l, self.l1l1ll1l11.get_start_iter())
        self.l1l1lll11l = Gtk.TextView(buffer=self.l1l1ll1l11)
        self.l1l1lll11l.set_property(l1l1 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1lll11l.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1lll11l.connect(l1l1 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll111111)
        self.l1l1lll11l.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1ll111.set_size_request(300,100)
        self.l1l1lll11l.show()
        l1ll1ll111.add(self.l1l1lll11l)
        l1ll1ll111.show()
        return l1ll1ll111
    def _1ll111111(self, *args, **kwargs):
        l1l1l11111, l1ll1l111l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l11111, l1ll1l111l).get_tags()
        if not self.l1l11l11ll:
            self.l1l11l11ll = args[1].window.get_cursor()
            self.l1ll111l11 = Gdk.Cursor(Gdk.CursorType.l1l11l1l11)
        elif tag:
            args[1].window.set_cursor(self.l1ll111l11)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l11l11ll:
                args[1].window.set_cursor(self.l1l11l11ll)
    def _1l1l1ll1l(self, l1l1111l, l1l1l11lll):
        res=[]
        l1l1lllll1=re.findall(l1l1l11lll,l1l1111l)
        for l1ll1l1ll1 in l1l1lllll1:
            for el in l1ll1l1ll1:
                if el:
                    res.append(el)
        return res
    def l1l1l1lll1(self, l1l1l11l1l, start):
        l1ll11ll1l=0
        for text in l1l1l11l1l:
            end = self.l1l1ll1l11.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll11ll1l+=1
                l1l1l111l1, l1l1ll1lll = match
                tag = self.l1l1ll1l11.create_tag(str(l1ll11ll1l), foreground=l1l1 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1l1 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll1l11l1, text)
                self.l1l1ll1l11.apply_tag(tag, l1l1l111l1, l1l1ll1lll)
                self.l1l1l1lll1(l1l1l11l1l, l1l1ll1lll)
    def _1ll1l11l1(self, tag, widget, l1l1lll1ll, _1ll1111l1, text):
        _1l11l1l1l = l1l1lll1ll.type
        _1ll11l1ll = l1l1lll1ll.window
        if _1l11l1l1l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11l1l1l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1lll1ll.button
            self.l1l11l11ll = Gdk.Cursor(Gdk.CursorType.l1l11l1l11)
            if _1l11l1l1l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1l1 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1ll1l11l(self, message, title=l1l1 (u"ࠧࠨ০"), l1111l111=True, l1l1l1ll11=None):
        if l1111l111:
            l1ll11l1l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll11l1l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll11l1l1,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1l1ll11:
            l1l11ll1ll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll11ll11 = Gtk.HBox(spacing=0)
            l1l1l1llll = Gtk.HBox(spacing=5)
            l1l1llll1l = Gtk.Label()
            l1l1llll1l.set_markup(l1l1 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1llll1l.set_line_wrap(True)
            l1l1llll1l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1l1 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1llll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1llll1.show()
            l1l1l1l11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l11l.show()
            l1l1lll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll111.show()
            l1ll11ll11.pack_start(separator, True, True, 0)
            l1ll11ll11.pack_start(l1ll1llll1, True, True, 0)
            l1ll11ll11.pack_start(l1l1l1l11l, True, True, 0)
            l1ll11ll11.pack_start(l1l1lll111, True, True, 0)
            l1ll11ll11.pack_start(l1l1llll1l, False, True, 0)
            l1l1l11l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11l11.show()
            l1ll11ll11.pack_end(l1l1l11l11, True, True, 0)
            l1l11ll1l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll1l1.show()
            vbox.pack_start(l1ll11ll11, True, True, 0)
            l1ll1ll111=self.__1ll11l111(l1l1111l=l1l1l1ll11)
            vbox.pack_start(l1ll1ll111, False, False, 0)
            vbox.pack_end(l1l11ll1l1, False, False, 0)
            l1l1l1llll.pack_start(vbox, True, True,5)
            l1l1l1llll.show()
            l1l11ll1ll.pack_end(l1l1l1llll, False, False, 0)
            vbox.show()
            l1ll11ll11.show()
        window.run()
class l11l1l11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1ll1ll1(self, widget, l1l1lll1l1):
        if l1l1lll1l1 == Gtk.ResponseType.OK:
            self.result = l1l1 (u"ࠥࡓࡐࠨ৩")
        elif l1l1lll1l1 == Gtk.ResponseType.CANCEL:
            self.result = l1l1 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1lll1l1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1l1 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11l1ll11(self, title=l1l1 (u"ࠨࠢ৬"), message=l1l1 (u"ࠢࠣ৭") , l1111l111=True):
        if l1111l111:
            l1ll11l1l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll11l1l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll11l1l1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1l1 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1ll1ll1)
        window.run()
class l1l11ll111(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1l1l1=None
        self.result = None
    def l1l1ll1ll1(self, widget, l1l1lll1l1):
        print(widget, l1l1lll1l1)
        if l1l1lll1l1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1lll1l1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1lll1l1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1l11ll1(self, widget, l1ll1ll1l1):
        if l1ll1ll1l1.get_active():
            self.l1l1l1l1l1 = 1
        else:
            self.l1l1l1l1l1 = 0
    def l1ll11lll1(self, title=l1l1 (u"ࠤࠥ৯"), message=l1l1 (u"ࠥࠦৰ"), l1ll1ll1ll =l1l1 (u"ࠦࠧৱ"),l1111l111=True):
        if l1111l111:
            l1ll11l1l1= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll11l1l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll11l1l1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1l1 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1ll1ll1)
        l1ll1lllll = Gtk.CheckButton(l1ll1ll1ll)
        l1ll1lllll.connect(l1l1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1l11ll1, l1ll1lllll)
        l1ll1lllll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll1lllll, expand=True, fill=True, padding=0)
        l1ll1lllll.show()
        window.run()
def l111111ll(title, msg, l1ll1ll1ll=l1l1 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1111l111=True):
    result=None
    try:
        l1ll1111ll = l1l11ll111()
        l1ll1111ll.l1ll11lll1(title, msg, l1ll1ll1ll, l1111l111)
        result = {l1l1 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll1111ll.result,  l1l1 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll1111ll.l1l1l1l1l1}
    except Exception as e:
        logger.exception(l1l1 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1111111l = l1111l1l1()
    message= l1l1 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll11l11l = l1l1 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1111111l.l1ll1l11l(message, l1l1 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1111l111=True, l1l1l1ll11=l1ll11l11l)