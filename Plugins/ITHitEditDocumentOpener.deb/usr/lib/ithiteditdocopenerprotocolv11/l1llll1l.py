#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11111l = sys.version_info [0] == 2
l1l111 = 2048
l1lll111 = 7
def l1l1l1l (l1ll1ll1):
    global l1l1l11
    l1l = ord (l1ll1ll1 [-1])
    l11lll = l1ll1ll1 [:-1]
    l1ll = l1l % len (l11lll)
    l1lll1 = l11lll [:l1ll] + l11lll [l1ll:]
    if l11111l:
        l11l11l = l1llllll () .join ([unichr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l111 - (l11l + l1l) % l1lll111) for l11l, char in enumerate (l1lll1)])
    return eval (l11l11l)
import re
class l1lllll(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111ll = kwargs.get(l1l1l1l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l1ll1 = kwargs.get(l1l1l1l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllll11 = self.l111111l(args)
        if l1lllll11:
            args=args+ l1lllll11
        self.args = [a for a in args]
    def l111111l(self, *args):
        l1lllll11=None
        l11l1lll = args[0][0]
        if re.search(l1l1l1l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11l1lll):
            l1lllll11 = (l1l1l1l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l11111ll
                            ,)
        return l1lllll11
class l1lll11ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll11 = self.l111111l(args)
        if l1lllll11:
            args = args + l1lllll11
        self.args = [a for a in args]
    def l111111l(self, *args):
        s = l1l1l1l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l1l1l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1lll(Exception):
    pass
class l11ll1l(Exception):
    pass
class l1llllll1(Exception):
    def __init__(self, message, l11111l1, url):
        super(l1llllll1,self).__init__(message)
        self.l11111l1 = l11111l1
        self.url = url
class l1llll1ll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1111111(Exception):
    pass
class l111l111(Exception):
    pass