#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l1lllll1 = 2048
l1lll1 = 7
def l1ll1ll (l11l1ll):
    global l11l1l
    l1llllll = ord (l11l1ll [-1])
    l111111 = l11l1ll [:-1]
    l1ll1ll1 = l1llllll % len (l111111)
    l1l1ll = l111111 [:l1ll1ll1] + l111111 [l1ll1ll1:]
    if l1lllll:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    return eval (l1111)
import hashlib
import os
import l111lll
from l111ll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111lll import l1111l1
from l1l1l1l import l11, l11lll
import logging
logger = logging.getLogger(l1ll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111ll():
    def __init__(self, l11l1l1,l11111l, l11lll1= None, l1llll=None):
        self.l1l111l=False
        self.l111l11 = self._1ll()
        self.l11111l = l11111l
        self.l11lll1 = l11lll1
        self.l11111 = l11l1l1
        if l11lll1:
            self.l1lll11l = True
        else:
            self.l1lll11l = False
        self.l1llll = l1llll
    def _1ll(self):
        try:
            return l111lll.l11l11() is not None
        except:
            return False
    def open(self):
        l1ll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111l11:
            raise NotImplementedError(l1ll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll1 = self.l11111
        if self.l11111l.lower().startswith(self.l11111.lower()):
            l1lll111 = re.compile(re.escape(self.l11111), re.IGNORECASE)
            l11111l = l1lll111.sub(l1ll1ll (u"ࠨࠩࠄ"), self.l11111l)
            l11111l = l11111l.replace(l1ll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1l1l(self.l11111, l11ll1, l11111l, self.l11lll1)
    def l1ll1l1l(self,l11111, l11ll1, l11111l, l11lll1):
        l1ll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l11l = l11llll(l11111)
        l11l1 = self.l1l1l11(l1l11l)
        logger.info(l1ll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l11l)
        if l11l1:
            logger.info(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111l1(l1l11l)
            l1l11l = l1ll11l(l11111, l11ll1, l11lll1, self.l1llll)
        logger.debug(l1ll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1=l1l11l + l1ll1ll (u"ࠤ࠲ࠦࠌ") + l11111l
        l11l = l1ll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1+ l1ll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11l)
        l1ll111 = os.system(l11l)
        if (l1ll111 != 0):
            raise IOError(l1ll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1, l1ll111))
    def l1l1l11(self, l1l11l):
        if os.path.exists(l1l11l):
            if os.path.islink(l1l11l):
                l1l11l = os.readlink(l1l11l)
            if os.path.ismount(l1l11l):
                return True
        return False
def l11llll(l11111):
    l1 = l11111.replace(l1ll1ll (u"࠭࡜࡝ࠩࠐ"), l1ll1ll (u"ࠧࡠࠩࠑ")).replace(l1ll1ll (u"ࠨ࠱ࠪࠒ"), l1ll1ll (u"ࠩࡢࠫࠓ"))
    l1l1l1 = l1ll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l11ll=os.environ[l1ll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll1l1=os.path.join(l1l11ll,l1l1l1, l1)
    l1lll1l=os.path.abspath(l1lll1l1)
    return l1lll1l
def l1ll1111(l1lll1ll):
    if not os.path.exists(l1lll1ll):
        os.makedirs(l1lll1ll)
def l1l11l1(l11111, l11ll1, l1llll11=None, password=None):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll1ll = l11llll(l11111)
    l1ll1111(l1lll1ll)
    if not l1llll11:
        l1ll11l1 = l1l1111()
        l1llll1 =l1ll11l1.l1ll1l(l1ll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll1 + l1ll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll1 + l1ll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll1, str):
            l1llll11, password = l1llll1
        else:
            raise l11lll()
        logger.info(l1ll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll1ll))
    l1l11 = pwd.getpwuid( os.getuid())[0]
    l11l11l=os.environ[l1ll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1111l={l1ll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l11, l1ll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11111, l1ll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll1ll, l1ll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11l11l, l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1llll11, l1ll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1111l, temp_file)
        if not os.path.exists(os.path.join(l11ll, l1ll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll11ll=l1ll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1ll (u"ࠧࠨࠤ")
        else:
            l1ll11ll=l1ll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l11=l1ll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll11ll,temp_file.name)
        l1l=[l1ll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11ll, l1ll1l11)]
        p = subprocess.Popen(l1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll1ll
    logger.debug(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll1l=os.path.abspath(l1lll1ll)
    logger.debug(l1ll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll1l)
    return l1lll1l
def l1ll11l(l11111, l11ll1, l11lll1, l1llll):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll111l(title):
        ll=30
        if len(title)>ll:
            l111ll=title.split(l1ll1ll (u"ࠨ࠯ࠣ࠳"))
            l11ll11=l1ll1ll (u"ࠧࠨ࠴")
            for block in l111ll:
                l11ll11+=block+l1ll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l11ll11) > ll:
                    l11ll11+=l1ll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11ll11
        return title
    def l1ll11(l111l1, password):
        l1ll1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1ll (u"ࠧࠦࠢ࠹").join(l111l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1lll = l1ll1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1lll.encode())
        l111l1l = [l1ll1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11ll1l = l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11ll1l)
            for e in l111l1l:
                if e in l11ll1l: return False
            raise l11(l11ll1l, l1ll11l=l111lll.l11l11(), l11ll1=l11ll1)
        logger.info(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1llll11 = l1ll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1ll (u"ࠦࠧ࠿")
    os.system(l1ll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll11 = l11llll(l11111)
    l1lll1ll = l11llll(hashlib.sha1(l11111.encode()).hexdigest()[:10])
    l1ll1111(l1lll1ll)
    logger.info(l1ll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1lll1ll))
    if l11lll1:
        l111l1 = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1llll11, l11lll1),
                    urllib.parse.unquote(l11ll1), os.path.abspath(l1lll1ll)]
        l1ll11(l111l1, password)
    else:
        while True:
            l1llll11, password = l1l111(l1lll1ll, l11ll1, l1llll)
            if l1llll11.lower() != l1ll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l111l1 = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡋ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡍ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1llll11,
                            urllib.parse.unquote(l11ll1), os.path.abspath(l1lll1ll)]
            else:
                raise l11lll()
            if l1ll11(l111l1, password): break
    os.system(l1ll1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1lll1ll, l1lll11))
    l1lll1l=os.path.abspath(l1lll11)
    return l1lll1l
def l1l111(l11111, l11ll1, l1llll):
    l1ll1 = os.path.join(os.environ[l1ll1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1)):
       os.makedirs(os.path.dirname(l1ll1))
    l1l1l = l1llll.get_value(l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll11l1 = l1l1111(l11111, l1l1l)
    l1llll11, password = l1ll11l1.l1ll1l(l1ll1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11ll1 + l1ll1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11ll1 + l1ll1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1llll11 != l1ll1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111l(l11111, l1llll11):
        l1ll1l1 = l1ll1ll (u"ࠤ࡙ࠣࠦ").join([l11111, l1llll11, l1ll1ll (u"࡚ࠪࠦࠬ") + password + l1ll1ll (u"࡛ࠫࠧ࠭"), l1ll1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1, l1ll1ll (u"࠭ࡷࠬࠩ࡝")) as l1ll1lll:
            l1ll1lll.write(l1ll1l1)
        os.chmod(l1ll1, 0o600)
    return l1llll11, password
def l111l(l11111, l1llll11):
    l1ll1 = l1l1ll1 = os.path.join(os.environ[l1ll1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1):
        with open(l1ll1, l1ll1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l111 = data[0].split(l1ll1ll (u"ࠦࠥࠨࡢ"))
            if l11111 == l11l111[0] and l1llll11 == l11l111[1]:
                return True
    return False