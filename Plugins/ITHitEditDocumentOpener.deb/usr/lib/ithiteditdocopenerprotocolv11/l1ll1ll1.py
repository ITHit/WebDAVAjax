#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l1 = sys.version_info [0] == 2
l111lll = 2048
l1l = 7
def l1ll1ll (l11l1ll):
    global l1lll11
    l1l1111 = ord (l11l1ll [-1])
    l1111l = l11l1ll [:-1]
    l1l1 = l1l1111 % len (l1111l)
    l1l1l1 = l1111l [:l1l1] + l1111l [l1l1:]
    if l1111l1:
        l11l1l1 = l11 () .join ([unichr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    else:
        l11l1l1 = str () .join ([chr (ord (char) - l111lll - (l1lll + l1l1111) % l1l) for l1lll, char in enumerate (l1l1l1)])
    return eval (l11l1l1)
import re
class ll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll11ll = kwargs.get(l1ll1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l1l11 = kwargs.get(l1ll1ll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l11111ll = self.l1111l11(args)
        if l11111ll:
            args=args+ l11111ll
        self.args = [a for a in args]
    def l1111l11(self, *args):
        l11111ll=None
        l1l1l111 = args[0][0]
        if re.search(l1ll1ll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1l111):
            l11111ll = (l1ll1ll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll11ll
                            ,)
        return l11111ll
class l1llll111(Exception):
    def __init__(self, *args, **kwargs):
        l11111ll = self.l1111l11(args)
        if l11111ll:
            args = args + l11111ll
        self.args = [a for a in args]
    def l1111l11(self, *args):
        s = l1ll1ll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll1ll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1lll(Exception):
    pass
class l1l11ll(Exception):
    pass
class l1llll1ll(Exception):
    def __init__(self, message, l1lll1l1l, url):
        super(l1llll1ll,self).__init__(message)
        self.l1lll1l1l = l1lll1l1l
        self.url = url
class l1llllll1(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l111111l(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1111111(Exception):
    pass
class l111lll1(Exception):
    pass