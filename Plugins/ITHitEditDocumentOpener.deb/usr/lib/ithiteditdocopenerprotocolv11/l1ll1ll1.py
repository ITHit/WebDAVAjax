#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1l1l1l = 2048
l111l = 7
def l1111 (l1ll1l11):
    global l11l111
    l1lll11l = ord (l1ll1l11 [-1])
    l1l11ll = l1ll1l11 [:-1]
    l111lll = l1lll11l % len (l1l11ll)
    l1l111l = l1l11ll [:l111lll] + l1l11ll [l111lll:]
    if l11ll1:
        l11l1ll = l1l111 () .join ([unichr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    else:
        l11l1ll = str () .join ([chr (ord (char) - l1l1l1l - (l1l + l1lll11l) % l111l) for l1l, char in enumerate (l1l111l)])
    return eval (l11l1ll)
import re
class l1lll1l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1l1l = kwargs.get(l1111 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l1l11 = kwargs.get(l1111 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llllll1 = self.l1llll1l1(args)
        if l1llllll1:
            args=args+ l1llllll1
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        l1llllll1=None
        l1l1111l = args[0][0]
        if re.search(l1111 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1111l):
            l1llllll1 = (l1111 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1l1l
                            ,)
        return l1llllll1
class l1lll11ll(Exception):
    def __init__(self, *args, **kwargs):
        l1llllll1 = self.l1llll1l1(args)
        if l1llllll1:
            args = args + l1llllll1
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        s = l1111 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1111 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1lll(Exception):
    pass
class l1ll1(Exception):
    pass
class l1lllllll(Exception):
    def __init__(self, message, l1llll11l, url):
        super(l1lllllll,self).__init__(message)
        self.l1llll11l = l1llll11l
        self.url = url
class l1111l11(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111l1(Exception):
    pass
class l111111l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1111111(Exception):
    pass
class l11111ll(Exception):
    pass
class l11l11ll(Exception):
    pass