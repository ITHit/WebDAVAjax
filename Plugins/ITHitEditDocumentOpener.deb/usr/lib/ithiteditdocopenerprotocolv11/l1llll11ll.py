#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l11 = 2048
l11111 = 7
def l1l1l1 (l111):
    global l1l1
    l1llll1 = ord (l111 [-1])
    l1ll11l = l111 [:-1]
    l1lll111 = l1llll1 % len (l1ll11l)
    l1lll = l1ll11l [:l1lll111] + l1ll11l [l1lll111:]
    if l1lllll:
        l1l111 = l111lll () .join ([unichr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11 - (l1ll11l1 + l1llll1) % l11111) for l1ll11l1, char in enumerate (l1lll)])
    return eval (l1l111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1ll1=logging.WARNING
logger = logging.getLogger(l1l1l1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll1ll1)
l1l1ll1l = SysLogHandler(address=l1l1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l1l1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l1l1ll1l)
ch = logging.StreamHandler()
ch.setLevel(l1llll1ll1)
logger.addHandler(ch)
class l1lll1lll1(io.FileIO):
    l1l1l1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l1l1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1l1l, l1lll111l1,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1l1l = l1llll1l1l
            self.l1lll111l1 = l1lll111l1
            if not options:
                options = l1l1l1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1l1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1l1l,
                                              self.l1lll111l1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1llll = os.path.join(os.path.sep, l1l1l1 (u"ࠪࡩࡹࡩࠧই"), l1l1l1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll11l11 = path
        else:
            self._1lll11l11 = self.l1lll1llll
        super(l1lll1lll1, self).__init__(self._1lll11l11, l1l1l1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1llllll1l(self, line):
        return l1lll1lll1.Entry(*[x for x in line.strip(l1l1l1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l1l1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1l1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1l1 (u"ࠤࠦࠦ঍")):
                    yield self._1llllll1l(line)
            except ValueError:
                pass
    def l1llll1lll(self, attr, value):
        for entry in self.entries:
            l1lll1ll11 = getattr(entry, attr)
            if l1lll1ll11 == value:
                return entry
        return None
    def l1llllll11(self, entry):
        if self.l1llll1lll(l1l1l1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l1l1 (u"ࠫࡡࡴࠧএ")).encode(l1l1l1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll111l(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1l1 (u"ࠢࠤࠤ঒")):
                if self._1llllll1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1l1 (u"ࠨࠩও").join(lines).encode(l1l1l1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllll111(cls, l1llll1l1l, path=None):
        l1lllll1l1 = cls(path=path)
        entry = l1lllll1l1.l1llll1lll(l1l1l1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1l1l)
        if entry:
            return l1lllll1l1.l1llll111l(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1l1l, l1lll111l1, options=None, path=None):
        return cls(path=path).l1llllll11(l1lll1lll1.Entry(device,
                                                    l1llll1l1l, l1lll111l1,
                                                    options=options))
class l1lllll11l(object):
    def __init__(self, l1lll1l1l1):
        self.l1llll1111=l1l1l1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11ll1=l1l1l1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1l1l1=l1lll1l1l1
        self.l1lllllll1()
        self.l1lll111ll()
        self.l1lll11lll()
        self.l1lll1111l()
        self.l1lll11l1l()
    def l1lllllll1(self):
        temp_file=open(l1lll1ll1l,l1l1l1 (u"࠭ࡲࠨঘ"))
        l1l1l11=temp_file.read()
        data=json.loads(l1l1l11)
        self.user=data[l1l1l1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll=data[l1l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11l111=data[l1l1l1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll111=data[l1l1l1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11111=data[l1l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l1ll=data[l1l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll11lll(self):
        l1lllll1=os.path.join(l1l1l1 (u"ࠨ࠯ࠣট"),l1l1l1 (u"ࠢࡶࡵࡵࠦঠ"),l1l1l1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l1l1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l1l1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1lllll1)
    def l1lll11l1l(self):
        logger.info(l1l1l1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11l111=os.path.join(self.l1ll111,self.l1llll1111)
        l1llll1l11 = pwd.getpwnam(self.user).pw_uid
        l1lll1l111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l111):
            os.makedirs(l11l111)
            os.system(l1l1l1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11l111))
            logger.debug(l1l1l1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11l111)
        else:
            logger.debug(l1l1l1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11l111)
        l1lllll1=os.path.join(l11l111, self.l1lll11ll1)
        print(l1lllll1)
        logger.debug(l1l1l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1lllll1)
        with open(l1lllll1, l1l1l1 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l11l:
            logger.debug(self.l1ll + l1l1l1 (u"ࠪࠤࠬপ")+self.l1lll11111+l1l1l1 (u"ࠫࠥࠨࠧফ")+self.l1lll1l1ll+l1l1l1 (u"ࠬࠨࠧব"))
            l1lll1l11l.writelines(self.l1ll + l1l1l1 (u"࠭ࠠࠨভ")+self.l1lll11111+l1l1l1 (u"ࠧࠡࠤࠪম")+self.l1lll1l1ll+l1l1l1 (u"ࠨࠤࠪয"))
        os.chmod(l1lllll1, 0o600)
        os.chown(l1lllll1, l1llll1l11, l1lll1l111)
    def l1lll111ll(self, l1lllll1ll=l1l1l1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l1l1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lllll1ll in groups:
            logger.info(l1l1l1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lllll1ll))
        else:
            logger.warning(l1l1l1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lllll1ll))
            l11l=l1l1l1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lllll1ll,self.user)
            logger.debug(l1l1l1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l11l)
            os.system(l11l)
            logger.debug(l1l1l1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1111l(self):
        logger.debug(l1l1l1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lllll1l1=l1lll1lll1()
        l1lllll1l1.add(self.l1ll, self.l11l111, l1lll111l1=l1l1l1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l1l1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l1l1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1ll1l = urllib.parse.unquote(sys.argv[1])
        if l1lll1ll1l:
            l1llll11l1=l1lllll11l(l1lll1ll1l)
        else:
            raise (l1l1l1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l1l1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise