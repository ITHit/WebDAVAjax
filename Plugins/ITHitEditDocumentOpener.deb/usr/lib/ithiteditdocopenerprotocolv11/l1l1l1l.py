#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lllll = sys.version_info [0] == 2
l1lllll1 = 2048
l1lll1 = 7
def l1ll1ll (l11l1ll):
    global l11l1l
    l1llllll = ord (l11l1ll [-1])
    l111111 = l11l1ll [:-1]
    l1ll1ll1 = l1llllll % len (l111111)
    l1l1ll = l111111 [:l1ll1ll1] + l111111 [l1ll1ll1:]
    if l1lllll:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1lllll1 - (l111 + l1llllll) % l1lll1) for l111, char in enumerate (l1l1ll)])
    return eval (l1111)
import re
class l11(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111l11 = kwargs.get(l1ll1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11ll1 = kwargs.get(l1ll1ll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllll1l = self.l11111ll(args)
        if l1lllll1l:
            args=args+ l1lllll1l
        self.args = [a for a in args]
    def l11111ll(self, *args):
        l1lllll1l=None
        l1l11ll1 = args[0][0]
        if re.search(l1ll1ll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11ll1):
            l1lllll1l = (l1ll1ll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1111l11
                            ,)
        return l1lllll1l
class l1lll1ll1(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll1l = self.l11111ll(args)
        if l1lllll1l:
            args = args + l1lllll1l
        self.args = [a for a in args]
    def l11111ll(self, *args):
        s = l1ll1ll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll1ll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1l11(Exception):
    pass
class l11lll(Exception):
    pass
class l111111l(Exception):
    def __init__(self, message, l1llllll1, url):
        super(l111111l,self).__init__(message)
        self.l1llllll1 = l1llllll1
        self.url = url
class l1111111(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111l111(Exception):
    pass