#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l11 = sys.version_info [0] == 2
l1l11l = 2048
l1llll1 = 7
def l1lll111 (l11ll):
    global l111ll
    l1 = ord (l11ll [-1])
    l1ll1l1 = l11ll [:-1]
    l11l1 = l1 % len (l1ll1l1)
    l1l11 = l1ll1l1 [:l11l1] + l1ll1l1 [l11l1:]
    if l111l11:
        l11l111 = l1llll11 () .join ([unichr (ord (char) - l1l11l - (l1ll11l1 + l1) % l1llll1) for l1ll11l1, char in enumerate (l1l11)])
    else:
        l11l111 = str () .join ([chr (ord (char) - l1l11l - (l1ll11l1 + l1) % l1llll1) for l1ll11l1, char in enumerate (l1l11)])
    return eval (l11l111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11l1l=logging.WARNING
logger = logging.getLogger(l1lll111 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11l1l)
l1l1llll = SysLogHandler(address=l1lll111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll111 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1llll.setFormatter(formatter)
logger.addHandler(l1l1llll)
ch = logging.StreamHandler()
ch.setLevel(l1lll11l1l)
logger.addHandler(ch)
class l1lllll1ll(io.FileIO):
    l1lll111 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll111 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1l111, l1lll1l11l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1l111 = l1lll1l111
            self.l1lll1l11l = l1lll1l11l
            if not options:
                options = l1lll111 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll111 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1l111,
                                              self.l1lll1l11l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1111l = os.path.join(os.path.sep, l1lll111 (u"ࠪࡩࡹࡩࠧই"), l1lll111 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1ll11 = path
        else:
            self._1lll1ll11 = self.l1lll1111l
        super(l1lllll1ll, self).__init__(self._1lll1ll11, l1lll111 (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l1l(self, line):
        return l1lllll1ll.Entry(*[x for x in line.strip(l1lll111 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll111 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll111 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll111 (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l1l(line)
            except ValueError:
                pass
    def l1lll111ll(self, attr, value):
        for entry in self.entries:
            l1lll1l1l1 = getattr(entry, attr)
            if l1lll1l1l1 == value:
                return entry
        return None
    def l1llll11l1(self, entry):
        if self.l1lll111ll(l1lll111 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll111 (u"ࠫࡡࡴࠧএ")).encode(l1lll111 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1llll(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll111 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll111 (u"ࠢࠤࠤ঒")):
                if self._1llll1l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll111 (u"ࠨࠩও").join(lines).encode(l1lll111 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llll111l(cls, l1lll1l111, path=None):
        l1llll1l11 = cls(path=path)
        entry = l1llll1l11.l1lll111ll(l1lll111 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1l111)
        if entry:
            return l1llll1l11.l1lll1llll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1l111, l1lll1l11l, options=None, path=None):
        return cls(path=path).l1llll11l1(l1lllll1ll.Entry(device,
                                                    l1lll1l111, l1lll1l11l,
                                                    options=options))
class l1lll11111(object):
    def __init__(self, l1lll11lll):
        self.l1lll11l11=l1lll111 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lllll1l1=l1lll111 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll11lll=l1lll11lll
        self.l1lll111l1()
        self.l1lllll111()
        self.l1llll1lll()
        self.l1lllllll1()
        self.l1llllll11()
    def l1lll111l1(self):
        temp_file=open(l1lllll11l,l1lll111 (u"࠭ࡲࠨঘ"))
        l1lll1ll=temp_file.read()
        data=json.loads(l1lll1ll)
        self.user=data[l1lll111 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l1ll1=data[l1lll111 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11l1l=data[l1lll111 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1lll1=data[l1lll111 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll11ll=data[l1lll111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1lll1=data[l1lll111 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1lll(self):
        l1l1l11=os.path.join(l1lll111 (u"ࠨ࠯ࠣট"),l1lll111 (u"ࠢࡶࡵࡵࠦঠ"),l1lll111 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll111 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll111 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l1l11)
    def l1llllll11(self):
        logger.info(l1lll111 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11l1l=os.path.join(self.l1lll1,self.l1lll11l11)
        l1lll1ll1l = pwd.getpwnam(self.user).pw_uid
        l1lll11ll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l1l):
            os.makedirs(l11l1l)
            os.system(l1lll111 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11l1l))
            logger.debug(l1lll111 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11l1l)
        else:
            logger.debug(l1lll111 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11l1l)
        l1l1l11=os.path.join(l11l1l, self.l1lllll1l1)
        print(l1l1l11)
        logger.debug(l1lll111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l1l11)
        with open(l1l1l11, l1lll111 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l1ll:
            logger.debug(self.l1l1ll1 + l1lll111 (u"ࠪࠤࠬপ")+self.l1llll11ll+l1lll111 (u"ࠫࠥࠨࠧফ")+self.l1lll1lll1+l1lll111 (u"ࠬࠨࠧব"))
            l1lll1l1ll.writelines(self.l1l1ll1 + l1lll111 (u"࠭ࠠࠨভ")+self.l1llll11ll+l1lll111 (u"ࠧࠡࠤࠪম")+self.l1lll1lll1+l1lll111 (u"ࠨࠤࠪয"))
        os.chmod(l1l1l11, 0o600)
        os.chown(l1l1l11, l1lll1ll1l, l1lll11ll1)
    def l1lllll111(self, l1llll1ll1=l1lll111 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll111 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll1ll1 in groups:
            logger.info(l1lll111 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll1ll1))
        else:
            logger.warning(l1lll111 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll1ll1))
            l1lll=l1lll111 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll1ll1,self.user)
            logger.debug(l1lll111 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1lll)
            os.system(l1lll)
            logger.debug(l1lll111 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lllllll1(self):
        logger.debug(l1lll111 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1l11=l1lllll1ll()
        l1llll1l11.add(self.l1l1ll1, self.l11l1l, l1lll1l11l=l1lll111 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll111 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll111 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll11l = urllib.parse.unquote(sys.argv[1])
        if l1lllll11l:
            l1llll1111=l1lll11111(l1lllll11l)
        else:
            raise (l1lll111 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll111 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise