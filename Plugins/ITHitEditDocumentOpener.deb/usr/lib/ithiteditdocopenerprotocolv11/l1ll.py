#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l11 = sys.version_info [0] == 2
l1ll1l = 2048
l11ll11 = 7
def l1llllll (l11l111):
    global l11l11
    l1ll1l11 = ord (l11l111 [-1])
    l1llll = l11l111 [:-1]
    ll = l1ll1l11 % len (l1llll)
    l1ll1 = l1llll [:ll] + l1llll [ll:]
    if l1l1l11:
        l1l111 = l1llll1l () .join ([unichr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1ll1l - (l1l + l1ll1l11) % l11ll11) for l1l, char in enumerate (l1ll1)])
    return eval (l1l111)
import re
class l11l1l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llll1l1 = kwargs.get(l1llllll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l111l11 = kwargs.get(l1llllll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll111 = self.l11111ll(args)
        if l1llll111:
            args=args+ l1llll111
        self.args = [a for a in args]
    def l11111ll(self, *args):
        l1llll111=None
        l1l11111 = args[0][0]
        if re.search(l1llllll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11111):
            l1llll111 = (l1llllll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1llll1l1
                            ,)
        return l1llll111
class l1lll1l1l(Exception):
    def __init__(self, *args, **kwargs):
        l1llll111 = self.l11111ll(args)
        if l1llll111:
            args = args + l1llll111
        self.args = [a for a in args]
    def l11111ll(self, *args):
        s = l1llllll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1llllll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1111l11(Exception):
    pass
class l11l1ll(Exception):
    pass
class l1lll1lll(Exception):
    def __init__(self, message, l1lllll11, url):
        super(l1lll1lll,self).__init__(message)
        self.l1lllll11 = l1lllll11
        self.url = url
class l1111111(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l111111l(Exception):
    pass
class l111l1ll(Exception):
    pass