#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l111l = 2048
l11llll = 7
def l11 (l1ll11):
    global l111l
    l1lll1l = ord (l1ll11 [-1])
    l1ll1l = l1ll11 [:-1]
    l1ll1l1 = l1lll1l % len (l1ll1l)
    l1111 = l1ll1l [:l1ll1l1] + l1ll1l [l1ll1l1:]
    if l1l111:
        l1ll1 = l1l11ll () .join ([unichr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    else:
        l1ll1 = str () .join ([chr (ord (char) - l1l111l - (l1lllll1 + l1lll1l) % l11llll) for l1lllll1, char in enumerate (l1111)])
    return eval (l1ll1)
import hashlib
import os
import l111ll1
from l1lll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111ll1 import l11l11
from l111 import l1l11l1, l11ll1
import logging
logger = logging.getLogger(l11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll1111():
    def __init__(self, l11ll11,l111l11, l1l1= None, l1l1ll=None):
        self.l11l1ll=False
        self.l1ll111l = self._l()
        self.l111l11 = l111l11
        self.l1l1 = l1l1
        self.l1lll11 = l11ll11
        if l1l1:
            self.l1ll1lll = True
        else:
            self.l1ll1lll = False
        self.l1l1ll = l1l1ll
    def _l(self):
        try:
            return l111ll1.l1ll() is not None
        except:
            return False
    def open(self):
        l11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll111l:
            raise NotImplementedError(l11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1llll1l = self.l1lll11
        if self.l111l11.lower().startswith(self.l1lll11.lower()):
            l1ll1ll = re.compile(re.escape(self.l1lll11), re.IGNORECASE)
            l111l11 = l1ll1ll.sub(l11 (u"ࠨࠩࠄ"), self.l111l11)
            l111l11 = l111l11.replace(l11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11lll(self.l1lll11, l1llll1l, l111l11, self.l1l1)
    def l11lll(self,l1lll11, l1llll1l, l111l11, l1l1):
        l11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1l11 = l11lll1(l1lll11)
        l1llll = self.l111lll(l1ll1l11)
        logger.info(l11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1l11)
        if l1llll:
            logger.info(l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l11(l1ll1l11)
            l1ll1l11 = l1l(l1lll11, l1llll1l, l1l1, self.l1l1ll)
        logger.debug(l11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111111=l1ll1l11 + l11 (u"ࠤ࠲ࠦࠌ") + l111l11
        l1l1l = l11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111111+ l11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1l)
        l111ll = os.system(l1l1l)
        if (l111ll != 0):
            raise IOError(l11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111111, l111ll))
    def l111lll(self, l1ll1l11):
        if os.path.exists(l1ll1l11):
            if os.path.islink(l1ll1l11):
                l1ll1l11 = os.readlink(l1ll1l11)
            if os.path.ismount(l1ll1l11):
                return True
        return False
def l11lll1(l1lll11):
    l1ll11l = l1lll11.replace(l11 (u"࠭࡜࡝ࠩࠐ"), l11 (u"ࠧࡠࠩࠑ")).replace(l11 (u"ࠨ࠱ࠪࠒ"), l11 (u"ࠩࡢࠫࠓ"))
    l1lll1l1 = l11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll1l=os.environ[l11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llll1=os.path.join(l11ll1l,l1lll1l1, l1ll11l)
    l11l1l=os.path.abspath(l1llll1)
    return l11l1l
def l1l1l1l(l111l1):
    if not os.path.exists(l111l1):
        os.makedirs(l111l1)
def l11l11l(l1lll11, l1llll1l, l1lll1=None, password=None):
    l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111l1 = l11lll1(l1lll11)
    l1l1l1l(l111l1)
    if not l1lll1:
        l11111l = l1lll11l()
        l11ll =l11111l.l1l11(l11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1llll1l + l11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1llll1l + l11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11ll, str):
            l1lll1, password = l11ll
        else:
            raise l11ll1()
        logger.info(l11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111l1))
    l1lllll = pwd.getpwuid( os.getuid())[0]
    l1111l=os.environ[l11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll111=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l1l11={l11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lllll, l11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1lll11, l11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111l1, l11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1111l, l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll1, l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l1l11, temp_file)
        if not os.path.exists(os.path.join(l1lll111, l11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1l1l=l11 (u"ࠦࡵࡿࠢࠣ")
            key=l11 (u"ࠧࠨࠤ")
        else:
            l1ll1l1l=l11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1ll1=l11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1l1l,temp_file.name)
        l1111ll=[l11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll111, l1l1ll1)]
        p = subprocess.Popen(l1111ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111l1
    logger.debug(l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11l1l=os.path.abspath(l111l1)
    logger.debug(l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11l1l)
    return l11l1l
def l1l(l1lll11, l1llll1l, l1l1, l1l1ll):
    l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1llll11(title):
        l11111=30
        if len(title)>l11111:
            l1ll111=title.split(l11 (u"ࠨ࠯ࠣ࠳"))
            l1=l11 (u"ࠧࠨ࠴")
            for block in l1ll111:
                l1+=block+l11 (u"ࠣ࠱ࠥ࠵")
                if len(l1) > l11111:
                    l1+=l11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1
        return title
    def l111l1l(l1llllll, password):
        l11 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11 (u"ࠧࠦࠢ࠹").join(l1llllll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l1lll = l11 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l1lll.encode())
        l1ll1ll1 = [l11 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11l111 = l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11l111)
            for e in l1ll1ll1:
                if e in l11l111: return False
            raise l1l11l1(l11l111, l1l=l111ll1.l1ll(), l1llll1l=l1llll1l)
        logger.info(l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll1 = l11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11 (u"ࠦࠧ࠿")
    os.system(l11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll11l1 = l11lll1(l1lll11)
    l111l1 = l11lll1(hashlib.sha1(l1lll11.encode()).hexdigest()[:10])
    l1l1l1l(l111l1)
    logger.info(l11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111l1))
    if l1l1:
        l1llllll = [l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11 (u"ࠤ࠰ࡸࠧࡄ"), l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11 (u"ࠫ࠲ࡵࠧࡆ"), l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll1, l1l1),
                    urllib.parse.unquote(l1llll1l), os.path.abspath(l111l1)]
        l111l1l(l1llllll, password)
    else:
        while True:
            l1lll1, password = l1l1111(l111l1, l1llll1l, l1l1ll)
            if l1lll1.lower() != l11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1llllll = [l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11 (u"ࠤ࠰ࡸࠧࡋ"), l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11 (u"ࠫ࠲ࡵࠧࡍ"), l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll1,
                            urllib.parse.unquote(l1llll1l), os.path.abspath(l111l1)]
            else:
                raise l11ll1()
            if l111l1l(l1llllll, password): break
    os.system(l11 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111l1, l1ll11l1))
    l11l1l=os.path.abspath(l1ll11l1)
    return l11l1l
def l1l1111(l1lll11, l1llll1l, l1l1ll):
    l11l1 = os.path.join(os.environ[l11 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l1)):
       os.makedirs(os.path.dirname(l11l1))
    l1111l1 = l1l1ll.get_value(l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11111l = l1lll11l(l1lll11, l1111l1)
    l1lll1, password = l11111l.l1l11(l11 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1llll1l + l11 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1llll1l + l11 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll1 != l11 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l1l1(l1lll11, l1lll1):
        l1ll11ll = l11 (u"ࠤ࡙ࠣࠦ").join([l1lll11, l1lll1, l11 (u"࡚ࠪࠦࠬ") + password + l11 (u"࡛ࠫࠧ࠭"), l11 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l1, l11 (u"࠭ࡷࠬࠩ࡝")) as l11l1l1:
            l11l1l1.write(l1ll11ll)
        os.chmod(l11l1, 0o600)
    return l1lll1, password
def l1l1l1(l1lll11, l1lll1):
    l11l1 = l11l = os.path.join(os.environ[l11 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l1):
        with open(l11l1, l11 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lll1ll = data[0].split(l11 (u"ࠦࠥࠨࡢ"))
            if l1lll11 == l1lll1ll[0] and l1lll1 == l1lll1ll[1]:
                return True
    return False