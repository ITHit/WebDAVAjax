#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11ll = sys.version_info [0] == 2
l111ll1 = 2048
l1l1l = 7
def l1l1 (l111ll):
    global l1lllll
    l1ll1l1l = ord (l111ll [-1])
    l11llll = l111ll [:-1]
    l1111 = l1ll1l1l % len (l11llll)
    l1llllll = l11llll [:l1111] + l11llll [l1111:]
    if l1ll11ll:
        l1ll1l11 = l11l1l1 () .join ([unichr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    else:
        l1ll1l11 = str () .join ([chr (ord (char) - l111ll1 - (l1111ll + l1ll1l1l) % l1l1l) for l1111ll, char in enumerate (l1llllll)])
    return eval (l1ll1l11)
import gi
gi.require_version(l1l1 (u"ࠨࡉࡷ࡯ࠬঽ"), l1l1 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1llll
import logging
logger = logging.getLogger(l1l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1ll(Gtk.Window):
    def __init__(self, l1ll1111l1, l1ll1l1l11):
        Gtk.Window.__init__(self)
        self.l1l1l1=30
        self.l1l1ll1l11 = False
        self.service = l1ll1111l1
        self.l111l1l=l1ll1l1l11
        self.l1l=l1l1llll.l1l1111l
        self.l1ll1l1l1l = Gtk.ListStore(str)
        self.l1l1l1llll()
    def l1l1l11l1l(self, service):
        l1l1l1l1ll = self.l1l.l11lll11(l1l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1l1l1ll
    def l1l1l1llll(self, l1ll1111l1=None):
        if l1ll1111l1:
            self.l1ll1l1l1l.clear()
            l1ll1l1lll=self.l1l1l11l1l(l1ll1111l1)
            self.l1ll1l1l1l.append([l1l1 (u"ࠧࠨু")])
            for l111l1l in l1ll1l1lll:
                self.l1ll1l1l1l.append([l111l1l])
        else:
            self.l1ll1l1l1l.clear()
            self.l1ll1l1l1l.append([l1l1 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1ll11ll(self, widget, data=None):
        l1l1ll11l1= widget.get_active()
        if data == l1l1 (u"ࠢ࠲ࠤৃ") and l1l1ll11l1:
            self.l1l1l1llll()
            self.l1l1lll111.set_active(0)
            self.l1ll111l11.set_text(l1l1 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll111l11.set_sensitive(False)
            self.l1l1lll111.set_sensitive(False)
        else:
            self.l1l1l1llll(l1ll1111l1=self.service)
            self.l1l1lll111.set_active(0)
            self.l1ll111l11.set_text(l1l1 (u"ࠤࠥ৅"))
            self.l1l1lll111.set_sensitive(True)
            self.l1ll111l11.set_sensitive(True)
    def l1l11l11ll(self, widget):
        if widget.get_active():
            l111l1l = widget.get_child().get_text()
        else:
            l111l1l = self.l1ll1l1l1l[widget.get_active()][0]
        password = self.l1ll11l11l(self.service, l111l1l)
        if password:
            self.l1ll111l11.set_text(password)
        else:
            self.l1ll111l11.set_text(l1l1 (u"ࠥࠦ৆"))
    def l1ll1l1111(self, l111l1l, pwd, service):
        keyring.set_password(service, l111l1l, pwd)
        l1l1l1l1ll=self.l1l.l11lll11(l1l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l111l1l in l1l1l1l1ll:
            value = self.l1l.get_value(l1l1 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l.l11lllll(l1l1 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1l1 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l111l1l))
    def l1ll11l11l(self, service, l111l1l):
        l1ll11llll = keyring.get_password(service, l111l1l)
        return l1ll11llll
    def l1l1l1l11l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1ll1lll(self, widget, data=None):
        self.l1l1ll1l11=widget.get_active()
    def l1ll1l(self, message, title=l1l1 (u"ࠨࠩো"), l1ll111l1=True):
        if l1ll111l1:
            l1ll1lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1lll11 = Gtk.MessageDialog(self,
            l1ll1lllll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1lll11.set_title(title)
        l1ll1lll11.set_default_response(Gtk.ResponseType.OK)
        l1l1l111l1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1lll1l1 = Gtk.VBox()
        l1l1l1lll1 = Gtk.Box(spacing=1)
        l1l1l1lll1.set_homogeneous(False)
        l1ll1llll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1llll1.set_homogeneous(False)
        l1ll11l111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11l111.set_homogeneous(False)
        l1l1l1lll1.pack_start(l1ll1llll1, True, True, 0)
        l1l1l1lll1.pack_start(l1ll11l111, True, True, 0)
        l1l1l11lll = l1ll1lll11.get_content_area()
        l1l1llll1l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l11lll.pack_start(l1l1llll1l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l11ll1 = Gtk.Label()
        l1l11ll111 = Gtk.Label()
        l1l11ll111.set_text(l1l1 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l11ll111, True, True, 0)
        l1l1l11ll1.set_text(l1l1 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1l11ll1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l11ll1, 0, 1, 0, 1)
        l1ll111111 = Gtk.RadioButton.new_with_label_from_widget(None, l1l1 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1ll111111.connect(l1l1 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1ll11ll, l1l1 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1ll111111, 1, 2, 0, 1)
        l1ll11l1ll = Gtk.RadioButton.new_with_label_from_widget(l1ll111111, l1l1 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll11l1ll.connect(l1l1 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1ll11ll, l1l1 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll11l1ll, 1, 2, 1, 2)
        l1l1l1l111 = Gtk.Label()
        l1l1l1l111.set_text(l1l1 (u"ࠥࠤࠧ৔"))
        table.attach(l1l1l1l111, 0, 1, 4, 6)
        l1l11llll1 = Gtk.Label()
        l1l11llll1.set_text(l1l1 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l11llll1.set_justify(Gtk.Justification.RIGHT)
        l1l11llll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l1lll111 = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1l1l1l)
        self.l1l1lll111.set_entry_text_column(0)
        table.attach(l1l11llll1, 0, 1, 6, 8)
        table.attach(self.l1l1lll111, 1, 3, 6, 8)
        self.l1l1lll111.connect(l1l1 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l11l11ll)
        l1l11lllll = Gtk.Label()
        l1l11lllll.set_text(l1l1 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l11lllll.set_justify(Gtk.Justification.RIGHT)
        l1l11lllll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll111l11 = Gtk.Entry()
        self.l1ll111l11.set_visibility(False)
        self.l1ll111l11.connect(l1l1 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1l1l11l, l1ll1lll11)
        table.attach(l1l11lllll, 0, 1, 8, 10)
        table.attach(self.l1ll111l11, 1, 3, 8, 10)
        l1l1ll1ll1 = Gtk.CheckButton(l1l1 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll1ll1.connect(l1l1 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1ll1lll, l1l1ll1ll1)
        l1l1ll1ll1.set_active(False)
        table.attach(l1l1ll1ll1, 1, 3, 12, 14)
        l1l1llllll = Gtk.Label()
        l1l1llllll.set_text(l1l1 (u"ࠥࠤࠧ৛") * 5)
        l1l1lll1l1.pack_start(l1l1llllll, True, True, 0)
        if self.l111l1l:
            l1ll11l1ll.set_active(True)
            self.l1l1lll111.set_active(0)
            self.l1l1lll111.set_sensitive(True)
            self.l1ll111l11.set_text(l1l1 (u"ࠦࠧড়"))
            self.l1ll111l11.set_sensitive(True)
        else:
            self.l1l1lll111.set_active(0)
            self.l1l1lll111.set_sensitive(False)
            self.l1ll111l11.set_text(l1l1 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll111l11.set_sensitive(False)
        l1l1l111l1.pack_start(vbox, True, True, 0)
        l1l1l111l1.pack_start(table, True, True, 0)
        l1l1l111l1.pack_end(l1l1lll1l1, True, True, 0)
        l1l1llll1l.pack_start(l1l1l111l1, True, True, 0)
        l1ll1lll11.show_all()
        response = l1ll1lll11.run()
        if self.l1l1lll111.get_active():
            l111l1l = self.l1l1lll111.get_child().get_text()
        else:
            l111l1l = self.l1ll1l1l1l[self.l1l1lll111.get_active()][0]
        pwd = self.l1ll111l11.get_text()
        l1ll1lll11.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1ll1l11:
                self.l1ll1l1111(l111l1l, pwd, self.service)
            return l111l1l, pwd
        else:
            return l1l1 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1l1 (u"ࠧࠨয়")
class l11ll1111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l11ll1ll(self, l1l111l1):
        l1ll1ll11l = Gtk.ScrolledWindow()
        l1ll1ll11l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11l1l1=None
        self.l1ll1ll111 = Gtk.TextBuffer()
        self.l1ll1ll111.set_text(l1l111l1)
        self.set_style()
        regexp= l1l1 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll1ll1l1 = self._1l1ll1111(l1l111l1, regexp)
        self.l1l11ll11l(l1ll1ll1l1, self.l1ll1ll111.get_start_iter())
        self.l1ll1ll1ll = Gtk.TextView(buffer=self.l1ll1ll111)
        self.l1ll1ll1ll.set_property(l1l1 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll1ll1ll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll1ll1ll.connect(l1l1 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1llll11)
        self.l1ll1ll1ll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1ll11l.set_size_request(300,100)
        self.l1ll1ll1ll.show()
        l1ll1ll11l.add(self.l1ll1ll1ll)
        l1ll1ll11l.show()
        return l1ll1ll11l
    def _1l1llll11(self, *args, **kwargs):
        l1ll1l11ll, l1l1l111ll=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1l11ll, l1l1l111ll).get_tags()
        if not self.l1ll11l1l1:
            self.l1ll11l1l1 = args[1].window.get_cursor()
            self.l1ll11ll11 = Gdk.Cursor(Gdk.CursorType.l1ll11111l)
        elif tag:
            args[1].window.set_cursor(self.l1ll11ll11)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11l1l1:
                args[1].window.set_cursor(self.l1ll11l1l1)
    def _1l1ll1111(self, l1l111l1, l1l11ll1l1):
        res=[]
        l1l1l1l1l1=re.findall(l1l11ll1l1,l1l111l1)
        for l1l1ll1l1l in l1l1l1l1l1:
            for el in l1l1ll1l1l:
                if el:
                    res.append(el)
        return res
    def l1l11ll11l(self, l1ll1ll1l1, start):
        l1ll11ll1l=0
        for text in l1ll1ll1l1:
            end = self.l1ll1ll111.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll11ll1l+=1
                l1l1lllll1, l1l11l1lll = match
                tag = self.l1ll1ll111.create_tag(str(l1ll11ll1l), foreground=l1l1 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1l1 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll1111ll, text)
                self.l1ll1ll111.apply_tag(tag, l1l1lllll1, l1l11l1lll)
                self.l1l11ll11l(l1ll1ll1l1, l1l11l1lll)
    def _1ll1111ll(self, tag, widget, l1l11l1l11, _1l1l1111l, text):
        _1ll1l111l = l1l11l1l11.type
        _1l1l11111 = l1l11l1l11.window
        if _1ll1l111l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll1l111l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l11l1l11.button
            self.l1ll11l1l1 = Gdk.Cursor(Gdk.CursorType.l1ll11111l)
            if _1ll1l111l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1l1 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1l111ll1(self, message, title=l1l1 (u"ࠧࠨ০"), l1ll111l1=True, l1l11lll11=None):
        if l1ll111l1:
            l1ll1lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll1lllll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l11lll11:
            l1l1l11lll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1l1lll1 = Gtk.HBox(spacing=0)
            l1ll1lll1l = Gtk.HBox(spacing=5)
            l1ll111lll = Gtk.Label()
            l1ll111lll.set_markup(l1l1 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll111lll.set_line_wrap(True)
            l1ll111lll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1l1 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1l1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1ll1.show()
            l1l11l1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11l1ll1.show()
            l1ll11lll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11lll1.show()
            l1l1l1lll1.pack_start(separator, True, True, 0)
            l1l1l1lll1.pack_start(l1ll1l1ll1, True, True, 0)
            l1l1l1lll1.pack_start(l1l11l1ll1, True, True, 0)
            l1l1l1lll1.pack_start(l1ll11lll1, True, True, 0)
            l1l1l1lll1.pack_start(l1ll111lll, False, True, 0)
            l1ll111l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111l1l.show()
            l1l1l1lll1.pack_end(l1ll111l1l, True, True, 0)
            l1l11lll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lll1l.show()
            vbox.pack_start(l1l1l1lll1, True, True, 0)
            l1ll1ll11l=self.__1l11ll1ll(l1l111l1=l1l11lll11)
            vbox.pack_start(l1ll1ll11l, False, False, 0)
            vbox.pack_end(l1l11lll1l, False, False, 0)
            l1ll1lll1l.pack_start(vbox, True, True,5)
            l1ll1lll1l.show()
            l1l1l11lll.pack_end(l1ll1lll1l, False, False, 0)
            vbox.show()
            l1l1l1lll1.show()
        window.run()
class l11lll11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111ll1(self, widget, l1l1lll11l):
        if l1l1lll11l == Gtk.ResponseType.OK:
            self.result = l1l1 (u"ࠥࡓࡐࠨ৩")
        elif l1l1lll11l == Gtk.ResponseType.CANCEL:
            self.result = l1l1 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1lll11l == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1l1 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1ll1l111(self, title=l1l1 (u"ࠨࠢ৬"), message=l1l1 (u"ࠢࠣ৭") , l1ll111l1=True):
        if l1ll111l1:
            l1ll1lllll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1lllll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1l1 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll111ll1)
        window.run()
class l1l1l1ll11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1lll1ll=None
        self.result = None
    def l1ll111ll1(self, widget, l1l1lll11l):
        print(widget, l1l1lll11l)
        if l1l1lll11l == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1lll11l == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1lll11l == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1ll1lll(self, widget, l1l1ll111l):
        if l1l1ll111l.get_active():
            self.l1l1lll1ll = 1
        else:
            self.l1l1lll1ll = 0
    def l1l1l1ll1l(self, title=l1l1 (u"ࠤࠥ৯"), message=l1l1 (u"ࠥࠦৰ"), l1l11l1l1l =l1l1 (u"ࠦࠧৱ"),l1ll111l1=True):
        if l1ll111l1:
            l1ll1lllll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1lllll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1lllll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1l1 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll111ll1)
        l1l1ll1ll1 = Gtk.CheckButton(l1l11l1l1l)
        l1l1ll1ll1.connect(l1l1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1ll1lll, l1l1ll1ll1)
        l1l1ll1ll1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll1ll1, expand=True, fill=True, padding=0)
        l1l1ll1ll1.show()
        window.run()
def l1l11llll(title, msg, l1l11l1l1l=l1l1 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1ll111l1=True):
    result=None
    try:
        l1ll1l11l1 = l1l1l1ll11()
        l1ll1l11l1.l1l1l1ll1l(title, msg, l1l11l1l1l, l1ll111l1)
        result = {l1l1 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll1l11l1.result,  l1l1 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll1l11l1.l1l1lll1ll}
    except Exception as e:
        logger.exception(l1l1 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11l1ll1l = l11ll1111()
    message= l1l1 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1l11l11 = l1l1 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11l1ll1l.l1l111ll1(message, l1l1 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1ll111l1=True, l1l11lll11=l1l1l11l11)