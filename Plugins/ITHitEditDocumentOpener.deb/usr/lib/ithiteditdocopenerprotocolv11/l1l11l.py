#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l = 2048
l11l1ll = 7
def l1l11 (l1lll):
    global l1lll1
    l1ll11l1 = ord (l1lll [-1])
    l1ll1ll = l1lll [:-1]
    l1l1ll1 = l1ll11l1 % len (l1ll1ll)
    l1llll1 = l1ll1ll [:l1l1ll1] + l1ll1ll [l1l1ll1:]
    if l1ll1l:
        l1ll1111 = l1lll1l1 () .join ([unichr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    else:
        l1ll1111 = str () .join ([chr (ord (char) - l111l - (l1111l1 + l1ll11l1) % l11l1ll) for l1111l1, char in enumerate (l1llll1)])
    return eval (l1ll1111)
import logging
import os
import re
from l11l1l import l1lll1l1l
logger = logging.getLogger(l1l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111ll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l11 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1l11():
    try:
        out = os.popen(l1l11 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l11 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l11 (u"ࠤࠥॸ").join(result)
                logger.info(l1l11 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l11 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l11 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l11 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll1l1l(l1l11 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l11 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111ll1(l1l11 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))