#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l1l1ll (l1ll):
    global l111l1
    l11l11 = ord (l1ll [-1])
    l11l1 = l1ll [:-1]
    l1l11 = l11l11 % len (l11l1)
    l111l = l11l1 [:l1l11] + l11l1 [l1l11:]
    if l1l1l:
        l1l11l = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    return eval (l1l11l)
import os
import re
import subprocess
import l1l
from l1l import l111
def l1():
    return []
def l11ll(l1l1l1, l1ll1l):
    logger = l111()
    l1ll11 = []
    l11lll = [l1l1ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll1 = process.wait()
            l1l111 = {}
            if l11ll1 == 0:
                l1l1 = re.compile(l1l1ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1 = re.compile(l1l1ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111ll = re.search(l1l1, line)
                    l1111 = l111ll.group(1)
                    if l1l1l1 == l1111:
                        l1lll = re.search(l1ll1, line)
                        if l1lll:
                            l11 = l1l1ll (u"ࠨࡦࡤࡺࠬࠄ")+l1lll.group(1)
                            version = l111ll.group(0)
                            if not l11 in l1l111:
                                l1l111[l11] = version
                            elif l1l.l1111l(version, l1l111[l11]) > 0:
                                l1l111[l11] = version
            for l11 in l1l111:
                l1ll11.append({l1l1ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l111[l11], l1l1ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11})
        except Exception as e:
            logger.error(str(e))
    return l1ll11