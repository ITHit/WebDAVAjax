#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111ll = 2048
l11lll = 7
def l1ll1l (l11ll):
    global l1
    l11 = ord (l11ll [-1])
    l11ll1 = l11ll [:-1]
    l1ll11 = l11 % len (l11ll1)
    l1111 = l11ll1 [:l1ll11] + l11ll1 [l1ll11:]
    if l1l1l:
        l111 = l111l () .join ([unichr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    else:
        l111 = str () .join ([chr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    return eval (l111)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111l1l(l1lllll=None):
    if platform.system() == l1ll1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111111
        props = {}
        try:
            prop_names = (l1ll1l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll1l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll1l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll1l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll1l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll1l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll1l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll1l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll1l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll1l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll1l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1llllll = l111111.l1lll1l(l1lllll, l1ll1l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11111 in prop_names:
                l1111ll = l1ll1l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1llllll, l11111)
                props[l11111] = l111111.l1lll1l(l1lllll, l1111ll)
        except:
            pass
    return props
def l11llll(logger, l11lll1):
    l1l1l11 = os.environ.get(l1ll1l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll1l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l11 = l1l1l11.upper()
    if l1l1l11 == l1ll1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l111l = logging.DEBUG
    elif l1l1l11 == l1ll1l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l111l = logging.INFO
    elif l1l1l11 == l1ll1l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l111l = logging.WARNING
    elif l1l1l11 == l1ll1l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l111l = logging.ERROR
    elif l1l1l11 == l1ll1l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l111l = logging.CRITICAL
    elif l1l1l11 == l1ll1l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l111l = logging.NOTSET
    logger.setLevel(l1l111l)
    l1ll1ll = RotatingFileHandler(l11lll1, maxBytes=1024*1024*5, backupCount=3)
    l1ll1ll.setLevel(l1l111l)
    formatter = logging.Formatter(l1ll1l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll1ll.setFormatter(formatter)
    logger.addHandler(l1ll1ll)
    globals()[l1ll1l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l():
    return globals()[l1ll1l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1lll11():
    if platform.system() == l1ll1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll1l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l111
        l11l111.l11l1ll(sys.stdin.fileno(), os.l11ll11)
        l11l111.l11l1ll(sys.stdout.fileno(), os.l11ll11)
def l1llll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll1l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1111():
    if platform.system() == l1ll1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111lll
        return l111lll.l1ll111()
    elif platform.system() == l1ll1l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l():
    if platform.system() == l1ll1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111lll
        return l111lll.l11ll1l()
    elif platform.system() == l1ll1l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll
        return l1ll.l1l()
    elif platform.system() == l1ll1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1l1l
        return l1l1l1l.l1l()
    return l1ll1l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1111l1(l1111l, l1ll1):
    if platform.system() == l1ll1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111lll
        return l111lll.l1ll11l(l1111l, l1ll1)
    elif platform.system() == l1ll1l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1l1l
        return l1l1l1l.l1l1ll(l1111l, l1ll1)
    elif platform.system() == l1ll1l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll
        return l1ll.l1l1ll(l1111l, l1ll1)
    raise ValueError(l1ll1l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111l11(l11l1l, url):
    if platform.system() == l1ll1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111lll
        return l111lll.l11111l(l11l1l, url)
    elif platform.system() == l1ll1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1l1l
        return l1ll1l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll1l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll
        return l1ll1l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l11ll():
    if platform.system() == l1ll1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111lll
        return l111lll.l1l11ll()
def l1l1lll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll1l (u"ࠩ࠱ࠫ࠶"))[0]
def l11l1l1(l11l1):
    l1ll1l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l11l1 = l1ll1l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11l1:
        if l1ll1l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l11l1[3:]) < int(protocol[l1ll1l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l11l1 = protocol[l1ll1l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l11l1
def ll(l1l1ll1, l1ll1l1):
    l1ll1l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1ll1 is None: l1l1ll1 = l1ll1l (u"ࠩ࠳ࠫ࠽");
    if l1ll1l1 is None: l1ll1l1 = l1ll1l (u"ࠪ࠴ࠬ࠾");
    l11l11l = l1l1ll1.split(l1ll1l (u"ࠫ࠳࠭࠿"))
    l111ll1 = l1ll1l1.split(l1ll1l (u"ࠬ࠴ࠧࡀ"))
    while len(l11l11l) < len(l111ll1): l11l11l.append(l1ll1l (u"ࠨ࠰ࠣࡁ"));
    while len(l111ll1) < len(l11l11l): l111ll1.append(l1ll1l (u"ࠢ࠱ࠤࡂ"));
    l11l11l = [ int(x) for x in l11l11l ]
    l111ll1 = [ int(x) for x in l111ll1 ]
    for  i in range(len(l11l11l)):
        if len(l111ll1) == i:
            return 1
        if l11l11l[i] == l111ll1[i]:
            continue
        elif l11l11l[i] > l111ll1[i]:
            return 1
        else:
            return -1
    if len(l11l11l) != len(l111ll1):
        return -1
    return 0