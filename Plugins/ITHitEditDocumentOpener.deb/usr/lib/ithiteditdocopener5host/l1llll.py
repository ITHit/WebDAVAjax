#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l11lll = 2048
l111ll = 7
def l11 (l1l1l):
    global l1111l
    l1lll1 = ord (l1l1l [-1])
    l1l11 = l1l1l [:-1]
    l11ll = l1lll1 % len (l1l11)
    l1l1 = l1l11 [:l11ll] + l1l11 [l11ll:]
    if l1ll:
        l111l1 = l111 () .join ([unichr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    return eval (l111l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1llll1(l1ll11l=None):
    if platform.system() == l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l11ll
        props = {}
        try:
            prop_names = (l11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11lll1 = l1l11ll.l11111(l1ll11l, l11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1l1 in prop_names:
                l111111 = l11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11lll1, l11l1l1)
                props[l11l1l1] = l1l11ll.l11111(l1ll11l, l111111)
        except:
            pass
    return props
def l111lll(logger, l1l1l1l):
    l1llllll = os.environ.get(l11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1llllll = l1llllll.upper()
    if l1llllll == l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1ll1l1 = logging.DEBUG
    elif l1llllll == l11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1ll1l1 = logging.INFO
    elif l1llllll == l11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1ll1l1 = logging.WARNING
    elif l1llllll == l11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1ll1l1 = logging.ERROR
    elif l1llllll == l11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1ll1l1 = logging.CRITICAL
    elif l1llllll == l11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1ll1l1 = logging.NOTSET
    logger.setLevel(l1ll1l1)
    l1lll11 = RotatingFileHandler(l1l1l1l, maxBytes=1024*1024*5, backupCount=3)
    l1lll11.setLevel(l1ll1l1)
    formatter = logging.Formatter(l11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lll11.setFormatter(formatter)
    logger.addHandler(l1lll11)
    globals()[l11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l():
    return globals()[l11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l11l1():
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111l11
        l111l11.l11ll11(sys.stdin.fileno(), os.l1l1l11)
        l111l11.l11ll11(sys.stdout.fileno(), os.l1l1l11)
def l1ll111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11111l():
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1ll1ll
        return l1ll1ll.l11l1ll()
    elif platform.system() == l11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1ll1ll
        return l1ll1ll.l1lllll()
    elif platform.system() == l11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11l1
        return l11l1.l1()
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11l11l
        return l11l11l.l1()
    return l11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l111l(l1l111, l1111):
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1ll1ll
        return l1ll1ll.l11llll(l1l111, l1111)
    elif platform.system() == l11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11l11l
        return l11l11l.l1l(l1l111, l1111)
    elif platform.system() == l11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11l1
        return l11l1.l1l(l1l111, l1111)
    raise ValueError(l11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l1lll(l111l, url):
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1ll1ll
        return l1ll1ll.l1l1111(l111l, url)
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11l11l
        return l11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11l1
        return l11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11l111():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1ll1ll
        return l1ll1ll.l11l111()
def l111ll1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11 (u"ࠩ࠱ࠫ࠶"))[0]
def l111l1l(l1ll1l):
    l11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1ll1 = l11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1l:
        if l11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1ll1[3:]) < int(protocol[l11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1ll1 = protocol[l11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1ll1
def l1lll(l1lll1l, l1111ll):
    l11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1lll1l is None: l1lll1l = l11 (u"ࠩ࠳ࠫ࠽");
    if l1111ll is None: l1111ll = l11 (u"ࠪ࠴ࠬ࠾");
    l1111l1 = l1lll1l.split(l11 (u"ࠫ࠳࠭࠿"))
    l11ll1l = l1111ll.split(l11 (u"ࠬ࠴ࠧࡀ"))
    while len(l1111l1) < len(l11ll1l): l1111l1.append(l11 (u"ࠨ࠰ࠣࡁ"));
    while len(l11ll1l) < len(l1111l1): l11ll1l.append(l11 (u"ࠢ࠱ࠤࡂ"));
    l1111l1 = [ int(x) for x in l1111l1 ]
    l11ll1l = [ int(x) for x in l11ll1l ]
    for  i in range(len(l1111l1)):
        if len(l11ll1l) == i:
            return 1
        if l1111l1[i] == l11ll1l[i]:
            continue
        elif l1111l1[i] > l11ll1l[i]:
            return 1
        else:
            return -1
    if len(l1111l1) != len(l11ll1l):
        return -1
    return 0