#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1l11 = 2048
l11l1 = 7
def l1llll (l1l1ll):
    global l111
    l11lll = ord (l1l1ll [-1])
    l1111l = l1l1ll [:-1]
    l1 = l11lll % len (l1111l)
    l1lll = l1111l [:l1] + l1111l [l1:]
    if l111l1:
        l1l1l = l111ll () .join ([unichr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    return eval (l1l1l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11111l(l111ll1=None):
    if platform.system() == l1llll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11l1ll
        props = {}
        try:
            prop_names = (l1llll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1llll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1llll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1llll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1llll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1llll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1llll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1llll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1llll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1llll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1llll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1llll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1lll = l11l1ll.l1lllll(l111ll1, l1llll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1lll11 in prop_names:
                l1l1l11 = l1llll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1lll, l1lll11)
                props[l1lll11] = l11l1ll.l1lllll(l111ll1, l1l1l11)
        except:
            pass
    return props
def l11l11l(logger, l1l111l):
    l11l1l1 = os.environ.get(l1llll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1llll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l1l1 = l11l1l1.upper()
    if l11l1l1 == l1llll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1ll1ll = logging.DEBUG
    elif l11l1l1 == l1llll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1ll1ll = logging.INFO
    elif l11l1l1 == l1llll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1ll1ll = logging.WARNING
    elif l11l1l1 == l1llll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1ll1ll = logging.ERROR
    elif l11l1l1 == l1llll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1ll1ll = logging.CRITICAL
    elif l11l1l1 == l1llll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1ll1ll = logging.NOTSET
    logger.setLevel(l1ll1ll)
    l1111ll = RotatingFileHandler(l1l111l, maxBytes=1024*1024*5, backupCount=3)
    l1111ll.setLevel(l1ll1ll)
    formatter = logging.Formatter(l1llll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1111ll.setFormatter(formatter)
    logger.addHandler(l1111ll)
    globals()[l1llll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11():
    return globals()[l1llll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll11l():
    if platform.system() == l1llll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1llll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111111
        l111111.l11lll1(sys.stdin.fileno(), os.l11ll11)
        l111111.l11lll1(sys.stdout.fileno(), os.l11ll11)
def l11111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1llll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1l1l():
    if platform.system() == l1llll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11ll1l
        return l11ll1l.l1l11ll()
    elif platform.system() == l1llll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1llll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l():
    if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11ll1l
        return l11ll1l.l11l111()
    elif platform.system() == l1llll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l
        return l1l.l11l()
    elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1llll1
        return l1llll1.l11l()
    return l1llll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111l11(l11l11, l11ll):
    if platform.system() == l1llll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11ll1l
        return l11ll1l.l111lll(l11l11, l11ll)
    elif platform.system() == l1llll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1llll1
        return l1llll1.l1lll1(l11l11, l11ll)
    elif platform.system() == l1llll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l
        return l1l.l1lll1(l11l11, l11ll)
    raise ValueError(l1llll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1111l1(l1ll1l, url):
    if platform.system() == l1llll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11ll1l
        return l11ll1l.l1l1ll1(l1ll1l, url)
    elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1llll1
        return l1llll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1llll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l
        return l1llll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1llll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll111():
    if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11ll1l
        return l11ll1l.l1ll111()
def l1ll1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1llll (u"ࠩ࠱ࠫ࠶"))[0]
def l1llllll(ll):
    l1llll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111l1l = l1llll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in ll:
        if l1llll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111l1l[3:]) < int(protocol[l1llll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111l1l = protocol[l1llll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111l1l
def l1111(l1lll1l, l1l11l1):
    l1llll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1lll1l is None: l1lll1l = l1llll (u"ࠩ࠳ࠫ࠽");
    if l1l11l1 is None: l1l11l1 = l1llll (u"ࠪ࠴ࠬ࠾");
    l11llll = l1lll1l.split(l1llll (u"ࠫ࠳࠭࠿"))
    l1l1111 = l1l11l1.split(l1llll (u"ࠬ࠴ࠧࡀ"))
    while len(l11llll) < len(l1l1111): l11llll.append(l1llll (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1111) < len(l11llll): l1l1111.append(l1llll (u"ࠢ࠱ࠤࡂ"));
    l11llll = [ int(x) for x in l11llll ]
    l1l1111 = [ int(x) for x in l1l1111 ]
    for  i in range(len(l11llll)):
        if len(l1l1111) == i:
            return 1
        if l11llll[i] == l1l1111[i]:
            continue
        elif l11llll[i] > l1l1111[i]:
            return 1
        else:
            return -1
    if len(l11llll) != len(l1l1111):
        return -1
    return 0