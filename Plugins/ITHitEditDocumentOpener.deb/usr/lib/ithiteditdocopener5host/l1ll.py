#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11lll = 2048
l1ll1 = 7
def l1l111 (l1l):
    global l1111
    ll = ord (l1l [-1])
    l111l1 = l1l [:-1]
    l111l = ll % len (l111l1)
    l11l1 = l111l1 [:l111l] + l111l1 [l111l:]
    if l1l1:
        l1lll = l1l11l () .join ([unichr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    else:
        l1lll = str () .join ([chr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    return eval (l1lll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11111l(l1lllll=None):
    if platform.system() == l1l111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111111
        props = {}
        try:
            prop_names = (l1l111 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l111 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l111 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l111 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l111 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l111 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l111 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l111 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l111 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l111 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l111 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1lll = l111111.l1llll1(l1lllll, l1l111 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1l1 in prop_names:
                l11l11l = l1l111 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1lll, l11l1l1)
                props[l11l1l1] = l111111.l1llll1(l1lllll, l11l11l)
        except:
            pass
    return props
def l11111(logger, l111l11):
    l11l111 = os.environ.get(l1l111 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l111 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l111 = l11l111.upper()
    if l11l111 == l1l111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1lll11 = logging.DEBUG
    elif l11l111 == l1l111 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1lll11 = logging.INFO
    elif l11l111 == l1l111 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1lll11 = logging.WARNING
    elif l11l111 == l1l111 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1lll11 = logging.ERROR
    elif l11l111 == l1l111 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1lll11 = logging.CRITICAL
    elif l11l111 == l1l111 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1lll11 = logging.NOTSET
    logger.setLevel(l1lll11)
    l1l1l11 = RotatingFileHandler(l111l11, maxBytes=1024*1024*5, backupCount=3)
    l1l1l11.setLevel(l1lll11)
    formatter = logging.Formatter(l1l111 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1l11.setFormatter(formatter)
    logger.addHandler(l1l1l11)
    globals()[l1l111 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l111ll():
    return globals()[l1l111 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll1l1():
    if platform.system() == l1l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l111 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l1ll
        l11l1ll.l1ll111(sys.stdin.fileno(), os.l1ll1ll)
        l11l1ll.l1ll111(sys.stdout.fileno(), os.l1ll1ll)
def l1l1l1l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l111 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11lll1():
    if platform.system() == l1l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111l1l
        return l111l1l.l1llllll()
    elif platform.system() == l1l111 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l():
    if platform.system() == l1l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111l1l
        return l111l1l.l11llll()
    elif platform.system() == l1l111 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l11
        return l1l11.l11l()
    elif platform.system() == l1l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1ll1
        return l1l1ll1.l11l()
    return l1l111 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lll1l(l1111l, l1l1ll):
    if platform.system() == l1l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111l1l
        return l111l1l.l11ll1l(l1111l, l1l1ll)
    elif platform.system() == l1l111 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1ll1
        return l1l1ll1.l1lll1(l1111l, l1l1ll)
    elif platform.system() == l1l111 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l11
        return l1l11.l1lll1(l1111l, l1l1ll)
    raise ValueError(l1l111 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l11l1(l1llll, url):
    if platform.system() == l1l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111l1l
        return l111l1l.l1l111l(l1llll, url)
    elif platform.system() == l1l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1ll1
        return l1l111 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l111 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l11
        return l1l111 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1111ll():
    if platform.system() == l1l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111l1l
        return l111l1l.l1111ll()
def l1l1111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l111 (u"ࠩ࠱ࠫ࠶"))[0]
def l1111l1(l11):
    l1l111 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111ll1 = l1l111 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11:
        if l1l111 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111ll1[3:]) < int(protocol[l1l111 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111ll1 = protocol[l1l111 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111ll1
def l1ll1l(l1ll11l, l111lll):
    l1l111 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll11l is None: l1ll11l = l1l111 (u"ࠩ࠳ࠫ࠽");
    if l111lll is None: l111lll = l1l111 (u"ࠪ࠴ࠬ࠾");
    l1l11ll = l1ll11l.split(l1l111 (u"ࠫ࠳࠭࠿"))
    l11ll11 = l111lll.split(l1l111 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l11ll) < len(l11ll11): l1l11ll.append(l1l111 (u"ࠨ࠰ࠣࡁ"));
    while len(l11ll11) < len(l1l11ll): l11ll11.append(l1l111 (u"ࠢ࠱ࠤࡂ"));
    l1l11ll = [ int(x) for x in l1l11ll ]
    l11ll11 = [ int(x) for x in l11ll11 ]
    for  i in range(len(l1l11ll)):
        if len(l11ll11) == i:
            return 1
        if l1l11ll[i] == l11ll11[i]:
            continue
        elif l1l11ll[i] > l11ll11[i]:
            return 1
        else:
            return -1
    if len(l1l11ll) != len(l11ll11):
        return -1
    return 0