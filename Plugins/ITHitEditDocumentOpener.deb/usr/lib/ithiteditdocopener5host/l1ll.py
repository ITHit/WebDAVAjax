#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111ll = 2048
l11lll = 7
def l1ll1l (l11ll):
    global l1
    l11 = ord (l11ll [-1])
    l11ll1 = l11ll [:-1]
    l1ll11 = l11 % len (l11ll1)
    l1111 = l11ll1 [:l1ll11] + l11ll1 [l1ll11:]
    if l1l1l:
        l111 = l111l () .join ([unichr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    else:
        l111 = str () .join ([chr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    return eval (l111)
import os
import re
import subprocess
import l1llll
from l1llll import l11l
def l1l():
    return []
def l1l1ll(l1111l, l1ll1):
    logger = l11l()
    l1l11 = []
    l111l1 = [l1ll1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1lll = process.wait()
            l11l1 = {}
            if l1lll == 0:
                l1l1 = re.compile(l1ll1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1lll1 = re.compile(l1ll1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l11l = re.search(l1l1, line)
                    l1l1l1 = l1l11l.group(1)
                    if l1111l == l1l1l1:
                        l11l11 = re.search(l1lll1, line)
                        if l11l11:
                            l11l1l = l1ll1l (u"ࠨࡦࡤࡺࠬࠄ")+l11l11.group(1)
                            version = l1l11l.group(0)
                            if not l11l1l in l11l1:
                                l11l1[l11l1l] = version
                            elif l1llll.ll(version, l11l1[l11l1l]) > 0:
                                l11l1[l11l1l] = version
            for l11l1l in l11l1:
                l1l11.append({l1ll1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l1[l11l1l], l1ll1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1l})
        except Exception as e:
            logger.error(str(e))
    return l1l11