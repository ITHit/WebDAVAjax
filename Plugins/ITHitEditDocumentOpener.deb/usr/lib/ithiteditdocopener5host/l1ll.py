#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1 = 7
def l11l1l (l11lll):
    global l111ll
    l1lll = ord (l11lll [-1])
    l1l111 = l11lll [:-1]
    l1ll1 = l1lll % len (l1l111)
    l1llll = l1l111 [:l1ll1] + l1l111 [l1ll1:]
    if l11:
        l11l = l111l1 () .join ([unichr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    return eval (l11l)
import os
import re
import subprocess
import l1l11
from l1l11 import l1ll1l
def l11l11():
    return []
def l1(l1111, l1111l):
    logger = l1ll1l()
    l11ll = []
    l1l11l = [l11l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l11l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1 = process.wait()
            l111l = {}
            if l1l1 == 0:
                l1l = re.compile(l11l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                ll = re.compile(l11l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111 = re.search(l1l, line)
                    l1lll1 = l111.group(1)
                    if l1111 == l1lll1:
                        l1l1l = re.search(ll, line)
                        if l1l1l:
                            l1l1ll = l11l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l.group(1)
                            version = l111.group(0)
                            if not l1l1ll in l111l:
                                l111l[l1l1ll] = version
                            elif l1l11.l11ll1(version, l111l[l1l1ll]) > 0:
                                l111l[l1l1ll] = version
            for l1l1ll in l111l:
                l11ll.append({l11l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l[l1l1ll], l11l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1ll})
        except Exception as e:
            logger.error(str(e))
    return l11ll