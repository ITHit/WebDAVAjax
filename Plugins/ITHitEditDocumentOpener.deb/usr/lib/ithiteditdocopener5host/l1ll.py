#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll = sys.version_info [0] == 2
l111l1 = 2048
l1ll1 = 7
def l11ll1 (l1l1l1):
    global l1l11
    l111ll = ord (l1l1l1 [-1])
    l1l1l = l1l1l1 [:-1]
    l1 = l111ll % len (l1l1l)
    l1111 = l1l1l [:l1] + l1l1l [l1:]
    if l11lll:
        l1l11l = l111l () .join ([unichr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    return eval (l1l11l)
import os
import re
import subprocess
import l1111l
from l1111l import l1ll11
def l11ll():
    return []
def l11(l11l11, l1l):
    logger = l1ll11()
    l1l111 = []
    l1l1 = [l11ll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1llll = process.wait()
            l11l1l = {}
            if l1llll == 0:
                ll = re.compile(l11ll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1lll1 = re.compile(l11ll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1 = re.search(ll, line)
                    l1lll = l11l1.group(1)
                    if l11l11 == l1lll:
                        l1ll1l = re.search(l1lll1, line)
                        if l1ll1l:
                            l111 = l11ll1 (u"ࠨࡦࡤࡺࠬࠄ")+l1ll1l.group(1)
                            version = l11l1.group(0)
                            if not l111 in l11l1l:
                                l11l1l[l111] = version
                            elif l1111l.l1l1ll(version, l11l1l[l111]) > 0:
                                l11l1l[l111] = version
            for l111 in l11l1l:
                l1l111.append({l11ll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l1l[l111], l11ll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111})
        except Exception as e:
            logger.error(str(e))
    return l1l111