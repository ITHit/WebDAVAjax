#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l111l = 2048
l1l = 7
def l11ll (l1111):
    global l11
    l111l1 = ord (l1111 [-1])
    l1l1ll = l1111 [:-1]
    l1l1 = l111l1 % len (l1l1ll)
    l111 = l1l1ll [:l1l1] + l1l1ll [l1l1:]
    if l1111l:
        l1l11l = l1 () .join ([unichr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    return eval (l1l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l1111(l11111=None):
    if platform.system() == l11ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1111l1
        props = {}
        try:
            prop_names = (l11ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1lll11 = l1111l1.l11l11l(l11111, l11ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11111l in prop_names:
                l111lll = l11ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1lll11, l11111l)
                props[l11111l] = l1111l1.l11l11l(l11111, l111lll)
        except:
            pass
    return props
def l1lll1l(logger, l1lllll):
    l111l11 = os.environ.get(l11ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l11 = l111l11.upper()
    if l111l11 == l11ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1llllll = logging.DEBUG
    elif l111l11 == l11ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1llllll = logging.INFO
    elif l111l11 == l11ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1llllll = logging.WARNING
    elif l111l11 == l11ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1llllll = logging.ERROR
    elif l111l11 == l11ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1llllll = logging.CRITICAL
    elif l111l11 == l11ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1llllll = logging.NOTSET
    logger.setLevel(l1llllll)
    l11ll11 = RotatingFileHandler(l1lllll, maxBytes=1024*1024*5, backupCount=3)
    l11ll11.setLevel(l1llllll)
    formatter = logging.Formatter(l11ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11ll11.setFormatter(formatter)
    logger.addHandler(l11ll11)
    globals()[l11ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l1():
    return globals()[l11ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l111l():
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l11l1
        l1l11l1.l11llll(sys.stdin.fileno(), os.l1ll111)
        l1l11l1.l11llll(sys.stdout.fileno(), os.l1ll111)
def l1111ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llll1():
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1ll11l
        return l1ll11l.l1ll1l1()
    elif platform.system() == l11ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll1l():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1ll11l
        return l1ll11l.l11l111()
    elif platform.system() == l11ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l111
        return l1l111.l1ll1l()
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111ll1
        return l111ll1.l1ll1l()
    return l11ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11l1ll(l11lll, l1l1l):
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1ll11l
        return l1ll11l.l1l1l1l(l11lll, l1l1l)
    elif platform.system() == l11ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111ll1
        return l111ll1.l1lll1(l11lll, l1l1l)
    elif platform.system() == l11ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l111
        return l1l111.l1lll1(l11lll, l1l1l)
    raise ValueError(l11ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111111(l1l11, url):
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1ll11l
        return l1ll11l.l1l1ll1(l1l11, url)
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111ll1
        return l11ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l111
        return l11ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11ll1l():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1ll11l
        return l1ll11l.l11ll1l()
def l11l1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1l11(l1l1l1):
    l11ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l11ll = l11ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l1l1:
        if l11ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l11ll[3:]) < int(protocol[l11ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l11ll = protocol[l11ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l11ll
def l1ll(l111l1l, l1ll1ll):
    l11ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l111l1l is None: l111l1l = l11ll (u"ࠩ࠳ࠫ࠽");
    if l1ll1ll is None: l1ll1ll = l11ll (u"ࠪ࠴ࠬ࠾");
    l1l1lll = l111l1l.split(l11ll (u"ࠫ࠳࠭࠿"))
    l11lll1 = l1ll1ll.split(l11ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1lll) < len(l11lll1): l1l1lll.append(l11ll (u"ࠨ࠰ࠣࡁ"));
    while len(l11lll1) < len(l1l1lll): l11lll1.append(l11ll (u"ࠢ࠱ࠤࡂ"));
    l1l1lll = [ int(x) for x in l1l1lll ]
    l11lll1 = [ int(x) for x in l11lll1 ]
    for  i in range(len(l1l1lll)):
        if len(l11lll1) == i:
            return 1
        if l1l1lll[i] == l11lll1[i]:
            continue
        elif l1l1lll[i] > l11lll1[i]:
            return 1
        else:
            return -1
    if len(l1l1lll) != len(l11lll1):
        return -1
    return 0