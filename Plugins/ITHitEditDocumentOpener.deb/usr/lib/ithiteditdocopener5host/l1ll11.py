#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll = 2048
l111l = 7
def l1l1l (ll):
    global l11ll
    l1111 = ord (ll [-1])
    l1lll = ll [:-1]
    l1ll1l = l1111 % len (l1lll)
    l1l11 = l1lll [:l1ll1l] + l1lll [l1ll1l:]
    if l1l1l1:
        l1l = l111ll () .join ([unichr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    return eval (l1l)
import os
import re
import subprocess
import l11l
from l11l import l11l1l
def l111l1():
    return []
def l1l1(l1111l, l1l11l):
    logger = l11l1l()
    l11 = []
    l111 = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111:
        try:
            output = os.popen(cmd).read()
            l1l1ll = 0
            l1 = {}
            if l1l1ll == 0:
                l1lll1 = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11ll1 = re.search(l1lll1, line)
                    l11lll = l11ll1.group(1)
                    if l1111l == l11lll:
                        l1llll = re.search(l1ll1, line)
                        if l1llll:
                            l1l111 = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1llll.group(1)
                            version = l11ll1.group(0)
                            if not l1l111 in l1:
                                l1[l1l111] = version
                            elif l11l.l11l11(version, l1[l1l111]) > 0:
                                l1[l1l111] = version
            for l1l111 in l1:
                l11.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1[l1l111], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l111})
        except Exception as e:
            logger.error(str(e))
    return l11