#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111l (l1111l):
    global l1l11l
    l111l1 = ord (l1111l [-1])
    l1l111 = l1111l [:-1]
    l111ll = l111l1 % len (l1l111)
    l1 = l1l111 [:l111ll] + l1l111 [l111ll:]
    if l111:
        l1l1 = l1lll () .join ([unichr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    else:
        l1l1 = str () .join ([chr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    return eval (l1l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11lll1(l1l111l=None):
    if platform.system() == l111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1l11
        props = {}
        try:
            prop_names = (l111l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1ll1 = l1l1l11.l1l1lll(l1l111l, l111l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1ll11l in prop_names:
                l1111l1 = l111l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1ll1, l1ll11l)
                props[l1ll11l] = l1l1l11.l1l1lll(l1l111l, l1111l1)
        except:
            pass
    return props
def l1llllll(logger, l111l1l):
    l111l11 = os.environ.get(l111l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l11 = l111l11.upper()
    if l111l11 == l111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111ll = logging.DEBUG
    elif l111l11 == l111l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111ll = logging.INFO
    elif l111l11 == l111l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111ll = logging.WARNING
    elif l111l11 == l111l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111ll = logging.ERROR
    elif l111l11 == l111l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111ll = logging.CRITICAL
    elif l111l11 == l111l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111ll = logging.NOTSET
    logger.setLevel(l1111ll)
    l11l111 = RotatingFileHandler(l111l1l, maxBytes=1024*1024*5, backupCount=3)
    l11l111.setLevel(l1111ll)
    formatter = logging.Formatter(l111l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l111.setFormatter(formatter)
    logger.addHandler(l11l111)
    globals()[l111l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l():
    return globals()[l111l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l1l1():
    if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1111
        l1l1111.l11llll(sys.stdin.fileno(), os.l1l1l1l)
        l1l1111.l11llll(sys.stdout.fileno(), os.l1l1l1l)
def l11ll1l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11111l():
    if platform.system() == l111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l1ll
        return l11l1ll.l1ll1ll()
    elif platform.system() == l111l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l11():
    if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l1ll
        return l11l1ll.l11ll11()
    elif platform.system() == l111l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11lll
        return l11lll.l1l11()
    elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1llll1
        return l1llll1.l1l11()
    return l111l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111111(l1ll1l, l11ll):
    if platform.system() == l111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l1ll
        return l11l1ll.l1l11ll(l1ll1l, l11ll)
    elif platform.system() == l111l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1llll1
        return l1llll1.l1l1ll(l1ll1l, l11ll)
    elif platform.system() == l111l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11lll
        return l11lll.l1l1ll(l1ll1l, l11ll)
    raise ValueError(l111l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1lll1l(l1ll1, url):
    if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l1ll
        return l11l1ll.l1l11l1(l1ll1, url)
    elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1llll1
        return l111l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11lll
        return l111l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll111():
    if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l1ll
        return l11l1ll.l1ll111()
def l1ll1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111l (u"ࠩ࠱ࠫ࠶"))[0]
def l11l11l(l1ll):
    l111l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111 = l111l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll:
        if l111l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111[3:]) < int(protocol[l111l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111 = protocol[l111l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111
def l11l1(l1lllll, l1lll11):
    l111l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1lllll is None: l1lllll = l111l (u"ࠩ࠳ࠫ࠽");
    if l1lll11 is None: l1lll11 = l111l (u"ࠪ࠴ࠬ࠾");
    l111lll = l1lllll.split(l111l (u"ࠫ࠳࠭࠿"))
    l111ll1 = l1lll11.split(l111l (u"ࠬ࠴ࠧࡀ"))
    while len(l111lll) < len(l111ll1): l111lll.append(l111l (u"ࠨ࠰ࠣࡁ"));
    while len(l111ll1) < len(l111lll): l111ll1.append(l111l (u"ࠢ࠱ࠤࡂ"));
    l111lll = [ int(x) for x in l111lll ]
    l111ll1 = [ int(x) for x in l111ll1 ]
    for  i in range(len(l111lll)):
        if len(l111ll1) == i:
            return 1
        if l111lll[i] == l111ll1[i]:
            continue
        elif l111lll[i] > l111ll1[i]:
            return 1
        else:
            return -1
    if len(l111lll) != len(l111ll1):
        return -1
    return 0