#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
l1ll1 = 7
def l1llll (l11):
    global l111
    l1lll = ord (l11 [-1])
    l111l1 = l11 [:-1]
    l11ll = l1lll % len (l111l1)
    l1l = l111l1 [:l11ll] + l111l1 [l11ll:]
    if l1ll1l:
        l111l = l111ll () .join ([unichr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    return eval (l111l)
import os
import re
import subprocess
import l1
from l1 import l1l1
def l11l1():
    return []
def l11l(l1l111, l1lll1):
    logger = l1l1()
    l1111 = []
    l1l1ll = [l1llll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1llll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1ll:
        try:
            output = os.popen(cmd).read()
            l11ll1 = 0
            l1111l = {}
            if l11ll1 == 0:
                l1ll = re.compile(l1llll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11l = re.compile(l1llll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11lll = re.search(l1ll, line)
                    ll = l11lll.group(1)
                    if l1l111 == ll:
                        l11l11 = re.search(l1l11l, line)
                        if l11l11:
                            l1l1l1 = l1llll (u"ࠨࡦࡤࡺࠬࠄ")+l11l11.group(1)
                            version = l11lll.group(0)
                            if not l1l1l1 in l1111l:
                                l1111l[l1l1l1] = version
                            elif l1.l1l11(version, l1111l[l1l1l1]) > 0:
                                l1111l[l1l1l1] = version
            for l1l1l1 in l1111l:
                l1111.append({l1llll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111l[l1l1l1], l1llll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1l1})
        except Exception as e:
            logger.error(str(e))
    return l1111