#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111ll = 2048
l1l1l = 7
def l1ll11 (l1l1ll):
    global l11l1l
    l111l = ord (l1l1ll [-1])
    l11l11 = l1l1ll [:-1]
    l1l = l111l % len (l11l11)
    l1llll = l11l11 [:l1l] + l11l11 [l1l:]
    if l1lll1:
        l1111l = l1l11l () .join ([unichr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    return eval (l1111l)
import l1l11
from l1l1l11l import l1l1l111
import objc as _111l11l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l11l.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111ll.l1111111(l111l1ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll11 (u"ࠨࠩࢬ"), {l1ll11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111ll11(l111l1l1):
    l111l1l1 = (l111l1l1 + l1ll11 (u"ࠩ࠽ࠫࢴ")).encode()
    l111111l = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l1111l1l = CFURLCreateWithString( kCFAllocatorDefault, l111111l, _111l11l.nil )
    l111llll = LaunchServices.l1111lll( l1111l1l, LaunchServices.l111ll1l, _111l11l.nil )
    if l111llll[0] is not None:
        return True
    return False
def ll():
    l11111l1 = []
    for name in l1l1l111:
        try:
            if l111ll11(name):
                l11111l1.append(name)
        except:
            continue
    return l11111l1
def l11ll(l1l1, l11l1):
    import plistlib
    import os
    l11 = []
    l1l1l1 = {}
    for l111l111 in os.listdir(l1ll11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l111.startswith(l11l1):
            try:
                l111lll1 = l1ll11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l111
                with open(l111lll1, l1ll11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l111 = plist[l1ll11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l1ll11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1 == l1111l11:
                        if not l1l111 in l1l1l1:
                            l1l1l1[l1l111] = version
                        elif l1l11.l1ll1(version, l1l1l1[l1l111]) > 0:
                            l1l1l1[l1l111] = version
            except BaseException:
                continue
    for l1l111 in l1l1l1:
        l11.append({l1ll11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l1l1[l1l111], l1ll11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l111})
    return l11