#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l11l1 = 2048
l1 = 7
def l1ll1 (l11l11):
    global l1l1ll
    l111l = ord (l11l11 [-1])
    l1l = l11l11 [:-1]
    l1llll = l111l % len (l1l)
    l1lll = l1l [:l1llll] + l1l [l1llll:]
    if ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l1l1)
import subprocess, threading
from l1111l import l11ll1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1llll1():
    l11l1l11 = [l1ll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1l11:
        try:
            l11ll1ll = l1ll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l1111l = winreg.l1l111l1(winreg.l11l1ll1, l11ll1ll)
        except l11ll111:
            continue
        value = winreg.l11llll1(l1l1111l, l1ll1 (u"ࠦࠧ࢓"))
        return value.split(l1ll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1l11():
    l1l11111 = []
    for name in l1l1l111:
        try:
            l11ll1ll = l1ll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l111l = winreg.l1l111l1(winreg.l11l1ll1, l11ll1ll)
            if winreg.l11llll1(l11l111l, l1ll1 (u"ࠢࠣ࢖")):
                l1l11111.append(name)
        except l11ll111:
            continue
    return l1l11111
def l1l1l1l(l111ll, l11ll):
    import re
    l11l1l = []
    l11l1111 = winreg.l1l111l1(winreg.l11l1ll1, l1ll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11lll(l11l1111)[0]):
        try:
            l11lll1l = winreg.l11l1lll(l11l1111, i)
            if l11lll1l.startswith(l11ll):
                l1l11l11 = winreg.l11ll1l1(l11l1111, l11lll1l)
                value, l11lllll = winreg.l11ll11l(l1l11l11, l1ll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lll11 = {l1ll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11ll = m.group(2)
                    if l111ll == l11l11ll:
                        m = re.search(l11ll.replace(l1ll1 (u"ࠬ࠴࢛ࠧ"), l1ll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll1l)
                        l11lll11[l1ll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l1l.append(l11lll11)
                else:
                    raise ValueError(l1ll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll111 as ex:
            continue
    return l11l1l
def l1l11ll1(l1l1):
    try:
        l11l1l1l = l1ll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1)
        l11l11l1 = winreg.l1l111l1(winreg.l11l1ll1, l11l1l1l)
        value, l11lllll = winreg.l11ll11l(l11l11l1, l1ll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11ll111:
        pass
    return l1ll1 (u"࠭ࠧࢣ")
def l1ll1l1(l1l1, url):
    threading.Thread(target=_1l11l1l,args=(l1l1, url)).start()
    return l1ll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11l1l(l1l1, url):
    logger = l11ll1()
    l1l111ll = l1l11ll1(l1l1)
    logger.debug(l1ll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l111ll, url))
    retcode = subprocess.Popen(l1ll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l111ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)