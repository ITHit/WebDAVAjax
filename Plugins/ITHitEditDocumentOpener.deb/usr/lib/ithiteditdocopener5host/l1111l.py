#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11lll = 2048
l1l1 = 7
def l11 (l1l11):
    global l1l11l
    l1111 = ord (l1l11 [-1])
    l1ll1 = l1l11 [:-1]
    l1ll = l1111 % len (l1ll1)
    l1llll = l1ll1 [:l1ll] + l1ll1 [l1ll:]
    if l11ll1:
        l1 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    else:
        l1 = str () .join ([chr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    return eval (l1)
import os
import re
import subprocess
import l11l1l
from l11l1l import l1lll1
def l1l1l1():
    return []
def l1l1ll(l11ll, l1ll1l):
    logger = l1lll1()
    l11l = []
    l11l11 = [l11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11l11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            l1l = {}
            if l111l1 == 0:
                l1l1l = re.compile(l11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                ll = re.compile(l11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll11 = re.search(l1l1l, line)
                    l111ll = l1ll11.group(1)
                    if l11ll == l111ll:
                        l111 = re.search(ll, line)
                        if l111:
                            l1l111 = l11 (u"ࠨࡦࡤࡺࠬࠄ")+l111.group(1)
                            version = l1ll11.group(0)
                            if not l1l111 in l1l:
                                l1l[l1l111] = version
                            elif l11l1l.l111l(version, l1l[l1l111]) > 0:
                                l1l[l1l111] = version
            for l1l111 in l1l:
                l11l.append({l11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l[l1l111], l11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l111})
        except Exception as e:
            logger.error(str(e))
    return l11l