#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l111 = 2048
l1l1l = 7
def l1l11 (l1l1l1):
    global l11l1l
    l1l1 = ord (l1l1l1 [-1])
    l11ll = l1l1l1 [:-1]
    l1llll = l1l1 % len (l11ll)
    l1lll1 = l11ll [:l1llll] + l11ll [l1llll:]
    if l1ll11:
        l1ll1l = l1l111 () .join ([unichr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    return eval (l1ll1l)
import os
import re
import subprocess
import l1lll
from l1lll import l1
def l11l11():
    return []
def l11lll(l1ll1, l11):
    logger = l1()
    l111ll = []
    l1111 = [l1l11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1111:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            ll = {}
            if l111l1 == 0:
                l1l1ll = re.compile(l1l11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll1 = re.compile(l1l11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll = re.search(l1l1ll, line)
                    l1l = l1ll.group(1)
                    if l1ll1 == l1l:
                        l11l = re.search(l11ll1, line)
                        if l11l:
                            l11l1 = l1l11 (u"ࠨࡦࡤࡺࠬࠄ")+l11l.group(1)
                            version = l1ll.group(0)
                            if not l11l1 in ll:
                                ll[l11l1] = version
                            elif l1lll.l1l11l(version, ll[l11l1]) > 0:
                                ll[l11l1] = version
            for l11l1 in ll:
                l111ll.append({l1l11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): ll[l11l1], l1l11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1})
        except Exception as e:
            logger.error(str(e))
    return l111ll