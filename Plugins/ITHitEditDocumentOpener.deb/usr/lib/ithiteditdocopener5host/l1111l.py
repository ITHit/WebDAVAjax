#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1l = 7
def l11ll1 (ll):
    global l1l1
    l1l1ll = ord (ll [-1])
    l1ll11 = ll [:-1]
    l1l11 = l1l1ll % len (l1ll11)
    l11 = l1ll11 [:l1l11] + l1ll11 [l1l11:]
    if l11l1l:
        l1 = l11lll () .join ([unichr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    return eval (l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1llllll(l1111l1=None):
    if platform.system() == l11ll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11lll1
        props = {}
        try:
            prop_names = (l11ll1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11ll1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11ll1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11ll1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11ll1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11ll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11ll1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11ll1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11ll1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11ll1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11ll1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11ll1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111l = l11lll1.l111ll1(l1111l1, l11ll1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l11ll in prop_names:
                l11llll = l11ll1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111l, l1l11ll)
                props[l1l11ll] = l11lll1.l111ll1(l1111l1, l11llll)
        except:
            pass
    return props
def l11ll1l(logger, l1l11l1):
    l1l111l = os.environ.get(l11ll1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11ll1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l111l = l1l111l.upper()
    if l1l111l == l11ll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11l11l = logging.DEBUG
    elif l1l111l == l11ll1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11l11l = logging.INFO
    elif l1l111l == l11ll1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11l11l = logging.WARNING
    elif l1l111l == l11ll1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11l11l = logging.ERROR
    elif l1l111l == l11ll1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11l11l = logging.CRITICAL
    elif l1l111l == l11ll1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11l11l = logging.NOTSET
    logger.setLevel(l11l11l)
    l1l1l11 = RotatingFileHandler(l1l11l1, maxBytes=1024*1024*5, backupCount=3)
    l1l1l11.setLevel(l11l11l)
    formatter = logging.Formatter(l11ll1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1l11.setFormatter(formatter)
    logger.addHandler(l1l1l11)
    globals()[l11ll1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1lll1():
    return globals()[l11ll1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111l1l():
    if platform.system() == l11ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11ll1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll11l
        l1ll11l.l11l111(sys.stdin.fileno(), os.l1l1111)
        l1ll11l.l11l111(sys.stdout.fileno(), os.l1l1111)
def l1111ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11ll1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l1l1():
    if platform.system() == l11ll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l1lll
        return l1l1lll.l1lll11()
    elif platform.system() == l11ll1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11ll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1111():
    if platform.system() == l11ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l1lll
        return l1l1lll.l1llll1()
    elif platform.system() == l11ll1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l11l
        return l1l11l.l1111()
    elif platform.system() == l11ll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11111
        return l11111.l1111()
    return l11ll1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11l1ll(l1l111, l1l):
    if platform.system() == l11ll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l1lll
        return l1l1lll.l1ll111(l1l111, l1l)
    elif platform.system() == l11ll1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11111
        return l11111.l11l(l1l111, l1l)
    elif platform.system() == l11ll1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l11l
        return l1l11l.l11l(l1l111, l1l)
    raise ValueError(l11ll1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1ll1ll(l1ll, url):
    if platform.system() == l11ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l1lll
        return l1l1lll.l111111(l1ll, url)
    elif platform.system() == l11ll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11111
        return l11ll1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11ll1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l11l
        return l11ll1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11ll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111lll():
    if platform.system() == l11ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l1lll
        return l1l1lll.l111lll()
def l1ll1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11ll1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1lll1l(l111l1):
    l11ll1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111l11 = l11ll1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111l1:
        if l11ll1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111l11[3:]) < int(protocol[l11ll1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111l11 = protocol[l11ll1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111l11
def l111ll(l1l1ll1, l1l1l1l):
    l11ll1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1ll1 is None: l1l1ll1 = l11ll1 (u"ࠩ࠳ࠫ࠽");
    if l1l1l1l is None: l1l1l1l = l11ll1 (u"ࠪ࠴ࠬ࠾");
    l11ll11 = l1l1ll1.split(l11ll1 (u"ࠫ࠳࠭࠿"))
    l1lllll = l1l1l1l.split(l11ll1 (u"ࠬ࠴ࠧࡀ"))
    while len(l11ll11) < len(l1lllll): l11ll11.append(l11ll1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1lllll) < len(l11ll11): l1lllll.append(l11ll1 (u"ࠢ࠱ࠤࡂ"));
    l11ll11 = [ int(x) for x in l11ll11 ]
    l1lllll = [ int(x) for x in l1lllll ]
    for  i in range(len(l11ll11)):
        if len(l1lllll) == i:
            return 1
        if l11ll11[i] == l1lllll[i]:
            continue
        elif l11ll11[i] > l1lllll[i]:
            return 1
        else:
            return -1
    if len(l11ll11) != len(l1lllll):
        return -1
    return 0