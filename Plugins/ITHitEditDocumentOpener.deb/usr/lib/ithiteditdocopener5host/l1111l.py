#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l11l1 = 2048
l1 = 7
def l1ll1 (l11l11):
    global l1l1ll
    l111l = ord (l11l11 [-1])
    l1l = l11l11 [:-1]
    l1llll = l111l % len (l1l)
    l1lll = l1l [:l1llll] + l1l [l1llll:]
    if ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l1l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11111l(l111111=None):
    if platform.system() == l1ll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l111l
        props = {}
        try:
            prop_names = (l1ll1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11ll1l = l1l111l.l11l11l(l111111, l1ll1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111l1l in prop_names:
                l1ll11l = l1ll1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11ll1l, l111l1l)
                props[l111l1l] = l1l111l.l11l11l(l111111, l1ll11l)
        except:
            pass
    return props
def l1lll1l(logger, l1lllll):
    l1ll111 = os.environ.get(l1ll1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1ll111 = l1ll111.upper()
    if l1ll111 == l1ll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111ll1 = logging.DEBUG
    elif l1ll111 == l1ll1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111ll1 = logging.INFO
    elif l1ll111 == l1ll1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111ll1 = logging.WARNING
    elif l1ll111 == l1ll1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111ll1 = logging.ERROR
    elif l1ll111 == l1ll1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111ll1 = logging.CRITICAL
    elif l1ll111 == l1ll1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111ll1 = logging.NOTSET
    logger.setLevel(l111ll1)
    l1l11l1 = RotatingFileHandler(l1lllll, maxBytes=1024*1024*5, backupCount=3)
    l1l11l1.setLevel(l111ll1)
    formatter = logging.Formatter(l1ll1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l11l1.setFormatter(formatter)
    logger.addHandler(l1l11l1)
    globals()[l1ll1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11ll1():
    return globals()[l1ll1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l11ll():
    if platform.system() == l1ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l1l1
        l11l1l1.l11l1ll(sys.stdin.fileno(), os.l1l1lll)
        l11l1l1.l11l1ll(sys.stdout.fileno(), os.l1l1lll)
def l1111ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1111():
    if platform.system() == l1ll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11lll1
        return l11lll1.l1llll1()
    elif platform.system() == l1ll1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1lll1():
    if platform.system() == l1ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11lll1
        return l11lll1.l1l1l11()
    elif platform.system() == l1ll1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l1l
        return l1l1l.l1lll1()
    elif platform.system() == l1ll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111lll
        return l111lll.l1lll1()
    return l1ll1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11ll11(l111ll, l11ll):
    if platform.system() == l1ll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11lll1
        return l11lll1.l1l1l1l(l111ll, l11ll)
    elif platform.system() == l1ll1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111lll
        return l111lll.l1ll11(l111ll, l11ll)
    elif platform.system() == l1ll1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l1l
        return l1l1l.l1ll11(l111ll, l11ll)
    raise ValueError(l1ll1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1111l1(l1l1, url):
    if platform.system() == l1ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11lll1
        return l11lll1.l1ll1l1(l1l1, url)
    elif platform.system() == l1ll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111lll
        return l1ll1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l1l
        return l1ll1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1llllll():
    if platform.system() == l1ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11lll1
        return l11lll1.l1llllll()
def l11l111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll1 (u"ࠩ࠱ࠫ࠶"))[0]
def l111l11(l11l):
    l1ll1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1ll1 = l1ll1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11l:
        if l1ll1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1ll1[3:]) < int(protocol[l1ll1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1ll1 = protocol[l1ll1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1ll1
def l11(l1ll1ll, l11111):
    l1ll1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll1ll is None: l1ll1ll = l1ll1 (u"ࠩ࠳ࠫ࠽");
    if l11111 is None: l11111 = l1ll1 (u"ࠪ࠴ࠬ࠾");
    l11llll = l1ll1ll.split(l1ll1 (u"ࠫ࠳࠭࠿"))
    l1lll11 = l11111.split(l1ll1 (u"ࠬ࠴ࠧࡀ"))
    while len(l11llll) < len(l1lll11): l11llll.append(l1ll1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1lll11) < len(l11llll): l1lll11.append(l1ll1 (u"ࠢ࠱ࠤࡂ"));
    l11llll = [ int(x) for x in l11llll ]
    l1lll11 = [ int(x) for x in l1lll11 ]
    for  i in range(len(l11llll)):
        if len(l1lll11) == i:
            return 1
        if l11llll[i] == l1lll11[i]:
            continue
        elif l11llll[i] > l1lll11[i]:
            return 1
        else:
            return -1
    if len(l11llll) != len(l1lll11):
        return -1
    return 0