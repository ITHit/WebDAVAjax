#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l1l11l):
    global l11lll
    l1l1l = ord (l1l11l [-1])
    l1l11 = l1l11l [:-1]
    l11l = l1l1l % len (l1l11)
    l11l1 = l1l11 [:l11l] + l1l11 [l11l:]
    if l1l1l1:
        l1l1ll = l1lll1 () .join ([unichr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    return eval (l1l1ll)
import os
import re
import subprocess
import l111ll
from l111ll import l1ll
def l1l1():
    return []
def l111l(l1111, ll):
    logger = l1ll()
    l111l1 = []
    l1ll1l = [l11l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11l11 = process.wait()
            l1l111 = {}
            if l11l11 == 0:
                l11 = re.compile(l11l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll1 = re.compile(l11l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1llll = re.search(l11, line)
                    l1l = l1llll.group(1)
                    if l1111 == l1l:
                        l1ll1 = re.search(l11ll1, line)
                        if l1ll1:
                            l1 = l11l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1ll1.group(1)
                            version = l1llll.group(0)
                            if not l1 in l1l111:
                                l1l111[l1] = version
                            elif l111ll.l11ll(version, l1l111[l1]) > 0:
                                l1l111[l1] = version
            for l1 in l1l111:
                l111l1.append({l11l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l111[l1], l11l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1})
        except Exception as e:
            logger.error(str(e))
    return l111l1