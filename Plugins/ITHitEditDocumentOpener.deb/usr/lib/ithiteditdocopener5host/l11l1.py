#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l = 2048
l1l1l1 = 7
def l111l (l11ll):
    global l1l1l
    l1l1ll = ord (l11ll [-1])
    l11l11 = l11ll [:-1]
    l11l1l = l1l1ll % len (l11l11)
    l1l111 = l11l11 [:l11l1l] + l11l11 [l11l1l:]
    if l1:
        l1lll1 = ll () .join ([unichr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    return eval (l1lll1)
import os
import re
import subprocess
import l111l1
from l111l1 import l111ll
def l11lll():
    return []
def l1l11l(l1ll1l, l1llll):
    logger = l111ll()
    l11ll1 = []
    l1ll = [l111l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1111 = process.wait()
            l1ll1 = {}
            if l1111 == 0:
                l1l11 = re.compile(l111l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111 = re.compile(l111l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l = re.search(l1l11, line)
                    l1l1 = l11l.group(1)
                    if l1ll1l == l1l1:
                        l1lll = re.search(l111, line)
                        if l1lll:
                            l11 = l111l (u"ࠨࡦࡤࡺࠬࠄ")+l1lll.group(1)
                            version = l11l.group(0)
                            if not l11 in l1ll1:
                                l1ll1[l11] = version
                            elif l111l1.l1111l(version, l1ll1[l11]) > 0:
                                l1ll1[l11] = version
            for l11 in l1ll1:
                l11ll1.append({l111l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1[l11], l111l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11})
        except Exception as e:
            logger.error(str(e))
    return l11ll1