#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l1l11l = 2048
l11l1l = 7
def l11l11 (l1l1l1):
    global l11ll
    l11 = ord (l1l1l1 [-1])
    l11lll = l1l1l1 [:-1]
    l1111 = l11 % len (l11lll)
    l1 = l11lll [:l1111] + l11lll [l1111:]
    if l1lll1:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    return eval (l1ll1l)
import os
import re
import subprocess
import l1111l
from l1111l import l1ll11
def ll():
    return []
def l1l111(l1l1ll, l1l11):
    logger = l1ll11()
    l1ll = []
    l1llll = [l11l11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1llll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l = process.wait()
            l111l1 = {}
            if l1l == 0:
                l1l1 = re.compile(l11l11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll1 = re.compile(l11l11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll1 = re.search(l1l1, line)
                    l111 = l1ll1.group(1)
                    if l1l1ll == l111:
                        l1l1l = re.search(l11ll1, line)
                        if l1l1l:
                            l11l = l11l11 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l.group(1)
                            version = l1ll1.group(0)
                            if not l11l in l111l1:
                                l111l1[l11l] = version
                            elif l1111l.l1lll(version, l111l1[l11l]) > 0:
                                l111l1[l11l] = version
            for l11l in l111l1:
                l1ll.append({l11l11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l1[l11l], l11l11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l})
        except Exception as e:
            logger.error(str(e))
    return l1ll