#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l11lll = 2048
l111ll = 7
def l11 (l1l1l):
    global l1111l
    l1lll1 = ord (l1l1l [-1])
    l1l11 = l1l1l [:-1]
    l11ll = l1lll1 % len (l1l11)
    l1l1 = l1l11 [:l11ll] + l1l11 [l11ll:]
    if l1ll:
        l111l1 = l111 () .join ([unichr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    return eval (l111l1)
import os
import re
import subprocess
import l1llll
from l1llll import l11l
def l1():
    return []
def l1l(l1l111, l1111):
    logger = l11l()
    l1l11l = []
    l11l11 = [l11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11l11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1 = process.wait()
            l1ll1l = {}
            if l1ll1 == 0:
                l1ll11 = re.compile(l11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1l1 = re.compile(l11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1ll = re.search(l1ll11, line)
                    ll = l1l1ll.group(1)
                    if l1l111 == ll:
                        l11ll1 = re.search(l1l1l1, line)
                        if l11ll1:
                            l111l = l11 (u"ࠨࡦࡤࡺࠬࠄ")+l11ll1.group(1)
                            version = l1l1ll.group(0)
                            if not l111l in l1ll1l:
                                l1ll1l[l111l] = version
                            elif l1llll.l1lll(version, l1ll1l[l111l]) > 0:
                                l1ll1l[l111l] = version
            for l111l in l1ll1l:
                l1l11l.append({l11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1l[l111l], l11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l})
        except Exception as e:
            logger.error(str(e))
    return l1l11l