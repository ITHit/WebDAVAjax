#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l1l (l11ll1):
    global l1l1ll
    l1llll = ord (l11ll1 [-1])
    l11l1l = l11ll1 [:-1]
    l111 = l1llll % len (l11l1l)
    l11lll = l11l1l [:l111] + l11l1l [l111:]
    if l111l1:
        l11l = l111l () .join ([unichr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    return eval (l11l)
import os
import re
import subprocess
import l1l
from l1l import l1l11
def ll():
    return []
def l1ll1l(l1ll11, l1l111):
    logger = l1l11()
    l1l1 = []
    l11l1 = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11l1:
        try:
            output = os.popen(cmd).read()
            l11l11 = 0
            l1ll1 = {}
            if l11l11 == 0:
                l1111l = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1111 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11ll = re.search(l1111l, line)
                    l1ll = l11ll.group(1)
                    if l1ll11 == l1ll:
                        l1l1l1 = re.search(l1111, line)
                        if l1l1l1:
                            l1 = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l1.group(1)
                            version = l11ll.group(0)
                            if not l1 in l1ll1:
                                l1ll1[l1] = version
                            elif l1l.l111ll(version, l1ll1[l1]) > 0:
                                l1ll1[l1] = version
            for l1 in l1ll1:
                l1l1.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1[l1], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1})
        except Exception as e:
            logger.error(str(e))
    return l1l1