#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1l1ll = 2048
l1l1l1 = 7
def l1111 (l1ll):
    global l1ll1
    l1l = ord (l1ll [-1])
    l1lll1 = l1ll [:-1]
    l1llll = l1l % len (l1lll1)
    l1 = l1lll1 [:l1llll] + l1lll1 [l1llll:]
    if l111ll:
        l111l = l11l1l () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    else:
        l111l = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    return eval (l111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111lll(l1llll1=None):
    if platform.system() == l1111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111ll1
        props = {}
        try:
            prop_names = (l1111 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1111 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1111 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1111 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1111 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1111 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1111 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1111 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1111 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1111 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1111 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111 = l111ll1.l1l111l(l1llll1, l1111 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1111ll in prop_names:
                l1l1l11 = l1111 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111, l1111ll)
                props[l1111ll] = l111ll1.l1l111l(l1llll1, l1l1l11)
        except:
            pass
    return props
def l1l1ll1(logger, l11llll):
    l11l11l = os.environ.get(l1111 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1111 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l11l = l11l11l.upper()
    if l11l11l == l1111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1lll = logging.DEBUG
    elif l11l11l == l1111 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1lll = logging.INFO
    elif l11l11l == l1111 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1lll = logging.WARNING
    elif l11l11l == l1111 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1lll = logging.ERROR
    elif l11l11l == l1111 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1lll = logging.CRITICAL
    elif l11l11l == l1111 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1lll = logging.NOTSET
    logger.setLevel(l1l1lll)
    l111111 = RotatingFileHandler(l11llll, maxBytes=1024*1024*5, backupCount=3)
    l111111.setLevel(l1l1lll)
    formatter = logging.Formatter(l1111 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111111.setFormatter(formatter)
    logger.addHandler(l111111)
    globals()[l1111 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def ll():
    return globals()[l1111 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111l1l():
    if platform.system() == l1111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1111 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1lll1l
        l1lll1l.l11l1l1(sys.stdin.fileno(), os.l11ll11)
        l1lll1l.l11l1l1(sys.stdout.fileno(), os.l11ll11)
def l1l1111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1111 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11lll1():
    if platform.system() == l1111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l1ll
        return l11l1ll.l1lllll()
    elif platform.system() == l1111 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll11():
    if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l1ll
        return l11l1ll.l1ll1ll()
    elif platform.system() == l1111 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11lll
        return l11lll.l1ll11()
    elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111l11
        return l111l11.l1ll11()
    return l1111 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lll11(l111l1, l1l1):
    if platform.system() == l1111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l1ll
        return l11l1ll.l11l111(l111l1, l1l1)
    elif platform.system() == l1111 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111l11
        return l111l11.l1l11(l111l1, l1l1)
    elif platform.system() == l1111 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11lll
        return l11lll.l1l11(l111l1, l1l1)
    raise ValueError(l1111 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1ll1l1(l1l1l, url):
    if platform.system() == l1111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l1ll
        return l11l1ll.l1ll11l(l1l1l, url)
    elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111l11
        return l1111 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1111 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11lll
        return l1111 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l1l1l():
    if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l1ll
        return l11l1ll.l1l1l1l()
def l1l11l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1111 (u"ࠩ࠱ࠫ࠶"))[0]
def l11ll1l(l11ll1):
    l1111 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1111l1 = l1111 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11ll1:
        if l1111 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1111l1[3:]) < int(protocol[l1111 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1111l1 = protocol[l1111 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1111l1
def l11l(l1l11ll, l1llllll):
    l1111 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l11ll is None: l1l11ll = l1111 (u"ࠩ࠳ࠫ࠽");
    if l1llllll is None: l1llllll = l1111 (u"ࠪ࠴ࠬ࠾");
    l1ll111 = l1l11ll.split(l1111 (u"ࠫ࠳࠭࠿"))
    l11111l = l1llllll.split(l1111 (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll111) < len(l11111l): l1ll111.append(l1111 (u"ࠨ࠰ࠣࡁ"));
    while len(l11111l) < len(l1ll111): l11111l.append(l1111 (u"ࠢ࠱ࠤࡂ"));
    l1ll111 = [ int(x) for x in l1ll111 ]
    l11111l = [ int(x) for x in l11111l ]
    for  i in range(len(l1ll111)):
        if len(l11111l) == i:
            return 1
        if l1ll111[i] == l11111l[i]:
            continue
        elif l1ll111[i] > l11111l[i]:
            return 1
        else:
            return -1
    if len(l1ll111) != len(l11111l):
        return -1
    return 0