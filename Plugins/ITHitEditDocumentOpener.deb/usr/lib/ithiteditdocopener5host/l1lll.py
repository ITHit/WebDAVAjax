#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l111 = 2048
l1l1l = 7
def l1l11 (l1l1l1):
    global l11l1l
    l1l1 = ord (l1l1l1 [-1])
    l11ll = l1l1l1 [:-1]
    l1llll = l1l1 % len (l11ll)
    l1lll1 = l11ll [:l1llll] + l11ll [l1llll:]
    if l1ll11:
        l1ll1l = l1l111 () .join ([unichr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    return eval (l1ll1l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l1lll(l1lllll=None):
    if platform.system() == l1l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll1l1
        props = {}
        try:
            prop_names = (l1l11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11llll = l1ll1l1.l1lll11(l1lllll, l1l11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1ll in prop_names:
                l1l1l11 = l1l11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11llll, l11l1ll)
                props[l11l1ll] = l1ll1l1.l1lll11(l1lllll, l1l1l11)
        except:
            pass
    return props
def l111l11(logger, l11ll11):
    l111l1l = os.environ.get(l1l11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l1l = l111l1l.upper()
    if l111l1l == l1l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1llllll = logging.DEBUG
    elif l111l1l == l1l11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1llllll = logging.INFO
    elif l111l1l == l1l11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1llllll = logging.WARNING
    elif l111l1l == l1l11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1llllll = logging.ERROR
    elif l111l1l == l1l11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1llllll = logging.CRITICAL
    elif l111l1l == l1l11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1llllll = logging.NOTSET
    logger.setLevel(l1llllll)
    l1l1l1l = RotatingFileHandler(l11ll11, maxBytes=1024*1024*5, backupCount=3)
    l1l1l1l.setLevel(l1llllll)
    formatter = logging.Formatter(l1l11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1l1l.setFormatter(formatter)
    logger.addHandler(l1l1l1l)
    globals()[l1l11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1():
    return globals()[l1l11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll1ll():
    if platform.system() == l1l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111ll1
        l111ll1.l111lll(sys.stdin.fileno(), os.l11l111)
        l111ll1.l111lll(sys.stdout.fileno(), os.l11l111)
def l11111l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l11l():
    if platform.system() == l1l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1111ll
        return l1111ll.l1llll1()
    elif platform.system() == l1l11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l11():
    if platform.system() == l1l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1111ll
        return l1111ll.l111111()
    elif platform.system() == l1l11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1111l
        return l1111l.l11l11()
    elif platform.system() == l1l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l11ll
        return l1l11ll.l11l11()
    return l1l11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1ll11l(l1ll1, l11):
    if platform.system() == l1l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1111ll
        return l1111ll.l1l1ll1(l1ll1, l11)
    elif platform.system() == l1l11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l11ll
        return l1l11ll.l11lll(l1ll1, l11)
    elif platform.system() == l1l11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1111l
        return l1111l.l11lll(l1ll1, l11)
    raise ValueError(l1l11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1ll111(l11l1, url):
    if platform.system() == l1l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1111ll
        return l1111ll.l1l1111(l11l1, url)
    elif platform.system() == l1l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l11ll
        return l1l11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1111l
        return l1l11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11lll1():
    if platform.system() == l1l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1111ll
        return l1111ll.l11lll1()
def l1111l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l11 (u"ࠩ࠱ࠫ࠶"))[0]
def l11111(ll):
    l1l11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l11l1 = l1l11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in ll:
        if l1l11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l11l1[3:]) < int(protocol[l1l11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l11l1 = protocol[l1l11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l11l1
def l1l11l(l1l111l, l1lll1l):
    l1l11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l111l is None: l1l111l = l1l11 (u"ࠩ࠳ࠫ࠽");
    if l1lll1l is None: l1lll1l = l1l11 (u"ࠪ࠴ࠬ࠾");
    l11l1l1 = l1l111l.split(l1l11 (u"ࠫ࠳࠭࠿"))
    l11ll1l = l1lll1l.split(l1l11 (u"ࠬ࠴ࠧࡀ"))
    while len(l11l1l1) < len(l11ll1l): l11l1l1.append(l1l11 (u"ࠨ࠰ࠣࡁ"));
    while len(l11ll1l) < len(l11l1l1): l11ll1l.append(l1l11 (u"ࠢ࠱ࠤࡂ"));
    l11l1l1 = [ int(x) for x in l11l1l1 ]
    l11ll1l = [ int(x) for x in l11ll1l ]
    for  i in range(len(l11l1l1)):
        if len(l11ll1l) == i:
            return 1
        if l11l1l1[i] == l11ll1l[i]:
            continue
        elif l11l1l1[i] > l11ll1l[i]:
            return 1
        else:
            return -1
    if len(l11l1l1) != len(l11ll1l):
        return -1
    return 0