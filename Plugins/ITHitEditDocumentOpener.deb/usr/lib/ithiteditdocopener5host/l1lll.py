#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l11ll = 2048
l111 = 7
def l1111l (l1l1):
    global l11l
    l1ll1l = ord (l1l1 [-1])
    l1l11 = l1l1 [:-1]
    l1lll1 = l1ll1l % len (l1l11)
    l111ll = l1l11 [:l1lll1] + l1l11 [l1lll1:]
    if l1l:
        l11l11 = l11ll1 () .join ([unichr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    return eval (l11l11)
import os
import re
import subprocess
import l11l1l
from l11l1l import l1l1l
def l1ll11():
    return []
def ll(l111l, l1l1ll):
    logger = l1l1l()
    l1l1l1 = []
    l11lll = [l1111l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1111l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            output = os.popen(cmd).read()
            l1ll1 = 0
            l1llll = {}
            if l1ll1 == 0:
                l1111 = re.compile(l1111l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11 = re.compile(l1111l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111l1 = re.search(l1111, line)
                    l1 = l111l1.group(1)
                    if l111l == l1:
                        l11l1 = re.search(l11, line)
                        if l11l1:
                            l1l111 = l1111l (u"ࠨࡦࡤࡺࠬࠄ")+l11l1.group(1)
                            version = l111l1.group(0)
                            if not l1l111 in l1llll:
                                l1llll[l1l111] = version
                            elif l11l1l.l1ll(version, l1llll[l1l111]) > 0:
                                l1llll[l1l111] = version
            for l1l111 in l1llll:
                l1l1l1.append({l1111l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1llll[l1l111], l1111l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l111})
        except Exception as e:
            logger.error(str(e))
    return l1l1l1