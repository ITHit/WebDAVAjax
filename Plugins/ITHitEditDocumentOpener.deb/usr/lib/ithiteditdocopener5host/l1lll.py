#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1ll11 = 2048
l1l1ll = 7
def l11l (ll):
    global l111l1
    l1l11 = ord (ll [-1])
    l11ll1 = ll [:-1]
    l11ll = l1l11 % len (l11ll1)
    l1ll1 = l11ll1 [:l11ll] + l11ll1 [l11ll:]
    if l111ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    return eval (l1l1l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11ll11(l1ll1ll=None):
    if platform.system() == l11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1111
        props = {}
        try:
            prop_names = (l11l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1ll11l = l1l1111.l1ll1l1(l1ll1ll, l11l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l111 in prop_names:
                l11l11l = l11l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1ll11l, l11l111)
                props[l11l111] = l1l1111.l1ll1l1(l1ll1ll, l11l11l)
        except:
            pass
    return props
def l1l11l1(logger, l11lll1):
    l11l1l1 = os.environ.get(l11l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l1l1 = l11l1l1.upper()
    if l11l1l1 == l11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111ll1 = logging.DEBUG
    elif l11l1l1 == l11l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111ll1 = logging.INFO
    elif l11l1l1 == l11l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111ll1 = logging.WARNING
    elif l11l1l1 == l11l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111ll1 = logging.ERROR
    elif l11l1l1 == l11l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111ll1 = logging.CRITICAL
    elif l11l1l1 == l11l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111ll1 = logging.NOTSET
    logger.setLevel(l111ll1)
    l11l1ll = RotatingFileHandler(l11lll1, maxBytes=1024*1024*5, backupCount=3)
    l11l1ll.setLevel(l111ll1)
    formatter = logging.Formatter(l11l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l1ll.setFormatter(formatter)
    logger.addHandler(l11l1ll)
    globals()[l11l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l11l():
    return globals()[l11l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l11():
    if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111l11
        l111l11.l1ll111(sys.stdin.fileno(), os.l1lllll)
        l111l11.l1ll111(sys.stdout.fileno(), os.l1lllll)
def l1llllll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll1l():
    if platform.system() == l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l1ll1
        return l1l1ll1.l1l111l()
    elif platform.system() == l11l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l():
    if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l1ll1
        return l1l1ll1.l111l1l()
    elif platform.system() == l11l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l1l()
    elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1111l1
        return l1111l1.l1l()
    return l11l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l11ll(l111, l1111l):
    if platform.system() == l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l1ll1
        return l1l1ll1.l11ll1l(l111, l1111l)
    elif platform.system() == l11l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1111l1
        return l1111l1.l11l1l(l111, l1111l)
    elif platform.system() == l11l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.l11l1l(l111, l1111l)
    raise ValueError(l11l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111111(l11l1, url):
    if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l1ll1
        return l1l1ll1.l11llll(l11l1, url)
    elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1111l1
        return l11l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return l11l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1111ll():
    if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l1ll1
        return l1l1ll1.l1111ll()
def l1llll1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l (u"ࠩ࠱ࠫ࠶"))[0]
def l11111(l1ll):
    l11l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1lll = l11l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll:
        if l11l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1lll[3:]) < int(protocol[l11l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1lll = protocol[l11l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1lll
def l11(l1l1l1l, l1lll11):
    l11l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1l1l is None: l1l1l1l = l11l (u"ࠩ࠳ࠫ࠽");
    if l1lll11 is None: l1lll11 = l11l (u"ࠪ࠴ࠬ࠾");
    l11111l = l1l1l1l.split(l11l (u"ࠫ࠳࠭࠿"))
    l111lll = l1lll11.split(l11l (u"ࠬ࠴ࠧࡀ"))
    while len(l11111l) < len(l111lll): l11111l.append(l11l (u"ࠨ࠰ࠣࡁ"));
    while len(l111lll) < len(l11111l): l111lll.append(l11l (u"ࠢ࠱ࠤࡂ"));
    l11111l = [ int(x) for x in l11111l ]
    l111lll = [ int(x) for x in l111lll ]
    for  i in range(len(l11111l)):
        if len(l111lll) == i:
            return 1
        if l11111l[i] == l111lll[i]:
            continue
        elif l11111l[i] > l111lll[i]:
            return 1
        else:
            return -1
    if len(l11111l) != len(l111lll):
        return -1
    return 0