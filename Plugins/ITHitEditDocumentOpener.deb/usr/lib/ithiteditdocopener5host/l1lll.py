#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll = 2048
l1ll1l = 7
def l1l1l (l1l1l1):
    global l11l1l
    l11l = ord (l1l1l1 [-1])
    l111l1 = l1l1l1 [:-1]
    l1l1ll = l11l % len (l111l1)
    ll = l111l1 [:l1l1ll] + l111l1 [l1l1ll:]
    if l1ll11:
        l11l11 = l11 () .join ([unichr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    return eval (l11l11)
import os
import re
import subprocess
import l111l
from l111l import l1ll
def l1l11():
    return []
def l1111(l111, l1lll1):
    logger = l1ll()
    l1l1 = []
    l111ll = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l111 = process.wait()
            l1llll = {}
            if l1l111 == 0:
                l1ll1 = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11ll1 = re.search(l1ll1, line)
                    l1l11l = l11ll1.group(1)
                    if l111 == l1l11l:
                        l1l = re.search(l1, line)
                        if l1l:
                            l11lll = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l.group(1)
                            version = l11ll1.group(0)
                            if not l11lll in l1llll:
                                l1llll[l11lll] = version
                            elif l111l.l11l1(version, l1llll[l11lll]) > 0:
                                l1llll[l11lll] = version
            for l11lll in l1llll:
                l1l1.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1llll[l11lll], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11lll})
        except Exception as e:
            logger.error(str(e))
    return l1l1