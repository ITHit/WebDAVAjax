#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll = 2048
l1ll1l = 7
def l1l1l (l1l1l1):
    global l11l1l
    l11l = ord (l1l1l1 [-1])
    l111l1 = l1l1l1 [:-1]
    l1l1ll = l11l % len (l111l1)
    ll = l111l1 [:l1l1ll] + l111l1 [l1l1ll:]
    if l1ll11:
        l11l11 = l11 () .join ([unichr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    return eval (l11l11)
import subprocess, threading
from l111l import l1ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11ll1l():
    l1l111l1 = [l1l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l111l1:
        try:
            l1l11l1l = l1l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l11ll = winreg.l1l11111(winreg.l11l1lll, l1l11l1l)
        except l11l1ll1:
            continue
        value = winreg.l1l11l11(l11l11ll, l1l1l (u"ࠦࠧ࢓"))
        return value.split(l1l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1l11():
    l11ll111 = []
    for name in l1l1l11l:
        try:
            l1l11l1l = l1l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll11l = winreg.l1l11111(winreg.l11l1lll, l1l11l1l)
            if winreg.l1l11l11(l11ll11l, l1l1l (u"ࠢࠣ࢖")):
                l11ll111.append(name)
        except l11l1ll1:
            continue
    return l11ll111
def l1l1l1l(l111, l1lll1):
    import re
    l1l1 = []
    l11ll1l1 = winreg.l1l11111(winreg.l11l1lll, l1l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l11l1(l11ll1l1)[0]):
        try:
            l1l111ll = winreg.l11l111l(l11ll1l1, i)
            if l1l111ll.startswith(l1lll1):
                l1l11ll1 = winreg.l11lll1l(l11ll1l1, l1l111ll)
                value, l11l1l11 = winreg.l11l1l1l(l1l11ll1, l1l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lll11 = {l1l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11lll = m.group(2)
                    if l111 == l1l11lll:
                        m = re.search(l1lll1.replace(l1l1l (u"ࠬ࠴࢛ࠧ"), l1l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l111ll)
                        l11lll11[l1l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1.append(l11lll11)
                else:
                    raise ValueError(l1l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1ll1 as ex:
            continue
    return l1l1
def l11l1111(l11lll):
    try:
        l11ll1ll = l1l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11lll)
        l1l1111l = winreg.l1l11111(winreg.l11l1lll, l11ll1ll)
        value, l11l1l11 = winreg.l11l1l1l(l1l1111l, l1l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1ll1:
        pass
    return l1l1l (u"࠭ࠧࢣ")
def l1ll1ll(l11lll, url):
    threading.Thread(target=_11lllll,args=(l11lll, url)).start()
    return l1l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lllll(l11lll, url):
    logger = l1ll()
    l11llll1 = l11l1111(l11lll)
    logger.debug(l1l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11llll1, url))
    retcode = subprocess.Popen(l1l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11llll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)