#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l111 = 2048
l1l1l = 7
def l1l11 (l1l1l1):
    global l11l1l
    l1l1 = ord (l1l1l1 [-1])
    l11ll = l1l1l1 [:-1]
    l1llll = l1l1 % len (l11ll)
    l1lll1 = l11ll [:l1llll] + l11ll [l1llll:]
    if l1ll11:
        l1ll1l = l1l111 () .join ([unichr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    return eval (l1ll1l)
import subprocess, threading
from l1lll import l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1llll1():
    l11lll1l = [l1l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lll1l:
        try:
            l11l1lll = l1l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll11 = winreg.l11l1ll1(winreg.l11ll11l, l11l1lll)
        except l11ll111:
            continue
        value = winreg.l11lllll(l11lll11, l1l11 (u"ࠦࠧ࢓"))
        return value.split(l1l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111111():
    l11ll1ll = []
    for name in l1l1l111:
        try:
            l11l1lll = l1l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1l1 = winreg.l11l1ll1(winreg.l11ll11l, l11l1lll)
            if winreg.l11lllll(l11ll1l1, l1l11 (u"ࠢࠣ࢖")):
                l11ll1ll.append(name)
        except l11ll111:
            continue
    return l11ll1ll
def l1l1ll1(l1ll1, l11):
    import re
    l111ll = []
    l11l111l = winreg.l11l1ll1(winreg.l11ll11l, l1l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11lll(l11l111l)[0]):
        try:
            l1l11l11 = winreg.l11l1l11(l11l111l, i)
            if l1l11l11.startswith(l11):
                l1l1111l = winreg.l11l11ll(l11l111l, l1l11l11)
                value, l1l11ll1 = winreg.l11l1l1l(l1l1111l, l1l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11111 = {l1l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l111l1 = m.group(2)
                    if l1ll1 == l1l111l1:
                        m = re.search(l11.replace(l1l11 (u"ࠬ࠴࢛ࠧ"), l1l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11l11)
                        l1l11111[l1l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111ll.append(l1l11111)
                else:
                    raise ValueError(l1l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll111 as ex:
            continue
    return l111ll
def l1l111ll(l11l1):
    try:
        l11llll1 = l1l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1)
        l1l11l1l = winreg.l11l1ll1(winreg.l11ll11l, l11llll1)
        value, l1l11ll1 = winreg.l11l1l1l(l1l11l1l, l1l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l11 (u"ࠬࠨࠧࢢ"))[1]
    except l11ll111:
        pass
    return l1l11 (u"࠭ࠧࢣ")
def l1l1111(l11l1, url):
    threading.Thread(target=_11l1111,args=(l11l1, url)).start()
    return l1l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1111(l11l1, url):
    logger = l1()
    l11l11l1 = l1l111ll(l11l1)
    logger.debug(l1l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11l1, url))
    retcode = subprocess.Popen(l1l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)