#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1l111 = 7
def l1ll (l111l):
    global l111l1
    l11l = ord (l111l [-1])
    l111ll = l111l [:-1]
    l1l11l = l11l % len (l111ll)
    l1111 = l111ll [:l1l11l] + l111ll [l1l11l:]
    if l11l1:
        l1l1 = l1lll () .join ([unichr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    else:
        l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    return eval (l1l1)
import subprocess, threading
from ll import l1111l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l1ll():
    l11l1ll1 = [l1ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1ll1:
        try:
            l11l1l11 = l1ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll11l = winreg.l11lll11(winreg.l11llll1, l11l1l11)
        except l11ll1l1:
            continue
        value = winreg.l11ll111(l11ll11l, l1ll (u"ࠦࠧ࢓"))
        return value.split(l1ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll111():
    l1l11l11 = []
    for name in l1l1l11l:
        try:
            l11l1l11 = l1ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11ll1 = winreg.l11lll11(winreg.l11llll1, l11l1l11)
            if winreg.l11ll111(l1l11ll1, l1ll (u"ࠢࠣ࢖")):
                l1l11l11.append(name)
        except l11ll1l1:
            continue
    return l1l11l11
def l11lll1(l1, l11l11):
    import re
    l1lll1 = []
    l1l11111 = winreg.l11lll11(winreg.l11llll1, l1ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lll1l(l1l11111)[0]):
        try:
            l1l111ll = winreg.l11l111l(l1l11111, i)
            if l1l111ll.startswith(l11l11):
                l11l1111 = winreg.l11l1lll(l1l11111, l1l111ll)
                value, l1l1111l = winreg.l1l111l1(l11l1111, l1ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11l1l = {l1ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11lll = m.group(2)
                    if l1 == l1l11lll:
                        m = re.search(l11l11.replace(l1ll (u"ࠬ࠴࢛ࠧ"), l1ll (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l111ll)
                        l1l11l1l[l1ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1lll1.append(l1l11l1l)
                else:
                    raise ValueError(l1ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll1l1 as ex:
            continue
    return l1lll1
def l11l11ll(l11lll):
    try:
        l11ll1ll = l1ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11lll)
        l11l11l1 = winreg.l11lll11(winreg.l11llll1, l11ll1ll)
        value, l1l1111l = winreg.l1l111l1(l11l11l1, l1ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll (u"ࠬࠨࠧࢢ"))[1]
    except l11ll1l1:
        pass
    return l1ll (u"࠭ࠧࢣ")
def l1l11l1(l11lll, url):
    threading.Thread(target=_11l1l1l,args=(l11lll, url)).start()
    return l1ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1l1l(l11lll, url):
    logger = l1111l()
    l11lllll = l11l11ll(l11lll)
    logger.debug(l1ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lllll, url))
    retcode = subprocess.Popen(l1ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lllll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)