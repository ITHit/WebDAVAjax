#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1lll = 2048
l11l1 = 7
def l111 (l1ll11):
    global l1l11
    l11l1l = ord (l1ll11 [-1])
    l1l1l = l1ll11 [:-1]
    l1l1ll = l11l1l % len (l1l1l)
    l1llll = l1l1l [:l1l1ll] + l1l1l [l1l1ll:]
    if l1ll:
        l1111l = l111ll () .join ([unichr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    return eval (l1111l)
import l1l1l1
from l1l1l111 import l1l1l11l
import objc as _111l1ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1ll.l111l1l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111111l.l1111lll(l111lll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111lll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111 (u"ࠨࠩࢬ"), {l111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l1111l11):
    l1111l11 = (l1111l11 + l111 (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll11 = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l11111l1 = CFURLCreateWithString( kCFAllocatorDefault, l111ll11, _111l1ll.nil )
    l1111111 = LaunchServices.l1111l1l( l11111l1, LaunchServices.l1111ll1, _111l1ll.nil )
    if l1111111[0] is not None:
        return True
    return False
def l11l():
    l111l111 = []
    for name in l1l1l11l:
        try:
            if l111l11l(name):
                l111l111.append(name)
        except:
            continue
    return l111l111
def l11l11(l11ll1, l1l111):
    import plistlib
    import os
    l1l = []
    l1ll1l = {}
    for l11111ll in os.listdir(l111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111ll.startswith(l1l111):
            try:
                l111llll = l111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111ll
                with open(l111llll, l111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1111 = plist[l111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll1l = version.split(l111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11ll1 == l111ll1l:
                        if not l1111 in l1ll1l:
                            l1ll1l[l1111] = version
                        elif l1l1l1.l111l(version, l1ll1l[l1111]) > 0:
                            l1ll1l[l1111] = version
            except BaseException:
                continue
    for l1111 in l1ll1l:
        l1l.append({l111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1l[l1111], l111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1111})
    return l1l