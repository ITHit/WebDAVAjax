#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll1l = 7
def l1111 (l111ll):
    global l11l11
    l1l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l1l1 % len (l1llll)
    l1111l = l1llll [:l11l] + l1llll [l11l:]
    if l1:
        l1lll = l11ll () .join ([unichr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    return eval (l1lll)
import l11ll1
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l111l11l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll11.l1111l1l(l11111l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1111 (u"ࠨࠩࢬ"), {l1111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111ll(l111l1ll):
    l111l1ll = (l111l1ll + l1111 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l11 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l111l111 = CFURLCreateWithString( kCFAllocatorDefault, l1111l11, _1111ll1.nil )
    l111llll = LaunchServices.l111lll1( l111l111, LaunchServices.l111l1l1, _1111ll1.nil )
    if l111llll[0] is not None:
        return True
    return False
def l11():
    l1111lll = []
    for name in l1l1l111:
        try:
            if l11111ll(name):
                l1111lll.append(name)
        except:
            continue
    return l1111lll
def l111(l111l, l1l1l1):
    import plistlib
    import os
    l1ll11 = []
    l1l1ll = {}
    for l111ll1l in os.listdir(l1111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(l1l1l1):
            try:
                l1111111 = l1111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l1111111, l1111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll = plist[l1111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111111l = version.split(l1111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111l == l111111l:
                        if not l1ll in l1l1ll:
                            l1l1ll[l1ll] = version
                        elif l11ll1.l1l111(version, l1l1ll[l1ll]) > 0:
                            l1l1ll[l1ll] = version
            except BaseException:
                continue
    for l1ll in l1l1ll:
        l1ll11.append({l1111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l1ll[l1ll], l1111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll})
    return l1ll11