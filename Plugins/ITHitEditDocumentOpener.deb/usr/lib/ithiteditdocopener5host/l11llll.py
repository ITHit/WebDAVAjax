#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1l = 2048
l1111 = 7
def l1ll (l11l):
    global l1ll1l
    l1lll1 = ord (l11l [-1])
    l1lll = l11l [:-1]
    ll = l1lll1 % len (l1lll)
    l1ll1 = l1lll [:ll] + l1lll [ll:]
    if l11l1:
        l1llll = l1l1 () .join ([unichr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    return eval (l1llll)
import subprocess, threading
from l111l1 import l11lll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l1l11():
    l11l11ll = [l1ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l11ll:
        try:
            l11lllll = l1ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll11 = winreg.l11l1l1l(winreg.l1l11l11, l11lllll)
        except l11ll111:
            continue
        value = winreg.l1l111l1(l11lll11, l1ll (u"ࠦࠧ࢓"))
        return value.split(l1ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1111ll():
    l11l11l1 = []
    for name in l1l1l111:
        try:
            l11lllll = l1ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11ll1 = winreg.l11l1l1l(winreg.l1l11l11, l11lllll)
            if winreg.l1l111l1(l1l11ll1, l1ll (u"ࠢࠣ࢖")):
                l11l11l1.append(name)
        except l11ll111:
            continue
    return l11l11l1
def l1111l1(l11ll, l11ll1):
    import re
    l111 = []
    l11ll1l1 = winreg.l11l1l1l(winreg.l1l11l11, l1ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1111(l11ll1l1)[0]):
        try:
            l1l11111 = winreg.l11l1ll1(l11ll1l1, i)
            if l1l11111.startswith(l11ll1):
                l11lll1l = winreg.l11l1l11(l11ll1l1, l1l11111)
                value, l1l11l1l = winreg.l11llll1(l11lll1l, l1ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111ll = {l1ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1lll = m.group(2)
                    if l11ll == l11l1lll:
                        m = re.search(l11ll1.replace(l1ll (u"ࠬ࠴࢛ࠧ"), l1ll (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11111)
                        l1l111ll[l1ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111.append(l1l111ll)
                else:
                    raise ValueError(l1ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll111 as ex:
            continue
    return l111
def l1l1111l(l1111l):
    try:
        l11l111l = l1ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1111l)
        l11ll11l = winreg.l11l1l1l(winreg.l1l11l11, l11l111l)
        value, l1l11l1l = winreg.l11llll1(l11ll11l, l1ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll (u"ࠬࠨࠧࢢ"))[1]
    except l11ll111:
        pass
    return l1ll (u"࠭ࠧࢣ")
def l1l111l(l1111l, url):
    threading.Thread(target=_1l11lll,args=(l1111l, url)).start()
    return l1ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11lll(l1111l, url):
    logger = l11lll()
    l11ll1ll = l1l1111l(l1111l)
    logger.debug(l1ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll1ll, url))
    retcode = subprocess.Popen(l1ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll1ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)