#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll1 = 7
def l11l (l1l11l):
    global ll
    l1llll = ord (l1l11l [-1])
    l11l1 = l1l11l [:-1]
    l1l1 = l1llll % len (l11l1)
    l1lll = l11l1 [:l1l1] + l11l1 [l1l1:]
    if l1:
        l1l111 = l11lll () .join ([unichr (ord (char) - l1l1ll - (l1ll + l1llll) % l1ll1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1ll - (l1ll + l1llll) % l1ll1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l111)
import l111ll
from l1l1l11l import l1l1l111
import objc as _111lll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111lll1.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l111llll(l111111l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111111l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l (u"ࠨࠩࢬ"), {l11l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1ll(l1111l11):
    l1111l11 = (l1111l11 + l11l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111ll1 = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l1111ll1, _111lll1.nil )
    l111ll11 = LaunchServices.l111l111( l1111111, LaunchServices.l1111l1l, _111lll1.nil )
    if l111ll11[0] is not None:
        return True
    return False
def l1l11():
    l111l11l = []
    for name in l1l1l111:
        try:
            if l111l1ll(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def l111l(l1ll11, l111):
    import plistlib
    import os
    l11 = []
    l1l = {}
    for l111l1l1 in os.listdir(l11l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l111):
            try:
                l11111l1 = l11l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l11111l1, l11l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l111l1 = plist[l11l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll1l = version.split(l11l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll11 == l111ll1l:
                        if not l111l1 in l1l:
                            l1l[l111l1] = version
                        elif l111ll.l1ll1l(version, l1l[l111l1]) > 0:
                            l1l[l111l1] = version
            except BaseException:
                continue
    for l111l1 in l1l:
        l11.append({l11l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l[l111l1], l11l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l111l1})
    return l11