#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1ll11 = 2048
l1llll = 7
def l1 (l11lll):
    global l1l1
    l11ll1 = ord (l11lll [-1])
    l111l = l11lll [:-1]
    l1l = l11ll1 % len (l111l)
    l111ll = l111l [:l1l] + l111l [l1l:]
    if l11l1:
        l1111 = l1l1l () .join ([unichr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    return eval (l1111)
import l1l1l1
from l1l1l111 import l1l1l11l
import objc as _111l111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l111.l111l1ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l11l.l1111l11(l11111ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1 (u"ࠨࠩࢬ"), {l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111ll1(l1111111):
    l1111111 = (l1111111 + l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l11111l1 = CFStringCreateWithCString( kCFAllocatorDefault, l1111111, kCFStringEncodingUTF8 )
    l1111l1l = CFURLCreateWithString( kCFAllocatorDefault, l11111l1, _111l111.nil )
    l111l1l1 = LaunchServices.l111ll11( l1111l1l, LaunchServices.l111llll, _111l111.nil )
    if l111l1l1[0] is not None:
        return True
    return False
def l111():
    l111ll1l = []
    for name in l1l1l11l:
        try:
            if l1111ll1(name):
                l111ll1l.append(name)
        except:
            continue
    return l111ll1l
def l1lll1(l11l11, l11l):
    import plistlib
    import os
    l11 = []
    l1lll = {}
    for l111lll1 in os.listdir(l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111lll1.startswith(l11l):
            try:
                l111111l = l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111lll1
                with open(l111111l, l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l11l = plist[l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111lll = version.split(l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l11 == l1111lll:
                        if not l1l11l in l1lll:
                            l1lll[l1l11l] = version
                        elif l1l1l1.l11ll(version, l1lll[l1l11l]) > 0:
                            l1lll[l1l11l] = version
            except BaseException:
                continue
    for l1l11l in l1lll:
        l11.append({l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll[l1l11l], l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l11l})
    return l11