#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1 = 7
def l1l1l1 (l111l):
    global l111ll
    l1111 = ord (l111l [-1])
    l1l11l = l111l [:-1]
    ll = l1111 % len (l1l11l)
    l11l11 = l1l11l [:ll] + l1l11l [ll:]
    if l1111l:
        l11lll = l1l111 () .join ([unichr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    return eval (l11lll)
import os
import re
import subprocess
import l111
from l111 import l1llll
def l111l1():
    return []
def l11l1l(l1l, l11ll):
    logger = l1llll()
    l11l1 = []
    l1l11 = [l1l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11l = process.wait()
            l1 = {}
            if l11l == 0:
                l1ll1l = re.compile(l1l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1ll = re.compile(l1l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll11 = re.search(l1ll1l, line)
                    l1l1l = l1ll11.group(1)
                    if l1l == l1l1l:
                        l1lll1 = re.search(l1l1ll, line)
                        if l1lll1:
                            l1lll = l1l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1lll1.group(1)
                            version = l1ll11.group(0)
                            if not l1lll in l1:
                                l1[l1lll] = version
                            elif l111.l1ll(version, l1[l1lll]) > 0:
                                l1[l1lll] = version
            for l1lll in l1:
                l11l1.append({l1l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1[l1lll], l1l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1lll})
        except Exception as e:
            logger.error(str(e))
    return l11l1