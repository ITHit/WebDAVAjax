#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1111 (l111ll):
    global l11ll1
    l1l1l = ord (l111ll [-1])
    l1 = l111ll [:-1]
    l1llll = l1l1l % len (l1)
    l111l = l1 [:l1llll] + l1 [l1llll:]
    if l11l1:
        l11l = l1ll11 () .join ([unichr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    return eval (l11l)
import subprocess, threading
from l1ll1 import l1l11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11ll11():
    l1l111ll = [l1111 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1111 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1111 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1111 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l111ll:
        try:
            l11ll1l1 = l1111 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll1l = winreg.l11l1l1l(winreg.l1l1111l, l11ll1l1)
        except l1l11l11:
            continue
        value = winreg.l11l11ll(l11lll1l, l1111 (u"ࠦࠧ࢓"))
        return value.split(l1111 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11111l():
    l11lllll = []
    for name in l1l1l111:
        try:
            l11ll1l1 = l1111 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll111 = winreg.l11l1l1l(winreg.l1l1111l, l11ll1l1)
            if winreg.l11l11ll(l11ll111, l1111 (u"ࠢࠣ࢖")):
                l11lllll.append(name)
        except l1l11l11:
            continue
    return l11lllll
def l1llllll(l111l1, l1l111):
    import re
    l1ll = []
    l11llll1 = winreg.l11l1l1l(winreg.l1l1111l, l1111 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll11l(l11llll1)[0]):
        try:
            l11l111l = winreg.l11l1ll1(l11llll1, i)
            if l11l111l.startswith(l1l111):
                l11ll1ll = winreg.l11l1l11(l11llll1, l11l111l)
                value, l1l11111 = winreg.l11l1lll(l11ll1ll, l1111 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1111 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1111 = {l1111 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll11 = m.group(2)
                    if l111l1 == l11lll11:
                        m = re.search(l1l111.replace(l1111 (u"ࠬ࠴࢛ࠧ"), l1111 (u"࠭࡜࡝࠰ࠪ࢜")) + l1111 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l111l)
                        l11l1111[l1111 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1ll.append(l11l1111)
                else:
                    raise ValueError(l1111 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11l11 as ex:
            continue
    return l1ll
def l1l111l1(l1lll):
    try:
        l1l11l1l = l1111 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1lll)
        l11l11l1 = winreg.l11l1l1l(winreg.l1l1111l, l1l11l1l)
        value, l1l11111 = winreg.l11l1lll(l11l11l1, l1111 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1111 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11l11:
        pass
    return l1111 (u"࠭ࠧࢣ")
def l1l1ll1(l1lll, url):
    threading.Thread(target=_1l11ll1,args=(l1lll, url)).start()
    return l1111 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11ll1(l1lll, url):
    logger = l1l11()
    l1l11lll = l1l111l1(l1lll)
    logger.debug(l1111 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11lll, url))
    retcode = subprocess.Popen(l1111 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11lll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1111 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1111 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)