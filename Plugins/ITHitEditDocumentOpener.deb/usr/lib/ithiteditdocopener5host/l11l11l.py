#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l11l1 = 2048
l1l1l1 = 7
def l11l (ll):
    global l1ll1
    l11l1l = ord (ll [-1])
    l11ll1 = ll [:-1]
    l1l11 = l11l1l % len (l11ll1)
    l11ll = l11ll1 [:l1l11] + l11ll1 [l1l11:]
    if l1l111:
        l111 = l1ll11 () .join ([unichr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    return eval (l111)
import l11lll
from l1l1l11l import l1l1l111
import objc as _111ll11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll11.l111111l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111111.l1111l11(l111l111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l (u"ࠨࠩࢬ"), {l11l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111ll1(l111l1l1):
    l111l1l1 = (l111l1l1 + l11l (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll1l = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l111ll1l, _111ll11.nil )
    l111llll = LaunchServices.l1111l1l( l11111ll, LaunchServices.l111lll1, _111ll11.nil )
    if l111llll[0] is not None:
        return True
    return False
def l111ll():
    l1111lll = []
    for name in l1l1l111:
        try:
            if l1111ll1(name):
                l1111lll.append(name)
        except:
            continue
    return l1111lll
def l1l11l(l1ll, l1111):
    import plistlib
    import os
    l111l = []
    l1lll = {}
    for l11111l1 in os.listdir(l11l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111l1.startswith(l1111):
            try:
                l111l1ll = l11l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111l1
                with open(l111l1ll, l11l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1lll1 = plist[l11l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l11l = version.split(l11l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll == l111l11l:
                        if not l1lll1 in l1lll:
                            l1lll[l1lll1] = version
                        elif l11lll.l1l1ll(version, l1lll[l1lll1]) > 0:
                            l1lll[l1lll1] = version
            except BaseException:
                continue
    for l1lll1 in l1lll:
        l111l.append({l11l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll[l1lll1], l11l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1lll1})
    return l111l