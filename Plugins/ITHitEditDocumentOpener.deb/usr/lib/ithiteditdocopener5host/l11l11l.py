#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll = sys.version_info [0] == 2
l111l1 = 2048
l1ll1 = 7
def l11ll1 (l1l1l1):
    global l1l11
    l111ll = ord (l1l1l1 [-1])
    l1l1l = l1l1l1 [:-1]
    l1 = l111ll % len (l1l1l)
    l1111 = l1l1l [:l1] + l1l1l [l1:]
    if l11lll:
        l1l11l = l111l () .join ([unichr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    return eval (l1l11l)
import l1111l
from l1l1l111 import l1l1l11l
import objc as _111l1ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1ll.l111llll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l11.l111l111(l1111ll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111ll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll1 (u"ࠨࠩࢬ"), {l11ll1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1l1(l111ll1l):
    l111ll1l = (l111ll1l + l11ll1 (u"ࠩ࠽ࠫࢴ")).encode()
    l11111ll = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l1111l1l = CFURLCreateWithString( kCFAllocatorDefault, l11111ll, _111l1ll.nil )
    l1111lll = LaunchServices.l111l11l( l1111l1l, LaunchServices.l1111111, _111l1ll.nil )
    if l1111lll[0] is not None:
        return True
    return False
def l11ll():
    l111111l = []
    for name in l1l1l11l:
        try:
            if l111l1l1(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l11(l11l11, l1l):
    import plistlib
    import os
    l1l111 = []
    l11l1l = {}
    for l11111l1 in os.listdir(l11ll1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111l1.startswith(l1l):
            try:
                l111lll1 = l11ll1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111l1
                with open(l111lll1, l11ll1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l111 = plist[l11ll1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll11 = version.split(l11ll1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l11 == l111ll11:
                        if not l111 in l11l1l:
                            l11l1l[l111] = version
                        elif l1111l.l1l1ll(version, l11l1l[l111]) > 0:
                            l11l1l[l111] = version
            except BaseException:
                continue
    for l111 in l11l1l:
        l1l111.append({l11ll1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l1l[l111], l11ll1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l111})
    return l1l111