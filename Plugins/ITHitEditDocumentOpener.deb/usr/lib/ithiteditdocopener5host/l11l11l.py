#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll = 2048
l111l = 7
def l1l1l (ll):
    global l11ll
    l1111 = ord (ll [-1])
    l1lll = ll [:-1]
    l1ll1l = l1111 % len (l1lll)
    l1l11 = l1lll [:l1ll1l] + l1lll [l1ll1l:]
    if l1l1l1:
        l1l = l111ll () .join ([unichr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    return eval (l1l)
import l11l
from l1l1l11l import l1l1l111
import objc as _111ll11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll11.l111ll1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l1l1.l111llll(l111111l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111111l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1l (u"ࠨࠩࢬ"), {l1l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111l11l):
    l111l11l = (l111l11l + l1l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l1l = CFStringCreateWithCString( kCFAllocatorDefault, l111l11l, kCFStringEncodingUTF8 )
    l111lll1 = CFURLCreateWithString( kCFAllocatorDefault, l1111l1l, _111ll11.nil )
    l1111l11 = LaunchServices.l111l111( l111lll1, LaunchServices.l11111ll, _111ll11.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l111l1():
    l11111l1 = []
    for name in l1l1l111:
        try:
            if l1111111(name):
                l11111l1.append(name)
        except:
            continue
    return l11111l1
def l1l1(l1111l, l1l11l):
    import plistlib
    import os
    l11 = []
    l1 = {}
    for l1111ll1 in os.listdir(l1l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111ll1.startswith(l1l11l):
            try:
                l111l1ll = l1l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111ll1
                with open(l111l1ll, l1l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l111 = plist[l1l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111lll = version.split(l1l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111l == l1111lll:
                        if not l1l111 in l1:
                            l1[l1l111] = version
                        elif l11l.l11l11(version, l1[l1l111]) > 0:
                            l1[l1l111] = version
            except BaseException:
                continue
    for l1l111 in l1:
        l11.append({l1l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1[l1l111], l1l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l111})
    return l11