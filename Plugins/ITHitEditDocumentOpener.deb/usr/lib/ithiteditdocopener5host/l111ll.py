#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll1 = 7
def l11l (l1l11l):
    global ll
    l1llll = ord (l1l11l [-1])
    l11l1 = l1l11l [:-1]
    l1l1 = l1llll % len (l11l1)
    l1lll = l11l1 [:l1l1] + l11l1 [l1l1:]
    if l1:
        l1l111 = l11lll () .join ([unichr (ord (char) - l1l1ll - (l1ll + l1llll) % l1ll1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1ll - (l1ll + l1llll) % l1ll1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l111)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11ll11(l1l111l=None):
    if platform.system() == l11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l11l1
        props = {}
        try:
            prop_names = (l11l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1llll1 = l1l11l1.l1lll11(l1l111l, l11l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111lll in prop_names:
                l111l1l = l11l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1llll1, l111lll)
                props[l111lll] = l1l11l1.l1lll11(l1l111l, l111l1l)
        except:
            pass
    return props
def l11llll(logger, l1l11ll):
    l11l1l1 = os.environ.get(l11l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l1l1 = l11l1l1.upper()
    if l11l1l1 == l11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111l1 = logging.DEBUG
    elif l11l1l1 == l11l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111l1 = logging.INFO
    elif l11l1l1 == l11l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111l1 = logging.WARNING
    elif l11l1l1 == l11l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111l1 = logging.ERROR
    elif l11l1l1 == l11l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111l1 = logging.CRITICAL
    elif l11l1l1 == l11l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111l1 = logging.NOTSET
    logger.setLevel(l1111l1)
    l11l111 = RotatingFileHandler(l1l11ll, maxBytes=1024*1024*5, backupCount=3)
    l11l111.setLevel(l1111l1)
    formatter = logging.Formatter(l11l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l111.setFormatter(formatter)
    logger.addHandler(l11l111)
    globals()[l11l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11ll1():
    return globals()[l11l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1llllll():
    if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111111
        l111111.l1l1111(sys.stdin.fileno(), os.l1lll1l)
        l111111.l1l1111(sys.stdout.fileno(), os.l1lll1l)
def l111l11(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    if platform.system() == l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1ll1ll
        return l1ll1ll.l111ll1()
    elif platform.system() == l11l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l11():
    if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1ll1ll
        return l1ll1ll.l1ll11l()
    elif platform.system() == l11l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l1l
        return l1l1l.l1l11()
    elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1l11
        return l1l1l11.l1l11()
    return l11l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1lll(l1ll11, l111):
    if platform.system() == l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1ll1ll
        return l1ll1ll.l1111ll(l1ll11, l111)
    elif platform.system() == l11l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1l11
        return l1l1l11.l111l(l1ll11, l111)
    elif platform.system() == l11l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l1l
        return l1l1l.l111l(l1ll11, l111)
    raise ValueError(l11l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11ll1l(l111l1, url):
    if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1ll1ll
        return l1ll1ll.l11111(l111l1, url)
    elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1l11
        return l11l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l1l
        return l11l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll111():
    if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1ll1ll
        return l1ll1ll.l1ll111()
def l1lllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1ll1(l1l):
    l11l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111l = l11l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l:
        if l11l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111l[3:]) < int(protocol[l11l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111l = protocol[l11l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111l
def l1ll1l(l11lll1, l11l1ll):
    l11l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11lll1 is None: l11lll1 = l11l (u"ࠩ࠳ࠫ࠽");
    if l11l1ll is None: l11l1ll = l11l (u"ࠪ࠴ࠬ࠾");
    l1l1l1l = l11lll1.split(l11l (u"ࠫ࠳࠭࠿"))
    l11l11l = l11l1ll.split(l11l (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1l1l) < len(l11l11l): l1l1l1l.append(l11l (u"ࠨ࠰ࠣࡁ"));
    while len(l11l11l) < len(l1l1l1l): l11l11l.append(l11l (u"ࠢ࠱ࠤࡂ"));
    l1l1l1l = [ int(x) for x in l1l1l1l ]
    l11l11l = [ int(x) for x in l11l11l ]
    for  i in range(len(l1l1l1l)):
        if len(l11l11l) == i:
            return 1
        if l1l1l1l[i] == l11l11l[i]:
            continue
        elif l1l1l1l[i] > l11l11l[i]:
            return 1
        else:
            return -1
    if len(l1l1l1l) != len(l11l11l):
        return -1
    return 0