#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11l1l = 2048
l11l1 = 7
def l111l1 (l1l11l):
    global l11
    ll = ord (l1l11l [-1])
    l1ll = l1l11l [:-1]
    l1111 = ll % len (l1ll)
    l11ll = l1ll [:l1111] + l1ll [l1111:]
    if l1ll1:
        l11lll = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    return eval (l11lll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11llll(l1l1lll=None):
    if platform.system() == l111l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1lll1l
        props = {}
        try:
            prop_names = (l111l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1111 = l1lll1l.l11l1l1(l1l1lll, l111l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1llllll in prop_names:
                l111ll1 = l111l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1111, l1llllll)
                props[l1llllll] = l1lll1l.l11l1l1(l1l1lll, l111ll1)
        except:
            pass
    return props
def l11ll1l(logger, l1111ll):
    l111l11 = os.environ.get(l111l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l11 = l111l11.upper()
    if l111l11 == l111l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1l11 = logging.DEBUG
    elif l111l11 == l111l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1l11 = logging.INFO
    elif l111l11 == l111l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1l11 = logging.WARNING
    elif l111l11 == l111l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1l11 = logging.ERROR
    elif l111l11 == l111l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1l11 = logging.CRITICAL
    elif l111l11 == l111l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1l11 = logging.NOTSET
    logger.setLevel(l1l1l11)
    l1lllll = RotatingFileHandler(l1111ll, maxBytes=1024*1024*5, backupCount=3)
    l1lllll.setLevel(l1l1l11)
    formatter = logging.Formatter(l111l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lllll.setFormatter(formatter)
    logger.addHandler(l1lllll)
    globals()[l111l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l11():
    return globals()[l111l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l1l():
    if platform.system() == l111l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll11l
        l1ll11l.l11111(sys.stdin.fileno(), os.l11111l)
        l1ll11l.l11111(sys.stdout.fileno(), os.l11111l)
def l1llll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111111():
    if platform.system() == l111l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11ll11
        return l11ll11.l1l11ll()
    elif platform.system() == l111l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll11():
    if platform.system() == l111l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11ll11
        return l11ll11.l1l11l1()
    elif platform.system() == l111l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l1
        return l1l1.l1ll11()
    elif platform.system() == l111l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1ll
        return l1ll1ll.l1ll11()
    return l111l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lll11(l1l111, l1):
    if platform.system() == l111l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11ll11
        return l11ll11.l1ll1l1(l1l111, l1)
    elif platform.system() == l111l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1ll
        return l1ll1ll.l11l(l1l111, l1)
    elif platform.system() == l111l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l1
        return l1l1.l11l(l1l111, l1)
    raise ValueError(l111l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111lll(l111l, url):
    if platform.system() == l111l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11ll11
        return l11ll11.l111l1l(l111l, url)
    elif platform.system() == l111l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1ll
        return l111l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l1
        return l111l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1111l1():
    if platform.system() == l111l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11ll11
        return l11ll11.l1111l1()
def l1l111l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1ll1(l1111l):
    l111l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l111 = l111l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1111l:
        if l111l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l111[3:]) < int(protocol[l111l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l111 = protocol[l111l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l111
def l1l11(l1ll111, l11lll1):
    l111l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll111 is None: l1ll111 = l111l1 (u"ࠩ࠳ࠫ࠽");
    if l11lll1 is None: l11lll1 = l111l1 (u"ࠪ࠴ࠬ࠾");
    l11l1ll = l1ll111.split(l111l1 (u"ࠫ࠳࠭࠿"))
    l11l11l = l11lll1.split(l111l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l11l1ll) < len(l11l11l): l11l1ll.append(l111l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l11l11l) < len(l11l1ll): l11l11l.append(l111l1 (u"ࠢ࠱ࠤࡂ"));
    l11l1ll = [ int(x) for x in l11l1ll ]
    l11l11l = [ int(x) for x in l11l11l ]
    for  i in range(len(l11l1ll)):
        if len(l11l11l) == i:
            return 1
        if l11l1ll[i] == l11l11l[i]:
            continue
        elif l11l1ll[i] > l11l11l[i]:
            return 1
        else:
            return -1
    if len(l11l1ll) != len(l11l11l):
        return -1
    return 0