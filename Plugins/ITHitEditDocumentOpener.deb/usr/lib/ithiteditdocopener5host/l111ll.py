#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1 = 2048
l111 = 7
def l1lll (l1l111):
    global l11l1l
    l1l = ord (l1l111 [-1])
    l11lll = l1l111 [:-1]
    l1ll1 = l1l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l1l1l:
        l1l1ll = l1ll11 () .join ([unichr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    return eval (l1l1ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1111l1(l1l11ll=None):
    if platform.system() == l1lll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11111l
        props = {}
        try:
            prop_names = (l1lll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1lll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1lll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1lll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1lll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1lll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1lll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1lll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1lll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1lll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1lll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1lll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11llll = l11111l.l111ll1(l1l11ll, l1lll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1ll11l in prop_names:
                l11lll1 = l1lll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11llll, l1ll11l)
                props[l1ll11l] = l11111l.l111ll1(l1l11ll, l11lll1)
        except:
            pass
    return props
def l1llll1(logger, l1111ll):
    l1ll1ll = os.environ.get(l1lll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1lll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1ll1ll = l1ll1ll.upper()
    if l1ll1ll == l1lll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11l1ll = logging.DEBUG
    elif l1ll1ll == l1lll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11l1ll = logging.INFO
    elif l1ll1ll == l1lll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11l1ll = logging.WARNING
    elif l1ll1ll == l1lll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11l1ll = logging.ERROR
    elif l1ll1ll == l1lll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11l1ll = logging.CRITICAL
    elif l1ll1ll == l1lll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11l1ll = logging.NOTSET
    logger.setLevel(l11l1ll)
    l111l11 = RotatingFileHandler(l1111ll, maxBytes=1024*1024*5, backupCount=3)
    l111l11.setLevel(l11l1ll)
    formatter = logging.Formatter(l1lll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111l11.setFormatter(formatter)
    logger.addHandler(l111l11)
    globals()[l1lll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1111():
    return globals()[l1lll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l11l():
    if platform.system() == l1lll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1lll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11ll1l
        l11ll1l.l1l11l1(sys.stdin.fileno(), os.l1l1l11)
        l11ll1l.l1l11l1(sys.stdout.fileno(), os.l1l1l11)
def l1l1lll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1lll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    if platform.system() == l1lll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111l1l
        return l111l1l.l111lll()
    elif platform.system() == l1lll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1lll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll():
    if platform.system() == l1lll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111l1l
        return l111l1l.l1ll111()
    elif platform.system() == l1lll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l1ll()
    elif platform.system() == l1lll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1lll1l
        return l1lll1l.l1ll()
    return l1lll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l1l(l11ll1, l111l1):
    if platform.system() == l1lll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111l1l
        return l111l1l.l1l1111(l11ll1, l111l1)
    elif platform.system() == l1lll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1lll1l
        return l1lll1l.ll(l11ll1, l111l1)
    elif platform.system() == l1lll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.ll(l11ll1, l111l1)
    raise ValueError(l1lll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11ll11(l1lll1, url):
    if platform.system() == l1lll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111l1l
        return l111l1l.l1lll11(l1lll1, url)
    elif platform.system() == l1lll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1lll1l
        return l1lll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1lll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return l1lll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1lll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lllll():
    if platform.system() == l1lll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111l1l
        return l111l1l.l1lllll()
def l11l1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1lll (u"ࠩ࠱ࠫ࠶"))[0]
def l11111(l1111l):
    l1lll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1ll1 = l1lll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1111l:
        if l1lll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1ll1[3:]) < int(protocol[l1lll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1ll1 = protocol[l1lll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1ll1
def l1l11l(l1l111l, l11l111):
    l1lll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l111l is None: l1l111l = l1lll (u"ࠩ࠳ࠫ࠽");
    if l11l111 is None: l11l111 = l1lll (u"ࠪ࠴ࠬ࠾");
    l111111 = l1l111l.split(l1lll (u"ࠫ࠳࠭࠿"))
    l1llllll = l11l111.split(l1lll (u"ࠬ࠴ࠧࡀ"))
    while len(l111111) < len(l1llllll): l111111.append(l1lll (u"ࠨ࠰ࠣࡁ"));
    while len(l1llllll) < len(l111111): l1llllll.append(l1lll (u"ࠢ࠱ࠤࡂ"));
    l111111 = [ int(x) for x in l111111 ]
    l1llllll = [ int(x) for x in l1llllll ]
    for  i in range(len(l111111)):
        if len(l1llllll) == i:
            return 1
        if l111111[i] == l1llllll[i]:
            continue
        elif l111111[i] > l1llllll[i]:
            return 1
        else:
            return -1
    if len(l111111) != len(l1llllll):
        return -1
    return 0