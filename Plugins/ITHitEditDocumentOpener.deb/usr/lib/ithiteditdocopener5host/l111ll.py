#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l1l11l):
    global l11lll
    l1l1l = ord (l1l11l [-1])
    l1l11 = l1l11l [:-1]
    l11l = l1l1l % len (l1l11)
    l11l1 = l1l11 [:l11l] + l1l11 [l11l:]
    if l1l1l1:
        l1l1ll = l1lll1 () .join ([unichr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    return eval (l1l1ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l1ll1(l11llll=None):
    if platform.system() == l11l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111111
        props = {}
        try:
            prop_names = (l11l1l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l1l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l1l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l1l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l1l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l1l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l1l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l1l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l1l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l1l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l1l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11l11l = l111111.l11l111(l11llll, l11l1l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l1l1l in prop_names:
                l1ll11l = l11l1l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11l11l, l1l1l1l)
                props[l1l1l1l] = l111111.l11l111(l11llll, l1ll11l)
        except:
            pass
    return props
def l1ll1ll(logger, l1ll111):
    l11l1ll = os.environ.get(l11l1l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l1l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l1ll = l11l1ll.upper()
    if l11l1ll == l11l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11ll11 = logging.DEBUG
    elif l11l1ll == l11l1l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11ll11 = logging.INFO
    elif l11l1ll == l11l1l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11ll11 = logging.WARNING
    elif l11l1ll == l11l1l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11ll11 = logging.ERROR
    elif l11l1ll == l11l1l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11ll11 = logging.CRITICAL
    elif l11l1ll == l11l1l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11ll11 = logging.NOTSET
    logger.setLevel(l11ll11)
    l11lll1 = RotatingFileHandler(l1ll111, maxBytes=1024*1024*5, backupCount=3)
    l11lll1.setLevel(l11ll11)
    formatter = logging.Formatter(l11l1l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11lll1.setFormatter(formatter)
    logger.addHandler(l11lll1)
    globals()[l11l1l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1ll():
    return globals()[l11l1l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11111():
    if platform.system() == l11l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l1l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1111ll
        l1111ll.l1ll1l1(sys.stdin.fileno(), os.l1lll1l)
        l1111ll.l1ll1l1(sys.stdout.fileno(), os.l1lll1l)
def l1l1lll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l1l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll11():
    if platform.system() == l11l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l11ll
        return l1l11ll.l11l1l1()
    elif platform.system() == l11l1l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l1():
    if platform.system() == l11l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l11ll
        return l1l11ll.l1l11l1()
    elif platform.system() == l11l1l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1111l
        return l1111l.l1l1()
    elif platform.system() == l11l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111l1l
        return l111l1l.l1l1()
    return l11l1l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111lll(l1111, ll):
    if platform.system() == l11l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l11ll
        return l1l11ll.l11ll1l(l1111, ll)
    elif platform.system() == l11l1l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111l1l
        return l111l1l.l111l(l1111, ll)
    elif platform.system() == l11l1l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1111l
        return l1111l.l111l(l1111, ll)
    raise ValueError(l11l1l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l111l(l1, url):
    if platform.system() == l11l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l11ll
        return l1l11ll.l1llllll(l1, url)
    elif platform.system() == l11l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111l1l
        return l11l1l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l1l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1111l
        return l11l1l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11111l():
    if platform.system() == l11l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l11ll
        return l1l11ll.l11111l()
def l1l1l11(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l1l (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1111(l1l111):
    l11l1l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111l11 = l11l1l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l111:
        if l11l1l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111l11[3:]) < int(protocol[l11l1l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111l11 = protocol[l11l1l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111l11
def l11ll(l1111l1, l1lllll):
    l11l1l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1111l1 is None: l1111l1 = l11l1l (u"ࠩ࠳ࠫ࠽");
    if l1lllll is None: l1lllll = l11l1l (u"ࠪ࠴ࠬ࠾");
    l1llll1 = l1111l1.split(l11l1l (u"ࠫ࠳࠭࠿"))
    l111ll1 = l1lllll.split(l11l1l (u"ࠬ࠴ࠧࡀ"))
    while len(l1llll1) < len(l111ll1): l1llll1.append(l11l1l (u"ࠨ࠰ࠣࡁ"));
    while len(l111ll1) < len(l1llll1): l111ll1.append(l11l1l (u"ࠢ࠱ࠤࡂ"));
    l1llll1 = [ int(x) for x in l1llll1 ]
    l111ll1 = [ int(x) for x in l111ll1 ]
    for  i in range(len(l1llll1)):
        if len(l111ll1) == i:
            return 1
        if l1llll1[i] == l111ll1[i]:
            continue
        elif l1llll1[i] > l111ll1[i]:
            return 1
        else:
            return -1
    if len(l1llll1) != len(l111ll1):
        return -1
    return 0