#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1111 = 7
def l1l1l (l1111l):
    global l1l111
    l11lll = ord (l1111l [-1])
    l1l11l = l1111l [:-1]
    l1ll11 = l11lll % len (l1l11l)
    l11 = l1l11l [:l1ll11] + l1l11l [l1ll11:]
    if l1l1:
        l111ll = l1llll () .join ([unichr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    return eval (l111ll)
import l1l
from l1l1l111 import l1l1l11l
import objc as _1111l1l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111l1l.l111l1l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111111l.l111ll1l(l111llll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111llll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1l (u"ࠨࠩࢬ"), {l1l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111ll(l111ll11):
    l111ll11 = (l111ll11 + l1l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l11111l1 = CFStringCreateWithCString( kCFAllocatorDefault, l111ll11, kCFStringEncodingUTF8 )
    l111l1ll = CFURLCreateWithString( kCFAllocatorDefault, l11111l1, _1111l1l.nil )
    l111lll1 = LaunchServices.l111l11l( l111l1ll, LaunchServices.l1111lll, _1111l1l.nil )
    if l111lll1[0] is not None:
        return True
    return False
def l111l():
    l1111111 = []
    for name in l1l1l11l:
        try:
            if l11111ll(name):
                l1111111.append(name)
        except:
            continue
    return l1111111
def l1l11(l1lll, l1):
    import plistlib
    import os
    ll = []
    l11l = {}
    for l1111l11 in os.listdir(l1l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111l11.startswith(l1):
            try:
                l111l111 = l1l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111l11
                with open(l111l111, l1l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11ll = plist[l1l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111ll1 = version.split(l1l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1lll == l1111ll1:
                        if not l11ll in l11l:
                            l11l[l11ll] = version
                        elif l1l.l1ll(version, l11l[l11ll]) > 0:
                            l11l[l11ll] = version
            except BaseException:
                continue
    for l11ll in l11l:
        ll.append({l1l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l[l11ll], l1l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11ll})
    return ll