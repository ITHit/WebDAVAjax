#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1l = 7
def l11ll1 (ll):
    global l1l1
    l1l1ll = ord (ll [-1])
    l1ll11 = ll [:-1]
    l1l11 = l1l1ll % len (l1ll11)
    l11 = l1ll11 [:l1l11] + l1ll11 [l1l11:]
    if l11l1l:
        l1 = l11lll () .join ([unichr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    return eval (l1)
import l1111l
from l1l1l111 import l1l1l11l
import objc as _111l1l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1l1.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l1l.l11111ll(l1111111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll1 (u"ࠨࠩࢬ"), {l11ll1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l111(l111l11l):
    l111l11l = (l111l11l + l11ll1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll1l = CFStringCreateWithCString( kCFAllocatorDefault, l111l11l, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l111ll1l, _111l1l1.nil )
    l111ll11 = LaunchServices.l11111l1( l111111l, LaunchServices.l1111lll, _111l1l1.nil )
    if l111ll11[0] is not None:
        return True
    return False
def l1111():
    l1111l11 = []
    for name in l1l1l11l:
        try:
            if l111l111(name):
                l1111l11.append(name)
        except:
            continue
    return l1111l11
def l11l(l1l111, l1l):
    import plistlib
    import os
    l11ll = []
    l111l1 = {}
    for l111llll in os.listdir(l11ll1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l1l):
            try:
                l111l1ll = l11ll1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l111l1ll, l11ll1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll = plist[l11ll1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l11ll1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l111 == l111lll1:
                        if not l1ll in l111l1:
                            l111l1[l1ll] = version
                        elif l1111l.l111ll(version, l111l1[l1ll]) > 0:
                            l111l1[l1ll] = version
            except BaseException:
                continue
    for l1ll in l111l1:
        l11ll.append({l11ll1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111l1[l1ll], l11ll1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll})
    return l11ll