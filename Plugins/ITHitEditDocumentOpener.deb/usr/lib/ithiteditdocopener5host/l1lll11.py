#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1ll11 = 2048
l1111 = 7
def l1l (l1l1):
    global l11l1l
    l11ll = ord (l1l1 [-1])
    l1lll1 = l1l1 [:-1]
    l1111l = l11ll % len (l1lll1)
    l1l11l = l1lll1 [:l1111l] + l1lll1 [l1111l:]
    if l1l1l:
        l1lll = l1llll () .join ([unichr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    return eval (l1lll)
import l111ll
from l1l1l111 import l1l1l11l
import objc as _111111l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111111l.l1111l11( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l1111ll1(l111lll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111lll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l (u"ࠨࠩࢬ"), {l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l111(l111llll):
    l111llll = (l111llll + l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1ll = CFStringCreateWithCString( kCFAllocatorDefault, l111llll, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l111l1ll, _111111l.nil )
    l111l11l = LaunchServices.l11111ll( l1111111, LaunchServices.l1111lll, _111111l.nil )
    if l111l11l[0] is not None:
        return True
    return False
def l11():
    l111ll11 = []
    for name in l1l1l11l:
        try:
            if l111l111(name):
                l111ll11.append(name)
        except:
            continue
    return l111ll11
def l111(l1l111, l11l11):
    import plistlib
    import os
    l111l = []
    l11lll = {}
    for l111l1l1 in os.listdir(l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l11l11):
            try:
                l1111l1l = l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l1111l1l, l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11ll1 = plist[l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll1l = version.split(l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l111 == l111ll1l:
                        if not l11ll1 in l11lll:
                            l11lll[l11ll1] = version
                        elif l111ll.l11l(version, l11lll[l11ll1]) > 0:
                            l11lll[l11ll1] = version
            except BaseException:
                continue
    for l11ll1 in l11lll:
        l111l.append({l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11lll[l11ll1], l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11ll1})
    return l111l