#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l1l11l = 2048
l11l1l = 7
def l11l11 (l1l1l1):
    global l11ll
    l11 = ord (l1l1l1 [-1])
    l11lll = l1l1l1 [:-1]
    l1111 = l11 % len (l11lll)
    l1 = l11lll [:l1111] + l11lll [l1111:]
    if l1lll1:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    return eval (l1ll1l)
import subprocess, threading
from l1111l import l1ll11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l1ll():
    l1l11l11 = [l11l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11l11:
        try:
            l11ll11l = l11l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll111 = winreg.l11l1lll(winreg.l1l11ll1, l11ll11l)
        except l11l111l:
            continue
        value = winreg.l11lll11(l11ll111, l11l11 (u"ࠦࠧ࢓"))
        return value.split(l11l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111l1l():
    l11l1l11 = []
    for name in l1l1l11l:
        try:
            l11ll11l = l11l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lllll = winreg.l11l1lll(winreg.l1l11ll1, l11ll11l)
            if winreg.l11lll11(l11lllll, l11l11 (u"ࠢࠣ࢖")):
                l11l1l11.append(name)
        except l11l111l:
            continue
    return l11l1l11
def l111l11(l1l1ll, l1l11):
    import re
    l1ll = []
    l1l111ll = winreg.l11l1lll(winreg.l1l11ll1, l11l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11111(l1l111ll)[0]):
        try:
            l1l11l1l = winreg.l11l1ll1(l1l111ll, i)
            if l1l11l1l.startswith(l1l11):
                l11l1111 = winreg.l11ll1l1(l1l111ll, l1l11l1l)
                value, l11l11ll = winreg.l11l1l1l(l11l1111, l11l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111l1 = {l11l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll1ll = m.group(2)
                    if l1l1ll == l11ll1ll:
                        m = re.search(l1l11.replace(l11l11 (u"ࠬ࠴࢛ࠧ"), l11l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l11l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11l1l)
                        l1l111l1[l11l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1ll.append(l1l111l1)
                else:
                    raise ValueError(l11l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l1ll
def l11lll1l(l11l):
    try:
        l11l11l1 = l11l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l)
        l1l11lll = winreg.l11l1lll(winreg.l1l11ll1, l11l11l1)
        value, l11l11ll = winreg.l11l1l1l(l1l11lll, l11l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l11 (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l11l11 (u"࠭ࠧࢣ")
def l1l11ll(l11l, url):
    threading.Thread(target=_1l1111l,args=(l11l, url)).start()
    return l11l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l1111l(l11l, url):
    logger = l1ll11()
    l11llll1 = l11lll1l(l11l)
    logger.debug(l11l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11llll1, url))
    retcode = subprocess.Popen(l11l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11llll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)