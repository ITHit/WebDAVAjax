#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll1l = 7
def l1111 (l111ll):
    global l11l11
    l1l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l1l1 % len (l1llll)
    l1111l = l1llll [:l11l] + l1llll [l11l:]
    if l1:
        l1lll = l11ll () .join ([unichr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    return eval (l1lll)
import subprocess, threading
from l11ll1 import l1l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1ll111():
    l11l1l1l = [l1111 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1111 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1111 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1111 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1l1l:
        try:
            l1l11l1l = l1111 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11111 = winreg.l1l11ll1(winreg.l1l111ll, l1l11l1l)
        except l11l1ll1:
            continue
        value = winreg.l11llll1(l1l11111, l1111 (u"ࠦࠧ࢓"))
        return value.split(l1111 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1llll1():
    l1l1111l = []
    for name in l1l1l111:
        try:
            l1l11l1l = l1111 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1l1 = winreg.l1l11ll1(winreg.l1l111ll, l1l11l1l)
            if winreg.l11llll1(l11ll1l1, l1111 (u"ࠢࠣ࢖")):
                l1l1111l.append(name)
        except l11l1ll1:
            continue
    return l1l1111l
def l1ll1l1(l111l, l1l1l1):
    import re
    l1ll11 = []
    l11l1111 = winreg.l1l11ll1(winreg.l1l111ll, l1111 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll11l(l11l1111)[0]):
        try:
            l11l1lll = winreg.l11l1l11(l11l1111, i)
            if l11l1lll.startswith(l1l1l1):
                l1l111l1 = winreg.l11ll111(l11l1111, l11l1lll)
                value, l11lllll = winreg.l1l11l11(l1l111l1, l1111 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1111 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11lll = {l1111 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l111l = m.group(2)
                    if l111l == l11l111l:
                        m = re.search(l1l1l1.replace(l1111 (u"ࠬ࠴࢛ࠧ"), l1111 (u"࠭࡜࡝࠰ࠪ࢜")) + l1111 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1lll)
                        l1l11lll[l1111 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1ll11.append(l1l11lll)
                else:
                    raise ValueError(l1111 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1ll1 as ex:
            continue
    return l1ll11
def l11lll1l(l1ll):
    try:
        l11lll11 = l1111 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll)
        l11ll1ll = winreg.l1l11ll1(winreg.l1l111ll, l11lll11)
        value, l11lllll = winreg.l1l11l11(l11ll1ll, l1111 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1111 (u"ࠬࠨࠧࢢ"))[1]
    except l11l1ll1:
        pass
    return l1111 (u"࠭ࠧࢣ")
def l1l1ll1(l1ll, url):
    threading.Thread(target=_11l11ll,args=(l1ll, url)).start()
    return l1111 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l11ll(l1ll, url):
    logger = l1l()
    l11l11l1 = l11lll1l(l1ll)
    logger.debug(l1111 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11l1, url))
    retcode = subprocess.Popen(l1111 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1111 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1111 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)