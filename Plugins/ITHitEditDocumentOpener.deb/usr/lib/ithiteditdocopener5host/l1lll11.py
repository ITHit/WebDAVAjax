#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l11ll = 2048
l111 = 7
def l1111l (l1l1):
    global l11l
    l1ll1l = ord (l1l1 [-1])
    l1l11 = l1l1 [:-1]
    l1lll1 = l1ll1l % len (l1l11)
    l111ll = l1l11 [:l1lll1] + l1l11 [l1lll1:]
    if l1l:
        l11l11 = l11ll1 () .join ([unichr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    return eval (l11l11)
import l11l1l
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1111l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l1ll.l111llll(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1111l (u"ࠨࠩࢬ"), {l1111l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1111l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1111l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1111l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1111l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1111l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1111l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l111(l1111l11):
    l1111l11 = (l1111l11 + l1111l (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1l1 = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l111l1l1, _1111ll1.nil )
    l111111l = LaunchServices.l1111l1l( l111ll11, LaunchServices.l11111l1, _1111ll1.nil )
    if l111111l[0] is not None:
        return True
    return False
def l1ll11():
    l111ll1l = []
    for name in l1l1l111:
        try:
            if l111l111(name):
                l111ll1l.append(name)
        except:
            continue
    return l111ll1l
def ll(l111l, l1l1ll):
    import plistlib
    import os
    l1l1l1 = []
    l1llll = {}
    for l1111111 in os.listdir(l1111l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111111.startswith(l1l1ll):
            try:
                l111l11l = l1111l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111111
                with open(l111l11l, l1111l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l111 = plist[l1111l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1111l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1111l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l1111l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111l == l111lll1:
                        if not l1l111 in l1llll:
                            l1llll[l1l111] = version
                        elif l11l1l.l1ll(version, l1llll[l1l111]) > 0:
                            l1llll[l1l111] = version
            except BaseException:
                continue
    for l1l111 in l1llll:
        l1l1l1.append({l1111l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1llll[l1l111], l1111l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l111})
    return l1l1l1