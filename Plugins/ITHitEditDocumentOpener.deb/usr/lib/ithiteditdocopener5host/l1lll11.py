#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11lll = 2048
l1l1 = 7
def l11 (l1l11):
    global l1l11l
    l1111 = ord (l1l11 [-1])
    l1ll1 = l1l11 [:-1]
    l1ll = l1111 % len (l1ll1)
    l1llll = l1ll1 [:l1ll] + l1ll1 [l1ll:]
    if l11ll1:
        l1 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    else:
        l1 = str () .join ([chr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    return eval (l1)
import l11l1l
from l1l1l11l import l1l1l111
import objc as _111lll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111lll1.l111ll1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111llll.l111l111(l11111l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11 (u"ࠨࠩࢬ"), {l11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l111l1l1):
    l111l1l1 = (l111l1l1 + l11 (u"ࠩ࠽ࠫࢴ")).encode()
    l111l11l = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l111l1ll = CFURLCreateWithString( kCFAllocatorDefault, l111l11l, _111lll1.nil )
    l1111lll = LaunchServices.l1111111( l111l1ll, LaunchServices.l111ll11, _111lll1.nil )
    if l1111lll[0] is not None:
        return True
    return False
def l1l1l1():
    l1111l11 = []
    for name in l1l1l111:
        try:
            if l1111l1l(name):
                l1111l11.append(name)
        except:
            continue
    return l1111l11
def l1l1ll(l11ll, l1ll1l):
    import plistlib
    import os
    l11l = []
    l1l = {}
    for l1111ll1 in os.listdir(l11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111ll1.startswith(l1ll1l):
            try:
                l11111ll = l11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111ll1
                with open(l11111ll, l11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l111 = plist[l11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111111l = version.split(l11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11ll == l111111l:
                        if not l1l111 in l1l:
                            l1l[l1l111] = version
                        elif l11l1l.l111l(version, l1l[l1l111]) > 0:
                            l1l[l1l111] = version
            except BaseException:
                continue
    for l1l111 in l1l:
        l11l.append({l11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l[l1l111], l11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l111})
    return l11l