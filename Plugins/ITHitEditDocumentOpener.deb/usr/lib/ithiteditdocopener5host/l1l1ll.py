#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll11 = 2048
l111ll = 7
def l11ll (l11l11):
    global l1111
    l11l1 = ord (l11l11 [-1])
    l1 = l11l11 [:-1]
    ll = l11l1 % len (l1)
    l1ll1 = l1 [:ll] + l1 [ll:]
    if l1l1l1:
        l11l1l = l1l11l () .join ([unichr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    return eval (l11l1l)
import os
import re
import subprocess
import l11l
from l11l import l111l
def l1l11():
    return []
def l1lll1(l11ll1, l111):
    logger = l111l()
    l1l111 = []
    l1l = [l11ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l:
        try:
            output = os.popen(cmd).read()
            l1111l = 0
            l1llll = {}
            if l1111l == 0:
                l1l1 = re.compile(l11ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11lll = re.compile(l11ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll1l = re.search(l1l1, line)
                    l1l1l = l1ll1l.group(1)
                    if l11ll1 == l1l1l:
                        l11 = re.search(l11lll, line)
                        if l11:
                            l1ll = l11ll (u"ࠨࡦࡤࡺࠬࠄ")+l11.group(1)
                            version = l1ll1l.group(0)
                            if not l1ll in l1llll:
                                l1llll[l1ll] = version
                            elif l11l.l111l1(version, l1llll[l1ll]) > 0:
                                l1llll[l1ll] = version
            for l1ll in l1llll:
                l1l111.append({l11ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1llll[l1ll], l11ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll})
        except Exception as e:
            logger.error(str(e))
    return l1l111