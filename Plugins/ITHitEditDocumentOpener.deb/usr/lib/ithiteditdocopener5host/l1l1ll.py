#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1l111 = 2048
l11ll1 = 7
def l1l1 (l11):
    global l1ll11
    l1llll = ord (l11 [-1])
    l1ll1 = l11 [:-1]
    l111l = l1llll % len (l1ll1)
    l1111l = l1ll1 [:l111l] + l1ll1 [l111l:]
    if l1l1l1:
        ll = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    else:
        ll = str () .join ([chr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    return eval (ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11lll1(l11llll=None):
    if platform.system() == l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11111l
        props = {}
        try:
            prop_names = (l1l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111 = l11111l.l111l11(l11llll, l1l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1l1 in prop_names:
                l1lllll = l1l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111, l11l1l1)
                props[l11l1l1] = l11111l.l111l11(l11llll, l1lllll)
        except:
            pass
    return props
def l1ll11l(logger, l111l1l):
    l111lll = os.environ.get(l1l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111lll = l111lll.upper()
    if l111lll == l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1l11 = logging.DEBUG
    elif l111lll == l1l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1l11 = logging.INFO
    elif l111lll == l1l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1l11 = logging.WARNING
    elif l111lll == l1l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1l11 = logging.ERROR
    elif l111lll == l1l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1l11 = logging.CRITICAL
    elif l111lll == l1l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1l11 = logging.NOTSET
    logger.setLevel(l1l1l11)
    l1ll111 = RotatingFileHandler(l111l1l, maxBytes=1024*1024*5, backupCount=3)
    l1ll111.setLevel(l1l1l11)
    formatter = logging.Formatter(l1l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll111.setFormatter(formatter)
    logger.addHandler(l1ll111)
    globals()[l1l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11lll():
    return globals()[l1l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1lll11():
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111111
        l111111.l1ll1l1(sys.stdin.fileno(), os.l1lll1l)
        l111111.l1ll1l1(sys.stdout.fileno(), os.l1lll1l)
def l11l111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llllll():
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l11ll
        return l1l11ll.l11ll11()
    elif platform.system() == l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l11ll
        return l1l11ll.l1111ll()
    elif platform.system() == l1l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l11
        return l1l11.l11l()
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1ll
        return l1ll1ll.l11l()
    return l1l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l111l(l11l1l, l1):
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l11ll
        return l1l11ll.l11l1ll(l11l1l, l1)
    elif platform.system() == l1l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1ll
        return l1ll1ll.l11l11(l11l1l, l1)
    elif platform.system() == l1l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l11
        return l1l11.l11l11(l11l1l, l1)
    raise ValueError(l1l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11ll1l(l1l, url):
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l11ll
        return l1l11ll.l1l1ll1(l1l, url)
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1ll
        return l1l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l11
        return l1l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l1l1l():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l11ll
        return l1l11ll.l1l1l1l()
def l1l11l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1llll1(l111):
    l1l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l11l = l1l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111:
        if l1l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l11l[3:]) < int(protocol[l1l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l11l = protocol[l1l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l11l
def l1ll(l1l1lll, l111ll1):
    l1l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1lll is None: l1l1lll = l1l1 (u"ࠩ࠳ࠫ࠽");
    if l111ll1 is None: l111ll1 = l1l1 (u"ࠪ࠴ࠬ࠾");
    l1111l1 = l1l1lll.split(l1l1 (u"ࠫ࠳࠭࠿"))
    l1l1111 = l111ll1.split(l1l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l1111l1) < len(l1l1111): l1111l1.append(l1l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1111) < len(l1111l1): l1l1111.append(l1l1 (u"ࠢ࠱ࠤࡂ"));
    l1111l1 = [ int(x) for x in l1111l1 ]
    l1l1111 = [ int(x) for x in l1l1111 ]
    for  i in range(len(l1111l1)):
        if len(l1l1111) == i:
            return 1
        if l1111l1[i] == l1l1111[i]:
            continue
        elif l1111l1[i] > l1l1111[i]:
            return 1
        else:
            return -1
    if len(l1111l1) != len(l1l1111):
        return -1
    return 0