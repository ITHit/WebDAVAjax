#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1l = 7
def l1ll (l1):
    global l111l1
    l1l = ord (l1 [-1])
    ll = l1 [:-1]
    l111l = l1l % len (ll)
    l11ll = ll [:l111l] + ll [l111l:]
    if l1ll1:
        l1ll11 = l1l111 () .join ([unichr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    return eval (l1ll11)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11l11l(l1ll111=None):
    if platform.system() == l1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111lll
        props = {}
        try:
            prop_names = (l1ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1ll11l = l111lll.l1l1ll1(l1ll111, l1ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111ll1 in prop_names:
                l1llll1 = l1ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1ll11l, l111ll1)
                props[l111ll1] = l111lll.l1l1ll1(l1ll111, l1llll1)
        except:
            pass
    return props
def l11ll11(logger, l1l11ll):
    l11ll1l = os.environ.get(l1ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11ll1l = l11ll1l.upper()
    if l11ll1l == l1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111l1 = logging.DEBUG
    elif l11ll1l == l1ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111l1 = logging.INFO
    elif l11ll1l == l1ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111l1 = logging.WARNING
    elif l11ll1l == l1ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111l1 = logging.ERROR
    elif l11ll1l == l1ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111l1 = logging.CRITICAL
    elif l11ll1l == l1ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111l1 = logging.NOTSET
    logger.setLevel(l1111l1)
    l11l111 = RotatingFileHandler(l1l11ll, maxBytes=1024*1024*5, backupCount=3)
    l11l111.setLevel(l1111l1)
    formatter = logging.Formatter(l1ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l111.setFormatter(formatter)
    logger.addHandler(l11l111)
    globals()[l1ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l11():
    return globals()[l1ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l11():
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11llll
        l11llll.l111l11(sys.stdin.fileno(), os.l111l1l)
        l11llll.l111l11(sys.stdout.fileno(), os.l111l1l)
def l1l11l1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111111():
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11111l
        return l11111l.l1llllll()
    elif platform.system() == l1ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11lll():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11111l
        return l11111l.l1111ll()
    elif platform.system() == l1ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1111
        return l1111.l11lll()
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1111
        return l1l1111.l11lll()
    return l1ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1ll1ll(l1lll, l11l):
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11111l
        return l11111l.l1lllll(l1lll, l11l)
    elif platform.system() == l1ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1111
        return l1l1111.l11ll1(l1lll, l11l)
    elif platform.system() == l1ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1111
        return l1111.l11ll1(l1lll, l11l)
    raise ValueError(l1ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l1l1(l11l1, url):
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11111l
        return l11111l.l1lll1l(l11l1, url)
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1111
        return l1ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1111
        return l1ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l111l():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11111l
        return l11111l.l1l111l()
def l11l1ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1lll11(l111):
    l1ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111 = l1ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111:
        if l1ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111[3:]) < int(protocol[l1ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111 = protocol[l1ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111
def l1111l(l11lll1, l1l1lll):
    l1ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11lll1 is None: l11lll1 = l1ll (u"ࠩ࠳ࠫ࠽");
    if l1l1lll is None: l1l1lll = l1ll (u"ࠪ࠴ࠬ࠾");
    l1ll1l1 = l11lll1.split(l1ll (u"ࠫ࠳࠭࠿"))
    l1l1l1l = l1l1lll.split(l1ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll1l1) < len(l1l1l1l): l1ll1l1.append(l1ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1l1l) < len(l1ll1l1): l1l1l1l.append(l1ll (u"ࠢ࠱ࠤࡂ"));
    l1ll1l1 = [ int(x) for x in l1ll1l1 ]
    l1l1l1l = [ int(x) for x in l1l1l1l ]
    for  i in range(len(l1ll1l1)):
        if len(l1l1l1l) == i:
            return 1
        if l1ll1l1[i] == l1l1l1l[i]:
            continue
        elif l1ll1l1[i] > l1l1l1l[i]:
            return 1
        else:
            return -1
    if len(l1ll1l1) != len(l1l1l1l):
        return -1
    return 0