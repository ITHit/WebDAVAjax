#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l1llll = 2048
l1l11 = 7
def l1ll1 (l1ll11):
    global l1l1l1
    l1111 = ord (l1ll11 [-1])
    ll = l1ll11 [:-1]
    l111l = l1111 % len (ll)
    l11l1l = ll [:l111l] + ll [l111l:]
    if l1l1:
        l11l = l111ll () .join ([unichr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    return eval (l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11ll11(l1l111l=None):
    if platform.system() == l1ll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l1ll1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111l = l1l1lll.l111lll(l1l111l, l1ll1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l111 in prop_names:
                l111l1l = l1ll1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111l, l11l111)
                props[l11l111] = l1l1lll.l111lll(l1l111l, l111l1l)
        except:
            pass
    return props
def l11111(logger, l1l11l1):
    l1111l1 = os.environ.get(l1ll1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1111l1 = l1111l1.upper()
    if l1111l1 == l1ll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1ll1ll = logging.DEBUG
    elif l1111l1 == l1ll1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1ll1ll = logging.INFO
    elif l1111l1 == l1ll1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1ll1ll = logging.WARNING
    elif l1111l1 == l1ll1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1ll1ll = logging.ERROR
    elif l1111l1 == l1ll1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1ll1ll = logging.CRITICAL
    elif l1111l1 == l1ll1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1ll1ll = logging.NOTSET
    logger.setLevel(l1ll1ll)
    l1ll11l = RotatingFileHandler(l1l11l1, maxBytes=1024*1024*5, backupCount=3)
    l1ll11l.setLevel(l1ll1ll)
    formatter = logging.Formatter(l1ll1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll11l.setFormatter(formatter)
    logger.addHandler(l1ll11l)
    globals()[l1ll1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1lll():
    return globals()[l1ll1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l1l():
    if platform.system() == l1ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11lll1
        l11lll1.l1llllll(sys.stdin.fileno(), os.l1l1111)
        l11lll1.l1llllll(sys.stdout.fileno(), os.l1l1111)
def l11llll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1111ll():
    if platform.system() == l1ll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111l11
        return l111l11.l1lll1l()
    elif platform.system() == l1ll1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l1():
    if platform.system() == l1ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111l11
        return l111l11.l1l1ll1()
    elif platform.system() == l1ll1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l111
        return l1l111.l11l1()
    elif platform.system() == l1ll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111ll1
        return l111ll1.l11l1()
    return l1ll1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111111(l1l11l, l1l):
    if platform.system() == l1ll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111l11
        return l111l11.l1lll11(l1l11l, l1l)
    elif platform.system() == l1ll1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111ll1
        return l111ll1.l111l1(l1l11l, l1l)
    elif platform.system() == l1ll1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l111
        return l1l111.l111l1(l1l11l, l1l)
    raise ValueError(l1ll1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11ll1l(l11lll, url):
    if platform.system() == l1ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111l11
        return l111l11.l1l1l11(l11lll, url)
    elif platform.system() == l1ll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111ll1
        return l1ll1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l111
        return l1ll1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lllll():
    if platform.system() == l1ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111l11
        return l111l11.l1lllll()
def l11l1ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1llll1(l1lll1):
    l1ll1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l11ll = l1ll1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1lll1:
        if l1ll1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l11ll[3:]) < int(protocol[l1ll1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l11ll = protocol[l1ll1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l11ll
def l11ll1(l11l11l, l11l1l1):
    l1ll1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l11l is None: l11l11l = l1ll1 (u"ࠩ࠳ࠫ࠽");
    if l11l1l1 is None: l11l1l1 = l1ll1 (u"ࠪ࠴ࠬ࠾");
    l1ll111 = l11l11l.split(l1ll1 (u"ࠫ࠳࠭࠿"))
    l1ll1l1 = l11l1l1.split(l1ll1 (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll111) < len(l1ll1l1): l1ll111.append(l1ll1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1ll1l1) < len(l1ll111): l1ll1l1.append(l1ll1 (u"ࠢ࠱ࠤࡂ"));
    l1ll111 = [ int(x) for x in l1ll111 ]
    l1ll1l1 = [ int(x) for x in l1ll1l1 ]
    for  i in range(len(l1ll111)):
        if len(l1ll1l1) == i:
            return 1
        if l1ll111[i] == l1ll1l1[i]:
            continue
        elif l1ll111[i] > l1ll1l1[i]:
            return 1
        else:
            return -1
    if len(l1ll111) != len(l1ll1l1):
        return -1
    return 0