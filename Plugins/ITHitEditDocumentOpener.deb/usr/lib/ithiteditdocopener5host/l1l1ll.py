#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1lll = 7
def l1l1 (l1lll1):
    global l1l1l
    l111ll = ord (l1lll1 [-1])
    l11l = l1lll1 [:-1]
    l111 = l111ll % len (l11l)
    l1l11l = l11l [:l111] + l11l [l111:]
    if l1llll:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import os
import re
import subprocess
import l1l11
from l1l11 import l11
def l1():
    return []
def l1l(l11lll, l1l1l1):
    logger = l11()
    l11l1 = []
    l1111l = [l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1111l:
        try:
            output = os.popen(cmd).read()
            l1l111 = 0
            l1ll1 = {}
            if l1l111 == 0:
                l111l1 = re.compile(l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll = re.compile(l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1111 = re.search(l111l1, line)
                    l11ll1 = l1111.group(1)
                    if l11lll == l11ll1:
                        l1ll11 = re.search(l11ll, line)
                        if l1ll11:
                            l11l1l = l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1ll11.group(1)
                            version = l1111.group(0)
                            if not l11l1l in l1ll1:
                                l1ll1[l11l1l] = version
                            elif l1l11.ll(version, l1ll1[l11l1l]) > 0:
                                l1ll1[l11l1l] = version
            for l11l1l in l1ll1:
                l11l1.append({l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1[l11l1l], l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1l})
        except Exception as e:
            logger.error(str(e))
    return l11l1