#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1111l = 2048
l1ll = 7
def l1l11l (l1):
    global l11l11
    l111l1 = ord (l1 [-1])
    l1llll = l1 [:-1]
    l1ll11 = l111l1 % len (l1llll)
    l1l1ll = l1llll [:l1ll11] + l1llll [l1ll11:]
    if l111ll:
        l11l1 = l1l () .join ([unichr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    return eval (l11l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11l11l(l1ll1ll=None):
    if platform.system() == l1l11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1lllll
        props = {}
        try:
            prop_names = (l1l11l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l11l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l11l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l11l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l11l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l11l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l11l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l11l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l11l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l11l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l11l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l11ll = l1lllll.l11llll(l1ll1ll, l1l11l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l1l1l in prop_names:
                l1111l1 = l1l11l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l11ll, l1l1l1l)
                props[l1l1l1l] = l1lllll.l11llll(l1ll1ll, l1111l1)
        except:
            pass
    return props
def l1l1111(logger, l1111ll):
    l111l11 = os.environ.get(l1l11l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l11l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l11 = l111l11.upper()
    if l111l11 == l1l11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1lll1l = logging.DEBUG
    elif l111l11 == l1l11l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1lll1l = logging.INFO
    elif l111l11 == l1l11l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1lll1l = logging.WARNING
    elif l111l11 == l1l11l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1lll1l = logging.ERROR
    elif l111l11 == l1l11l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1lll1l = logging.CRITICAL
    elif l111l11 == l1l11l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1lll1l = logging.NOTSET
    logger.setLevel(l1lll1l)
    l111111 = RotatingFileHandler(l1111ll, maxBytes=1024*1024*5, backupCount=3)
    l111111.setLevel(l1lll1l)
    formatter = logging.Formatter(l1l11l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111111.setFormatter(formatter)
    logger.addHandler(l111111)
    globals()[l1l11l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1lll():
    return globals()[l1l11l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1llll1():
    if platform.system() == l1l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l11l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1ll1
        l1l1ll1.l111lll(sys.stdin.fileno(), os.l1l11l1)
        l1l1ll1.l111lll(sys.stdout.fileno(), os.l1l11l1)
def l11111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l11l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l111l():
    if platform.system() == l1l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l1ll
        return l11l1ll.l11ll11()
    elif platform.system() == l1l11l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l1l1():
    if platform.system() == l1l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l1ll
        return l11l1ll.l1l1l11()
    elif platform.system() == l1l11l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import ll
        return ll.l1l1l1()
    elif platform.system() == l1l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll111
        return l1ll111.l1l1l1()
    return l1l11l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1ll11l(l1lll1, l1ll1):
    if platform.system() == l1l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l1ll
        return l11l1ll.l111l1l(l1lll1, l1ll1)
    elif platform.system() == l1l11l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll111
        return l1ll111.l1l11(l1lll1, l1ll1)
    elif platform.system() == l1l11l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import ll
        return ll.l1l11(l1lll1, l1ll1)
    raise ValueError(l1l11l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11111l(l11ll, url):
    if platform.system() == l1l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l1ll
        return l11l1ll.l11l111(l11ll, url)
    elif platform.system() == l1l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll111
        return l1l11l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l11l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import ll
        return l1l11l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll1l1():
    if platform.system() == l1l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l1ll
        return l11l1ll.l1ll1l1()
def l1l1lll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l11l (u"ࠩ࠱ࠫ࠶"))[0]
def l11ll1l(l1l111):
    l1l11l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1llllll = l1l11l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l111:
        if l1l11l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1llllll[3:]) < int(protocol[l1l11l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1llllll = protocol[l1l11l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1llllll
def l11lll(l11l1l1, l111ll1):
    l1l11l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l1l1 is None: l11l1l1 = l1l11l (u"ࠩ࠳ࠫ࠽");
    if l111ll1 is None: l111ll1 = l1l11l (u"ࠪ࠴ࠬ࠾");
    l1lll11 = l11l1l1.split(l1l11l (u"ࠫ࠳࠭࠿"))
    l11lll1 = l111ll1.split(l1l11l (u"ࠬ࠴ࠧࡀ"))
    while len(l1lll11) < len(l11lll1): l1lll11.append(l1l11l (u"ࠨ࠰ࠣࡁ"));
    while len(l11lll1) < len(l1lll11): l11lll1.append(l1l11l (u"ࠢ࠱ࠤࡂ"));
    l1lll11 = [ int(x) for x in l1lll11 ]
    l11lll1 = [ int(x) for x in l11lll1 ]
    for  i in range(len(l1lll11)):
        if len(l11lll1) == i:
            return 1
        if l1lll11[i] == l11lll1[i]:
            continue
        elif l1lll11[i] > l11lll1[i]:
            return 1
        else:
            return -1
    if len(l1lll11) != len(l11lll1):
        return -1
    return 0