#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1 = 2048
l1111 = 7
def l11ll (l1ll1l):
    global l11ll1
    l11l1 = ord (l1ll1l [-1])
    l1l = l1ll1l [:-1]
    l1l1ll = l11l1 % len (l1l)
    l11lll = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l111ll:
        l1ll = l11l () .join ([unichr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    return eval (l1ll)
import os
import re
import subprocess
import l1l11
from l1l11 import l1l1l1
def l111():
    return []
def l1l11l(l1llll, l11l1l):
    logger = l1l1l1()
    l11 = []
    l1lll1 = [l11ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1lll1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1 = process.wait()
            l1l111 = {}
            if l1ll1 == 0:
                ll = re.compile(l11ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1111l = re.compile(l11ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1lll = re.search(ll, line)
                    l111l1 = l1lll.group(1)
                    if l1llll == l111l1:
                        l1l1 = re.search(l1111l, line)
                        if l1l1:
                            l11l11 = l11ll (u"ࠨࡦࡤࡺࠬࠄ")+l1l1.group(1)
                            version = l1lll.group(0)
                            if not l11l11 in l1l111:
                                l1l111[l11l11] = version
                            elif l1l11.l1ll11(version, l1l111[l11l11]) > 0:
                                l1l111[l11l11] = version
            for l11l11 in l1l111:
                l11.append({l11ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l111[l11l11], l11ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l11})
        except Exception as e:
            logger.error(str(e))
    return l11