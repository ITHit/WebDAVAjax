#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll = 2048
l1ll1l = 7
def l1l1l (l1l1l1):
    global l11l1l
    l11l = ord (l1l1l1 [-1])
    l111l1 = l1l1l1 [:-1]
    l1l1ll = l11l % len (l111l1)
    ll = l111l1 [:l1l1ll] + l111l1 [l1l1ll:]
    if l1ll11:
        l11l11 = l11 () .join ([unichr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    return eval (l11l11)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll1l1(l11ll11=None):
    if platform.system() == l1l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11l111
        props = {}
        try:
            prop_names = (l1l1l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1lll = l11l111.l1l1ll1(l11ll11, l1l1l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111l11 in prop_names:
                l11l1l1 = l1l1l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1lll, l111l11)
                props[l111l11] = l11l111.l1l1ll1(l11ll11, l11l1l1)
        except:
            pass
    return props
def l11l11l(logger, l11111):
    l11llll = os.environ.get(l1l1l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11llll = l11llll.upper()
    if l11llll == l1l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1lll11 = logging.DEBUG
    elif l11llll == l1l1l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1lll11 = logging.INFO
    elif l11llll == l1l1l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1lll11 = logging.WARNING
    elif l11llll == l1l1l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1lll11 = logging.ERROR
    elif l11llll == l1l1l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1lll11 = logging.CRITICAL
    elif l11llll == l1l1l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1lll11 = logging.NOTSET
    logger.setLevel(l1lll11)
    l1ll111 = RotatingFileHandler(l11111, maxBytes=1024*1024*5, backupCount=3)
    l1ll111.setLevel(l1lll11)
    formatter = logging.Formatter(l1l1l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll111.setFormatter(formatter)
    logger.addHandler(l1ll111)
    globals()[l1l1l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1ll():
    return globals()[l1l1l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111l1l():
    if platform.system() == l1l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l111l
        l1l111l.l1l11l1(sys.stdin.fileno(), os.l11l1ll)
        l1l111l.l1l11l1(sys.stdout.fileno(), os.l11l1ll)
def l111ll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll11l():
    if platform.system() == l1l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1111ll
        return l1111ll.l11ll1l()
    elif platform.system() == l1l1l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l11():
    if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1111ll
        return l1111ll.l1l1l11()
    elif platform.system() == l1l1l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1lll
        return l1lll.l1l11()
    elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1lllll
        return l1lllll.l1l11()
    return l1l1l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lll1l(l111, l1lll1):
    if platform.system() == l1l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1111ll
        return l1111ll.l1l1l1l(l111, l1lll1)
    elif platform.system() == l1l1l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1lllll
        return l1lllll.l1111(l111, l1lll1)
    elif platform.system() == l1l1l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1lll
        return l1lll.l1111(l111, l1lll1)
    raise ValueError(l1l1l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l11ll(l11lll, url):
    if platform.system() == l1l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1111ll
        return l1111ll.l1ll1ll(l11lll, url)
    elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1lllll
        return l1l1l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1lll
        return l1l1l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l1111():
    if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1111ll
        return l1111ll.l1l1111()
def l11111l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1l (u"ࠩ࠱ࠫ࠶"))[0]
def l1llll1(l1llll):
    l1l1l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1llllll = l1l1l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1llll:
        if l1l1l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1llllll[3:]) < int(protocol[l1l1l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1llllll = protocol[l1l1l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1llllll
def l11l1(l1111l1, l111lll):
    l1l1l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1111l1 is None: l1111l1 = l1l1l (u"ࠩ࠳ࠫ࠽");
    if l111lll is None: l111lll = l1l1l (u"ࠪ࠴ࠬ࠾");
    l111111 = l1111l1.split(l1l1l (u"ࠫ࠳࠭࠿"))
    l11lll1 = l111lll.split(l1l1l (u"ࠬ࠴ࠧࡀ"))
    while len(l111111) < len(l11lll1): l111111.append(l1l1l (u"ࠨ࠰ࠣࡁ"));
    while len(l11lll1) < len(l111111): l11lll1.append(l1l1l (u"ࠢ࠱ࠤࡂ"));
    l111111 = [ int(x) for x in l111111 ]
    l11lll1 = [ int(x) for x in l11lll1 ]
    for  i in range(len(l111111)):
        if len(l11lll1) == i:
            return 1
        if l111111[i] == l11lll1[i]:
            continue
        elif l111111[i] > l11lll1[i]:
            return 1
        else:
            return -1
    if len(l111111) != len(l11lll1):
        return -1
    return 0