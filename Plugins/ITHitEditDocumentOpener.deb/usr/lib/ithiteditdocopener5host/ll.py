#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11l1 = 2048
l11 = 7
def l1lll1 (l1111l):
    global l1ll1
    l1llll = ord (l1111l [-1])
    l1lll = l1111l [:-1]
    l1l1 = l1llll % len (l1lll)
    l11l11 = l1lll [:l1l1] + l1lll [l1l1:]
    if l111l:
        l111ll = l11lll () .join ([unichr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    return eval (l111ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1lll11(l11l11l=None):
    if platform.system() == l1lll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1l11
        props = {}
        try:
            prop_names = (l1lll1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1lll1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1lll1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1lll1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1lll1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1lll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1lll1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1lll1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1lll1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1lll1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1lll1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1lll1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1111 = l1l1l11.l1l1lll(l11l11l, l1lll1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111l1l in prop_names:
                l11ll11 = l1lll1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1111, l111l1l)
                props[l111l1l] = l1l1l11.l1l1lll(l11l11l, l11ll11)
        except:
            pass
    return props
def l1l11l1(logger, l111ll1):
    l111l11 = os.environ.get(l1lll1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1lll1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l11 = l111l11.upper()
    if l111l11 == l1lll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111ll = logging.DEBUG
    elif l111l11 == l1lll1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111ll = logging.INFO
    elif l111l11 == l1lll1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111ll = logging.WARNING
    elif l111l11 == l1lll1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111ll = logging.ERROR
    elif l111l11 == l1lll1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111ll = logging.CRITICAL
    elif l111l11 == l1lll1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111ll = logging.NOTSET
    logger.setLevel(l1111ll)
    l1ll1ll = RotatingFileHandler(l111ll1, maxBytes=1024*1024*5, backupCount=3)
    l1ll1ll.setLevel(l1111ll)
    formatter = logging.Formatter(l1lll1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll1ll.setFormatter(formatter)
    logger.addHandler(l1ll1ll)
    globals()[l1lll1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11ll():
    return globals()[l1lll1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1llllll():
    if platform.system() == l1lll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1lll1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll11l
        l1ll11l.l11111(sys.stdin.fileno(), os.l1ll1l1)
        l1ll11l.l11111(sys.stdout.fileno(), os.l1ll1l1)
def l1ll111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1lll1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llll1():
    if platform.system() == l1lll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111lll
        return l111lll.l11l1l1()
    elif platform.system() == l1lll1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1lll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1111():
    if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111lll
        return l111lll.l1lllll()
    elif platform.system() == l1lll1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l11l
        return l1l11l.l1111()
    elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1111l1
        return l1111l1.l1111()
    return l1lll1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11ll1l(l11l, l1):
    if platform.system() == l1lll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111lll
        return l111lll.l11111l(l11l, l1)
    elif platform.system() == l1lll1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1111l1
        return l1111l1.l1l(l11l, l1)
    elif platform.system() == l1lll1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l11l
        return l1l11l.l1l(l11l, l1)
    raise ValueError(l1lll1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11lll1(l1l11, url):
    if platform.system() == l1lll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111lll
        return l111lll.l11l111(l1l11, url)
    elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1111l1
        return l1lll1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1lll1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l11l
        return l1lll1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1lll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111111():
    if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111lll
        return l111lll.l111111()
def l11l1ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1lll1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1lll1l(l111):
    l1lll1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1ll1 = l1lll1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111:
        if l1lll1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1ll1[3:]) < int(protocol[l1lll1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1ll1 = protocol[l1lll1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1ll1
def l1ll1l(l1l1l1l, l1l11ll):
    l1lll1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1l1l is None: l1l1l1l = l1lll1 (u"ࠩ࠳ࠫ࠽");
    if l1l11ll is None: l1l11ll = l1lll1 (u"ࠪ࠴ࠬ࠾");
    l1l111l = l1l1l1l.split(l1lll1 (u"ࠫ࠳࠭࠿"))
    l11llll = l1l11ll.split(l1lll1 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l111l) < len(l11llll): l1l111l.append(l1lll1 (u"ࠨ࠰ࠣࡁ"));
    while len(l11llll) < len(l1l111l): l11llll.append(l1lll1 (u"ࠢ࠱ࠤࡂ"));
    l1l111l = [ int(x) for x in l1l111l ]
    l11llll = [ int(x) for x in l11llll ]
    for  i in range(len(l1l111l)):
        if len(l11llll) == i:
            return 1
        if l1l111l[i] == l11llll[i]:
            continue
        elif l1l111l[i] > l11llll[i]:
            return 1
        else:
            return -1
    if len(l1l111l) != len(l11llll):
        return -1
    return 0