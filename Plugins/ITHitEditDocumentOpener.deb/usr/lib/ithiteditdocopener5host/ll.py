#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1 = 2048
l1lll = 7
def l1ll11 (l1111l):
    global l1ll
    l11ll = ord (l1111l [-1])
    l111ll = l1111l [:-1]
    l1llll = l11ll % len (l111ll)
    l1l = l111ll [:l1llll] + l111ll [l1llll:]
    if l11:
        l11l1l = l111l1 () .join ([unichr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    return eval (l11l1l)
import os
import re
import subprocess
import l1l1
from l1l1 import l111l
def l1l11l():
    return []
def l11l(l11l11, l1l1ll):
    logger = l111l()
    l1lll1 = []
    l11lll = [l1ll11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11l1 = process.wait()
            l1l11 = {}
            if l11l1 == 0:
                l1ll1l = re.compile(l1ll11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l111 = re.compile(l1ll11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11ll1 = re.search(l1ll1l, line)
                    l1111 = l11ll1.group(1)
                    if l11l11 == l1111:
                        l111 = re.search(l1l111, line)
                        if l111:
                            l1l1l1 = l1ll11 (u"ࠨࡦࡤࡺࠬࠄ")+l111.group(1)
                            version = l11ll1.group(0)
                            if not l1l1l1 in l1l11:
                                l1l11[l1l1l1] = version
                            elif l1l1.l1ll1(version, l1l11[l1l1l1]) > 0:
                                l1l11[l1l1l1] = version
            for l1l1l1 in l1l11:
                l1lll1.append({l1ll11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l11[l1l1l1], l1ll11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1l1})
        except Exception as e:
            logger.error(str(e))
    return l1lll1