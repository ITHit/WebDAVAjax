#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1ll11 = 2048
l1111 = 7
def l1l (l1l1):
    global l11l1l
    l11ll = ord (l1l1 [-1])
    l1lll1 = l1l1 [:-1]
    l1111l = l11ll % len (l1lll1)
    l1l11l = l1lll1 [:l1111l] + l1lll1 [l1111l:]
    if l1l1l:
        l1lll = l1llll () .join ([unichr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    return eval (l1lll)
import os
import re
import subprocess
import l111ll
from l111ll import l111l1
def l11():
    return []
def l111(l1l111, l11l11):
    logger = l111l1()
    l111l = []
    l1ll = [l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll:
        try:
            output = os.popen(cmd).read()
            l1 = 0
            l11lll = {}
            if l1 == 0:
                l1l1ll = re.compile(l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1l = re.compile(l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1 = re.search(l1l1ll, line)
                    l1l1l1 = l11l1.group(1)
                    if l1l111 == l1l1l1:
                        l1l11 = re.search(l1ll1l, line)
                        if l1l11:
                            l11ll1 = l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l11.group(1)
                            version = l11l1.group(0)
                            if not l11ll1 in l11lll:
                                l11lll[l11ll1] = version
                            elif l111ll.l11l(version, l11lll[l11ll1]) > 0:
                                l11lll[l11ll1] = version
            for l11ll1 in l11lll:
                l111l.append({l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11lll[l11ll1], l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11ll1})
        except Exception as e:
            logger.error(str(e))
    return l111l