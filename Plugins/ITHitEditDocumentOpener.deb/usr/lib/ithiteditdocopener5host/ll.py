#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll = sys.version_info [0] == 2
l1l111 = 2048
l111 = 7
def l11 (l11l1):
    global l1111l
    l11l = ord (l11l1 [-1])
    l111ll = l11l1 [:-1]
    l1l11 = l11l % len (l111ll)
    l1l1l1 = l111ll [:l1l11] + l111ll [l1l11:]
    if l1lll:
        l1 = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    return eval (l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1lll11(l1ll111=None):
    if platform.system() == l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1llllll
        props = {}
        try:
            prop_names = (l11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1llll1 = l1llllll.l11ll11(l1ll111, l11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l11l1 in prop_names:
                l111l1l = l11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1llll1, l1l11l1)
                props[l1l11l1] = l1llllll.l11ll11(l1ll111, l111l1l)
        except:
            pass
    return props
def l1l1111(logger, l1111l1):
    l1l1l1l = os.environ.get(l11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l1l = l1l1l1l.upper()
    if l1l1l1l == l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11llll = logging.DEBUG
    elif l1l1l1l == l11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11llll = logging.INFO
    elif l1l1l1l == l11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11llll = logging.WARNING
    elif l1l1l1l == l11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11llll = logging.ERROR
    elif l1l1l1l == l11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11llll = logging.CRITICAL
    elif l1l1l1l == l11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11llll = logging.NOTSET
    logger.setLevel(l11llll)
    l111l11 = RotatingFileHandler(l1111l1, maxBytes=1024*1024*5, backupCount=3)
    l111l11.setLevel(l11llll)
    formatter = logging.Formatter(l11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111l11.setFormatter(formatter)
    logger.addHandler(l111l11)
    globals()[l11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1ll1():
    return globals()[l11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l1l1():
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l111
        l11l111.l111lll(sys.stdin.fileno(), os.l1lll1l)
        l11l111.l111lll(sys.stdout.fileno(), os.l1lll1l)
def l1ll1l1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l11l():
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l1ll1
        return l1l1ll1.l11ll1l()
    elif platform.system() == l11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l1ll1
        return l1l1ll1.l11lll1()
    elif platform.system() == l11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l1ll()
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1lll
        return l1l1lll.l1ll()
    return l11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1ll1ll(l11ll, l11ll1):
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l1ll1
        return l1l1ll1.l1111ll(l11ll, l11ll1)
    elif platform.system() == l11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1lll
        return l1l1lll.l11l11(l11ll, l11ll1)
    elif platform.system() == l11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.l11l11(l11ll, l11ll1)
    raise ValueError(l11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l1ll(l1l1, url):
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l1ll1
        return l1l1ll1.l1l11ll(l1l1, url)
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1lll
        return l11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return l11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lllll():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l1ll1
        return l1l1ll1.l1lllll()
def l1ll11l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11 (u"ࠩ࠱ࠫ࠶"))[0]
def l111111(l111l):
    l11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l111l = l11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111l:
        if l11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l111l[3:]) < int(protocol[l11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l111l = protocol[l11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l111l
def l1l1ll(l111ll1, l11111):
    l11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l111ll1 is None: l111ll1 = l11 (u"ࠩ࠳ࠫ࠽");
    if l11111 is None: l11111 = l11 (u"ࠪ࠴ࠬ࠾");
    l1l1l11 = l111ll1.split(l11 (u"ࠫ࠳࠭࠿"))
    l11111l = l11111.split(l11 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1l11) < len(l11111l): l1l1l11.append(l11 (u"ࠨ࠰ࠣࡁ"));
    while len(l11111l) < len(l1l1l11): l11111l.append(l11 (u"ࠢ࠱ࠤࡂ"));
    l1l1l11 = [ int(x) for x in l1l1l11 ]
    l11111l = [ int(x) for x in l11111l ]
    for  i in range(len(l1l1l11)):
        if len(l11111l) == i:
            return 1
        if l1l1l11[i] == l11111l[i]:
            continue
        elif l1l1l11[i] > l11111l[i]:
            return 1
        else:
            return -1
    if len(l1l1l11) != len(l11111l):
        return -1
    return 0