#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l11l1):
    global l11l11
    l1l1ll = ord (l11l1 [-1])
    l11l = l11l1 [:-1]
    l1l11 = l1l1ll % len (l11l)
    l1l11l = l11l [:l1l11] + l11l [l1l11:]
    if l1l:
        l1111 = l111ll () .join ([unichr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    else:
        l1111 = str () .join ([chr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    return eval (l1111)
import os
import re
import subprocess
import l1l1l
from l1l1l import l11ll1
def l11ll():
    return []
def l1llll(l1l1, l1lll1):
    logger = l11ll1()
    l1ll = []
    l1111l = [l11l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1111l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1l = process.wait()
            l1ll1 = {}
            if l1ll1l == 0:
                l11 = re.compile(l11l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111l1 = re.compile(l11l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1 = re.search(l11, line)
                    l1l111 = l1.group(1)
                    if l1l1 == l1l111:
                        l1l1l1 = re.search(l111l1, line)
                        if l1l1l1:
                            l111l = l11l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l1.group(1)
                            version = l1.group(0)
                            if not l111l in l1ll1:
                                l1ll1[l111l] = version
                            elif l1l1l.l1ll11(version, l1ll1[l111l]) > 0:
                                l1ll1[l111l] = version
            for l111l in l1ll1:
                l1ll.append({l11l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1[l111l], l11l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l})
        except Exception as e:
            logger.error(str(e))
    return l1ll