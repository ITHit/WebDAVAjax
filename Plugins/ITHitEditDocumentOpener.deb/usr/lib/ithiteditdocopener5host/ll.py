#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1111l = 2048
l1ll = 7
def l1l11l (l1):
    global l11l11
    l111l1 = ord (l1 [-1])
    l1llll = l1 [:-1]
    l1ll11 = l111l1 % len (l1llll)
    l1l1ll = l1llll [:l1ll11] + l1llll [l1ll11:]
    if l111ll:
        l11l1 = l1l () .join ([unichr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    return eval (l11l1)
import os
import re
import subprocess
import l111l
from l111l import l1lll
def l1l1l1():
    return []
def l1l11(l1lll1, l1ll1):
    logger = l1lll()
    l11 = []
    l11ll1 = [l1l11l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l11l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11ll1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1111 = process.wait()
            l1l111 = {}
            if l1111 == 0:
                l11l1l = re.compile(l1l11l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1 = re.compile(l1l11l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111 = re.search(l11l1l, line)
                    l11l = l111.group(1)
                    if l1lll1 == l11l:
                        l1l1l = re.search(l1l1, line)
                        if l1l1l:
                            l11ll = l1l11l (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l.group(1)
                            version = l111.group(0)
                            if not l11ll in l1l111:
                                l1l111[l11ll] = version
                            elif l111l.l11lll(version, l1l111[l11ll]) > 0:
                                l1l111[l11ll] = version
            for l11ll in l1l111:
                l11.append({l1l11l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l111[l11ll], l1l11l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11ll})
        except Exception as e:
            logger.error(str(e))
    return l11