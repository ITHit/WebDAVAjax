#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1l111 = 7
def l1ll (l111l):
    global l111l1
    l11l = ord (l111l [-1])
    l111ll = l111l [:-1]
    l1l11l = l11l % len (l111ll)
    l1111 = l111ll [:l1l11l] + l111ll [l1l11l:]
    if l11l1:
        l1l1 = l1lll () .join ([unichr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    else:
        l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    return eval (l1l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11111(l111ll1=None):
    if platform.system() == l1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11l1l1
        props = {}
        try:
            prop_names = (l1ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1llllll = l11l1l1.l1l1ll1(l111ll1, l1ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l1lll in prop_names:
                l11ll1l = l1ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1llllll, l1l1lll)
                props[l1l1lll] = l11l1l1.l1l1ll1(l111ll1, l11ll1l)
        except:
            pass
    return props
def l11l11l(logger, l1ll11l):
    l1l1l1l = os.environ.get(l1ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l1l = l1l1l1l.upper()
    if l1l1l1l == l1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1ll1l1 = logging.DEBUG
    elif l1l1l1l == l1ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1ll1l1 = logging.INFO
    elif l1l1l1l == l1ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1ll1l1 = logging.WARNING
    elif l1l1l1l == l1ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1ll1l1 = logging.ERROR
    elif l1l1l1l == l1ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1ll1l1 = logging.CRITICAL
    elif l1l1l1l == l1ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1ll1l1 = logging.NOTSET
    logger.setLevel(l1ll1l1)
    l111111 = RotatingFileHandler(l1ll11l, maxBytes=1024*1024*5, backupCount=3)
    l111111.setLevel(l1ll1l1)
    formatter = logging.Formatter(l1ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111111.setFormatter(formatter)
    logger.addHandler(l111111)
    globals()[l1ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1111l():
    return globals()[l1ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1111l1():
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1lll11
        l1lll11.l1lll1l(sys.stdin.fileno(), os.l1l11ll)
        l1lll11.l1lll1l(sys.stdout.fileno(), os.l1l11ll)
def l1ll1ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1111():
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1111ll
        return l1111ll.l11l1ll()
    elif platform.system() == l1ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll11():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1111ll
        return l1111ll.l1ll111()
    elif platform.system() == l1ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1
        return l1ll1.l1ll11()
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11ll11
        return l11ll11.l1ll11()
    return l1ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l11(l1, l11l11):
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1111ll
        return l1111ll.l11lll1(l1, l11l11)
    elif platform.system() == l1ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11ll11
        return l11ll11.l1l11(l1, l11l11)
    elif platform.system() == l1ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1
        return l1ll1.l1l11(l1, l11l11)
    raise ValueError(l1ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11111l(l11lll, url):
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1111ll
        return l1111ll.l1l11l1(l11lll, url)
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11ll11
        return l1ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1
        return l1ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11l111():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1111ll
        return l1111ll.l11l111()
def l111l11(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1lllll(l1l1l1):
    l1ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11llll = l1ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l1l1:
        if l1ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11llll[3:]) < int(protocol[l1ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11llll = protocol[l1ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11llll
def l11ll(l1llll1, l111lll):
    l1ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1llll1 is None: l1llll1 = l1ll (u"ࠩ࠳ࠫ࠽");
    if l111lll is None: l111lll = l1ll (u"ࠪ࠴ࠬ࠾");
    l1l111l = l1llll1.split(l1ll (u"ࠫ࠳࠭࠿"))
    l111l1l = l111lll.split(l1ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1l111l) < len(l111l1l): l1l111l.append(l1ll (u"ࠨ࠰ࠣࡁ"));
    while len(l111l1l) < len(l1l111l): l111l1l.append(l1ll (u"ࠢ࠱ࠤࡂ"));
    l1l111l = [ int(x) for x in l1l111l ]
    l111l1l = [ int(x) for x in l111l1l ]
    for  i in range(len(l1l111l)):
        if len(l111l1l) == i:
            return 1
        if l1l111l[i] == l111l1l[i]:
            continue
        elif l1l111l[i] > l111l1l[i]:
            return 1
        else:
            return -1
    if len(l1l111l) != len(l111l1l):
        return -1
    return 0