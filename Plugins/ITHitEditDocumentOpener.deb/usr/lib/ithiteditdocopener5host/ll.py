#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l = sys.version_info [0] == 2
l1111 = 2048
l111 = 7
def l1l1 (l1llll):
    global l1l11
    l1l11l = ord (l1llll [-1])
    l11l11 = l1llll [:-1]
    l1l1l = l1l11l % len (l11l11)
    l111ll = l11l11 [:l1l1l] + l11l11 [l1l1l:]
    if l11l:
        l1 = l1l () .join ([unichr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    else:
        l1 = str () .join ([chr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    return eval (l1)
import os
import re
import subprocess
import l1ll1l
from l1ll1l import l1ll1
def l11l1():
    return []
def l11(l111l, l1l1l1):
    logger = l1ll1()
    l1l1ll = []
    l11lll = [l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll11 = process.wait()
            l1lll1 = {}
            if l1ll11 == 0:
                l1l111 = re.compile(l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll = re.compile(l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1l = re.search(l1l111, line)
                    l1lll = l11l1l.group(1)
                    if l111l == l1lll:
                        l1ll = re.search(l11ll, line)
                        if l1ll:
                            l111l1 = l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1ll.group(1)
                            version = l11l1l.group(0)
                            if not l111l1 in l1lll1:
                                l1lll1[l111l1] = version
                            elif l1ll1l.l1111l(version, l1lll1[l111l1]) > 0:
                                l1lll1[l111l1] = version
            for l111l1 in l1lll1:
                l1l1ll.append({l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll1[l111l1], l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l1})
        except Exception as e:
            logger.error(str(e))
    return l1l1ll