#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1lll = 2048
l11l1 = 7
def l111 (l1ll11):
    global l1l11
    l11l1l = ord (l1ll11 [-1])
    l1l1l = l1ll11 [:-1]
    l1l1ll = l11l1l % len (l1l1l)
    l1llll = l1l1l [:l1l1ll] + l1l1l [l1l1ll:]
    if l1ll:
        l1111l = l111ll () .join ([unichr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    return eval (l1111l)
import os
import re
import subprocess
import l1l1l1
from l1l1l1 import l11ll
def l11l():
    return []
def l11l11(l11ll1, l1l111):
    logger = l11ll()
    l1l = []
    l1l11l = [l111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l11l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1 = process.wait()
            l1ll1l = {}
            if l1l1 == 0:
                l1ll1 = re.compile(l111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11lll = re.compile(l111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1lll1 = re.search(l1ll1, line)
                    l11 = l1lll1.group(1)
                    if l11ll1 == l11:
                        l111l1 = re.search(l11lll, line)
                        if l111l1:
                            l1111 = l111 (u"ࠨࡦࡤࡺࠬࠄ")+l111l1.group(1)
                            version = l1lll1.group(0)
                            if not l1111 in l1ll1l:
                                l1ll1l[l1111] = version
                            elif l1l1l1.l111l(version, l1ll1l[l1111]) > 0:
                                l1ll1l[l1111] = version
            for l1111 in l1ll1l:
                l1l.append({l111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1l[l1111], l111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1111})
        except Exception as e:
            logger.error(str(e))
    return l1l