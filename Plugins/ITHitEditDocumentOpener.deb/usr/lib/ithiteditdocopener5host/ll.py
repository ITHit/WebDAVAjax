#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1l1ll = 2048
l111 = 7
def l111l (l111l1):
    global l1lll
    l11l11 = ord (l111l1 [-1])
    l1111 = l111l1 [:-1]
    l11l = l11l11 % len (l1111)
    l1l1l1 = l1111 [:l11l] + l1111 [l11l:]
    if l11ll:
        l1l11l = l11lll () .join ([unichr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    return eval (l1l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111lll(l11ll11=None):
    if platform.system() == l111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll1ll
        props = {}
        try:
            prop_names = (l111l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11l1ll = l1ll1ll.l1111ll(l11ll11, l111l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11111 in prop_names:
                l1l1ll1 = l111l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11l1ll, l11111)
                props[l11111] = l1ll1ll.l1111ll(l11ll11, l1l1ll1)
        except:
            pass
    return props
def l1l111l(logger, l111ll1):
    l1l11l1 = os.environ.get(l111l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l11l1 = l1l11l1.upper()
    if l1l11l1 == l111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1ll1l1 = logging.DEBUG
    elif l1l11l1 == l111l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1ll1l1 = logging.INFO
    elif l1l11l1 == l111l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1ll1l1 = logging.WARNING
    elif l1l11l1 == l111l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1ll1l1 = logging.ERROR
    elif l1l11l1 == l111l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1ll1l1 = logging.CRITICAL
    elif l1l11l1 == l111l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1ll1l1 = logging.NOTSET
    logger.setLevel(l1ll1l1)
    l1l1l11 = RotatingFileHandler(l111ll1, maxBytes=1024*1024*5, backupCount=3)
    l1l1l11.setLevel(l1ll1l1)
    formatter = logging.Formatter(l111l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1l11.setFormatter(formatter)
    logger.addHandler(l1l1l11)
    globals()[l111l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l111():
    return globals()[l111l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1lll1l():
    if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1llll1
        l1llll1.l11lll1(sys.stdin.fileno(), os.l11l1l1)
        l1llll1.l11lll1(sys.stdout.fileno(), os.l11l1l1)
def l1l11ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llllll():
    if platform.system() == l111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111l1l
        return l111l1l.l1l1l1l()
    elif platform.system() == l111l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll1():
    if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111l1l
        return l111l1l.l11ll1l()
    elif platform.system() == l111l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1lll1
        return l1lll1.l1ll1()
    elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111l11
        return l111l11.l1ll1()
    return l111l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111111(l1llll, l1ll):
    if platform.system() == l111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111l1l
        return l111l1l.l1lll11(l1llll, l1ll)
    elif platform.system() == l111l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111l11
        return l111l11.l111ll(l1llll, l1ll)
    elif platform.system() == l111l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1lll1
        return l1lll1.l111ll(l1llll, l1ll)
    raise ValueError(l111l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l111(l1ll11, url):
    if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111l1l
        return l111l1l.l1lllll(l1ll11, url)
    elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111l11
        return l111l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1lll1
        return l111l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l1lll():
    if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111l1l
        return l111l1l.l1l1lll()
def l1l1111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111l (u"ࠩ࠱ࠫ࠶"))[0]
def l1111l1(l1111l):
    l111l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l11l = l111l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1111l:
        if l111l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l11l[3:]) < int(protocol[l111l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l11l = protocol[l111l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l11l
def l1l1(l11llll, l1ll111):
    l111l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11llll is None: l11llll = l111l (u"ࠩ࠳ࠫ࠽");
    if l1ll111 is None: l1ll111 = l111l (u"ࠪ࠴ࠬ࠾");
    l11111l = l11llll.split(l111l (u"ࠫ࠳࠭࠿"))
    l1ll11l = l1ll111.split(l111l (u"ࠬ࠴ࠧࡀ"))
    while len(l11111l) < len(l1ll11l): l11111l.append(l111l (u"ࠨ࠰ࠣࡁ"));
    while len(l1ll11l) < len(l11111l): l1ll11l.append(l111l (u"ࠢ࠱ࠤࡂ"));
    l11111l = [ int(x) for x in l11111l ]
    l1ll11l = [ int(x) for x in l1ll11l ]
    for  i in range(len(l11111l)):
        if len(l1ll11l) == i:
            return 1
        if l11111l[i] == l1ll11l[i]:
            continue
        elif l11111l[i] > l1ll11l[i]:
            return 1
        else:
            return -1
    if len(l11111l) != len(l1ll11l):
        return -1
    return 0