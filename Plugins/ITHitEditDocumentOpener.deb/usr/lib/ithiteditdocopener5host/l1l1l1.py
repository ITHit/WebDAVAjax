#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1ll11 = 2048
l1llll = 7
def l1 (l11lll):
    global l1l1
    l11ll1 = ord (l11lll [-1])
    l111l = l11lll [:-1]
    l1l = l11ll1 % len (l111l)
    l111ll = l111l [:l1l] + l111l [l1l:]
    if l11l1:
        l1111 = l1l1l () .join ([unichr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    return eval (l1111)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11lll1(l1ll11l=None):
    if platform.system() == l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11l11l
        props = {}
        try:
            prop_names = (l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1ll1l1 = l11l11l.l1l1lll(l1ll11l, l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11ll1l in prop_names:
                l11111 = l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1ll1l1, l11ll1l)
                props[l11ll1l] = l11l11l.l1l1lll(l1ll11l, l11111)
        except:
            pass
    return props
def l1l1l1l(logger, l11l1ll):
    l1lll1l = os.environ.get(l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1lll1l = l1lll1l.upper()
    if l1lll1l == l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111ll = logging.DEBUG
    elif l1lll1l == l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111ll = logging.INFO
    elif l1lll1l == l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111ll = logging.WARNING
    elif l1lll1l == l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111ll = logging.ERROR
    elif l1lll1l == l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111ll = logging.CRITICAL
    elif l1lll1l == l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111ll = logging.NOTSET
    logger.setLevel(l1111ll)
    l111l11 = RotatingFileHandler(l11l1ll, maxBytes=1024*1024*5, backupCount=3)
    l111l11.setLevel(l1111ll)
    formatter = logging.Formatter(l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111l11.setFormatter(formatter)
    logger.addHandler(l111l11)
    globals()[l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l111l1():
    return globals()[l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1111():
    if platform.system() == l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111l1l
        l111l1l.l1l11l1(sys.stdin.fileno(), os.l1l111l)
        l111l1l.l1l11l1(sys.stdout.fileno(), os.l1l111l)
def l1111l1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l1l1():
    if platform.system() == l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11111l
        return l11111l.l111ll1()
    elif platform.system() == l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l111():
    if platform.system() == l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11111l
        return l11111l.l11llll()
    elif platform.system() == l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l111()
    elif platform.system() == l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1l11
        return l1l1l11.l111()
    return l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111lll(l11l11, l11l):
    if platform.system() == l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11111l
        return l11111l.l1l1ll1(l11l11, l11l)
    elif platform.system() == l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1l11
        return l1l1l11.l1lll1(l11l11, l11l)
    elif platform.system() == l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.l1lll1(l11l11, l11l)
    raise ValueError(l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1lll11(l1l11l, url):
    if platform.system() == l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11111l
        return l11111l.l11ll11(l1l11l, url)
    elif platform.system() == l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1l11
        return l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lllll():
    if platform.system() == l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11111l
        return l11111l.l1lllll()
def l1llll1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l11l111(l1lll):
    l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l11ll = l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1lll:
        if l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l11ll[3:]) < int(protocol[l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l11ll = protocol[l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l11ll
def l11ll(l1ll111, l1ll1ll):
    l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll111 is None: l1ll111 = l1 (u"ࠩ࠳ࠫ࠽");
    if l1ll1ll is None: l1ll1ll = l1 (u"ࠪ࠴ࠬ࠾");
    l111111 = l1ll111.split(l1 (u"ࠫ࠳࠭࠿"))
    l1llllll = l1ll1ll.split(l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l111111) < len(l1llllll): l111111.append(l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1llllll) < len(l111111): l1llllll.append(l1 (u"ࠢ࠱ࠤࡂ"));
    l111111 = [ int(x) for x in l111111 ]
    l1llllll = [ int(x) for x in l1llllll ]
    for  i in range(len(l111111)):
        if len(l1llllll) == i:
            return 1
        if l111111[i] == l1llllll[i]:
            continue
        elif l111111[i] > l1llllll[i]:
            return 1
        else:
            return -1
    if len(l111111) != len(l1llllll):
        return -1
    return 0