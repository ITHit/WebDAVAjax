#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1lll = 2048
l11l1 = 7
def l111 (l1ll11):
    global l1l11
    l11l1l = ord (l1ll11 [-1])
    l1l1l = l1ll11 [:-1]
    l1l1ll = l11l1l % len (l1l1l)
    l1llll = l1l1l [:l1l1ll] + l1l1l [l1l1ll:]
    if l1ll:
        l1111l = l111ll () .join ([unichr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    return eval (l1111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111l11(l1l1l11=None):
    if platform.system() == l111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll111
        props = {}
        try:
            prop_names = (l111 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111 = l1ll111.l1llll1(l1l1l11, l111 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1ll in prop_names:
                l1l11l1 = l111 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111, l11l1ll)
                props[l11l1ll] = l1ll111.l1llll1(l1l1l11, l1l11l1)
        except:
            pass
    return props
def l111l1l(logger, l1lllll):
    l1111l1 = os.environ.get(l111 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1111l1 = l1111l1.upper()
    if l1111l1 == l111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1ll1 = logging.DEBUG
    elif l1111l1 == l111 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1ll1 = logging.INFO
    elif l1111l1 == l111 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1ll1 = logging.WARNING
    elif l1111l1 == l111 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1ll1 = logging.ERROR
    elif l1111l1 == l111 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1ll1 = logging.CRITICAL
    elif l1111l1 == l111 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1ll1 = logging.NOTSET
    logger.setLevel(l1l1ll1)
    l1l1111 = RotatingFileHandler(l1lllll, maxBytes=1024*1024*5, backupCount=3)
    l1l1111.setLevel(l1l1ll1)
    formatter = logging.Formatter(l111 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1111.setFormatter(formatter)
    logger.addHandler(l1l1111)
    globals()[l111 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11ll():
    return globals()[l111 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1llllll():
    if platform.system() == l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111111
        l111111.l11ll1l(sys.stdin.fileno(), os.l11l11l)
        l111111.l11ll1l(sys.stdout.fileno(), os.l11l11l)
def l1ll11l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll1l():
    if platform.system() == l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11111l
        return l11111l.l1l1lll()
    elif platform.system() == l111 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l():
    if platform.system() == l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11111l
        return l11111l.l11l1l1()
    elif platform.system() == l111 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import ll
        return ll.l11l()
    elif platform.system() == l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11llll
        return l11llll.l11l()
    return l111 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11ll11(l11ll1, l1l111):
    if platform.system() == l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11111l
        return l11111l.l1l111l(l11ll1, l1l111)
    elif platform.system() == l111 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11llll
        return l11llll.l11l11(l11ll1, l1l111)
    elif platform.system() == l111 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import ll
        return ll.l11l11(l11ll1, l1l111)
    raise ValueError(l111 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111ll1(l1111, url):
    if platform.system() == l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11111l
        return l11111l.l1l11ll(l1111, url)
    elif platform.system() == l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11llll
        return l111 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import ll
        return l111 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lll11():
    if platform.system() == l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11111l
        return l11111l.l1lll11()
def l111lll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111 (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll1l1(l1ll1l):
    l111 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l111 = l111 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1l:
        if l111 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l111[3:]) < int(protocol[l111 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l111 = protocol[l111 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l111
def l111l(l1111ll, l1l1l1l):
    l111 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1111ll is None: l1111ll = l111 (u"ࠩ࠳ࠫ࠽");
    if l1l1l1l is None: l1l1l1l = l111 (u"ࠪ࠴ࠬ࠾");
    l1ll1ll = l1111ll.split(l111 (u"ࠫ࠳࠭࠿"))
    l11lll1 = l1l1l1l.split(l111 (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll1ll) < len(l11lll1): l1ll1ll.append(l111 (u"ࠨ࠰ࠣࡁ"));
    while len(l11lll1) < len(l1ll1ll): l11lll1.append(l111 (u"ࠢ࠱ࠤࡂ"));
    l1ll1ll = [ int(x) for x in l1ll1ll ]
    l11lll1 = [ int(x) for x in l11lll1 ]
    for  i in range(len(l1ll1ll)):
        if len(l11lll1) == i:
            return 1
        if l1ll1ll[i] == l11lll1[i]:
            continue
        elif l1ll1ll[i] > l11lll1[i]:
            return 1
        else:
            return -1
    if len(l1ll1ll) != len(l11lll1):
        return -1
    return 0