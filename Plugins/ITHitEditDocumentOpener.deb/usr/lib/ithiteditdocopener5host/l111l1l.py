#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l1 = 2048
l11ll = 7
def l11 (ll):
    global l1
    l1ll11 = ord (ll [-1])
    l1lll = ll [:-1]
    l1l11 = l1ll11 % len (l1lll)
    l11l1l = l1lll [:l1l11] + l1lll [l1l11:]
    if l1ll1l:
        l1l1ll = l1llll () .join ([unichr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    return eval (l1l1ll)
import l1lll1
from l1l1l111 import l1l1l11l
import objc as _111ll1l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll1l.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111llll.l111l111(l111ll11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11 (u"ࠨࠩࢬ"), {l11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l1111l11):
    l1111l11 = (l1111l11 + l11 (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1ll = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l1111lll = CFURLCreateWithString( kCFAllocatorDefault, l111l1ll, _111ll1l.nil )
    l111111l = LaunchServices.l11111l1( l1111lll, LaunchServices.l1111ll1, _111ll1l.nil )
    if l111111l[0] is not None:
        return True
    return False
def l111():
    l111l11l = []
    for name in l1l1l11l:
        try:
            if l1111111(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def l11l(l1111, l11ll1):
    import plistlib
    import os
    l1l1l = []
    l11l11 = {}
    for l1111l1l in os.listdir(l11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111l1l.startswith(l11ll1):
            try:
                l111l1l1 = l11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111l1l
                with open(l111l1l1, l11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1111l = plist[l11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l11111ll = version.split(l11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111 == l11111ll:
                        if not l1111l in l11l11:
                            l11l11[l1111l] = version
                        elif l1lll1.l1l1l1(version, l11l11[l1111l]) > 0:
                            l11l11[l1111l] = version
            except BaseException:
                continue
    for l1111l in l11l11:
        l1l1l.append({l11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l11[l1111l], l11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1111l})
    return l1l1l