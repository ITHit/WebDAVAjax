#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l1l11l):
    global l11lll
    l1l1l = ord (l1l11l [-1])
    l1l11 = l1l11l [:-1]
    l11l = l1l1l % len (l1l11)
    l11l1 = l1l11 [:l11l] + l1l11 [l11l:]
    if l1l1l1:
        l1l1ll = l1lll1 () .join ([unichr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    return eval (l1l1ll)
import l111ll
from l1l1l111 import l1l1l11l
import objc as _11111ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11111ll.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111111.l111l11l(l11111l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l1l (u"ࠨࠩࢬ"), {l11l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111lll1(l111l111):
    l111l111 = (l111l111 + l11l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1ll = CFStringCreateWithCString( kCFAllocatorDefault, l111l111, kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l111l1ll, _11111ll.nil )
    l1111lll = LaunchServices.l111l1l1( l111ll11, LaunchServices.l111llll, _11111ll.nil )
    if l1111lll[0] is not None:
        return True
    return False
def l1l1():
    l1111l11 = []
    for name in l1l1l11l:
        try:
            if l111lll1(name):
                l1111l11.append(name)
        except:
            continue
    return l1111l11
def l111l(l1111, ll):
    import plistlib
    import os
    l111l1 = []
    l1l111 = {}
    for l111111l in os.listdir(l11l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111111l.startswith(ll):
            try:
                l1111l1l = l11l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111111l
                with open(l1111l1l, l11l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1 = plist[l11l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll1l = version.split(l11l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111 == l111ll1l:
                        if not l1 in l1l111:
                            l1l111[l1] = version
                        elif l111ll.l11ll(version, l1l111[l1]) > 0:
                            l1l111[l1] = version
            except BaseException:
                continue
    for l1 in l1l111:
        l111l1.append({l11l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l111[l1], l11l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1})
    return l111l1