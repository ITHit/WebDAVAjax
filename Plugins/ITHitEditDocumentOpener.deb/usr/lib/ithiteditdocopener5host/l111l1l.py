#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1l1ll = 2048
l111 = 7
def l111l (l111l1):
    global l1lll
    l11l11 = ord (l111l1 [-1])
    l1111 = l111l1 [:-1]
    l11l = l11l11 % len (l1111)
    l1l1l1 = l1111 [:l11l] + l1111 [l11l:]
    if l11ll:
        l1l11l = l11lll () .join ([unichr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    return eval (l1l11l)
import subprocess, threading
from ll import l1l111
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l1l1l():
    l11l11ll = [l111l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l111l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l111l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l111l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l11ll:
        try:
            l1l11l1l = l111l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l1l111l1(winreg.l11l1111, l1l11l1l)
        except l1l11111:
            continue
        value = winreg.l11l1ll1(l11l1l1l, l111l (u"ࠦࠧ࢓"))
        return value.split(l111l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11ll1l():
    l11ll11l = []
    for name in l1l1l111:
        try:
            l1l11l1l = l111l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1lll = winreg.l1l111l1(winreg.l11l1111, l1l11l1l)
            if winreg.l11l1ll1(l11l1lll, l111l (u"ࠢࠣ࢖")):
                l11ll11l.append(name)
        except l1l11111:
            continue
    return l11ll11l
def l1lll11(l1llll, l1ll):
    import re
    l1l1l = []
    l1l1111l = winreg.l1l111l1(winreg.l11l1111, l111l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11lll(l1l1111l)[0]):
        try:
            l11lll11 = winreg.l11ll1ll(l1l1111l, i)
            if l11lll11.startswith(l1ll):
                l11l1l11 = winreg.l1l111ll(l1l1111l, l11lll11)
                value, l1l11ll1 = winreg.l11lllll(l11l1l11, l111l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l111l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11l1 = {l111l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll1l1 = m.group(2)
                    if l1llll == l11ll1l1:
                        m = re.search(l1ll.replace(l111l (u"ࠬ࠴࢛ࠧ"), l111l (u"࠭࡜࡝࠰ࠪ࢜")) + l111l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll11)
                        l11l11l1[l111l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1l.append(l11l11l1)
                else:
                    raise ValueError(l111l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11111 as ex:
            continue
    return l1l1l
def l11ll111(l1ll11):
    try:
        l11lll1l = l111l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll11)
        l11l111l = winreg.l1l111l1(winreg.l11l1111, l11lll1l)
        value, l1l11ll1 = winreg.l11lllll(l11l111l, l111l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l111l (u"ࠬࠨࠧࢢ"))[1]
    except l1l11111:
        pass
    return l111l (u"࠭ࠧࢣ")
def l1lllll(l1ll11, url):
    threading.Thread(target=_11llll1,args=(l1ll11, url)).start()
    return l111l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11llll1(l1ll11, url):
    logger = l1l111()
    l1l11l11 = l11ll111(l1ll11)
    logger.debug(l111l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l11, url))
    retcode = subprocess.Popen(l111l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l111l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l111l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)