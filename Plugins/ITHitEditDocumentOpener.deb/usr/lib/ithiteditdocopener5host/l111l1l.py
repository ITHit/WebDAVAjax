#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1 = 2048
l111 = 7
def l1lll (l1l111):
    global l11l1l
    l1l = ord (l1l111 [-1])
    l11lll = l1l111 [:-1]
    l1ll1 = l1l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l1l1l:
        l1l1ll = l1ll11 () .join ([unichr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    return eval (l1l1ll)
import subprocess, threading
from l111ll import l1111
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l111lll():
    l11l11ll = [l1lll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1lll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1lll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1lll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l11ll:
        try:
            l1l11l1l = l1lll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11llll1 = winreg.l11l1111(winreg.l11l1l1l, l1l11l1l)
        except l11ll1l1:
            continue
        value = winreg.l1l111ll(l11llll1, l1lll (u"ࠦࠧ࢓"))
        return value.split(l1lll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll111():
    l11lllll = []
    for name in l1l1l11l:
        try:
            l1l11l1l = l1lll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l11 = winreg.l11l1111(winreg.l11l1l1l, l1l11l1l)
            if winreg.l1l111ll(l1l11l11, l1lll (u"ࠢࠣ࢖")):
                l11lllll.append(name)
        except l11ll1l1:
            continue
    return l11lllll
def l1l1111(l11ll1, l111l1):
    import re
    l11l1 = []
    l1l11111 = winreg.l11l1111(winreg.l11l1l1l, l1lll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11lll(l1l11111)[0]):
        try:
            l11lll11 = winreg.l11l1ll1(l1l11111, i)
            if l11lll11.startswith(l111l1):
                l1l1111l = winreg.l11l1lll(l1l11111, l11lll11)
                value, l11l1l11 = winreg.l11ll11l(l1l1111l, l1lll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1lll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll111 = {l1lll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11ll1 = m.group(2)
                    if l11ll1 == l1l11ll1:
                        m = re.search(l111l1.replace(l1lll (u"ࠬ࠴࢛ࠧ"), l1lll (u"࠭࡜࡝࠰ࠪ࢜")) + l1lll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll11)
                        l11ll111[l1lll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l1.append(l11ll111)
                else:
                    raise ValueError(l1lll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll1l1 as ex:
            continue
    return l11l1
def l1l111l1(l1lll1):
    try:
        l11ll1ll = l1lll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1lll1)
        l11l111l = winreg.l11l1111(winreg.l11l1l1l, l11ll1ll)
        value, l11l1l11 = winreg.l11ll11l(l11l111l, l1lll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1lll (u"ࠬࠨࠧࢢ"))[1]
    except l11ll1l1:
        pass
    return l1lll (u"࠭ࠧࢣ")
def l1lll11(l1lll1, url):
    threading.Thread(target=_11lll1l,args=(l1lll1, url)).start()
    return l1lll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lll1l(l1lll1, url):
    logger = l1111()
    l11l11l1 = l1l111l1(l1lll1)
    logger.debug(l1lll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11l1, url))
    retcode = subprocess.Popen(l1lll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1lll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1lll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)