#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1111l = 2048
ll = 7
def l1ll (l11l):
    global l1l111
    l1lll = ord (l11l [-1])
    l1l1l1 = l11l [:-1]
    l111l1 = l1lll % len (l1l1l1)
    l11l1 = l1l1l1 [:l111l1] + l1l1l1 [l111l1:]
    if l111l:
        l1l1ll = l111 () .join ([unichr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    return eval (l1l1ll)
import l11l1l
from l1l1l111 import l1l1l11l
import objc as _111ll1l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll1l.l1111l1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l111l11l(l111l1ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll (u"ࠨࠩࢬ"), {l1ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l111(l111lll1):
    l111lll1 = (l111lll1 + l1ll (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l11 = CFStringCreateWithCString( kCFAllocatorDefault, l111lll1, kCFStringEncodingUTF8 )
    l11111l1 = CFURLCreateWithString( kCFAllocatorDefault, l1111l11, _111ll1l.nil )
    l11111ll = LaunchServices.l111ll11( l11111l1, LaunchServices.l111l1l1, _111ll1l.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l1lll1():
    l111111l = []
    for name in l1l1l11l:
        try:
            if l111l111(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l1l1l(l111ll, l1l):
    import plistlib
    import os
    l1l1 = []
    l1111 = {}
    for l1111ll1 in os.listdir(l1ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111ll1.startswith(l1l):
            try:
                l111llll = l1ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111ll1
                with open(l111llll, l1ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l11l = plist[l1ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l1ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111ll == l1111111:
                        if not l1l11l in l1111:
                            l1111[l1l11l] = version
                        elif l11l1l.l1(version, l1111[l1l11l]) > 0:
                            l1111[l1l11l] = version
            except BaseException:
                continue
    for l1l11l in l1111:
        l1l1.append({l1ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111[l1l11l], l1ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l11l})
    return l1l1