#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11lll = 2048
l1ll1 = 7
def l1l111 (l1l):
    global l1111
    ll = ord (l1l [-1])
    l111l1 = l1l [:-1]
    l111l = ll % len (l111l1)
    l11l1 = l111l1 [:l111l] + l111l1 [l111l:]
    if l1l1:
        l1lll = l1l11l () .join ([unichr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    else:
        l1lll = str () .join ([chr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    return eval (l1lll)
import subprocess, threading
from l1ll import l111ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1llllll():
    l11l1lll = [l1l111 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l111 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l111 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l111 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1lll:
        try:
            l11l1ll1 = l1l111 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1111 = winreg.l11ll1l1(winreg.l11ll1ll, l11l1ll1)
        except l11ll111:
            continue
        value = winreg.l11lll1l(l11l1111, l1l111 (u"ࠦࠧ࢓"))
        return value.split(l1l111 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11llll():
    l1l11lll = []
    for name in l1l1l11l:
        try:
            l11l1ll1 = l1l111 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11111 = winreg.l11ll1l1(winreg.l11ll1ll, l11l1ll1)
            if winreg.l11lll1l(l1l11111, l1l111 (u"ࠢࠣ࢖")):
                l1l11lll.append(name)
        except l11ll111:
            continue
    return l1l11lll
def l11ll1l(l1111l, l1l1ll):
    import re
    l11l11 = []
    l1l11l1l = winreg.l11ll1l1(winreg.l11ll1ll, l1l111 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lll11(l1l11l1l)[0]):
        try:
            l11l11l1 = winreg.l11l1l1l(l1l11l1l, i)
            if l11l11l1.startswith(l1l1ll):
                l1l111l1 = winreg.l1l11l11(l1l11l1l, l11l11l1)
                value, l11lllll = winreg.l1l1111l(l1l111l1, l1l111 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l111 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111ll = {l1l111 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11llll1 = m.group(2)
                    if l1111l == l11llll1:
                        m = re.search(l1l1ll.replace(l1l111 (u"ࠬ࠴࢛ࠧ"), l1l111 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l111 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l11l1)
                        l1l111ll[l1l111 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l11.append(l1l111ll)
                else:
                    raise ValueError(l1l111 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll111 as ex:
            continue
    return l11l11
def l1l11ll1(l1llll):
    try:
        l11l1l11 = l1l111 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1llll)
        l11l111l = winreg.l11ll1l1(winreg.l11ll1ll, l11l1l11)
        value, l11lllll = winreg.l1l1111l(l11l111l, l1l111 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l111 (u"ࠬࠨࠧࢢ"))[1]
    except l11ll111:
        pass
    return l1l111 (u"࠭ࠧࢣ")
def l1l111l(l1llll, url):
    threading.Thread(target=_11ll11l,args=(l1llll, url)).start()
    return l1l111 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll11l(l1llll, url):
    logger = l111ll()
    l11l11ll = l1l11ll1(l1llll)
    logger.debug(l1l111 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11ll, url))
    retcode = subprocess.Popen(l1l111 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l111 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l111 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)