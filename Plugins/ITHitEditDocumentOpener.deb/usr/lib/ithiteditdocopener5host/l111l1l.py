#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1l1ll (l1l11):
    global l11ll1
    l1ll11 = ord (l1l11 [-1])
    l111ll = l1l11 [:-1]
    l1lll = l1ll11 % len (l111ll)
    l1ll1l = l111ll [:l1lll] + l111ll [l1lll:]
    if l1llll:
        l1lll1 = l11l1l () .join ([unichr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    return eval (l1lll1)
import subprocess, threading
from l1 import l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l11l1():
    l11ll111 = [l1l1ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11ll111:
        try:
            l1l11l11 = l1l1ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll1ll = winreg.l11ll1l1(winreg.l11l1l11, l1l11l11)
        except l11l111l:
            continue
        value = winreg.l1l11111(l11ll1ll, l1l1ll (u"ࠦࠧ࢓"))
        return value.split(l1l1ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11l111():
    l11l1l1l = []
    for name in l1l1l11l:
        try:
            l1l11l11 = l1l1ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111l1 = winreg.l11ll1l1(winreg.l11l1l11, l1l11l11)
            if winreg.l1l11111(l1l111l1, l1l1ll (u"ࠢࠣ࢖")):
                l11l1l1l.append(name)
        except l11l111l:
            continue
    return l11l1l1l
def l1111ll(l11l11, l1l1l1):
    import re
    l1l1l = []
    l11ll11l = winreg.l11ll1l1(winreg.l11l1l11, l1l1ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l111ll(l11ll11l)[0]):
        try:
            l11l1lll = winreg.l1l11ll1(l11ll11l, i)
            if l11l1lll.startswith(l1l1l1):
                l11l11ll = winreg.l11lllll(l11ll11l, l11l1lll)
                value, l11l1111 = winreg.l11lll11(l11l11ll, l1l1ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11l1l = {l1l1ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l1111l = m.group(2)
                    if l11l11 == l1l1111l:
                        m = re.search(l1l1l1.replace(l1l1ll (u"ࠬ࠴࢛ࠧ"), l1l1ll (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1lll)
                        l1l11l1l[l1l1ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1l.append(l1l11l1l)
                else:
                    raise ValueError(l1l1ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l1l1l
def l11l1ll1(l1ll):
    try:
        l11lll1l = l1l1ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll)
        l11llll1 = winreg.l11ll1l1(winreg.l11l1l11, l11lll1l)
        value, l11l1111 = winreg.l11lll11(l11llll1, l1l1ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1ll (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l1l1ll (u"࠭ࠧࢣ")
def l11llll(l1ll, url):
    threading.Thread(target=_1l11lll,args=(l1ll, url)).start()
    return l1l1ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11lll(l1ll, url):
    logger = l11l()
    l11l11l1 = l11l1ll1(l1ll)
    logger.debug(l1l1ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11l1, url))
    retcode = subprocess.Popen(l1l1ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)