#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1l1 = 7
def l1l111 (l111ll):
    global l1l11l
    l11l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l11l1 % len (l1llll)
    ll = l1llll [:l11l] + l1llll [l11l:]
    if l1l11:
        l11 = l1l1ll () .join ([unichr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    else:
        l11 = str () .join ([chr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    return eval (l11)
import subprocess, threading
from l1l import l1111l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l1ll1():
    l11lll1l = [l1l111 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l111 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l111 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l111 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lll1l:
        try:
            l11l1111 = l1l111 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11lll = winreg.l1l11111(winreg.l11l1ll1, l11l1111)
        except l11l11ll:
            continue
        value = winreg.l11llll1(l1l11lll, l1l111 (u"ࠦࠧ࢓"))
        return value.split(l1l111 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll1l1():
    l1l11l1l = []
    for name in l1l1l11l:
        try:
            l11l1111 = l1l111 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111ll = winreg.l1l11111(winreg.l11l1ll1, l11l1111)
            if winreg.l11llll1(l1l111ll, l1l111 (u"ࠢࠣ࢖")):
                l1l11l1l.append(name)
        except l11l11ll:
            continue
    return l1l11l1l
def l1ll11l(l1ll1l, l1l1l):
    import re
    l1 = []
    l1l1111l = winreg.l1l11111(winreg.l11l1ll1, l1l111 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l111l(l1l1111l)[0]):
        try:
            l11ll1l1 = winreg.l11lll11(l1l1111l, i)
            if l11ll1l1.startswith(l1l1l):
                l1l111l1 = winreg.l1l11l11(l1l1111l, l11ll1l1)
                value, l11ll11l = winreg.l1l11ll1(l1l111l1, l1l111 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l111 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11l1 = {l1l111 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lllll = m.group(2)
                    if l1ll1l == l11lllll:
                        m = re.search(l1l1l.replace(l1l111 (u"ࠬ࠴࢛ࠧ"), l1l111 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l111 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1l1)
                        l11l11l1[l1l111 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1.append(l11l11l1)
                else:
                    raise ValueError(l1l111 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l11ll as ex:
            continue
    return l1
def l11ll111(l1lll1):
    try:
        l11ll1ll = l1l111 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1lll1)
        l11l1l1l = winreg.l1l11111(winreg.l11l1ll1, l11ll1ll)
        value, l11ll11l = winreg.l1l11ll1(l11l1l1l, l1l111 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l111 (u"ࠬࠨࠧࢢ"))[1]
    except l11l11ll:
        pass
    return l1l111 (u"࠭ࠧࢣ")
def l111ll1(l1lll1, url):
    threading.Thread(target=_11l1lll,args=(l1lll1, url)).start()
    return l1l111 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1lll(l1lll1, url):
    logger = l1111l()
    l11l1l11 = l11ll111(l1lll1)
    logger.debug(l1l111 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1l11, url))
    retcode = subprocess.Popen(l1l111 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l111 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l111 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)