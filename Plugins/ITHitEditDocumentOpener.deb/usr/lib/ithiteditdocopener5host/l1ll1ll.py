#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l1l11l = 2048
l11l1l = 7
def l11l11 (l1l1l1):
    global l11ll
    l11 = ord (l1l1l1 [-1])
    l11lll = l1l1l1 [:-1]
    l1111 = l11 % len (l11lll)
    l1 = l11lll [:l1111] + l11lll [l1111:]
    if l1lll1:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    return eval (l1ll1l)
import l1111l
from l1l1l111 import l1l1l11l
import objc as _111111l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111111l.l111l111( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll1l.l111l1ll(l111llll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111llll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l11 (u"ࠨࠩࢬ"), {l11l11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111l1(l1111lll):
    l1111lll = (l1111lll + l11l11 (u"ࠩ࠽ࠫࢴ")).encode()
    l11111ll = CFStringCreateWithCString( kCFAllocatorDefault, l1111lll, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l11111ll, _111111l.nil )
    l111l1l1 = LaunchServices.l1111l11( l1111111, LaunchServices.l1111ll1, _111111l.nil )
    if l111l1l1[0] is not None:
        return True
    return False
def ll():
    l111l11l = []
    for name in l1l1l11l:
        try:
            if l11111l1(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def l1l111(l1l1ll, l1l11):
    import plistlib
    import os
    l1ll = []
    l111l1 = {}
    for l1111l1l in os.listdir(l11l11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111l1l.startswith(l1l11):
            try:
                l111lll1 = l11l11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111l1l
                with open(l111lll1, l11l11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l = plist[l11l11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll11 = version.split(l11l11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1ll == l111ll11:
                        if not l11l in l111l1:
                            l111l1[l11l] = version
                        elif l1111l.l1lll(version, l111l1[l11l]) > 0:
                            l111l1[l11l] = version
            except BaseException:
                continue
    for l11l in l111l1:
        l1ll.append({l11l11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111l1[l11l], l11l11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l})
    return l1ll