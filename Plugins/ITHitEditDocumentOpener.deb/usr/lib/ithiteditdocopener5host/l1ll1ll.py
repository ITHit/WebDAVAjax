#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l11lll = 2048
l111ll = 7
def l11 (l1l1l):
    global l1111l
    l1lll1 = ord (l1l1l [-1])
    l1l11 = l1l1l [:-1]
    l11ll = l1lll1 % len (l1l11)
    l1l1 = l1l11 [:l11ll] + l1l11 [l11ll:]
    if l1ll:
        l111l1 = l111 () .join ([unichr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    return eval (l111l1)
import subprocess, threading
from l1llll import l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11l1ll():
    l11l1l11 = [l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1l11:
        try:
            l1l111l1 = l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l11l1 = winreg.l11l1l1l(winreg.l11l111l, l1l111l1)
        except l1l11lll:
            continue
        value = winreg.l11lll1l(l11l11l1, l11 (u"ࠦࠧ࢓"))
        return value.split(l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1lllll():
    l11lll11 = []
    for name in l1l1l111:
        try:
            l1l111l1 = l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll111 = winreg.l11l1l1l(winreg.l11l111l, l1l111l1)
            if winreg.l11lll1l(l11ll111, l11 (u"ࠢࠣ࢖")):
                l11lll11.append(name)
        except l1l11lll:
            continue
    return l11lll11
def l11llll(l1l111, l1111):
    import re
    l1l11l = []
    l1l111ll = winreg.l11l1l1l(winreg.l11l111l, l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll1l1(l1l111ll)[0]):
        try:
            l1l1111l = winreg.l11l1ll1(l1l111ll, i)
            if l1l1111l.startswith(l1111):
                l11l11ll = winreg.l1l11111(l1l111ll, l1l1111l)
                value, l1l11l11 = winreg.l11lllll(l11l11ll, l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11l1l = {l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll1ll = m.group(2)
                    if l1l111 == l11ll1ll:
                        m = re.search(l1111.replace(l11 (u"ࠬ࠴࢛ࠧ"), l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l1111l)
                        l1l11l1l[l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l11l.append(l1l11l1l)
                else:
                    raise ValueError(l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11lll as ex:
            continue
    return l1l11l
def l11l1111(l111l):
    try:
        l11llll1 = l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l111l)
        l11ll11l = winreg.l11l1l1l(winreg.l11l111l, l11llll1)
        value, l1l11l11 = winreg.l11lllll(l11ll11l, l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11lll:
        pass
    return l11 (u"࠭ࠧࢣ")
def l1l1111(l111l, url):
    threading.Thread(target=_1l11ll1,args=(l111l, url)).start()
    return l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11ll1(l111l, url):
    logger = l11l()
    l11l1lll = l11l1111(l111l)
    logger.debug(l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1lll, url))
    retcode = subprocess.Popen(l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1lll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)