#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11l1l = 2048
l11l1 = 7
def l111l1 (l1l11l):
    global l11
    ll = ord (l1l11l [-1])
    l1ll = l1l11l [:-1]
    l1111 = ll % len (l1ll)
    l11ll = l1ll [:l1111] + l1ll [l1111:]
    if l1ll1:
        l11lll = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    return eval (l11lll)
import l111ll
from l1l1ll1l import l1l1lll1
import objc as _11l11ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11l11ll.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111l1 (u"࠭ࡌࡔࡅࡲࡴࡾࡊࡥࡧࡣࡸࡰࡹࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡘࡖࡑࡌ࡯ࡳࡗࡕࡐࠬࢣ"), LaunchServices._11l111l.l11l1l11(l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡎࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢤ"), l1111lll (u"ࠨࡠࡾࡣࡤࡉࡆࡖࡔࡏࡁࢂࡤࡻࡠࡡࡆࡊ࡚ࡘࡌ࠾ࡿࡌࡢࡣࢁ࡟ࡠࡅࡉࡉࡷࡸ࡯ࡳ࠿ࢀࠫࢥ")), l111l1 (u"ࠩࠪࢦ"), {l111l1 (u"ࠪࡶࡪࡺࡶࡢ࡮ࠪࢧ"): {l111l1 (u"ࠫࡦࡲࡲࡦࡣࡧࡽࡤࡩࡦࡳࡧࡷࡥ࡮ࡴࡥࡥࠩࢨ"): True}, l111l1 (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨࢩ"): {2: {l111l1 (u"࠭࡮ࡶ࡮࡯ࡣࡦࡩࡣࡦࡲࡷࡩࡩ࠭ࢪ"): True, l111l1 (u"ࠧࡢ࡮ࡵࡩࡦࡪࡹࡠࡥࡩࡶࡪࡺࡡࡪࡰࡨࡨࠬࢫ"): True, l111l1 (u"ࠨࡶࡼࡴࡪࡥ࡭ࡰࡦ࡬ࡪ࡮࡫ࡲࠨࢬ"): l111l1 (u"ࠩࡲࠫࢭ")}}}),
        ])
except:
    pass
def l1111l11(l111l1l1):
    _11l11l1 = False
    l111lll1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1 + l111l1 (u"ࠪ࠾ࠬࢮ"), kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l111lll1, _11l11ll.nil )
    l111l111 = LaunchServices.l111l1ll( l111ll11, LaunchServices.l111ll1l, _11l11ll.nil )
    if l111l111[0] is not None:
        _11l11l1 = True
    return _11l11l1
def l1ll11():
    l1111l1l = []
    for name in l1l1lll1:
        try:
            if l1111l11(name):
                l1111l1l.append(name)
        except:
            continue
    return l1111l1l
def l11l(l1l111, l1):
    import plistlib
    import os
    l1l = []
    l1111l = {}
    for l11l1111 in os.listdir(l111l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶࠦࢯ")):
        if l11l1111.startswith(l1):
            try:
                l111l11l = l111l1 (u"ࠧ࠵ࡁࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡷ࠴ࠫࡳ࠰ࡅࡲࡲࡹ࡫࡮ࡵࡵ࠲ࡍࡳ࡬࡯࠯ࡲ࡯࡭ࡸࡺࠢࢰ") % l11l1111
                with open(l111l11l, l111l1 (u"࠭ࡲࡣࠩࢱ")) as f:
                    plist = plistlib.load(f)
                    l111l = plist[l111l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐ࡙ࡿࡰࡦࡵࠥࢲ")][0][l111l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧࡘࡖࡑ࡙ࡣࡩࡧࡰࡩࡸࠨࢳ")][0]
                    version = plist[l111l1 (u"ࠤࡆࡊࡇࡻ࡮ࡥ࡮ࡨ࡚ࡪࡸࡳࡪࡱࡱࠦࢴ")]
                    l111llll = version.split(l111l1 (u"ࠥ࠲ࠧࢵ"))[0]
                    if l1l111 == l111llll:
                        if not l111l in l1111l:
                            l1111l[l111l] = version
                        elif l111ll.l1l11(version, l1111l[l111l]) > 0:
                            l1111l[l111l] = version
            except BaseException:
                continue
    for l111l in l1111l:
        l1l.append({l111l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬࢶ"): l1111l[l111l], l111l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧࢷ"): l111l})
    return l1l