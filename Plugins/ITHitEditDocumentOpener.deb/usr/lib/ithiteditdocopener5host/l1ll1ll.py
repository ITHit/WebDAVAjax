#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1lll1 = 2048
l111l = 7
def l1l1 (l1ll11):
    global l1
    l1l1l = ord (l1ll11 [-1])
    l11ll1 = l1ll11 [:-1]
    l11l11 = l1l1l % len (l11ll1)
    l1l11l = l11ll1 [:l11l11] + l11ll1 [l11l11:]
    if l1ll1:
        l1llll = l1l111 () .join ([unichr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    return eval (l1llll)
import subprocess, threading
from l11 import l1lll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l1l11():
    l11lll11 = [l1l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lll11:
        try:
            l11l11l1 = l1l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l111ll = winreg.l11l1l11(winreg.l11l111l, l11l11l1)
        except l1l11l11:
            continue
        value = winreg.l11lll1l(l1l111ll, l1l1 (u"ࠦࠧ࢓"))
        return value.split(l1l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11llll():
    l11l1ll1 = []
    for name in l1l1l111:
        try:
            l11l11l1 = l1l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll111 = winreg.l11l1l11(winreg.l11l111l, l11l11l1)
            if winreg.l11lll1l(l11ll111, l1l1 (u"ࠢࠣ࢖")):
                l11l1ll1.append(name)
        except l1l11l11:
            continue
    return l11l1ll1
def l11ll1l(l11l1, ll):
    import re
    l1111 = []
    l1l11ll1 = winreg.l11l1l11(winreg.l11l111l, l1l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll11l(l1l11ll1)[0]):
        try:
            l11l1l1l = winreg.l1l1111l(l1l11ll1, i)
            if l11l1l1l.startswith(ll):
                l11llll1 = winreg.l11l11ll(l1l11ll1, l11l1l1l)
                value, l11lllll = winreg.l1l111l1(l11llll1, l1l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll1l1 = {l1l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1111 = m.group(2)
                    if l11l1 == l11l1111:
                        m = re.search(ll.replace(l1l1 (u"ࠬ࠴࢛ࠧ"), l1l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1l1l)
                        l11ll1l1[l1l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1111.append(l11ll1l1)
                else:
                    raise ValueError(l1l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11l11 as ex:
            continue
    return l1111
def l11ll1ll(l11lll):
    try:
        l1l11lll = l1l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11lll)
        l1l11l1l = winreg.l11l1l11(winreg.l11l111l, l1l11lll)
        value, l11lllll = winreg.l1l111l1(l1l11l1l, l1l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11l11:
        pass
    return l1l1 (u"࠭ࠧࢣ")
def l11l1ll(l11lll, url):
    threading.Thread(target=_1l11111,args=(l11lll, url)).start()
    return l1l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11111(l11lll, url):
    logger = l1lll()
    l11l1lll = l11ll1ll(l11lll)
    logger.debug(l1l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1lll, url))
    retcode = subprocess.Popen(l1l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1lll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)