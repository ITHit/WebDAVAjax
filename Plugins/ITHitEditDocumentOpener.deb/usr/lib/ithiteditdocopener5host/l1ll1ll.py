#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
l1l111 = 2048
l1ll11 = 7
def l1l1 (l111l1):
    global l11ll
    l1111l = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l1ll1 = l1111l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l111:
        l11ll1 = l1111 () .join ([unichr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    else:
        l11ll1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    return eval (l11ll1)
import l1lll1
from l1l1l111 import l1l1l11l
import objc as _111ll11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll11.l1111111( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l111l1ll(l11111ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1 (u"ࠨࠩࢬ"), {l1l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111111l(l1111l1l):
    l1111l1l = (l1111l1l + l1l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l1111l1l, kCFStringEncodingUTF8 )
    l111l11l = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _111ll11.nil )
    l11111l1 = LaunchServices.l111l111( l111l11l, LaunchServices.l111l1l1, _111ll11.nil )
    if l11111l1[0] is not None:
        return True
    return False
def l1llll():
    l1111lll = []
    for name in l1l1l11l:
        try:
            if l111111l(name):
                l1111lll.append(name)
        except:
            continue
    return l1111lll
def l11l(l1ll1l, l1lll):
    import plistlib
    import os
    l1 = []
    l1l1l = {}
    for l1111ll1 in os.listdir(l1l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111ll1.startswith(l1lll):
            try:
                l111ll1l = l1l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111ll1
                with open(l111ll1l, l1l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1 = plist[l1l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l1l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll1l == l1111l11:
                        if not l11l1 in l1l1l:
                            l1l1l[l11l1] = version
                        elif l1lll1.l1l1l1(version, l1l1l[l11l1]) > 0:
                            l1l1l[l11l1] = version
            except BaseException:
                continue
    for l11l1 in l1l1l:
        l1.append({l1l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l1l[l11l1], l1l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1})
    return l1