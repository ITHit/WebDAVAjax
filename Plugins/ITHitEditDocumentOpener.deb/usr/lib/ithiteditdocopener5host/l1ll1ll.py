#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1l = 2048
l11 = 7
def l11l1 (l11l):
    global l111
    l11lll = ord (l11l [-1])
    l1ll1l = l11l [:-1]
    l111ll = l11lll % len (l1ll1l)
    l111l1 = l1ll1l [:l111ll] + l1ll1l [l111ll:]
    if l111l:
        l1ll = l1111l () .join ([unichr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    return eval (l1ll)
import l1
from l1l1l111 import l1l1l11l
import objc as _1111111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111111.l111111l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l111ll11(l111l11l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l11l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l1 (u"ࠨࠩࢬ"), {l11l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1ll(l111l1l1):
    l111l1l1 = (l111l1l1 + l11l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l11111l1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l1111l1l = CFURLCreateWithString( kCFAllocatorDefault, l11111l1, _1111111.nil )
    l1111ll1 = LaunchServices.l111llll( l1111l1l, LaunchServices.l11111ll, _1111111.nil )
    if l1111ll1[0] is not None:
        return True
    return False
def l1ll11():
    l111ll1l = []
    for name in l1l1l11l:
        try:
            if l111l1ll(name):
                l111ll1l.append(name)
        except:
            continue
    return l111ll1l
def l11l11(l11l1l, l1ll1):
    import plistlib
    import os
    l11ll1 = []
    l1l1l1 = {}
    for l111l111 in os.listdir(l11l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l111.startswith(l1ll1):
            try:
                l1111l11 = l11l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l111
                with open(l1111l11, l11l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l11l = plist[l11l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l11l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l1l == l111lll1:
                        if not l1l11l in l1l1l1:
                            l1l1l1[l1l11l] = version
                        elif l1.l1l1ll(version, l1l1l1[l1l11l]) > 0:
                            l1l1l1[l1l11l] = version
            except BaseException:
                continue
    for l1l11l in l1l1l1:
        l11ll1.append({l11l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l1l1[l1l11l], l11l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l11l})
    return l11ll1