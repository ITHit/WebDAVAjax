#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1l111 = 2048
l11ll1 = 7
def l1l1 (l11):
    global l1ll11
    l1llll = ord (l11 [-1])
    l1ll1 = l11 [:-1]
    l111l = l1llll % len (l1ll1)
    l1111l = l1ll1 [:l111l] + l1ll1 [l111l:]
    if l1l1l1:
        ll = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    else:
        ll = str () .join ([chr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    return eval (ll)
import l1l1ll
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l111l1ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111llll.l11111l1(l111ll11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1 (u"ࠨࠩࢬ"), {l1l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111111l(l1111111):
    l1111111 = (l1111111 + l1l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll1l = CFStringCreateWithCString( kCFAllocatorDefault, l1111111, kCFStringEncodingUTF8 )
    l111lll1 = CFURLCreateWithString( kCFAllocatorDefault, l111ll1l, _1111ll1.nil )
    l1111l11 = LaunchServices.l111l111( l111lll1, LaunchServices.l1111l1l, _1111ll1.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l11l():
    l111l1l1 = []
    for name in l1l1l111:
        try:
            if l111111l(name):
                l111l1l1.append(name)
        except:
            continue
    return l111l1l1
def l11l11(l11l1l, l1):
    import plistlib
    import os
    l1lll1 = []
    l111 = {}
    for l111l11l in os.listdir(l1l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l11l.startswith(l1):
            try:
                l11111ll = l1l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l11l
                with open(l11111ll, l1l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l = plist[l1l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111lll = version.split(l1l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l1l == l1111lll:
                        if not l1l in l111:
                            l111[l1l] = version
                        elif l1l1ll.l1ll(version, l111[l1l]) > 0:
                            l111[l1l] = version
            except BaseException:
                continue
    for l1l in l111:
        l1lll1.append({l1l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111[l1l], l1l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l})
    return l1lll1