#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l1l = 7
def l111 (l1ll):
    global l1l1l1
    l1l11 = ord (l1ll [-1])
    l1 = l1ll [:-1]
    l11lll = l1l11 % len (l1)
    l1l1ll = l1 [:l11lll] + l1 [l11lll:]
    if l1ll11:
        l1111l = l1ll1 () .join ([unichr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    return eval (l1111l)
import l1lll1
from l1l1l111 import l1l1l11l
import objc as _111l1l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1l1.l111ll11( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l11.l11111ll(l1111111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111 (u"ࠨࠩࢬ"), {l111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1ll(l111l111):
    l111l111 = (l111l111 + l111 (u"ࠩ࠽ࠫࢴ")).encode()
    l111lll1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l111, kCFStringEncodingUTF8 )
    l111llll = CFURLCreateWithString( kCFAllocatorDefault, l111lll1, _111l1l1.nil )
    l1111ll1 = LaunchServices.l111l11l( l111llll, LaunchServices.l111ll1l, _111l1l1.nil )
    if l1111ll1[0] is not None:
        return True
    return False
def l11l11():
    l1111l1l = []
    for name in l1l1l11l:
        try:
            if l111l1ll(name):
                l1111l1l.append(name)
        except:
            continue
    return l1111l1l
def l11ll(l1lll, l11l):
    import plistlib
    import os
    l1111 = []
    l1ll1l = {}
    for l1111lll in os.listdir(l111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111lll.startswith(l11l):
            try:
                l111111l = l111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111lll
                with open(l111111l, l111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l111l = plist[l111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l11111l1 = version.split(l111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1lll == l11111l1:
                        if not l111l in l1ll1l:
                            l1ll1l[l111l] = version
                        elif l1lll1.l1l11l(version, l1ll1l[l111l]) > 0:
                            l1ll1l[l111l] = version
            except BaseException:
                continue
    for l111l in l1ll1l:
        l1111.append({l111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1l[l111l], l111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l111l})
    return l1111