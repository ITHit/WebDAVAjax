#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
l1l111 = 2048
l1ll11 = 7
def l1l1 (l111l1):
    global l11ll
    l1111l = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l1ll1 = l1111l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l111:
        l11ll1 = l1111 () .join ([unichr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    else:
        l11ll1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    return eval (l11ll1)
import _winreg
import subprocess, threading
from l1lll1 import l1l
from l1l1l111 import l1l1l11l
def l1l1l1l():
    l1l11l1l = [l1l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11l1l:
        try:
            l11l11l1 = l1l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l111l1 = _winreg.l11llll1(_winreg.l11ll111, l11l11l1)
        except l1l111ll:
            continue
        value = _winreg.l1l1111l(l1l111l1, l1l1 (u"ࠦࠧ࢓"))
        return value.split(l1l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111l1l():
    l11lllll = []
    for name in l1l1l11l:
        try:
            l11l11l1 = l1l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1ll1 = _winreg.l11llll1(_winreg.l11ll111, l11l11l1)
            if _winreg.l1l1111l(l11l1ll1, l1l1 (u"ࠢࠣ࢖")):
                l11lllll.append(name)
        except l1l111ll:
            continue
    return l11lllll
def l11111(l1ll1l, l1lll):
    import re
    l1 = []
    l1l11ll1 = _winreg.l11llll1(_winreg.l11ll111, l1l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, _winreg.l1l11lll(l1l11ll1)[0]):
        try:
            l11ll1l1 = _winreg.l11l11ll(l1l11ll1, i)
            if l11ll1l1.startswith(l1lll):
                l1l11l11 = _winreg.l11ll1ll(l1l11ll1, l11ll1l1)
                value, l11lll1l = _winreg.l11lll11(l1l11l11, l1l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l111l = {l1l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11111 = m.group(2)
                    if l1ll1l == l1l11111:
                        m = re.search(l1lll.replace(l1l1 (u"ࠬ࠴࢛ࠧ"), l1l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1l1)
                        l11l111l[l1l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1.append(l11l111l)
                else:
                    raise ValueError(l1l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l111ll as ex:
            continue
    return l1
def l11l1l11(l11l1):
    try:
        l11ll11l = l1l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1)
        l11l1l1l = _winreg.l11llll1(_winreg.l11ll111, l11ll11l)
        value, l11lll1l = _winreg.l11lll11(l11l1l1l, l1l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1 (u"ࠬࠨࠧࢢ"))[1]
    except l1l111ll:
        pass
    return l1l1 (u"࠭ࠧࢣ")
def l1ll1l1(l11l1, url):
    threading.Thread(target=_11l1lll,args=(l11l1, url)).start()
    return l1l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1lll(l11l1, url):
    logger = l1l()
    l11l1111 = l11l1l11(l11l1)
    logger.debug(l1l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1111, url))
    retcode = subprocess.Popen(l1l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1111, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)