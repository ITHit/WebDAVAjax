#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l11l1l = 7
def l11ll (l1ll1):
    global l1l1l
    l1l11 = ord (l1ll1 [-1])
    l11l11 = l1ll1 [:-1]
    l1l111 = l1l11 % len (l11l11)
    l1ll1l = l11l11 [:l1l111] + l11l11 [l1l111:]
    if l1ll11:
        l1 = l11lll () .join ([unichr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    return eval (l1)
import subprocess, threading
from l1111 import l11l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l11ll():
    l11ll11l = [l11ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11ll11l:
        try:
            l11l11l1 = l11ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l11l1111(winreg.l11l1l11, l11l11l1)
        except l1l111ll:
            continue
        value = winreg.l11lll11(l11l1l1l, l11ll (u"ࠦࠧ࢓"))
        return value.split(l11ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll1ll():
    l11ll1ll = []
    for name in l1l1l111:
        try:
            l11l11l1 = l11ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l11ll = winreg.l11l1111(winreg.l11l1l11, l11l11l1)
            if winreg.l11lll11(l11l11ll, l11ll (u"ࠢࠣ࢖")):
                l11ll1ll.append(name)
        except l1l111ll:
            continue
    return l11ll1ll
def l1l1111(l111, l11ll1):
    import re
    ll = []
    l11llll1 = winreg.l11l1111(winreg.l11l1l11, l11ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lllll(l11llll1)[0]):
        try:
            l1l1111l = winreg.l11ll111(l11llll1, i)
            if l1l1111l.startswith(l11ll1):
                l11l1ll1 = winreg.l1l11l11(l11llll1, l1l1111l)
                value, l1l11111 = winreg.l1l111l1(l11l1ll1, l11ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll1l1 = {l11ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll1l = m.group(2)
                    if l111 == l11lll1l:
                        m = re.search(l11ll1.replace(l11ll (u"ࠬ࠴࢛ࠧ"), l11ll (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l1111l)
                        l11ll1l1[l11ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        ll.append(l11ll1l1)
                else:
                    raise ValueError(l11ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l111ll as ex:
            continue
    return ll
def l1l11lll(l1llll):
    try:
        l1l11l1l = l11ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1llll)
        l1l11ll1 = winreg.l11l1111(winreg.l11l1l11, l1l11l1l)
        value, l1l11111 = winreg.l1l111l1(l1l11ll1, l11ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll (u"ࠬࠨࠧࢢ"))[1]
    except l1l111ll:
        pass
    return l11ll (u"࠭ࠧࢣ")
def l11111(l1llll, url):
    threading.Thread(target=_11l1lll,args=(l1llll, url)).start()
    return l11ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1lll(l1llll, url):
    logger = l11l1()
    l11l111l = l1l11lll(l1llll)
    logger.debug(l11ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l111l, url))
    retcode = subprocess.Popen(l11ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l111l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)