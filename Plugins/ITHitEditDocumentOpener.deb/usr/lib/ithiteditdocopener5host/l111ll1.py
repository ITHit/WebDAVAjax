#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l111l = 2048
l1l = 7
def l11ll (l1111):
    global l11
    l111l1 = ord (l1111 [-1])
    l1l1ll = l1111 [:-1]
    l1l1 = l111l1 % len (l1l1ll)
    l111 = l1l1ll [:l1l1] + l1l1ll [l1l1:]
    if l1111l:
        l1l11l = l1 () .join ([unichr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    return eval (l1l11l)
import l1ll11
from l1l1l11l import l1l1l111
import objc as _111l1l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1l1.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l1l.l111ll11(l111l1ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll (u"ࠨࠩࢬ"), {l11ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111ll(l111l11l):
    l111l11l = (l111l11l + l11ll (u"ࠩ࠽ࠫࢴ")).encode()
    l1111111 = CFStringCreateWithCString( kCFAllocatorDefault, l111l11l, kCFStringEncodingUTF8 )
    l111l111 = CFURLCreateWithString( kCFAllocatorDefault, l1111111, _111l1l1.nil )
    l111111l = LaunchServices.l111ll1l( l111l111, LaunchServices.l11111l1, _111l1l1.nil )
    if l111111l[0] is not None:
        return True
    return False
def l1ll1l():
    l111llll = []
    for name in l1l1l111:
        try:
            if l11111ll(name):
                l111llll.append(name)
        except:
            continue
    return l111llll
def l1lll1(l11lll, l1l1l):
    import plistlib
    import os
    l111ll = []
    l1l1l1 = {}
    for l1111ll1 in os.listdir(l11ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111ll1.startswith(l1l1l):
            try:
                l1111l11 = l11ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111ll1
                with open(l1111l11, l11ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l11 = plist[l11ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111lll = version.split(l11ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11lll == l1111lll:
                        if not l1l11 in l1l1l1:
                            l1l1l1[l1l11] = version
                        elif l1ll11.l1ll(version, l1l1l1[l1l11]) > 0:
                            l1l1l1[l1l11] = version
            except BaseException:
                continue
    for l1l11 in l1l1l1:
        l111ll.append({l11ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l1l1[l1l11], l11ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l11})
    return l111ll