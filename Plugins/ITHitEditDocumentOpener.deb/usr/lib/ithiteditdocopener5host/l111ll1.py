#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111ll (l1l1l):
    global l11ll
    l1111l = ord (l1l1l [-1])
    l11l = l1l1l [:-1]
    l11l1l = l1111l % len (l11l)
    l1l11l = l11l [:l11l1l] + l11l [l11l1l:]
    if l1ll11:
        l1ll1l = l1l1l1 () .join ([unichr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import subprocess, threading
from l111l1 import l1l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1llll1():
    l11l11l1 = [l111ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l111ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l111ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l111ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l11l1:
        try:
            l1l11111 = l111ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11ll1 = winreg.l11ll1l1(winreg.l11ll111, l1l11111)
        except l11l1111:
            continue
        value = winreg.l1l1111l(l1l11ll1, l111ll (u"ࠦࠧ࢓"))
        return value.split(l111ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11llll():
    l11l1l1l = []
    for name in l1l1l11l:
        try:
            l1l11111 = l111ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l11 = winreg.l11ll1l1(winreg.l11ll111, l1l11111)
            if winreg.l1l1111l(l1l11l11, l111ll (u"ࠢࠣ࢖")):
                l11l1l1l.append(name)
        except l11l1111:
            continue
    return l11l1l1l
def l1ll111(l1l11, l11l1):
    import re
    l1 = []
    l11llll1 = winreg.l11ll1l1(winreg.l11ll111, l111ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lllll(l11llll1)[0]):
        try:
            l1l111ll = winreg.l11l11ll(l11llll1, i)
            if l1l111ll.startswith(l11l1):
                l11l1ll1 = winreg.l1l11lll(l11llll1, l1l111ll)
                value, l1l11l1l = winreg.l11ll1ll(l11l1ll1, l111ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l111ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l111l = {l111ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll11 = m.group(2)
                    if l1l11 == l11lll11:
                        m = re.search(l11l1.replace(l111ll (u"ࠬ࠴࢛ࠧ"), l111ll (u"࠭࡜࡝࠰ࠪ࢜")) + l111ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l111ll)
                        l11l111l[l111ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1.append(l11l111l)
                else:
                    raise ValueError(l111ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1111 as ex:
            continue
    return l1
def l11l1l11(l1lll1):
    try:
        l11ll11l = l111ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1lll1)
        l11l1lll = winreg.l11ll1l1(winreg.l11ll111, l11ll11l)
        value, l1l11l1l = winreg.l11ll1ll(l11l1lll, l111ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l111ll (u"ࠬࠨࠧࢢ"))[1]
    except l11l1111:
        pass
    return l111ll (u"࠭ࠧࢣ")
def l11l1l1(l1lll1, url):
    threading.Thread(target=_11lll1l,args=(l1lll1, url)).start()
    return l111ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lll1l(l1lll1, url):
    logger = l1l1()
    l1l111l1 = l11l1l11(l1lll1)
    logger.debug(l111ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l111l1, url))
    retcode = subprocess.Popen(l111ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l111l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l111ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l111ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)