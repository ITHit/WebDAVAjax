#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1111l = 2048
ll = 7
def l1ll (l11l):
    global l1l111
    l1lll = ord (l11l [-1])
    l1l1l1 = l11l [:-1]
    l111l1 = l1lll % len (l1l1l1)
    l11l1 = l1l1l1 [:l111l1] + l1l1l1 [l111l1:]
    if l111l:
        l1l1ll = l111 () .join ([unichr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    return eval (l1l1ll)
import subprocess, threading
from l11l1l import l11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l1111():
    l11l111l = [l1ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l111l:
        try:
            l11l1lll = l1ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l11l11ll(winreg.l1l111l1, l11l1lll)
        except l11l1l11:
            continue
        value = winreg.l11l1111(l11l1l1l, l1ll (u"ࠦࠧ࢓"))
        return value.split(l1ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1111ll():
    l1l11lll = []
    for name in l1l1l11l:
        try:
            l11l1lll = l1ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l11 = winreg.l11l11ll(winreg.l1l111l1, l11l1lll)
            if winreg.l11l1111(l1l11l11, l1ll (u"ࠢࠣ࢖")):
                l1l11lll.append(name)
        except l11l1l11:
            continue
    return l1l11lll
def l11ll11(l111ll, l1l):
    import re
    l1l1 = []
    l1l11l1l = winreg.l11l11ll(winreg.l1l111l1, l1ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11llll1(l1l11l1l)[0]):
        try:
            l11lll1l = winreg.l11l1ll1(l1l11l1l, i)
            if l11lll1l.startswith(l1l):
                l11ll11l = winreg.l11ll1l1(l1l11l1l, l11lll1l)
                value, l11ll1ll = winreg.l1l11111(l11ll11l, l1ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11l1 = {l1ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll111 = m.group(2)
                    if l111ll == l11ll111:
                        m = re.search(l1l.replace(l1ll (u"ࠬ࠴࢛ࠧ"), l1ll (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll1l)
                        l11l11l1[l1ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1.append(l11l11l1)
                else:
                    raise ValueError(l1ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1l11 as ex:
            continue
    return l1l1
def l11lllll(l1l11l):
    try:
        l1l11ll1 = l1ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11l)
        l1l111ll = winreg.l11l11ll(winreg.l1l111l1, l1l11ll1)
        value, l11ll1ll = winreg.l1l11111(l1l111ll, l1ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll (u"ࠬࠨࠧࢢ"))[1]
    except l11l1l11:
        pass
    return l1ll (u"࠭ࠧࢣ")
def l111l11(l1l11l, url):
    threading.Thread(target=_1l1111l,args=(l1l11l, url)).start()
    return l1ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l1111l(l1l11l, url):
    logger = l11()
    l11lll11 = l11lllll(l1l11l)
    logger.debug(l1ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lll11, url))
    retcode = subprocess.Popen(l1ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lll11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)