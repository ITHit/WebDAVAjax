#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1l1 (l1l):
    global l1l1l
    l11l = ord (l1l [-1])
    l11lll = l1l [:-1]
    l1lll = l11l % len (l11lll)
    l1ll = l11lll [:l1lll] + l11lll [l1lll:]
    if l1l11l:
        l1ll11 = l1lll1 () .join ([unichr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    return eval (l1ll11)
import _winreg
import subprocess, threading
from l1l11 import l11l11
from l1l1l111 import l1l1l11l
def l1l1lll():
    l11l111l = [l1l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l111l:
        try:
            l1l111l1 = l1l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l1111l = _winreg.l1l11111(_winreg.l1l11l1l, l1l111l1)
        except l11ll111:
            continue
        value = _winreg.l1l11lll(l1l1111l, l1l1 (u"ࠦࠧ࢓"))
        return value.split(l1l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1lll11():
    l11l1l1l = []
    for name in l1l1l11l:
        try:
            l1l111l1 = l1l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1ll1 = _winreg.l1l11111(_winreg.l1l11l1l, l1l111l1)
            if _winreg.l1l11lll(l11l1ll1, l1l1 (u"ࠢࠣ࢖")):
                l11l1l1l.append(name)
        except l11ll111:
            continue
    return l11l1l1l
def l11l11l(l1, l111l1):
    import re
    l11ll = []
    l11lllll = _winreg.l1l11111(_winreg.l1l11l1l, l1l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, _winreg.l11l11ll(l11lllll)[0]):
        try:
            l11ll1l1 = _winreg.l11l11l1(l11lllll, i)
            if l11ll1l1.startswith(l111l1):
                l11lll11 = _winreg.l1l11l11(l11lllll, l11ll1l1)
                value, l11l1111 = _winreg.l1l11ll1(l11lll11, l1l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll11l = {l1l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11llll1 = m.group(2)
                    if l1 == l11llll1:
                        m = re.search(l111l1.replace(l1l1 (u"ࠬ࠴࢛ࠧ"), l1l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1l1)
                        l11ll11l[l1l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11ll.append(l11ll11l)
                else:
                    raise ValueError(l1l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll111 as ex:
            continue
    return l11ll
def l11lll1l(l11l1l):
    try:
        l1l111ll = l1l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1l)
        l11l1lll = _winreg.l1l11111(_winreg.l1l11l1l, l1l111ll)
        value, l11l1111 = _winreg.l1l11ll1(l11l1lll, l1l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1 (u"ࠬࠨࠧࢢ"))[1]
    except l11ll111:
        pass
    return l1l1 (u"࠭ࠧࢣ")
def l11lll1(l11l1l, url):
    threading.Thread(target=_11ll1ll,args=(l11l1l, url)).start()
    return l1l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll1ll(l11l1l, url):
    logger = l11l11()
    l11l1l11 = l11lll1l(l11l1l)
    logger.debug(l1l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1l11, url))
    retcode = subprocess.Popen(l1l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)