#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l1llll = 2048
l1l11 = 7
def l1ll1 (l1ll11):
    global l1l1l1
    l1111 = ord (l1ll11 [-1])
    ll = l1ll11 [:-1]
    l111l = l1111 % len (ll)
    l11l1l = ll [:l111l] + ll [l111l:]
    if l1l1:
        l11l = l111ll () .join ([unichr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    return eval (l11l)
import l1l1ll
from l1l1l11l import l1l1l111
import objc as _11111l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11111l1.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l111111l(l1111l11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll1 (u"ࠨࠩࢬ"), {l1ll1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l111l1l1):
    l111l1l1 = (l111l1l1 + l1ll1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111l11l = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l111l11l, _11111l1.nil )
    l111l111 = LaunchServices.l111llll( l111ll11, LaunchServices.l1111ll1, _11111l1.nil )
    if l111l111[0] is not None:
        return True
    return False
def l11l1():
    l11111ll = []
    for name in l1l1l111:
        try:
            if l1111l1l(name):
                l11111ll.append(name)
        except:
            continue
    return l11111ll
def l111l1(l1l11l, l1l):
    import plistlib
    import os
    l11l11 = []
    l1lll1 = {}
    for l111ll1l in os.listdir(l1ll1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(l1l):
            try:
                l111l1ll = l1ll1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l111l1ll, l1ll1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11lll = plist[l1ll1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l1ll1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l11l == l1111111:
                        if not l11lll in l1lll1:
                            l1lll1[l11lll] = version
                        elif l1l1ll.l11ll1(version, l1lll1[l11lll]) > 0:
                            l1lll1[l11lll] = version
            except BaseException:
                continue
    for l11lll in l1lll1:
        l11l11.append({l1ll1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll1[l11lll], l1ll1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11lll})
    return l11l11