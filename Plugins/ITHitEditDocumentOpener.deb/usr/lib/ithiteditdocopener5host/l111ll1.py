#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1111 (l111ll):
    global l11ll1
    l1l1l = ord (l111ll [-1])
    l1 = l111ll [:-1]
    l1llll = l1l1l % len (l1)
    l111l = l1 [:l1llll] + l1 [l1llll:]
    if l11l1:
        l11l = l1ll11 () .join ([unichr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    return eval (l11l)
import l1ll1
from l1l1l11l import l1l1l111
import objc as _111llll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111llll.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l111.l111ll11(l1111l1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1111 (u"ࠨࠩࢬ"), {l1111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111l1(l111l1ll):
    l111l1ll = (l111l1ll + l1111 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111111 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l1111111, _111llll.nil )
    l111l11l = LaunchServices.l1111ll1( l11111ll, LaunchServices.l1111lll, _111llll.nil )
    if l111l11l[0] is not None:
        return True
    return False
def l11l11():
    l111l1l1 = []
    for name in l1l1l111:
        try:
            if l11111l1(name):
                l111l1l1.append(name)
        except:
            continue
    return l111l1l1
def l11lll(l111l1, l1l111):
    import plistlib
    import os
    l1ll = []
    l111 = {}
    for l111ll1l in os.listdir(l1111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(l1l111):
            try:
                l1111l11 = l1111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l1111l11, l1111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1lll = plist[l1111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111111l = version.split(l1111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111l1 == l111111l:
                        if not l1lll in l111:
                            l111[l1lll] = version
                        elif l1ll1.l1l(version, l111[l1lll]) > 0:
                            l111[l1lll] = version
            except BaseException:
                continue
    for l1lll in l111:
        l1ll.append({l1111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111[l1lll], l1111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1lll})
    return l1ll