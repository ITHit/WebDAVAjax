#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l1llll = 2048
l1l11 = 7
def l1ll1 (l1ll11):
    global l1l1l1
    l1111 = ord (l1ll11 [-1])
    ll = l1ll11 [:-1]
    l111l = l1111 % len (ll)
    l11l1l = ll [:l111l] + ll [l111l:]
    if l1l1:
        l11l = l111ll () .join ([unichr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    return eval (l11l)
import subprocess, threading
from l1l1ll import l1lll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1lll1l():
    l1l111ll = [l1ll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l111ll:
        try:
            l11llll1 = l1ll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l1l11l1l(winreg.l1l11lll, l11llll1)
        except l1l1111l:
            continue
        value = winreg.l11l1l11(l11l1l1l, l1ll1 (u"ࠦࠧ࢓"))
        return value.split(l1ll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1ll1():
    l11l1ll1 = []
    for name in l1l1l111:
        try:
            l11llll1 = l1ll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lll11 = winreg.l1l11l1l(winreg.l1l11lll, l11llll1)
            if winreg.l11l1l11(l11lll11, l1ll1 (u"ࠢࠣ࢖")):
                l11l1ll1.append(name)
        except l1l1111l:
            continue
    return l11l1ll1
def l1lll11(l1l11l, l1l):
    import re
    l11l11 = []
    l1l11ll1 = winreg.l1l11l1l(winreg.l1l11lll, l1ll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l111l1(l1l11ll1)[0]):
        try:
            l11ll1ll = winreg.l1l11l11(l1l11ll1, i)
            if l11ll1ll.startswith(l1l):
                l11ll11l = winreg.l11lllll(l1l11ll1, l11ll1ll)
                value, l11ll1l1 = winreg.l1l11111(l11ll11l, l1ll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l111l = {l1ll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll1l = m.group(2)
                    if l1l11l == l11lll1l:
                        m = re.search(l1l.replace(l1ll1 (u"ࠬ࠴࢛ࠧ"), l1ll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1ll)
                        l11l111l[l1ll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l11.append(l11l111l)
                else:
                    raise ValueError(l1ll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l1111l as ex:
            continue
    return l11l11
def l11l1lll(l11lll):
    try:
        l11l11ll = l1ll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11lll)
        l11l11l1 = winreg.l1l11l1l(winreg.l1l11lll, l11l11ll)
        value, l11ll1l1 = winreg.l1l11111(l11l11l1, l1ll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll1 (u"ࠬࠨࠧࢢ"))[1]
    except l1l1111l:
        pass
    return l1ll1 (u"࠭ࠧࢣ")
def l1l1l11(l11lll, url):
    threading.Thread(target=_11ll111,args=(l11lll, url)).start()
    return l1ll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll111(l11lll, url):
    logger = l1lll()
    l11l1111 = l11l1lll(l11lll)
    logger.debug(l1ll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1111, url))
    retcode = subprocess.Popen(l1ll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1111, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)