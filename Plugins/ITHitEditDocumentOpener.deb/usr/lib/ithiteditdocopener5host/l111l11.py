#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1l1ll = 2048
l1l1l1 = 7
def l1111 (l1ll):
    global l1ll1
    l1l = ord (l1ll [-1])
    l1lll1 = l1ll [:-1]
    l1llll = l1l % len (l1lll1)
    l1 = l1lll1 [:l1llll] + l1lll1 [l1llll:]
    if l111ll:
        l111l = l11l1l () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    else:
        l111l = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    return eval (l111l)
import l1lll
from l1l1l111 import l1l1l11l
import objc as _111l111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l111.l111111l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l1111l11(l1111ll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111ll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1111 (u"ࠨࠩࢬ"), {l1111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l111l1ll):
    l111l1ll = (l111l1ll + l1111 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111111 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l111ll1l = CFURLCreateWithString( kCFAllocatorDefault, l1111111, _111l111.nil )
    l1111l1l = LaunchServices.l1111lll( l111ll1l, LaunchServices.l111llll, _111l111.nil )
    if l1111l1l[0] is not None:
        return True
    return False
def l1ll11():
    l11111ll = []
    for name in l1l1l11l:
        try:
            if l111l11l(name):
                l11111ll.append(name)
        except:
            continue
    return l11111ll
def l1l11(l111l1, l1l1):
    import plistlib
    import os
    l11l1 = []
    l11ll1 = {}
    for l111l1l1 in os.listdir(l1111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l1l1):
            try:
                l111ll11 = l1111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l111ll11, l1111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1l = plist[l1111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l11111l1 = version.split(l1111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111l1 == l11111l1:
                        if not l1l1l in l11ll1:
                            l11ll1[l1l1l] = version
                        elif l1lll.l11l(version, l11ll1[l1l1l]) > 0:
                            l11ll1[l1l1l] = version
            except BaseException:
                continue
    for l1l1l in l11ll1:
        l11l1.append({l1111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11ll1[l1l1l], l1111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1l})
    return l11l1