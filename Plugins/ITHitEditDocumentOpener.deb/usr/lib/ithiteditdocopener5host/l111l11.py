#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1l1ll = 2048
l111 = 7
def l111l (l111l1):
    global l1lll
    l11l11 = ord (l111l1 [-1])
    l1111 = l111l1 [:-1]
    l11l = l11l11 % len (l1111)
    l1l1l1 = l1111 [:l11l] + l1111 [l11l:]
    if l11ll:
        l1l11l = l11lll () .join ([unichr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    return eval (l1l11l)
import ll
from l1l1l11l import l1l1l111
import objc as _111l1ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1ll.l1111l11( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111111.l111lll1(l111l1l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111l (u"ࠨࠩࢬ"), {l111l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111ll1(l11111ll):
    l11111ll = (l11111ll + l111l (u"ࠩ࠽ࠫࢴ")).encode()
    l111l11l = CFStringCreateWithCString( kCFAllocatorDefault, l11111ll, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l111l11l, _111l1ll.nil )
    l1111lll = LaunchServices.l111l111( l111111l, LaunchServices.l111ll11, _111l1ll.nil )
    if l1111lll[0] is not None:
        return True
    return False
def l1ll1():
    l1111l1l = []
    for name in l1l1l111:
        try:
            if l1111ll1(name):
                l1111l1l.append(name)
        except:
            continue
    return l1111l1l
def l111ll(l1llll, l1ll):
    import plistlib
    import os
    l1l1l = []
    l1111l = {}
    for l11111l1 in os.listdir(l111l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111l1.startswith(l1ll):
            try:
                l111ll1l = l111l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111l1
                with open(l111ll1l, l111l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll11 = plist[l111l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111llll = version.split(l111l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1llll == l111llll:
                        if not l1ll11 in l1111l:
                            l1111l[l1ll11] = version
                        elif ll.l1l1(version, l1111l[l1ll11]) > 0:
                            l1111l[l1ll11] = version
            except BaseException:
                continue
    for l1ll11 in l1111l:
        l1l1l.append({l111l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111l[l1ll11], l111l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll11})
    return l1l1l