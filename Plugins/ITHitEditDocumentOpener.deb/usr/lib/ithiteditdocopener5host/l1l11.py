#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1lll = 7
def l1l1 (l1lll1):
    global l1l1l
    l111ll = ord (l1lll1 [-1])
    l11l = l1lll1 [:-1]
    l111 = l111ll % len (l11l)
    l1l11l = l11l [:l111] + l11l [l111:]
    if l1llll:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111ll1(l1lll11=None):
    if platform.system() == l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1lllll
        props = {}
        try:
            prop_names = (l1l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11ll1l = l1lllll.l11llll(l1lll11, l1l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1lll1l in prop_names:
                l1l11l1 = l1l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11ll1l, l1lll1l)
                props[l1lll1l] = l1lllll.l11llll(l1lll11, l1l11l1)
        except:
            pass
    return props
def l1ll1l1(logger, l1llllll):
    l111l1l = os.environ.get(l1l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111l1l = l111l1l.upper()
    if l111l1l == l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1111 = logging.DEBUG
    elif l111l1l == l1l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1111 = logging.INFO
    elif l111l1l == l1l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1111 = logging.WARNING
    elif l111l1l == l1l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1111 = logging.ERROR
    elif l111l1l == l1l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1111 = logging.CRITICAL
    elif l111l1l == l1l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1111 = logging.NOTSET
    logger.setLevel(l1l1111)
    l1ll11l = RotatingFileHandler(l1llllll, maxBytes=1024*1024*5, backupCount=3)
    l1ll11l.setLevel(l1l1111)
    formatter = logging.Formatter(l1l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll11l.setFormatter(formatter)
    logger.addHandler(l1ll11l)
    globals()[l1l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11():
    return globals()[l1l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111l11():
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1lll
        l1l1lll.l1l1l1l(sys.stdin.fileno(), os.l11l1l1)
        l1l1lll.l1l1l1l(sys.stdout.fileno(), os.l11l1l1)
def l11l111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11lll1():
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1111ll
        return l1111ll.l1111l1()
    elif platform.system() == l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1111ll
        return l1111ll.l1l111l()
    elif platform.system() == l1l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l1ll
        return l1l1ll.l1()
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11ll11
        return l11ll11.l1()
    return l1l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111111(l11lll, l1l1l1):
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1111ll
        return l1111ll.l1ll1ll(l11lll, l1l1l1)
    elif platform.system() == l1l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11ll11
        return l11ll11.l1l(l11lll, l1l1l1)
    elif platform.system() == l1l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l1ll
        return l1l1ll.l1l(l11lll, l1l1l1)
    raise ValueError(l1l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1llll1(l11l1l, url):
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1111ll
        return l1111ll.l11l1ll(l11l1l, url)
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11ll11
        return l1l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l1ll
        return l1l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111lll():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1111ll
        return l1111ll.l111lll()
def l1l11ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll111(l1ll1):
    l1l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111l = l1l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1:
        if l1l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111l[3:]) < int(protocol[l1l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111l = protocol[l1l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111l
def ll(l11111, l11l11l):
    l1l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11111 is None: l11111 = l1l1 (u"ࠩ࠳ࠫ࠽");
    if l11l11l is None: l11l11l = l1l1 (u"ࠪ࠴ࠬ࠾");
    l1l1ll1 = l11111.split(l1l1 (u"ࠫ࠳࠭࠿"))
    l1l1l11 = l11l11l.split(l1l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1ll1) < len(l1l1l11): l1l1ll1.append(l1l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1l11) < len(l1l1ll1): l1l1l11.append(l1l1 (u"ࠢ࠱ࠤࡂ"));
    l1l1ll1 = [ int(x) for x in l1l1ll1 ]
    l1l1l11 = [ int(x) for x in l1l1l11 ]
    for  i in range(len(l1l1ll1)):
        if len(l1l1l11) == i:
            return 1
        if l1l1ll1[i] == l1l1l11[i]:
            continue
        elif l1l1ll1[i] > l1l1l11[i]:
            return 1
        else:
            return -1
    if len(l1l1ll1) != len(l1l1l11):
        return -1
    return 0