#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111ll = 2048
l1l1l = 7
def l1ll11 (l1l1ll):
    global l11l1l
    l111l = ord (l1l1ll [-1])
    l11l11 = l1l1ll [:-1]
    l1l = l111l % len (l11l11)
    l1llll = l11l11 [:l1l] + l11l11 [l1l:]
    if l1lll1:
        l1111l = l1l11l () .join ([unichr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    return eval (l1111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111111(l1lllll=None):
    if platform.system() == l1ll11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1l1l
        props = {}
        try:
            prop_names = (l1ll11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111 = l1l1l1l.l11ll11(l1lllll, l1ll11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11llll in prop_names:
                l111ll1 = l1ll11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111, l11llll)
                props[l11llll] = l1l1l1l.l11ll11(l1lllll, l111ll1)
        except:
            pass
    return props
def l11l11l(logger, l1l11l1):
    l1l1l11 = os.environ.get(l1ll11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l11 = l1l1l11.upper()
    if l1l1l11 == l1ll11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l111l = logging.DEBUG
    elif l1l1l11 == l1ll11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l111l = logging.INFO
    elif l1l1l11 == l1ll11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l111l = logging.WARNING
    elif l1l1l11 == l1ll11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l111l = logging.ERROR
    elif l1l1l11 == l1ll11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l111l = logging.CRITICAL
    elif l1l1l11 == l1ll11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l111l = logging.NOTSET
    logger.setLevel(l1l111l)
    l1l1111 = RotatingFileHandler(l1l11l1, maxBytes=1024*1024*5, backupCount=3)
    l1l1111.setLevel(l1l111l)
    formatter = logging.Formatter(l1ll11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1111.setFormatter(formatter)
    logger.addHandler(l1l1111)
    globals()[l1ll11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1():
    return globals()[l1ll11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111lll():
    if platform.system() == l1ll11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll1ll
        l1ll1ll.l11111l(sys.stdin.fileno(), os.l1lll11)
        l1ll1ll.l11111l(sys.stdout.fileno(), os.l1lll11)
def l11l1ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1lll():
    if platform.system() == l1ll11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l1ll1
        return l1l1ll1.l11l111()
    elif platform.system() == l1ll11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def ll():
    if platform.system() == l1ll11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l1ll1
        return l1l1ll1.l111l11()
    elif platform.system() == l1ll11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1111
        return l1111.ll()
    elif platform.system() == l1ll11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11lll1
        return l11lll1.ll()
    return l1ll11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111l1l(l1l1, l11l1):
    if platform.system() == l1ll11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l1ll1
        return l1l1ll1.l1ll111(l1l1, l11l1)
    elif platform.system() == l1ll11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11lll1
        return l11lll1.l11ll(l1l1, l11l1)
    elif platform.system() == l1ll11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1111
        return l1111.l11ll(l1l1, l11l1)
    raise ValueError(l1ll11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1111ll(l1l111, url):
    if platform.system() == l1ll11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l1ll1
        return l1l1ll1.l1llllll(l1l111, url)
    elif platform.system() == l1ll11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11lll1
        return l1ll11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1111
        return l1ll11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11l1l1():
    if platform.system() == l1ll11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l1ll1
        return l1l1ll1.l11l1l1()
def l1llll1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll11 (u"ࠩ࠱ࠫ࠶"))[0]
def l11ll1l(l1l1l1):
    l1ll11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1111l1 = l1ll11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l1l1:
        if l1ll11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1111l1[3:]) < int(protocol[l1ll11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1111l1 = protocol[l1ll11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1111l1
def l1ll1(l1ll11l, l1l11ll):
    l1ll11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll11l is None: l1ll11l = l1ll11 (u"ࠩ࠳ࠫ࠽");
    if l1l11ll is None: l1l11ll = l1ll11 (u"ࠪ࠴ࠬ࠾");
    l1ll1l1 = l1ll11l.split(l1ll11 (u"ࠫ࠳࠭࠿"))
    l1lll1l = l1l11ll.split(l1ll11 (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll1l1) < len(l1lll1l): l1ll1l1.append(l1ll11 (u"ࠨ࠰ࠣࡁ"));
    while len(l1lll1l) < len(l1ll1l1): l1lll1l.append(l1ll11 (u"ࠢ࠱ࠤࡂ"));
    l1ll1l1 = [ int(x) for x in l1ll1l1 ]
    l1lll1l = [ int(x) for x in l1lll1l ]
    for  i in range(len(l1ll1l1)):
        if len(l1lll1l) == i:
            return 1
        if l1ll1l1[i] == l1lll1l[i]:
            continue
        elif l1ll1l1[i] > l1lll1l[i]:
            return 1
        else:
            return -1
    if len(l1ll1l1) != len(l1lll1l):
        return -1
    return 0