#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1l = 2048
l1111 = 7
def l1ll (l11l):
    global l1ll1l
    l1lll1 = ord (l11l [-1])
    l1lll = l11l [:-1]
    ll = l1lll1 % len (l1lll)
    l1ll1 = l1lll [:ll] + l1lll [ll:]
    if l11l1:
        l1llll = l1l1 () .join ([unichr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    return eval (l1llll)
import os
import re
import subprocess
import l111l1
from l111l1 import l11lll
def l1l11l():
    return []
def l1l111(l11ll, l11ll1):
    logger = l11lll()
    l111 = []
    l111l = [l1ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11 = process.wait()
            l11l11 = {}
            if l11 == 0:
                l11l1l = re.compile(l1ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1l1 = re.compile(l1ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1 = re.search(l11l1l, line)
                    l1ll11 = l1.group(1)
                    if l11ll == l1ll11:
                        l1l = re.search(l1l1l1, line)
                        if l1l:
                            l1111l = l1ll (u"ࠨࡦࡤࡺࠬࠄ")+l1l.group(1)
                            version = l1.group(0)
                            if not l1111l in l11l11:
                                l11l11[l1111l] = version
                            elif l111l1.l1l1ll(version, l11l11[l1111l]) > 0:
                                l11l11[l1111l] = version
            for l1111l in l11l11:
                l111.append({l1ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l11[l1111l], l1ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1111l})
        except Exception as e:
            logger.error(str(e))
    return l111