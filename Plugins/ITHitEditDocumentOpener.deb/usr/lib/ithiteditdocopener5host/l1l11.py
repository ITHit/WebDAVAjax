#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1l111 = 2048
l11ll1 = 7
def l1l1 (l11):
    global l1ll11
    l1llll = ord (l11 [-1])
    l1ll1 = l11 [:-1]
    l111l = l1llll % len (l1ll1)
    l1111l = l1ll1 [:l111l] + l1ll1 [l111l:]
    if l1l1l1:
        ll = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    else:
        ll = str () .join ([chr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    return eval (ll)
import os
import re
import subprocess
import l1l1ll
from l1l1ll import l11lll
def l11l():
    return []
def l11l11(l11l1l, l1):
    logger = l11lll()
    l1lll1 = []
    l111ll = [l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            l111 = {}
            if l111l1 == 0:
                l1111 = re.compile(l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll = re.compile(l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1 = re.search(l1111, line)
                    l1ll1l = l11l1.group(1)
                    if l11l1l == l1ll1l:
                        l1l11l = re.search(l11ll, line)
                        if l1l11l:
                            l1l = l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1l11l.group(1)
                            version = l11l1.group(0)
                            if not l1l in l111:
                                l111[l1l] = version
                            elif l1l1ll.l1ll(version, l111[l1l]) > 0:
                                l111[l1l] = version
            for l1l in l111:
                l1lll1.append({l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111[l1l], l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l})
        except Exception as e:
            logger.error(str(e))
    return l1lll1