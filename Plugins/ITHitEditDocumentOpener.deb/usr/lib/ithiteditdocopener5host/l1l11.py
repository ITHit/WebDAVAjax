#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1lll1 (l11):
    global l11l11
    l1111l = ord (l11 [-1])
    l1lll = l11 [:-1]
    l1l1ll = l1111l % len (l1lll)
    l1l = l1lll [:l1l1ll] + l1lll [l1l1ll:]
    if l1:
        l11ll = l1111 () .join ([unichr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    return eval (l11ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111l11(l1ll11l=None):
    if platform.system() == l1lll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll111
        props = {}
        try:
            prop_names = (l1lll1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1lll1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1lll1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1lll1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1lll1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1lll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1lll1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1lll1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1lll1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1lll1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1lll1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1lll1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l1lll = l1ll111.l1ll1ll(l1ll11l, l1lll1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1lll11 in prop_names:
                l1111l1 = l1lll1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l1lll, l1lll11)
                props[l1lll11] = l1ll111.l1ll1ll(l1ll11l, l1111l1)
        except:
            pass
    return props
def l11l1ll(logger, l11llll):
    l1l111l = os.environ.get(l1lll1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1lll1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l111l = l1l111l.upper()
    if l1l111l == l1lll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11lll1 = logging.DEBUG
    elif l1l111l == l1lll1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11lll1 = logging.INFO
    elif l1l111l == l1lll1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11lll1 = logging.WARNING
    elif l1l111l == l1lll1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11lll1 = logging.ERROR
    elif l1l111l == l1lll1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11lll1 = logging.CRITICAL
    elif l1l111l == l1lll1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11lll1 = logging.NOTSET
    logger.setLevel(l11lll1)
    l11l11l = RotatingFileHandler(l11llll, maxBytes=1024*1024*5, backupCount=3)
    l11l11l.setLevel(l11lll1)
    formatter = logging.Formatter(l1lll1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l11l.setFormatter(formatter)
    logger.addHandler(l11l11l)
    globals()[l1lll1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11lll():
    return globals()[l1lll1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111lll():
    if platform.system() == l1lll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1lll1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1ll1
        l1l1ll1.l1llllll(sys.stdin.fileno(), os.l1111ll)
        l1l1ll1.l1llllll(sys.stdout.fileno(), os.l1111ll)
def l1lllll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1lll1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    if platform.system() == l1lll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l11ll
        return l1l11ll.l111ll1()
    elif platform.system() == l1lll1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1lll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l111():
    if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l11ll
        return l1l11ll.l1llll1()
    elif platform.system() == l1lll1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11ll1
        return l11ll1.l111()
    elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1l1l
        return l1l1l1l.l111()
    return l1lll1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l11l1(l1l1, l111ll):
    if platform.system() == l1lll1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l11ll
        return l1l11ll.l1l1l11(l1l1, l111ll)
    elif platform.system() == l1lll1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1l1l
        return l1l1l1l.l1l111(l1l1, l111ll)
    elif platform.system() == l1lll1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11ll1
        return l11ll1.l1l111(l1l1, l111ll)
    raise ValueError(l1lll1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l1l1(l11l, url):
    if platform.system() == l1lll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l11ll
        return l1l11ll.l11ll1l(l11l, url)
    elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1l1l
        return l1lll1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1lll1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11ll1
        return l1lll1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1lll1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111l1l():
    if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l11ll
        return l1l11ll.l111l1l()
def l11l111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1lll1 (u"ࠩ࠱ࠫ࠶"))[0]
def l11111(l1ll11):
    l1lll1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1111 = l1lll1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll11:
        if l1lll1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1111[3:]) < int(protocol[l1lll1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1111 = protocol[l1lll1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1111
def l1l1l(l11ll11, l111111):
    l1lll1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11ll11 is None: l11ll11 = l1lll1 (u"ࠩ࠳ࠫ࠽");
    if l111111 is None: l111111 = l1lll1 (u"ࠪ࠴ࠬ࠾");
    l11111l = l11ll11.split(l1lll1 (u"ࠫ࠳࠭࠿"))
    l1lll1l = l111111.split(l1lll1 (u"ࠬ࠴ࠧࡀ"))
    while len(l11111l) < len(l1lll1l): l11111l.append(l1lll1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1lll1l) < len(l11111l): l1lll1l.append(l1lll1 (u"ࠢ࠱ࠤࡂ"));
    l11111l = [ int(x) for x in l11111l ]
    l1lll1l = [ int(x) for x in l1lll1l ]
    for  i in range(len(l11111l)):
        if len(l1lll1l) == i:
            return 1
        if l11111l[i] == l1lll1l[i]:
            continue
        elif l11111l[i] > l1lll1l[i]:
            return 1
        else:
            return -1
    if len(l11111l) != len(l1lll1l):
        return -1
    return 0