#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1 = 7
def l11l1l (l11lll):
    global l111ll
    l1lll = ord (l11lll [-1])
    l1l111 = l11lll [:-1]
    l1ll1 = l1lll % len (l1l111)
    l1llll = l1l111 [:l1ll1] + l1l111 [l1ll1:]
    if l11:
        l11l = l111l1 () .join ([unichr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    return eval (l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1lllll(l11111=None):
    if platform.system() == l11l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1111
        props = {}
        try:
            prop_names = (l11l1l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l1l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l1l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l1l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l1l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l1l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l1l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l1l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l1l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l1l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l1l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111lll = l1l1111.l1111l1(l11111, l11l1l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11ll11 in prop_names:
                l111l1l = l11l1l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111lll, l11ll11)
                props[l11ll11] = l1l1111.l1111l1(l11111, l111l1l)
        except:
            pass
    return props
def l11llll(logger, l1ll111):
    l1lll1l = os.environ.get(l11l1l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l1l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1lll1l = l1lll1l.upper()
    if l1lll1l == l11l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111ll = logging.DEBUG
    elif l1lll1l == l11l1l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111ll = logging.INFO
    elif l1lll1l == l11l1l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111ll = logging.WARNING
    elif l1lll1l == l11l1l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111ll = logging.ERROR
    elif l1lll1l == l11l1l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111ll = logging.CRITICAL
    elif l1lll1l == l11l1l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111ll = logging.NOTSET
    logger.setLevel(l1111ll)
    l111l11 = RotatingFileHandler(l1ll111, maxBytes=1024*1024*5, backupCount=3)
    l111l11.setLevel(l1111ll)
    formatter = logging.Formatter(l11l1l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111l11.setFormatter(formatter)
    logger.addHandler(l111l11)
    globals()[l11l1l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1ll1l():
    return globals()[l11l1l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l11l1():
    if platform.system() == l11l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l1l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l1ll
        l11l1ll.l1l1lll(sys.stdin.fileno(), os.l1ll1ll)
        l11l1ll.l1l1lll(sys.stdout.fileno(), os.l1ll1ll)
def l11111l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l1l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    if platform.system() == l11l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1llllll
        return l1llllll.l11lll1()
    elif platform.system() == l11l1l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l11():
    if platform.system() == l11l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1llllll
        return l1llllll.l111ll1()
    elif platform.system() == l11l1l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll
        return l1ll.l11l11()
    elif platform.system() == l11l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111111
        return l111111.l11l11()
    return l11l1l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l1l(l1111, l1111l):
    if platform.system() == l11l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1llllll
        return l1llllll.l1llll1(l1111, l1111l)
    elif platform.system() == l11l1l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111111
        return l111111.l1(l1111, l1111l)
    elif platform.system() == l11l1l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll
        return l1ll.l1(l1111, l1111l)
    raise ValueError(l11l1l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l11l(l1l1ll, url):
    if platform.system() == l11l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1llllll
        return l1llllll.l1l1ll1(l1l1ll, url)
    elif platform.system() == l11l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111111
        return l11l1l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l1l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll
        return l11l1l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lll11():
    if platform.system() == l11l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1llllll
        return l1llllll.l1lll11()
def l11l1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l1l (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll11l(l111l):
    l11l1l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1l11 = l11l1l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111l:
        if l11l1l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1l11[3:]) < int(protocol[l11l1l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1l11 = protocol[l11l1l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1l11
def l11ll1(l11l111, l1l11ll):
    l11l1l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l111 is None: l11l111 = l11l1l (u"ࠩ࠳ࠫ࠽");
    if l1l11ll is None: l1l11ll = l11l1l (u"ࠪ࠴ࠬ࠾");
    l1l111l = l11l111.split(l11l1l (u"ࠫ࠳࠭࠿"))
    l11ll1l = l1l11ll.split(l11l1l (u"ࠬ࠴ࠧࡀ"))
    while len(l1l111l) < len(l11ll1l): l1l111l.append(l11l1l (u"ࠨ࠰ࠣࡁ"));
    while len(l11ll1l) < len(l1l111l): l11ll1l.append(l11l1l (u"ࠢ࠱ࠤࡂ"));
    l1l111l = [ int(x) for x in l1l111l ]
    l11ll1l = [ int(x) for x in l11ll1l ]
    for  i in range(len(l1l111l)):
        if len(l11ll1l) == i:
            return 1
        if l1l111l[i] == l11ll1l[i]:
            continue
        elif l1l111l[i] > l11ll1l[i]:
            return 1
        else:
            return -1
    if len(l1l111l) != len(l11ll1l):
        return -1
    return 0