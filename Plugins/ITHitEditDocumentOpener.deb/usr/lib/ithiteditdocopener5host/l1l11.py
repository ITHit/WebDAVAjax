#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
l1l111 = 2048
l1ll11 = 7
def l1l1 (l111l1):
    global l11ll
    l1111l = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l1ll1 = l1111l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l111:
        l11ll1 = l1111 () .join ([unichr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    else:
        l11ll1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    return eval (l11ll1)
import os
import re
import subprocess
import l1lll1
from l1lll1 import l1l
def l1llll():
    return []
def l11l(l1ll1l, l1lll):
    logger = l1l()
    l1 = []
    l1l1ll = [l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1ll:
        try:
            output = os.popen(cmd).read()
            l11l1l = 0
            l1l1l = {}
            if l11l1l == 0:
                l11 = re.compile(l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111ll = re.compile(l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    ll = re.search(l11, line)
                    l111l = ll.group(1)
                    if l1ll1l == l111l:
                        l1ll = re.search(l111ll, line)
                        if l1ll:
                            l11l1 = l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1ll.group(1)
                            version = ll.group(0)
                            if not l11l1 in l1l1l:
                                l1l1l[l11l1] = version
                            elif l1lll1.l1l1l1(version, l1l1l[l11l1]) > 0:
                                l1l1l[l11l1] = version
            for l11l1 in l1l1l:
                l1.append({l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l1l[l11l1], l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1})
        except Exception as e:
            logger.error(str(e))
    return l1