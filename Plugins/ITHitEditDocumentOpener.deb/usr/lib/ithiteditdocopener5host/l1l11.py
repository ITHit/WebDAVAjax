#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11lll = 2048
l1ll1 = 7
def l1l111 (l1l):
    global l1111
    ll = ord (l1l [-1])
    l111l1 = l1l [:-1]
    l111l = ll % len (l111l1)
    l11l1 = l111l1 [:l111l] + l111l1 [l111l:]
    if l1l1:
        l1lll = l1l11l () .join ([unichr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    else:
        l1lll = str () .join ([chr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    return eval (l1lll)
import os
import re
import subprocess
import l1ll
from l1ll import l111ll
def l11l():
    return []
def l1lll1(l1111l, l1l1ll):
    logger = l111ll()
    l11l11 = []
    l11l1l = [l1l111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11l1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll1 = process.wait()
            l11 = {}
            if l11ll1 == 0:
                l1l1l = re.compile(l1l111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1 = re.compile(l1l111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11ll = re.search(l1l1l, line)
                    l111 = l11ll.group(1)
                    if l1111l == l111:
                        l1l1l1 = re.search(l1, line)
                        if l1l1l1:
                            l1llll = l1l111 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l1.group(1)
                            version = l11ll.group(0)
                            if not l1llll in l11:
                                l11[l1llll] = version
                            elif l1ll.l1ll1l(version, l11[l1llll]) > 0:
                                l11[l1llll] = version
            for l1llll in l11:
                l11l11.append({l1l111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11[l1llll], l1l111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1llll})
        except Exception as e:
            logger.error(str(e))
    return l11l11