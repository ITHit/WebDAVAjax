#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l1 = 2048
l11ll = 7
def l11 (ll):
    global l1
    l1ll11 = ord (ll [-1])
    l1lll = ll [:-1]
    l1l11 = l1ll11 % len (l1lll)
    l11l1l = l1lll [:l1l11] + l1lll [l1l11:]
    if l1ll1l:
        l1l1ll = l1llll () .join ([unichr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    return eval (l1l1ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11llll(l111111=None):
    if platform.system() == l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll111
        props = {}
        try:
            prop_names = (l11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111lll = l1ll111.l11lll1(l111111, l11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111ll1 in prop_names:
                l1l1lll = l11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111lll, l111ll1)
                props[l111ll1] = l1ll111.l11lll1(l111111, l1l1lll)
        except:
            pass
    return props
def l1l11ll(logger, l11ll1l):
    l1lll1l = os.environ.get(l11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1lll1l = l1lll1l.upper()
    if l1lll1l == l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111l1 = logging.DEBUG
    elif l1lll1l == l11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111l1 = logging.INFO
    elif l1lll1l == l11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111l1 = logging.WARNING
    elif l1lll1l == l11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111l1 = logging.ERROR
    elif l1lll1l == l11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111l1 = logging.CRITICAL
    elif l1lll1l == l11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111l1 = logging.NOTSET
    logger.setLevel(l1111l1)
    l1l11l1 = RotatingFileHandler(l11ll1l, maxBytes=1024*1024*5, backupCount=3)
    l1l11l1.setLevel(l1111l1)
    formatter = logging.Formatter(l11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l11l1.setFormatter(formatter)
    logger.addHandler(l1l11l1)
    globals()[l11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l11l():
    return globals()[l11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l1l1():
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1111ll
        l1111ll.l11l1ll(sys.stdin.fileno(), os.l1lll11)
        l1111ll.l11l1ll(sys.stdout.fileno(), os.l1lll11)
def l11l11l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l111():
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11111l
        return l11111l.l1llllll()
    elif platform.system() == l11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l111():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11111l
        return l11111l.l1l111l()
    elif platform.system() == l11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l1
        return l1l1.l111()
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111l1l
        return l111l1l.l111()
    return l11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l11(l1111, l11ll1):
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11111l
        return l11111l.l1ll1ll(l1111, l11ll1)
    elif platform.system() == l11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111l1l
        return l111l1l.l11l(l1111, l11ll1)
    elif platform.system() == l11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l1
        return l1l1.l11l(l1111, l11ll1)
    raise ValueError(l11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11ll11(l1111l, url):
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11111l
        return l11111l.l1llll1(l1111l, url)
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111l1l
        return l11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l1
        return l11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll11l():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11111l
        return l11111l.l1ll11l()
def l1ll1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11 (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1111(l11l11):
    l11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111 = l11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11l11:
        if l11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111[3:]) < int(protocol[l11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111 = protocol[l11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111
def l1l1l1(l1l1l1l, l1l1ll1):
    l11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1l1l is None: l1l1l1l = l11 (u"ࠩ࠳ࠫ࠽");
    if l1l1ll1 is None: l1l1ll1 = l11 (u"ࠪ࠴ࠬ࠾");
    l1lllll = l1l1l1l.split(l11 (u"ࠫ࠳࠭࠿"))
    l111l11 = l1l1ll1.split(l11 (u"ࠬ࠴ࠧࡀ"))
    while len(l1lllll) < len(l111l11): l1lllll.append(l11 (u"ࠨ࠰ࠣࡁ"));
    while len(l111l11) < len(l1lllll): l111l11.append(l11 (u"ࠢ࠱ࠤࡂ"));
    l1lllll = [ int(x) for x in l1lllll ]
    l111l11 = [ int(x) for x in l111l11 ]
    for  i in range(len(l1lllll)):
        if len(l111l11) == i:
            return 1
        if l1lllll[i] == l111l11[i]:
            continue
        elif l1lllll[i] > l111l11[i]:
            return 1
        else:
            return -1
    if len(l1lllll) != len(l111l11):
        return -1
    return 0