#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1111 = 7
def l1l1l (l1111l):
    global l1l111
    l11lll = ord (l1111l [-1])
    l1l11l = l1111l [:-1]
    l1ll11 = l11lll % len (l1l11l)
    l11 = l1l11l [:l1ll11] + l1l11l [l1ll11:]
    if l1l1:
        l111ll = l1llll () .join ([unichr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    return eval (l111ll)
import os
import re
import subprocess
import l1l
from l1l import l11l11
def l111l():
    return []
def l1l11(l1lll, l1):
    logger = l11l11()
    ll = []
    l11ll1 = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11ll1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1l = process.wait()
            l11l = {}
            if l1ll1l == 0:
                l111 = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1l1 = re.search(l111, line)
                    l1l1ll = l1l1l1.group(1)
                    if l1lll == l1l1ll:
                        l11l1l = re.search(l1ll1, line)
                        if l11l1l:
                            l11ll = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l11l1l.group(1)
                            version = l1l1l1.group(0)
                            if not l11ll in l11l:
                                l11l[l11ll] = version
                            elif l1l.l1ll(version, l11l[l11ll]) > 0:
                                l11l[l11ll] = version
            for l11ll in l11l:
                ll.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l[l11ll], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11ll})
        except Exception as e:
            logger.error(str(e))
    return ll