#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l11l1l = 7
def l11ll (l1ll1):
    global l1l1l
    l1l11 = ord (l1ll1 [-1])
    l11l11 = l1ll1 [:-1]
    l1l111 = l1l11 % len (l11l11)
    l1ll1l = l11l11 [:l1l111] + l11l11 [l1l111:]
    if l1ll11:
        l1 = l11lll () .join ([unichr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    return eval (l1)
import os
import re
import subprocess
import l1111
from l1111 import l11l1
def l11():
    return []
def l11l(l111, l11ll1):
    logger = l11l1()
    ll = []
    l1l1ll = [l11ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1l1 = process.wait()
            l1lll = {}
            if l1l1l1 == 0:
                l1111l = re.compile(l11ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111l1 = re.compile(l11ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll = re.search(l1111l, line)
                    l1l11l = l1ll.group(1)
                    if l111 == l1l11l:
                        l111ll = re.search(l111l1, line)
                        if l111ll:
                            l1llll = l11ll (u"ࠨࡦࡤࡺࠬࠄ")+l111ll.group(1)
                            version = l1ll.group(0)
                            if not l1llll in l1lll:
                                l1lll[l1llll] = version
                            elif l1111.l1l(version, l1lll[l1llll]) > 0:
                                l1lll[l1llll] = version
            for l1llll in l1lll:
                ll.append({l11ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll[l1llll], l11ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1llll})
        except Exception as e:
            logger.error(str(e))
    return ll