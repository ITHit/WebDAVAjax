#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l1l = 7
def l111 (l1ll):
    global l1l1l1
    l1l11 = ord (l1ll [-1])
    l1 = l1ll [:-1]
    l11lll = l1l11 % len (l1)
    l1l1ll = l1 [:l11lll] + l1 [l11lll:]
    if l1ll11:
        l1111l = l1ll1 () .join ([unichr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    return eval (l1111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1lll11(l1l1l1l=None):
    if platform.system() == l111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11111l
        props = {}
        try:
            prop_names = (l111 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1lllll = l11111l.l1l1lll(l1l1l1l, l111 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11ll11 in prop_names:
                l1ll11l = l111 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1lllll, l11ll11)
                props[l11ll11] = l11111l.l1l1lll(l1l1l1l, l1ll11l)
        except:
            pass
    return props
def l11l1l1(logger, l1111ll):
    l1l111l = os.environ.get(l111 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l111l = l1l111l.upper()
    if l1l111l == l111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111111 = logging.DEBUG
    elif l1l111l == l111 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111111 = logging.INFO
    elif l1l111l == l111 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111111 = logging.WARNING
    elif l1l111l == l111 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111111 = logging.ERROR
    elif l1l111l == l111 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111111 = logging.CRITICAL
    elif l1l111l == l111 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111111 = logging.NOTSET
    logger.setLevel(l111111)
    l1ll111 = RotatingFileHandler(l1111ll, maxBytes=1024*1024*5, backupCount=3)
    l1ll111.setLevel(l111111)
    formatter = logging.Formatter(l111 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll111.setFormatter(formatter)
    logger.addHandler(l1ll111)
    globals()[l111 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l1():
    return globals()[l111 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11llll():
    if platform.system() == l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1111
        l1l1111.l111l11(sys.stdin.fileno(), os.l1lll1l)
        l1l1111.l111l11(sys.stdout.fileno(), os.l1lll1l)
def l111lll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111ll1():
    if platform.system() == l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l11l1
        return l1l11l1.l1l1l11()
    elif platform.system() == l111 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l11():
    if platform.system() == l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l11l1
        return l1l11l1.l111l1l()
    elif platform.system() == l111 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11l1l
        return l11l1l.l11l11()
    elif platform.system() == l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1ll
        return l1ll1ll.l11l11()
    return l111 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11ll1l(l1lll, l11l):
    if platform.system() == l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l11l1
        return l1l11l1.l11lll1(l1lll, l11l)
    elif platform.system() == l111 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1ll
        return l1ll1ll.l11ll(l1lll, l11l)
    elif platform.system() == l111 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11l1l
        return l11l1l.l11ll(l1lll, l11l)
    raise ValueError(l111 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l11ll(l111l, url):
    if platform.system() == l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l11l1
        return l1l11l1.l1l1ll1(l111l, url)
    elif platform.system() == l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1ll
        return l111 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11l1l
        return l111 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11111():
    if platform.system() == l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l11l1
        return l1l11l1.l11111()
def l11l111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111 (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll1l1(l1ll1l):
    l111 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1llllll = l111 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1l:
        if l111 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1llllll[3:]) < int(protocol[l111 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1llllll = protocol[l111 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1llllll
def l1l11l(l11l1ll, l11l11l):
    l111 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l1ll is None: l11l1ll = l111 (u"ࠩ࠳ࠫ࠽");
    if l11l11l is None: l11l11l = l111 (u"ࠪ࠴ࠬ࠾");
    l1111l1 = l11l1ll.split(l111 (u"ࠫ࠳࠭࠿"))
    l1llll1 = l11l11l.split(l111 (u"ࠬ࠴ࠧࡀ"))
    while len(l1111l1) < len(l1llll1): l1111l1.append(l111 (u"ࠨ࠰ࠣࡁ"));
    while len(l1llll1) < len(l1111l1): l1llll1.append(l111 (u"ࠢ࠱ࠤࡂ"));
    l1111l1 = [ int(x) for x in l1111l1 ]
    l1llll1 = [ int(x) for x in l1llll1 ]
    for  i in range(len(l1111l1)):
        if len(l1llll1) == i:
            return 1
        if l1111l1[i] == l1llll1[i]:
            continue
        elif l1111l1[i] > l1llll1[i]:
            return 1
        else:
            return -1
    if len(l1111l1) != len(l1llll1):
        return -1
    return 0