#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll11 = 7
def l1111l (l1llll):
    global l111l
    l11l11 = ord (l1llll [-1])
    l11ll = l1llll [:-1]
    l1l11 = l11l11 % len (l11ll)
    l1ll = l11ll [:l1l11] + l11ll [l1l11:]
    if l1l111:
        l1l1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    return eval (l1l1l1)
import os
import re
import subprocess
import l1ll1
from l1ll1 import l11l
def l1l1l():
    return []
def l11l1l(l11lll, l11ll1):
    logger = l11l()
    l11l1 = []
    ll = [l1111l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1111l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in ll:
        try:
            output = os.popen(cmd).read()
            l11 = 0
            l111ll = {}
            if l11 == 0:
                l1l = re.compile(l1111l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1 = re.compile(l1111l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1lll = re.search(l1l, line)
                    l1 = l1lll.group(1)
                    if l11lll == l1:
                        l1111 = re.search(l1l1, line)
                        if l1111:
                            l111l1 = l1111l (u"ࠨࡦࡤࡺࠬࠄ")+l1111.group(1)
                            version = l1lll.group(0)
                            if not l111l1 in l111ll:
                                l111ll[l111l1] = version
                            elif l1ll1.l1l11l(version, l111ll[l111l1]) > 0:
                                l111ll[l111l1] = version
            for l111l1 in l111ll:
                l11l1.append({l1111l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111ll[l111l1], l1111l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l1})
        except Exception as e:
            logger.error(str(e))
    return l11l1