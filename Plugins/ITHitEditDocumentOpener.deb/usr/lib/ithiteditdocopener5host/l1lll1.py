#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll1l = 7
def l1111 (l111ll):
    global l11l11
    l1l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l1l1 % len (l1llll)
    l1111l = l1llll [:l11l] + l1llll [l11l:]
    if l1:
        l1lll = l11ll () .join ([unichr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    return eval (l1lll)
import os
import re
import subprocess
import l11ll1
from l11ll1 import l1l
def l11():
    return []
def l111(l111l, l1l1l1):
    logger = l1l()
    l1ll11 = []
    l11l1l = [l1111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11l1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            l1l1ll = {}
            if l111l1 == 0:
                l1l11l = re.compile(l1111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1 = re.compile(l1111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1l = re.search(l1l11l, line)
                    ll = l1l1l.group(1)
                    if l111l == ll:
                        l11lll = re.search(l11l1, line)
                        if l11lll:
                            l1ll = l1111 (u"ࠨࡦࡤࡺࠬࠄ")+l11lll.group(1)
                            version = l1l1l.group(0)
                            if not l1ll in l1l1ll:
                                l1l1ll[l1ll] = version
                            elif l11ll1.l1l111(version, l1l1ll[l1ll]) > 0:
                                l1l1ll[l1ll] = version
            for l1ll in l1l1ll:
                l1ll11.append({l1111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l1ll[l1ll], l1111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll})
        except Exception as e:
            logger.error(str(e))
    return l1ll11