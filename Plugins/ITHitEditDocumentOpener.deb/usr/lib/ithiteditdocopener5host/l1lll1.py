#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
l1l111 = 2048
l1ll11 = 7
def l1l1 (l111l1):
    global l11ll
    l1111l = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l1ll1 = l1111l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l111:
        l11ll1 = l1111 () .join ([unichr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    else:
        l11ll1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    return eval (l11ll1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll11l(l1111l1=None):
    if platform.system() == l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l1l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111l = l1l1lll.l1l11ll(l1111l1, l1l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1ll111 in prop_names:
                l11ll11 = l1l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111l, l1ll111)
                props[l1ll111] = l1l1lll.l1l11ll(l1111l1, l11ll11)
        except:
            pass
    return props
def l11l111(logger, l111111):
    l1l111l = os.environ.get(l1l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l111l = l1l111l.upper()
    if l1l111l == l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l11l1 = logging.DEBUG
    elif l1l111l == l1l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l11l1 = logging.INFO
    elif l1l111l == l1l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l11l1 = logging.WARNING
    elif l1l111l == l1l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l11l1 = logging.ERROR
    elif l1l111l == l1l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l11l1 = logging.CRITICAL
    elif l1l111l == l1l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l11l1 = logging.NOTSET
    logger.setLevel(l1l11l1)
    l111lll = RotatingFileHandler(l111111, maxBytes=1024*1024*5, backupCount=3)
    l111lll.setLevel(l1l11l1)
    formatter = logging.Formatter(l1l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111lll.setFormatter(formatter)
    logger.addHandler(l111lll)
    globals()[l1l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l():
    return globals()[l1l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l1ll():
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1ll1
        l1l1ll1.l11ll1l(sys.stdin.fileno(), os.l1lll1l)
        l1l1ll1.l11ll1l(sys.stdout.fileno(), os.l1lll1l)
def l11lll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llll1():
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111ll1
        return l111ll1.l1l1l1l()
    elif platform.system() == l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1llll():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111ll1
        return l111ll1.l111l1l()
    elif platform.system() == l1l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l11
        return l1l11.l1llll()
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1ll
        return l1ll1ll.l1llll()
    return l1l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l11(l1ll1l, l1lll):
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111ll1
        return l111ll1.l11111(l1ll1l, l1lll)
    elif platform.system() == l1l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1ll
        return l1ll1ll.l11l(l1ll1l, l1lll)
    elif platform.system() == l1l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l11
        return l1l11.l11l(l1ll1l, l1lll)
    raise ValueError(l1l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11llll(l11l1, url):
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111ll1
        return l111ll1.l1ll1l1(l11l1, url)
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1ll
        return l1l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l11
        return l1l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lll11():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111ll1
        return l111ll1.l1lll11()
def l1llllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1111ll(l1l1l):
    l1l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l1l1 = l1l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l1l:
        if l1l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l1l1[3:]) < int(protocol[l1l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l1l1 = protocol[l1l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l1l1
def l1l1l1(l111l11, l11l11l):
    l1l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l111l11 is None: l111l11 = l1l1 (u"ࠩ࠳ࠫ࠽");
    if l11l11l is None: l11l11l = l1l1 (u"ࠪ࠴ࠬ࠾");
    l1l1111 = l111l11.split(l1l1 (u"ࠫ࠳࠭࠿"))
    l1lllll = l11l11l.split(l1l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1111) < len(l1lllll): l1l1111.append(l1l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1lllll) < len(l1l1111): l1lllll.append(l1l1 (u"ࠢ࠱ࠤࡂ"));
    l1l1111 = [ int(x) for x in l1l1111 ]
    l1lllll = [ int(x) for x in l1lllll ]
    for  i in range(len(l1l1111)):
        if len(l1lllll) == i:
            return 1
        if l1l1111[i] == l1lllll[i]:
            continue
        elif l1l1111[i] > l1lllll[i]:
            return 1
        else:
            return -1
    if len(l1l1111) != len(l1lllll):
        return -1
    return 0