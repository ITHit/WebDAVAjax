#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1111 (l111ll):
    global l11ll1
    l1l1l = ord (l111ll [-1])
    l1 = l111ll [:-1]
    l1llll = l1l1l % len (l1)
    l111l = l1 [:l1llll] + l1 [l1llll:]
    if l11l1:
        l11l = l1ll11 () .join ([unichr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    return eval (l11l)
import os
import re
import subprocess
import l1ll1
from l1ll1 import l1l11
def l11l11():
    return []
def l11lll(l111l1, l1l111):
    logger = l1l11()
    l1ll = []
    l1l11l = [l1111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l11l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll = process.wait()
            l111 = {}
            if l11ll == 0:
                ll = re.compile(l1111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1l = re.compile(l1111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11 = re.search(ll, line)
                    l1ll1l = l11.group(1)
                    if l111l1 == l1ll1l:
                        l1l1ll = re.search(l11l1l, line)
                        if l1l1ll:
                            l1lll = l1111 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1ll.group(1)
                            version = l11.group(0)
                            if not l1lll in l111:
                                l111[l1lll] = version
                            elif l1ll1.l1l(version, l111[l1lll]) > 0:
                                l111[l1lll] = version
            for l1lll in l111:
                l1ll.append({l1111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111[l1lll], l1111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1lll})
        except Exception as e:
            logger.error(str(e))
    return l1ll