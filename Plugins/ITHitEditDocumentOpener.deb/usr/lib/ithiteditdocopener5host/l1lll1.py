#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1l1ll = 2048
l111 = 7
def l111l (l111l1):
    global l1lll
    l11l11 = ord (l111l1 [-1])
    l1111 = l111l1 [:-1]
    l11l = l11l11 % len (l1111)
    l1l1l1 = l1111 [:l11l] + l1111 [l11l:]
    if l11ll:
        l1l11l = l11lll () .join ([unichr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    return eval (l1l11l)
import os
import re
import subprocess
import ll
from ll import l1l111
def l1ll1():
    return []
def l111ll(l1llll, l1ll):
    logger = l1l111()
    l1l1l = []
    l1 = [l111l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1l = process.wait()
            l1111l = {}
            if l1ll1l == 0:
                l1l11 = re.compile(l111l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1l = re.compile(l111l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1 = re.search(l1l11, line)
                    l11 = l11l1.group(1)
                    if l1llll == l11:
                        l1l = re.search(l11l1l, line)
                        if l1l:
                            l1ll11 = l111l (u"ࠨࡦࡤࡺࠬࠄ")+l1l.group(1)
                            version = l11l1.group(0)
                            if not l1ll11 in l1111l:
                                l1111l[l1ll11] = version
                            elif ll.l1l1(version, l1111l[l1ll11]) > 0:
                                l1111l[l1ll11] = version
            for l1ll11 in l1111l:
                l1l1l.append({l111l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111l[l1ll11], l111l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll11})
        except Exception as e:
            logger.error(str(e))
    return l1l1l