#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll11 = 2048
l111ll = 7
def l11ll (l11l11):
    global l1111
    l11l1 = ord (l11l11 [-1])
    l1 = l11l11 [:-1]
    ll = l11l1 % len (l1)
    l1ll1 = l1 [:ll] + l1 [ll:]
    if l1l1l1:
        l11l1l = l1l11l () .join ([unichr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    return eval (l11l1l)
import subprocess, threading
from l11l import l111l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11111():
    l11l1ll1 = [l11ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1ll1:
        try:
            l11l11l1 = l11ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l1111l = winreg.l11l1l11(winreg.l11ll111, l11l11l1)
        except l11lll11:
            continue
        value = winreg.l11l1lll(l1l1111l, l11ll (u"ࠦࠧ࢓"))
        return value.split(l11ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l111l():
    l1l111ll = []
    for name in l1l1l11l:
        try:
            l11l11l1 = l11ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11lll = winreg.l11l1l11(winreg.l11ll111, l11l11l1)
            if winreg.l11l1lll(l1l11lll, l11ll (u"ࠢࠣ࢖")):
                l1l111ll.append(name)
        except l11lll11:
            continue
    return l1l111ll
def l1l1l1l(l11ll1, l111):
    import re
    l1l111 = []
    l11l1l1l = winreg.l11l1l11(winreg.l11ll111, l11ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll1l1(l11l1l1l)[0]):
        try:
            l1l111l1 = winreg.l1l11l11(l11l1l1l, i)
            if l1l111l1.startswith(l111):
                l11llll1 = winreg.l11l1111(l11l1l1l, l1l111l1)
                value, l1l11111 = winreg.l11ll11l(l11llll1, l11ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l111l = {l11ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lllll = m.group(2)
                    if l11ll1 == l11lllll:
                        m = re.search(l111.replace(l11ll (u"ࠬ࠴࢛ࠧ"), l11ll (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l111l1)
                        l11l111l[l11ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l111.append(l11l111l)
                else:
                    raise ValueError(l11ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11lll11 as ex:
            continue
    return l1l111
def l11lll1l(l1ll):
    try:
        l1l11l1l = l11ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll)
        l11ll1ll = winreg.l11l1l11(winreg.l11ll111, l1l11l1l)
        value, l1l11111 = winreg.l11ll11l(l11ll1ll, l11ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll (u"ࠬࠨࠧࢢ"))[1]
    except l11lll11:
        pass
    return l11ll (u"࠭ࠧࢣ")
def l1l11ll(l1ll, url):
    threading.Thread(target=_1l11ll1,args=(l1ll, url)).start()
    return l11ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11ll1(l1ll, url):
    logger = l111l()
    l11l11ll = l11lll1l(l1ll)
    logger.debug(l11ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11ll, url))
    retcode = subprocess.Popen(l11ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)