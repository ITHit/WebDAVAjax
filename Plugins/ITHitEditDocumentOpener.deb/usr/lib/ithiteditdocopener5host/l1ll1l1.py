#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1 = 2048
l1lll = 7
def l1ll11 (l1111l):
    global l1ll
    l11ll = ord (l1111l [-1])
    l111ll = l1111l [:-1]
    l1llll = l11ll % len (l111ll)
    l1l = l111ll [:l1llll] + l111ll [l1llll:]
    if l11:
        l11l1l = l111l1 () .join ([unichr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    return eval (l11l1l)
import l1l1
from l1l1l111 import l1l1l11l
import objc as _111111l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111111l.l111ll1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l1111ll1(l1111l1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll11 (u"ࠨࠩࢬ"), {l1ll11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111ll11(l111l1ll):
    l111l1ll = (l111l1ll + l1ll11 (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1l1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l111l11l = CFURLCreateWithString( kCFAllocatorDefault, l111l1l1, _111111l.nil )
    l11111ll = LaunchServices.l1111lll( l111l11l, LaunchServices.l111llll, _111111l.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l1l11l():
    l1111111 = []
    for name in l1l1l11l:
        try:
            if l111ll11(name):
                l1111111.append(name)
        except:
            continue
    return l1111111
def l11l(l11l11, l1l1ll):
    import plistlib
    import os
    l1lll1 = []
    l1l11 = {}
    for l11111l1 in os.listdir(l1ll11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111l1.startswith(l1l1ll):
            try:
                l111l111 = l1ll11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111l1
                with open(l111l111, l1ll11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1l1 = plist[l1ll11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l1ll11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l11 == l1111l11:
                        if not l1l1l1 in l1l11:
                            l1l11[l1l1l1] = version
                        elif l1l1.l1ll1(version, l1l11[l1l1l1]) > 0:
                            l1l11[l1l1l1] = version
            except BaseException:
                continue
    for l1l1l1 in l1l11:
        l1lll1.append({l1ll11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l11[l1l1l1], l1ll11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1l1})
    return l1lll1