#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll1 = 2048
l11l = 7
def ll (l1):
    global l1l
    l1llll = ord (l1 [-1])
    l1l111 = l1 [:-1]
    l1l1l1 = l1llll % len (l1l111)
    l11lll = l1l111 [:l1l1l1] + l1l111 [l1l1l1:]
    if l11ll:
        l111 = l11l11 () .join ([unichr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    else:
        l111 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    return eval (l111)
import l111l1
from l1l1l11l import l1l1l111
import objc as _1111lll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111lll.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l111l1ll(l111l1l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), ll (u"ࠨࠩࢬ"), {ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111ll11(l1111l1l):
    l1111l1l = (l1111l1l + ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111l111 = CFStringCreateWithCString( kCFAllocatorDefault, l1111l1l, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l111l111, _1111lll.nil )
    l1111111 = LaunchServices.l111llll( l111111l, LaunchServices.l111lll1, _1111lll.nil )
    if l1111111[0] is not None:
        return True
    return False
def l11ll1():
    l111l11l = []
    for name in l1l1l111:
        try:
            if l111ll11(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def l1lll(l1111, l11l1):
    import plistlib
    import os
    l1l1l = []
    l1lll1 = {}
    for l111ll1l in os.listdir(ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(l11l1):
            try:
                l1111l11 = ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l1111l11, ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1l = plist[ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111ll1 = version.split(ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111 == l1111ll1:
                        if not l11l1l in l1lll1:
                            l1lll1[l11l1l] = version
                        elif l111l1.l1ll11(version, l1lll1[l11l1l]) > 0:
                            l1lll1[l11l1l] = version
            except BaseException:
                continue
    for l11l1l in l1lll1:
        l1l1l.append({ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll1[l11l1l], ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1l})
    return l1l1l