#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l1l (l11ll1):
    global l1l1ll
    l1llll = ord (l11ll1 [-1])
    l11l1l = l11ll1 [:-1]
    l111 = l1llll % len (l11l1l)
    l11lll = l11l1l [:l111] + l11l1l [l111:]
    if l111l1:
        l11l = l111l () .join ([unichr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    return eval (l11l)
import subprocess, threading
from l1l import l1l11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l111l1l():
    l11llll1 = [l1l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11llll1:
        try:
            l11l11l1 = l1l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l11lllll(winreg.l11lll1l, l11l11l1)
        except l11l1l11:
            continue
        value = winreg.l1l1111l(l11l1l1l, l1l1l (u"ࠦࠧ࢓"))
        return value.split(l1l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111l11():
    l1l111l1 = []
    for name in l1l1l11l:
        try:
            l11l11l1 = l1l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111ll = winreg.l11lllll(winreg.l11lll1l, l11l11l1)
            if winreg.l1l1111l(l1l111ll, l1l1l (u"ࠢࠣ࢖")):
                l1l111l1.append(name)
        except l11l1l11:
            continue
    return l1l111l1
def l11lll1(l1ll11, l1l111):
    import re
    l1l1 = []
    l1l11111 = winreg.l11lllll(winreg.l11lll1l, l1l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lll11(l1l11111)[0]):
        try:
            l11ll111 = winreg.l11ll11l(l1l11111, i)
            if l11ll111.startswith(l1l111):
                l1l11lll = winreg.l1l11l11(l1l11111, l11ll111)
                value, l11ll1ll = winreg.l1l11l1l(l1l11lll, l1l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11ll1 = {l1l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1111 = m.group(2)
                    if l1ll11 == l11l1111:
                        m = re.search(l1l111.replace(l1l1l (u"ࠬ࠴࢛ࠧ"), l1l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll111)
                        l1l11ll1[l1l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1.append(l1l11ll1)
                else:
                    raise ValueError(l1l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1l11 as ex:
            continue
    return l1l1
def l11ll1l1(l1):
    try:
        l11l1lll = l1l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1)
        l11l111l = winreg.l11lllll(winreg.l11lll1l, l11l1lll)
        value, l11ll1ll = winreg.l1l11l1l(l11l111l, l1l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1l11:
        pass
    return l1l1l (u"࠭ࠧࢣ")
def l11ll1l(l1, url):
    threading.Thread(target=_11l11ll,args=(l1, url)).start()
    return l1l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l11ll(l1, url):
    logger = l1l11()
    l11l1ll1 = l11ll1l1(l1)
    logger.debug(l1l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1ll1, url))
    retcode = subprocess.Popen(l1l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1ll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)