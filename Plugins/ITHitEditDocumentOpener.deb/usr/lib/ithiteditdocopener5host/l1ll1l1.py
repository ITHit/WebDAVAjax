#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll = sys.version_info [0] == 2
l11l1l = 2048
l1lll = 7
def l11l11 (l11lll):
    global l11ll1
    l1ll1l = ord (l11lll [-1])
    l1l11 = l11lll [:-1]
    l1111 = l1ll1l % len (l1l11)
    l11 = l1l11 [:l1111] + l1l11 [l1111:]
    if l1l1ll:
        l111l = l1l () .join ([unichr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    return eval (l111l)
import l1ll1
from l1l1l11l import l1l1l111
import objc as _1111lll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111lll.l111111l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111ll1.l11111ll(l111l111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l11 (u"ࠨࠩࢬ"), {l11l11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111llll):
    l111llll = (l111llll + l11l11 (u"ࠩ࠽ࠫࢴ")).encode()
    l11111l1 = CFStringCreateWithCString( kCFAllocatorDefault, l111llll, kCFStringEncodingUTF8 )
    l1111l11 = CFURLCreateWithString( kCFAllocatorDefault, l11111l1, _1111lll.nil )
    l111l11l = LaunchServices.l111ll11( l1111l11, LaunchServices.l111ll1l, _1111lll.nil )
    if l111l11l[0] is not None:
        return True
    return False
def l1l1l1():
    l111l1ll = []
    for name in l1l1l111:
        try:
            if l1111111(name):
                l111l1ll.append(name)
        except:
            continue
    return l111l1ll
def l11ll(l1ll, l111l1):
    import plistlib
    import os
    l1 = []
    l1l111 = {}
    for l111l1l1 in os.listdir(l11l11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l111l1):
            try:
                l1111l1l = l11l11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l1111l1l, l11l11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1 = plist[l11l11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l11l11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll == l111lll1:
                        if not l1l1 in l1l111:
                            l1l111[l1l1] = version
                        elif l1ll1.l11l(version, l1l111[l1l1]) > 0:
                            l1l111[l1l1] = version
            except BaseException:
                continue
    for l1l1 in l1l111:
        l1.append({l11l11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l111[l1l1], l11l11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1})
    return l1