#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1ll11 = 2048
l1llll = 7
def l1 (l11lll):
    global l1l1
    l11ll1 = ord (l11lll [-1])
    l111l = l11lll [:-1]
    l1l = l11ll1 % len (l111l)
    l111ll = l111l [:l1l] + l111l [l1l:]
    if l11l1:
        l1111 = l1l1l () .join ([unichr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    return eval (l1111)
import _winreg
import subprocess, threading
from l1l1l1 import l111l1
from l1l1l111 import l1l1l11l
def l111ll1():
    l11l1lll = [l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1lll:
        try:
            l11l1111 = l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11lll = _winreg.l11ll1l1(_winreg.l1l11ll1, l11l1111)
        except l1l111ll:
            continue
        value = _winreg.l11ll1ll(l1l11lll, l1 (u"ࠦࠧ࢓"))
        return value.split(l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11llll():
    l11l11l1 = []
    for name in l1l1l11l:
        try:
            l11l1111 = l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll111 = _winreg.l11ll1l1(_winreg.l1l11ll1, l11l1111)
            if _winreg.l11ll1ll(l11ll111, l1 (u"ࠢࠣ࢖")):
                l11l11l1.append(name)
        except l1l111ll:
            continue
    return l11l11l1
def l1l1ll1(l11l11, l11l):
    import re
    l11 = []
    l11l111l = _winreg.l11ll1l1(_winreg.l1l11ll1, l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, _winreg.l1l1111l(l11l111l)[0]):
        try:
            l11lll1l = _winreg.l11l1ll1(l11l111l, i)
            if l11lll1l.startswith(l11l):
                l11l1l1l = _winreg.l11lllll(l11l111l, l11lll1l)
                value, l11l11ll = _winreg.l1l11111(l11l1l1l, l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111l1 = {l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll11 = m.group(2)
                    if l11l11 == l11lll11:
                        m = re.search(l11l.replace(l1 (u"ࠬ࠴࢛ࠧ"), l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll1l)
                        l1l111l1[l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11.append(l1l111l1)
                else:
                    raise ValueError(l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l111ll as ex:
            continue
    return l11
def l11l1l11(l1l11l):
    try:
        l11llll1 = l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11l)
        l1l11l11 = _winreg.l11ll1l1(_winreg.l1l11ll1, l11llll1)
        value, l11l11ll = _winreg.l1l11111(l1l11l11, l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1 (u"ࠬࠨࠧࢢ"))[1]
    except l1l111ll:
        pass
    return l1 (u"࠭ࠧࢣ")
def l11ll11(l1l11l, url):
    threading.Thread(target=_11ll11l,args=(l1l11l, url)).start()
    return l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll11l(l1l11l, url):
    logger = l111l1()
    l1l11l1l = l11l1l11(l1l11l)
    logger.debug(l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l1l, url))
    retcode = subprocess.Popen(l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)