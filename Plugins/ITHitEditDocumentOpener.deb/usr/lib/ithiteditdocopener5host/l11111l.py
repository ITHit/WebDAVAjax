#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1lll = 2048
l11l1 = 7
def l111 (l1ll11):
    global l1l11
    l11l1l = ord (l1ll11 [-1])
    l1l1l = l1ll11 [:-1]
    l1l1ll = l11l1l % len (l1l1l)
    l1llll = l1l1l [:l1l1ll] + l1l1l [l1l1ll:]
    if l1ll:
        l1111l = l111ll () .join ([unichr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    return eval (l1111l)
import subprocess, threading
from l1l1l1 import l11ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l1lll():
    l1l11ll1 = [l111 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l111 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l111 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l111 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11ll1:
        try:
            l1l111l1 = l111 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l111ll = winreg.l1l11lll(winreg.l11l11l1, l1l111l1)
        except l1l11l11:
            continue
        value = winreg.l11ll1ll(l1l111ll, l111 (u"ࠦࠧ࢓"))
        return value.split(l111 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11l1l1():
    l11lll11 = []
    for name in l1l1l11l:
        try:
            l1l111l1 = l111 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1l1 = winreg.l1l11lll(winreg.l11l11l1, l1l111l1)
            if winreg.l11ll1ll(l11ll1l1, l111 (u"ࠢࠣ࢖")):
                l11lll11.append(name)
        except l1l11l11:
            continue
    return l11lll11
def l1l111l(l11ll1, l1l111):
    import re
    l1l = []
    l11l111l = winreg.l1l11lll(winreg.l11l11l1, l111 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1ll1(l11l111l)[0]):
        try:
            l11l1lll = winreg.l11l1111(l11l111l, i)
            if l11l1lll.startswith(l1l111):
                l1l1111l = winreg.l11l1l11(l11l111l, l11l1lll)
                value, l11l1l1l = winreg.l1l11l1l(l1l1111l, l111 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l111 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll11l = {l111 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11111 = m.group(2)
                    if l11ll1 == l1l11111:
                        m = re.search(l1l111.replace(l111 (u"ࠬ࠴࢛ࠧ"), l111 (u"࠭࡜࡝࠰ࠪ࢜")) + l111 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1lll)
                        l11ll11l[l111 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l.append(l11ll11l)
                else:
                    raise ValueError(l111 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11l11 as ex:
            continue
    return l1l
def l11llll1(l1111):
    try:
        l11l11ll = l111 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1111)
        l11ll111 = winreg.l1l11lll(winreg.l11l11l1, l11l11ll)
        value, l11l1l1l = winreg.l1l11l1l(l11ll111, l111 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l111 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11l11:
        pass
    return l111 (u"࠭ࠧࢣ")
def l1l11ll(l1111, url):
    threading.Thread(target=_11lllll,args=(l1111, url)).start()
    return l111 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lllll(l1111, url):
    logger = l11ll()
    l11lll1l = l11llll1(l1111)
    logger.debug(l111 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lll1l, url))
    retcode = subprocess.Popen(l111 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lll1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l111 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l111 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)