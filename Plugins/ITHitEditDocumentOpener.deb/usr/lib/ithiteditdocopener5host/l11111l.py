#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l = 2048
l1l1l1 = 7
def l111l (l11ll):
    global l1l1l
    l1l1ll = ord (l11ll [-1])
    l11l11 = l11ll [:-1]
    l11l1l = l1l1ll % len (l11l11)
    l1l111 = l11l11 [:l11l1l] + l11l11 [l11l1l:]
    if l1:
        l1lll1 = ll () .join ([unichr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    return eval (l1lll1)
import l111l1
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l111l11l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111111l.l111ll1l(l1111l1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111l (u"ࠨࠩࢬ"), {l111l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1l1(l1111l11):
    l1111l11 = (l1111l11 + l111l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111111 = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l11111l1 = CFURLCreateWithString( kCFAllocatorDefault, l1111111, _1111ll1.nil )
    l111ll11 = LaunchServices.l111l111( l11111l1, LaunchServices.l11111ll, _1111ll1.nil )
    if l111ll11[0] is not None:
        return True
    return False
def l11lll():
    l111llll = []
    for name in l1l1l111:
        try:
            if l111l1l1(name):
                l111llll.append(name)
        except:
            continue
    return l111llll
def l1l11l(l1ll1l, l1llll):
    import plistlib
    import os
    l11ll1 = []
    l1ll1 = {}
    for l111l1ll in os.listdir(l111l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1ll.startswith(l1llll):
            try:
                l111lll1 = l111l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1ll
                with open(l111lll1, l111l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11 = plist[l111l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111lll = version.split(l111l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll1l == l1111lll:
                        if not l11 in l1ll1:
                            l1ll1[l11] = version
                        elif l111l1.l1111l(version, l1ll1[l11]) > 0:
                            l1ll1[l11] = version
            except BaseException:
                continue
    for l11 in l1ll1:
        l11ll1.append({l111l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1[l11], l111l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11})
    return l11ll1