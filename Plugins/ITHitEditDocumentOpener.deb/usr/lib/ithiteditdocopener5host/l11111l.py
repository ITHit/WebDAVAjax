#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l1 = 2048
l11ll = 7
def l11 (ll):
    global l1
    l1ll11 = ord (ll [-1])
    l1lll = ll [:-1]
    l1l11 = l1ll11 % len (l1lll)
    l11l1l = l1lll [:l1l11] + l1lll [l1l11:]
    if l1ll1l:
        l1l1ll = l1llll () .join ([unichr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    return eval (l1l1ll)
import subprocess, threading
from l1lll1 import l1l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1llllll():
    l11lll1l = [l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lll1l:
        try:
            l1l11111 = l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l11ll1l1(winreg.l11l1lll, l1l11111)
        except l11l1111:
            continue
        value = winreg.l1l11ll1(l11l1l1l, l11 (u"ࠦࠧ࢓"))
        return value.split(l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l111l():
    l11lllll = []
    for name in l1l1l11l:
        try:
            l1l11111 = l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1ll1 = winreg.l11ll1l1(winreg.l11l1lll, l1l11111)
            if winreg.l1l11ll1(l11l1ll1, l11 (u"ࠢࠣ࢖")):
                l11lllll.append(name)
        except l11l1111:
            continue
    return l11lllll
def l1ll1ll(l1111, l11ll1):
    import re
    l1l1l = []
    l1l1111l = winreg.l11ll1l1(winreg.l11l1lll, l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1l11(l1l1111l)[0]):
        try:
            l11l11l1 = winreg.l11lll11(l1l1111l, i)
            if l11l11l1.startswith(l11ll1):
                l11l111l = winreg.l1l111ll(l1l1111l, l11l11l1)
                value, l11ll1ll = winreg.l11llll1(l11l111l, l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11l11 = {l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11ll = m.group(2)
                    if l1111 == l11l11ll:
                        m = re.search(l11ll1.replace(l11 (u"ࠬ࠴࢛ࠧ"), l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l11l1)
                        l1l11l11[l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1l.append(l1l11l11)
                else:
                    raise ValueError(l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1111 as ex:
            continue
    return l1l1l
def l1l11l1l(l1111l):
    try:
        l1l111l1 = l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1111l)
        l1l11lll = winreg.l11ll1l1(winreg.l11l1lll, l1l111l1)
        value, l11ll1ll = winreg.l11llll1(l1l11lll, l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11 (u"ࠬࠨࠧࢢ"))[1]
    except l11l1111:
        pass
    return l11 (u"࠭ࠧࢣ")
def l1llll1(l1111l, url):
    threading.Thread(target=_11ll111,args=(l1111l, url)).start()
    return l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll111(l1111l, url):
    logger = l1l11l()
    l11ll11l = l1l11l1l(l1111l)
    logger.debug(l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll11l, url))
    retcode = subprocess.Popen(l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll11l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)