#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11lll = 2048
l1lll1 = 7
def l1l1l (l111l1):
    global l111l
    l111 = ord (l111l1 [-1])
    l1 = l111l1 [:-1]
    l1ll11 = l111 % len (l1)
    l11ll1 = l1 [:l1ll11] + l1 [l1ll11:]
    if l1ll1:
        l1l11 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    else:
        l1l11 = str () .join ([chr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    return eval (l1l11)
import l11ll
from l1l1l111 import l1l1l11l
import objc as _1111lll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111lll.l1111111( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l1111l1l(l111111l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111111l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1l (u"ࠨࠩࢬ"), {l1l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111lll1(l111l1l1):
    l111l1l1 = (l111l1l1 + l1l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111l111 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l111l111, _1111lll.nil )
    l1111l11 = LaunchServices.l111l1ll( l111ll11, LaunchServices.l111ll1l, _1111lll.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l1lll():
    l1111ll1 = []
    for name in l1l1l11l:
        try:
            if l111lll1(name):
                l1111ll1.append(name)
        except:
            continue
    return l1111ll1
def l1111(l1l11l, l1ll1l):
    import plistlib
    import os
    l1llll = []
    l11l1l = {}
    for l111llll in os.listdir(l1l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l1ll1l):
            try:
                l11111ll = l1l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l11111ll, l1l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l111ll = plist[l1l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l11l = version.split(l1l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l11l == l111l11l:
                        if not l111ll in l11l1l:
                            l11l1l[l111ll] = version
                        elif l11ll.l1l1l1(version, l11l1l[l111ll]) > 0:
                            l11l1l[l111ll] = version
            except BaseException:
                continue
    for l111ll in l11l1l:
        l1llll.append({l1l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l1l[l111ll], l1l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l111ll})
    return l1llll