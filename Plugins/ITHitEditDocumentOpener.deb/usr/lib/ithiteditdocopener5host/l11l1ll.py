#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111l (l1111l):
    global l1l11l
    l111l1 = ord (l1111l [-1])
    l1l111 = l1111l [:-1]
    l111ll = l111l1 % len (l1l111)
    l1 = l1l111 [:l111ll] + l1l111 [l111ll:]
    if l111:
        l1l1 = l1lll () .join ([unichr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    else:
        l1l1 = str () .join ([chr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    return eval (l1l1)
import subprocess, threading
from l1ll11 import l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1ll1ll():
    l1l11l11 = [l111l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l111l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l111l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l111l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11l11:
        try:
            l11l1lll = l111l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11ll1 = winreg.l11lll11(winreg.l1l1111l, l11l1lll)
        except l11l1l1l:
            continue
        value = winreg.l1l111l1(l1l11ll1, l111l (u"ࠦࠧ࢓"))
        return value.split(l111l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11ll11():
    l11ll1ll = []
    for name in l1l1l11l:
        try:
            l11l1lll = l111l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l11l1 = winreg.l11lll11(winreg.l1l1111l, l11l1lll)
            if winreg.l1l111l1(l11l11l1, l111l (u"ࠢࠣ࢖")):
                l11ll1ll.append(name)
        except l11l1l1l:
            continue
    return l11ll1ll
def l1l11ll(l1ll1l, l11ll):
    import re
    l11ll1 = []
    l1l11111 = winreg.l11lll11(winreg.l1l1111l, l111l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l1l(l1l11111)[0]):
        try:
            l1l11lll = winreg.l11l11ll(l1l11111, i)
            if l1l11lll.startswith(l11ll):
                l11l1ll1 = winreg.l11ll111(l1l11111, l1l11lll)
                value, l11l1111 = winreg.l11ll1l1(l11l1ll1, l111l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l111l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll11l = {l111l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1l11 = m.group(2)
                    if l1ll1l == l11l1l11:
                        m = re.search(l11ll.replace(l111l (u"ࠬ࠴࢛ࠧ"), l111l (u"࠭࡜࡝࠰ࠪ࢜")) + l111l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11lll)
                        l11ll11l[l111l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11ll1.append(l11ll11l)
                else:
                    raise ValueError(l111l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1l1l as ex:
            continue
    return l11ll1
def l11l111l(l1ll1):
    try:
        l11lllll = l111l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll1)
        l11lll1l = winreg.l11lll11(winreg.l1l1111l, l11lllll)
        value, l11l1111 = winreg.l11ll1l1(l11lll1l, l111l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l111l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1l1l:
        pass
    return l111l (u"࠭ࠧࢣ")
def l1l11l1(l1ll1, url):
    threading.Thread(target=_11llll1,args=(l1ll1, url)).start()
    return l111l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11llll1(l1ll1, url):
    logger = l11l()
    l1l111ll = l11l111l(l1ll1)
    logger.debug(l111l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l111ll, url))
    retcode = subprocess.Popen(l111l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l111ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l111l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l111l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)