#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1l1ll = 2048
l1l1l1 = 7
def l1111 (l1ll):
    global l1ll1
    l1l = ord (l1ll [-1])
    l1lll1 = l1ll [:-1]
    l1llll = l1l % len (l1lll1)
    l1 = l1lll1 [:l1llll] + l1lll1 [l1llll:]
    if l111ll:
        l111l = l11l1l () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    else:
        l111l = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    return eval (l111l)
import subprocess, threading
from l1lll import ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1lllll():
    l11ll1ll = [l1111 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1111 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1111 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1111 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11ll1ll:
        try:
            l1l11l1l = l1111 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1lll = winreg.l11l11ll(winreg.l11ll11l, l1l11l1l)
        except l11lllll:
            continue
        value = winreg.l11llll1(l11l1lll, l1111 (u"ࠦࠧ࢓"))
        return value.split(l1111 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll1ll():
    l11ll111 = []
    for name in l1l1l11l:
        try:
            l1l11l1l = l1111 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11lll = winreg.l11l11ll(winreg.l11ll11l, l1l11l1l)
            if winreg.l11llll1(l1l11lll, l1111 (u"ࠢࠣ࢖")):
                l11ll111.append(name)
        except l11lllll:
            continue
    return l11ll111
def l11l111(l111l1, l1l1):
    import re
    l11l1 = []
    l1l111l1 = winreg.l11l11ll(winreg.l11ll11l, l1111 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1111(l1l111l1)[0]):
        try:
            l11l1ll1 = winreg.l11l1l11(l1l111l1, i)
            if l11l1ll1.startswith(l1l1):
                l11lll1l = winreg.l1l1111l(l1l111l1, l11l1ll1)
                value, l11lll11 = winreg.l1l11111(l11lll1l, l1111 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1111 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l111l = {l1111 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11ll1 = m.group(2)
                    if l111l1 == l1l11ll1:
                        m = re.search(l1l1.replace(l1111 (u"ࠬ࠴࢛ࠧ"), l1111 (u"࠭࡜࡝࠰ࠪ࢜")) + l1111 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1ll1)
                        l11l111l[l1111 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l1.append(l11l111l)
                else:
                    raise ValueError(l1111 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11lllll as ex:
            continue
    return l11l1
def l11ll1l1(l1l1l):
    try:
        l1l11l11 = l1111 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1l)
        l11l11l1 = winreg.l11l11ll(winreg.l11ll11l, l1l11l11)
        value, l11lll11 = winreg.l1l11111(l11l11l1, l1111 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1111 (u"ࠬࠨࠧࢢ"))[1]
    except l11lllll:
        pass
    return l1111 (u"࠭ࠧࢣ")
def l1ll11l(l1l1l, url):
    threading.Thread(target=_11l1l1l,args=(l1l1l, url)).start()
    return l1111 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1l1l(l1l1l, url):
    logger = ll()
    l1l111ll = l11ll1l1(l1l1l)
    logger.debug(l1111 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l111ll, url))
    retcode = subprocess.Popen(l1111 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l111ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1111 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1111 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)