#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll = sys.version_info [0] == 2
l1l111 = 2048
l111 = 7
def l11 (l11l1):
    global l1111l
    l11l = ord (l11l1 [-1])
    l111ll = l11l1 [:-1]
    l1l11 = l11l % len (l111ll)
    l1l1l1 = l111ll [:l1l11] + l111ll [l1l11:]
    if l1lll:
        l1 = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    return eval (l1)
import subprocess, threading
from ll import l1ll1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11ll1l():
    l1l111ll = [l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l111ll:
        try:
            l11llll1 = l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll11l = winreg.l1l111l1(winreg.l11ll1ll, l11llll1)
        except l11l1lll:
            continue
        value = winreg.l11l1l1l(l11ll11l, l11 (u"ࠦࠧ࢓"))
        return value.split(l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11lll1():
    l11ll1l1 = []
    for name in l1l1l111:
        try:
            l11llll1 = l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lll1l = winreg.l1l111l1(winreg.l11ll1ll, l11llll1)
            if winreg.l11l1l1l(l11lll1l, l11 (u"ࠢࠣ࢖")):
                l11ll1l1.append(name)
        except l11l1lll:
            continue
    return l11ll1l1
def l1111ll(l11ll, l11ll1):
    import re
    l11l1l = []
    l11l1ll1 = winreg.l1l111l1(winreg.l11ll1ll, l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l111l(l11l1ll1)[0]):
        try:
            l11l1l11 = winreg.l1l1111l(l11l1ll1, i)
            if l11l1l11.startswith(l11ll1):
                l11l11l1 = winreg.l1l11lll(l11l1ll1, l11l1l11)
                value, l1l11l11 = winreg.l11l1111(l11l11l1, l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lllll = {l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll111 = m.group(2)
                    if l11ll == l11ll111:
                        m = re.search(l11ll1.replace(l11 (u"ࠬ࠴࢛ࠧ"), l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1l11)
                        l11lllll[l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l1l.append(l11lllll)
                else:
                    raise ValueError(l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1lll as ex:
            continue
    return l11l1l
def l11lll11(l1l1):
    try:
        l1l11111 = l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1)
        l11l11ll = winreg.l1l111l1(winreg.l11ll1ll, l1l11111)
        value, l1l11l11 = winreg.l11l1111(l11l11ll, l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11 (u"ࠬࠨࠧࢢ"))[1]
    except l11l1lll:
        pass
    return l11 (u"࠭ࠧࢣ")
def l1l11ll(l1l1, url):
    threading.Thread(target=_1l11ll1,args=(l1l1, url)).start()
    return l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11ll1(l1l1, url):
    logger = l1ll1()
    l1l11l1l = l11lll11(l1l1)
    logger.debug(l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l1l, url))
    retcode = subprocess.Popen(l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)