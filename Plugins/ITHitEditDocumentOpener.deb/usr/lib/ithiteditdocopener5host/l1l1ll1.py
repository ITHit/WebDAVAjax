#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111ll = 2048
l1l1l = 7
def l1ll11 (l1l1ll):
    global l11l1l
    l111l = ord (l1l1ll [-1])
    l11l11 = l1l1ll [:-1]
    l1l = l111l % len (l11l11)
    l1llll = l11l11 [:l1l] + l11l11 [l1l:]
    if l1lll1:
        l1111l = l1l11l () .join ([unichr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    return eval (l1111l)
import subprocess, threading
from l1l11 import l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11l111():
    l1l111ll = [l1ll11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l111ll:
        try:
            l1l11l11 = l1ll11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l111l = winreg.l11l1lll(winreg.l11l1ll1, l1l11l11)
        except l11lllll:
            continue
        value = winreg.l1l111l1(l11l111l, l1ll11 (u"ࠦࠧ࢓"))
        return value.split(l1ll11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111l11():
    l11llll1 = []
    for name in l1l1l111:
        try:
            l1l11l11 = l1ll11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l11ll = winreg.l11l1lll(winreg.l11l1ll1, l1l11l11)
            if winreg.l1l111l1(l11l11ll, l1ll11 (u"ࠢࠣ࢖")):
                l11llll1.append(name)
        except l11lllll:
            continue
    return l11llll1
def l1ll111(l1l1, l11l1):
    import re
    l11 = []
    l1l11ll1 = winreg.l11l1lll(winreg.l11l1ll1, l1ll11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l11l1(l1l11ll1)[0]):
        try:
            l1l1111l = winreg.l1l11l1l(l1l11ll1, i)
            if l1l1111l.startswith(l11l1):
                l11lll11 = winreg.l1l11lll(l1l11ll1, l1l1111l)
                value, l11ll11l = winreg.l1l11111(l11lll11, l1ll11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lll1l = {l1ll11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1l1l = m.group(2)
                    if l1l1 == l11l1l1l:
                        m = re.search(l11l1.replace(l1ll11 (u"ࠬ࠴࢛ࠧ"), l1ll11 (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l1111l)
                        l11lll1l[l1ll11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11.append(l11lll1l)
                else:
                    raise ValueError(l1ll11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11lllll as ex:
            continue
    return l11
def l11l1111(l1l111):
    try:
        l11ll111 = l1ll11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l111)
        l11ll1l1 = winreg.l11l1lll(winreg.l11l1ll1, l11ll111)
        value, l11ll11l = winreg.l1l11111(l11ll1l1, l1ll11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll11 (u"ࠬࠨࠧࢢ"))[1]
    except l11lllll:
        pass
    return l1ll11 (u"࠭ࠧࢣ")
def l1llllll(l1l111, url):
    threading.Thread(target=_11ll1ll,args=(l1l111, url)).start()
    return l1ll11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll1ll(l1l111, url):
    logger = l1()
    l11l1l11 = l11l1111(l1l111)
    logger.debug(l1ll11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1l11, url))
    retcode = subprocess.Popen(l1ll11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)