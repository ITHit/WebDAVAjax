#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1ll11 = 2048
l1l1ll = 7
def l11l (ll):
    global l111l1
    l1l11 = ord (ll [-1])
    l11ll1 = ll [:-1]
    l11ll = l1l11 % len (l11ll1)
    l1ll1 = l11ll1 [:l11ll] + l11ll1 [l11ll:]
    if l111ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    return eval (l1l1l1)
import subprocess, threading
from l1lll import l1l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l111l():
    l11lllll = [l11l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lllll:
        try:
            l1l11l11 = l11l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l111l1 = winreg.l11l1ll1(winreg.l11ll1ll, l1l11l11)
        except l1l11l1l:
            continue
        value = winreg.l1l111ll(l1l111l1, l11l (u"ࠦࠧ࢓"))
        return value.split(l11l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111l1l():
    l1l11ll1 = []
    for name in l1l1l111:
        try:
            l1l11l11 = l11l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l111l = winreg.l11l1ll1(winreg.l11ll1ll, l1l11l11)
            if winreg.l1l111ll(l11l111l, l11l (u"ࠢࠣ࢖")):
                l1l11ll1.append(name)
        except l1l11l1l:
            continue
    return l1l11ll1
def l11ll1l(l111, l1111l):
    import re
    l11lll = []
    l11lll1l = winreg.l11l1ll1(winreg.l11ll1ll, l11l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11lll(l11lll1l)[0]):
        try:
            l11ll11l = winreg.l11l1lll(l11lll1l, i)
            if l11ll11l.startswith(l1111l):
                l11l1l1l = winreg.l11lll11(l11lll1l, l11ll11l)
                value, l11ll1l1 = winreg.l11l1l11(l11l1l1l, l11l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l1111l = {l11l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1111 = m.group(2)
                    if l111 == l11l1111:
                        m = re.search(l1111l.replace(l11l (u"ࠬ࠴࢛ࠧ"), l11l (u"࠭࡜࡝࠰ࠪ࢜")) + l11l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll11l)
                        l1l1111l[l11l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11lll.append(l1l1111l)
                else:
                    raise ValueError(l11l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11l1l as ex:
            continue
    return l11lll
def l11ll111(l11l1):
    try:
        l1l11111 = l11l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1)
        l11l11l1 = winreg.l11l1ll1(winreg.l11ll1ll, l1l11111)
        value, l11ll1l1 = winreg.l11l1l11(l11l11l1, l11l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l (u"ࠬࠨࠧࢢ"))[1]
    except l1l11l1l:
        pass
    return l11l (u"࠭ࠧࢣ")
def l11llll(l11l1, url):
    threading.Thread(target=_11llll1,args=(l11l1, url)).start()
    return l11l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11llll1(l11l1, url):
    logger = l1l11l()
    l11l11ll = l11ll111(l11l1)
    logger.debug(l11l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11ll, url))
    retcode = subprocess.Popen(l11l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)