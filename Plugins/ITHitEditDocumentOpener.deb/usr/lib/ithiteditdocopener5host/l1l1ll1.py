#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1ll1 = 7
def l1l1l (l11lll):
    global l11l1
    l1l111 = ord (l11lll [-1])
    l1l = l11lll [:-1]
    l1l1ll = l1l111 % len (l1l)
    l1l1 = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l1llll:
        l1111 = l1111l () .join ([unichr (ord (char) - l1ll - (l1 + l1l111) % l1ll1) for l1, char in enumerate (l1l1)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll - (l1 + l1l111) % l1ll1) for l1, char in enumerate (l1l1)])
    return eval (l1111)
import l11l
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l11l.l111llll(l11111ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1l (u"ࠨࠩࢬ"), {l1l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l11(l11111l1):
    l11111l1 = (l11111l1 + l1l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll1l = CFStringCreateWithCString( kCFAllocatorDefault, l11111l1, kCFStringEncodingUTF8 )
    l1111lll = CFURLCreateWithString( kCFAllocatorDefault, l111ll1l, _1111ll1.nil )
    l111l1ll = LaunchServices.l111ll11( l1111lll, LaunchServices.l1111l1l, _1111ll1.nil )
    if l111l1ll[0] is not None:
        return True
    return False
def l1lll1():
    l111111l = []
    for name in l1l1l111:
        try:
            if l1111l11(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l11ll1(l1ll1l, l1l1l1):
    import plistlib
    import os
    l11 = []
    l111l = {}
    for l1111111 in os.listdir(l1l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111111.startswith(l1l1l1):
            try:
                l111l1l1 = l1l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111111
                with open(l111l1l1, l1l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1l = plist[l1l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l111 = version.split(l1l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll1l == l111l111:
                        if not l11l1l in l111l:
                            l111l[l11l1l] = version
                        elif l11l.l111ll(version, l111l[l11l1l]) > 0:
                            l111l[l11l1l] = version
            except BaseException:
                continue
    for l11l1l in l111l:
        l11.append({l1l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111l[l11l1l], l1l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1l})
    return l11