#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11lll = 2048
l1ll1 = 7
def l1l111 (l1l):
    global l1111
    ll = ord (l1l [-1])
    l111l1 = l1l [:-1]
    l111l = ll % len (l111l1)
    l11l1 = l111l1 [:l111l] + l111l1 [l111l:]
    if l1l1:
        l1lll = l1l11l () .join ([unichr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    else:
        l1lll = str () .join ([chr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    return eval (l1lll)
import l1ll
from l1l1l111 import l1l1l11l
import objc as _1111111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111111.l111llll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111ll.l111ll1l(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l111 (u"ࠨࠩࢬ"), {l1l111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l11111l1):
    l11111l1 = (l11111l1 + l1l111 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l1l = CFStringCreateWithCString( kCFAllocatorDefault, l11111l1, kCFStringEncodingUTF8 )
    l111l1ll = CFURLCreateWithString( kCFAllocatorDefault, l1111l1l, _1111111.nil )
    l111lll1 = LaunchServices.l111ll11( l111l1ll, LaunchServices.l111l111, _1111111.nil )
    if l111lll1[0] is not None:
        return True
    return False
def l11l():
    l1111ll1 = []
    for name in l1l1l11l:
        try:
            if l111l11l(name):
                l1111ll1.append(name)
        except:
            continue
    return l1111ll1
def l1lll1(l1111l, l1l1ll):
    import plistlib
    import os
    l11l11 = []
    l11 = {}
    for l111111l in os.listdir(l1l111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111111l.startswith(l1l1ll):
            try:
                l111l1l1 = l1l111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111111l
                with open(l111l1l1, l1l111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1llll = plist[l1l111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l1l111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111l == l1111l11:
                        if not l1llll in l11:
                            l11[l1llll] = version
                        elif l1ll.l1ll1l(version, l11[l1llll]) > 0:
                            l11[l1llll] = version
            except BaseException:
                continue
    for l1llll in l11:
        l11l11.append({l1l111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11[l1llll], l1l111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1llll})
    return l11l11