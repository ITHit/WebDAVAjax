#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1l = 7
def l11ll1 (ll):
    global l1l1
    l1l1ll = ord (ll [-1])
    l1ll11 = ll [:-1]
    l1l11 = l1l1ll % len (l1ll11)
    l11 = l1ll11 [:l1l11] + l1ll11 [l1l11:]
    if l11l1l:
        l1 = l11lll () .join ([unichr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    return eval (l1)
import os
import re
import subprocess
import l1111l
from l1111l import l1lll1
def l1111():
    return []
def l11l(l1l111, l1l):
    logger = l1lll1()
    l11ll = []
    l1l1l1 = [l11ll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1l1:
        try:
            output = os.popen(cmd).read()
            l111l = 0
            l111l1 = {}
            if l111l == 0:
                l1llll = re.compile(l11ll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111 = re.compile(l11ll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1lll = re.search(l1llll, line)
                    l1ll1l = l1lll.group(1)
                    if l1l111 == l1ll1l:
                        l11l1 = re.search(l111, line)
                        if l11l1:
                            l1ll = l11ll1 (u"ࠨࡦࡤࡺࠬࠄ")+l11l1.group(1)
                            version = l1lll.group(0)
                            if not l1ll in l111l1:
                                l111l1[l1ll] = version
                            elif l1111l.l111ll(version, l111l1[l1ll]) > 0:
                                l111l1[l1ll] = version
            for l1ll in l111l1:
                l11ll.append({l11ll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l1[l1ll], l11ll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll})
        except Exception as e:
            logger.error(str(e))
    return l11ll