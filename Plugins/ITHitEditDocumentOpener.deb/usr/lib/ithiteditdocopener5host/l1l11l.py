#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11l1 = 2048
l11 = 7
def l1lll1 (l1111l):
    global l1ll1
    l1llll = ord (l1111l [-1])
    l1lll = l1111l [:-1]
    l1l1 = l1llll % len (l1lll)
    l11l11 = l1lll [:l1l1] + l1lll [l1l1:]
    if l111l:
        l111ll = l11lll () .join ([unichr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    return eval (l111ll)
import os
import re
import subprocess
import ll
from ll import l11ll
def l1111():
    return []
def l1l(l11l, l1):
    logger = l11ll()
    l1l111 = []
    l11ll1 = [l1lll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1lll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11ll1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1l = process.wait()
            l111 = {}
            if l1l1l == 0:
                l1l1ll = re.compile(l1lll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll = re.compile(l1lll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll11 = re.search(l1l1ll, line)
                    l1l1l1 = l1ll11.group(1)
                    if l11l == l1l1l1:
                        l111l1 = re.search(l1ll, line)
                        if l111l1:
                            l1l11 = l1lll1 (u"ࠨࡦࡤࡺࠬࠄ")+l111l1.group(1)
                            version = l1ll11.group(0)
                            if not l1l11 in l111:
                                l111[l1l11] = version
                            elif ll.l1ll1l(version, l111[l1l11]) > 0:
                                l111[l1l11] = version
            for l1l11 in l111:
                l1l111.append({l1lll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111[l1l11], l1lll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l11})
        except Exception as e:
            logger.error(str(e))
    return l1l111