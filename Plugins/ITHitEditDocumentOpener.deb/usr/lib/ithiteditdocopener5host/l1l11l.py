#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l11 = 2048
l1l1 = 7
def l11l1l (l1l1ll):
    global l1lll
    l11 = ord (l1l1ll [-1])
    l1 = l1l1ll [:-1]
    l11l1 = l11 % len (l1)
    l1ll = l1 [:l11l1] + l1 [l11l1:]
    if l1111:
        ll = l1l () .join ([unichr (ord (char) - l1l11 - (l1l1l + l11) % l1l1) for l1l1l, char in enumerate (l1ll)])
    else:
        ll = str () .join ([chr (ord (char) - l1l11 - (l1l1l + l11) % l1l1) for l1l1l, char in enumerate (l1ll)])
    return eval (ll)
import os
import re
import subprocess
import l111l1
from l111l1 import l11ll1
def l1ll1l():
    return []
def l1llll(l111l, l1111l):
    logger = l11ll1()
    l1ll1 = []
    l1ll11 = [l11l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1l1 = process.wait()
            l1lll1 = {}
            if l1l1l1 == 0:
                l111ll = re.compile(l11l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l = re.compile(l11l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111 = re.search(l111ll, line)
                    l11ll = l111.group(1)
                    if l111l == l11ll:
                        l1l111 = re.search(l11l, line)
                        if l1l111:
                            l11lll = l11l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l111.group(1)
                            version = l111.group(0)
                            if not l11lll in l1lll1:
                                l1lll1[l11lll] = version
                            elif l111l1.l11l11(version, l1lll1[l11lll]) > 0:
                                l1lll1[l11lll] = version
            for l11lll in l1lll1:
                l1ll1.append({l11l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll1[l11lll], l11l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11lll})
        except Exception as e:
            logger.error(str(e))
    return l1ll1