#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111l1 = 2048
l1l111 = 7
def l1l11l (l1ll1l):
    global l1
    l11lll = ord (l1ll1l [-1])
    l1lll = l1ll1l [:-1]
    l111l = l11lll % len (l1lll)
    l1llll = l1lll [:l111l] + l1lll [l111l:]
    if l1l1l:
        l1111l = l1l1l1 () .join ([unichr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    return eval (l1111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll1l1(l11l1l1=None):
    if platform.system() == l1l11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll111
        props = {}
        try:
            prop_names = (l1l11l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l11l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l11l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l11l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l11l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l11l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l11l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l11l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l11l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l11l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l11l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11lll1 = l1ll111.l11l1ll(l11l1l1, l1l11l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1ll1ll in prop_names:
                l1llll1 = l1l11l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11lll1, l1ll1ll)
                props[l1ll1ll] = l1ll111.l11l1ll(l11l1l1, l1llll1)
        except:
            pass
    return props
def l1111ll(logger, l1l1lll):
    l1l1l1l = os.environ.get(l1l11l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l11l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l1l = l1l1l1l.upper()
    if l1l1l1l == l1l11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11llll = logging.DEBUG
    elif l1l1l1l == l1l11l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11llll = logging.INFO
    elif l1l1l1l == l1l11l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11llll = logging.WARNING
    elif l1l1l1l == l1l11l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11llll = logging.ERROR
    elif l1l1l1l == l1l11l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11llll = logging.CRITICAL
    elif l1l1l1l == l1l11l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11llll = logging.NOTSET
    logger.setLevel(l11llll)
    l111ll1 = RotatingFileHandler(l1l1lll, maxBytes=1024*1024*5, backupCount=3)
    l111ll1.setLevel(l11llll)
    formatter = logging.Formatter(l1l11l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111ll1.setFormatter(formatter)
    logger.addHandler(l111ll1)
    globals()[l1l11l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1111():
    return globals()[l1l11l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l11l():
    if platform.system() == l1l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l11l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1lll11
        l1lll11.l1ll11l(sys.stdin.fileno(), os.l111l11)
        l1lll11.l1ll11l(sys.stdout.fileno(), os.l111l11)
def l1lllll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l11l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1ll1():
    if platform.system() == l1l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1lll1l
        return l1lll1l.l11111l()
    elif platform.system() == l1l11l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll():
    if platform.system() == l1l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1lll1l
        return l1lll1l.l11ll1l()
    elif platform.system() == l1l11l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11l11
        return l11l11.l1ll()
    elif platform.system() == l1l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111111
        return l111111.l1ll()
    return l1l11l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l111l(l1l1ll, ll):
    if platform.system() == l1l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1lll1l
        return l1lll1l.l11ll11(l1l1ll, ll)
    elif platform.system() == l1l11l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111111
        return l111111.l1l(l1l1ll, ll)
    elif platform.system() == l1l11l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11l11
        return l11l11.l1l(l1l1ll, ll)
    raise ValueError(l1l11l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111lll(l1l11, url):
    if platform.system() == l1l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1lll1l
        return l1lll1l.l1111l1(l1l11, url)
    elif platform.system() == l1l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111111
        return l1l11l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l11l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11l11
        return l1l11l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111l1l():
    if platform.system() == l1l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1lll1l
        return l1lll1l.l111l1l()
def l1l11ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l11l (u"ࠩ࠱ࠫ࠶"))[0]
def l1l11l1(l111ll):
    l1l11l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1111 = l1l11l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111ll:
        if l1l11l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1111[3:]) < int(protocol[l1l11l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1111 = protocol[l1l11l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1111
def l11ll(l11111, l1llllll):
    l1l11l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11111 is None: l11111 = l1l11l (u"ࠩ࠳ࠫ࠽");
    if l1llllll is None: l1llllll = l1l11l (u"ࠪ࠴ࠬ࠾");
    l11l111 = l11111.split(l1l11l (u"ࠫ࠳࠭࠿"))
    l1l1l11 = l1llllll.split(l1l11l (u"ࠬ࠴ࠧࡀ"))
    while len(l11l111) < len(l1l1l11): l11l111.append(l1l11l (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1l11) < len(l11l111): l1l1l11.append(l1l11l (u"ࠢ࠱ࠤࡂ"));
    l11l111 = [ int(x) for x in l11l111 ]
    l1l1l11 = [ int(x) for x in l1l1l11 ]
    for  i in range(len(l11l111)):
        if len(l1l1l11) == i:
            return 1
        if l11l111[i] == l1l1l11[i]:
            continue
        elif l11l111[i] > l1l1l11[i]:
            return 1
        else:
            return -1
    if len(l11l111) != len(l1l1l11):
        return -1
    return 0