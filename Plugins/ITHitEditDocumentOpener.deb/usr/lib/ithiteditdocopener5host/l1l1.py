#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11l1l = 2048
l11l1 = 7
def l111l1 (l1l11l):
    global l11
    ll = ord (l1l11l [-1])
    l1ll = l1l11l [:-1]
    l1111 = ll % len (l1ll)
    l11ll = l1ll [:l1111] + l1ll [l1111:]
    if l1ll1:
        l11lll = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    return eval (l11lll)
import os
import re
import subprocess
import l111ll
from l111ll import l11l11
def l1ll11():
    return []
def l11l(l1l111, l1):
    logger = l11l11()
    l1l = []
    l1lll = [l111l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1lll:
        try:
            output = os.popen(cmd).read()
            l111 = 0
            l1111l = {}
            if l111 == 0:
                l1ll1l = re.compile(l111l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1l1 = re.compile(l111l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1llll = re.search(l1ll1l, line)
                    l1l1l = l1llll.group(1)
                    if l1l111 == l1l1l:
                        l1l1ll = re.search(l1l1l1, line)
                        if l1l1ll:
                            l111l = l111l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1ll.group(1)
                            version = l1llll.group(0)
                            if not l111l in l1111l:
                                l1111l[l111l] = version
                            elif l111ll.l1l11(version, l1111l[l111l]) > 0:
                                l1111l[l111l] = version
            for l111l in l1111l:
                l1l.append({l111l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111l[l111l], l111l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l})
        except Exception as e:
            logger.error(str(e))
    return l1l