#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1 = 2048
l1lll = 7
def l1ll11 (l1111l):
    global l1ll
    l11ll = ord (l1111l [-1])
    l111ll = l1111l [:-1]
    l1llll = l11ll % len (l111ll)
    l1l = l111ll [:l1llll] + l111ll [l1llll:]
    if l11:
        l11l1l = l111l1 () .join ([unichr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    return eval (l11l1l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l1l1l(l1l11l1=None):
    if platform.system() == l1ll11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1ll1ll
        props = {}
        try:
            prop_names = (l1ll11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1lll11 = l1ll1ll.l1ll11l(l1l11l1, l1ll11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11111l in prop_names:
                l1l111l = l1ll11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1lll11, l11111l)
                props[l11111l] = l1ll1ll.l1ll11l(l1l11l1, l1l111l)
        except:
            pass
    return props
def l111lll(logger, l11llll):
    l1lllll = os.environ.get(l1ll11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1lllll = l1lllll.upper()
    if l1lllll == l1ll11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1llllll = logging.DEBUG
    elif l1lllll == l1ll11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1llllll = logging.INFO
    elif l1lllll == l1ll11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1llllll = logging.WARNING
    elif l1lllll == l1ll11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1llllll = logging.ERROR
    elif l1lllll == l1ll11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1llllll = logging.CRITICAL
    elif l1lllll == l1ll11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1llllll = logging.NOTSET
    logger.setLevel(l1llllll)
    l11ll1l = RotatingFileHandler(l11llll, maxBytes=1024*1024*5, backupCount=3)
    l11ll1l.setLevel(l1llllll)
    formatter = logging.Formatter(l1ll11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11ll1l.setFormatter(formatter)
    logger.addHandler(l11ll1l)
    globals()[l1ll11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l111l():
    return globals()[l1ll11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll111():
    if platform.system() == l1ll11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111ll1
        l111ll1.l1l11ll(sys.stdin.fileno(), os.l11l1l1)
        l111ll1.l1l11ll(sys.stdout.fileno(), os.l11l1l1)
def l11lll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1111():
    if platform.system() == l1ll11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1lll1l
        return l1lll1l.l11l11l()
    elif platform.system() == l1ll11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l11l():
    if platform.system() == l1ll11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1lll1l
        return l1lll1l.l1111l1()
    elif platform.system() == l1ll11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import ll
        return ll.l1l11l()
    elif platform.system() == l1ll11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1l1
        return l1ll1l1.l1l11l()
    return l1ll11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1ll1(l11l11, l1l1ll):
    if platform.system() == l1ll11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1lll1l
        return l1lll1l.l1llll1(l11l11, l1l1ll)
    elif platform.system() == l1ll11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1l1
        return l1ll1l1.l11l(l11l11, l1l1ll)
    elif platform.system() == l1ll11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import ll
        return ll.l11l(l11l11, l1l1ll)
    raise ValueError(l1ll11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l1l11(l1l1l1, url):
    if platform.system() == l1ll11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1lll1l
        return l1lll1l.l11l111(l1l1l1, url)
    elif platform.system() == l1ll11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1l1
        return l1ll11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import ll
        return l1ll11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111l1l():
    if platform.system() == l1ll11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1lll1l
        return l1lll1l.l111l1l()
def l11l1ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll11 (u"ࠩ࠱ࠫ࠶"))[0]
def l11111(l1l11):
    l1ll11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111l11 = l1ll11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l11:
        if l1ll11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111l11[3:]) < int(protocol[l1ll11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111l11 = protocol[l1ll11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111l11
def l1ll1(l1l1lll, l1111ll):
    l1ll11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1lll is None: l1l1lll = l1ll11 (u"ࠩ࠳ࠫ࠽");
    if l1111ll is None: l1111ll = l1ll11 (u"ࠪ࠴ࠬ࠾");
    l11ll11 = l1l1lll.split(l1ll11 (u"ࠫ࠳࠭࠿"))
    l111111 = l1111ll.split(l1ll11 (u"ࠬ࠴ࠧࡀ"))
    while len(l11ll11) < len(l111111): l11ll11.append(l1ll11 (u"ࠨ࠰ࠣࡁ"));
    while len(l111111) < len(l11ll11): l111111.append(l1ll11 (u"ࠢ࠱ࠤࡂ"));
    l11ll11 = [ int(x) for x in l11ll11 ]
    l111111 = [ int(x) for x in l111111 ]
    for  i in range(len(l11ll11)):
        if len(l111111) == i:
            return 1
        if l11ll11[i] == l111111[i]:
            continue
        elif l11ll11[i] > l111111[i]:
            return 1
        else:
            return -1
    if len(l11ll11) != len(l111111):
        return -1
    return 0