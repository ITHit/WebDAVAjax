#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l1 = 2048
l11ll = 7
def l11 (ll):
    global l1
    l1ll11 = ord (ll [-1])
    l1lll = ll [:-1]
    l1l11 = l1ll11 % len (l1lll)
    l11l1l = l1lll [:l1l11] + l1lll [l1l11:]
    if l1ll1l:
        l1l1ll = l1llll () .join ([unichr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    return eval (l1l1ll)
import os
import re
import subprocess
import l1lll1
from l1lll1 import l1l11l
def l111():
    return []
def l11l(l1111, l11ll1):
    logger = l1l11l()
    l1l1l = []
    l11lll = [l11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1 = process.wait()
            l11l11 = {}
            if l1ll1 == 0:
                l1l = re.compile(l11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1 = re.compile(l11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l111 = re.search(l1l, line)
                    l1ll = l1l111.group(1)
                    if l1111 == l1ll:
                        l111l = re.search(l11l1, line)
                        if l111l:
                            l1111l = l11 (u"ࠨࡦࡤࡺࠬࠄ")+l111l.group(1)
                            version = l1l111.group(0)
                            if not l1111l in l11l11:
                                l11l11[l1111l] = version
                            elif l1lll1.l1l1l1(version, l11l11[l1111l]) > 0:
                                l11l11[l1111l] = version
            for l1111l in l11l11:
                l1l1l.append({l11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l11[l1111l], l11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1111l})
        except Exception as e:
            logger.error(str(e))
    return l1l1l