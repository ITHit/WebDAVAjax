#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll = sys.version_info [0] == 2
l11l1l = 2048
l1lll = 7
def l11l11 (l11lll):
    global l11ll1
    l1ll1l = ord (l11lll [-1])
    l1l11 = l11lll [:-1]
    l1111 = l1ll1l % len (l1l11)
    l11 = l1l11 [:l1111] + l1l11 [l1111:]
    if l1l1ll:
        l111l = l1l () .join ([unichr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    return eval (l111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1llll1(l11lll1=None):
    if platform.system() == l11l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11111l
        props = {}
        try:
            prop_names = (l11l11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111ll1 = l11111l.l1l1lll(l11lll1, l11l11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111l11 in prop_names:
                l11l1ll = l11l11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111ll1, l111l11)
                props[l111l11] = l11111l.l1l1lll(l11lll1, l11l1ll)
        except:
            pass
    return props
def l1111ll(logger, l11l1l1):
    l11ll1l = os.environ.get(l11l11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11ll1l = l11ll1l.upper()
    if l11ll1l == l11l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111l1l = logging.DEBUG
    elif l11ll1l == l11l11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111l1l = logging.INFO
    elif l11ll1l == l11l11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111l1l = logging.WARNING
    elif l11ll1l == l11l11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111l1l = logging.ERROR
    elif l11ll1l == l11l11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111l1l = logging.CRITICAL
    elif l11ll1l == l11l11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111l1l = logging.NOTSET
    logger.setLevel(l111l1l)
    l1lll11 = RotatingFileHandler(l11l1l1, maxBytes=1024*1024*5, backupCount=3)
    l1lll11.setLevel(l111l1l)
    formatter = logging.Formatter(l11l11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lll11.setFormatter(formatter)
    logger.addHandler(l1lll11)
    globals()[l11l11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def ll():
    return globals()[l11l11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l11():
    if platform.system() == l11l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11ll11
        l11ll11.l1l1l1l(sys.stdin.fileno(), os.l11111)
        l11ll11.l1l1l1l(sys.stdout.fileno(), os.l11111)
def l1ll1ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111111():
    if platform.system() == l11l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l111
        return l11l111.l1l11ll()
    elif platform.system() == l11l11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l1l1():
    if platform.system() == l11l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l111
        return l11l111.l11l11l()
    elif platform.system() == l11l11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1llll
        return l1llll.l1l1l1()
    elif platform.system() == l11l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1l1
        return l1ll1l1.l1l1l1()
    return l11l11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1llllll(l1ll, l111l1):
    if platform.system() == l11l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l111
        return l11l111.l1ll11l(l1ll, l111l1)
    elif platform.system() == l11l11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1l1
        return l1ll1l1.l11ll(l1ll, l111l1)
    elif platform.system() == l11l11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1llll
        return l1llll.l11ll(l1ll, l111l1)
    raise ValueError(l11l11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l1111(l1l1, url):
    if platform.system() == l11l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l111
        return l11l111.l1l111l(l1l1, url)
    elif platform.system() == l11l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1l1
        return l11l11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1llll
        return l11l11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll111():
    if platform.system() == l11l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l111
        return l11l111.l1ll111()
def l1l1ll1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l11 (u"ࠩ࠱ࠫ࠶"))[0]
def l1111l1(l1l111):
    l11l11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l11l1 = l11l11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l111:
        if l11l11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l11l1[3:]) < int(protocol[l11l11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l11l1 = protocol[l11l11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l11l1
def l11l(l11llll, l1lll1l):
    l11l11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11llll is None: l11llll = l11l11 (u"ࠩ࠳ࠫ࠽");
    if l1lll1l is None: l1lll1l = l11l11 (u"ࠪ࠴ࠬ࠾");
    l1lllll = l11llll.split(l11l11 (u"ࠫ࠳࠭࠿"))
    l111lll = l1lll1l.split(l11l11 (u"ࠬ࠴ࠧࡀ"))
    while len(l1lllll) < len(l111lll): l1lllll.append(l11l11 (u"ࠨ࠰ࠣࡁ"));
    while len(l111lll) < len(l1lllll): l111lll.append(l11l11 (u"ࠢ࠱ࠤࡂ"));
    l1lllll = [ int(x) for x in l1lllll ]
    l111lll = [ int(x) for x in l111lll ]
    for  i in range(len(l1lllll)):
        if len(l111lll) == i:
            return 1
        if l1lllll[i] == l111lll[i]:
            continue
        elif l1lllll[i] > l111lll[i]:
            return 1
        else:
            return -1
    if len(l1lllll) != len(l111lll):
        return -1
    return 0