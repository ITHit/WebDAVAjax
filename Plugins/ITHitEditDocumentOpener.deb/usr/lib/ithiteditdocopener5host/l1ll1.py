#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1111 (l111ll):
    global l11ll1
    l1l1l = ord (l111ll [-1])
    l1 = l111ll [:-1]
    l1llll = l1l1l % len (l1)
    l111l = l1 [:l1llll] + l1 [l1llll:]
    if l11l1:
        l11l = l1ll11 () .join ([unichr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    return eval (l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l11ll(l11l1ll=None):
    if platform.system() == l1111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111l1l
        props = {}
        try:
            prop_names = (l1111 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1111 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1111 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1111 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1111 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1111 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1111 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1111 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1111 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1111 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1111 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11lll1 = l111l1l.l1l1l1l(l11l1ll, l1111 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1ll11l in prop_names:
                l111l11 = l1111 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11lll1, l1ll11l)
                props[l1ll11l] = l111l1l.l1l1l1l(l11l1ll, l111l11)
        except:
            pass
    return props
def l1lll1l(logger, l1llll1):
    l1l1l11 = os.environ.get(l1111 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1111 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l11 = l1l1l11.upper()
    if l1l1l11 == l1111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l11l1 = logging.DEBUG
    elif l1l1l11 == l1111 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l11l1 = logging.INFO
    elif l1l1l11 == l1111 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l11l1 = logging.WARNING
    elif l1l1l11 == l1111 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l11l1 = logging.ERROR
    elif l1l1l11 == l1111 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l11l1 = logging.CRITICAL
    elif l1l1l11 == l1111 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l11l1 = logging.NOTSET
    logger.setLevel(l1l11l1)
    l1l1lll = RotatingFileHandler(l1llll1, maxBytes=1024*1024*5, backupCount=3)
    l1l1lll.setLevel(l1l11l1)
    formatter = logging.Formatter(l1111 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1lll.setFormatter(formatter)
    logger.addHandler(l1l1lll)
    globals()[l1111 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l11():
    return globals()[l1111 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1lll11():
    if platform.system() == l1111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1111 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111111
        l111111.l1lllll(sys.stdin.fileno(), os.l11ll1l)
        l111111.l1lllll(sys.stdout.fileno(), os.l11ll1l)
def l11111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1111 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111lll():
    if platform.system() == l1111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l11l
        return l11l11l.l11ll11()
    elif platform.system() == l1111 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l11():
    if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l11l
        return l11l11l.l11111l()
    elif platform.system() == l1111 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1lll1
        return l1lll1.l11l11()
    elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111ll1
        return l111ll1.l11l11()
    return l1111 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1ll1l1(l111l1, l1l111):
    if platform.system() == l1111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l11l
        return l11l11l.l1llllll(l111l1, l1l111)
    elif platform.system() == l1111 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111ll1
        return l111ll1.l11lll(l111l1, l1l111)
    elif platform.system() == l1111 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1lll1
        return l1lll1.l11lll(l111l1, l1l111)
    raise ValueError(l1111 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11llll(l1lll, url):
    if platform.system() == l1111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l11l
        return l11l11l.l1l1ll1(l1lll, url)
    elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111ll1
        return l1111 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1111 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1lll1
        return l1111 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1111ll():
    if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l11l
        return l11l11l.l1111ll()
def l1ll111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1111 (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll1ll(l111):
    l1111 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l111 = l1111 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111:
        if l1111 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l111[3:]) < int(protocol[l1111 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l111 = protocol[l1111 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l111
def l1l(l1l111l, l1111l1):
    l1111 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l111l is None: l1l111l = l1111 (u"ࠩ࠳ࠫ࠽");
    if l1111l1 is None: l1111l1 = l1111 (u"ࠪ࠴ࠬ࠾");
    l1l1111 = l1l111l.split(l1111 (u"ࠫ࠳࠭࠿"))
    l11l1l1 = l1111l1.split(l1111 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1111) < len(l11l1l1): l1l1111.append(l1111 (u"ࠨ࠰ࠣࡁ"));
    while len(l11l1l1) < len(l1l1111): l11l1l1.append(l1111 (u"ࠢ࠱ࠤࡂ"));
    l1l1111 = [ int(x) for x in l1l1111 ]
    l11l1l1 = [ int(x) for x in l11l1l1 ]
    for  i in range(len(l1l1111)):
        if len(l11l1l1) == i:
            return 1
        if l1l1111[i] == l11l1l1[i]:
            continue
        elif l1l1111[i] > l11l1l1[i]:
            return 1
        else:
            return -1
    if len(l1l1111) != len(l11l1l1):
        return -1
    return 0