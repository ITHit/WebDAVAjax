#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll11 = 7
def l1111l (l1llll):
    global l111l
    l11l11 = ord (l1llll [-1])
    l11ll = l1llll [:-1]
    l1l11 = l11l11 % len (l11ll)
    l1ll = l11ll [:l1l11] + l11ll [l1l11:]
    if l1l111:
        l1l1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    return eval (l1l1l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll1ll(l11ll1l=None):
    if platform.system() == l1111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1lll1l
        props = {}
        try:
            prop_names = (l1111l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1111l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1111l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1111l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1111l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1111l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1111l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1111l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1111l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1111l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1111l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1lllll = l1lll1l.l111l1l(l11ll1l, l1111l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11llll in prop_names:
                l1llll1 = l1111l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1lllll, l11llll)
                props[l11llll] = l1lll1l.l111l1l(l11ll1l, l1llll1)
        except:
            pass
    return props
def l111ll1(logger, l11lll1):
    l1l1ll1 = os.environ.get(l1111l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1111l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1ll1 = l1l1ll1.upper()
    if l1l1ll1 == l1111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111l1 = logging.DEBUG
    elif l1l1ll1 == l1111l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111l1 = logging.INFO
    elif l1l1ll1 == l1111l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111l1 = logging.WARNING
    elif l1l1ll1 == l1111l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111l1 = logging.ERROR
    elif l1l1ll1 == l1111l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111l1 = logging.CRITICAL
    elif l1l1ll1 == l1111l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111l1 = logging.NOTSET
    logger.setLevel(l1111l1)
    l1ll11l = RotatingFileHandler(l11lll1, maxBytes=1024*1024*5, backupCount=3)
    l1ll11l.setLevel(l1111l1)
    formatter = logging.Formatter(l1111l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll11l.setFormatter(formatter)
    logger.addHandler(l1ll11l)
    globals()[l1111l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l():
    return globals()[l1111l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1111():
    if platform.system() == l1111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1111l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll1l1
        l1ll1l1.l1l1lll(sys.stdin.fileno(), os.l11l1ll)
        l1ll1l1.l1l1lll(sys.stdout.fileno(), os.l11l1ll)
def l11111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1111l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1l1l():
    if platform.system() == l1111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l1l1
        return l11l1l1.l11l11l()
    elif platform.system() == l1111l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l1l():
    if platform.system() == l1111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l1l1
        return l11l1l1.l11111l()
    elif platform.system() == l1111l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1lll1
        return l1lll1.l1l1l()
    elif platform.system() == l1111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11ll11
        return l11ll11.l1l1l()
    return l1111l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lll11(l11lll, l11ll1):
    if platform.system() == l1111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l1l1
        return l11l1l1.l111lll(l11lll, l11ll1)
    elif platform.system() == l1111l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11ll11
        return l11ll11.l11l1l(l11lll, l11ll1)
    elif platform.system() == l1111l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1lll1
        return l1lll1.l11l1l(l11lll, l11ll1)
    raise ValueError(l1111l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111111(l111l1, url):
    if platform.system() == l1111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l1l1
        return l11l1l1.l1111ll(l111l1, url)
    elif platform.system() == l1111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11ll11
        return l1111l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1111l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1lll1
        return l1111l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l11ll():
    if platform.system() == l1111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l1l1
        return l11l1l1.l1l11ll()
def l1ll111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1111l (u"ࠩ࠱ࠫ࠶"))[0]
def l1l11l1(l111ll):
    l1111l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1l11 = l1111l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l111ll:
        if l1111l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1l11[3:]) < int(protocol[l1111l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1l11 = protocol[l1111l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1l11
def l1l11l(l11l111, l1llllll):
    l1111l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l111 is None: l11l111 = l1111l (u"ࠩ࠳ࠫ࠽");
    if l1llllll is None: l1llllll = l1111l (u"ࠪ࠴ࠬ࠾");
    l1l111l = l11l111.split(l1111l (u"ࠫ࠳࠭࠿"))
    l111l11 = l1llllll.split(l1111l (u"ࠬ࠴ࠧࡀ"))
    while len(l1l111l) < len(l111l11): l1l111l.append(l1111l (u"ࠨ࠰ࠣࡁ"));
    while len(l111l11) < len(l1l111l): l111l11.append(l1111l (u"ࠢ࠱ࠤࡂ"));
    l1l111l = [ int(x) for x in l1l111l ]
    l111l11 = [ int(x) for x in l111l11 ]
    for  i in range(len(l1l111l)):
        if len(l111l11) == i:
            return 1
        if l1l111l[i] == l111l11[i]:
            continue
        elif l1l111l[i] > l111l11[i]:
            return 1
        else:
            return -1
    if len(l1l111l) != len(l111l11):
        return -1
    return 0