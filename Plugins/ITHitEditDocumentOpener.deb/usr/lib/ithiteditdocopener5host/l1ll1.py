#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1l111 = 7
def l1ll (l111l):
    global l111l1
    l11l = ord (l111l [-1])
    l111ll = l111l [:-1]
    l1l11l = l11l % len (l111ll)
    l1111 = l111ll [:l1l11l] + l111ll [l1l11l:]
    if l11l1:
        l1l1 = l1lll () .join ([unichr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    else:
        l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    return eval (l1l1)
import os
import re
import subprocess
import ll
from ll import l1111l
def l1ll11():
    return []
def l1l11(l1, l11l11):
    logger = l1111l()
    l1lll1 = []
    l1ll1l = [l1ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1llll = process.wait()
            l1l1l1 = {}
            if l1llll == 0:
                l111 = re.compile(l1ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11 = re.compile(l1ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11ll1 = re.search(l111, line)
                    l1l = l11ll1.group(1)
                    if l1 == l1l:
                        l1l1l = re.search(l11, line)
                        if l1l1l:
                            l11lll = l1ll (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l.group(1)
                            version = l11ll1.group(0)
                            if not l11lll in l1l1l1:
                                l1l1l1[l11lll] = version
                            elif ll.l11ll(version, l1l1l1[l11lll]) > 0:
                                l1l1l1[l11lll] = version
            for l11lll in l1l1l1:
                l1lll1.append({l1ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l1l1[l11lll], l1ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11lll})
        except Exception as e:
            logger.error(str(e))
    return l1lll1