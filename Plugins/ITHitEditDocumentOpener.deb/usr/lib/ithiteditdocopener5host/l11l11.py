#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111l1 = 2048
l1l111 = 7
def l1l11l (l1ll1l):
    global l1
    l11lll = ord (l1ll1l [-1])
    l1lll = l1ll1l [:-1]
    l111l = l11lll % len (l1lll)
    l1llll = l1lll [:l111l] + l1lll [l111l:]
    if l1l1l:
        l1111l = l1l1l1 () .join ([unichr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    return eval (l1111l)
import os
import re
import subprocess
import l1l1
from l1l1 import l1111
def l1ll():
    return []
def l1l(l1l1ll, ll):
    logger = l1111()
    l1ll11 = []
    l11 = [l1l11l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l11l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11l = process.wait()
            l111ll = {}
            if l11l == 0:
                l1lll1 = re.compile(l1l11l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1 = re.compile(l1l11l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1l = re.search(l1lll1, line)
                    l11ll1 = l11l1l.group(1)
                    if l1l1ll == l11ll1:
                        l1ll1 = re.search(l11l1, line)
                        if l1ll1:
                            l1l11 = l1l11l (u"ࠨࡦࡤࡺࠬࠄ")+l1ll1.group(1)
                            version = l11l1l.group(0)
                            if not l1l11 in l111ll:
                                l111ll[l1l11] = version
                            elif l1l1.l11ll(version, l111ll[l1l11]) > 0:
                                l111ll[l1l11] = version
            for l1l11 in l111ll:
                l1ll11.append({l1l11l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111ll[l1l11], l1l11l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l11})
        except Exception as e:
            logger.error(str(e))
    return l1ll11