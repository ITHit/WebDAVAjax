#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1l11l = 2048
l1lll = 7
def l11ll (l1111):
    global l1l11
    l111 = ord (l1111 [-1])
    l1ll1 = l1111 [:-1]
    l1llll = l111 % len (l1ll1)
    l11 = l1ll1 [:l1llll] + l1ll1 [l1llll:]
    if l1ll:
        l1 = l11l1l () .join ([unichr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    return eval (l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l1l1l(l11l111=None):
    if platform.system() == l11ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1ll1
        props = {}
        try:
            prop_names = (l11ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11lll1 = l1l1ll1.l1111ll(l11l111, l11ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l1lll in prop_names:
                l11llll = l11ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11lll1, l1l1lll)
                props[l1l1lll] = l1l1ll1.l1111ll(l11l111, l11llll)
        except:
            pass
    return props
def l1ll1l1(logger, l1lllll):
    l1l1111 = os.environ.get(l11ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1111 = l1l1111.upper()
    if l1l1111 == l11ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1lll1l = logging.DEBUG
    elif l1l1111 == l11ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1lll1l = logging.INFO
    elif l1l1111 == l11ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1lll1l = logging.WARNING
    elif l1l1111 == l11ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1lll1l = logging.ERROR
    elif l1l1111 == l11ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1lll1l = logging.CRITICAL
    elif l1l1111 == l11ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1lll1l = logging.NOTSET
    logger.setLevel(l1lll1l)
    l11l1l1 = RotatingFileHandler(l1lllll, maxBytes=1024*1024*5, backupCount=3)
    l11l1l1.setLevel(l1lll1l)
    formatter = logging.Formatter(l11ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l1l1.setFormatter(formatter)
    logger.addHandler(l11l1l1)
    globals()[l11ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11ll1():
    return globals()[l11ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1llll1():
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll111
        l1ll111.l111l1l(sys.stdin.fileno(), os.l111l11)
        l1ll111.l111l1l(sys.stdout.fileno(), os.l111l11)
def l1l111l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111ll1():
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1llllll
        return l1llllll.l11111l()
    elif platform.system() == l11ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l111l():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1llllll
        return l1llllll.l1ll11l()
    elif platform.system() == l11ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l111l()
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111111
        return l111111.l111l()
    return l11ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lll11(l1111l, l11l1):
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1llllll
        return l1llllll.l1l1l11(l1111l, l11l1)
    elif platform.system() == l11ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111111
        return l111111.ll(l1111l, l11l1)
    elif platform.system() == l11ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.ll(l1111l, l11l1)
    raise ValueError(l11ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l11l(l1l1l1, url):
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1llllll
        return l1llllll.l11111(l1l1l1, url)
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111111
        return l11ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return l11ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11ll11():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1llllll
        return l1llllll.l11ll11()
def l111lll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1l11l1(l11l):
    l11ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11ll1l = l11ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11l:
        if l11ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11ll1l[3:]) < int(protocol[l11ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11ll1l = protocol[l11ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11ll1l
def l111l1(l1ll1ll, l11l1ll):
    l11ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll1ll is None: l1ll1ll = l11ll (u"ࠩ࠳ࠫ࠽");
    if l11l1ll is None: l11l1ll = l11ll (u"ࠪ࠴ࠬ࠾");
    l1l11ll = l1ll1ll.split(l11ll (u"ࠫ࠳࠭࠿"))
    l1111l1 = l11l1ll.split(l11ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1l11ll) < len(l1111l1): l1l11ll.append(l11ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1111l1) < len(l1l11ll): l1111l1.append(l11ll (u"ࠢ࠱ࠤࡂ"));
    l1l11ll = [ int(x) for x in l1l11ll ]
    l1111l1 = [ int(x) for x in l1111l1 ]
    for  i in range(len(l1l11ll)):
        if len(l1111l1) == i:
            return 1
        if l1l11ll[i] == l1111l1[i]:
            continue
        elif l1l11ll[i] > l1111l1[i]:
            return 1
        else:
            return -1
    if len(l1l11ll) != len(l1111l1):
        return -1
    return 0