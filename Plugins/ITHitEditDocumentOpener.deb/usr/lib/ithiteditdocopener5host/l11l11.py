#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1l1 = 7
def l1l111 (l111ll):
    global l1l11l
    l11l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l11l1 % len (l1llll)
    ll = l1llll [:l11l] + l1llll [l11l:]
    if l1l11:
        l11 = l1l1ll () .join ([unichr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    else:
        l11 = str () .join ([chr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    return eval (l11)
import os
import re
import subprocess
import l1l
from l1l import l1111l
def l11l1l():
    return []
def l11ll(l1ll1l, l1l1l):
    logger = l1111l()
    l1 = []
    l1l1l1 = [l1l111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll1 = process.wait()
            l1111 = {}
            if l11ll1 == 0:
                l1ll = re.compile(l1l111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1 = re.compile(l1l111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111l = re.search(l1ll, line)
                    l1lll = l111l.group(1)
                    if l1ll1l == l1lll:
                        l111 = re.search(l1ll1, line)
                        if l111:
                            l1lll1 = l1l111 (u"ࠨࡦࡤࡺࠬࠄ")+l111.group(1)
                            version = l111l.group(0)
                            if not l1lll1 in l1111:
                                l1111[l1lll1] = version
                            elif l1l.l11lll(version, l1111[l1lll1]) > 0:
                                l1111[l1lll1] = version
            for l1lll1 in l1111:
                l1.append({l1l111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111[l1lll1], l1l111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1lll1})
        except Exception as e:
            logger.error(str(e))
    return l1