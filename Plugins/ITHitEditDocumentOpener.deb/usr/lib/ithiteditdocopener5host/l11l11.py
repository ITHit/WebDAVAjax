#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1ll1 = 7
def l1l1l (l11lll):
    global l11l1
    l1l111 = ord (l11lll [-1])
    l1l = l11lll [:-1]
    l1l1ll = l1l111 % len (l1l)
    l1l1 = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l1llll:
        l1111 = l1111l () .join ([unichr (ord (char) - l1ll - (l1 + l1l111) % l1ll1) for l1, char in enumerate (l1l1)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll - (l1 + l1l111) % l1ll1) for l1, char in enumerate (l1l1)])
    return eval (l1111)
import os
import re
import subprocess
import l11l
from l11l import l1lll
def l1lll1():
    return []
def l11ll1(l1ll1l, l1l1l1):
    logger = l1lll()
    l11 = []
    l11ll = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11ll:
        try:
            output = os.popen(cmd).read()
            ll = 0
            l111l = {}
            if ll == 0:
                l1l11l = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll11 = re.search(l1l11l, line)
                    l111l1 = l1ll11.group(1)
                    if l1ll1l == l111l1:
                        l111 = re.search(l1l11, line)
                        if l111:
                            l11l1l = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l111.group(1)
                            version = l1ll11.group(0)
                            if not l11l1l in l111l:
                                l111l[l11l1l] = version
                            elif l11l.l111ll(version, l111l[l11l1l]) > 0:
                                l111l[l11l1l] = version
            for l11l1l in l111l:
                l11.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l[l11l1l], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1l})
        except Exception as e:
            logger.error(str(e))
    return l11