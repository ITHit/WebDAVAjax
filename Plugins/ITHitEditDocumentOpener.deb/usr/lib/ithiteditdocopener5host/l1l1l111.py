#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111l (l1111l):
    global l1l11l
    l111l1 = ord (l1111l [-1])
    l1l111 = l1111l [:-1]
    l111ll = l111l1 % len (l1l111)
    l1 = l1l111 [:l111ll] + l1l111 [l111ll:]
    if l111:
        l1l1 = l1lll () .join ([unichr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    else:
        l1l1 = str () .join ([chr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    return eval (l1l1)
l1l1l11l = [l111l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l111l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l111l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l111l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l111l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l111l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l111l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l111l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l111l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]