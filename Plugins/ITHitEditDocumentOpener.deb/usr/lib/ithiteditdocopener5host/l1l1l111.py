#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1l = 2048
l11 = 7
def l11l1 (l11l):
    global l111
    l11lll = ord (l11l [-1])
    l1ll1l = l11l [:-1]
    l111ll = l11lll % len (l1ll1l)
    l111l1 = l1ll1l [:l111ll] + l1ll1l [l111ll:]
    if l111l:
        l1ll = l1111l () .join ([unichr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    return eval (l1ll)
l1l1l11l = [l11l1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]