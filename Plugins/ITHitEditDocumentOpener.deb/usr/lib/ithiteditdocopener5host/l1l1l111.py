#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l1l (l11ll1):
    global l1l1ll
    l1llll = ord (l11ll1 [-1])
    l11l1l = l11ll1 [:-1]
    l111 = l1llll % len (l11l1l)
    l11lll = l11l1l [:l111] + l11l1l [l111:]
    if l111l1:
        l11l = l111l () .join ([unichr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    return eval (l11l)
l1l1l11l = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]