#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1111l = 2048
l1ll = 7
def l1l11l (l1):
    global l11l11
    l111l1 = ord (l1 [-1])
    l1llll = l1 [:-1]
    l1ll11 = l111l1 % len (l1llll)
    l1l1ll = l1llll [:l1ll11] + l1llll [l1ll11:]
    if l111ll:
        l11l1 = l1l () .join ([unichr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    return eval (l11l1)
l1l1l11l = [l1l11l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l11l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l11l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l11l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l11l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l11l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l11l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l11l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l11l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]