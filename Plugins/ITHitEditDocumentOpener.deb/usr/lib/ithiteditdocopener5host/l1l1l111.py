#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1l1ll (l1l11):
    global l11ll1
    l1ll11 = ord (l1l11 [-1])
    l111ll = l1l11 [:-1]
    l1lll = l1ll11 % len (l111ll)
    l1ll1l = l111ll [:l1lll] + l111ll [l1lll:]
    if l1llll:
        l1lll1 = l11l1l () .join ([unichr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    return eval (l1lll1)
l1l1l11l = [l1l1ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]