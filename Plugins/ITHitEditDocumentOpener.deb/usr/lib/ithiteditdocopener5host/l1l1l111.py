#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11lll = 2048
l1lll1 = 7
def l1l1l (l111l1):
    global l111l
    l111 = ord (l111l1 [-1])
    l1 = l111l1 [:-1]
    l1ll11 = l111 % len (l1)
    l11ll1 = l1 [:l1ll11] + l1 [l1ll11:]
    if l1ll1:
        l1l11 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    else:
        l1l11 = str () .join ([chr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    return eval (l1l11)
l1l1l11l = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]