#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
l1l111 = 2048
l1ll11 = 7
def l1l1 (l111l1):
    global l11ll
    l1111l = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l1ll1 = l1111l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l111:
        l11ll1 = l1111 () .join ([unichr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    else:
        l11ll1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l1111l) % l1ll11) for l1l11l, char in enumerate (l11l11)])
    return eval (l11ll1)
l1l1l11l = [l1l1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]