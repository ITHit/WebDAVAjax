#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1 = 2048
l1lll = 7
def l1ll11 (l1111l):
    global l1ll
    l11ll = ord (l1111l [-1])
    l111ll = l1111l [:-1]
    l1llll = l11ll % len (l111ll)
    l1l = l111ll [:l1llll] + l111ll [l1llll:]
    if l11:
        l11l1l = l111l1 () .join ([unichr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    return eval (l11l1l)
l1l1l11l = [l1ll11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]