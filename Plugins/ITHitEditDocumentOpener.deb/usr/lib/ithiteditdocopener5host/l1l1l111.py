#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1111l = 2048
ll = 7
def l1ll (l11l):
    global l1l111
    l1lll = ord (l11l [-1])
    l1l1l1 = l11l [:-1]
    l111l1 = l1lll % len (l1l1l1)
    l11l1 = l1l1l1 [:l111l1] + l1l1l1 [l111l1:]
    if l111l:
        l1l1ll = l111 () .join ([unichr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    return eval (l1l1ll)
l1l1l11l = [l1ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]