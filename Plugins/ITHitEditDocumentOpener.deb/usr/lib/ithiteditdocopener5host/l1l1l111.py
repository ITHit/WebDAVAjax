#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1 = 2048
l1111 = 7
def l11ll (l1ll1l):
    global l11ll1
    l11l1 = ord (l1ll1l [-1])
    l1l = l1ll1l [:-1]
    l1l1ll = l11l1 % len (l1l)
    l11lll = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l111ll:
        l1ll = l11l () .join ([unichr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    return eval (l1ll)
l1l1l11l = [l11ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]