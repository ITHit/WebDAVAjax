#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11lll = 2048
l1ll1 = 7
def l1l111 (l1l):
    global l1111
    ll = ord (l1l [-1])
    l111l1 = l1l [:-1]
    l111l = ll % len (l111l1)
    l11l1 = l111l1 [:l111l] + l111l1 [l111l:]
    if l1l1:
        l1lll = l1l11l () .join ([unichr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    else:
        l1lll = str () .join ([chr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    return eval (l1lll)
l1l1l11l = [l1l111 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l111 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l111 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l111 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l111 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l111 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l111 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l111 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l111 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]