#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll11 = 2048
l111ll = 7
def l11ll (l11l11):
    global l1111
    l11l1 = ord (l11l11 [-1])
    l1 = l11l11 [:-1]
    ll = l11l1 % len (l1)
    l1ll1 = l1 [:ll] + l1 [ll:]
    if l1l1l1:
        l11l1l = l1l11l () .join ([unichr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    return eval (l11l1l)
l1l1l11l = [l11ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]