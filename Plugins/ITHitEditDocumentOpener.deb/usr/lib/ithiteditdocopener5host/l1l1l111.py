#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1lll = 2048
l11l1 = 7
def l111 (l1ll11):
    global l1l11
    l11l1l = ord (l1ll11 [-1])
    l1l1l = l1ll11 [:-1]
    l1l1ll = l11l1l % len (l1l1l)
    l1llll = l1l1l [:l1l1ll] + l1l1l [l1l1ll:]
    if l1ll:
        l1111l = l111ll () .join ([unichr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    return eval (l1111l)
l1l1l11l = [l111 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l111 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l111 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l111 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l111 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l111 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l111 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l111 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l111 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]