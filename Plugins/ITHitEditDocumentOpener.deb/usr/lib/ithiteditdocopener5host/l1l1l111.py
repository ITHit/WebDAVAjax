#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll1 = 2048
l11l = 7
def l1l1l (l111ll):
    global l1l1
    l1l11 = ord (l111ll [-1])
    l11l11 = l111ll [:-1]
    l1111l = l1l11 % len (l11l11)
    l1l1ll = l11l11 [:l1111l] + l11l11 [l1111l:]
    if l1ll11:
        l111 = l1l111 () .join ([unichr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    return eval (l111)
l1l1l11l = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]