#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1l111 = 7
def l1ll (l111l):
    global l111l1
    l11l = ord (l111l [-1])
    l111ll = l111l [:-1]
    l1l11l = l11l % len (l111ll)
    l1111 = l111ll [:l1l11l] + l111ll [l1l11l:]
    if l11l1:
        l1l1 = l1lll () .join ([unichr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    else:
        l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    return eval (l1l1)
l1l1l11l = [l1ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]