#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11l1 = 2048
l11 = 7
def l1lll1 (l1111l):
    global l1ll1
    l1llll = ord (l1111l [-1])
    l1lll = l1111l [:-1]
    l1l1 = l1llll % len (l1lll)
    l11l11 = l1lll [:l1l1] + l1lll [l1l1:]
    if l111l:
        l111ll = l11lll () .join ([unichr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    return eval (l111ll)
l1l1l11l = [l1lll1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1lll1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1lll1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1lll1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1lll1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1lll1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1lll1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1lll1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1lll1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]