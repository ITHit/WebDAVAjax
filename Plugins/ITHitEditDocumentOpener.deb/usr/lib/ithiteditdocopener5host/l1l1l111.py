#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1l1 = 7
def l1l111 (l111ll):
    global l1l11l
    l11l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l11l1 % len (l1llll)
    ll = l1llll [:l11l] + l1llll [l11l:]
    if l1l11:
        l11 = l1l1ll () .join ([unichr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    else:
        l11 = str () .join ([chr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    return eval (l11)
l1l1l11l = [l1l111 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l111 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l111 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l111 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l111 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l111 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l111 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l111 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l111 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]