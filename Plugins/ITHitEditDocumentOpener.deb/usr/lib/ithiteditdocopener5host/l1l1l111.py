#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll = 2048
l1ll1l = 7
def l1l1l (l1l1l1):
    global l11l1l
    l11l = ord (l1l1l1 [-1])
    l111l1 = l1l1l1 [:-1]
    l1l1ll = l11l % len (l111l1)
    ll = l111l1 [:l1l1ll] + l111l1 [l1l1ll:]
    if l1ll11:
        l11l11 = l11 () .join ([unichr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    return eval (l11l11)
l1l1l11l = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]