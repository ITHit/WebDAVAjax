#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
l1ll1 = 7
def l1llll (l11):
    global l111
    l1lll = ord (l11 [-1])
    l111l1 = l11 [:-1]
    l11ll = l1lll % len (l111l1)
    l1l = l111l1 [:l11ll] + l111l1 [l11ll:]
    if l1ll1l:
        l111l = l111ll () .join ([unichr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    return eval (l111l)
l1l1l11l = [l1llll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1llll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1llll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1llll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1llll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1llll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1llll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1llll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1llll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]