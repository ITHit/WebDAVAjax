#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1l11 = 2048
l11l1 = 7
def l1llll (l1l1ll):
    global l111
    l11lll = ord (l1l1ll [-1])
    l1111l = l1l1ll [:-1]
    l1 = l11lll % len (l1111l)
    l1lll = l1111l [:l1] + l1111l [l1:]
    if l111l1:
        l1l1l = l111ll () .join ([unichr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    return eval (l1l1l)
l1l1l11l = [l1llll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1llll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1llll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1llll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1llll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1llll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1llll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1llll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1llll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]