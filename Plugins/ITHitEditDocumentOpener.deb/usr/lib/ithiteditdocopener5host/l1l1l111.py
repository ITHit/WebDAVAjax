#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l111l (l11):
    global l1lll
    l11l = ord (l11 [-1])
    l11ll1 = l11 [:-1]
    l1l1 = l11l % len (l11ll1)
    l1lll1 = l11ll1 [:l1l1] + l11ll1 [l1l1:]
    if l1ll1l:
        l111l1 = l1ll () .join ([unichr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    return eval (l111l1)
l1l1l11l = [l111l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l111l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l111l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l111l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l111l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l111l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l111l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l111l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l111l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]