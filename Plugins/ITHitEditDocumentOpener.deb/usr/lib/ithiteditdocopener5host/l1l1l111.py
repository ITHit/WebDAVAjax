#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll = sys.version_info [0] == 2
l111l1 = 2048
l1ll1 = 7
def l11ll1 (l1l1l1):
    global l1l11
    l111ll = ord (l1l1l1 [-1])
    l1l1l = l1l1l1 [:-1]
    l1 = l111ll % len (l1l1l)
    l1111 = l1l1l [:l1] + l1l1l [l1:]
    if l11lll:
        l1l11l = l111l () .join ([unichr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    return eval (l1l11l)
l1l1l11l = [l11ll1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]