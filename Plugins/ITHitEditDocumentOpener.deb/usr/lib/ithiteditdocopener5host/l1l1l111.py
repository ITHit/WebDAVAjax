#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1 = 7
def l11l1l (l11lll):
    global l111ll
    l1lll = ord (l11lll [-1])
    l1l111 = l11lll [:-1]
    l1ll1 = l1lll % len (l1l111)
    l1llll = l1l111 [:l1ll1] + l1l111 [l1ll1:]
    if l11:
        l11l = l111l1 () .join ([unichr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    return eval (l11l)
l1l1l11l = [l11l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]