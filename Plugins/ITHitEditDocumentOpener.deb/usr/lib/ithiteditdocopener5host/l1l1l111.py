#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l1l11l = 2048
l11l1l = 7
def l11l11 (l1l1l1):
    global l11ll
    l11 = ord (l1l1l1 [-1])
    l11lll = l1l1l1 [:-1]
    l1111 = l11 % len (l11lll)
    l1 = l11lll [:l1111] + l11lll [l1111:]
    if l1lll1:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    return eval (l1ll1l)
l1l1l11l = [l11l11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]