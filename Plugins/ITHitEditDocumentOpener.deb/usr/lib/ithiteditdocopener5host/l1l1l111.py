#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1111 = 7
def l1l1l (l1111l):
    global l1l111
    l11lll = ord (l1111l [-1])
    l1l11l = l1111l [:-1]
    l1ll11 = l11lll % len (l1l11l)
    l11 = l1l11l [:l1ll11] + l1l11l [l1ll11:]
    if l1l1:
        l111ll = l1llll () .join ([unichr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    return eval (l111ll)
l1l1l11l = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]