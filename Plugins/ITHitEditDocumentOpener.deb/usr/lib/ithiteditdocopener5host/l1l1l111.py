#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1 = 2048
l111 = 7
def l1lll (l1l111):
    global l11l1l
    l1l = ord (l1l111 [-1])
    l11lll = l1l111 [:-1]
    l1ll1 = l1l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l1l1l:
        l1l1ll = l1ll11 () .join ([unichr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    return eval (l1l1ll)
l1l1l11l = [l1lll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1lll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1lll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1lll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1lll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1lll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1lll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1lll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1lll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]