#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l1l = 7
def l111 (l1ll):
    global l1l1l1
    l1l11 = ord (l1ll [-1])
    l1 = l1ll [:-1]
    l11lll = l1l11 % len (l1)
    l1l1ll = l1 [:l11lll] + l1 [l11lll:]
    if l1ll11:
        l1111l = l1ll1 () .join ([unichr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    return eval (l1111l)
l1l1l11l = [l111 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l111 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l111 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l111 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l111 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l111 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l111 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l111 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l111 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]