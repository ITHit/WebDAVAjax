#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1l1 (l1l):
    global l1l1l
    l11l = ord (l1l [-1])
    l11lll = l1l [:-1]
    l1lll = l11l % len (l11lll)
    l1ll = l11lll [:l1lll] + l11lll [l1lll:]
    if l1l11l:
        l1ll11 = l1lll1 () .join ([unichr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    return eval (l1ll11)
l1l1l11l = [l1l1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]