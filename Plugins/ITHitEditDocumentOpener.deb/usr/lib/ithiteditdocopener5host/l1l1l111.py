#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def ll (l111):
    global l111ll
    l1111l = ord (l111 [-1])
    l11ll1 = l111 [:-1]
    l1ll = l1111l % len (l11ll1)
    l1l11 = l11ll1 [:l1ll] + l11ll1 [l1ll:]
    if l1llll:
        l11ll = l1l () .join ([unichr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    return eval (l11ll)
l1l11lll = [ll (u"ࠧࡳࡳ࠮ࡹࡲࡶࡩࠨࢆ"), ll (u"ࠨ࡭ࡴ࠯ࡳࡳࡼ࡫ࡲࡱࡱ࡬ࡲࡹࠨࢇ"), ll (u"ࠢ࡮ࡵ࠰ࡩࡽࡩࡥ࡭ࠤ࢈"), ll (u"ࠣ࡯ࡶ࠱ࡻ࡯ࡳࡪࡱࠥࢉ"), ll (u"ࠤࡰࡷ࠲ࡧࡣࡤࡧࡶࡷࠧࢊ"), ll (u"ࠥࡱࡸ࠳ࡰࡳࡱ࡭ࡩࡨࡺࠢࢋ"), ll (u"ࠦࡲࡹ࠭ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴࠥࢌ"),
                      ll (u"ࠧࡳࡳ࠮ࡵࡳࡨࠧࢍ"), ll (u"ࠨ࡭ࡴ࠯࡬ࡲ࡫ࡵࡰࡢࡶ࡫ࠦࢎ")]