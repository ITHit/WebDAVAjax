#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1 = 7
def l1l1l1 (l111l):
    global l111ll
    l1111 = ord (l111l [-1])
    l1l11l = l111l [:-1]
    ll = l1111 % len (l1l11l)
    l11l11 = l1l11l [:ll] + l1l11l [ll:]
    if l1111l:
        l11lll = l1l111 () .join ([unichr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    return eval (l11lll)
l1l1l11l = [l1l1l1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]