#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l1l11l):
    global l11lll
    l1l1l = ord (l1l11l [-1])
    l1l11 = l1l11l [:-1]
    l11l = l1l1l % len (l1l11)
    l11l1 = l1l11 [:l11l] + l1l11 [l11l:]
    if l1l1l1:
        l1l1ll = l1lll1 () .join ([unichr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    return eval (l1l1ll)
l1l1l11l = [l11l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]