#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111ll (l1l1l):
    global l11ll
    l1111l = ord (l1l1l [-1])
    l11l = l1l1l [:-1]
    l11l1l = l1111l % len (l11l)
    l1l11l = l11l [:l11l1l] + l11l [l11l1l:]
    if l1ll11:
        l1ll1l = l1l1l1 () .join ([unichr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    return eval (l1ll1l)
l1l1l11l = [l111ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l111ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l111ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l111ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l111ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l111ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l111ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l111ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l111ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]