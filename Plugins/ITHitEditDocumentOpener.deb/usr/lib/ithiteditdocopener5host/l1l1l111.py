#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1ll11 = 2048
l1111 = 7
def l1l (l1l1):
    global l11l1l
    l11ll = ord (l1l1 [-1])
    l1lll1 = l1l1 [:-1]
    l1111l = l11ll % len (l1lll1)
    l1l11l = l1lll1 [:l1111l] + l1lll1 [l1111l:]
    if l1l1l:
        l1lll = l1llll () .join ([unichr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    return eval (l1lll)
l1l1l11l = [l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]