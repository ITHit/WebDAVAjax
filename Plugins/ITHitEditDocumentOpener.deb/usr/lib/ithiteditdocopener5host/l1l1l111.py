#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1lll1 (l11):
    global l11l11
    l1111l = ord (l11 [-1])
    l1lll = l11 [:-1]
    l1l1ll = l1111l % len (l1lll)
    l1l = l1lll [:l1l1ll] + l1lll [l1l1ll:]
    if l1:
        l11ll = l1111 () .join ([unichr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    return eval (l11ll)
l1l1l11l = [l1lll1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1lll1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1lll1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1lll1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1lll1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1lll1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1lll1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1lll1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1lll1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]