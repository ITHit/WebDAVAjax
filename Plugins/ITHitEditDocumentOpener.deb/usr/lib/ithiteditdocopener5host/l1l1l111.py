#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l1l1ll (l1ll):
    global l111l1
    l11l11 = ord (l1ll [-1])
    l11l1 = l1ll [:-1]
    l1l11 = l11l11 % len (l11l1)
    l111l = l11l1 [:l1l11] + l11l1 [l1l11:]
    if l1l1l:
        l1l11l = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    return eval (l1l11l)
l1l1l11l = [l1l1ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]