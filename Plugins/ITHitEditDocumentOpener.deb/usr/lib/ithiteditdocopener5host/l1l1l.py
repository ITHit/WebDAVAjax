#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l11l1 = 2048
l1 = 7
def l1ll1 (l11l11):
    global l1l1ll
    l111l = ord (l11l11 [-1])
    l1l = l11l11 [:-1]
    l1llll = l111l % len (l1l)
    l1lll = l1l [:l1llll] + l1l [l1llll:]
    if ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l1l1)
import os
import re
import subprocess
import l1111l
from l1111l import l11ll1
def l1lll1():
    return []
def l1ll11(l111ll, l11ll):
    logger = l11ll1()
    l11l1l = []
    l1l11l = [l1ll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l11l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            l11l = {}
            if l111l1 == 0:
                l1l111 = re.compile(l1ll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11 = re.compile(l1ll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll1l = re.search(l1l111, line)
                    l11lll = l1ll1l.group(1)
                    if l111ll == l11lll:
                        l111 = re.search(l1l11, line)
                        if l111:
                            l1l1 = l1ll1 (u"ࠨࡦࡤࡺࠬࠄ")+l111.group(1)
                            version = l1ll1l.group(0)
                            if not l1l1 in l11l:
                                l11l[l1l1] = version
                            elif l1111l.l11(version, l11l[l1l1]) > 0:
                                l11l[l1l1] = version
            for l1l1 in l11l:
                l11l1l.append({l1ll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l[l1l1], l1ll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1})
        except Exception as e:
            logger.error(str(e))
    return l11l1l