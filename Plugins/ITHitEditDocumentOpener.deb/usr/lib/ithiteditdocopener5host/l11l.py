#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll11 = 2048
l111ll = 7
def l11ll (l11l11):
    global l1111
    l11l1 = ord (l11l11 [-1])
    l1 = l11l11 [:-1]
    ll = l11l1 % len (l1)
    l1ll1 = l1 [:ll] + l1 [ll:]
    if l1l1l1:
        l11l1l = l1l11l () .join ([unichr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    return eval (l11l1l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11ll11(l1111l1=None):
    if platform.system() == l11ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l11ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111111 = l1l1lll.l1ll111(l1111l1, l11ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111ll1 in prop_names:
                l11ll1l = l11ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111111, l111ll1)
                props[l111ll1] = l1l1lll.l1ll111(l1111l1, l11ll1l)
        except:
            pass
    return props
def l1lllll(logger, l1llll1):
    l1l1ll1 = os.environ.get(l11ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1ll1 = l1l1ll1.upper()
    if l1l1ll1 == l11ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1llllll = logging.DEBUG
    elif l1l1ll1 == l11ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1llllll = logging.INFO
    elif l1l1ll1 == l11ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1llllll = logging.WARNING
    elif l1l1ll1 == l11ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1llllll = logging.ERROR
    elif l1l1ll1 == l11ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1llllll = logging.CRITICAL
    elif l1l1ll1 == l11ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1llllll = logging.NOTSET
    logger.setLevel(l1llllll)
    l11l1ll = RotatingFileHandler(l1llll1, maxBytes=1024*1024*5, backupCount=3)
    l11l1ll.setLevel(l1llllll)
    formatter = logging.Formatter(l11ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11l1ll.setFormatter(formatter)
    logger.addHandler(l11l1ll)
    globals()[l11ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l111l():
    return globals()[l11ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l11():
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1lll11
        l1lll11.l1lll1l(sys.stdin.fileno(), os.l1ll1ll)
        l1lll11.l1lll1l(sys.stdout.fileno(), os.l1ll1ll)
def l111l11(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l1l():
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1ll1l1
        return l1ll1l1.l11111()
    elif platform.system() == l11ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l11():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1ll1l1
        return l1ll1l1.l1l111l()
    elif platform.system() == l11ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l1ll
        return l1l1ll.l1l11()
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11l111
        return l11l111.l1l11()
    return l11ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11llll(l11ll1, l111):
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1ll1l1
        return l1ll1l1.l1l1l1l(l11ll1, l111)
    elif platform.system() == l11ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11l111
        return l11l111.l1lll1(l11ll1, l111)
    elif platform.system() == l11ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l1ll
        return l1l1ll.l1lll1(l11ll1, l111)
    raise ValueError(l11ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1111ll(l1ll, url):
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1ll1l1
        return l1ll1l1.l1l11ll(l1ll, url)
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11l111
        return l11ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l1ll
        return l11ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11lll1():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1ll1l1
        return l1ll1l1.l11lll1()
def l11l11l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1111(l1llll):
    l11ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1ll11l = l11ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1llll:
        if l11ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1ll11l[3:]) < int(protocol[l11ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1ll11l = protocol[l11ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1ll11l
def l111l1(l11111l, l11l1l1):
    l11ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11111l is None: l11111l = l11ll (u"ࠩ࠳ࠫ࠽");
    if l11l1l1 is None: l11l1l1 = l11ll (u"ࠪ࠴ࠬ࠾");
    l1l11l1 = l11111l.split(l11ll (u"ࠫ࠳࠭࠿"))
    l111lll = l11l1l1.split(l11ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1l11l1) < len(l111lll): l1l11l1.append(l11ll (u"ࠨ࠰ࠣࡁ"));
    while len(l111lll) < len(l1l11l1): l111lll.append(l11ll (u"ࠢ࠱ࠤࡂ"));
    l1l11l1 = [ int(x) for x in l1l11l1 ]
    l111lll = [ int(x) for x in l111lll ]
    for  i in range(len(l1l11l1)):
        if len(l111lll) == i:
            return 1
        if l1l11l1[i] == l111lll[i]:
            continue
        elif l1l11l1[i] > l111lll[i]:
            return 1
        else:
            return -1
    if len(l1l11l1) != len(l111lll):
        return -1
    return 0