#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11lll = 2048
l1lll1 = 7
def l1l1l (l111l1):
    global l111l
    l111 = ord (l111l1 [-1])
    l1 = l111l1 [:-1]
    l1ll11 = l111 % len (l1)
    l11ll1 = l1 [:l1ll11] + l1 [l1ll11:]
    if l1ll1:
        l1l11 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    else:
        l1l11 = str () .join ([chr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    return eval (l1l11)
import os
import re
import subprocess
import l11ll
from l11ll import ll
def l1lll():
    return []
def l1111(l1l11l, l1ll1l):
    logger = ll()
    l1llll = []
    l1ll = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11 = process.wait()
            l11l1l = {}
            if l11 == 0:
                l1l111 = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1111l = re.search(l1l111, line)
                    l11l11 = l1111l.group(1)
                    if l1l11l == l11l11:
                        l1l = re.search(l1l1, line)
                        if l1l:
                            l111ll = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1l.group(1)
                            version = l1111l.group(0)
                            if not l111ll in l11l1l:
                                l11l1l[l111ll] = version
                            elif l11ll.l1l1l1(version, l11l1l[l111ll]) > 0:
                                l11l1l[l111ll] = version
            for l111ll in l11l1l:
                l1llll.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l1l[l111ll], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111ll})
        except Exception as e:
            logger.error(str(e))
    return l1llll