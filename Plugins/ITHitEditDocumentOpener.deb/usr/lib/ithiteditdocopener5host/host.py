#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l111l (l11):
    global l1lll
    l11l = ord (l11 [-1])
    l11ll1 = l11 [:-1]
    l1l1 = l11l % len (l11ll1)
    l1lll1 = l11ll1 [:l1l1] + l11ll1 [l1l1:]
    if l1ll1l:
        l111l1 = l1ll () .join ([unichr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    return eval (l111l1)
import json
import struct
from l1l11 import *
l1l1ll11 = sys.version_info[0] == 2
l1ll111l = l111l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = l111l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l111l (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠸࠻࠴࠰ࠣࡅ")
l1lll11l = l111l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1ll1l1l.replace(l111l (u"ࠧࠦࠢࡇ"), l111l (u"ࠨ࡟ࠣࡈ")) + l111l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1ll = {}
if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l111l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l11l1 = sys.argv[0]
        try:
            l1lll1ll = l11llll(l1l11l1)
            l1ll1l1l = l1lll1ll[l111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1ll[l111l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll11l = l1lll1ll[l111l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1ll1l1l.replace(l111l (u"ࠨࠠࠣࡏ"), l111l (u"ࠢࡠࠤࡐ")) + l111l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll1l = os.path.join(os.environ.get(l111l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1llll11 = os.path.join(os.environ.get(l111l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l111l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll11l.split(l111l (u"ࠨࠬࠣࡖ"))[0].replace(l111l (u"ࠢࠡࠤࡗ"), l111l (u"ࠣࡡࠥࡘ")).lower())
    l1lll1l1 = l111l11(l1llll11 + l111l (u"ࠤ࠲࡙ࠦ"))
    l1l1ll1l = os.path.join(l1lll1l1, l1ll11ll)
elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1llll11 = os.path.join(os.environ.get(l111l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l111l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll11l.split(l111l (u"ࠨࠬࠣ࡝"))[0].replace(l111l (u"ࠢࠡࠤ࡞"), l111l (u"ࠣࡡࠥ࡟")).lower())
    l1lll1l1 = l111l11(l1llll11 + l111l (u"ࠤ࠲ࠦࡠ"))
    l1l1ll1l = os.path.join(l1lll1l1, l1ll11ll)
else:
    l1l1ll1l = os.path.join(l1ll11ll)
logger = logging.getLogger(l111l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l11ll(logger, l1l1ll1l)
logger.info(l111l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l111l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(l111l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l111l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll11l)
logger.info(l111l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll111l)
l11ll = get_major_version(VERSION)
l1111 = l1ll1l1(l11ll, l1ll111l)
logger.info(l111l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11ll)
logger.info(l111l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111)
logger.info(l111l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l111l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll111():
    if l1l1ll11:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1l1():
    if l1l1ll11:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1111():
    l1ll1lll = l1lll111().read(4)
    while len(l1ll1lll) == 4:
        l1llll1l = struct.unpack(l111l (u"ࠨࡀࡊࠤ࡫"), l1ll1lll)[0]
        request = l1lll111().read(l1llll1l).decode()
        logger.info(l111l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lllll1(request)
        l1l1l1ll(response)
        logger.info(l111l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1lll = l1lll111().read(4)
    logger.info(l111l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1l1ll(message):
    message = json.dumps(message).encode()
    l1l1llll = struct.pack(l111l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1l1().write(l1l1llll)
    l1l1l1l1().write(message)
    l1l1l1l1().flush()
def l1lllll1(request):
    if request:
        l1ll11l1 = json.loads(request)
    try:
        return {
            l111l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1111l,
            l111l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11111,
            l111l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l111
        }[l1ll11l1[l111l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll11l1)
    except Exception as e:
        logger.error(l111l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1111l()
def l1111l(l1ll11l1=None):
    l1l1lll1(l1ll11l1)
    l1ll1ll1 = {l111l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1()}
    l1ll1ll1[l111l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1lll1l(l1111)
    return l1ll1ll1
def l11111(l1ll11l1):
    url = l1ll11l1[l111l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1l = url.split(l111l (u"ࠬࡀࠧࡸ"))[0]
    return {l111l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1llllll(l1l1l, url)}
def l11l111(l1ll11l1):
    try:
        l1l1l = l111111(l1111)
        url = l111l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1l, l1ll11l1[l111l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll11l1[l111l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l111l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1l, url))
        return {l111l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1llllll(l1l1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l111l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1lll1(l1ll11l1):
    l1ll1l11 = l111l (u"࠭ࠧࢀ")
    if l1ll11l1:
        for name in l1ll11l1:
            if name in [l111l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l111l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l11 += l111l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll11l1[name]
    if l1ll1l11: logger.info(l1ll1l11[:-1])
def main():
    try:
        l11l11l()
        l1ll1111()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l111l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()