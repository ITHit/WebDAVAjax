#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l = sys.version_info [0] == 2
l1111 = 2048
l111 = 7
def l1l1 (l1llll):
    global l1l11
    l1l11l = ord (l1llll [-1])
    l11l11 = l1llll [:-1]
    l1l1l = l1l11l % len (l11l11)
    l111ll = l11l11 [:l1l1l] + l11l11 [l1l1l:]
    if l11l:
        l1 = l1l () .join ([unichr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    else:
        l1 = str () .join ([chr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    return eval (l1)
import json
import struct
from l1ll1l import *
l1ll1lll = sys.version_info[0] == 2
l1ll1111 = l1l1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1ll1 = l1l1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1 (u"ࠥ࠺࠳࠸࠮࠹࠻࠷࠸࠳࠶ࠢࡅ")
l1ll111l = l1l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll1ll = l1ll1ll1.replace(l1l1 (u"ࠧࠦࠢࡇ"), l1l1 (u"ࠨ࡟ࠣࡈ")) + l1l1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1lll1 = {}
if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11111 = sys.argv[0]
        try:
            l1l1lll1 = l1111ll(l11111)
            l1ll1ll1 = l1l1lll1[l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1lll1[l1l1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll111l = l1l1lll1[l1l1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll1ll = l1ll1ll1.replace(l1l1 (u"ࠨࠠࠣࡏ"), l1l1 (u"ࠢࡠࠤࡐ")) + l1l1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll11l = os.path.join(os.environ.get(l1l1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll1ll)
elif platform.system() == l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l1l = os.path.join(os.environ.get(l1l1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll111l.split(l1l1 (u"ࠨࠬࠣࡖ"))[0].replace(l1l1 (u"ࠢࠡࠤࡗ"), l1l1 (u"ࠣࡡࠥࡘ")).lower())
    l1ll11l1 = l11l1ll(l1ll1l1l + l1l1 (u"ࠤ࠲࡙ࠦ"))
    l1lll11l = os.path.join(l1ll11l1, l1lll1ll)
elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l1l = os.path.join(os.environ.get(l1l1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll111l.split(l1l1 (u"ࠨࠬࠣ࡝"))[0].replace(l1l1 (u"ࠢࠡࠤ࡞"), l1l1 (u"ࠣࡡࠥ࡟")).lower())
    l1ll11l1 = l11l1ll(l1ll1l1l + l1l1 (u"ࠤ࠲ࠦࡠ"))
    l1lll11l = os.path.join(l1ll11l1, l1lll1ll)
else:
    l1lll11l = os.path.join(l1lll1ll)
logger = logging.getLogger(l1l1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11ll1l(logger, l1lll11l)
logger.info(l1l1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1ll1)
logger.info(l1l1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll111l)
logger.info(l1l1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l111l = get_major_version(VERSION)
l1lll1 = l1l11l1(l111l, l1ll1111)
logger.info(l1l1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111l)
logger.info(l1l1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll1)
logger.info(l1l1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1l11():
    if l1ll1lll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll11ll():
    if l1ll1lll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1ll1l():
    l1lll1l1 = l1ll1l11().read(4)
    while len(l1lll1l1) == 4:
        l1llll1l = struct.unpack(l1l1 (u"ࠨࡀࡊࠤ࡫"), l1lll1l1)[0]
        request = l1ll1l11().read(l1llll1l).decode()
        logger.info(l1l1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1l1ll(request)
        l1lll111(response)
        logger.info(l1l1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1l1 = l1ll1l11().read(4)
    logger.info(l1l1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll111(message):
    message = json.dumps(message).encode()
    l1lllll1 = struct.pack(l1l1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll11ll().write(l1lllll1)
    l1ll11ll().write(message)
    l1ll11ll().flush()
def l1l1l1ll(request):
    if request:
        l1l1ll11 = json.loads(request)
    try:
        return {
            l1l1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11,
            l1l1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l111l11,
            l1l1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l111
        }[l1l1ll11[l1l1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1ll11)
    except Exception as e:
        logger.error(l1l1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11()
def l11(l1l1ll11=None):
    l1llll11(l1l1ll11)
    l1l1l1l1 = {l1l1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1()}
    l1l1l1l1[l1l1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1llll1(l1lll1)
    return l1l1l1l1
def l111l11(l1l1ll11):
    url = l1l1ll11[l1l1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l111l1 = url.split(l1l1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111111(l111l1, url)}
def l11l111(l1l1ll11):
    try:
        l111l1 = l1ll111(l1lll1)
        url = l1l1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l111l1, l1l1ll11[l1l1 (u"ࠨࡣࡦࡸࠬࡻ")], l1l1ll11[l1l1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l111l1, url))
        return {l1l1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111111(l111l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll11(l1l1ll11):
    l1l1llll = l1l1 (u"࠭ࠧࢀ")
    if l1l1ll11:
        for name in l1l1ll11:
            if name in [l1l1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1llll += l1l1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1ll11[name]
    if l1l1llll: logger.info(l1l1llll[:-1])
def main():
    try:
        l111lll()
        l1l1ll1l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()