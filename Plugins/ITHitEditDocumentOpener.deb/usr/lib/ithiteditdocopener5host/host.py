#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l111 = 2048
l1l1l = 7
def l1l11 (l1l1l1):
    global l11l1l
    l1l1 = ord (l1l1l1 [-1])
    l11ll = l1l1l1 [:-1]
    l1llll = l1l1 % len (l11ll)
    l1lll1 = l11ll [:l1llll] + l11ll [l1llll:]
    if l1ll11:
        l1ll1l = l1l111 () .join ([unichr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l111 - (l111l + l1l1) % l1l1l) for l111l, char in enumerate (l1lll1)])
    return eval (l1ll1l)
import json
import struct
from l1lll import *
l1ll11l1 = sys.version_info[0] == 2
l1l1lll1 = l1l11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lllll1 = l1l11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l11 (u"ࠥ࠺࠳࠶࠮࠹࠹࠶࠴࠳࠶ࠢࡅ")
l1lll1l1 = l1l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1llll = l1lllll1.replace(l1l11 (u"ࠧࠦࠢࡇ"), l1l11 (u"ࠨ࡟ࠣࡈ")) + l1l11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l1l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lllll = sys.argv[0]
        try:
            l1ll1l11 = l1l1lll(l1lllll)
            l1lllll1 = l1ll1l11[l1l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l1l11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll1l1 = l1ll1l11[l1l11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1llll = l1lllll1.replace(l1l11 (u"ࠨࠠࠣࡏ"), l1l11 (u"ࠢࡠࠤࡐ")) + l1l11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1lll = os.path.join(os.environ.get(l1l11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1llll)
elif platform.system() == l1l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l1l = os.path.join(os.environ.get(l1l11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll1l1.split(l1l11 (u"ࠨࠬࠣࡖ"))[0].replace(l1l11 (u"ࠢࠡࠤࡗ"), l1l11 (u"ࠣࡡࠥࡘ")).lower())
    l1lll1ll = l11111l(l1ll1l1l + l1l11 (u"ࠤ࠲࡙ࠦ"))
    l1ll1lll = os.path.join(l1lll1ll, l1l1llll)
elif platform.system() == l1l11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l1l = os.path.join(os.environ.get(l1l11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll1l1.split(l1l11 (u"ࠨࠬࠣ࡝"))[0].replace(l1l11 (u"ࠢࠡࠤ࡞"), l1l11 (u"ࠣࡡࠥ࡟")).lower())
    l1lll1ll = l11111l(l1ll1l1l + l1l11 (u"ࠤ࠲ࠦࡠ"))
    l1ll1lll = os.path.join(l1lll1ll, l1l1llll)
else:
    l1ll1lll = os.path.join(l1l1llll)
logger = logging.getLogger(l1l11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111l11(logger, l1ll1lll)
logger.info(l1l11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lllll1)
logger.info(l1l11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll1l1)
logger.info(l1l11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1lll1)
l1ll1 = get_major_version(VERSION)
ll = l1ll11l(l1ll1, l1l1lll1)
logger.info(l1l11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1ll1)
logger.info(l1l11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % ll)
logger.info(l1l11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1ll1l():
    if l1ll11l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll111l():
    if l1ll11l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1llll11():
    l1ll1ll1 = l1l1ll1l().read(4)
    while len(l1ll1ll1) == 4:
        l1l1l1l1 = struct.unpack(l1l11 (u"ࠨࡀࡊࠤ࡫"), l1ll1ll1)[0]
        request = l1l1ll1l().read(l1l1l1l1).decode()
        logger.info(l1l11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1ll11(request)
        l1llll1l(response)
        logger.info(l1l11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1ll1 = l1l1ll1l().read(4)
    logger.info(l1l11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll1l(message):
    message = json.dumps(message).encode()
    l1ll11ll = struct.pack(l1l11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll111l().write(l1ll11ll)
    l1ll111l().write(message)
    l1ll111l().flush()
def l1l1ll11(request):
    if request:
        l1lll111 = json.loads(request)
    try:
        return {
            l1l11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11lll,
            l1l11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1111,
            l1l11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11lll1
        }[l1lll111[l1l11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll111)
    except Exception as e:
        logger.error(l1l11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11lll()
def l11lll(l1lll111=None):
    l1l1l1ll(l1lll111)
    l1ll1111 = {l1l11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l11()}
    l1ll1111[l1l11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1111l1(ll)
    return l1ll1111
def l1l1111(l1lll111):
    url = l1lll111[l1l11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1 = url.split(l1l11 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1ll111(l11l1, url)}
def l11lll1(l1lll111):
    try:
        l11l1 = l11111(ll)
        url = l1l11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1, l1lll111[l1l11 (u"ࠨࡣࡦࡸࠬࡻ")], l1lll111[l1l11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1, url))
        return {l1l11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1ll111(l11l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1l1ll(l1lll111):
    l1lll11l = l1l11 (u"࠭ࠧࢀ")
    if l1lll111:
        for name in l1lll111:
            if name in [l1l11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll11l += l1l11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll111[name]
    if l1lll11l: logger.info(l1lll11l[:-1])
def main():
    try:
        l1ll1ll()
        l1llll11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()