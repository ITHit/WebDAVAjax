#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l1l (l11ll1):
    global l1l1ll
    l1llll = ord (l11ll1 [-1])
    l11l1l = l11ll1 [:-1]
    l111 = l1llll % len (l11l1l)
    l11lll = l11l1l [:l111] + l11l1l [l111:]
    if l111l1:
        l11l = l111l () .join ([unichr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    return eval (l11l)
import json
import struct
from l1l import *
l1l1l1ll = sys.version_info[0] == 2
l1ll1l1l = l1l1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1ll11 = l1l1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1l (u"ࠥ࠹࠳࠸࠰࠯࠷࠻࠴࠼࠴࠰ࠣࡅ")
l1lll1l1 = l1l1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1lll1 = l1l1ll11.replace(l1l1l (u"ࠧࠦࠢࡇ"), l1l1l (u"ࠨ࡟ࠣࡈ")) + l1l1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11ll = {}
if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l1lll = sys.argv[0]
        try:
            l1ll11ll = l11l1l1(l1l1lll)
            l1l1ll11 = l1ll11ll[l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11ll[l1l1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll1l1 = l1ll11ll[l1l1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1lll1 = l1l1ll11.replace(l1l1l (u"ࠨࠠࠣࡏ"), l1l1l (u"ࠢࡠࠤࡐ")) + l1l1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1l11 = os.path.join(os.environ.get(l1l1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1lll1)
elif platform.system() == l1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll11l1 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll1l1.split(l1l1l (u"ࠨࠬࠣࡖ"))[0].replace(l1l1l (u"ࠢࠡࠤࡗ"), l1l1l (u"ࠣࡡࠥࡘ")).lower())
    l1lll111 = l1l1l1l(l1ll11l1 + l1l1l (u"ࠤ࠲࡙ࠦ"))
    l1ll1l11 = os.path.join(l1lll111, l1l1lll1)
elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll11l1 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll1l1.split(l1l1l (u"ࠨࠬࠣ࡝"))[0].replace(l1l1l (u"ࠢࠡࠤ࡞"), l1l1l (u"ࠣࡡࠥ࡟")).lower())
    l1lll111 = l1l1l1l(l1ll11l1 + l1l1l (u"ࠤ࠲ࠦࡠ"))
    l1ll1l11 = os.path.join(l1lll111, l1l1lll1)
else:
    l1ll1l11 = os.path.join(l1l1lll1)
logger = logging.getLogger(l1l1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111111(logger, l1ll1l11)
logger.info(l1l1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1ll11)
logger.info(l1l1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll1l1)
logger.info(l1l1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1l1l)
l1ll11 = get_major_version(VERSION)
l1ll1 = l11ll11(l1ll11, l1ll1l1l)
logger.info(l1l1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1ll11)
logger.info(l1l1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1)
logger.info(l1l1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1ll1():
    if l1l1l1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1llll1l():
    if l1l1l1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1llll():
    l1lll1ll = l1ll1ll1().read(4)
    while len(l1lll1ll) == 4:
        l1lllll1 = struct.unpack(l1l1l (u"ࠨࡀࡊࠤ࡫"), l1lll1ll)[0]
        request = l1ll1ll1().read(l1lllll1).decode()
        logger.info(l1l1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll11(request)
        l1ll1lll(response)
        logger.info(l1l1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1ll = l1ll1ll1().read(4)
    logger.info(l1l1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1lll(message):
    message = json.dumps(message).encode()
    l1ll1111 = struct.pack(l1l1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1llll1l().write(l1ll1111)
    l1llll1l().write(message)
    l1llll1l().flush()
def l1llll11(request):
    if request:
        l1l1l1l1 = json.loads(request)
    try:
        return {
            l1l1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1ll1l,
            l1l1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11ll1l,
            l1l1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll1ll
        }[l1l1l1l1[l1l1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1l1)
    except Exception as e:
        logger.error(l1l1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1ll1l()
def l1ll1l(l1l1l1l1=None):
    l1l1ll1l(l1l1l1l1)
    l1lll11l = {l1l1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): ll()}
    l1lll11l[l1l1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l111l(l1ll1)
    return l1lll11l
def l11ll1l(l1l1l1l1):
    url = l1l1l1l1[l1l1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1 = url.split(l1l1l (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l111(l1, url)}
def l1ll1ll(l1l1l1l1):
    try:
        l1 = l1ll11l(l1ll1)
        url = l1l1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1, l1l1l1l1[l1l1l (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1l1[l1l1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1, url))
        return {l1l1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l111(l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1ll1l(l1l1l1l1):
    l1ll111l = l1l1l (u"࠭ࠧࢀ")
    if l1l1l1l1:
        for name in l1l1l1l1:
            if name in [l1l1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll111l += l1l1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1l1[name]
    if l1ll111l: logger.info(l1ll111l[:-1])
def main():
    try:
        l1l1ll1()
        l1l1llll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()