#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l11l1):
    global l11l11
    l1l1ll = ord (l11l1 [-1])
    l11l = l11l1 [:-1]
    l1l11 = l1l1ll % len (l11l)
    l1l11l = l11l [:l1l11] + l11l [l1l11:]
    if l1l:
        l1111 = l111ll () .join ([unichr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    else:
        l1111 = str () .join ([chr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    return eval (l1111)
import json
import struct
from l1l1l import *
l1ll11ll = sys.version_info[0] == 2
l1ll1lll = l11l1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = l11l1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l1l (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠻࠶࠴࠰ࠣࡅ")
l1ll11l1 = l11l1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1l1ll = l1ll1l1l.replace(l11l1l (u"ࠧࠦࠢࡇ"), l11l1l (u"ࠨ࡟ࠣࡈ")) + l11l1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l11l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111ll1 = sys.argv[0]
        try:
            l1ll1l11 = l1l1ll1(l111ll1)
            l1ll1l1l = l1ll1l11[l11l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l11l1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll11l1 = l1ll1l11[l11l1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1l1ll = l1ll1l1l.replace(l11l1l (u"ࠨࠠࠣࡏ"), l11l1l (u"ࠢࡠࠤࡐ")) + l11l1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1ll1 = os.path.join(os.environ.get(l11l1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1l1ll)
elif platform.system() == l11l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll11 = os.path.join(os.environ.get(l11l1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll11l1.split(l11l1l (u"ࠨࠬࠣࡖ"))[0].replace(l11l1l (u"ࠢࠡࠤࡗ"), l11l1l (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l1l1111(l1l1ll11 + l11l1l (u"ࠤ࠲࡙ࠦ"))
    l1ll1ll1 = os.path.join(l1l1llll, l1l1l1ll)
elif platform.system() == l11l1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll11 = os.path.join(os.environ.get(l11l1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll11l1.split(l11l1l (u"ࠨࠬࠣ࡝"))[0].replace(l11l1l (u"ࠢࠡࠤ࡞"), l11l1l (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l1l1111(l1l1ll11 + l11l1l (u"ࠤ࠲ࠦࡠ"))
    l1ll1ll1 = os.path.join(l1l1llll, l1l1l1ll)
else:
    l1ll1ll1 = os.path.join(l1l1l1ll)
logger = logging.getLogger(l11l1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l11ll(logger, l1ll1ll1)
logger.info(l11l1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(l11l1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll11l1)
logger.info(l11l1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1lll)
l1l1 = get_major_version(VERSION)
l1ll1 = l11l11l(l1l1, l1ll1lll)
logger.info(l11l1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l1)
logger.info(l11l1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1)
logger.info(l11l1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1ll1l():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1111():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1lll1():
    l1llll1l = l1l1ll1l().read(4)
    while len(l1llll1l) == 4:
        l1l1l1l1 = struct.unpack(l11l1l (u"ࠨࡀࡊࠤ࡫"), l1llll1l)[0]
        request = l1l1ll1l().read(l1l1l1l1).decode()
        logger.info(l11l1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll111(request)
        l1lll1l1(response)
        logger.info(l11l1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1llll1l = l1l1ll1l().read(4)
    logger.info(l11l1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1l1(message):
    message = json.dumps(message).encode()
    l1lllll1 = struct.pack(l11l1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1111().write(l1lllll1)
    l1ll1111().write(message)
    l1ll1111().flush()
def l1lll111(request):
    if request:
        l1lll1ll = json.loads(request)
    try:
        return {
            l11l1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1llll,
            l11l1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lll1l,
            l11l1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111l1l
        }[l1lll1ll[l11l1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll1ll)
    except Exception as e:
        logger.error(l11l1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1llll()
def l1llll(l1lll1ll=None):
    l1ll111l(l1lll1ll)
    l1llll11 = {l11l1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11ll()}
    l1llll11[l11l1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1l1(l1ll1)
    return l1llll11
def l1lll1l(l1lll1ll):
    url = l1lll1ll[l11l1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l111l = url.split(l11l1l (u"ࠬࡀࠧࡸ"))[0]
    return {l11l1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111lll(l111l, url)}
def l111l1l(l1lll1ll):
    try:
        l111l = l1111ll(l1ll1)
        url = l11l1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l111l, l1lll1ll[l11l1l (u"ࠨࡣࡦࡸࠬࡻ")], l1lll1ll[l11l1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l111l, url))
        return {l11l1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111lll(l111l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll111l(l1lll1ll):
    l1lll11l = l11l1l (u"࠭ࠧࢀ")
    if l1lll1ll:
        for name in l1lll1ll:
            if name in [l11l1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll11l += l11l1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll1ll[name]
    if l1lll11l: logger.info(l1lll11l[:-1])
def main():
    try:
        l1ll11l()
        l1l1lll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()