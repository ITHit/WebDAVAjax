#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11l1l = 2048
l11l1 = 7
def l111l1 (l1l11l):
    global l11
    ll = ord (l1l11l [-1])
    l1ll = l1l11l [:-1]
    l1111 = ll % len (l1ll)
    l11ll = l1ll [:l1111] + l1ll [l1111:]
    if l1ll1:
        l11lll = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    return eval (l11lll)
import json
import struct
from l111ll import *
l1l1llll = sys.version_info [0] == 2
l1ll1l11 = l111l1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll1ll = l111l1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l111l1 (u"ࠥ࠹࠳࠸࠰࠯࠷࠹࠵࠻࠴࠰ࠣࡅ")
l1lll111 = l111l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11l1 = l1lll1ll.replace(l111l1 (u"ࠧࠦࠢࡇ"), l111l1 (u"ࠨ࡟ࠣࡈ")) + l111l1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1111 = {}
if platform.system() == l111l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l111l1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l1lll = sys.argv[0]
        try:
            l1ll1111 = l11llll(l1l1lll)
            l1lll1ll = l1ll1111[l111l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1111[l111l1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll111 = l1ll1111[l111l1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11l1 = l1lll1ll.replace(l111l1 (u"ࠨࠠࠣࡏ"), l111l1 (u"ࠢࡠࠤࡐ")) + l111l1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll11 = os.path.join(os.environ.get(l111l1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11l1)
elif platform.system() == l111l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l1l = os.path.join(os.environ.get(l111l1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l111l1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll111.split(l111l1 (u"ࠨࠬࠣࡖ"))[0].replace(l111l1 (u"ࠢࠡࠤࡗ"), l111l1 (u"ࠣࡡࠥࡘ")).lower())
    l1ll11ll=l1llll1(l1ll1l1l + l111l1 (u"ࠤ࠲࡙ࠦ"))
    l1llll11 = os.path.join(l1ll11ll, l1ll11l1)
elif platform.system() == l111l1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l1l = os.path.join(os.environ.get(l111l1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l111l1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll111.split(l111l1 (u"ࠨࠬࠣ࡝"))[0].replace(l111l1 (u"ࠢࠡࠤ࡞"), l111l1 (u"ࠣࡡࠥ࡟")).lower())
    l1ll11ll=l1llll1(l1ll1l1l + l111l1 (u"ࠤ࠲ࠦࡠ"))
    l1llll11 = os.path.join(l1ll11ll, l1ll11l1)
else:
    l1llll11 = os.path.join( l1ll11l1)
logger = logging.getLogger(l111l1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11ll1l(logger, l1llll11)
logger.info(l111l1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l111l1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll1ll)
logger.info(l111l1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l111l1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll111)
logger.info(l111l1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1l11)
l1l111 = get_major_version(VERSION)
l1111l = l1lll11(l1l111, l1ll1l11)
logger.info(l111l1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l111)
logger.info(l111l1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111l)
def l1lll1l1():
    if l1l1llll:
        l1lllll1 = sys.stdin.read(4)
    else:
        l1lllll1 = bytes(sys.stdin.read(4).encode())
    while len(l1lllll1) == 4:
        l1ll1ll1 = struct.unpack(l111l1 (u"ࠦ࡮ࠨࡩ"), l1lllll1)[0]
        request = sys.stdin.read(l1ll1ll1)
        logger.info(l111l1 (u"ࠧࡍ࡯ࡵࠢࡵࡩࡶࡻࡥࡴࡶࠣ࠾ࢀ࠶ࡽࠣࡪ").format(request))
        response = l1llll1l(request)
        l1lll11l(response)
        logger.info(l111l1 (u"ࠨࡓࡦࡰࡷࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠺ࡼ࠲ࢀࠦ࡫").format(response))
        l1lllll1 = sys.stdin.read(4)
def l1llll1l(request):
    if request:
        l1ll111l = json.loads(request)
    try:
        return {
            l111l1 (u"ࠧࡨࡧࡷࡣࡵࡸ࡯ࡵࡱࡦࡳࡱࡹࠧ࡬"): l11l,
            l111l1 (u"ࠨࡱࡳࡩࡳࡥࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࡭"): l111l1l,
            l111l1 (u"ࠩ࡬ࡲ࡮ࡺ࡟ࡢࡰࡲࡲࠬ࡮"): l1111l1
        }[l1ll111l[l111l1 (u"ࠥࡥࡨࡺࠢ࡯")]](l1ll111l)
    except Exception as e:
        logger.error(l111l1 (u"ࠫࡸࡽࡩࡵࡥ࡫ࡣࡦࡩࡴࡪࡱࡱࡷࠥ࡫ࡲࡳࡱࡵ࠾ࠥ࠭ࡰ") + str(e))
        return l11l()
def l11l(l1ll111l=None):
    l1ll1lll = {l111l1 (u"ࠬࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࡔࡥ࡫ࡩࡲ࡫ࡳࠨࡱ"): l1ll11()}
    l1ll1lll[l111l1 (u"ࠨࡰࡳࡱࡷࡳࡨࡵ࡬ࡴࠤࡲ")] = l1l111l(l1111l)
    response = json.dumps(l1ll1lll)
    return response
def l111l1l(l1ll111l):
    url = l1ll111l[l111l1 (u"ࠢࡶࡴ࡯ࠦࡳ")]
    l111l = url.split(l111l1 (u"ࠨ࠼ࠪࡴ"))[0]
    l1ll1lll = {l111l1 (u"ࠩࡦࡱࡩࡥࡲࡦࡵࡸࡰࡹ࠭ࡵ"): l111lll(l111l, url)}
    return json.dumps(l1ll1lll)
def l1111l1(l1ll111l):
    try:
        l111l = l1l1ll1(l1111l)
        url = l111l1 (u"ࡵࠫࠪࡹ࠺ࡢࡥࡷࡁࠪࡹ࠻ࡊࡶࡨࡱ࡚ࡸ࡬࠾ࡐࡒࡒࡊࡁࠥࡴࠩࡶ") % (l111l, l1ll111l[l111l1 (u"ࠫࡦࡩࡴࠨࡷ")], l1ll111l[l111l1 (u"ࠬࡶࡡࡳࡣࡰࡷࠬࡸ")])
        logger.debug(l111l1 (u"ࠨࡲࡶࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰ࠭࠭ࠥࡴࠩ࠯ࠤࠬࠫࡳࠨࠫࠥࡹ") % (l111l, url))
        l1ll1lll = {l111l1 (u"ࠧࡤ࡯ࡧࡣࡷ࡫ࡳࡶ࡮ࡷࠫࡺ"): l111lll(l111l, url)}
    except Exception as e:
        logger.error(str(e))
        l1ll1lll = {l111l1 (u"ࠨࡥࡰࡨࡤࡸࡥࡴࡷ࡯ࡸࠬࡻ"): str(e)}
    return json.dumps(l1ll1lll)
def l1lll11l(message):
    if l1l1llll:
        sys.stdout.write(struct.pack(l111l1 (u"ࠤࡌࠦࡼ"), len(message)))
    else:
        sys.stdout.buffer.write(struct.pack(l111l1 (u"ࠥࡍࠧࡽ"), len(message)))
    sys.stdout.write(message)
    sys.stdout.flush()
def main():
    try:
        l1l1l1l()
        l1lll1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l111l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨࡾ"):
    main()