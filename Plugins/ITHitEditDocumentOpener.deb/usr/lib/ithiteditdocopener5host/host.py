#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1l1 = 7
def l1l111 (l111ll):
    global l1l11l
    l11l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l11l1 % len (l1llll)
    ll = l1llll [:l11l] + l1llll [l11l:]
    if l1l11:
        l11 = l1l1ll () .join ([unichr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    else:
        l11 = str () .join ([chr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    return eval (l11)
import json
import struct
from l1l import *
l1lll1l1 = sys.version_info[0] == 2
l1l1llll = l1l111 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll111 = l1l111 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l111 (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠺࠹࠴࠰ࠣࡅ")
l1l1l1l1 = l1l111 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1l1ll = l1lll111.replace(l1l111 (u"ࠧࠦࠢࡇ"), l1l111 (u"ࠨ࡟ࠣࡈ")) + l1l111 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1ll = {}
if platform.system() == l1l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l111 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lllll = sys.argv[0]
        try:
            l1lll1ll = l1111ll(l1lllll)
            l1lll111 = l1lll1ll[l1l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1ll[l1l111 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1l1l1 = l1lll1ll[l1l111 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1l1ll = l1lll111.replace(l1l111 (u"ࠨࠠࠣࡏ"), l1l111 (u"ࠢࡠࠤࡐ")) + l1l111 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll11 = os.path.join(os.environ.get(l1l111 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1l1ll)
elif platform.system() == l1l111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1llll1l = os.path.join(os.environ.get(l1l111 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l111 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1l1l1.split(l1l111 (u"ࠨࠬࠣࡖ"))[0].replace(l1l111 (u"ࠢࠡࠤࡗ"), l1l111 (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll11 = l11llll(l1llll1l + l1l111 (u"ࠤ࠲࡙ࠦ"))
    l1llll11 = os.path.join(l1l1ll11, l1l1l1ll)
elif platform.system() == l1l111 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1llll1l = os.path.join(os.environ.get(l1l111 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l111 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1l1l1.split(l1l111 (u"ࠨࠬࠣ࡝"))[0].replace(l1l111 (u"ࠢࠡࠤ࡞"), l1l111 (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll11 = l11llll(l1llll1l + l1l111 (u"ࠤ࠲ࠦࡠ"))
    l1llll11 = os.path.join(l1l1ll11, l1l1l1ll)
else:
    l1llll11 = os.path.join(l1l1l1ll)
logger = logging.getLogger(l1l111 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l11l(logger, l1llll11)
logger.info(l1l111 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l111 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll111)
logger.info(l1l111 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l111 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1l1l1)
logger.info(l1l111 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1llll)
l1ll1l = get_major_version(VERSION)
l1111 = l11111(l1ll1l, l1l1llll)
logger.info(l1l111 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1ll1l)
logger.info(l1l111 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111)
logger.info(l1l111 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l111 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1lll1():
    if l1lll1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll1l():
    if l1lll1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1ll1():
    l1ll111l = l1l1lll1().read(4)
    while len(l1ll111l) == 4:
        l1ll11ll = struct.unpack(l1l111 (u"ࠨࡀࡊࠤ࡫"), l1ll111l)[0]
        request = l1l1lll1().read(l1ll11ll).decode()
        logger.info(l1l111 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11l1(request)
        l1ll1l1l(response)
        logger.info(l1l111 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll111l = l1l1lll1().read(4)
    logger.info(l1l111 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l1l(message):
    message = json.dumps(message).encode()
    l1lllll1 = struct.pack(l1l111 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll1l().write(l1lllll1)
    l1l1ll1l().write(message)
    l1l1ll1l().flush()
def l1ll11l1(request):
    if request:
        l1ll1111 = json.loads(request)
    try:
        return {
            l1l111 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11ll,
            l1l111 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l111ll1,
            l1l111 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l1ll
        }[l1ll1111[l1l111 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1111)
    except Exception as e:
        logger.error(l1l111 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11ll()
def l11ll(l1ll1111=None):
    l1lll11l(l1ll1111)
    l1ll1lll = {l1l111 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1l()}
    l1ll1lll[l1l111 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll1ll(l1111)
    return l1ll1lll
def l111ll1(l1ll1111):
    url = l1ll1111[l1l111 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1lll1 = url.split(l1l111 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l111 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111l11(l1lll1, url)}
def l11l1ll(l1ll1111):
    try:
        l1lll1 = l11ll11(l1111)
        url = l1l111 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1lll1, l1ll1111[l1l111 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1111[l1l111 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l111 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1lll1, url))
        return {l1l111 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111l11(l1lll1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l111 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll11l(l1ll1111):
    l1ll1l11 = l1l111 (u"࠭ࠧࢀ")
    if l1ll1111:
        for name in l1ll1111:
            if name in [l1l111 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l111 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l11 += l1l111 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1111[name]
    if l1ll1l11: logger.info(l1ll1l11[:-1])
def main():
    try:
        l1l111l()
        l1ll1ll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l111 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()