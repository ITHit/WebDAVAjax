#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll1 = 2048
l11l = 7
def ll (l1):
    global l1l
    l1llll = ord (l1 [-1])
    l1l111 = l1 [:-1]
    l1l1l1 = l1llll % len (l1l111)
    l11lll = l1l111 [:l1l1l1] + l1l111 [l1l1l1:]
    if l11ll:
        l111 = l11l11 () .join ([unichr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    else:
        l111 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    return eval (l111)
import json
import struct
from l111l1 import *
l1lll1ll = sys.version_info[0] == 2
l1ll1111 = ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = ll (u"ࠥ࠺࠳࠶࠮࠹࠹࠶࠺࠳࠶ࠢࡅ")
l1l1l1ll = ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll11l = l1ll1l1l.replace(ll (u"ࠧࠦࠢࡇ"), ll (u"ࠨ࡟ࠣࡈ")) + ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1lll1 = {}
if platform.system() == ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1llll1 = sys.argv[0]
        try:
            l1l1lll1 = l11ll1l(l1llll1)
            l1ll1l1l = l1l1lll1[ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1lll1[ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1l1ll = l1l1lll1[ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll11l = l1ll1l1l.replace(ll (u"ࠨࠠࠣࡏ"), ll (u"ࠢࡠࠤࡐ")) + ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1lll = os.path.join(os.environ.get(ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll11l)
elif platform.system() == ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1l1 = os.path.join(os.environ.get(ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1l1ll.split(ll (u"ࠨࠬࠣࡖ"))[0].replace(ll (u"ࠢࠡࠤࡗ"), ll (u"ࠣࡡࠥࡘ")).lower())
    l1ll11ll = l1lll1l(l1l1l1l1 + ll (u"ࠤ࠲࡙ࠦ"))
    l1ll1lll = os.path.join(l1ll11ll, l1lll11l)
elif platform.system() == ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1l1 = os.path.join(os.environ.get(ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1l1ll.split(ll (u"ࠨࠬࠣ࡝"))[0].replace(ll (u"ࠢࠡࠤ࡞"), ll (u"ࠣࡡࠥ࡟")).lower())
    l1ll11ll = l1lll1l(l1l1l1l1 + ll (u"ࠤ࠲ࠦࡠ"))
    l1ll1lll = os.path.join(l1ll11ll, l1lll11l)
else:
    l1ll1lll = os.path.join(l1lll11l)
logger = logging.getLogger(ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l1l1l(logger, l1ll1lll)
logger.info(ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1l1ll)
logger.info(ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l1111 = get_major_version(VERSION)
l1lll1 = l1l1l11(l1111, l1ll1111)
logger.info(ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111)
logger.info(ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll1)
logger.info(ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lllll1():
    if l1lll1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll111():
    if l1lll1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll111l():
    l1l1ll1l = l1lllll1().read(4)
    while len(l1l1ll1l) == 4:
        l1l1ll11 = struct.unpack(ll (u"ࠨࡀࡊࠤ࡫"), l1l1ll1l)[0]
        request = l1lllll1().read(l1l1ll11).decode()
        logger.info(ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1ll1(request)
        l1ll1l11(response)
        logger.info(ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll1l = l1lllll1().read(4)
    logger.info(ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l11(message):
    message = json.dumps(message).encode()
    l1lll1l1 = struct.pack(ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll111().write(l1lll1l1)
    l1lll111().write(message)
    l1lll111().flush()
def l1ll1ll1(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1lll,
            ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11ll11,
            ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1111l1
        }[l1llll1l[ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1lll()
def l1lll(l1llll1l=None):
    l1llll11(l1llll1l)
    l1ll11l1 = {ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11ll1()}
    l1ll11l1[ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1l1(l1lll1)
    return l1ll11l1
def l11ll11(l1llll1l):
    url = l1llll1l[ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1l = url.split(ll (u"ࠬࡀࠧࡸ"))[0]
    return {ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111111(l11l1l, url)}
def l1111l1(l1llll1l):
    try:
        l11l1l = l11llll(l1lll1)
        url = ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1l, l1llll1l[ll (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1l, url))
        return {ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111111(l11l1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll11(l1llll1l):
    l1l1llll = ll (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1llll += ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1l1llll: logger.info(l1l1llll[:-1])
def main():
    try:
        l1ll1ll()
        l1ll111l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()