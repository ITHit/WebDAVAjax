#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111ll = 2048
l11lll = 7
def l1ll1l (l11ll):
    global l1
    l11 = ord (l11ll [-1])
    l11ll1 = l11ll [:-1]
    l1ll11 = l11 % len (l11ll1)
    l1111 = l11ll1 [:l1ll11] + l11ll1 [l1ll11:]
    if l1l1l:
        l111 = l111l () .join ([unichr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    else:
        l111 = str () .join ([chr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    return eval (l111)
import json
import struct
from l1llll import *
l1lll111 = sys.version_info[0] == 2
l1l1llll = l1ll1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1ll11 = l1ll1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll1l (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠽࠺࠴࠰ࠣࡅ")
l1llll11 = l1ll1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1ll1l = l1l1ll11.replace(l1ll1l (u"ࠧࠦࠢࡇ"), l1ll1l (u"ࠨ࡟ࠣࡈ")) + l1ll1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1l1ll = {}
if platform.system() == l1ll1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lllll = sys.argv[0]
        try:
            l1l1l1ll = l111l1l(l1lllll)
            l1l1ll11 = l1l1l1ll[l1ll1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1l1ll[l1ll1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1llll11 = l1l1l1ll[l1ll1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1ll1l = l1l1ll11.replace(l1ll1l (u"ࠨࠠࠣࡏ"), l1ll1l (u"ࠢࡠࠤࡐ")) + l1ll1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1l1 = os.path.join(os.environ.get(l1ll1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1ll1l)
elif platform.system() == l1ll1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll11l1 = os.path.join(os.environ.get(l1ll1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1llll11.split(l1ll1l (u"ࠨࠬࠣࡖ"))[0].replace(l1ll1l (u"ࠢࠡࠤࡗ"), l1ll1l (u"ࠣࡡࠥࡘ")).lower())
    l1l1lll1 = l1llll1(l1ll11l1 + l1ll1l (u"ࠤ࠲࡙ࠦ"))
    l1l1l1l1 = os.path.join(l1l1lll1, l1l1ll1l)
elif platform.system() == l1ll1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll11l1 = os.path.join(os.environ.get(l1ll1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1llll11.split(l1ll1l (u"ࠨࠬࠣ࡝"))[0].replace(l1ll1l (u"ࠢࠡࠤ࡞"), l1ll1l (u"ࠣࡡࠥ࡟")).lower())
    l1l1lll1 = l1llll1(l1ll11l1 + l1ll1l (u"ࠤ࠲ࠦࡠ"))
    l1l1l1l1 = os.path.join(l1l1lll1, l1l1ll1l)
else:
    l1l1l1l1 = os.path.join(l1l1ll1l)
logger = logging.getLogger(l1ll1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11llll(logger, l1l1l1l1)
logger.info(l1ll1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1ll11)
logger.info(l1ll1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1llll11)
logger.info(l1ll1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1llll)
l1111l = get_major_version(VERSION)
l11l1 = l1111l1(l1111l, l1l1llll)
logger.info(l1ll1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111l)
logger.info(l1ll1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11l1)
logger.info(l1ll1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll1ll():
    if l1lll111:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll111l():
    if l1lll111:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll11l():
    l1ll1111 = l1lll1ll().read(4)
    while len(l1ll1111) == 4:
        l1ll1ll1 = struct.unpack(l1ll1l (u"ࠨࡀࡊࠤ࡫"), l1ll1111)[0]
        request = l1lll1ll().read(l1ll1ll1).decode()
        logger.info(l1ll1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1lll(request)
        l1ll1l1l(response)
        logger.info(l1ll1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1111 = l1lll1ll().read(4)
    logger.info(l1ll1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l1l(message):
    message = json.dumps(message).encode()
    l1ll11ll = struct.pack(l1ll1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll111l().write(l1ll11ll)
    l1ll111l().write(message)
    l1ll111l().flush()
def l1ll1lll(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l1ll1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l1ll,
            l1ll1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11111l,
            l1ll1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l11ll
        }[l1llll1l[l1ll1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l1ll1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l1ll()
def l1l1ll(l1llll1l=None):
    l1lll1l1(l1llll1l)
    l1ll1l11 = {l1ll1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l()}
    l1ll1l11[l1ll1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1lll(l11l1)
    return l1ll1l11
def l11111l(l1llll1l):
    url = l1llll1l[l1ll1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1l = url.split(l1ll1l (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111l11(l11l1l, url)}
def l1l11ll(l1llll1l):
    try:
        l11l1l = l11l1l1(l11l1)
        url = l1ll1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1l, l1llll1l[l1ll1l (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l1ll1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1l, url))
        return {l1ll1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111l11(l11l1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll1l1(l1llll1l):
    l1lllll1 = l1ll1l (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l1ll1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lllll1 += l1ll1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1lllll1: logger.info(l1lllll1[:-1])
def main():
    try:
        l1lll11()
        l1lll11l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()