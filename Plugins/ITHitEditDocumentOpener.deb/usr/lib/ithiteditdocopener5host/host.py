#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1 = 7
def l1l1l1 (l111l):
    global l111ll
    l1111 = ord (l111l [-1])
    l1l11l = l111l [:-1]
    ll = l1111 % len (l1l11l)
    l11l11 = l1l11l [:ll] + l1l11l [ll:]
    if l1111l:
        l11lll = l1l111 () .join ([unichr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    return eval (l11lll)
import json
import struct
from l111 import *
l1lll1l1 = sys.version_info[0] == 2
l1llll11 = l1l1l1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = l1l1l1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1l1 (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠼࠼࠴࠰ࠣࡅ")
l1l1l1l1 = l1l1l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1ll11 = l1ll1l1l.replace(l1l1l1 (u"ࠧࠦࠢࡇ"), l1l1l1 (u"ࠨ࡟ࠣࡈ")) + l1l1l1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1ll1l = {}
if platform.system() == l1l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1l1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111lll = sys.argv[0]
        try:
            l1l1ll1l = l1ll11l(l111lll)
            l1ll1l1l = l1l1ll1l[l1l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1ll1l[l1l1l1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1l1l1 = l1l1ll1l[l1l1l1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1ll11 = l1ll1l1l.replace(l1l1l1 (u"ࠨࠠࠣࡏ"), l1l1l1 (u"ࠢࡠࠤࡐ")) + l1l1l1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll1l = os.path.join(os.environ.get(l1l1l1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1ll11)
elif platform.system() == l1l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lllll1 = os.path.join(os.environ.get(l1l1l1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1l1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1l1l1.split(l1l1l1 (u"ࠨࠬࠣࡖ"))[0].replace(l1l1l1 (u"ࠢࠡࠤࡗ"), l1l1l1 (u"ࠣࡡࠥࡘ")).lower())
    l1lll111 = l11ll1l(l1lllll1 + l1l1l1 (u"ࠤ࠲࡙ࠦ"))
    l1llll1l = os.path.join(l1lll111, l1l1ll11)
elif platform.system() == l1l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lllll1 = os.path.join(os.environ.get(l1l1l1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1l1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1l1l1.split(l1l1l1 (u"ࠨࠬࠣ࡝"))[0].replace(l1l1l1 (u"ࠢࠡࠤ࡞"), l1l1l1 (u"ࠣࡡࠥ࡟")).lower())
    l1lll111 = l11ll1l(l1lllll1 + l1l1l1 (u"ࠤ࠲ࠦࡠ"))
    l1llll1l = os.path.join(l1lll111, l1l1ll11)
else:
    l1llll1l = os.path.join(l1l1ll11)
logger = logging.getLogger(l1l1l1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11111l(logger, l1llll1l)
logger.info(l1l1l1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1l1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(l1l1l1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1l1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1l1l1)
logger.info(l1l1l1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1llll11)
l1l = get_major_version(VERSION)
l1 = l1l1l11(l1l, l1llll11)
logger.info(l1l1l1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l)
logger.info(l1l1l1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1)
logger.info(l1l1l1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1l1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1ll1():
    if l1lll1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1111():
    if l1lll1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1l11():
    l1ll111l = l1ll1ll1().read(4)
    while len(l1ll111l) == 4:
        l1ll1lll = struct.unpack(l1l1l1 (u"ࠨࡀࡊࠤ࡫"), l1ll111l)[0]
        request = l1ll1ll1().read(l1ll1lll).decode()
        logger.info(l1l1l1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1llll(request)
        l1ll11ll(response)
        logger.info(l1l1l1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll111l = l1ll1ll1().read(4)
    logger.info(l1l1l1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll11ll(message):
    message = json.dumps(message).encode()
    l1ll11l1 = struct.pack(l1l1l1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1111().write(l1ll11l1)
    l1ll1111().write(message)
    l1ll1111().flush()
def l1l1llll(request):
    if request:
        l1l1l1ll = json.loads(request)
    try:
        return {
            l1l1l1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l1l,
            l1l1l1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l11l1,
            l1l1l1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll1l1
        }[l1l1l1ll[l1l1l1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1ll)
    except Exception as e:
        logger.error(l1l1l1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l1l()
def l11l1l(l1l1l1ll=None):
    l1l1lll1(l1l1l1ll)
    l1lll11l = {l1l1l1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111l1()}
    l1lll11l[l1l1l1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1lll(l1)
    return l1lll11l
def l1l11l1(l1l1l1ll):
    url = l1l1l1ll[l1l1l1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1lll = url.split(l1l1l1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1l1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1lll1l(l1lll, url)}
def l1ll1l1(l1l1l1ll):
    try:
        l1lll = l1l1l1l(l1)
        url = l1l1l1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1lll, l1l1l1ll[l1l1l1 (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1ll[l1l1l1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1l1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1lll, url))
        return {l1l1l1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1lll1l(l1lll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1l1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1lll1(l1l1l1ll):
    l1lll1ll = l1l1l1 (u"࠭ࠧࢀ")
    if l1l1l1ll:
        for name in l1l1l1ll:
            if name in [l1l1l1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1l1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll1ll += l1l1l1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1ll[name]
    if l1lll1ll: logger.info(l1lll1ll[:-1])
def main():
    try:
        l11llll()
        l1ll1l11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()