#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1l11 = 2048
l11l1 = 7
def l1llll (l1l1ll):
    global l111
    l11lll = ord (l1l1ll [-1])
    l1111l = l1l1ll [:-1]
    l1 = l11lll % len (l1111l)
    l1lll = l1111l [:l1] + l1111l [l1:]
    if l111l1:
        l1l1l = l111ll () .join ([unichr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    return eval (l1l1l)
import json
import struct
from l1ll import *
l1ll11l1 = sys.version_info[0] == 2
l1lllll1 = l1llll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll11ll = l1llll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1llll (u"ࠥ࠺࠳࠶࠮࠹࠻࠴࠴࠳࠶ࠢࡅ")
l1ll1l11 = l1llll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1ll1 = l1ll11ll.replace(l1llll (u"ࠧࠦࠢࡇ"), l1llll (u"ࠨ࡟ࠣࡈ")) + l1llll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1l1ll = {}
if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1llll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111ll1 = sys.argv[0]
        try:
            l1l1l1ll = l11111l(l111ll1)
            l1ll11ll = l1l1l1ll[l1llll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1l1ll[l1llll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1l1l1ll[l1llll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1ll1 = l1ll11ll.replace(l1llll (u"ࠨࠠࠣࡏ"), l1llll (u"ࠢࡠࠤࡐ")) + l1llll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1l1 = os.path.join(os.environ.get(l1llll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1ll1)
elif platform.system() == l1llll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll1l = os.path.join(os.environ.get(l1llll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1llll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l1llll (u"ࠨࠬࠣࡖ"))[0].replace(l1llll (u"ࠢࠡࠤࡗ"), l1llll (u"ࠣࡡࠥࡘ")).lower())
    l1l1lll1 = l11111(l1l1ll1l + l1llll (u"ࠤ࠲࡙ࠦ"))
    l1l1l1l1 = os.path.join(l1l1lll1, l1ll1ll1)
elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll1l = os.path.join(os.environ.get(l1llll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1llll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l1llll (u"ࠨࠬࠣ࡝"))[0].replace(l1llll (u"ࠢࠡࠤ࡞"), l1llll (u"ࠣࡡࠥ࡟")).lower())
    l1l1lll1 = l11111(l1l1ll1l + l1llll (u"ࠤ࠲ࠦࡠ"))
    l1l1l1l1 = os.path.join(l1l1lll1, l1ll1ll1)
else:
    l1l1l1l1 = os.path.join(l1ll1ll1)
logger = logging.getLogger(l1llll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l11l(logger, l1l1l1l1)
logger.info(l1llll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1llll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll11ll)
logger.info(l1llll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1llll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l1llll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lllll1)
l11l11 = get_major_version(VERSION)
ll = l111l11(l11l11, l1lllll1)
logger.info(l1llll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11l11)
logger.info(l1llll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % ll)
logger.info(l1llll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1llll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1111():
    if l1ll11l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll111l():
    if l1ll11l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1l1():
    l1lll1ll = l1ll1111().read(4)
    while len(l1lll1ll) == 4:
        l1llll1l = struct.unpack(l1llll (u"ࠨࡀࡊࠤ࡫"), l1lll1ll)[0]
        request = l1ll1111().read(l1llll1l).decode()
        logger.info(l1llll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1llll(request)
        l1ll1lll(response)
        logger.info(l1llll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1ll = l1ll1111().read(4)
    logger.info(l1llll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1lll(message):
    message = json.dumps(message).encode()
    l1lll11l = struct.pack(l1llll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll111l().write(l1lll11l)
    l1ll111l().write(message)
    l1ll111l().flush()
def l1l1llll(request):
    if request:
        l1ll1l1l = json.loads(request)
    try:
        return {
            l1llll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1lll1,
            l1llll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1ll1,
            l1llll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll111
        }[l1ll1l1l[l1llll (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1l1l)
    except Exception as e:
        logger.error(l1llll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1lll1()
def l1lll1(l1ll1l1l=None):
    l1lll111(l1ll1l1l)
    l1l1ll11 = {l1llll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l()}
    l1l1ll11[l1llll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll1l1(ll)
    return l1l1ll11
def l1l1ll1(l1ll1l1l):
    url = l1ll1l1l[l1llll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1ll1l = url.split(l1llll (u"ࠬࡀࠧࡸ"))[0]
    return {l1llll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1111l1(l1ll1l, url)}
def l1ll111(l1ll1l1l):
    try:
        l1ll1l = l1llllll(ll)
        url = l1llll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1ll1l, l1ll1l1l[l1llll (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1l1l[l1llll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1llll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1ll1l, url))
        return {l1llll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1111l1(l1ll1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1llll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll111(l1ll1l1l):
    l1llll11 = l1llll (u"࠭ࠧࢀ")
    if l1ll1l1l:
        for name in l1ll1l1l:
            if name in [l1llll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1llll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1llll11 += l1llll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1l1l[name]
    if l1llll11: logger.info(l1llll11[:-1])
def main():
    try:
        l1ll11l()
        l1lll1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1llll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()