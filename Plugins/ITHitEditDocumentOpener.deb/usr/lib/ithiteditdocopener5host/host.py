#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll = 2048
l1ll1l = 7
def l1l1l (l1l1l1):
    global l11l1l
    l11l = ord (l1l1l1 [-1])
    l111l1 = l1l1l1 [:-1]
    l1l1ll = l11l % len (l111l1)
    ll = l111l1 [:l1l1ll] + l111l1 [l1l1ll:]
    if l1ll11:
        l11l11 = l11 () .join ([unichr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1111l + l11l) % l1ll1l) for l1111l, char in enumerate (ll)])
    return eval (l11l11)
import json
import struct
from l111l import *
l1ll11ll = sys.version_info[0] == 2
l1llll11 = l1l1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll1l1 = l1l1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1l (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠻࠺࠴࠰ࠣࡅ")
l1l1ll1l = l1l1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lllll1 = l1lll1l1.replace(l1l1l (u"ࠧࠦࠢࡇ"), l1l1l (u"ࠨ࡟ࠣࡈ")) + l1l1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11l1 = {}
if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11ll11 = sys.argv[0]
        try:
            l1ll11l1 = l1ll1l1(l11ll11)
            l1lll1l1 = l1ll11l1[l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11l1[l1l1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll1l = l1ll11l1[l1l1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lllll1 = l1lll1l1.replace(l1l1l (u"ࠨࠠࠣࡏ"), l1l1l (u"ࠢࡠࠤࡐ")) + l1l1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1ll1 = os.path.join(os.environ.get(l1l1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lllll1)
elif platform.system() == l1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1111 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll1l.split(l1l1l (u"ࠨࠬࠣࡖ"))[0].replace(l1l1l (u"ࠢࠡࠤࡗ"), l1l1l (u"ࠣࡡࠥࡘ")).lower())
    l1ll1l11 = l111ll1(l1ll1111 + l1l1l (u"ࠤ࠲࡙ࠦ"))
    l1ll1ll1 = os.path.join(l1ll1l11, l1lllll1)
elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1111 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll1l.split(l1l1l (u"ࠨࠬࠣ࡝"))[0].replace(l1l1l (u"ࠢࠡࠤ࡞"), l1l1l (u"ࠣࡡࠥ࡟")).lower())
    l1ll1l11 = l111ll1(l1ll1111 + l1l1l (u"ࠤ࠲ࠦࡠ"))
    l1ll1ll1 = os.path.join(l1ll1l11, l1lllll1)
else:
    l1ll1ll1 = os.path.join(l1lllll1)
logger = logging.getLogger(l1l1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l11l(logger, l1ll1ll1)
logger.info(l1l1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll1l1)
logger.info(l1l1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll1l)
logger.info(l1l1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1llll11)
l111 = get_major_version(VERSION)
l1llll = l1lll1l(l111, l1llll11)
logger.info(l1l1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111)
logger.info(l1l1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1llll)
logger.info(l1l1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1l1():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1ll():
    l1l1llll = l1lll11l().read(4)
    while len(l1l1llll) == 4:
        l1l1ll11 = struct.unpack(l1l1l (u"ࠨࡀࡊࠤ࡫"), l1l1llll)[0]
        request = l1lll11l().read(l1l1ll11).decode()
        logger.info(l1l1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll111l(request)
        l1ll1l1l(response)
        logger.info(l1l1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1llll = l1lll11l().read(4)
    logger.info(l1l1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l1l(message):
    message = json.dumps(message).encode()
    l1lll111 = struct.pack(l1l1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1l1().write(l1lll111)
    l1l1l1l1().write(message)
    l1l1l1l1().flush()
def l1ll111l(request):
    if request:
        l1ll1lll = json.loads(request)
    try:
        return {
            l1l1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1111,
            l1l1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1ll1ll,
            l1l1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1111
        }[l1ll1lll[l1l1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1lll)
    except Exception as e:
        logger.error(l1l1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1111()
def l1111(l1ll1lll=None):
    l1llll1l(l1ll1lll)
    l1l1lll1 = {l1l1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l11()}
    l1l1lll1[l1l1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11111l(l1llll)
    return l1l1lll1
def l1ll1ll(l1ll1lll):
    url = l1ll1lll[l1l1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11lll = url.split(l1l1l (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l11ll(l11lll, url)}
def l1l1111(l1ll1lll):
    try:
        l11lll = l1llll1(l1llll)
        url = l1l1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11lll, l1ll1lll[l1l1l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1lll[l1l1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11lll, url))
        return {l1l1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l11ll(l11lll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll1l(l1ll1lll):
    l1l1l1ll = l1l1l (u"࠭ࠧࢀ")
    if l1ll1lll:
        for name in l1ll1lll:
            if name in [l1l1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1ll += l1l1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1lll[name]
    if l1l1l1ll: logger.info(l1l1l1ll[:-1])
def main():
    try:
        l111l1l()
        l1lll1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()