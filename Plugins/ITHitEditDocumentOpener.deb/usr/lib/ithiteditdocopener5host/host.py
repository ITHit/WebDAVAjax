#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1lll = 2048
l11l1 = 7
def l111 (l1ll11):
    global l1l11
    l11l1l = ord (l1ll11 [-1])
    l1l1l = l1ll11 [:-1]
    l1l1ll = l11l1l % len (l1l1l)
    l1llll = l1l1l [:l1l1ll] + l1l1l [l1l1ll:]
    if l1ll:
        l1111l = l111ll () .join ([unichr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1lll - (l1 + l11l1l) % l11l1) for l1, char in enumerate (l1llll)])
    return eval (l1111l)
import json
import struct
from l1l1l1 import *
l1l1llll = sys.version_info[0] == 2
l1l1l1ll = l111 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1111 = l111 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l111 (u"ࠥ࠺࠳࠶࠮࠹࠹࠸࠽࠳࠶ࠢࡅ")
l1l1ll11 = l111 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11l1 = l1ll1111.replace(l111 (u"ࠧࠦࠢࡇ"), l111 (u"ࠨ࡟ࠣࡈ")) + l111 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll11l = {}
if platform.system() == l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l111 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l1l11 = sys.argv[0]
        try:
            l1lll11l = l111l11(l1l1l11)
            l1ll1111 = l1lll11l[l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll11l[l111 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll11 = l1lll11l[l111 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11l1 = l1ll1111.replace(l111 (u"ࠨࠠࠣࡏ"), l111 (u"ࠢࡠࠤࡐ")) + l111 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1lll = os.path.join(os.environ.get(l111 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11l1)
elif platform.system() == l111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll11ll = os.path.join(os.environ.get(l111 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l111 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll11.split(l111 (u"ࠨࠬࠣࡖ"))[0].replace(l111 (u"ࠢࠡࠤࡗ"), l111 (u"ࠣࡡࠥࡘ")).lower())
    l1llll1l = l1ll11l(l1ll11ll + l111 (u"ࠤ࠲࡙ࠦ"))
    l1ll1lll = os.path.join(l1llll1l, l1ll11l1)
elif platform.system() == l111 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll11ll = os.path.join(os.environ.get(l111 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l111 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll11.split(l111 (u"ࠨࠬࠣ࡝"))[0].replace(l111 (u"ࠢࠡࠤ࡞"), l111 (u"ࠣࡡࠥ࡟")).lower())
    l1llll1l = l1ll11l(l1ll11ll + l111 (u"ࠤ࠲ࠦࡠ"))
    l1ll1lll = os.path.join(l1llll1l, l1ll11l1)
else:
    l1ll1lll = os.path.join(l1ll11l1)
logger = logging.getLogger(l111 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111l1l(logger, l1ll1lll)
logger.info(l111 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l111 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1111)
logger.info(l111 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l111 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll11)
logger.info(l111 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1ll)
l11ll1 = get_major_version(VERSION)
l1ll1l = l11ll11(l11ll1, l1l1l1ll)
logger.info(l111 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11ll1)
logger.info(l111 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1l)
logger.info(l111 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l111 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lllll1():
    if l1l1llll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll111():
    if l1l1llll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1ll1l():
    l1ll1l11 = l1lllll1().read(4)
    while len(l1ll1l11) == 4:
        l1ll1ll1 = struct.unpack(l111 (u"ࠨࡀࡊࠤ࡫"), l1ll1l11)[0]
        request = l1lllll1().read(l1ll1ll1).decode()
        logger.info(l111 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll111l(request)
        l1l1l1l1(response)
        logger.info(l111 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l11 = l1lllll1().read(4)
    logger.info(l111 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1l1l1(message):
    message = json.dumps(message).encode()
    l1lll1l1 = struct.pack(l111 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll111().write(l1lll1l1)
    l1lll111().write(message)
    l1lll111().flush()
def l1ll111l(request):
    if request:
        l1l1lll1 = json.loads(request)
    try:
        return {
            l111 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l11,
            l111 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l11ll,
            l111 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lll11
        }[l1l1lll1[l111 (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1lll1)
    except Exception as e:
        logger.error(l111 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l11()
def l11l11(l1l1lll1=None):
    l1lll1ll(l1l1lll1)
    l1ll1l1l = {l111 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l()}
    l1ll1l1l[l111 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l111lll(l1ll1l)
    return l1ll1l1l
def l1l11ll(l1l1lll1):
    url = l1l1lll1[l111 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1111 = url.split(l111 (u"ࠬࡀࠧࡸ"))[0]
    return {l111 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111ll1(l1111, url)}
def l1lll11(l1l1lll1):
    try:
        l1111 = l1ll1l1(l1ll1l)
        url = l111 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1111, l1l1lll1[l111 (u"ࠨࡣࡦࡸࠬࡻ")], l1l1lll1[l111 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l111 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1111, url))
        return {l111 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111ll1(l1111, url)}
    except Exception as e:
        logger.error(str(e))
        return {l111 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll1ll(l1l1lll1):
    l1llll11 = l111 (u"࠭ࠧࢀ")
    if l1l1lll1:
        for name in l1l1lll1:
            if name in [l111 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l111 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1llll11 += l111 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1lll1[name]
    if l1llll11: logger.info(l1llll11[:-1])
def main():
    try:
        l1llllll()
        l1l1ll1l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l111 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()