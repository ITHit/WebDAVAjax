#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1lll = 7
def l1l1 (l1lll1):
    global l1l1l
    l111ll = ord (l1lll1 [-1])
    l11l = l1lll1 [:-1]
    l111 = l111ll % len (l11l)
    l1l11l = l11l [:l111] + l11l [l111:]
    if l1llll:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import json
import struct
from l1l11 import *
l1ll1lll = sys.version_info[0] == 2
l1ll1111 = l1l1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l11 = l1l1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1 (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠺࠷࠴࠰ࠣࡅ")
l1llll11 = l1l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lllll1 = l1ll1l11.replace(l1l1 (u"ࠧࠦࠢࡇ"), l1l1 (u"ࠨ࡟ࠣࡈ")) + l1l1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll111 = {}
if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lll11 = sys.argv[0]
        try:
            l1lll111 = l111ll1(l1lll11)
            l1ll1l11 = l1lll111[l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll111[l1l1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1llll11 = l1lll111[l1l1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lllll1 = l1ll1l11.replace(l1l1 (u"ࠨࠠࠣࡏ"), l1l1 (u"ࠢࡠࠤࡐ")) + l1l1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1ll = os.path.join(os.environ.get(l1l1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lllll1)
elif platform.system() == l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1llll11.split(l1l1 (u"ࠨࠬࠣࡖ"))[0].replace(l1l1 (u"ࠢࠡࠤࡗ"), l1l1 (u"ࠣࡡࠥࡘ")).lower())
    l1ll111l = l11l111(l1ll1ll1 + l1l1 (u"ࠤ࠲࡙ࠦ"))
    l1l1l1ll = os.path.join(l1ll111l, l1lllll1)
elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1llll11.split(l1l1 (u"ࠨࠬࠣ࡝"))[0].replace(l1l1 (u"ࠢࠡࠤ࡞"), l1l1 (u"ࠣࡡࠥ࡟")).lower())
    l1ll111l = l11l111(l1ll1ll1 + l1l1 (u"ࠤ࠲ࠦࡠ"))
    l1l1l1ll = os.path.join(l1ll111l, l1lllll1)
else:
    l1l1l1ll = os.path.join(l1lllll1)
logger = logging.getLogger(l1l1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll1l1(logger, l1l1l1ll)
logger.info(l1l1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l11)
logger.info(l1l1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1llll11)
logger.info(l1l1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l11lll = get_major_version(VERSION)
l1ll1 = l111111(l11lll, l1ll1111)
logger.info(l1l1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11lll)
logger.info(l1l1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1)
logger.info(l1l1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1ll11():
    if l1ll1lll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll11ll():
    if l1ll1lll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1lll1():
    l1ll1l1l = l1l1ll11().read(4)
    while len(l1ll1l1l) == 4:
        l1lll1l1 = struct.unpack(l1l1 (u"ࠨࡀࡊࠤ࡫"), l1ll1l1l)[0]
        request = l1l1ll11().read(l1lll1l1).decode()
        logger.info(l1l1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11l1(request)
        l1l1llll(response)
        logger.info(l1l1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l1l = l1l1ll11().read(4)
    logger.info(l1l1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1llll(message):
    message = json.dumps(message).encode()
    l1lll1ll = struct.pack(l1l1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll11ll().write(l1lll1ll)
    l1ll11ll().write(message)
    l1ll11ll().flush()
def l1ll11l1(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l1l1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l,
            l1l1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l1ll,
            l1l1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111lll
        }[l1llll1l[l1l1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l1l1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l()
def l1l(l1llll1l=None):
    l1lll11l(l1llll1l)
    l1l1ll1l = {l1l1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1()}
    l1l1ll1l[l1l1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l11ll(l1ll1)
    return l1l1ll1l
def l11l1ll(l1llll1l):
    url = l1llll1l[l1l1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1l = url.split(l1l1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1llll1(l11l1l, url)}
def l111lll(l1llll1l):
    try:
        l11l1l = l1ll111(l1ll1)
        url = l1l1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1l, l1llll1l[l1l1 (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l1l1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1l, url))
        return {l1l1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1llll1(l11l1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll11l(l1llll1l):
    l1l1l1l1 = l1l1 (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l1l1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1l1 += l1l1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1l1l1l1: logger.info(l1l1l1l1[:-1])
def main():
    try:
        l111l11()
        l1l1lll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()