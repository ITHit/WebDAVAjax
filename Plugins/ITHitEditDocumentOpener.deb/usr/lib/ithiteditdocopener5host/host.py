#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1ll11 = 2048
l1l1ll = 7
def l11l (ll):
    global l111l1
    l1l11 = ord (ll [-1])
    l11ll1 = ll [:-1]
    l11ll = l1l11 % len (l11ll1)
    l1ll1 = l11ll1 [:l11ll] + l11ll1 [l11ll:]
    if l111ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    return eval (l1l1l1)
import json
import struct
from l1lll import *
l1l1l1ll = sys.version_info[0] == 2
l1lll1l1 = l11l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1111 = l11l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠽࠾࠴࠰ࠣࡅ")
l1ll11l1 = l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll1ll = l1ll1111.replace(l11l (u"ࠧࠦࠢࡇ"), l11l (u"ࠨ࡟ࠣࡈ")) + l11l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll111 = {}
if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll1ll = sys.argv[0]
        try:
            l1lll111 = l11ll11(l1ll1ll)
            l1ll1111 = l1lll111[l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll111[l11l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll11l1 = l1lll111[l11l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll1ll = l1ll1111.replace(l11l (u"ࠨࠠࠣࡏ"), l11l (u"ࠢࡠࠤࡐ")) + l11l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1llll = os.path.join(os.environ.get(l11l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll1ll)
elif platform.system() == l11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1llll11 = os.path.join(os.environ.get(l11l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll11l1.split(l11l (u"ࠨࠬࠣࡖ"))[0].replace(l11l (u"ࠢࠡࠤࡗ"), l11l (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll11 = l1llllll(l1llll11 + l11l (u"ࠤ࠲࡙ࠦ"))
    l1l1llll = os.path.join(l1l1ll11, l1lll1ll)
elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1llll11 = os.path.join(os.environ.get(l11l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll11l1.split(l11l (u"ࠨࠬࠣ࡝"))[0].replace(l11l (u"ࠢࠡࠤ࡞"), l11l (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll11 = l1llllll(l1llll11 + l11l (u"ࠤ࠲ࠦࡠ"))
    l1l1llll = os.path.join(l1l1ll11, l1lll1ll)
else:
    l1l1llll = os.path.join(l1lll1ll)
logger = logging.getLogger(l11l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l11l1(logger, l1l1llll)
logger.info(l11l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1111)
logger.info(l11l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll11l1)
logger.info(l11l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll1l1)
l111 = get_major_version(VERSION)
l1ll = l1l11ll(l111, l1lll1l1)
logger.info(l11l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111)
logger.info(l11l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll)
logger.info(l11l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1ll1l():
    if l1l1l1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1lll():
    if l1l1l1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lllll1():
    l1ll11ll = l1l1ll1l().read(4)
    while len(l1ll11ll) == 4:
        l1l1lll1 = struct.unpack(l11l (u"ࠨࡀࡊࠤ࡫"), l1ll11ll)[0]
        request = l1l1ll1l().read(l1l1lll1).decode()
        logger.info(l11l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1ll1(request)
        l1llll1l(response)
        logger.info(l11l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll11ll = l1l1ll1l().read(4)
    logger.info(l11l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll1l(message):
    message = json.dumps(message).encode()
    l1ll1l11 = struct.pack(l11l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1lll().write(l1ll1l11)
    l1ll1lll().write(message)
    l1ll1lll().flush()
def l1ll1ll1(request):
    if request:
        l1ll111l = json.loads(request)
    try:
        return {
            l11l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l1l,
            l11l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11llll,
            l11l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1111ll
        }[l1ll111l[l11l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll111l)
    except Exception as e:
        logger.error(l11l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l1l()
def l11l1l(l1ll111l=None):
    l1lll11l(l1ll111l)
    l1l1l1l1 = {l11l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l()}
    l1l1l1l1[l11l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1llll1(l1ll)
    return l1l1l1l1
def l11llll(l1ll111l):
    url = l1ll111l[l11l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1 = url.split(l11l (u"ࠬࡀࠧࡸ"))[0]
    return {l11l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111111(l11l1, url)}
def l1111ll(l1ll111l):
    try:
        l11l1 = l11111(l1ll)
        url = l11l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1, l1ll111l[l11l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll111l[l11l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1, url))
        return {l11l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111111(l11l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll11l(l1ll111l):
    l1ll1l1l = l11l (u"࠭ࠧࢀ")
    if l1ll111l:
        for name in l1ll111l:
            if name in [l11l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l1l += l11l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll111l[name]
    if l1ll1l1l: logger.info(l1ll1l1l[:-1])
def main():
    try:
        l1l1l11()
        l1lllll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()