#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1lll1 (l11):
    global l11l11
    l1111l = ord (l11 [-1])
    l1lll = l11 [:-1]
    l1l1ll = l1111l % len (l1lll)
    l1l = l1lll [:l1l1ll] + l1lll [l1l1ll:]
    if l1:
        l11ll = l1111 () .join ([unichr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    return eval (l11ll)
import json
import struct
from l1l11 import *
l1ll1l1l = sys.version_info[0] == 2
l1l1llll = l1lll1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1llll11 = l1lll1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1lll1 (u"ࠥ࠺࠳࠸࠮࠹࠻࠶࠽࠳࠶ࠢࡅ")
l1ll11l1 = l1lll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1llll11.replace(l1lll1 (u"ࠧࠦࠢࡇ"), l1lll1 (u"ࠨ࡟ࠣࡈ")) + l1lll1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll11l = {}
if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1lll1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll11l = sys.argv[0]
        try:
            l1lll11l = l111l11(l1ll11l)
            l1llll11 = l1lll11l[l1lll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll11l[l1lll1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll11l1 = l1lll11l[l1lll1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1llll11.replace(l1lll1 (u"ࠨࠠࠣࡏ"), l1lll1 (u"ࠢࡠࠤࡐ")) + l1lll1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll1l1 = os.path.join(os.environ.get(l1lll1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l1lll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1lll = os.path.join(os.environ.get(l1lll1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1lll1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll11l1.split(l1lll1 (u"ࠨࠬࠣࡖ"))[0].replace(l1lll1 (u"ࠢࠡࠤࡗ"), l1lll1 (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll11 = l1lllll(l1ll1lll + l1lll1 (u"ࠤ࠲࡙ࠦ"))
    l1lll1l1 = os.path.join(l1l1ll11, l1ll11ll)
elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1lll = os.path.join(os.environ.get(l1lll1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1lll1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll11l1.split(l1lll1 (u"ࠨࠬࠣ࡝"))[0].replace(l1lll1 (u"ࠢࠡࠤ࡞"), l1lll1 (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll11 = l1lllll(l1ll1lll + l1lll1 (u"ࠤ࠲ࠦࡠ"))
    l1lll1l1 = os.path.join(l1l1ll11, l1ll11ll)
else:
    l1lll1l1 = os.path.join(l1ll11ll)
logger = logging.getLogger(l1lll1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l1ll(logger, l1lll1l1)
logger.info(l1lll1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1lll1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1llll11)
logger.info(l1lll1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1lll1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll11l1)
logger.info(l1lll1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1llll)
l1l1 = get_major_version(VERSION)
l1ll11 = l1l11l1(l1l1, l1l1llll)
logger.info(l1lll1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l1)
logger.info(l1lll1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll11)
logger.info(l1lll1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1lll1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll111l():
    if l1ll1l1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1ll1():
    if l1ll1l1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1l1l1():
    l1l1ll1l = l1ll111l().read(4)
    while len(l1l1ll1l) == 4:
        l1lll1ll = struct.unpack(l1lll1 (u"ࠨࡀࡊࠤ࡫"), l1l1ll1l)[0]
        request = l1ll111l().read(l1lll1ll).decode()
        logger.info(l1lll1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1l11(request)
        l1llll1l(response)
        logger.info(l1lll1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll1l = l1ll111l().read(4)
    logger.info(l1lll1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll1l(message):
    message = json.dumps(message).encode()
    l1lll111 = struct.pack(l1lll1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1ll1().write(l1lll111)
    l1ll1ll1().write(message)
    l1ll1ll1().flush()
def l1ll1l11(request):
    if request:
        l1lllll1 = json.loads(request)
    try:
        return {
            l1lll1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l111,
            l1lll1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11ll1l,
            l1lll1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111l1l
        }[l1lllll1[l1lll1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lllll1)
    except Exception as e:
        logger.error(l1lll1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l111()
def l1l111(l1lllll1=None):
    l1l1l1ll(l1lllll1)
    l1l1lll1 = {l1lll1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111()}
    l1l1lll1[l1lll1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l111(l1ll11)
    return l1l1lll1
def l11ll1l(l1lllll1):
    url = l1lllll1[l1lll1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l = url.split(l1lll1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1lll1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l1l1(l11l, url)}
def l111l1l(l1lllll1):
    try:
        l11l = l11111(l1ll11)
        url = l1lll1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l, l1lllll1[l1lll1 (u"ࠨࡣࡦࡸࠬࡻ")], l1lllll1[l1lll1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1lll1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l, url))
        return {l1lll1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l1l1(l11l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1lll1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1l1ll(l1lllll1):
    l1ll1111 = l1lll1 (u"࠭ࠧࢀ")
    if l1lllll1:
        for name in l1lllll1:
            if name in [l1lll1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1lll1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1111 += l1lll1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lllll1[name]
    if l1ll1111: logger.info(l1ll1111[:-1])
def main():
    try:
        l111lll()
        l1l1l1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1lll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()