#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll = sys.version_info [0] == 2
l11l1l = 2048
l1lll = 7
def l11l11 (l11lll):
    global l11ll1
    l1ll1l = ord (l11lll [-1])
    l1l11 = l11lll [:-1]
    l1111 = l1ll1l % len (l1l11)
    l11 = l1l11 [:l1111] + l1l11 [l1111:]
    if l1l1ll:
        l111l = l1l () .join ([unichr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    return eval (l111l)
import json
import struct
from l1ll1 import *
l1ll11l1 = sys.version_info[0] == 2
l1ll111l = l11l11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll111 = l11l11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l11 (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠻࠹࠴࠰ࠣࡅ")
l1l1l1ll = l11l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1lll111.replace(l11l11 (u"ࠧࠦࠢࡇ"), l11l11 (u"ࠨ࡟ࠣࡈ")) + l11l11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1l1 = {}
if platform.system() == l11l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11lll1 = sys.argv[0]
        try:
            l1lll1l1 = l1llll1(l11lll1)
            l1lll111 = l1lll1l1[l11l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1l1[l11l11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1l1ll = l1lll1l1[l11l11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1lll111.replace(l11l11 (u"ࠨࠠࠣࡏ"), l11l11 (u"ࠢࡠࠤࡐ")) + l11l11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll11 = os.path.join(os.environ.get(l11l11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l11l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1ll1 = os.path.join(os.environ.get(l11l11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1l1ll.split(l11l11 (u"ࠨࠬࠣࡖ"))[0].replace(l11l11 (u"ࠢࠡࠤࡗ"), l11l11 (u"ࠣࡡࠥࡘ")).lower())
    l1ll1l11 = l1ll1ll(l1ll1ll1 + l11l11 (u"ࠤ࠲࡙ࠦ"))
    l1l1ll11 = os.path.join(l1ll1l11, l1ll11ll)
elif platform.system() == l11l11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1ll1 = os.path.join(os.environ.get(l11l11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1l1ll.split(l11l11 (u"ࠨࠬࠣ࡝"))[0].replace(l11l11 (u"ࠢࠡࠤ࡞"), l11l11 (u"ࠣࡡࠥ࡟")).lower())
    l1ll1l11 = l1ll1ll(l1ll1ll1 + l11l11 (u"ࠤ࠲ࠦࡠ"))
    l1l1ll11 = os.path.join(l1ll1l11, l1ll11ll)
else:
    l1l1ll11 = os.path.join(l1ll11ll)
logger = logging.getLogger(l11l11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1111ll(logger, l1l1ll11)
logger.info(l11l11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll111)
logger.info(l11l11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1l1ll)
logger.info(l11l11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll111l)
l1ll = get_major_version(VERSION)
l1l111 = l1llllll(l1ll, l1ll111l)
logger.info(l11l11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1ll)
logger.info(l11l11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l111)
logger.info(l11l11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1llll():
    if l1ll11l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1ll():
    if l1ll11l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1l1l():
    l1ll1lll = l1l1llll().read(4)
    while len(l1ll1lll) == 4:
        l1ll1111 = struct.unpack(l11l11 (u"ࠨࡀࡊࠤ࡫"), l1ll1lll)[0]
        request = l1l1llll().read(l1ll1111).decode()
        logger.info(l11l11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1lll1(request)
        l1lllll1(response)
        logger.info(l11l11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1lll = l1l1llll().read(4)
    logger.info(l11l11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lllll1(message):
    message = json.dumps(message).encode()
    l1l1l1l1 = struct.pack(l11l11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1ll().write(l1l1l1l1)
    l1lll1ll().write(message)
    l1lll1ll().flush()
def l1l1lll1(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l11l11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11ll,
            l11l11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l111l,
            l11l11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll111
        }[l1llll1l[l11l11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l11l11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11ll()
def l11ll(l1llll1l=None):
    l1lll11l(l1llll1l)
    l1llll11 = {l11l11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l1l1()}
    l1llll11[l11l11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1ll1(l1l111)
    return l1llll11
def l1l111l(l1llll1l):
    url = l1llll1l[l11l11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1 = url.split(l11l11 (u"ࠬࡀࠧࡸ"))[0]
    return {l11l11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1111(l1l1, url)}
def l1ll111(l1llll1l):
    try:
        l1l1 = l1111l1(l1l111)
        url = l11l11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1, l1llll1l[l11l11 (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l11l11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1, url))
        return {l11l11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1111(l1l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll11l(l1llll1l):
    l1l1ll1l = l11l11 (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l11l11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1ll1l += l11l11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1l1ll1l: logger.info(l1l1ll1l[:-1])
def main():
    try:
        l1l1l11()
        l1ll1l1l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()