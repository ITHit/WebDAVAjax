#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1 = 2048
l111 = 7
def l1lll (l1l111):
    global l11l1l
    l1l = ord (l1l111 [-1])
    l11lll = l1l111 [:-1]
    l1ll1 = l1l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l1l1l:
        l1l1ll = l1ll11 () .join ([unichr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    return eval (l1l1ll)
import json
import struct
from l111ll import *
l1l1ll11 = sys.version_info[0] == 2
l1lllll1 = l1lll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1111 = l1lll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1lll (u"ࠥ࠺࠳࠶࠮࠹࠹࠸࠸࠳࠶ࠢࡅ")
l1ll1l11 = l1lll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1ll1l = l1ll1111.replace(l1lll (u"ࠧࠦࠢࡇ"), l1lll (u"ࠨ࡟ࠣࡈ")) + l1lll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll111 = {}
if platform.system() == l1lll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1lll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l11ll = sys.argv[0]
        try:
            l1lll111 = l1111l1(l1l11ll)
            l1ll1111 = l1lll111[l1lll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll111[l1lll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1lll111[l1lll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1ll1l = l1ll1111.replace(l1lll (u"ࠨࠠࠣࡏ"), l1lll (u"ࠢࡠࠤࡐ")) + l1lll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll11l1 = os.path.join(os.environ.get(l1lll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1ll1l)
elif platform.system() == l1lll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lll11l = os.path.join(os.environ.get(l1lll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1lll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l1lll (u"ࠨࠬࠣࡖ"))[0].replace(l1lll (u"ࠢࠡࠤࡗ"), l1lll (u"ࠣࡡࠥࡘ")).lower())
    l1lll1l1 = l1l1lll(l1lll11l + l1lll (u"ࠤ࠲࡙ࠦ"))
    l1ll11l1 = os.path.join(l1lll1l1, l1l1ll1l)
elif platform.system() == l1lll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lll11l = os.path.join(os.environ.get(l1lll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1lll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l1lll (u"ࠨࠬࠣ࡝"))[0].replace(l1lll (u"ࠢࠡࠤ࡞"), l1lll (u"ࠣࡡࠥ࡟")).lower())
    l1lll1l1 = l1l1lll(l1lll11l + l1lll (u"ࠤ࠲ࠦࡠ"))
    l1ll11l1 = os.path.join(l1lll1l1, l1l1ll1l)
else:
    l1ll11l1 = os.path.join(l1l1ll1l)
logger = logging.getLogger(l1lll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1llll1(logger, l1ll11l1)
logger.info(l1lll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1lll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1111)
logger.info(l1lll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1lll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l1lll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lllll1)
l11ll1 = get_major_version(VERSION)
l1111l = l1l1l1l(l11ll1, l1lllll1)
logger.info(l1lll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11ll1)
logger.info(l1lll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111l)
logger.info(l1lll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1lll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1ll1():
    if l1l1ll11:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1l1():
    if l1l1ll11:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1ll():
    l1ll1lll = l1ll1ll1().read(4)
    while len(l1ll1lll) == 4:
        l1llll11 = struct.unpack(l1lll (u"ࠨࡀࡊࠤ࡫"), l1ll1lll)[0]
        request = l1ll1ll1().read(l1llll11).decode()
        logger.info(l1lll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1l1ll(request)
        l1ll111l(response)
        logger.info(l1lll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1lll = l1ll1ll1().read(4)
    logger.info(l1lll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll111l(message):
    message = json.dumps(message).encode()
    l1ll1l1l = struct.pack(l1lll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1l1().write(l1ll1l1l)
    l1l1l1l1().write(message)
    l1l1l1l1().flush()
def l1l1l1ll(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l1lll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): ll,
            l1lll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lll11,
            l1lll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lllll
        }[l1llll1l[l1lll (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l1lll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return ll()
def ll(l1llll1l=None):
    l1ll11ll(l1llll1l)
    l1l1llll = {l1lll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll()}
    l1l1llll[l1lll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1l1(l1111l)
    return l1l1llll
def l1lll11(l1llll1l):
    url = l1llll1l[l1lll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1lll1 = url.split(l1lll (u"ࠬࡀࠧࡸ"))[0]
    return {l1lll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11ll11(l1lll1, url)}
def l1lllll(l1llll1l):
    try:
        l1lll1 = l11111(l1111l)
        url = l1lll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1lll1, l1llll1l[l1lll (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l1lll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1lll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1lll1, url))
        return {l1lll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11ll11(l1lll1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1lll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll11ll(l1llll1l):
    l1l1lll1 = l1lll (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l1lll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1lll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1lll1 += l1lll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1l1lll1: logger.info(l1l1lll1[:-1])
def main():
    try:
        l11l11l()
        l1lll1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1lll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()