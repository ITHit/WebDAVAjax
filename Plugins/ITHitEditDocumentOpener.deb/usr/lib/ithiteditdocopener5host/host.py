#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11l1 = 2048
l11 = 7
def l1lll1 (l1111l):
    global l1ll1
    l1llll = ord (l1111l [-1])
    l1lll = l1111l [:-1]
    l1l1 = l1llll % len (l1lll)
    l11l11 = l1lll [:l1l1] + l1lll [l1l1:]
    if l111l:
        l111ll = l11lll () .join ([unichr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    return eval (l111ll)
import json
import struct
from ll import *
l1l1lll1 = sys.version_info[0] == 2
l1l1ll1l = l1lll1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1lll = l1lll1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1lll1 (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠻࠽࠴࠰ࠣࡅ")
l1ll1l11 = l1lll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll11l = l1ll1lll.replace(l1lll1 (u"ࠧࠦࠢࡇ"), l1lll1 (u"ࠨ࡟ࠣࡈ")) + l1lll1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11ll = {}
if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1lll1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11l11l = sys.argv[0]
        try:
            l1ll11ll = l1lll11(l11l11l)
            l1ll1lll = l1ll11ll[l1lll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11ll[l1lll1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1ll11ll[l1lll1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll11l = l1ll1lll.replace(l1lll1 (u"ࠨࠠࠣࡏ"), l1lll1 (u"ࠢࡠࠤࡐ")) + l1lll1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll1l = os.path.join(os.environ.get(l1lll1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll11l)
elif platform.system() == l1lll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll11 = os.path.join(os.environ.get(l1lll1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1lll1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l1lll1 (u"ࠨࠬࠣࡖ"))[0].replace(l1lll1 (u"ࠢࠡࠤࡗ"), l1lll1 (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l1ll111(l1l1ll11 + l1lll1 (u"ࠤ࠲࡙ࠦ"))
    l1llll1l = os.path.join(l1l1llll, l1lll11l)
elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll11 = os.path.join(os.environ.get(l1lll1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1lll1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l1lll1 (u"ࠨࠬࠣ࡝"))[0].replace(l1lll1 (u"ࠢࠡࠤ࡞"), l1lll1 (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l1ll111(l1l1ll11 + l1lll1 (u"ࠤ࠲ࠦࡠ"))
    l1llll1l = os.path.join(l1l1llll, l1lll11l)
else:
    l1llll1l = os.path.join(l1lll11l)
logger = logging.getLogger(l1lll1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l11l1(logger, l1llll1l)
logger.info(l1lll1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1lll1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1lll)
logger.info(l1lll1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1lll1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l1lll1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1ll1l)
l11l = get_major_version(VERSION)
l111 = l11ll1l(l11l, l1l1ll1l)
logger.info(l1lll1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11l)
logger.info(l1lll1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111)
logger.info(l1lll1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1lll1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll11l1():
    if l1l1lll1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll111l():
    if l1l1lll1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1l1():
    l1ll1111 = l1ll11l1().read(4)
    while len(l1ll1111) == 4:
        l1l1l1ll = struct.unpack(l1lll1 (u"ࠨࡀࡊࠤ࡫"), l1ll1111)[0]
        request = l1ll11l1().read(l1l1l1ll).decode()
        logger.info(l1lll1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1l1l1(request)
        l1ll1ll1(response)
        logger.info(l1lll1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1111 = l1ll11l1().read(4)
    logger.info(l1lll1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1ll1(message):
    message = json.dumps(message).encode()
    l1llll11 = struct.pack(l1lll1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll111l().write(l1llll11)
    l1ll111l().write(message)
    l1ll111l().flush()
def l1l1l1l1(request):
    if request:
        l1lll111 = json.loads(request)
    try:
        return {
            l1lll1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l,
            l1lll1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l111,
            l1lll1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111111
        }[l1lll111[l1lll1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll111)
    except Exception as e:
        logger.error(l1lll1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l()
def l1l(l1lll111=None):
    l1lllll1(l1lll111)
    l1lll1ll = {l1lll1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1111()}
    l1lll1ll[l1lll1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1ll(l111)
    return l1lll1ll
def l11l111(l1lll111):
    url = l1lll111[l1lll1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l11 = url.split(l1lll1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1lll1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11lll1(l1l11, url)}
def l111111(l1lll111):
    try:
        l1l11 = l1lll1l(l111)
        url = l1lll1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l11, l1lll111[l1lll1 (u"ࠨࡣࡦࡸࠬࡻ")], l1lll111[l1lll1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1lll1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l11, url))
        return {l1lll1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11lll1(l1l11, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1lll1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lllll1(l1lll111):
    l1ll1l1l = l1lll1 (u"࠭ࠧࢀ")
    if l1lll111:
        for name in l1lll111:
            if name in [l1lll1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1lll1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l1l += l1lll1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll111[name]
    if l1ll1l1l: logger.info(l1ll1l1l[:-1])
def main():
    try:
        l1llllll()
        l1lll1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1lll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()