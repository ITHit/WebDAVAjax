#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l = 2048
l1l1l1 = 7
def l111l (l11ll):
    global l1l1l
    l1l1ll = ord (l11ll [-1])
    l11l11 = l11ll [:-1]
    l11l1l = l1l1ll % len (l11l11)
    l1l111 = l11l11 [:l11l1l] + l11l11 [l11l1l:]
    if l1:
        l1lll1 = ll () .join ([unichr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    return eval (l1lll1)
import json
import struct
from l111l1 import *
l1ll1l1l = sys.version_info[0] == 2
l1lll11l = l111l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1llll11 = l111l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l111l (u"ࠥ࠺࠳࠶࠮࠹࠹࠹࠴࠳࠶ࠢࡅ")
l1lllll1 = l111l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1lll = l1llll11.replace(l111l (u"ࠧࠦࠢࡇ"), l111l (u"ࠨ࡟ࠣࡈ")) + l111l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11ll = {}
if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l111l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll1l1 = sys.argv[0]
        try:
            l1ll11ll = l11111(l1ll1l1)
            l1llll11 = l1ll11ll[l111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11ll[l111l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lllll1 = l1ll11ll[l111l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1lll = l1llll11.replace(l111l (u"ࠨࠠࠣࡏ"), l111l (u"ࠢࡠࠤࡐ")) + l111l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll11l1 = os.path.join(os.environ.get(l111l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1lll)
elif platform.system() == l111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll11 = os.path.join(os.environ.get(l111l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l111l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lllll1.split(l111l (u"ࠨࠬࠣࡖ"))[0].replace(l111l (u"ࠢࠡࠤࡗ"), l111l (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll1l = l1ll11l(l1l1ll11 + l111l (u"ࠤ࠲࡙ࠦ"))
    l1ll11l1 = os.path.join(l1l1ll1l, l1ll1lll)
elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll11 = os.path.join(os.environ.get(l111l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l111l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lllll1.split(l111l (u"ࠨࠬࠣ࡝"))[0].replace(l111l (u"ࠢࠡࠤ࡞"), l111l (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll1l = l1ll11l(l1l1ll11 + l111l (u"ࠤ࠲ࠦࡠ"))
    l1ll11l1 = os.path.join(l1l1ll1l, l1ll1lll)
else:
    l1ll11l1 = os.path.join(l1ll1lll)
logger = logging.getLogger(l111l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1111l1(logger, l1ll11l1)
logger.info(l111l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l111l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1llll11)
logger.info(l111l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l111l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lllll1)
logger.info(l111l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll11l)
l1ll1l = get_major_version(VERSION)
l1ll1 = l111lll(l1ll1l, l1lll11l)
logger.info(l111l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1ll1l)
logger.info(l111l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1)
logger.info(l111l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l111l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1111():
    if l1ll1l1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1lll1():
    if l1ll1l1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1l1():
    l1l1l1l1 = l1ll1111().read(4)
    while len(l1l1l1l1) == 4:
        l1ll1l11 = struct.unpack(l111l (u"ࠨࡀࡊࠤ࡫"), l1l1l1l1)[0]
        request = l1ll1111().read(l1ll1l11).decode()
        logger.info(l111l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll1l(request)
        l1lll111(response)
        logger.info(l111l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1l1l1 = l1ll1111().read(4)
    logger.info(l111l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll111(message):
    message = json.dumps(message).encode()
    l1lll1ll = struct.pack(l111l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1lll1().write(l1lll1ll)
    l1l1lll1().write(message)
    l1l1lll1().flush()
def l1llll1l(request):
    if request:
        l1l1l1ll = json.loads(request)
    try:
        return {
            l111l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l11l,
            l111l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l111l1l,
            l111l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1llllll
        }[l1l1l1ll[l111l (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1ll)
    except Exception as e:
        logger.error(l111l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l11l()
def l1l11l(l1l1l1ll=None):
    l1ll111l(l1l1l1ll)
    l1ll1ll1 = {l111l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11lll()}
    l1ll1ll1[l111l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1lllll(l1ll1)
    return l1ll1ll1
def l111l1l(l1l1l1ll):
    url = l1l1l1ll[l111l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11 = url.split(l111l (u"ࠬࡀࠧࡸ"))[0]
    return {l111l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11llll(l11, url)}
def l1llllll(l1l1l1ll):
    try:
        l11 = l1l1111(l1ll1)
        url = l111l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11, l1l1l1ll[l111l (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1ll[l111l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l111l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11, url))
        return {l111l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11llll(l11, url)}
    except Exception as e:
        logger.error(str(e))
        return {l111l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll111l(l1l1l1ll):
    l1l1llll = l111l (u"࠭ࠧࢀ")
    if l1l1l1ll:
        for name in l1l1l1ll:
            if name in [l111l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l111l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1llll += l111l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1ll[name]
    if l1l1llll: logger.info(l1l1llll[:-1])
def main():
    try:
        l1l1ll1()
        l1lll1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l111l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()