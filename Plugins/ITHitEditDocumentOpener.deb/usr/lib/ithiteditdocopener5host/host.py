#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l11l1l = 7
def l11ll (l1ll1):
    global l1l1l
    l1l11 = ord (l1ll1 [-1])
    l11l11 = l1ll1 [:-1]
    l1l111 = l1l11 % len (l11l11)
    l1ll1l = l11l11 [:l1l111] + l11l11 [l1l111:]
    if l1ll11:
        l1 = l11lll () .join ([unichr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    return eval (l1)
import json
import struct
from l1111 import *
l1ll11ll = sys.version_info[0] == 2
l1ll1111 = l11ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1ll11 = l11ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11ll (u"ࠥ࠺࠳࠶࠮࠹࠻࠵࠴࠳࠶ࠢࡅ")
l1lll1ll = l11ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1l1ll = l1l1ll11.replace(l11ll (u"ࠧࠦࠢࡇ"), l11ll (u"ࠨ࡟ࠣࡈ")) + l11ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll111l = {}
if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111l11 = sys.argv[0]
        try:
            l1ll111l = l11lll1(l111l11)
            l1l1ll11 = l1ll111l[l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll111l[l11ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll1ll = l1ll111l[l11ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1l1ll = l1l1ll11.replace(l11ll (u"ࠨࠠࠣࡏ"), l11ll (u"ࠢࡠࠤࡐ")) + l11ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll1l1 = os.path.join(os.environ.get(l11ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1l1ll)
elif platform.system() == l11ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lll11l = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll1ll.split(l11ll (u"ࠨࠬࠣࡖ"))[0].replace(l11ll (u"ࠢࠡࠤࡗ"), l11ll (u"ࠣࡡࠥࡘ")).lower())
    l1lll111 = l111111(l1lll11l + l11ll (u"ࠤ࠲࡙ࠦ"))
    l1lll1l1 = os.path.join(l1lll111, l1l1l1ll)
elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lll11l = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll1ll.split(l11ll (u"ࠨࠬࠣ࡝"))[0].replace(l11ll (u"ࠢࠡࠤ࡞"), l11ll (u"ࠣࡡࠥ࡟")).lower())
    l1lll111 = l111111(l1lll11l + l11ll (u"ࠤ࠲ࠦࡠ"))
    l1lll1l1 = os.path.join(l1lll111, l1l1l1ll)
else:
    l1lll1l1 = os.path.join(l1l1l1ll)
logger = logging.getLogger(l11ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll1l1(logger, l1lll1l1)
logger.info(l11ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1ll11)
logger.info(l11ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll1ll)
logger.info(l11ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l111 = get_major_version(VERSION)
l1lll = l1l111l(l111, l1ll1111)
logger.info(l11ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111)
logger.info(l11ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll)
logger.info(l11ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1llll():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lllll1():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1llll11():
    l1ll1l1l = l1l1llll().read(4)
    while len(l1ll1l1l) == 4:
        l1ll1l11 = struct.unpack(l11ll (u"ࠨࡀࡊࠤ࡫"), l1ll1l1l)[0]
        request = l1l1llll().read(l1ll1l11).decode()
        logger.info(l11ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1lll(request)
        l1l1ll1l(response)
        logger.info(l11ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l1l = l1l1llll().read(4)
    logger.info(l11ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1ll1l(message):
    message = json.dumps(message).encode()
    l1ll11l1 = struct.pack(l11ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lllll1().write(l1ll11l1)
    l1lllll1().write(message)
    l1lllll1().flush()
def l1ll1lll(request):
    if request:
        l1l1l1l1 = json.loads(request)
    try:
        return {
            l11ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l,
            l11ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11111,
            l11ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lll11
        }[l1l1l1l1[l11ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1l1)
    except Exception as e:
        logger.error(l11ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l()
def l11l(l1l1l1l1=None):
    l1llll1l(l1l1l1l1)
    l1l1lll1 = {l11ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11()}
    l1l1lll1[l11ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1l1l(l1lll)
    return l1l1lll1
def l11111(l1l1l1l1):
    url = l1l1l1l1[l11ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1llll = url.split(l11ll (u"ࠬࡀࠧࡸ"))[0]
    return {l11ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l1l1(l1llll, url)}
def l1lll11(l1l1l1l1):
    try:
        l1llll = l1llllll(l1lll)
        url = l11ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1llll, l1l1l1l1[l11ll (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1l1[l11ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1llll, url))
        return {l11ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l1l1(l1llll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll1l(l1l1l1l1):
    l1ll1ll1 = l11ll (u"࠭ࠧࢀ")
    if l1l1l1l1:
        for name in l1l1l1l1:
            if name in [l11ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1ll1 += l11ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1l1[name]
    if l1ll1ll1: logger.info(l1ll1ll1[:-1])
def main():
    try:
        l11llll()
        l1llll11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()