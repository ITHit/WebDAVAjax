#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll11 = 2048
l111ll = 7
def l11ll (l11l11):
    global l1111
    l11l1 = ord (l11l11 [-1])
    l1 = l11l11 [:-1]
    ll = l11l1 % len (l1)
    l1ll1 = l1 [:ll] + l1 [ll:]
    if l1l1l1:
        l11l1l = l1l11l () .join ([unichr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    return eval (l11l1l)
import json
import struct
from l11l import *
l1ll11ll = sys.version_info[0] == 2
l1lllll1 = l11ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1lll1 = l11ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠻࠸࠴࠰ࠣࡅ")
l1l1ll1l = l11ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1ll11 = l1l1lll1.replace(l11ll (u"ࠧࠦࠢࡇ"), l11ll (u"ࠨ࡟ࠣࡈ")) + l11ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1111l1 = sys.argv[0]
        try:
            l1ll1l11 = l11ll11(l1111l1)
            l1l1lll1 = l1ll1l11[l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l11ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll1l = l1ll1l11[l11ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1ll11 = l1l1lll1.replace(l11ll (u"ࠨࠠࠣࡏ"), l11ll (u"ࠢࡠࠤࡐ")) + l11ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll1l = os.path.join(os.environ.get(l11ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1ll11)
elif platform.system() == l11ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1l1 = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll1l.split(l11ll (u"ࠨࠬࠣࡖ"))[0].replace(l11ll (u"ࠢࠡࠤࡗ"), l11ll (u"ࠣࡡࠥࡘ")).lower())
    l1lll11l = l111l11(l1l1l1l1 + l11ll (u"ࠤ࠲࡙ࠦ"))
    l1llll1l = os.path.join(l1lll11l, l1l1ll11)
elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1l1 = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll1l.split(l11ll (u"ࠨࠬࠣ࡝"))[0].replace(l11ll (u"ࠢࠡࠤ࡞"), l11ll (u"ࠣࡡࠥ࡟")).lower())
    l1lll11l = l111l11(l1l1l1l1 + l11ll (u"ࠤ࠲ࠦࡠ"))
    l1llll1l = os.path.join(l1lll11l, l1l1ll11)
else:
    l1llll1l = os.path.join(l1l1ll11)
logger = logging.getLogger(l11ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1lllll(logger, l1llll1l)
logger.info(l11ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1lll1)
logger.info(l11ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll1l)
logger.info(l11ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lllll1)
l11ll1 = get_major_version(VERSION)
l1llll = l11llll(l11ll1, l1lllll1)
logger.info(l11ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11ll1)
logger.info(l11ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1llll)
logger.info(l11ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1111():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1ll():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll111():
    l1ll111l = l1ll1111().read(4)
    while len(l1ll111l) == 4:
        l1l1l1ll = struct.unpack(l11ll (u"ࠨࡀࡊࠤ࡫"), l1ll111l)[0]
        request = l1ll1111().read(l1l1l1ll).decode()
        logger.info(l11ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11l1(request)
        l1lll1l1(response)
        logger.info(l11ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll111l = l1ll1111().read(4)
    logger.info(l11ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1l1(message):
    message = json.dumps(message).encode()
    l1ll1l1l = struct.pack(l11ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1ll().write(l1ll1l1l)
    l1lll1ll().write(message)
    l1lll1ll().flush()
def l1ll11l1(request):
    if request:
        l1llll11 = json.loads(request)
    try:
        return {
            l11ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1lll1,
            l11ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l11ll,
            l11ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11lll1
        }[l1llll11[l11ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll11)
    except Exception as e:
        logger.error(l11ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1lll1()
def l1lll1(l1llll11=None):
    l1l1llll(l1llll11)
    l1ll1ll1 = {l11ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l11()}
    l1ll1ll1[l11ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l11l(l1llll)
    return l1ll1ll1
def l1l11ll(l1llll11):
    url = l1llll11[l11ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1ll = url.split(l11ll (u"ࠬࡀࠧࡸ"))[0]
    return {l11ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1111ll(l1ll, url)}
def l11lll1(l1llll11):
    try:
        l1ll = l1l1111(l1llll)
        url = l11ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1ll, l1llll11[l11ll (u"ࠨࡣࡦࡸࠬࡻ")], l1llll11[l11ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1ll, url))
        return {l11ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1111ll(l1ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1llll(l1llll11):
    l1ll1lll = l11ll (u"࠭ࠧࢀ")
    if l1llll11:
        for name in l1llll11:
            if name in [l11ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1lll += l11ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll11[name]
    if l1ll1lll: logger.info(l1ll1lll[:-1])
def main():
    try:
        l1l1l11()
        l1lll111()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()