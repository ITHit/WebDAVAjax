#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l1l11l = 2048
l11l1l = 7
def l11l11 (l1l1l1):
    global l11ll
    l11 = ord (l1l1l1 [-1])
    l11lll = l1l1l1 [:-1]
    l1111 = l11 % len (l11lll)
    l1 = l11lll [:l1111] + l11lll [l1111:]
    if l1lll1:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1l11l - (l111ll + l11) % l11l1l) for l111ll, char in enumerate (l1)])
    return eval (l1ll1l)
import json
import struct
from l1111l import *
l1llll1l = sys.version_info[0] == 2
l1lll1l1 = l11l11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lllll1 = l11l11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l11 (u"ࠥ࠺࠳࠶࠮࠹࠹࠹࠺࠳࠶ࠢࡅ")
l1lll1ll = l11l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll111l = l1lllll1.replace(l11l11 (u"ࠧࠦࠢࡇ"), l11l11 (u"ࠨ࡟ࠣࡈ")) + l11l11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l11l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l11l1 = sys.argv[0]
        try:
            l1ll1l11 = l1111ll(l1l11l1)
            l1lllll1 = l1ll1l11[l11l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l11l11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll1ll = l1ll1l11[l11l11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll111l = l1lllll1.replace(l11l11 (u"ࠨࠠࠣࡏ"), l11l11 (u"ࠢࡠࠤࡐ")) + l11l11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll111 = os.path.join(os.environ.get(l11l11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll111l)
elif platform.system() == l11l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1ll1 = os.path.join(os.environ.get(l11l11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll1ll.split(l11l11 (u"ࠨࠬࠣࡖ"))[0].replace(l11l11 (u"ࠢࠡࠤࡗ"), l11l11 (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll1l = l11ll1l(l1ll1ll1 + l11l11 (u"ࠤ࠲࡙ࠦ"))
    l1lll111 = os.path.join(l1l1ll1l, l1ll111l)
elif platform.system() == l11l11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1ll1 = os.path.join(os.environ.get(l11l11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll1ll.split(l11l11 (u"ࠨࠬࠣ࡝"))[0].replace(l11l11 (u"ࠢࠡࠤ࡞"), l11l11 (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll1l = l11ll1l(l1ll1ll1 + l11l11 (u"ࠤ࠲ࠦࡠ"))
    l1lll111 = os.path.join(l1l1ll1l, l1ll111l)
else:
    l1lll111 = os.path.join(l1ll111l)
logger = logging.getLogger(l11l11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11111l(logger, l1lll111)
logger.info(l11l11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lllll1)
logger.info(l11l11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll1ll)
logger.info(l11l11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll1l1)
l1l1ll = get_major_version(VERSION)
l111l1 = l11l111(l1l1ll, l1lll1l1)
logger.info(l11l11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l1ll)
logger.info(l11l11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111l1)
logger.info(l11l11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1ll11():
    if l1llll1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1ll():
    if l1llll1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll11l():
    l1l1l1l1 = l1l1ll11().read(4)
    while len(l1l1l1l1) == 4:
        l1ll1lll = struct.unpack(l11l11 (u"ࠨࡀࡊࠤ࡫"), l1l1l1l1)[0]
        request = l1l1ll11().read(l1ll1lll).decode()
        logger.info(l11l11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll11(request)
        l1ll11ll(response)
        logger.info(l11l11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1l1l1 = l1l1ll11().read(4)
    logger.info(l11l11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll11ll(message):
    message = json.dumps(message).encode()
    l1l1llll = struct.pack(l11l11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1ll().write(l1l1llll)
    l1l1l1ll().write(message)
    l1l1l1ll().flush()
def l1llll11(request):
    if request:
        l1ll11l1 = json.loads(request)
    try:
        return {
            l11l11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l111,
            l11l11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l11ll,
            l11l11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll111
        }[l1ll11l1[l11l11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll11l1)
    except Exception as e:
        logger.error(l11l11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l111()
def l1l111(l1ll11l1=None):
    l1ll1l1l(l1ll11l1)
    l1ll1111 = {l11l11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): ll()}
    l1ll1111[l11l11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11111(l111l1)
    return l1ll1111
def l1l11ll(l1ll11l1):
    url = l1ll11l1[l11l11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l = url.split(l11l11 (u"ࠬࡀࠧࡸ"))[0]
    return {l11l11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1ll1(l11l, url)}
def l1ll111(l1ll11l1):
    try:
        l11l = l11ll11(l111l1)
        url = l11l11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l, l1ll11l1[l11l11 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll11l1[l11l11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l, url))
        return {l11l11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1ll1(l11l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1l1l(l1ll11l1):
    l1l1lll1 = l11l11 (u"࠭ࠧࢀ")
    if l1ll11l1:
        for name in l1ll11l1:
            if name in [l11l11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1lll1 += l11l11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll11l1[name]
    if l1l1lll1: logger.info(l1l1lll1[:-1])
def main():
    try:
        l1llll1()
        l1lll11l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()