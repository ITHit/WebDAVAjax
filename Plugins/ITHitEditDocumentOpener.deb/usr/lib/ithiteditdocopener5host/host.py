#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1l = 7
def l11ll1 (ll):
    global l1l1
    l1l1ll = ord (ll [-1])
    l1ll11 = ll [:-1]
    l1l11 = l1l1ll % len (l1ll11)
    l11 = l1ll11 [:l1l11] + l1ll11 [l1l11:]
    if l11l1l:
        l1 = l11lll () .join ([unichr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    return eval (l1)
import json
import struct
from l1111l import *
l1ll1l11 = sys.version_info[0] == 2
l1l1llll = l11ll1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lllll1 = l11ll1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11ll1 (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠶࠶࠴࠰ࠣࡅ")
l1ll1l1l = l11ll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll111l = l1lllll1.replace(l11ll1 (u"ࠧࠦࠢࡇ"), l11ll1 (u"ࠨ࡟ࠣࡈ")) + l11ll1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1llll11 = {}
if platform.system() == l11ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11ll1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1111l1 = sys.argv[0]
        try:
            l1llll11 = l1llllll(l1111l1)
            l1lllll1 = l1llll11[l11ll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1llll11[l11ll1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l1l = l1llll11[l11ll1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll111l = l1lllll1.replace(l11ll1 (u"ࠨࠠࠣࡏ"), l11ll1 (u"ࠢࡠࠤࡐ")) + l11ll1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1ll1 = os.path.join(os.environ.get(l11ll1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll111l)
elif platform.system() == l11ll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1lll = os.path.join(os.environ.get(l11ll1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11ll1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l1l.split(l11ll1 (u"ࠨࠬࠣࡖ"))[0].replace(l11ll1 (u"ࠢࠡࠤࡗ"), l11ll1 (u"ࠣࡡࠥࡘ")).lower())
    l1lll1l1 = l1111ll(l1ll1lll + l11ll1 (u"ࠤ࠲࡙ࠦ"))
    l1ll1ll1 = os.path.join(l1lll1l1, l1ll111l)
elif platform.system() == l11ll1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1lll = os.path.join(os.environ.get(l11ll1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11ll1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l1l.split(l11ll1 (u"ࠨࠬࠣ࡝"))[0].replace(l11ll1 (u"ࠢࠡࠤ࡞"), l11ll1 (u"ࠣࡡࠥ࡟")).lower())
    l1lll1l1 = l1111ll(l1ll1lll + l11ll1 (u"ࠤ࠲ࠦࡠ"))
    l1ll1ll1 = os.path.join(l1lll1l1, l1ll111l)
else:
    l1ll1ll1 = os.path.join(l1ll111l)
logger = logging.getLogger(l11ll1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11ll1l(logger, l1ll1ll1)
logger.info(l11ll1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11ll1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lllll1)
logger.info(l11ll1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11ll1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l1l)
logger.info(l11ll1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1llll)
l1l111 = get_major_version(VERSION)
l111l1 = l11l1ll(l1l111, l1l1llll)
logger.info(l11ll1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l111)
logger.info(l11ll1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111l1)
logger.info(l11ll1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11ll1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1111():
    if l1ll1l11:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll1l():
    if l1ll1l11:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1ll():
    l1l1l1ll = l1ll1111().read(4)
    while len(l1l1l1ll) == 4:
        l1lll111 = struct.unpack(l11ll1 (u"ࠨࡀࡊࠤ࡫"), l1l1l1ll)[0]
        request = l1ll1111().read(l1lll111).decode()
        logger.info(l11ll1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1lll1(request)
        l1l1ll11(response)
        logger.info(l11ll1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1l1ll = l1ll1111().read(4)
    logger.info(l11ll1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1ll11(message):
    message = json.dumps(message).encode()
    l1ll11l1 = struct.pack(l11ll1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll1l().write(l1ll11l1)
    l1l1ll1l().write(message)
    l1l1ll1l().flush()
def l1l1lll1(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l11ll1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l,
            l11ll1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l111111,
            l11ll1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111lll
        }[l1llll1l[l11ll1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l11ll1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l()
def l11l(l1llll1l=None):
    l1lll11l(l1llll1l)
    l1ll11ll = {l11ll1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1111()}
    l1ll11ll[l11ll1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll1l1(l111l1)
    return l1ll11ll
def l111111(l1llll1l):
    url = l1llll1l[l11ll1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1ll = url.split(l11ll1 (u"ࠬࡀࠧࡸ"))[0]
    return {l11ll1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1ll1ll(l1ll, url)}
def l111lll(l1llll1l):
    try:
        l1ll = l1lll1l(l111l1)
        url = l11ll1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1ll, l1llll1l[l11ll1 (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l11ll1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11ll1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1ll, url))
        return {l11ll1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1ll1ll(l1ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11ll1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll11l(l1llll1l):
    l1l1l1l1 = l11ll1 (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l11ll1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11ll1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1l1 += l11ll1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1l1l1l1: logger.info(l1l1l1l1[:-1])
def main():
    try:
        l111l1l()
        l1lll1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11ll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()