#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l11lll = 2048
l111ll = 7
def l11 (l1l1l):
    global l1111l
    l1lll1 = ord (l1l1l [-1])
    l1l11 = l1l1l [:-1]
    l11ll = l1lll1 % len (l1l11)
    l1l1 = l1l11 [:l11ll] + l1l11 [l11ll:]
    if l1ll:
        l111l1 = l111 () .join ([unichr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    return eval (l111l1)
import json
import struct
from l1llll import *
l1ll111l = sys.version_info[0] == 2
l1llll11 = l11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1lll1 = l11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11 (u"ࠥ࠺࠳࠸࠮࠹࠻࠶࠼࠳࠶ࠢࡅ")
l1l1llll = l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1llll1l = l1l1lll1.replace(l11 (u"ࠧࠦࠢࡇ"), l11 (u"ࠨ࡟ࠣࡈ")) + l11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11l1 = {}
if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll11l = sys.argv[0]
        try:
            l1ll11l1 = l1llll1(l1ll11l)
            l1l1lll1 = l1ll11l1[l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11l1[l11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1llll = l1ll11l1[l11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1llll1l = l1l1lll1.replace(l11 (u"ࠨࠠࠣࡏ"), l11 (u"ࠢࡠࠤࡐ")) + l11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll1ll = os.path.join(os.environ.get(l11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1llll1l)
elif platform.system() == l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1ll = os.path.join(os.environ.get(l11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1llll.split(l11 (u"ࠨࠬࠣࡖ"))[0].replace(l11 (u"ࠢࠡࠤࡗ"), l11 (u"ࠣࡡࠥࡘ")).lower())
    l1ll1l1l = l1ll111(l1l1l1ll + l11 (u"ࠤ࠲࡙ࠦ"))
    l1lll1ll = os.path.join(l1ll1l1l, l1llll1l)
elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1ll = os.path.join(os.environ.get(l11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1llll.split(l11 (u"ࠨࠬࠣ࡝"))[0].replace(l11 (u"ࠢࠡࠤ࡞"), l11 (u"ࠣࡡࠥ࡟")).lower())
    l1ll1l1l = l1ll111(l1l1l1ll + l11 (u"ࠤ࠲ࠦࡠ"))
    l1lll1ll = os.path.join(l1ll1l1l, l1llll1l)
else:
    l1lll1ll = os.path.join(l1llll1l)
logger = logging.getLogger(l11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111lll(logger, l1lll1ll)
logger.info(l11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1lll1)
logger.info(l11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1llll)
logger.info(l11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1llll11)
l1l111 = get_major_version(VERSION)
l1ll1l = l1l111l(l1l111, l1llll11)
logger.info(l11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l111)
logger.info(l11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1l)
logger.info(l11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1lll():
    if l1ll111l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1ll1():
    if l1ll111l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lllll1():
    l1ll1l11 = l1ll1lll().read(4)
    while len(l1ll1l11) == 4:
        l1l1l1l1 = struct.unpack(l11 (u"ࠨࡀࡊࠤ࡫"), l1ll1l11)[0]
        request = l1ll1lll().read(l1l1l1l1).decode()
        logger.info(l11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll1l1(request)
        l1l1ll11(response)
        logger.info(l11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l11 = l1ll1lll().read(4)
    logger.info(l11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1ll11(message):
    message = json.dumps(message).encode()
    l1l1ll1l = struct.pack(l11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1ll1().write(l1l1ll1l)
    l1ll1ll1().write(message)
    l1ll1ll1().flush()
def l1lll1l1(request):
    if request:
        l1ll1111 = json.loads(request)
    try:
        return {
            l11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l,
            l11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1111,
            l11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l111
        }[l1ll1111[l11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1111)
    except Exception as e:
        logger.error(l11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l()
def l1l(l1ll1111=None):
    l1ll11ll(l1ll1111)
    l1lll111 = {l11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1()}
    l1lll111[l11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l111ll1(l1ll1l)
    return l1lll111
def l1l1111(l1ll1111):
    url = l1ll1111[l11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l111l = url.split(l11 (u"ࠬࡀࠧࡸ"))[0]
    return {l11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1lll(l111l, url)}
def l11l111(l1ll1111):
    try:
        l111l = l111l1l(l1ll1l)
        url = l11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l111l, l1ll1111[l11 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1111[l11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l111l, url))
        return {l11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1lll(l111l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll11ll(l1ll1111):
    l1lll11l = l11 (u"࠭ࠧࢀ")
    if l1ll1111:
        for name in l1ll1111:
            if name in [l11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll11l += l11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1111[name]
    if l1lll11l: logger.info(l1lll11l[:-1])
def main():
    try:
        l1l11l1()
        l1lllll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()