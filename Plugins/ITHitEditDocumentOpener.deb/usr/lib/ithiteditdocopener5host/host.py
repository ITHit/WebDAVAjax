#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l1l1ll = 2048
l1111 = 7
def l11l (l111ll):
    global l1l111
    l111l1 = ord (l111ll [-1])
    l1111l = l111ll [:-1]
    l11 = l111l1 % len (l1111l)
    l1ll1l = l1111l [:l11] + l1111l [l11:]
    if ll:
        l1l1l1 = l11l1 () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    return eval (l1l1l1)
import json
import struct
from l1ll import *
l1lll1ll = sys.version_info[0] == 2
l1ll11ll = l11l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1ll1 = l11l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠽࠼࠴࠰ࠣࡅ")
l1lllll1 = l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1llll1l = l1ll1ll1.replace(l11l (u"ࠧࠦࠢࡇ"), l11l (u"ࠨ࡟ࠣࡈ")) + l11l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1l1ll = {}
if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lllll = sys.argv[0]
        try:
            l1l1l1ll = l1l111l(l1lllll)
            l1ll1ll1 = l1l1l1ll[l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1l1ll[l11l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lllll1 = l1l1l1ll[l11l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1llll1l = l1ll1ll1.replace(l11l (u"ࠨࠠࠣࡏ"), l11l (u"ࠢࡠࠤࡐ")) + l11l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1l11 = os.path.join(os.environ.get(l11l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1llll1l)
elif platform.system() == l11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1l1 = os.path.join(os.environ.get(l11l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lllll1.split(l11l (u"ࠨࠬࠣࡖ"))[0].replace(l11l (u"ࠢࠡࠤࡗ"), l11l (u"ࠣࡡࠥࡘ")).lower())
    l1lll1l1 = l11111l(l1l1l1l1 + l11l (u"ࠤ࠲࡙ࠦ"))
    l1ll1l11 = os.path.join(l1lll1l1, l1llll1l)
elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1l1 = os.path.join(os.environ.get(l11l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lllll1.split(l11l (u"ࠨࠬࠣ࡝"))[0].replace(l11l (u"ࠢࠡࠤ࡞"), l11l (u"ࠣࡡࠥ࡟")).lower())
    l1lll1l1 = l11111l(l1l1l1l1 + l11l (u"ࠤ࠲ࠦࡠ"))
    l1ll1l11 = os.path.join(l1lll1l1, l1llll1l)
else:
    l1ll1l11 = os.path.join(l1llll1l)
logger = logging.getLogger(l11l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11llll(logger, l1ll1l11)
logger.info(l11l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1ll1)
logger.info(l11l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lllll1)
logger.info(l11l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll11ll)
l1l1l = get_major_version(VERSION)
l1l = l1l1lll(l1l1l, l1ll11ll)
logger.info(l11l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l1l)
logger.info(l11l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l)
logger.info(l11l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1lll1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1llll():
    if l1lll1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll11l1():
    l1l1ll11 = l1lll11l().read(4)
    while len(l1l1ll11) == 4:
        l1ll1lll = struct.unpack(l11l (u"ࠨࡀࡊࠤ࡫"), l1l1ll11)[0]
        request = l1lll11l().read(l1ll1lll).decode()
        logger.info(l11l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll11(request)
        l1lll111(response)
        logger.info(l11l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll11 = l1lll11l().read(4)
    logger.info(l11l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll111(message):
    message = json.dumps(message).encode()
    l1ll1111 = struct.pack(l11l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1llll().write(l1ll1111)
    l1l1llll().write(message)
    l1l1llll().flush()
def l1llll11(request):
    if request:
        l1ll111l = json.loads(request)
    try:
        return {
            l11l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1ll11,
            l11l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l111111,
            l11l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l1l1
        }[l1ll111l[l11l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll111l)
    except Exception as e:
        logger.error(l11l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1ll11()
def l1ll11(l1ll111l=None):
    l1l1lll1(l1ll111l)
    l1l1ll1l = {l11l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11ll1()}
    l1l1ll1l[l11l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11ll11(l1l)
    return l1l1ll1l
def l111111(l1ll111l):
    url = l1ll111l[l11l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1 = url.split(l11l (u"ࠬࡀࠧࡸ"))[0]
    return {l11l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l11l1(l1, url)}
def l11l1l1(l1ll111l):
    try:
        l1 = l1l1l1l(l1l)
        url = l11l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1, l1ll111l[l11l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll111l[l11l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1, url))
        return {l11l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l11l1(l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1lll1(l1ll111l):
    l1ll1l1l = l11l (u"࠭ࠧࢀ")
    if l1ll111l:
        for name in l1ll111l:
            if name in [l11l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l1l += l11l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll111l[name]
    if l1ll1l1l: logger.info(l1ll1l1l[:-1])
def main():
    try:
        l1l1l11()
        l1ll11l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()