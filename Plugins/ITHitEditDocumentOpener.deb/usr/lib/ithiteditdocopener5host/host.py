#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1l1ll = 2048
l1l1l1 = 7
def l1111 (l1ll):
    global l1ll1
    l1l = ord (l1ll [-1])
    l1lll1 = l1ll [:-1]
    l1llll = l1l % len (l1lll1)
    l1 = l1lll1 [:l1llll] + l1lll1 [l1llll:]
    if l111ll:
        l111l = l11l1l () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    else:
        l111l = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    return eval (l111l)
import json
import struct
from l1lll import *
l1l1ll11 = sys.version_info[0] == 2
l1ll1l1l = l1111 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1lll = l1111 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1111 (u"ࠥ࠺࠳࠸࠮࠹࠻࠶࠹࠳࠶ࠢࡅ")
l1ll11ll = l1111 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1111 = l1ll1lll.replace(l1111 (u"ࠧࠦࠢࡇ"), l1111 (u"ࠨ࡟ࠣࡈ")) + l1111 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll111 = {}
if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1111 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1llll1 = sys.argv[0]
        try:
            l1lll111 = l111lll(l1llll1)
            l1ll1lll = l1lll111[l1111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll111[l1111 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll11ll = l1lll111[l1111 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1111 = l1ll1lll.replace(l1111 (u"ࠨࠠࠣࡏ"), l1111 (u"ࠢࡠࠤࡐ")) + l1111 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll11l = os.path.join(os.environ.get(l1111 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1111)
elif platform.system() == l1111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1ll = os.path.join(os.environ.get(l1111 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1111 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll11ll.split(l1111 (u"ࠨࠬࠣࡖ"))[0].replace(l1111 (u"ࠢࠡࠤࡗ"), l1111 (u"ࠣࡡࠥࡘ")).lower())
    l1ll1ll1 = l1l1111(l1l1l1ll + l1111 (u"ࠤ࠲࡙ࠦ"))
    l1lll11l = os.path.join(l1ll1ll1, l1ll1111)
elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1ll = os.path.join(os.environ.get(l1111 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1111 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll11ll.split(l1111 (u"ࠨࠬࠣ࡝"))[0].replace(l1111 (u"ࠢࠡࠤ࡞"), l1111 (u"ࠣࡡࠥ࡟")).lower())
    l1ll1ll1 = l1l1111(l1l1l1ll + l1111 (u"ࠤ࠲ࠦࡠ"))
    l1lll11l = os.path.join(l1ll1ll1, l1ll1111)
else:
    l1lll11l = os.path.join(l1ll1111)
logger = logging.getLogger(l1111 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l1ll1(logger, l1lll11l)
logger.info(l1111 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1111 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1lll)
logger.info(l1111 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1111 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll11ll)
logger.info(l1111 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1l1l)
l111l1 = get_major_version(VERSION)
l11ll1 = l1lll11(l111l1, l1ll1l1l)
logger.info(l1111 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111l1)
logger.info(l1111 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11ll1)
logger.info(l1111 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1111 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1l1l1():
    if l1l1ll11:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll1l():
    if l1l1ll11:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1l1():
    l1ll1l11 = l1l1l1l1().read(4)
    while len(l1ll1l11) == 4:
        l1llll11 = struct.unpack(l1111 (u"ࠨࡀࡊࠤ࡫"), l1ll1l11)[0]
        request = l1l1l1l1().read(l1llll11).decode()
        logger.info(l1111 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11l1(request)
        l1llll1l(response)
        logger.info(l1111 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l11 = l1l1l1l1().read(4)
    logger.info(l1111 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll1l(message):
    message = json.dumps(message).encode()
    l1ll111l = struct.pack(l1111 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll1l().write(l1ll111l)
    l1l1ll1l().write(message)
    l1l1ll1l().flush()
def l1ll11l1(request):
    if request:
        l1lllll1 = json.loads(request)
    try:
        return {
            l1111 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l11,
            l1111 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1ll11l,
            l1111 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1l1l
        }[l1lllll1[l1111 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lllll1)
    except Exception as e:
        logger.error(l1111 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l11()
def l1l11(l1lllll1=None):
    l1l1llll(l1lllll1)
    l1l1lll1 = {l1111 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll11()}
    l1l1lll1[l1111 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l11l1(l11ll1)
    return l1l1lll1
def l1ll11l(l1lllll1):
    url = l1lllll1[l1111 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1l = url.split(l1111 (u"ࠬࡀࠧࡸ"))[0]
    return {l1111 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1ll1l1(l1l1l, url)}
def l1l1l1l(l1lllll1):
    try:
        l1l1l = l11ll1l(l11ll1)
        url = l1111 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1l, l1lllll1[l1111 (u"ࠨࡣࡦࡸࠬࡻ")], l1lllll1[l1111 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1111 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1l, url))
        return {l1111 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1ll1l1(l1l1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1111 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1llll(l1lllll1):
    l1lll1ll = l1111 (u"࠭ࠧࢀ")
    if l1lllll1:
        for name in l1lllll1:
            if name in [l1111 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1111 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll1ll += l1111 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lllll1[name]
    if l1lll1ll: logger.info(l1lll1ll[:-1])
def main():
    try:
        l111l1l()
        l1lll1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1111 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()