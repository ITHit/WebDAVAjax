#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1 = 7
def l11l1l (l11lll):
    global l111ll
    l1lll = ord (l11lll [-1])
    l1l111 = l11lll [:-1]
    l1ll1 = l1lll % len (l1l111)
    l1llll = l1l111 [:l1ll1] + l1l111 [l1ll1:]
    if l11:
        l11l = l111l1 () .join ([unichr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    return eval (l11l)
import json
import struct
from l1l11 import *
l1ll11ll = sys.version_info[0] == 2
l1llll11 = l11l1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll1ll = l11l1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l1l (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠽࠵࠴࠰ࠣࡅ")
l1l1lll1 = l11l1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll111 = l1lll1ll.replace(l11l1l (u"ࠧࠦࠢࡇ"), l11l1l (u"ࠨ࡟ࠣࡈ")) + l11l1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lllll1 = {}
if platform.system() == l11l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11111 = sys.argv[0]
        try:
            l1lllll1 = l1lllll(l11111)
            l1lll1ll = l1lllll1[l11l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lllll1[l11l1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1lll1 = l1lllll1[l11l1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll111 = l1lll1ll.replace(l11l1l (u"ࠨࠠࠣࡏ"), l11l1l (u"ࠢࡠࠤࡐ")) + l11l1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1llll = os.path.join(os.environ.get(l11l1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll111)
elif platform.system() == l11l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lll1l1 = os.path.join(os.environ.get(l11l1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1lll1.split(l11l1l (u"ࠨࠬࠣࡖ"))[0].replace(l11l1l (u"ࠢࠡࠤࡗ"), l11l1l (u"ࠣࡡࠥࡘ")).lower())
    l1ll111l = l11111l(l1lll1l1 + l11l1l (u"ࠤ࠲࡙ࠦ"))
    l1l1llll = os.path.join(l1ll111l, l1lll111)
elif platform.system() == l11l1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lll1l1 = os.path.join(os.environ.get(l11l1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1lll1.split(l11l1l (u"ࠨࠬࠣ࡝"))[0].replace(l11l1l (u"ࠢࠡࠤ࡞"), l11l1l (u"ࠣࡡࠥ࡟")).lower())
    l1ll111l = l11111l(l1lll1l1 + l11l1l (u"ࠤ࠲ࠦࡠ"))
    l1l1llll = os.path.join(l1ll111l, l1lll111)
else:
    l1l1llll = os.path.join(l1lll111)
logger = logging.getLogger(l11l1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11llll(logger, l1l1llll)
logger.info(l11l1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll1ll)
logger.info(l11l1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1lll1)
logger.info(l11l1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1llll11)
l1111 = get_major_version(VERSION)
l111l = l1l1l1l(l1111, l1llll11)
logger.info(l11l1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111)
logger.info(l11l1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111l)
logger.info(l11l1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1lll():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll11():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1l1l1():
    l1ll1l11 = l1ll1lll().read(4)
    while len(l1ll1l11) == 4:
        l1l1ll1l = struct.unpack(l11l1l (u"ࠨࡀࡊࠤ࡫"), l1ll1l11)[0]
        request = l1ll1lll().read(l1l1ll1l).decode()
        logger.info(l11l1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1l1l(request)
        l1ll1111(response)
        logger.info(l11l1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l11 = l1ll1lll().read(4)
    logger.info(l11l1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1111(message):
    message = json.dumps(message).encode()
    l1l1l1ll = struct.pack(l11l1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll11().write(l1l1l1ll)
    l1l1ll11().write(message)
    l1l1ll11().flush()
def l1ll1l1l(request):
    if request:
        l1ll11l1 = json.loads(request)
    try:
        return {
            l11l1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1,
            l11l1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1ll1,
            l11l1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lll11
        }[l1ll11l1[l11l1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll11l1)
    except Exception as e:
        logger.error(l11l1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1()
def l1(l1ll11l1=None):
    l1llll1l(l1ll11l1)
    l1ll1ll1 = {l11l1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l11()}
    l1ll1ll1[l11l1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1l1(l111l)
    return l1ll1ll1
def l1l1ll1(l1ll11l1):
    url = l1ll11l1[l11l1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1ll = url.split(l11l1l (u"ࠬࡀࠧࡸ"))[0]
    return {l11l1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l11l(l1l1ll, url)}
def l1lll11(l1ll11l1):
    try:
        l1l1ll = l1ll11l(l111l)
        url = l11l1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1ll, l1ll11l1[l11l1l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll11l1[l11l1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1ll, url))
        return {l11l1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l11l(l1l1ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll1l(l1ll11l1):
    l1lll11l = l11l1l (u"࠭ࠧࢀ")
    if l1ll11l1:
        for name in l1ll11l1:
            if name in [l11l1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll11l += l11l1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll11l1[name]
    if l1lll11l: logger.info(l1lll11l[:-1])
def main():
    try:
        l1l11l1()
        l1l1l1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()