#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l1l1ll (l1ll):
    global l111l1
    l11l11 = ord (l1ll [-1])
    l11l1 = l1ll [:-1]
    l1l11 = l11l11 % len (l11l1)
    l111l = l11l1 [:l1l11] + l11l1 [l1l11:]
    if l1l1l:
        l1l11l = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    return eval (l1l11l)
import json
import struct
from l1l import *
l1l1lll1 = sys.version_info[0] == 2
l1llll1l = l1l1ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = l1l1ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠺࠶࠴࠰ࠣࡅ")
l1llll11 = l1l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1l1ll = l1ll1l1l.replace(l1l1ll (u"ࠧࠦࠢࡇ"), l1l1ll (u"ࠨ࡟ࠣࡈ")) + l1l1ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l1l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11l1l1 = sys.argv[0]
        try:
            l1ll1l11 = l1ll111(l11l1l1)
            l1ll1l1l = l1ll1l11[l1l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l1l1ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1llll11 = l1ll1l11[l1l1ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1l1ll = l1ll1l1l.replace(l1l1ll (u"ࠨࠠࠣࡏ"), l1l1ll (u"ࠢࡠࠤࡐ")) + l1l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1111 = os.path.join(os.environ.get(l1l1ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1l1ll)
elif platform.system() == l1l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l1ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1llll11.split(l1l1ll (u"ࠨࠬࠣࡖ"))[0].replace(l1l1ll (u"ࠢࠡࠤࡗ"), l1l1ll (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l1l1ll1(l1ll1ll1 + l1l1ll (u"ࠤ࠲࡙ࠦ"))
    l1ll1111 = os.path.join(l1l1llll, l1l1l1ll)
elif platform.system() == l1l1ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l1ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1llll11.split(l1l1ll (u"ࠨࠬࠣ࡝"))[0].replace(l1l1ll (u"ࠢࠡࠤ࡞"), l1l1ll (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l1l1ll1(l1ll1ll1 + l1l1ll (u"ࠤ࠲ࠦࡠ"))
    l1ll1111 = os.path.join(l1l1llll, l1l1l1ll)
else:
    l1ll1111 = os.path.join(l1l1l1ll)
logger = logging.getLogger(l1l1ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll11l(logger, l1ll1111)
logger.info(l1l1ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(l1l1ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1llll11)
logger.info(l1l1ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1llll1l)
l1l1l1 = get_major_version(VERSION)
l1l111 = l111111(l1l1l1, l1llll1l)
logger.info(l1l1ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l1l1)
logger.info(l1l1ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l111)
logger.info(l1l1ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll11l1():
    if l1l1lll1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1ll():
    if l1l1lll1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll11l():
    l1ll111l = l1ll11l1().read(4)
    while len(l1ll111l) == 4:
        l1lll111 = struct.unpack(l1l1ll (u"ࠨࡀࡊࠤ࡫"), l1ll111l)[0]
        request = l1ll11l1().read(l1lll111).decode()
        logger.info(l1l1ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11ll(request)
        l1l1ll1l(response)
        logger.info(l1l1ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll111l = l1ll11l1().read(4)
    logger.info(l1l1ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1ll1l(message):
    message = json.dumps(message).encode()
    l1l1ll11 = struct.pack(l1l1ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1ll().write(l1l1ll11)
    l1lll1ll().write(message)
    l1lll1ll().flush()
def l1ll11ll(request):
    if request:
        l1l1l1l1 = json.loads(request)
    try:
        return {
            l1l1ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11ll,
            l1l1ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lll1l,
            l1l1ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l11l
        }[l1l1l1l1[l1l1ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1l1)
    except Exception as e:
        logger.error(l1l1ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11ll()
def l11ll(l1l1l1l1=None):
    l1ll1lll(l1l1l1l1)
    l1lll1l1 = {l1l1ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1()}
    l1lll1l1[l1l1ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll1l1(l1l111)
    return l1lll1l1
def l1lll1l(l1l1l1l1):
    url = l1l1l1l1[l1l1ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11 = url.split(l1l1ll (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1111ll(l11, url)}
def l11l11l(l1l1l1l1):
    try:
        l11 = l11lll1(l1l111)
        url = l1l1ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11, l1l1l1l1[l1l1ll (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1l1[l1l1ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11, url))
        return {l1l1ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1111ll(l11, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1lll(l1l1l1l1):
    l1lllll1 = l1l1ll (u"࠭ࠧࢀ")
    if l1l1l1l1:
        for name in l1l1l1l1:
            if name in [l1l1ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lllll1 += l1l1ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1l1[name]
    if l1lllll1: logger.info(l1lllll1[:-1])
def main():
    try:
        l1ll1ll()
        l1lll11l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()