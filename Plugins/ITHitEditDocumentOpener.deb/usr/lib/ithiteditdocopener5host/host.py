#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll1 = 7
def l1llll (l11ll1):
    global ll
    l1l11l = ord (l11ll1 [-1])
    l1l1ll = l11ll1 [:-1]
    l11 = l1l11l % len (l1l1ll)
    l1 = l1l1ll [:l11] + l1l1ll [l11:]
    if l11l11:
        l111ll = l11l1 () .join ([unichr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    else:
        l111ll = str () .join ([chr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    return eval (l111ll)
import json
import struct
from l1111l import *
l1ll111l = sys.version_info[0] == 2
l1lll1ll = l1llll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1lll1 = l1llll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1llll (u"ࠥ࠺࠳࠶࠮࠹࠹࠸࠶࠳࠶ࠢࡅ")
l1ll1l1l = l1llll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1llll1l = l1l1lll1.replace(l1llll (u"ࠧࠦࠢࡇ"), l1llll (u"ࠨ࡟ࠣࡈ")) + l1llll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll11l = {}
if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1llll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll111 = sys.argv[0]
        try:
            l1lll11l = l11111(l1ll111)
            l1l1lll1 = l1lll11l[l1llll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll11l[l1llll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l1l = l1lll11l[l1llll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1llll1l = l1l1lll1.replace(l1llll (u"ࠨࠠࠣࡏ"), l1llll (u"ࠢࡠࠤࡐ")) + l1llll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1l1 = os.path.join(os.environ.get(l1llll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1llll1l)
elif platform.system() == l1llll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll1l = os.path.join(os.environ.get(l1llll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1llll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l1l.split(l1llll (u"ࠨࠬࠣࡖ"))[0].replace(l1llll (u"ࠢࠡࠤࡗ"), l1llll (u"ࠣࡡࠥࡘ")).lower())
    l1lllll1 = l1111ll(l1l1ll1l + l1llll (u"ࠤ࠲࡙ࠦ"))
    l1l1l1l1 = os.path.join(l1lllll1, l1llll1l)
elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll1l = os.path.join(os.environ.get(l1llll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1llll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l1l.split(l1llll (u"ࠨࠬࠣ࡝"))[0].replace(l1llll (u"ࠢࠡࠤ࡞"), l1llll (u"ࠣࡡࠥ࡟")).lower())
    l1lllll1 = l1111ll(l1l1ll1l + l1llll (u"ࠤ࠲ࠦࡠ"))
    l1l1l1l1 = os.path.join(l1lllll1, l1llll1l)
else:
    l1l1l1l1 = os.path.join(l1llll1l)
logger = logging.getLogger(l1llll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111ll1(logger, l1l1l1l1)
logger.info(l1llll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1llll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1lll1)
logger.info(l1llll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1llll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l1l)
logger.info(l1llll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll1ll)
l111 = get_major_version(VERSION)
l1lll = l11111l(l111, l1lll1ll)
logger.info(l1llll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111)
logger.info(l1llll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll)
logger.info(l1llll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1llll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll11l1():
    if l1ll111l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1l1():
    if l1ll111l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll11ll():
    l1ll1lll = l1ll11l1().read(4)
    while len(l1ll1lll) == 4:
        l1l1ll11 = struct.unpack(l1llll (u"ࠨࡀࡊࠤ࡫"), l1ll1lll)[0]
        request = l1ll11l1().read(l1l1ll11).decode()
        logger.info(l1llll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1111(request)
        l1llll11(response)
        logger.info(l1llll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1lll = l1ll11l1().read(4)
    logger.info(l1llll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll11(message):
    message = json.dumps(message).encode()
    l1l1l1ll = struct.pack(l1llll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1l1().write(l1l1l1ll)
    l1lll1l1().write(message)
    l1lll1l1().flush()
def l1ll1111(request):
    if request:
        l1ll1ll1 = json.loads(request)
    try:
        return {
            l1llll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l1l1,
            l1llll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l1ll,
            l1llll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1111
        }[l1ll1ll1[l1llll (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1ll1)
    except Exception as e:
        logger.error(l1llll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l1l1()
def l1l1l1(l1ll1ll1=None):
    l1lll111(l1ll1ll1)
    l1l1llll = {l1llll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11lll()}
    l1l1llll[l1llll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1lll11(l1lll)
    return l1l1llll
def l11l1ll(l1ll1ll1):
    url = l1ll1ll1[l1llll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l = url.split(l1llll (u"ࠬࡀࠧࡸ"))[0]
    return {l1llll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l111(l11l, url)}
def l1l1111(l1ll1ll1):
    try:
        l11l = l1lllll(l1lll)
        url = l1llll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l, l1ll1ll1[l1llll (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1ll1[l1llll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1llll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l, url))
        return {l1llll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l111(l11l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1llll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll111(l1ll1ll1):
    l1ll1l11 = l1llll (u"࠭ࠧࢀ")
    if l1ll1ll1:
        for name in l1ll1ll1:
            if name in [l1llll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1llll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l11 += l1llll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1ll1[name]
    if l1ll1l11: logger.info(l1ll1l11[:-1])
def main():
    try:
        l1l11l1()
        l1ll11ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1llll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()