#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1111l = 2048
l1ll = 7
def l1l11l (l1):
    global l11l11
    l111l1 = ord (l1 [-1])
    l1llll = l1 [:-1]
    l1ll11 = l111l1 % len (l1llll)
    l1l1ll = l1llll [:l1ll11] + l1llll [l1ll11:]
    if l111ll:
        l11l1 = l1l () .join ([unichr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    return eval (l11l1)
import json
import struct
from l111l import *
l1ll1111 = sys.version_info[0] == 2
l1ll1lll = l1l11l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1llll = l1l11l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l11l (u"ࠥ࠺࠳࠶࠮࠹࠹࠹࠶࠳࠶ࠢࡅ")
l1l1l1ll = l1l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1l1llll.replace(l1l11l (u"ࠧࠦࠢࡇ"), l1l11l (u"ࠨ࡟ࠣࡈ")) + l1l11l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1ll1 = {}
if platform.system() == l1l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l11l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll1ll = sys.argv[0]
        try:
            l1ll1ll1 = l11l11l(l1ll1ll)
            l1l1llll = l1ll1ll1[l1l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1ll1[l1l11l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1l1ll = l1ll1ll1[l1l11l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1l1llll.replace(l1l11l (u"ࠨࠠࠣࡏ"), l1l11l (u"ࠢࡠࠤࡐ")) + l1l11l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll11l = os.path.join(os.environ.get(l1l11l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l1l11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l1l = os.path.join(os.environ.get(l1l11l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l11l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1l1ll.split(l1l11l (u"ࠨࠬࠣࡖ"))[0].replace(l1l11l (u"ࠢࠡࠤࡗ"), l1l11l (u"ࠣࡡࠥࡘ")).lower())
    l1lll1ll = l11111(l1ll1l1l + l1l11l (u"ࠤ࠲࡙ࠦ"))
    l1lll11l = os.path.join(l1lll1ll, l1ll11ll)
elif platform.system() == l1l11l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l1l = os.path.join(os.environ.get(l1l11l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l11l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1l1ll.split(l1l11l (u"ࠨࠬࠣ࡝"))[0].replace(l1l11l (u"ࠢࠡࠤ࡞"), l1l11l (u"ࠣࡡࠥ࡟")).lower())
    l1lll1ll = l11111(l1ll1l1l + l1l11l (u"ࠤ࠲ࠦࡠ"))
    l1lll11l = os.path.join(l1lll1ll, l1ll11ll)
else:
    l1lll11l = os.path.join(l1ll11ll)
logger = logging.getLogger(l1l11l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l1111(logger, l1lll11l)
logger.info(l1l11l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l11l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1llll)
logger.info(l1l11l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l11l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1l1ll)
logger.info(l1l11l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1lll)
l1lll1 = get_major_version(VERSION)
l1l111 = l1ll11l(l1lll1, l1ll1lll)
logger.info(l1l11l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1lll1)
logger.info(l1l11l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l111)
logger.info(l1l11l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l11l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll11l1():
    if l1ll1111:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1l1():
    if l1ll1111:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lllll1():
    l1llll11 = l1ll11l1().read(4)
    while len(l1llll11) == 4:
        l1l1ll11 = struct.unpack(l1l11l (u"ࠨࡀࡊࠤ࡫"), l1llll11)[0]
        request = l1ll11l1().read(l1l1ll11).decode()
        logger.info(l1l11l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll1l1(request)
        l1l1lll1(response)
        logger.info(l1l11l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1llll11 = l1ll11l1().read(4)
    logger.info(l1l11l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1lll1(message):
    message = json.dumps(message).encode()
    l1lll111 = struct.pack(l1l11l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1l1().write(l1lll111)
    l1l1l1l1().write(message)
    l1l1l1l1().flush()
def l1lll1l1(request):
    if request:
        l1ll111l = json.loads(request)
    try:
        return {
            l1l11l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l11,
            l1l11l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l111,
            l1l11l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll1l1
        }[l1ll111l[l1l11l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll111l)
    except Exception as e:
        logger.error(l1l11l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l11()
def l1l11(l1ll111l=None):
    l1llll1l(l1ll111l)
    l1ll1l11 = {l1l11l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l1l1()}
    l1ll1l11[l1l11l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1lll(l1l111)
    return l1ll1l11
def l11l111(l1ll111l):
    url = l1ll111l[l1l11l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11ll = url.split(l1l11l (u"ࠬࡀࠧࡸ"))[0]
    return {l1l11l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11111l(l11ll, url)}
def l1ll1l1(l1ll111l):
    try:
        l11ll = l11ll1l(l1l111)
        url = l1l11l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11ll, l1ll111l[l1l11l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll111l[l1l11l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l11l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11ll, url))
        return {l1l11l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11111l(l11ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l11l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll1l(l1ll111l):
    l1l1ll1l = l1l11l (u"࠭ࠧࢀ")
    if l1ll111l:
        for name in l1ll111l:
            if name in [l1l11l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l11l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1ll1l += l1l11l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll111l[name]
    if l1l1ll1l: logger.info(l1l1ll1l[:-1])
def main():
    try:
        l1llll1()
        l1lllll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()