#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11ll = 2048
l1llll = 7
def l1ll11 (l1l1):
    global l1ll1
    l11l1 = ord (l1l1 [-1])
    l1l = l1l1 [:-1]
    l111 = l11l1 % len (l1l)
    l11lll = l1l [:l111] + l1l [l111:]
    if l111l:
        l1l111 = l11l11 () .join ([unichr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    return eval (l1l111)
import json
import struct
from l1111l import *
l1lllll1 = sys.version_info[0] == 2
l1ll1ll1 = l1ll11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll111l = l1ll11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll11 (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠸࠷࠴࠰ࠣࡅ")
l1l1ll11 = l1ll11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1l11 = l1ll111l.replace(l1ll11 (u"ࠧࠦࠢࡇ"), l1ll11 (u"ࠨ࡟ࠣࡈ")) + l1ll11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1lll1 = {}
if platform.system() == l1ll11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111ll1 = sys.argv[0]
        try:
            l1l1lll1 = l1llll1(l111ll1)
            l1ll111l = l1l1lll1[l1ll11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1lll1[l1ll11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll11 = l1l1lll1[l1ll11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1l11 = l1ll111l.replace(l1ll11 (u"ࠨࠠࠣࡏ"), l1ll11 (u"ࠢࡠࠤࡐ")) + l1ll11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll11ll = os.path.join(os.environ.get(l1ll11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1l11)
elif platform.system() == l1ll11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1lll = os.path.join(os.environ.get(l1ll11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll11.split(l1ll11 (u"ࠨࠬࠣࡖ"))[0].replace(l1ll11 (u"ࠢࠡࠤࡗ"), l1ll11 (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l1lllll(l1ll1lll + l1ll11 (u"ࠤ࠲࡙ࠦ"))
    l1ll11ll = os.path.join(l1l1llll, l1ll1l11)
elif platform.system() == l1ll11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1lll = os.path.join(os.environ.get(l1ll11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll11.split(l1ll11 (u"ࠨࠬࠣ࡝"))[0].replace(l1ll11 (u"ࠢࠡࠤ࡞"), l1ll11 (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l1lllll(l1ll1lll + l1ll11 (u"ࠤ࠲ࠦࡠ"))
    l1ll11ll = os.path.join(l1l1llll, l1ll1l11)
else:
    l1ll11ll = os.path.join(l1ll1l11)
logger = logging.getLogger(l1ll11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l1111(logger, l1ll11ll)
logger.info(l1ll11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll111l)
logger.info(l1ll11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll11)
logger.info(l1ll11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1ll1)
l1lll1 = get_major_version(VERSION)
l1l1l = l1ll1l1(l1lll1, l1ll1ll1)
logger.info(l1ll11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1lll1)
logger.info(l1ll11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l1l)
logger.info(l1ll11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1llll11():
    if l1lllll1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1ll():
    if l1lllll1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll11l():
    l1l1ll1l = l1llll11().read(4)
    while len(l1l1ll1l) == 4:
        l1ll1l1l = struct.unpack(l1ll11 (u"ࠨࡀࡊࠤ࡫"), l1l1ll1l)[0]
        request = l1llll11().read(l1ll1l1l).decode()
        logger.info(l1ll11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11l1(request)
        l1lll1l1(response)
        logger.info(l1ll11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll1l = l1llll11().read(4)
    logger.info(l1ll11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1l1(message):
    message = json.dumps(message).encode()
    l1lll111 = struct.pack(l1ll11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1ll().write(l1lll111)
    l1l1l1ll().write(message)
    l1l1l1ll().flush()
def l1ll11l1(request):
    if request:
        l1lll1ll = json.loads(request)
    try:
        return {
            l1ll11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l11,
            l1ll11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lll1l,
            l1ll11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11111l
        }[l1lll1ll[l1ll11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll1ll)
    except Exception as e:
        logger.error(l1ll11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l11()
def l1l11(l1lll1ll=None):
    l1ll1111(l1lll1ll)
    l1llll1l = {l1ll11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1l()}
    l1llll1l[l1ll11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11ll11(l1l1l)
    return l1llll1l
def l1lll1l(l1lll1ll):
    url = l1lll1ll[l1ll11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l111l1 = url.split(l1ll11 (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111l11(l111l1, url)}
def l11111l(l1lll1ll):
    try:
        l111l1 = l1ll11l(l1l1l)
        url = l1ll11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l111l1, l1lll1ll[l1ll11 (u"ࠨࡣࡦࡸࠬࡻ")], l1lll1ll[l1ll11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l111l1, url))
        return {l1ll11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111l11(l111l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1111(l1lll1ll):
    l1l1l1l1 = l1ll11 (u"࠭ࠧࢀ")
    if l1lll1ll:
        for name in l1lll1ll:
            if name in [l1ll11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1l1 += l1ll11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll1ll[name]
    if l1l1l1l1: logger.info(l1l1l1l1[:-1])
def main():
    try:
        l1l11l1()
        l1lll11l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()