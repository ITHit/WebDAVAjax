#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def ll (l111):
    global l111ll
    l1111l = ord (l111 [-1])
    l11ll1 = l111 [:-1]
    l1ll = l1111l % len (l11ll1)
    l1l11 = l11ll1 [:l1ll] + l11ll1 [l1ll:]
    if l1llll:
        l11ll = l1l () .join ([unichr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    return eval (l11ll)
import json
import struct
from l111l import *
reload(sys)
sys.l1ll111l(ll (u"ࠨࡷࡷࡪ࠽࠭ࡃ"))
l1ll1lll = sys.version_info[0] == 2
l1lll11l = ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠦࡄ")
l1lllll1 = ll (u"ࠥࡍ࡙ࠦࡈࡪࡶࠣࡉࡩ࡯ࡴࠡࡆࡲࡧࠥࡕࡰࡦࡰࡨࡶࠥ࠻ࠠࡉࡱࡶࡸࠧࡅ")
VERSION = ll (u"ࠦ࠺࠴࠲࠱࠰࠸࠻࠸࠸࠮࠱ࠤࡆ")
l1ll1l1l = ll (u"ࠧࡏࡔࠡࡊ࡬ࡸ࠱ࠦࡌࡵࡦࠥࡇ")
l1l1lll1 = l1lllll1.replace(ll (u"ࠨࠠࠣࡈ"), ll (u"ࠢࡠࠤࡉ")) + ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡊ")
l1llll11 = {}
if platform.system() == ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࡋ"):
    if hasattr(sys, ll (u"ࠪࡪࡷࡵࡺࡦࡰࠪࡌ")):
        l1llll1 = sys.argv[0]
        try:
            l1llll11 = l11ll11(l1llll1)
            l1lllll1 = l1llll11[ll (u"ࠫࡕࡸ࡯ࡥࡷࡦࡸࡓࡧ࡭ࡦࠩࡍ")]
            VERSION = l1llll11[ll (u"ࠧࡌࡩ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࡎ")]
            l1ll1l1l = l1llll11[ll (u"ࠨࡃࡰ࡯ࡳࡥࡳࡿࡎࡢ࡯ࡨࠦࡏ")]
        except:
            pass
    l1l1lll1 = l1lllll1.replace(ll (u"ࠢࠡࠤࡐ"), ll (u"ࠣࡡࠥࡑ")) + ll (u"ࠤ࠱ࡰࡴ࡭ࠢࡒ")
    l1lll1l1 = os.path.join(os.environ.get(ll (u"ࠪࡘࡊࡓࡐࠨࡓ")), l1l1lll1)
elif platform.system() == ll (u"ࠦࡑ࡯࡮ࡶࡺࠥࡔ"):
    l1lll111 = os.path.join(os.environ.get(ll (u"ࠬࡎࡏࡎࡇࠪࡕ")), ll (u"ࠨ࠮ࠦࡵࠥࡖ") % l1ll1l1l.split(ll (u"ࠢ࠭ࠤࡗ"))[0].replace(ll (u"ࠣࠢࠥࡘ"), ll (u"ࠤࡢ࡙ࠦ")).lower())
    l1lll1ll = l11ll1l(l1lll111 + ll (u"ࠥ࠳࡚ࠧ"))
    l1lll1l1 = os.path.join(l1lll1ll, l1l1lll1)
elif platform.system() == ll (u"ࠦࡉࡧࡲࡸ࡫ࡱ࡛ࠦ"):
    l1lll111 = os.path.join(os.environ.get(ll (u"ࠬࡎࡏࡎࡇࠪ࡜")), ll (u"ࠨ࠮ࠦࡵࠥ࡝") % l1ll1l1l.split(ll (u"ࠢ࠭ࠤ࡞"))[0].replace(ll (u"ࠣࠢࠥ࡟"), ll (u"ࠤࡢࠦࡠ")).lower())
    l1lll1ll = l11ll1l(l1lll111 + ll (u"ࠥ࠳ࠧࡡ"))
    l1lll1l1 = os.path.join(l1lll1ll, l1l1lll1)
else:
    l1lll1l1 = os.path.join(l1l1lll1)
logger = logging.getLogger(ll (u"ࠦࡳࡧࡴࡪࡸࡨࡣ࡭ࡵࡳࡵࠤࡢ"))
l1ll1ll(logger, l1lll1l1)
logger.info(ll (u"ࠧࡖࡲࡰࡦࡸࡧࡹࠦࡉ࡯ࡨࡲ࠾ࠧࡣ"))
logger.info(ll (u"ࠨ࡜ࡵࡃࡳࡴࠥࡔࡡ࡮ࡧ࠽ࠤࠪࡹࠢࡤ") % l1lllll1)
logger.info(ll (u"ࠢ࡝ࡶ࡙ࡩࡷࡹࡩࡰࡰ࠽ࠤࠪࡹࠢࡥ") % VERSION)
logger.info(ll (u"ࠣ࡞ࡷࡇࡴࡳࡰࡢࡰࡼࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡦ") % l1ll1l1l)
logger.info(ll (u"ࠤ࡟ࡸࡔࡶࡥ࡯ࡧࡵࠤࡒࡧࡳ࡬࠼ࠣࠩࡸࠨࡧ") % l1lll11l)
l11l11 = get_major_version(VERSION)
l111l1 = l111l11(l11l11, l1lll11l)
logger.info(ll (u"ࠥࡠࡹࡓࡡ࡫ࡱࡵࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠥࡴࠤࡨ") % l11l11)
logger.info(ll (u"ࠦࡡࡺࡐࡳࡱࡷࡳࡨࡵ࡬ࠡࡐࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࡩ") % l111l1)
logger.info(ll (u"ࠬࡢࡴࡐࡕ࠽ࠤࠪࡹࠧࡪ") % platform.platform())
logger.info(ll (u"࠭࡜ࡵࡒࡼࡸ࡭ࡵ࡮࠻ࠢࠨࡷࠬ࡫") % sys.version)
def l1ll11l1():
    if l1ll1lll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1l1():
    if l1ll1lll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1ll11():
    l1ll1111 = l1ll11l1().read(4)
    while len(l1ll1111) == 4:
        l1ll1ll1 = struct.unpack(ll (u"ࠢࡁࡋࠥ࡬"), l1ll1111)[0]
        request = l1ll11l1().read(l1ll1ll1).decode()
        logger.info(ll (u"ࠣࡉࡲࡸࠥࡸࡥࡲࡷࡨࡷࡹࠦ࠺ࡼ࠲ࢀࠦ࡭").format(request))
        response = l1ll11ll(request)
        l1l1llll(response)
        logger.info(ll (u"ࠤࡖࡩࡳࡺࠠࡳࡧࡶࡴࡴࡴࡳࡦࠢ࠽ࡿ࠵ࢃࠢ࡮").format(response))
        l1ll1111 = l1ll11l1().read(4)
    logger.info(ll (u"ࠪࡉࡽ࡯ࡴࡪࡰࡪࠥࠬ࡯"))
def l1l1llll(message):
    message = json.dumps(message).encode()
    l1llll1l = struct.pack(ll (u"ࠦࡅࡏࠢࡰ"), len(message))
    l1l1l1l1().write(l1llll1l)
    l1l1l1l1().write(message)
    l1l1l1l1().flush()
def l1ll11ll(request):
    if request:
        l1l1l11l = json.loads(request)
    try:
        return {
            ll (u"ࠬ࡭ࡥࡵࡡࡳࡶࡴࡺ࡯ࡤࡱ࡯ࡷࠬࡱ"): l1111,
            ll (u"࠭࡯ࡱࡧࡱࡣࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࡲ"): l111111,
            ll (u"ࠧࡪࡰ࡬ࡸࡤࡧ࡮ࡰࡰࠪࡳ"): l11l11l
        }[l1l1l11l[ll (u"ࠣࡣࡦࡸࠧࡴ")]](l1l1l11l)
    except Exception as e:
        logger.error(ll (u"ࠩࡶࡻ࡮ࡺࡣࡩࡡࡤࡧࡹ࡯࡯࡯ࡵࠣࡩࡷࡸ࡯ࡳ࠼ࠣࠫࡵ") + str(e))
        return l1111()
def l1111(l1l1l11l=None):
    l1l1l1ll(l1l1l11l)
    l1ll1l11 = {ll (u"ࠪࡷࡺࡶࡰࡰࡴࡷࡩࡩ࡙ࡣࡩࡧࡰࡩࡸ࠭ࡶ"): l11()}
    l1ll1l11[ll (u"ࠦࡵࡸ࡯ࡵࡱࡦࡳࡱࡹࠢࡷ")] = l111l1l(l111l1)
    return l1ll1l11
def l111111(l1l1l11l):
    url = l1l1l11l[ll (u"ࠧࡻࡲ࡭ࠤࡸ")]
    l1ll11 = url.split(ll (u"࠭࠺ࠨࡹ"))[0]
    return {ll (u"ࠧࡤ࡯ࡧࡣࡷ࡫ࡳࡶ࡮ࡷࠫࡺ"): l1l11l1(l1ll11, url)}
def l11l11l(l1l1l11l):
    try:
        l1ll11 = l1llllll(l111l1)
        url = ll (u"ࡳࠩࠨࡷ࠿ࡧࡣࡵ࠿ࠨࡷࡀࡏࡴࡦ࡯ࡘࡶࡱࡃࡎࡐࡐࡈ࠿ࠪࡹࠧࡻ") % (l1ll11, l1l1l11l[ll (u"ࠩࡤࡧࡹ࠭ࡼ")], l1l1l11l[ll (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪࡽ")])
        logger.debug(ll (u"ࠦࡷࡻ࡮ࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࠫࠫࠪࡹࠧ࠭ࠢࠪࠩࡸ࠭ࠩࠣࡾ") % (l1ll11, url))
        return {ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): l1l11l1(l1ll11, url)}
    except Exception as e:
        logger.error(str(e))
        return {ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࢀ"): str(e)}
def l1l1l1ll(l1l1l11l):
    l1l1ll1l = ll (u"ࠧࠨࢁ")
    if l1l1l11l:
        for name in l1l1l11l:
            if name in [ll (u"ࠨࡤࡢࡲࡦࡳࡥࠨࢂ"),ll (u"ࠩࡥࡣࡻ࡫ࡲࠨࢃ")]:
                l1l1ll1l += ll (u"ࠪࠩࡸࠦࠧࢄ") % l1l1l11l[name]
    if l1l1ll1l: logger.info(l1l1ll1l[:-1])
def main():
    try:
        l11111l()
        l1l1ll11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨࢅ"):
    main()