#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111l1 = 2048
l11ll = 7
def l11 (ll):
    global l1
    l1ll11 = ord (ll [-1])
    l1lll = ll [:-1]
    l1l11 = l1ll11 % len (l1lll)
    l11l1l = l1lll [:l1l11] + l1lll [l1l11:]
    if l1ll1l:
        l1l1ll = l1llll () .join ([unichr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111l1 - (l111ll + l1ll11) % l11ll) for l111ll, char in enumerate (l11l1l)])
    return eval (l1l1ll)
import json
import struct
from l1lll1 import *
l1ll1l1l = sys.version_info[0] == 2
l1lll111 = l11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lllll1 = l11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11 (u"ࠥ࠺࠳࠶࠮࠹࠹࠸࠹࠳࠶ࠢࡅ")
l1llll11 = l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1lllll1.replace(l11 (u"ࠧࠦࠢࡇ"), l11 (u"ࠨ࡟ࠣࡈ")) + l11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1ll1 = {}
if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111111 = sys.argv[0]
        try:
            l1ll1ll1 = l11llll(l111111)
            l1lllll1 = l1ll1ll1[l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1ll1[l11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1llll11 = l1ll1ll1[l11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1lllll1.replace(l11 (u"ࠨࠠࠣࡏ"), l11 (u"ࠢࡠࠤࡐ")) + l11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll11 = os.path.join(os.environ.get(l11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1llll1l = os.path.join(os.environ.get(l11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1llll11.split(l11 (u"ࠨࠬࠣࡖ"))[0].replace(l11 (u"ࠢࠡࠤࡗ"), l11 (u"ࠣࡡࠥࡘ")).lower())
    l1l1l1ll = l11l11l(l1llll1l + l11 (u"ࠤ࠲࡙ࠦ"))
    l1l1ll11 = os.path.join(l1l1l1ll, l1ll11ll)
elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1llll1l = os.path.join(os.environ.get(l11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1llll11.split(l11 (u"ࠨࠬࠣ࡝"))[0].replace(l11 (u"ࠢࠡࠤ࡞"), l11 (u"ࠣࡡࠥ࡟")).lower())
    l1l1l1ll = l11l11l(l1llll1l + l11 (u"ࠤ࠲ࠦࡠ"))
    l1l1ll11 = os.path.join(l1l1l1ll, l1ll11ll)
else:
    l1l1ll11 = os.path.join(l1ll11ll)
logger = logging.getLogger(l11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l11ll(logger, l1l1ll11)
logger.info(l11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lllll1)
logger.info(l11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1llll11)
logger.info(l11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll111)
l1111 = get_major_version(VERSION)
l11l11 = l1l1l11(l1111, l1lll111)
logger.info(l11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111)
logger.info(l11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11l11)
logger.info(l11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1lll():
    if l1ll1l1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll1l():
    if l1ll1l1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1111():
    l1lll1ll = l1ll1lll().read(4)
    while len(l1lll1ll) == 4:
        l1ll111l = struct.unpack(l11 (u"ࠨࡀࡊࠤ࡫"), l1lll1ll)[0]
        request = l1ll1lll().read(l1ll111l).decode()
        logger.info(l11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1l11(request)
        l1lll11l(response)
        logger.info(l11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1ll = l1ll1lll().read(4)
    logger.info(l11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll11l(message):
    message = json.dumps(message).encode()
    l1ll11l1 = struct.pack(l11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll1l().write(l1ll11l1)
    l1l1ll1l().write(message)
    l1l1ll1l().flush()
def l1ll1l11(request):
    if request:
        l1l1llll = json.loads(request)
    try:
        return {
            l11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l,
            l11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1llll1,
            l11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1ll11l
        }[l1l1llll[l11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1llll)
    except Exception as e:
        logger.error(l11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l()
def l11l(l1l1llll=None):
    l1lll1l1(l1l1llll)
    l1l1lll1 = {l11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111()}
    l1l1lll1[l11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll1l1(l11l11)
    return l1l1lll1
def l1llll1(l1l1llll):
    url = l1l1llll[l11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1111l = url.split(l11 (u"ࠬࡀࠧࡸ"))[0]
    return {l11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11ll11(l1111l, url)}
def l1ll11l(l1l1llll):
    try:
        l1111l = l1l1111(l11l11)
        url = l11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1111l, l1l1llll[l11 (u"ࠨࡣࡦࡸࠬࡻ")], l1l1llll[l11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1111l, url))
        return {l11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11ll11(l1111l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll1l1(l1l1llll):
    l1l1l1l1 = l11 (u"࠭ࠧࢀ")
    if l1l1llll:
        for name in l1l1llll:
            if name in [l11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1l1 += l11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1llll[name]
    if l1l1l1l1: logger.info(l1l1l1l1[:-1])
def main():
    try:
        l11l1l1()
        l1ll1111()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()