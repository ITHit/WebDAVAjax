#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1111 (l111ll):
    global l11ll1
    l1l1l = ord (l111ll [-1])
    l1 = l111ll [:-1]
    l1llll = l1l1l % len (l1)
    l111l = l1 [:l1llll] + l1 [l1llll:]
    if l11l1:
        l11l = l1ll11 () .join ([unichr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1111l - (l1l1l1 + l1l1l) % l1l1) for l1l1l1, char in enumerate (l111l)])
    return eval (l11l)
import json
import struct
from l1ll1 import *
l1l1l1l1 = sys.version_info[0] == 2
l1ll11ll = l1111 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1ll1l = l1111 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1111 (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠺࠺࠴࠰ࠣࡅ")
l1ll1l11 = l1111 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1llll1l = l1l1ll1l.replace(l1111 (u"ࠧࠦࠢࡇ"), l1111 (u"ࠨ࡟ࠣࡈ")) + l1111 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1lll = {}
if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1111 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11l1ll = sys.argv[0]
        try:
            l1ll1lll = l1l11ll(l11l1ll)
            l1l1ll1l = l1ll1lll[l1111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1lll[l1111 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1ll1lll[l1111 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1llll1l = l1l1ll1l.replace(l1111 (u"ࠨࠠࠣࡏ"), l1111 (u"ࠢࡠࠤࡐ")) + l1111 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll11 = os.path.join(os.environ.get(l1111 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1llll1l)
elif platform.system() == l1111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll111l = os.path.join(os.environ.get(l1111 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1111 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l1111 (u"ࠨࠬࠣࡖ"))[0].replace(l1111 (u"ࠢࠡࠤࡗ"), l1111 (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l11111(l1ll111l + l1111 (u"ࠤ࠲࡙ࠦ"))
    l1l1ll11 = os.path.join(l1l1llll, l1llll1l)
elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll111l = os.path.join(os.environ.get(l1111 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1111 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l1111 (u"ࠨࠬࠣ࡝"))[0].replace(l1111 (u"ࠢࠡࠤ࡞"), l1111 (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l11111(l1ll111l + l1111 (u"ࠤ࠲ࠦࡠ"))
    l1l1ll11 = os.path.join(l1l1llll, l1llll1l)
else:
    l1l1ll11 = os.path.join(l1llll1l)
logger = logging.getLogger(l1111 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1lll1l(logger, l1l1ll11)
logger.info(l1111 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1111 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1ll1l)
logger.info(l1111 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1111 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l1111 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll11ll)
l111l1 = get_major_version(VERSION)
l111 = l1ll1l1(l111l1, l1ll11ll)
logger.info(l1111 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111l1)
logger.info(l1111 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111)
logger.info(l1111 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1111 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1lll1():
    if l1l1l1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1l1l():
    if l1l1l1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1l1():
    l1ll11l1 = l1l1lll1().read(4)
    while len(l1ll11l1) == 4:
        l1lll1ll = struct.unpack(l1111 (u"ࠨࡀࡊࠤ࡫"), l1ll11l1)[0]
        request = l1l1lll1().read(l1lll1ll).decode()
        logger.info(l1111 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll11l(request)
        l1llll11(response)
        logger.info(l1111 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll11l1 = l1l1lll1().read(4)
    logger.info(l1111 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll11(message):
    message = json.dumps(message).encode()
    l1l1l1ll = struct.pack(l1111 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1l1l().write(l1l1l1ll)
    l1ll1l1l().write(message)
    l1ll1l1l().flush()
def l1lll11l(request):
    if request:
        l1ll1ll1 = json.loads(request)
    try:
        return {
            l1111 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11lll,
            l1111 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1ll1,
            l1111 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1111ll
        }[l1ll1ll1[l1111 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1ll1)
    except Exception as e:
        logger.error(l1111 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11lll()
def l11lll(l1ll1ll1=None):
    l1lll111(l1ll1ll1)
    l1lllll1 = {l1111 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l11()}
    l1lllll1[l1111 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll111(l111)
    return l1lllll1
def l1l1ll1(l1ll1ll1):
    url = l1ll1ll1[l1111 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1lll = url.split(l1111 (u"ࠬࡀࠧࡸ"))[0]
    return {l1111 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11llll(l1lll, url)}
def l1111ll(l1ll1ll1):
    try:
        l1lll = l1ll1ll(l111)
        url = l1111 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1lll, l1ll1ll1[l1111 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1ll1[l1111 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1111 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1lll, url))
        return {l1111 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11llll(l1lll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1111 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll111(l1ll1ll1):
    l1ll1111 = l1111 (u"࠭ࠧࢀ")
    if l1ll1ll1:
        for name in l1ll1ll1:
            if name in [l1111 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1111 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1111 += l1111 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1ll1[name]
    if l1ll1111: logger.info(l1ll1111[:-1])
def main():
    try:
        l1lll11()
        l1lll1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1111 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()