#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1l1ll (l1l11):
    global l11ll1
    l1ll11 = ord (l1l11 [-1])
    l111ll = l1l11 [:-1]
    l1lll = l1ll11 % len (l111ll)
    l1ll1l = l111ll [:l1lll] + l111ll [l1lll:]
    if l1llll:
        l1lll1 = l11l1l () .join ([unichr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    return eval (l1lll1)
import json
import struct
from l1 import *
l1l1ll1l = sys.version_info[0] == 2
l1lllll1 = l1l1ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1ll11 = l1l1ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠺࠵࠴࠰ࠣࡅ")
l1l1llll = l1l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll1l1 = l1l1ll11.replace(l1l1ll (u"ࠧࠦࠢࡇ"), l1l1ll (u"ࠨ࡟ࠣࡈ")) + l1l1ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1l1l1 = {}
if platform.system() == l1l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1llllll = sys.argv[0]
        try:
            l1l1l1l1 = l11111(l1llllll)
            l1l1ll11 = l1l1l1l1[l1l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1l1l1[l1l1ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1llll = l1l1l1l1[l1l1ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll1l1 = l1l1ll11.replace(l1l1ll (u"ࠨࠠࠣࡏ"), l1l1ll (u"ࠢࡠࠤࡐ")) + l1l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll11ll = os.path.join(os.environ.get(l1l1ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll1l1)
elif platform.system() == l1l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1lll1 = os.path.join(os.environ.get(l1l1ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1llll.split(l1l1ll (u"ࠨࠬࠣࡖ"))[0].replace(l1l1ll (u"ࠢࠡࠤࡗ"), l1l1ll (u"ࠣࡡࠥࡘ")).lower())
    l1llll11 = l1llll1(l1l1lll1 + l1l1ll (u"ࠤ࠲࡙ࠦ"))
    l1ll11ll = os.path.join(l1llll11, l1lll1l1)
elif platform.system() == l1l1ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1lll1 = os.path.join(os.environ.get(l1l1ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1llll.split(l1l1ll (u"ࠨࠬࠣ࡝"))[0].replace(l1l1ll (u"ࠢࠡࠤ࡞"), l1l1ll (u"ࠣࡡࠥ࡟")).lower())
    l1llll11 = l1llll1(l1l1lll1 + l1l1ll (u"ࠤ࠲ࠦࡠ"))
    l1ll11ll = os.path.join(l1llll11, l1lll1l1)
else:
    l1ll11ll = os.path.join(l1lll1l1)
logger = logging.getLogger(l1l1ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11ll11(logger, l1ll11ll)
logger.info(l1l1ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1ll11)
logger.info(l1l1ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1llll)
logger.info(l1l1ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lllll1)
l11l11 = get_major_version(VERSION)
l111l = l1l111l(l11l11, l1lllll1)
logger.info(l1l1ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11l11)
logger.info(l1l1ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111l)
logger.info(l1l1ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1l1ll():
    if l1l1ll1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll111():
    if l1l1ll1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1111():
    l1ll11l1 = l1l1l1ll().read(4)
    while len(l1ll11l1) == 4:
        l1ll1l11 = struct.unpack(l1l1ll (u"ࠨࡀࡊࠤ࡫"), l1ll11l1)[0]
        request = l1l1l1ll().read(l1ll1l11).decode()
        logger.info(l1l1ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll111l(request)
        l1ll1l1l(response)
        logger.info(l1l1ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll11l1 = l1l1l1ll().read(4)
    logger.info(l1l1ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l1l(message):
    message = json.dumps(message).encode()
    l1llll1l = struct.pack(l1l1ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll111().write(l1llll1l)
    l1lll111().write(message)
    l1lll111().flush()
def l1ll111l(request):
    if request:
        l1lll11l = json.loads(request)
    try:
        return {
            l1l1ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1ll1,
            l1l1ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11llll,
            l1l1ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1l1l
        }[l1lll11l[l1l1ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll11l)
    except Exception as e:
        logger.error(l1l1ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1ll1()
def l1ll1(l1lll11l=None):
    l1ll1lll(l1lll11l)
    l1ll1ll1 = {l1l1ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11ll()}
    l1ll1ll1[l1l1ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll1l1(l111l)
    return l1ll1ll1
def l11llll(l1lll11l):
    url = l1lll11l[l1l1ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1ll = url.split(l1l1ll (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1lll(l1ll, url)}
def l1l1l1l(l1lll11l):
    try:
        l1ll = l111111(l111l)
        url = l1l1ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1ll, l1lll11l[l1l1ll (u"ࠨࡣࡦࡸࠬࡻ")], l1lll11l[l1l1ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1ll, url))
        return {l1l1ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1lll(l1ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1lll(l1lll11l):
    l1lll1ll = l1l1ll (u"࠭ࠧࢀ")
    if l1lll11l:
        for name in l1lll11l:
            if name in [l1l1ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll1ll += l1l1ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll11l[name]
    if l1lll1ll: logger.info(l1lll1ll[:-1])
def main():
    try:
        l1111l1()
        l1ll1111()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()