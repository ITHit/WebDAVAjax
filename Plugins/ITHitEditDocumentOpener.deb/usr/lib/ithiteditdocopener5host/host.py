#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1 = 2048
l1lll = 7
def l1ll11 (l1111l):
    global l1ll
    l11ll = ord (l1111l [-1])
    l111ll = l1111l [:-1]
    l1llll = l11ll % len (l111ll)
    l1l = l111ll [:l1llll] + l111ll [l1llll:]
    if l11:
        l11l1l = l111l1 () .join ([unichr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    return eval (l11l1l)
import json
import struct
from l1l1 import *
l1l1l1ll = sys.version_info[0] == 2
l1lll111 = l1ll11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1l1l1 = l1ll11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll11 (u"ࠥ࠺࠳࠸࠮࠹࠻࠶࠻࠳࠶ࠢࡅ")
l1ll1lll = l1ll11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11l1 = l1l1l1l1.replace(l1ll11 (u"ࠧࠦࠢࡇ"), l1ll11 (u"ࠨ࡟ࠣࡈ")) + l1ll11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1ll11 = {}
if platform.system() == l1ll11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l11l1 = sys.argv[0]
        try:
            l1l1ll11 = l1l1l1l(l1l11l1)
            l1l1l1l1 = l1l1ll11[l1ll11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1ll11[l1ll11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1lll = l1l1ll11[l1ll11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11l1 = l1l1l1l1.replace(l1ll11 (u"ࠨࠠࠣࡏ"), l1ll11 (u"ࠢࡠࠤࡐ")) + l1ll11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll1ll = os.path.join(os.environ.get(l1ll11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11l1)
elif platform.system() == l1ll11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll1l = os.path.join(os.environ.get(l1ll11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1lll.split(l1ll11 (u"ࠨࠬࠣࡖ"))[0].replace(l1ll11 (u"ࠢࠡࠤࡗ"), l1ll11 (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l11lll1(l1l1ll1l + l1ll11 (u"ࠤ࠲࡙ࠦ"))
    l1lll1ll = os.path.join(l1l1llll, l1ll11l1)
elif platform.system() == l1ll11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll1l = os.path.join(os.environ.get(l1ll11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1lll.split(l1ll11 (u"ࠨࠬࠣ࡝"))[0].replace(l1ll11 (u"ࠢࠡࠤ࡞"), l1ll11 (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l11lll1(l1l1ll1l + l1ll11 (u"ࠤ࠲ࠦࡠ"))
    l1lll1ll = os.path.join(l1l1llll, l1ll11l1)
else:
    l1lll1ll = os.path.join(l1ll11l1)
logger = logging.getLogger(l1ll11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111lll(logger, l1lll1ll)
logger.info(l1ll11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1l1l1)
logger.info(l1ll11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1lll)
logger.info(l1ll11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll111)
l11l11 = get_major_version(VERSION)
l1l11 = l1l1ll1(l11l11, l1lll111)
logger.info(l1ll11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11l11)
logger.info(l1ll11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l11)
logger.info(l1ll11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1llll11():
    if l1l1l1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1l1():
    if l1l1l1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lllll1():
    l1llll1l = l1llll11().read(4)
    while len(l1llll1l) == 4:
        l1ll111l = struct.unpack(l1ll11 (u"ࠨࡀࡊࠤ࡫"), l1llll1l)[0]
        request = l1llll11().read(l1ll111l).decode()
        logger.info(l1ll11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1l1l(request)
        l1ll11ll(response)
        logger.info(l1ll11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1llll1l = l1llll11().read(4)
    logger.info(l1ll11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll11ll(message):
    message = json.dumps(message).encode()
    l1lll11l = struct.pack(l1ll11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1l1().write(l1lll11l)
    l1lll1l1().write(message)
    l1lll1l1().flush()
def l1ll1l1l(request):
    if request:
        l1ll1111 = json.loads(request)
    try:
        return {
            l1ll11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l,
            l1ll11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l111,
            l1ll11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111l1l
        }[l1ll1111[l1ll11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1111)
    except Exception as e:
        logger.error(l1ll11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l()
def l11l(l1ll1111=None):
    l1ll1l11(l1ll1111)
    l1l1lll1 = {l1ll11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l11l()}
    l1l1lll1[l1ll11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1ll(l1l11)
    return l1l1lll1
def l11l111(l1ll1111):
    url = l1ll1111[l1ll11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1l1 = url.split(l1ll11 (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1l11(l1l1l1, url)}
def l111l1l(l1ll1111):
    try:
        l1l1l1 = l11111(l1l11)
        url = l1ll11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1l1, l1ll1111[l1ll11 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1111[l1ll11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1l1, url))
        return {l1ll11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1l11(l1l1l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1l11(l1ll1111):
    l1ll1ll1 = l1ll11 (u"࠭ࠧࢀ")
    if l1ll1111:
        for name in l1ll1111:
            if name in [l1ll11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1ll1 += l1ll11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1111[name]
    if l1ll1ll1: logger.info(l1ll1ll1[:-1])
def main():
    try:
        l1ll111()
        l1lllll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()