#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l111l = 2048
l1l = 7
def l11ll (l1111):
    global l11
    l111l1 = ord (l1111 [-1])
    l1l1ll = l1111 [:-1]
    l1l1 = l111l1 % len (l1l1ll)
    l111 = l1l1ll [:l1l1] + l1l1ll [l1l1:]
    if l1111l:
        l1l11l = l1 () .join ([unichr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    return eval (l1l11l)
import json
import struct
from l1ll11 import *
l1llll1l = sys.version_info[0] == 2
l1l1l1ll = l11ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll11l1 = l11ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠹࠵࠴࠰ࠣࡅ")
l1lll1l1 = l11ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll111l = l1ll11l1.replace(l11ll (u"ࠧࠦࠢࡇ"), l11ll (u"ࠨ࡟ࠣࡈ")) + l11ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1lll = {}
if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11111 = sys.argv[0]
        try:
            l1ll1lll = l1l1111(l11111)
            l1ll11l1 = l1ll1lll[l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1lll[l11ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll1l1 = l1ll1lll[l11ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll111l = l1ll11l1.replace(l11ll (u"ࠨࠠࠣࡏ"), l11ll (u"ࠢࡠࠤࡐ")) + l11ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll1ll = os.path.join(os.environ.get(l11ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll111l)
elif platform.system() == l11ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll11ll = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll1l1.split(l11ll (u"ࠨࠬࠣࡖ"))[0].replace(l11ll (u"ࠢࠡࠤࡗ"), l11ll (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll1l = l1111ll(l1ll11ll + l11ll (u"ࠤ࠲࡙ࠦ"))
    l1lll1ll = os.path.join(l1l1ll1l, l1ll111l)
elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll11ll = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll1l1.split(l11ll (u"ࠨࠬࠣ࡝"))[0].replace(l11ll (u"ࠢࠡࠤ࡞"), l11ll (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll1l = l1111ll(l1ll11ll + l11ll (u"ࠤ࠲ࠦࡠ"))
    l1lll1ll = os.path.join(l1l1ll1l, l1ll111l)
else:
    l1lll1ll = os.path.join(l1ll111l)
logger = logging.getLogger(l11ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1lll1l(logger, l1lll1ll)
logger.info(l11ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll11l1)
logger.info(l11ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll1l1)
logger.info(l11ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1ll)
l11lll = get_major_version(VERSION)
l1l1l1 = l11l1ll(l11lll, l1l1l1ll)
logger.info(l11ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11lll)
logger.info(l11ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l1l1)
logger.info(l11ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1llll1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1l1l():
    if l1llll1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1lll1():
    l1lllll1 = l1lll11l().read(4)
    while len(l1lllll1) == 4:
        l1ll1l11 = struct.unpack(l11ll (u"ࠨࡀࡊࠤ࡫"), l1lllll1)[0]
        request = l1lll11l().read(l1ll1l11).decode()
        logger.info(l11ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1ll1(request)
        l1l1l1l1(response)
        logger.info(l11ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lllll1 = l1lll11l().read(4)
    logger.info(l11ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1l1l1(message):
    message = json.dumps(message).encode()
    l1lll111 = struct.pack(l11ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1l1l().write(l1lll111)
    l1ll1l1l().write(message)
    l1ll1l1l().flush()
def l1ll1ll1(request):
    if request:
        l1ll1111 = json.loads(request)
    try:
        return {
            l11ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1lll1,
            l11ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1ll1,
            l11ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11ll1l
        }[l1ll1111[l11ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1111)
    except Exception as e:
        logger.error(l11ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1lll1()
def l1lll1(l1ll1111=None):
    l1l1ll11(l1ll1111)
    l1l1llll = {l11ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll1l()}
    l1l1llll[l11ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1l1(l1l1l1)
    return l1l1llll
def l1l1ll1(l1ll1111):
    url = l1ll1111[l11ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l11 = url.split(l11ll (u"ࠬࡀࠧࡸ"))[0]
    return {l11ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111111(l1l11, url)}
def l11ll1l(l1ll1111):
    try:
        l1l11 = l1l1l11(l1l1l1)
        url = l11ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l11, l1ll1111[l11ll (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1111[l11ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l11, url))
        return {l11ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111111(l1l11, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1ll11(l1ll1111):
    l1llll11 = l11ll (u"࠭ࠧࢀ")
    if l1ll1111:
        for name in l1ll1111:
            if name in [l11ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1llll11 += l11ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1111[name]
    if l1llll11: logger.info(l1llll11[:-1])
def main():
    try:
        l1l111l()
        l1l1lll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()