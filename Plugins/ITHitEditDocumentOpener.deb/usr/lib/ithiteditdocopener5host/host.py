#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l1llll = 2048
l1l11 = 7
def l1ll1 (l1ll11):
    global l1l1l1
    l1111 = ord (l1ll11 [-1])
    ll = l1ll11 [:-1]
    l111l = l1111 % len (ll)
    l11l1l = ll [:l111l] + ll [l111l:]
    if l1l1:
        l11l = l111ll () .join ([unichr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    return eval (l11l)
import json
import struct
from l1l1ll import *
l1l1l1l1 = sys.version_info[0] == 2
l1l1ll11 = l1ll1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1l1ll = l1ll1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll1 (u"ࠥ࠺࠳࠶࠮࠹࠹࠸࠷࠳࠶ࠢࡅ")
l1ll1l11 = l1ll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1lll1 = l1l1l1ll.replace(l1ll1 (u"ࠧࠦࠢࡇ"), l1ll1 (u"ࠨ࡟ࠣࡈ")) + l1ll1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1l1 = {}
if platform.system() == l1ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l111l = sys.argv[0]
        try:
            l1lll1l1 = l11ll11(l1l111l)
            l1l1l1ll = l1lll1l1[l1ll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1l1[l1ll1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1lll1l1[l1ll1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1lll1 = l1l1l1ll.replace(l1ll1 (u"ࠨࠠࠣࡏ"), l1ll1 (u"ࠢࡠࠤࡐ")) + l1ll1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1lll = os.path.join(os.environ.get(l1ll1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1lll1)
elif platform.system() == l1ll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1llll11 = os.path.join(os.environ.get(l1ll1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l1ll1 (u"ࠨࠬࠣࡖ"))[0].replace(l1ll1 (u"ࠢࠡࠤࡗ"), l1ll1 (u"ࠣࡡࠥࡘ")).lower())
    l1lllll1 = l11llll(l1llll11 + l1ll1 (u"ࠤ࠲࡙ࠦ"))
    l1ll1lll = os.path.join(l1lllll1, l1l1lll1)
elif platform.system() == l1ll1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1llll11 = os.path.join(os.environ.get(l1ll1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l1ll1 (u"ࠨࠬࠣ࡝"))[0].replace(l1ll1 (u"ࠢࠡࠤ࡞"), l1ll1 (u"ࠣࡡࠥ࡟")).lower())
    l1lllll1 = l11llll(l1llll11 + l1ll1 (u"ࠤ࠲ࠦࡠ"))
    l1ll1lll = os.path.join(l1lllll1, l1l1lll1)
else:
    l1ll1lll = os.path.join(l1l1lll1)
logger = logging.getLogger(l1ll1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11111(logger, l1ll1lll)
logger.info(l1ll1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1l1ll)
logger.info(l1ll1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l1ll1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1ll11)
l1l11l = get_major_version(VERSION)
l1lll1 = l111111(l1l11l, l1l1ll11)
logger.info(l1ll1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l11l)
logger.info(l1ll1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll1)
logger.info(l1ll1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1l1l():
    if l1l1l1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll111l():
    if l1l1l1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1llll1l():
    l1ll11l1 = l1ll1l1l().read(4)
    while len(l1ll11l1) == 4:
        l1ll1ll1 = struct.unpack(l1ll1 (u"ࠨࡀࡊࠤ࡫"), l1ll11l1)[0]
        request = l1ll1l1l().read(l1ll1ll1).decode()
        logger.info(l1ll1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1llll(request)
        l1lll1ll(response)
        logger.info(l1ll1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll11l1 = l1ll1l1l().read(4)
    logger.info(l1ll1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1ll(message):
    message = json.dumps(message).encode()
    l1ll1111 = struct.pack(l1ll1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll111l().write(l1ll1111)
    l1ll111l().write(message)
    l1ll111l().flush()
def l1l1llll(request):
    if request:
        l1lll111 = json.loads(request)
    try:
        return {
            l1ll1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l111l1,
            l1ll1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1l11,
            l1ll1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lllll
        }[l1lll111[l1ll1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll111)
    except Exception as e:
        logger.error(l1ll1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l111l1()
def l111l1(l1lll111=None):
    l1ll11ll(l1lll111)
    l1l1ll1l = {l1ll1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1()}
    l1l1ll1l[l1ll1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1ll(l1lll1)
    return l1l1ll1l
def l1l1l11(l1lll111):
    url = l1lll111[l1ll1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11lll = url.split(l1ll1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11ll1l(l11lll, url)}
def l1lllll(l1lll111):
    try:
        l11lll = l1llll1(l1lll1)
        url = l1ll1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11lll, l1lll111[l1ll1 (u"ࠨࡣࡦࡸࠬࡻ")], l1lll111[l1ll1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11lll, url))
        return {l1ll1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11ll1l(l11lll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll11ll(l1lll111):
    l1lll11l = l1ll1 (u"࠭ࠧࢀ")
    if l1lll111:
        for name in l1lll111:
            if name in [l1ll1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll11l += l1ll1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll111[name]
    if l1lll11l: logger.info(l1lll11l[:-1])
def main():
    try:
        l1l1l1l()
        l1llll1l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()