#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111ll (l1l1l):
    global l11ll
    l1111l = ord (l1l1l [-1])
    l11l = l1l1l [:-1]
    l11l1l = l1111l % len (l11l)
    l1l11l = l11l [:l11l1l] + l11l [l11l1l:]
    if l1ll11:
        l1ll1l = l1l1l1 () .join ([unichr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import json
import struct
from l111l1 import *
l1ll1111 = sys.version_info[0] == 2
l1l1l1ll = l111ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = l111ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l111ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠼࠻࠴࠰ࠣࡅ")
l1ll1l11 = l111ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll11l = l1ll1l1l.replace(l111ll (u"ࠧࠦࠢࡇ"), l111ll (u"ࠨ࡟ࠣࡈ")) + l111ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11l1 = {}
if platform.system() == l111ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l111ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lll1l = sys.argv[0]
        try:
            l1ll11l1 = l1ll11l(l1lll1l)
            l1ll1l1l = l1ll11l1[l111ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11l1[l111ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1ll11l1[l111ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll11l = l1ll1l1l.replace(l111ll (u"ࠨࠠࠣࡏ"), l111ll (u"ࠢࡠࠤࡐ")) + l111ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1lll = os.path.join(os.environ.get(l111ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll11l)
elif platform.system() == l111ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1llll = os.path.join(os.environ.get(l111ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l111ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l111ll (u"ࠨࠬࠣࡖ"))[0].replace(l111ll (u"ࠢࠡࠤࡗ"), l111ll (u"ࠣࡡࠥࡘ")).lower())
    l1llll11 = l1l11l1(l1l1llll + l111ll (u"ࠤ࠲࡙ࠦ"))
    l1ll1lll = os.path.join(l1llll11, l1lll11l)
elif platform.system() == l111ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1llll = os.path.join(os.environ.get(l111ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l111ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l111ll (u"ࠨࠬࠣ࡝"))[0].replace(l111ll (u"ࠢࠡࠤ࡞"), l111ll (u"ࠣࡡࠥ࡟")).lower())
    l1llll11 = l1l11l1(l1l1llll + l111ll (u"ࠤ࠲ࠦࡠ"))
    l1ll1lll = os.path.join(l1llll11, l1lll11l)
else:
    l1ll1lll = os.path.join(l1lll11l)
logger = logging.getLogger(l111ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l11l(logger, l1ll1lll)
logger.info(l111ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l111ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(l111ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l111ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l111ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1ll)
l1l11 = get_major_version(VERSION)
l1ll1 = l11lll1(l1l11, l1l1l1ll)
logger.info(l111ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l11)
logger.info(l111ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1)
logger.info(l111ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l111ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1llll1l():
    if l1ll1111:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll11():
    if l1ll1111:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll111():
    l1l1ll1l = l1llll1l().read(4)
    while len(l1l1ll1l) == 4:
        l1ll1ll1 = struct.unpack(l111ll (u"ࠨࡀࡊࠤ࡫"), l1l1ll1l)[0]
        request = l1llll1l().read(l1ll1ll1).decode()
        logger.info(l111ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll111l(request)
        l1ll11ll(response)
        logger.info(l111ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll1l = l1llll1l().read(4)
    logger.info(l111ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll11ll(message):
    message = json.dumps(message).encode()
    l1l1l1l1 = struct.pack(l111ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll11().write(l1l1l1l1)
    l1l1ll11().write(message)
    l1l1ll11().flush()
def l1ll111l(request):
    if request:
        l1l1lll1 = json.loads(request)
    try:
        return {
            l111ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l1ll,
            l111ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l1l1,
            l111ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1llllll
        }[l1l1lll1[l111ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1lll1)
    except Exception as e:
        logger.error(l111ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l1ll()
def l1l1ll(l1l1lll1=None):
    l1lllll1(l1l1lll1)
    l1lll1ll = {l111ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11lll()}
    l1lll1ll[l111ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1lllll(l1ll1)
    return l1lll1ll
def l11l1l1(l1l1lll1):
    url = l1l1lll1[l111ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1lll1 = url.split(l111ll (u"ࠬࡀࠧࡸ"))[0]
    return {l111ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1ll1ll(l1lll1, url)}
def l1llllll(l1l1lll1):
    try:
        l1lll1 = l111111(l1ll1)
        url = l111ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1lll1, l1l1lll1[l111ll (u"ࠨࡣࡦࡸࠬࡻ")], l1l1lll1[l111ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l111ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1lll1, url))
        return {l111ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1ll1ll(l1lll1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l111ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lllll1(l1l1lll1):
    l1lll1l1 = l111ll (u"࠭ࠧࢀ")
    if l1l1lll1:
        for name in l1l1lll1:
            if name in [l111ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l111ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll1l1 += l111ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1lll1[name]
    if l1lll1l1: logger.info(l1lll1l1[:-1])
def main():
    try:
        l11l1ll()
        l1lll111()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l111ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()