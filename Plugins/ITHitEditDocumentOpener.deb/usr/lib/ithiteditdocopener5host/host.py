#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll = 2048
l111l = 7
def l1l1l (ll):
    global l11ll
    l1111 = ord (ll [-1])
    l1lll = ll [:-1]
    l1ll1l = l1111 % len (l1lll)
    l1l11 = l1lll [:l1ll1l] + l1lll [l1ll1l:]
    if l1l1l1:
        l1l = l111ll () .join ([unichr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    return eval (l1l)
import json
import struct
from l11l import *
l1lll1l1 = sys.version_info[0] == 2
l1ll1111 = l1l1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1llll11 = l1l1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1l (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠶࠷࠴࠰ࠣࡅ")
l1lll111 = l1l1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1llll11.replace(l1l1l (u"ࠧࠦࠢࡇ"), l1l1l (u"ࠨ࡟ࠣࡈ")) + l1l1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l1l1l = sys.argv[0]
        try:
            l1ll1l11 = l11ll1l(l1l1l1l)
            l1llll11 = l1ll1l11[l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l1l1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lll111 = l1ll1l11[l1l1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1llll11.replace(l1l1l (u"ࠨࠠࠣࡏ"), l1l1l (u"ࠢࡠࠤࡐ")) + l1l1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1llll = os.path.join(os.environ.get(l1l1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lll111.split(l1l1l (u"ࠨࠬࠣࡖ"))[0].replace(l1l1l (u"ࠢࠡࠤࡗ"), l1l1l (u"ࠣࡡࠥࡘ")).lower())
    l1ll1lll = l11ll11(l1ll1ll1 + l1l1l (u"ࠤ࠲࡙ࠦ"))
    l1l1llll = os.path.join(l1ll1lll, l1ll11ll)
elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lll111.split(l1l1l (u"ࠨࠬࠣ࡝"))[0].replace(l1l1l (u"ࠢࠡࠤ࡞"), l1l1l (u"ࠣࡡࠥ࡟")).lower())
    l1ll1lll = l11ll11(l1ll1ll1 + l1l1l (u"ࠤ࠲ࠦࡠ"))
    l1l1llll = os.path.join(l1ll1lll, l1ll11ll)
else:
    l1l1llll = os.path.join(l1ll11ll)
logger = logging.getLogger(l1l1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111ll1(logger, l1l1llll)
logger.info(l1l1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1llll11)
logger.info(l1l1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lll111)
logger.info(l1l1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l1111l = get_major_version(VERSION)
l1 = l1ll1l1(l1111l, l1ll1111)
logger.info(l1l1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111l)
logger.info(l1l1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1)
logger.info(l1l1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1lll1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll11l1():
    if l1lll1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lllll1():
    l1lll1ll = l1lll11l().read(4)
    while len(l1lll1ll) == 4:
        l1l1lll1 = struct.unpack(l1l1l (u"ࠨࡀࡊࠤ࡫"), l1lll1ll)[0]
        request = l1lll11l().read(l1l1lll1).decode()
        logger.info(l1l1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1ll11(request)
        l1l1l1ll(response)
        logger.info(l1l1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1ll = l1lll11l().read(4)
    logger.info(l1l1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1l1ll(message):
    message = json.dumps(message).encode()
    l1llll1l = struct.pack(l1l1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll11l1().write(l1llll1l)
    l1ll11l1().write(message)
    l1ll11l1().flush()
def l1l1ll11(request):
    if request:
        l1l1l1l1 = json.loads(request)
    try:
        return {
            l1l1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l1,
            l1l1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l111l,
            l1l1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lllll
        }[l1l1l1l1[l1l1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1l1)
    except Exception as e:
        logger.error(l1l1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l1()
def l1l1(l1l1l1l1=None):
    l1ll111l(l1l1l1l1)
    l1l1ll1l = {l1l1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111l1()}
    l1l1ll1l[l1l1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l111111(l1)
    return l1l1ll1l
def l1l111l(l1l1l1l1):
    url = l1l1l1l1[l1l1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l111 = url.split(l1l1l (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1ll1(l1l111, url)}
def l1lllll(l1l1l1l1):
    try:
        l1l111 = l1111l1(l1)
        url = l1l1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l111, l1l1l1l1[l1l1l (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1l1[l1l1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l111, url))
        return {l1l1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1ll1(l1l111, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll111l(l1l1l1l1):
    l1ll1l1l = l1l1l (u"࠭ࠧࢀ")
    if l1l1l1l1:
        for name in l1l1l1l1:
            if name in [l1l1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l1l += l1l1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1l1[name]
    if l1ll1l1l: logger.info(l1ll1l1l[:-1])
def main():
    try:
        l11111()
        l1lllll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()