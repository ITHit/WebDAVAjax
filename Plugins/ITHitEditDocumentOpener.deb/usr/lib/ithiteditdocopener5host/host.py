#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l11l1 = 2048
l1 = 7
def l1ll1 (l11l11):
    global l1l1ll
    l111l = ord (l11l11 [-1])
    l1l = l11l11 [:-1]
    l1llll = l111l % len (l1l)
    l1lll = l1l [:l1llll] + l1l [l1llll:]
    if ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l1l1)
import json
import struct
from l1111l import *
l1ll11l1 = sys.version_info[0] == 2
l1ll1l11 = l1ll1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1ll1 = l1ll1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll1 (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠽࠹࠴࠰ࠣࡅ")
l1ll11ll = l1ll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1111 = l1ll1ll1.replace(l1ll1 (u"ࠧࠦࠢࡇ"), l1ll1 (u"ࠨ࡟ࠣࡈ")) + l1ll1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1l1 = {}
if platform.system() == l1ll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111111 = sys.argv[0]
        try:
            l1lll1l1 = l11111l(l111111)
            l1ll1ll1 = l1lll1l1[l1ll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1l1[l1ll1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll11ll = l1lll1l1[l1ll1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1111 = l1ll1ll1.replace(l1ll1 (u"ࠨࠠࠣࡏ"), l1ll1 (u"ࠢࡠࠤࡐ")) + l1ll1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1lll = os.path.join(os.environ.get(l1ll1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1111)
elif platform.system() == l1ll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll111l = os.path.join(os.environ.get(l1ll1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll11ll.split(l1ll1 (u"ࠨࠬࠣࡖ"))[0].replace(l1ll1 (u"ࠢࠡࠤࡗ"), l1ll1 (u"ࠣࡡࠥࡘ")).lower())
    l1lll111 = l1111ll(l1ll111l + l1ll1 (u"ࠤ࠲࡙ࠦ"))
    l1ll1lll = os.path.join(l1lll111, l1ll1111)
elif platform.system() == l1ll1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll111l = os.path.join(os.environ.get(l1ll1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll11ll.split(l1ll1 (u"ࠨࠬࠣ࡝"))[0].replace(l1ll1 (u"ࠢࠡࠤ࡞"), l1ll1 (u"ࠣࡡࠥ࡟")).lower())
    l1lll111 = l1111ll(l1ll111l + l1ll1 (u"ࠤ࠲ࠦࡠ"))
    l1ll1lll = os.path.join(l1lll111, l1ll1111)
else:
    l1ll1lll = os.path.join(l1ll1111)
logger = logging.getLogger(l1ll1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1lll1l(logger, l1ll1lll)
logger.info(l1ll1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1ll1)
logger.info(l1ll1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll11ll)
logger.info(l1ll1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1l11)
l111ll = get_major_version(VERSION)
l11l = l11ll11(l111ll, l1ll1l11)
logger.info(l1ll1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111ll)
logger.info(l1ll1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11l)
logger.info(l1ll1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll1ll():
    if l1ll11l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll11l():
    if l1ll11l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1lll1():
    l1l1llll = l1lll1ll().read(4)
    while len(l1l1llll) == 4:
        l1lllll1 = struct.unpack(l1ll1 (u"ࠨࡀࡊࠤ࡫"), l1l1llll)[0]
        request = l1lll1ll().read(l1lllll1).decode()
        logger.info(l1ll1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1l1ll(request)
        l1llll11(response)
        logger.info(l1ll1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1llll = l1lll1ll().read(4)
    logger.info(l1ll1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll11(message):
    message = json.dumps(message).encode()
    l1l1ll1l = struct.pack(l1ll1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll11l().write(l1l1ll1l)
    l1lll11l().write(message)
    l1lll11l().flush()
def l1l1l1ll(request):
    if request:
        l1ll1l1l = json.loads(request)
    try:
        return {
            l1ll1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1ll11,
            l1ll1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1ll1l1,
            l1ll1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1llllll
        }[l1ll1l1l[l1ll1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1l1l)
    except Exception as e:
        logger.error(l1ll1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1ll11()
def l1ll11(l1ll1l1l=None):
    l1l1ll11(l1ll1l1l)
    l1l1l1l1 = {l1ll1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1lll1()}
    l1l1l1l1[l1ll1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l111(l11l)
    return l1l1l1l1
def l1ll1l1(l1ll1l1l):
    url = l1ll1l1l[l1ll1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1 = url.split(l1ll1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1111l1(l1l1, url)}
def l1llllll(l1ll1l1l):
    try:
        l1l1 = l111l11(l11l)
        url = l1ll1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1, l1ll1l1l[l1ll1 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1l1l[l1ll1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1, url))
        return {l1ll1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1111l1(l1l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1ll11(l1ll1l1l):
    l1llll1l = l1ll1 (u"࠭ࠧࢀ")
    if l1ll1l1l:
        for name in l1ll1l1l:
            if name in [l1ll1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1llll1l += l1ll1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1l1l[name]
    if l1llll1l: logger.info(l1llll1l[:-1])
def main():
    try:
        l1l11ll()
        l1l1lll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()