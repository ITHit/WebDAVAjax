#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1l = 7
def l1ll (l1):
    global l111l1
    l1l = ord (l1 [-1])
    ll = l1 [:-1]
    l111l = l1l % len (ll)
    l11ll = ll [:l111l] + ll [l111l:]
    if l1ll1:
        l1ll11 = l1l111 () .join ([unichr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    return eval (l1ll11)
import json
import struct
from l1l1ll import *
l1ll11l1 = sys.version_info[0] == 2
l1ll1lll = l1ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll1l1 = l1ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠺࠾࠴࠰ࠣࡅ")
l1l1ll1l = l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll11l = l1lll1l1.replace(l1ll (u"ࠧࠦࠢࡇ"), l1ll (u"ࠨ࡟ࠣࡈ")) + l1ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1llll = {}
if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll111 = sys.argv[0]
        try:
            l1l1llll = l11l11l(l1ll111)
            l1lll1l1 = l1l1llll[l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1llll[l1ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll1l = l1l1llll[l1ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll11l = l1lll1l1.replace(l1ll (u"ࠨࠠࠣࡏ"), l1ll (u"ࠢࡠࠤࡐ")) + l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1ll1 = os.path.join(os.environ.get(l1ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll11l)
elif platform.system() == l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1ll = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll1l.split(l1ll (u"ࠨࠬࠣࡖ"))[0].replace(l1ll (u"ࠢࠡࠤࡗ"), l1ll (u"ࠣࡡࠥࡘ")).lower())
    l1lllll1 = l1l11l1(l1l1l1ll + l1ll (u"ࠤ࠲࡙ࠦ"))
    l1ll1ll1 = os.path.join(l1lllll1, l1lll11l)
elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1ll = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll1l.split(l1ll (u"ࠨࠬࠣ࡝"))[0].replace(l1ll (u"ࠢࠡࠤ࡞"), l1ll (u"ࠣࡡࠥ࡟")).lower())
    l1lllll1 = l1l11l1(l1l1l1ll + l1ll (u"ࠤ࠲ࠦࡠ"))
    l1ll1ll1 = os.path.join(l1lllll1, l1lll11l)
else:
    l1ll1ll1 = os.path.join(l1lll11l)
logger = logging.getLogger(l1ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11ll11(logger, l1ll1ll1)
logger.info(l1ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll1l1)
logger.info(l1ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll1l)
logger.info(l1ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1lll)
l1lll = get_major_version(VERSION)
l111 = l1ll1ll(l1lll, l1ll1lll)
logger.info(l1ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1lll)
logger.info(l1ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111)
logger.info(l1ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1111():
    if l1ll11l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1ll():
    if l1ll11l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll11ll():
    l1ll111l = l1ll1111().read(4)
    while len(l1ll111l) == 4:
        l1lll111 = struct.unpack(l1ll (u"ࠨࡀࡊࠤ࡫"), l1ll111l)[0]
        request = l1ll1111().read(l1lll111).decode()
        logger.info(l1ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll1l(request)
        l1ll1l1l(response)
        logger.info(l1ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll111l = l1ll1111().read(4)
    logger.info(l1ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l1l(message):
    message = json.dumps(message).encode()
    l1l1lll1 = struct.pack(l1ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1ll().write(l1l1lll1)
    l1lll1ll().write(message)
    l1lll1ll().flush()
def l1llll1l(request):
    if request:
        l1l1l1l1 = json.loads(request)
    try:
        return {
            l1ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11ll1,
            l1ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lll1l,
            l1ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l111l
        }[l1l1l1l1[l1ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1l1)
    except Exception as e:
        logger.error(l1ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11ll1()
def l11ll1(l1l1l1l1=None):
    l1ll1l11(l1l1l1l1)
    l1l1ll11 = {l1ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11lll()}
    l1l1ll11[l1ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1ll(l111)
    return l1l1ll11
def l1lll1l(l1l1l1l1):
    url = l1l1l1l1[l1ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1 = url.split(l1ll (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l1l1(l11l1, url)}
def l1l111l(l1l1l1l1):
    try:
        l11l1 = l1lll11(l111)
        url = l1ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1, l1l1l1l1[l1ll (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1l1[l1ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1, url))
        return {l1ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l1l1(l11l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1l11(l1l1l1l1):
    l1llll11 = l1ll (u"࠭ࠧࢀ")
    if l1l1l1l1:
        for name in l1l1l1l1:
            if name in [l1ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1llll11 += l1ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1l1[name]
    if l1llll11: logger.info(l1llll11[:-1])
def main():
    try:
        l1l1l11()
        l1ll11ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()