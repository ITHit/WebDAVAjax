#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11lll = 2048
l1ll1 = 7
def l1l111 (l1l):
    global l1111
    ll = ord (l1l [-1])
    l111l1 = l1l [:-1]
    l111l = ll % len (l111l1)
    l11l1 = l111l1 [:l111l] + l111l1 [l111l:]
    if l1l1:
        l1lll = l1l11l () .join ([unichr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    else:
        l1lll = str () .join ([chr (ord (char) - l11lll - (l1ll11 + ll) % l1ll1) for l1ll11, char in enumerate (l11l1)])
    return eval (l1lll)
import json
import struct
from l1ll import *
l1l1l1l1 = sys.version_info[0] == 2
l1ll1111 = l1l111 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll111 = l1l111 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l111 (u"ࠥ࠺࠳࠸࠮࠹࠻࠶࠸࠳࠶ࠢࡅ")
l1l1ll11 = l1l111 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11ll = l1lll111.replace(l1l111 (u"ࠧࠦࠢࡇ"), l1l111 (u"ࠨ࡟ࠣࡈ")) + l1l111 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11l1 = {}
if platform.system() == l1l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l111 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1lllll = sys.argv[0]
        try:
            l1ll11l1 = l11111l(l1lllll)
            l1lll111 = l1ll11l1[l1l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11l1[l1l111 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll11 = l1ll11l1[l1l111 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11ll = l1lll111.replace(l1l111 (u"ࠨࠠࠣࡏ"), l1l111 (u"ࠢࡠࠤࡐ")) + l1l111 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1l1l = os.path.join(os.environ.get(l1l111 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11ll)
elif platform.system() == l1l111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll111l = os.path.join(os.environ.get(l1l111 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l111 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll11.split(l1l111 (u"ࠨࠬࠣࡖ"))[0].replace(l1l111 (u"ࠢࠡࠤࡗ"), l1l111 (u"ࠣࡡࠥࡘ")).lower())
    l1l1lll1 = l1l1l1l(l1ll111l + l1l111 (u"ࠤ࠲࡙ࠦ"))
    l1ll1l1l = os.path.join(l1l1lll1, l1ll11ll)
elif platform.system() == l1l111 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll111l = os.path.join(os.environ.get(l1l111 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l111 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll11.split(l1l111 (u"ࠨࠬࠣ࡝"))[0].replace(l1l111 (u"ࠢࠡࠤ࡞"), l1l111 (u"ࠣࡡࠥ࡟")).lower())
    l1l1lll1 = l1l1l1l(l1ll111l + l1l111 (u"ࠤ࠲ࠦࡠ"))
    l1ll1l1l = os.path.join(l1l1lll1, l1ll11ll)
else:
    l1ll1l1l = os.path.join(l1ll11ll)
logger = logging.getLogger(l1l111 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11111(logger, l1ll1l1l)
logger.info(l1l111 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l111 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll111)
logger.info(l1l111 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l111 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll11)
logger.info(l1l111 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l1111l = get_major_version(VERSION)
l11 = l1lll1l(l1111l, l1ll1111)
logger.info(l1l111 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111l)
logger.info(l1l111 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11)
logger.info(l1l111 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l111 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1llll():
    if l1l1l1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1l11():
    if l1l1l1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1llll11():
    l1lll1ll = l1l1llll().read(4)
    while len(l1lll1ll) == 4:
        l1l1ll1l = struct.unpack(l1l111 (u"ࠨࡀࡊࠤ࡫"), l1lll1ll)[0]
        request = l1l1llll().read(l1l1ll1l).decode()
        logger.info(l1l111 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lllll1(request)
        l1llll1l(response)
        logger.info(l1l111 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1ll = l1l1llll().read(4)
    logger.info(l1l111 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll1l(message):
    message = json.dumps(message).encode()
    l1l1l1ll = struct.pack(l1l111 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1l11().write(l1l1l1ll)
    l1ll1l11().write(message)
    l1ll1l11().flush()
def l1lllll1(request):
    if request:
        l1lll11l = json.loads(request)
    try:
        return {
            l1l111 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1lll1,
            l1l111 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l111l,
            l1l111 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1111ll
        }[l1lll11l[l1l111 (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll11l)
    except Exception as e:
        logger.error(l1l111 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1lll1()
def l1lll1(l1lll11l=None):
    l1ll1lll(l1lll11l)
    l1lll1l1 = {l1l111 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l()}
    l1lll1l1[l1l111 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1111(l11)
    return l1lll1l1
def l1l111l(l1lll11l):
    url = l1lll11l[l1l111 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1llll = url.split(l1l111 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l111 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l11l1(l1llll, url)}
def l1111ll(l1lll11l):
    try:
        l1llll = l1111l1(l11)
        url = l1l111 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1llll, l1lll11l[l1l111 (u"ࠨࡣࡦࡸࠬࡻ")], l1lll11l[l1l111 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l111 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1llll, url))
        return {l1l111 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l11l1(l1llll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l111 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1lll(l1lll11l):
    l1ll1ll1 = l1l111 (u"࠭ࠧࢀ")
    if l1lll11l:
        for name in l1lll11l:
            if name in [l1l111 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l111 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1ll1 += l1l111 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll11l[name]
    if l1ll1ll1: logger.info(l1ll1ll1[:-1])
def main():
    try:
        l1ll1l1()
        l1llll11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l111 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()