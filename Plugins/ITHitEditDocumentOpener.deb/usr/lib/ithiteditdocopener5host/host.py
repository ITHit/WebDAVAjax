#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1l111 = 2048
l11ll1 = 7
def l1l1 (l11):
    global l1ll11
    l1llll = ord (l11 [-1])
    l1ll1 = l11 [:-1]
    l111l = l1llll % len (l1ll1)
    l1111l = l1ll1 [:l111l] + l1ll1 [l111l:]
    if l1l1l1:
        ll = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    else:
        ll = str () .join ([chr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    return eval (ll)
import json
import struct
from l1l1ll import *
l1llll1l = sys.version_info[0] == 2
l1l1l1l1 = l1l1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lllll1 = l1l1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1 (u"ࠥ࠺࠳࠶࠮࠹࠹࠷࠼࠳࠶ࠢࡅ")
l1llll11 = l1l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1l1l = l1lllll1.replace(l1l1 (u"ࠧࠦࠢࡇ"), l1l1 (u"ࠨ࡟ࠣࡈ")) + l1l1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l11 = {}
if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11llll = sys.argv[0]
        try:
            l1ll1l11 = l11lll1(l11llll)
            l1lllll1 = l1ll1l11[l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l11[l1l1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1llll11 = l1ll1l11[l1l1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1l1l = l1lllll1.replace(l1l1 (u"ࠨࠠࠣࡏ"), l1l1 (u"ࠢࡠࠤࡐ")) + l1l1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll11ll = os.path.join(os.environ.get(l1l1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1l1l)
elif platform.system() == l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1lll = os.path.join(os.environ.get(l1l1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1llll11.split(l1l1 (u"ࠨࠬࠣࡖ"))[0].replace(l1l1 (u"ࠢࠡࠤࡗ"), l1l1 (u"ࠣࡡࠥࡘ")).lower())
    l1ll11l1 = l11l111(l1ll1lll + l1l1 (u"ࠤ࠲࡙ࠦ"))
    l1ll11ll = os.path.join(l1ll11l1, l1ll1l1l)
elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1lll = os.path.join(os.environ.get(l1l1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1llll11.split(l1l1 (u"ࠨࠬࠣ࡝"))[0].replace(l1l1 (u"ࠢࠡࠤ࡞"), l1l1 (u"ࠣࡡࠥ࡟")).lower())
    l1ll11l1 = l11l111(l1ll1lll + l1l1 (u"ࠤ࠲ࠦࡠ"))
    l1ll11ll = os.path.join(l1ll11l1, l1ll1l1l)
else:
    l1ll11ll = os.path.join(l1ll1l1l)
logger = logging.getLogger(l1l1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll11l(logger, l1ll11ll)
logger.info(l1l1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lllll1)
logger.info(l1l1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1llll11)
logger.info(l1l1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1l1)
l11l1l = get_major_version(VERSION)
l111 = l1l111l(l11l1l, l1l1l1l1)
logger.info(l1l1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11l1l)
logger.info(l1l1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111)
logger.info(l1l1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1ll1():
    if l1llll1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1ll():
    if l1llll1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll11l():
    l1l1ll1l = l1ll1ll1().read(4)
    while len(l1l1ll1l) == 4:
        l1l1llll = struct.unpack(l1l1 (u"ࠨࡀࡊࠤ࡫"), l1l1ll1l)[0]
        request = l1ll1ll1().read(l1l1llll).decode()
        logger.info(l1l1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1ll11(request)
        l1lll1l1(response)
        logger.info(l1l1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll1l = l1ll1ll1().read(4)
    logger.info(l1l1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1l1(message):
    message = json.dumps(message).encode()
    l1lll111 = struct.pack(l1l1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1ll().write(l1lll111)
    l1lll1ll().write(message)
    l1lll1ll().flush()
def l1l1ll11(request):
    if request:
        l1l1lll1 = json.loads(request)
    try:
        return {
            l1l1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l11,
            l1l1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1ll1,
            l1l1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1l1l
        }[l1l1lll1[l1l1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1lll1)
    except Exception as e:
        logger.error(l1l1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l11()
def l11l11(l1l1lll1=None):
    l1ll1111(l1l1lll1)
    l1l1l1ll = {l1l1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l()}
    l1l1l1ll[l1l1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l11l1(l111)
    return l1l1l1ll
def l1l1ll1(l1l1lll1):
    url = l1l1lll1[l1l1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l = url.split(l1l1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11ll1l(l1l, url)}
def l1l1l1l(l1l1lll1):
    try:
        l1l = l1llll1(l111)
        url = l1l1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l, l1l1lll1[l1l1 (u"ࠨࡣࡦࡸࠬࡻ")], l1l1lll1[l1l1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l, url))
        return {l1l1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11ll1l(l1l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1111(l1l1lll1):
    l1ll111l = l1l1 (u"࠭ࠧࢀ")
    if l1l1lll1:
        for name in l1l1lll1:
            if name in [l1l1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll111l += l1l1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1lll1[name]
    if l1ll111l: logger.info(l1ll111l[:-1])
def main():
    try:
        l1lll11()
        l1lll11l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()