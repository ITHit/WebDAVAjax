#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll = sys.version_info [0] == 2
l1l111 = 2048
l111 = 7
def l11 (l11l1):
    global l1111l
    l11l = ord (l11l1 [-1])
    l111ll = l11l1 [:-1]
    l1l11 = l11l % len (l111ll)
    l1l1l1 = l111ll [:l1l11] + l111ll [l1l11:]
    if l1lll:
        l1 = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    return eval (l1)
import json
import struct
from ll import *
l1lll11l = sys.version_info[0] == 2
l1l1l1ll = l11 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1lll = l11 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11 (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠹࠾࠴࠰ࠣࡅ")
l1ll11ll = l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1llll = l1ll1lll.replace(l11 (u"ࠧࠦࠢࡇ"), l11 (u"ࠨ࡟ࠣࡈ")) + l11 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1llll1l = {}
if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll111 = sys.argv[0]
        try:
            l1llll1l = l1lll11(l1ll111)
            l1ll1lll = l1llll1l[l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1llll1l[l11 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll11ll = l1llll1l[l11 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1llll = l1ll1lll.replace(l11 (u"ࠨࠠࠣࡏ"), l11 (u"ࠢࡠࠤࡐ")) + l11 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1l11 = os.path.join(os.environ.get(l11 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1llll)
elif platform.system() == l11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1111 = os.path.join(os.environ.get(l11 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll11ll.split(l11 (u"ࠨࠬࠣࡖ"))[0].replace(l11 (u"ࠢࠡࠤࡗ"), l11 (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll11 = l1ll1l1(l1ll1111 + l11 (u"ࠤ࠲࡙ࠦ"))
    l1ll1l11 = os.path.join(l1l1ll11, l1l1llll)
elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1111 = os.path.join(os.environ.get(l11 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll11ll.split(l11 (u"ࠨࠬࠣ࡝"))[0].replace(l11 (u"ࠢࠡࠤ࡞"), l11 (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll11 = l1ll1l1(l1ll1111 + l11 (u"ࠤ࠲ࠦࡠ"))
    l1ll1l11 = os.path.join(l1l1ll11, l1l1llll)
else:
    l1ll1l11 = os.path.join(l1l1llll)
logger = logging.getLogger(l11 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l1111(logger, l1ll1l11)
logger.info(l11 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1lll)
logger.info(l11 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll11ll)
logger.info(l11 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1ll)
l11ll = get_major_version(VERSION)
l111l = l1ll1ll(l11ll, l1l1l1ll)
logger.info(l11 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11ll)
logger.info(l11 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111l)
logger.info(l11 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll11l1():
    if l1lll11l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll111():
    if l1lll11l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1ll():
    l1lllll1 = l1ll11l1().read(4)
    while len(l1lllll1) == 4:
        l1l1lll1 = struct.unpack(l11 (u"ࠨࡀࡊࠤ࡫"), l1lllll1)[0]
        request = l1ll11l1().read(l1l1lll1).decode()
        logger.info(l11 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll1l1(request)
        l1ll1l1l(response)
        logger.info(l11 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lllll1 = l1ll11l1().read(4)
    logger.info(l11 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll1l1l(message):
    message = json.dumps(message).encode()
    l1l1l1l1 = struct.pack(l11 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll111().write(l1l1l1l1)
    l1lll111().write(message)
    l1lll111().flush()
def l1lll1l1(request):
    if request:
        l1llll11 = json.loads(request)
    try:
        return {
            l11 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l11,
            l11 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l11ll,
            l11 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lllll
        }[l1llll11[l11 (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll11)
    except Exception as e:
        logger.error(l11 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l11()
def l11l11(l1llll11=None):
    l1ll1ll1(l1llll11)
    l1l1ll1l = {l11 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll()}
    l1l1ll1l[l11 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1ll11l(l111l)
    return l1l1ll1l
def l1l11ll(l1llll11):
    url = l1llll11[l11 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1 = url.split(l11 (u"ࠬࡀࠧࡸ"))[0]
    return {l11 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l1ll(l1l1, url)}
def l1lllll(l1llll11):
    try:
        l1l1 = l111111(l111l)
        url = l11 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1, l1llll11[l11 (u"ࠨࡣࡦࡸࠬࡻ")], l1llll11[l11 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1, url))
        return {l11 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l1ll(l1l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1ll1(l1llll11):
    l1ll111l = l11 (u"࠭ࠧࢀ")
    if l1llll11:
        for name in l1llll11:
            if name in [l11 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll111l += l11 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll11[name]
    if l1ll111l: logger.info(l1ll111l[:-1])
def main():
    try:
        l11l1l1()
        l1lll1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()