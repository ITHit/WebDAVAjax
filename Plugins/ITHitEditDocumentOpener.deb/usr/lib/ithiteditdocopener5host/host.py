#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll11 = 7
def l1111l (l1llll):
    global l111l
    l11l11 = ord (l1llll [-1])
    l11ll = l1llll [:-1]
    l1l11 = l11l11 % len (l11ll)
    l1ll = l11ll [:l1l11] + l11ll [l1l11:]
    if l1l111:
        l1l1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    return eval (l1l1l1)
import json
import struct
from l1ll1 import *
l1lll1l1 = sys.version_info [0] == 2
l1ll1l11 = l1111l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1llll11 = l1111l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1111l (u"ࠥ࠹࠳࠸࠰࠯࠷࠹࠷࠶࠴࠰ࠣࡅ")
l1ll1ll1 = l1111l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll111l = l1llll11.replace(l1111l (u"ࠧࠦࠢࡇ"), l1111l (u"ࠨ࡟ࠣࡈ")) + l1111l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll111 = {}
if platform.system() == l1111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1111l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11ll1l = sys.argv[0]
        try:
            l1lll111 = l1ll1ll(l11ll1l)
            l1llll11 = l1lll111[l1111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll111[l1111l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1ll1 = l1lll111[l1111l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll111l = l1llll11.replace(l1111l (u"ࠨࠠࠣࡏ"), l1111l (u"ࠢࡠࠤࡐ")) + l1111l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1111 = os.path.join(os.environ.get(l1111l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll111l)
elif platform.system() == l1111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll11ll = os.path.join(os.environ.get(l1111l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1111l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1ll1.split(l1111l (u"ࠨࠬࠣࡖ"))[0].replace(l1111l (u"ࠢࠡࠤࡗ"), l1111l (u"ࠣࡡࠥࡘ")).lower())
    l1lllll1=l11111(l1ll11ll + l1111l (u"ࠤ࠲࡙ࠦ"))
    l1ll1111 = os.path.join(l1lllll1, l1ll111l)
elif platform.system() == l1111l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll11ll = os.path.join(os.environ.get(l1111l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1111l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1ll1.split(l1111l (u"ࠨࠬࠣ࡝"))[0].replace(l1111l (u"ࠢࠡࠤ࡞"), l1111l (u"ࠣࡡࠥ࡟")).lower())
    l1lllll1=l11111(l1ll11ll + l1111l (u"ࠤ࠲ࠦࡠ"))
    l1ll1111 = os.path.join(l1lllll1, l1ll111l)
else:
    l1ll1111 = os.path.join( l1ll111l)
logger = logging.getLogger(l1111l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111ll1(logger, l1ll1111)
logger.info(l1111l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1111l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1llll11)
logger.info(l1111l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1111l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1ll1)
logger.info(l1111l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1l11)
l11lll = get_major_version(VERSION)
l111ll = l1lll11(l11lll, l1ll1l11)
logger.info(l1111l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11lll)
logger.info(l1111l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111ll)
def l1ll1l1l():
    if l1lll1l1:
        l1ll11l1 = sys.stdin.read(4)
    else:
        l1ll11l1 = bytes(sys.stdin.read(4).encode())
    while len(l1ll11l1) == 4:
        l1lll1ll = struct.unpack(l1111l (u"ࠦ࡮ࠨࡩ"), l1ll11l1)[0]
        request = sys.stdin.read(l1lll1ll)
        logger.info(l1111l (u"ࠧࡍ࡯ࡵࠢࡵࡩࡶࡻࡥࡴࡶࠣ࠾ࢀ࠶ࡽࠣࡪ").format(request))
        response = l1ll1lll(request)
        l1l1llll(response)
        logger.info(l1111l (u"ࠨࡓࡦࡰࡷࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠺ࡼ࠲ࢀࠦ࡫").format(response))
        l1ll11l1 = sys.stdin.read(4)
def l1ll1lll(request):
    if request:
        l1lll11l = json.loads(request)
    try:
        return {
            l1111l (u"ࠧࡨࡧࡷࡣࡵࡸ࡯ࡵࡱࡦࡳࡱࡹࠧ࡬"): l11l1l,
            l1111l (u"ࠨࡱࡳࡩࡳࡥࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࡭"): l1111ll,
            l1111l (u"ࠩ࡬ࡲ࡮ࡺ࡟ࡢࡰࡲࡲࠬ࡮"): l1l11ll
        }[l1lll11l[l1111l (u"ࠥࡥࡨࡺࠢ࡯")]](l1lll11l)
    except Exception as e:
        logger.error(l1111l (u"ࠫࡸࡽࡩࡵࡥ࡫ࡣࡦࡩࡴࡪࡱࡱࡷࠥ࡫ࡲࡳࡱࡵ࠾ࠥ࠭ࡰ") + str(e))
        return l11l1l()
def l11l1l(l1lll11l=None):
    l1llll1l = {l1111l (u"ࠬࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࡔࡥ࡫ࡩࡲ࡫ࡳࠨࡱ"): l1l1l()}
    l1llll1l[l1111l (u"ࠨࡰࡳࡱࡷࡳࡨࡵ࡬ࡴࠤࡲ")] = l1ll111(l111ll)
    response = json.dumps(l1llll1l)
    return response
def l1111ll(l1lll11l):
    url = l1lll11l[l1111l (u"ࠢࡶࡴ࡯ࠦࡳ")]
    l111l1 = url.split(l1111l (u"ࠨ࠼ࠪࡴ"))[0]
    l1llll1l = {l1111l (u"ࠩࡦࡱࡩࡥࡲࡦࡵࡸࡰࡹ࠭ࡵ"): l111111(l111l1, url)}
    return json.dumps(l1llll1l)
def l1l11ll(l1lll11l):
    try:
        l111l1 = l1l11l1(l111ll)
        url = l1111l (u"ࡵࠫࠪࡹ࠺ࡢࡥࡷࡁࠪࡹ࠻ࡊࡶࡨࡱ࡚ࡸ࡬࠾ࡐࡒࡒࡊࡁࠥࡴࠩࡶ") % (l111l1, l1lll11l[l1111l (u"ࠫࡦࡩࡴࠨࡷ")], l1lll11l[l1111l (u"ࠬࡶࡡࡳࡣࡰࡷࠬࡸ")])
        logger.debug(l1111l (u"ࠨࡲࡶࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰ࠭࠭ࠥࡴࠩ࠯ࠤࠬࠫࡳࠨࠫࠥࡹ") % (l111l1, url))
        l1llll1l = {l1111l (u"ࠧࡤ࡯ࡧࡣࡷ࡫ࡳࡶ࡮ࡷࠫࡺ"): l111111(l111l1, url)}
    except Exception as e:
        logger.error(str(e))
        l1llll1l = {l1111l (u"ࠨࡥࡰࡨࡤࡸࡥࡴࡷ࡯ࡸࠬࡻ"): str(e)}
    return json.dumps(l1llll1l)
def l1l1llll(message):
    if l1lll1l1:
        sys.stdout.write(struct.pack(l1111l (u"ࠤࡌࠦࡼ"), len(message)))
    else:
        sys.stdout.buffer.write(struct.pack(l1111l (u"ࠥࡍࠧࡽ"), len(message)))
    sys.stdout.write(message)
    sys.stdout.flush()
def main():
    try:
        l1l1111()
        l1ll1l1l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1111l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨࡾ"):
    main()