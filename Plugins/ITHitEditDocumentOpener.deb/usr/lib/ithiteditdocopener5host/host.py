#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
l1ll1 = 7
def l1llll (l11):
    global l111
    l1lll = ord (l11 [-1])
    l111l1 = l11 [:-1]
    l11ll = l1lll % len (l111l1)
    l1l = l111l1 [:l11ll] + l111l1 [l11ll:]
    if l1ll1l:
        l111l = l111ll () .join ([unichr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    return eval (l111l)
import json
import struct
from l1 import *
l1ll1l1l = sys.version_info[0] == 2
l1lll111 = l1llll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l11 = l1llll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1llll (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠵࠺࠴࠰ࠣࡅ")
l1l1llll = l1llll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1111 = l1ll1l11.replace(l1llll (u"ࠧࠦࠢࡇ"), l1llll (u"ࠨ࡟ࠣࡈ")) + l1llll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11ll = {}
if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1llll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11ll11 = sys.argv[0]
        try:
            l1ll11ll = l1l1lll(l11ll11)
            l1ll1l11 = l1ll11ll[l1llll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11ll[l1llll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1llll = l1ll11ll[l1llll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1111 = l1ll1l11.replace(l1llll (u"ࠨࠠࠣࡏ"), l1llll (u"ࠢࡠࠤࡐ")) + l1llll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1l1 = os.path.join(os.environ.get(l1llll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1111)
elif platform.system() == l1llll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lll1l1 = os.path.join(os.environ.get(l1llll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1llll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1llll.split(l1llll (u"ࠨࠬࠣࡖ"))[0].replace(l1llll (u"ࠢࠡࠤࡗ"), l1llll (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll1l = l1l1ll1(l1lll1l1 + l1llll (u"ࠤ࠲࡙ࠦ"))
    l1l1l1l1 = os.path.join(l1l1ll1l, l1ll1111)
elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lll1l1 = os.path.join(os.environ.get(l1llll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1llll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1llll.split(l1llll (u"ࠨࠬࠣ࡝"))[0].replace(l1llll (u"ࠢࠡࠤ࡞"), l1llll (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll1l = l1l1ll1(l1lll1l1 + l1llll (u"ࠤ࠲ࠦࡠ"))
    l1l1l1l1 = os.path.join(l1l1ll1l, l1ll1111)
else:
    l1l1l1l1 = os.path.join(l1ll1111)
logger = logging.getLogger(l1llll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11lll1(logger, l1l1l1l1)
logger.info(l1llll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1llll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l11)
logger.info(l1llll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1llll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1llll)
logger.info(l1llll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll111)
l1l111 = get_major_version(VERSION)
l1111l = l111l1l(l1l111, l1lll111)
logger.info(l1llll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l111)
logger.info(l1llll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111l)
logger.info(l1llll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1llll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1ll1():
    if l1ll1l1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lllll1():
    if l1ll1l1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1ll():
    l1ll11l1 = l1ll1ll1().read(4)
    while len(l1ll11l1) == 4:
        l1l1l1ll = struct.unpack(l1llll (u"ࠨࡀࡊࠤ࡫"), l1ll11l1)[0]
        request = l1ll1ll1().read(l1l1l1ll).decode()
        logger.info(l1llll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll11(request)
        l1l1lll1(response)
        logger.info(l1llll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll11l1 = l1ll1ll1().read(4)
    logger.info(l1llll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1lll1(message):
    message = json.dumps(message).encode()
    l1llll1l = struct.pack(l1llll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lllll1().write(l1llll1l)
    l1lllll1().write(message)
    l1lllll1().flush()
def l1llll11(request):
    if request:
        l1l1ll11 = json.loads(request)
    try:
        return {
            l1llll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l,
            l1llll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1ll1ll,
            l1llll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1111ll
        }[l1l1ll11[l1llll (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1ll11)
    except Exception as e:
        logger.error(l1llll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l()
def l11l(l1l1ll11=None):
    l1lll11l(l1l1ll11)
    l1ll1lll = {l1llll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1()}
    l1ll1lll[l1llll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l11l(l1111l)
    return l1ll1lll
def l1ll1ll(l1l1ll11):
    url = l1l1ll11[l1llll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1l1 = url.split(l1llll (u"ࠬࡀࠧࡸ"))[0]
    return {l1llll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11111l(l1l1l1, url)}
def l1111ll(l1l1ll11):
    try:
        l1l1l1 = l111lll(l1111l)
        url = l1llll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1l1, l1l1ll11[l1llll (u"ࠨࡣࡦࡸࠬࡻ")], l1l1ll11[l1llll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1llll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1l1, url))
        return {l1llll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11111l(l1l1l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1llll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll11l(l1l1ll11):
    l1ll111l = l1llll (u"࠭ࠧࢀ")
    if l1l1ll11:
        for name in l1l1ll11:
            if name in [l1llll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1llll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll111l += l1llll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1ll11[name]
    if l1ll111l: logger.info(l1ll111l[:-1])
def main():
    try:
        l111111()
        l1lll1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1llll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()