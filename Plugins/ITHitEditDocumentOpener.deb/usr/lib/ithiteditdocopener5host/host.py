#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l11 = 2048
l1ll1l = 7
def l1111 (l111ll):
    global l11l11
    l1l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l1l1 % len (l1llll)
    l1111l = l1llll [:l11l] + l1llll [l11l:]
    if l1:
        l1lll = l11ll () .join ([unichr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l11 - (l1ll1 + l1l1) % l1ll1l) for l1ll1, char in enumerate (l1111l)])
    return eval (l1lll)
import json
import struct
from l11ll1 import *
l1lll1ll = sys.version_info[0] == 2
l1ll1lll = l1111 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll111 = l1111 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1111 (u"ࠥ࠺࠳࠶࠮࠹࠻࠴࠵࠳࠶ࠢࡅ")
l1ll1l11 = l1111 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1ll1 = l1lll111.replace(l1111 (u"ࠧࠦࠢࡇ"), l1111 (u"ࠨ࡟ࠣࡈ")) + l1111 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1ll11 = {}
if platform.system() == l1111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1111 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll1ll = sys.argv[0]
        try:
            l1l1ll11 = l111111(l1ll1ll)
            l1lll111 = l1l1ll11[l1111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1ll11[l1111 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1l11 = l1l1ll11[l1111 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1ll1 = l1lll111.replace(l1111 (u"ࠨࠠࠣࡏ"), l1111 (u"ࠢࡠࠤࡐ")) + l1111 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll1l1l = os.path.join(os.environ.get(l1111 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1ll1)
elif platform.system() == l1111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1l1l1 = os.path.join(os.environ.get(l1111 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1111 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1l11.split(l1111 (u"ࠨࠬࠣࡖ"))[0].replace(l1111 (u"ࠢࠡࠤࡗ"), l1111 (u"ࠣࡡࠥࡘ")).lower())
    l1ll1111 = l11l11l(l1l1l1l1 + l1111 (u"ࠤ࠲࡙ࠦ"))
    l1ll1l1l = os.path.join(l1ll1111, l1ll1ll1)
elif platform.system() == l1111 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1l1l1 = os.path.join(os.environ.get(l1111 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1111 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1l11.split(l1111 (u"ࠨࠬࠣ࡝"))[0].replace(l1111 (u"ࠢࠡࠤ࡞"), l1111 (u"ࠣࡡࠥ࡟")).lower())
    l1ll1111 = l11l11l(l1l1l1l1 + l1111 (u"ࠤ࠲ࠦࡠ"))
    l1ll1l1l = os.path.join(l1ll1111, l1ll1ll1)
else:
    l1ll1l1l = os.path.join(l1ll1ll1)
logger = logging.getLogger(l1111 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111lll(logger, l1ll1l1l)
logger.info(l1111 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1111 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll111)
logger.info(l1111 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1111 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1l11)
logger.info(l1111 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1lll)
l111l = get_major_version(VERSION)
l1l1ll = l11l1l1(l111l, l1ll1lll)
logger.info(l1111 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111l)
logger.info(l1111 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l1ll)
logger.info(l1111 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1111 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll111l():
    if l1lll1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1llll11():
    if l1lll1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll11l():
    l1lllll1 = l1ll111l().read(4)
    while len(l1lllll1) == 4:
        l1l1l1ll = struct.unpack(l1111 (u"ࠨࡀࡊࠤ࡫"), l1lllll1)[0]
        request = l1ll111l().read(l1l1l1ll).decode()
        logger.info(l1111 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll11l1(request)
        l1l1lll1(response)
        logger.info(l1111 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lllll1 = l1ll111l().read(4)
    logger.info(l1111 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1lll1(message):
    message = json.dumps(message).encode()
    l1ll11ll = struct.pack(l1111 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1llll11().write(l1ll11ll)
    l1llll11().write(message)
    l1llll11().flush()
def l1ll11l1(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l1111 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l111,
            l1111 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1ll1,
            l1111 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lll1l
        }[l1llll1l[l1111 (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l1111 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l111()
def l111(l1llll1l=None):
    l1l1ll1l(l1llll1l)
    l1l1llll = {l1111 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11()}
    l1l1llll[l1111 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11ll1l(l1l1ll)
    return l1l1llll
def l1l1ll1(l1llll1l):
    url = l1llll1l[l1111 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1ll = url.split(l1111 (u"ࠬࡀࠧࡸ"))[0]
    return {l1111 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l111(l1ll, url)}
def l1lll1l(l1llll1l):
    try:
        l1ll = l1l1l1l(l1l1ll)
        url = l1111 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1ll, l1llll1l[l1111 (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l1111 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1111 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1ll, url))
        return {l1111 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l111(l1ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1111 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1ll1l(l1llll1l):
    l1lll1l1 = l1111 (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l1111 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1111 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll1l1 += l1111 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1lll1l1: logger.info(l1lll1l1[:-1])
def main():
    try:
        l1llllll()
        l1lll11l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1111 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()