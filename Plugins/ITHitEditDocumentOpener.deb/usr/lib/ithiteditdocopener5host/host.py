#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1l11l = 2048
l1lll = 7
def l11ll (l1111):
    global l1l11
    l111 = ord (l1111 [-1])
    l1ll1 = l1111 [:-1]
    l1llll = l111 % len (l1ll1)
    l11 = l1ll1 [:l1llll] + l1ll1 [l1llll:]
    if l1ll:
        l1 = l11l1l () .join ([unichr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    return eval (l1)
import json
import struct
from l11l11 import *
l1l1lll1 = sys.version_info[0] == 2
l1ll11ll = l11ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1ll11 = l11ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠸࠺࠴࠰ࠣࡅ")
l1ll1111 = l11ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1ll1 = l1l1ll11.replace(l11ll (u"ࠧࠦࠢࡇ"), l11ll (u"ࠨ࡟ࠣࡈ")) + l11ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1ll = {}
if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11l111 = sys.argv[0]
        try:
            l1lll1ll = l1l1l1l(l11l111)
            l1l1ll11 = l1lll1ll[l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1ll[l11ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1111 = l1lll1ll[l11ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1ll1 = l1l1ll11.replace(l11ll (u"ࠨࠠࠣࡏ"), l11ll (u"ࠢࡠࠤࡐ")) + l11ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll11 = os.path.join(os.environ.get(l11ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1ll1)
elif platform.system() == l11ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1llll = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1111.split(l11ll (u"ࠨࠬࠣࡖ"))[0].replace(l11ll (u"ࠢࠡࠤࡗ"), l11ll (u"ࠣࡡࠥࡘ")).lower())
    l1lll111 = l1l111l(l1l1llll + l11ll (u"ࠤ࠲࡙ࠦ"))
    l1llll11 = os.path.join(l1lll111, l1ll1ll1)
elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1llll = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1111.split(l11ll (u"ࠨࠬࠣ࡝"))[0].replace(l11ll (u"ࠢࠡࠤ࡞"), l11ll (u"ࠣࡡࠥ࡟")).lower())
    l1lll111 = l1l111l(l1l1llll + l11ll (u"ࠤ࠲ࠦࡠ"))
    l1llll11 = os.path.join(l1lll111, l1ll1ll1)
else:
    l1llll11 = os.path.join(l1ll1ll1)
logger = logging.getLogger(l11ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll1l1(logger, l1llll11)
logger.info(l11ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1ll11)
logger.info(l11ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1111)
logger.info(l11ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll11ll)
l1111l = get_major_version(VERSION)
l11l = l1lll11(l1111l, l1ll11ll)
logger.info(l11ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1111l)
logger.info(l11ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11l)
logger.info(l11ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1l1ll1l():
    if l1l1lll1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lllll1():
    if l1l1lll1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1l1ll():
    l1ll11l1 = l1l1ll1l().read(4)
    while len(l1ll11l1) == 4:
        l1ll1l1l = struct.unpack(l11ll (u"ࠨࡀࡊࠤ࡫"), l1ll11l1)[0]
        request = l1l1ll1l().read(l1ll1l1l).decode()
        logger.info(l11ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1lll(request)
        l1llll1l(response)
        logger.info(l11ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll11l1 = l1l1ll1l().read(4)
    logger.info(l11ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1llll1l(message):
    message = json.dumps(message).encode()
    l1lll1l1 = struct.pack(l11ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lllll1().write(l1lll1l1)
    l1lllll1().write(message)
    l1lllll1().flush()
def l1ll1lll(request):
    if request:
        l1lll11l = json.loads(request)
    try:
        return {
            l11ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): ll,
            l11ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11111,
            l11ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11ll11
        }[l1lll11l[l11ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll11l)
    except Exception as e:
        logger.error(l11ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return ll()
def ll(l1lll11l=None):
    l1ll111l(l1lll11l)
    l1l1l1l1 = {l11ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111l()}
    l1l1l1l1[l11ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l111lll(l11l)
    return l1l1l1l1
def l11111(l1lll11l):
    url = l1lll11l[l11ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l1l1 = url.split(l11ll (u"ࠬࡀࠧࡸ"))[0]
    return {l11ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l11l(l1l1l1, url)}
def l11ll11(l1lll11l):
    try:
        l1l1l1 = l1l11l1(l11l)
        url = l11ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l1l1, l1lll11l[l11ll (u"ࠨࡣࡦࡸࠬࡻ")], l1lll11l[l11ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l1l1, url))
        return {l11ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l11l(l1l1l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll111l(l1lll11l):
    l1ll1l11 = l11ll (u"࠭ࠧࢀ")
    if l1lll11l:
        for name in l1lll11l:
            if name in [l11ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l11 += l11ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll11l[name]
    if l1ll1l11: logger.info(l1ll1l11[:-1])
def main():
    try:
        l1llll1()
        l1l1l1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()