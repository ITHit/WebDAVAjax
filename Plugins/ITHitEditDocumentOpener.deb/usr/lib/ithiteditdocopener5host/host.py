#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll1 = 2048
l11l = 7
def l1l1l (l111ll):
    global l1l1
    l1l11 = ord (l111ll [-1])
    l11l11 = l111ll [:-1]
    l1111l = l1l11 % len (l11l11)
    l1l1ll = l11l11 [:l1111l] + l11l11 [l1111l:]
    if l1ll11:
        l111 = l1l111 () .join ([unichr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    return eval (l111)
import json
import struct
from l11lll import *
l1ll11l1 = sys.version_info[0] == 2
l1ll1lll = l1l1l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll1l1 = l1l1l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l1l (u"ࠥ࠺࠳࠶࠮࠹࠻࠴࠻࠳࠶ࠢࡅ")
l1l1llll = l1l1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1l1ll = l1lll1l1.replace(l1l1l (u"ࠧࠦࠢࡇ"), l1l1l (u"ࠨ࡟ࠣࡈ")) + l1l1l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11ll = {}
if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l1l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11llll = sys.argv[0]
        try:
            l1ll11ll = l1l11l1(l11llll)
            l1lll1l1 = l1ll11ll[l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11ll[l1l1l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1llll = l1ll11ll[l1l1l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1l1ll = l1lll1l1.replace(l1l1l (u"ࠨࠠࠣࡏ"), l1l1l (u"ࠢࡠࠤࡐ")) + l1l1l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1l1 = os.path.join(os.environ.get(l1l1l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1l1ll)
elif platform.system() == l1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1ll11 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l1l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1llll.split(l1l1l (u"ࠨࠬࠣࡖ"))[0].replace(l1l1l (u"ࠢࠡࠤࡗ"), l1l1l (u"ࠣࡡࠥࡘ")).lower())
    l1llll11 = l111111(l1l1ll11 + l1l1l (u"ࠤ࠲࡙ࠦ"))
    l1l1l1l1 = os.path.join(l1llll11, l1l1l1ll)
elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1ll11 = os.path.join(os.environ.get(l1l1l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l1l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1llll.split(l1l1l (u"ࠨࠬࠣ࡝"))[0].replace(l1l1l (u"ࠢࠡࠤ࡞"), l1l1l (u"ࠣࡡࠥ࡟")).lower())
    l1llll11 = l111111(l1l1ll11 + l1l1l (u"ࠤ࠲ࠦࡠ"))
    l1l1l1l1 = os.path.join(l1llll11, l1l1l1ll)
else:
    l1l1l1l1 = os.path.join(l1l1l1ll)
logger = logging.getLogger(l1l1l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111lll(logger, l1l1l1l1)
logger.info(l1l1l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l1l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll1l1)
logger.info(l1l1l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l1l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1llll)
logger.info(l1l1l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1lll)
l1lll1 = get_major_version(VERSION)
l1111 = l11111(l1lll1, l1ll1lll)
logger.info(l1l1l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1lll1)
logger.info(l1l1l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111)
logger.info(l1l1l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l1l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1ll11l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll1ll1():
    if l1ll11l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1lll1():
    l1ll1111 = l1lll11l().read(4)
    while len(l1ll1111) == 4:
        l1ll1l11 = struct.unpack(l1l1l (u"ࠨࡀࡊࠤ࡫"), l1ll1111)[0]
        request = l1lll11l().read(l1ll1l11).decode()
        logger.info(l1l1l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll111l(request)
        l1lll1ll(response)
        logger.info(l1l1l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1111 = l1lll11l().read(4)
    logger.info(l1l1l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1ll(message):
    message = json.dumps(message).encode()
    l1lllll1 = struct.pack(l1l1l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll1ll1().write(l1lllll1)
    l1ll1ll1().write(message)
    l1ll1ll1().flush()
def l1ll111l(request):
    if request:
        l1ll1l1l = json.loads(request)
    try:
        return {
            l1l1l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11l1l,
            l1l1l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11l1l1,
            l1l1l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11111l
        }[l1ll1l1l[l1l1l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1l1l)
    except Exception as e:
        logger.error(l1l1l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11l1l()
def l11l1l(l1ll1l1l=None):
    l1llll1l(l1ll1l1l)
    l1lll111 = {l1l1l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1lll()}
    l1lll111[l1l1l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l11l1ll(l1111)
    return l1lll111
def l11l1l1(l1ll1l1l):
    url = l1ll1l1l[l1l1l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    ll = url.split(l1l1l (u"ࠬࡀࠧࡸ"))[0]
    return {l1l1l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111ll1(ll, url)}
def l11111l(l1ll1l1l):
    try:
        ll = l111l11(l1111)
        url = l1l1l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (ll, l1ll1l1l[l1l1l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1l1l[l1l1l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l1l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (ll, url))
        return {l1l1l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111ll1(ll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l1l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll1l(l1ll1l1l):
    l1l1ll1l = l1l1l (u"࠭ࠧࢀ")
    if l1ll1l1l:
        for name in l1ll1l1l:
            if name in [l1l1l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l1l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1ll1l += l1l1l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1l1l[name]
    if l1l1ll1l: logger.info(l1l1ll1l[:-1])
def main():
    try:
        l111l1l()
        l1l1lll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()