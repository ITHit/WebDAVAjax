#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1111l = 2048
ll = 7
def l1ll (l11l):
    global l1l111
    l1lll = ord (l11l [-1])
    l1l1l1 = l11l [:-1]
    l111l1 = l1lll % len (l1l1l1)
    l11l1 = l1l1l1 [:l111l1] + l1l1l1 [l111l1:]
    if l111l:
        l1l1ll = l111 () .join ([unichr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    return eval (l1l1ll)
import json
import struct
from l11l1l import *
l1lll1l1 = sys.version_info[0] == 2
l1l1llll = l1ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l1l = l1ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll (u"ࠥ࠹࠳࠸࠱࠯࠷࠻࠽࠷࠴࠰ࠣࡅ")
l1l1l1l1 = l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1ll1l = l1ll1l1l.replace(l1ll (u"ࠧࠦࠢࡇ"), l1ll (u"ࠨ࡟ࠣࡈ")) + l1ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll11ll = {}
if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11lll1 = sys.argv[0]
        try:
            l1ll11ll = l1lll1l(l11lll1)
            l1ll1l1l = l1ll11ll[l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll11ll[l1ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1l1l1 = l1ll11ll[l1ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1ll1l = l1ll1l1l.replace(l1ll (u"ࠨࠠࠣࡏ"), l1ll (u"ࠢࡠࠤࡐ")) + l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1lll11l = os.path.join(os.environ.get(l1ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1ll1l)
elif platform.system() == l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lllll1 = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1l1l1.split(l1ll (u"ࠨࠬࠣࡖ"))[0].replace(l1ll (u"ࠢࠡࠤࡗ"), l1ll (u"ࠣࡡࠥࡘ")).lower())
    l1lll1ll = l11111(l1lllll1 + l1ll (u"ࠤ࠲࡙ࠦ"))
    l1lll11l = os.path.join(l1lll1ll, l1l1ll1l)
elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lllll1 = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1l1l1.split(l1ll (u"ࠨࠬࠣ࡝"))[0].replace(l1ll (u"ࠢࠡࠤ࡞"), l1ll (u"ࠣࡡࠥ࡟")).lower())
    l1lll1ll = l11111(l1lllll1 + l1ll (u"ࠤ࠲ࠦࡠ"))
    l1lll11l = os.path.join(l1lll1ll, l1l1ll1l)
else:
    l1lll11l = os.path.join(l1l1ll1l)
logger = logging.getLogger(l1ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l11l(logger, l1lll11l)
logger.info(l1ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l1l)
logger.info(l1ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1l1l1)
logger.info(l1ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1llll)
l111ll = get_major_version(VERSION)
l1111 = l1lllll(l111ll, l1l1llll)
logger.info(l1ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l111ll)
logger.info(l1ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111)
logger.info(l1ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll1ll1():
    if l1lll1l1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1ll():
    if l1lll1l1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1llll1l():
    l1lll111 = l1ll1ll1().read(4)
    while len(l1lll111) == 4:
        l1ll111l = struct.unpack(l1ll (u"ࠨࡀࡊࠤ࡫"), l1lll111)[0]
        request = l1ll1ll1().read(l1ll111l).decode()
        logger.info(l1ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1lll(request)
        l1l1ll11(response)
        logger.info(l1ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll111 = l1ll1ll1().read(4)
    logger.info(l1ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1ll11(message):
    message = json.dumps(message).encode()
    l1ll1l11 = struct.pack(l1ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1ll().write(l1ll1l11)
    l1l1l1ll().write(message)
    l1l1l1ll().flush()
def l1ll1lll(request):
    if request:
        l1l1lll1 = json.loads(request)
    try:
        return {
            l1ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l1l,
            l1ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l111l11,
            l1ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11111l
        }[l1l1lll1[l1ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1lll1)
    except Exception as e:
        logger.error(l1ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l1l()
def l1l1l(l1l1lll1=None):
    l1llll11(l1l1lll1)
    l1ll11l1 = {l1ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1lll1()}
    l1ll11l1[l1ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1l11(l1111)
    return l1ll11l1
def l111l11(l1l1lll1):
    url = l1l1lll1[l1ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l11l = url.split(l1ll (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l11l1(l1l11l, url)}
def l11111l(l1l1lll1):
    try:
        l1l11l = l11l111(l1111)
        url = l1ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l11l, l1l1lll1[l1ll (u"ࠨࡣࡦࡸࠬࡻ")], l1l1lll1[l1ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l11l, url))
        return {l1ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l11l1(l1l11l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll11(l1l1lll1):
    l1ll1111 = l1ll (u"࠭ࠧࢀ")
    if l1l1lll1:
        for name in l1l1lll1:
            if name in [l1ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1111 += l1ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1lll1[name]
    if l1ll1111: logger.info(l1ll1111[:-1])
def main():
    try:
        l11llll()
        l1llll1l()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()