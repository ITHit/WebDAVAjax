#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1ll11 = 2048
l1llll = 7
def l1 (l11lll):
    global l1l1
    l11ll1 = ord (l11lll [-1])
    l111l = l11lll [:-1]
    l1l = l11ll1 % len (l111l)
    l111ll = l111l [:l1l] + l111l [l1l:]
    if l11l1:
        l1111 = l1l1l () .join ([unichr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    return eval (l1111)
import json
import struct
from l1l1l1 import *
l1lll1ll = sys.version_info[0] == 2
l1ll11ll = l1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1lll = l1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1 (u"ࠥ࠹࠳࠸࠰࠯࠷࠹࠹࠻࠴࠰ࠣࡅ")
l1l1ll1l = l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll11l1 = l1ll1lll.replace(l1 (u"ࠧࠦࠢࡇ"), l1 (u"ࠨ࡟ࠣࡈ")) + l1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll111l = {}
if platform.system() == l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1ll11l = sys.argv[0]
        try:
            l1ll111l = l11lll1(l1ll11l)
            l1ll1lll = l1ll111l[l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll111l[l1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll1l = l1ll111l[l1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll11l1 = l1ll1lll.replace(l1 (u"ࠨࠠࠣࡏ"), l1 (u"ࠢࡠࠤࡐ")) + l1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll11 = os.path.join(os.environ.get(l1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll11l1)
elif platform.system() == l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1111 = os.path.join(os.environ.get(l1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll1l.split(l1 (u"ࠨࠬࠣࡖ"))[0].replace(l1 (u"ࠢࠡࠤࡗ"), l1 (u"ࠣࡡࠥࡘ")).lower())
    l1l1llll = l1111l1(l1ll1111 + l1 (u"ࠤ࠲࡙ࠦ"))
    l1l1ll11 = os.path.join(l1l1llll, l1ll11l1)
elif platform.system() == l1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1111 = os.path.join(os.environ.get(l1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll1l.split(l1 (u"ࠨࠬࠣ࡝"))[0].replace(l1 (u"ࠢࠡࠤ࡞"), l1 (u"ࠣࡡࠥ࡟")).lower())
    l1l1llll = l1111l1(l1ll1111 + l1 (u"ࠤ࠲ࠦࡠ"))
    l1l1ll11 = os.path.join(l1l1llll, l1ll11l1)
else:
    l1l1ll11 = os.path.join(l1ll11l1)
logger = logging.getLogger(l1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l1l1l(logger, l1l1ll11)
logger.info(l1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1lll)
logger.info(l1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll1l)
logger.info(l1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll11ll)
l11l11 = get_major_version(VERSION)
l1lll = l111lll(l11l11, l1ll11ll)
logger.info(l1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11l11)
logger.info(l1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll)
logger.info(l1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1llll1l():
    if l1lll1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lllll1():
    if l1lll1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1llll11():
    l1l1lll1 = l1llll1l().read(4)
    while len(l1l1lll1) == 4:
        l1lll11l = struct.unpack(l1 (u"ࠨࡀࡊࠤ࡫"), l1l1lll1)[0]
        request = l1llll1l().read(l1lll11l).decode()
        logger.info(l1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1l1l(request)
        l1lll111(response)
        logger.info(l1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1lll1 = l1llll1l().read(4)
    logger.info(l1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll111(message):
    message = json.dumps(message).encode()
    l1l1l1ll = struct.pack(l1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lllll1().write(l1l1l1ll)
    l1lllll1().write(message)
    l1lllll1().flush()
def l1ll1l1l(request):
    if request:
        l1l1l1l1 = json.loads(request)
    try:
        return {
            l1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1lll1,
            l1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l11ll11,
            l1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1lllll
        }[l1l1l1l1[l1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1l1l1)
    except Exception as e:
        logger.error(l1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1lll1()
def l1lll1(l1l1l1l1=None):
    l1ll1l11(l1l1l1l1)
    l1lll1l1 = {l1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111()}
    l1lll1l1[l1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1llll1(l1lll)
    return l1lll1l1
def l11ll11(l1l1l1l1):
    url = l1l1l1l1[l1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l11l = url.split(l1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1lll11(l1l11l, url)}
def l1lllll(l1l1l1l1):
    try:
        l1l11l = l11l111(l1lll)
        url = l1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l11l, l1l1l1l1[l1 (u"ࠨࡣࡦࡸࠬࡻ")], l1l1l1l1[l1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l11l, url))
        return {l1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1lll11(l1l11l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll1l11(l1l1l1l1):
    l1ll1ll1 = l1 (u"࠭ࠧࢀ")
    if l1l1l1l1:
        for name in l1l1l1l1:
            if name in [l1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1ll1 += l1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1l1l1[name]
    if l1ll1ll1: logger.info(l1ll1ll1[:-1])
def main():
    try:
        l1l1111()
        l1llll11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()