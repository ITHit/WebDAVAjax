#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1l1ll = 2048
l111 = 7
def l111l (l111l1):
    global l1lll
    l11l11 = ord (l111l1 [-1])
    l1111 = l111l1 [:-1]
    l11l = l11l11 % len (l1111)
    l1l1l1 = l1111 [:l11l] + l1111 [l11l:]
    if l11ll:
        l1l11l = l11lll () .join ([unichr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l1l1ll - (l11ll1 + l11l11) % l111) for l11ll1, char in enumerate (l1l1l1)])
    return eval (l1l11l)
import json
import struct
from ll import *
l1ll1111 = sys.version_info[0] == 2
l1l1l1ll = l111l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll11ll = l111l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l111l (u"ࠥ࠺࠳࠶࠮࠹࠹࠶࠷࠳࠶ࠢࡅ")
l1l1llll = l111l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1llll1l = l1ll11ll.replace(l111l (u"ࠧࠦࠢࡇ"), l111l (u"ࠨ࡟ࠣࡈ")) + l111l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1lll = {}
if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l111l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11ll11 = sys.argv[0]
        try:
            l1ll1lll = l111lll(l11ll11)
            l1ll11ll = l1ll1lll[l111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1lll[l111l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1llll = l1ll1lll[l111l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1llll1l = l1ll11ll.replace(l111l (u"ࠨࠠࠣࡏ"), l111l (u"ࠢࡠࠤࡐ")) + l111l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1lll1 = os.path.join(os.environ.get(l111l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1llll1l)
elif platform.system() == l111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l11 = os.path.join(os.environ.get(l111l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l111l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1llll.split(l111l (u"ࠨࠬࠣࡖ"))[0].replace(l111l (u"ࠢࠡࠤࡗ"), l111l (u"ࠣࡡࠥࡘ")).lower())
    l1ll11l1 = l1l11ll(l1ll1l11 + l111l (u"ࠤ࠲࡙ࠦ"))
    l1l1lll1 = os.path.join(l1ll11l1, l1llll1l)
elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l11 = os.path.join(os.environ.get(l111l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l111l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1llll.split(l111l (u"ࠨࠬࠣ࡝"))[0].replace(l111l (u"ࠢࠡࠤ࡞"), l111l (u"ࠣࡡࠥ࡟")).lower())
    l1ll11l1 = l1l11ll(l1ll1l11 + l111l (u"ࠤ࠲ࠦࡠ"))
    l1l1lll1 = os.path.join(l1ll11l1, l1llll1l)
else:
    l1l1lll1 = os.path.join(l1llll1l)
logger = logging.getLogger(l111l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1l111l(logger, l1l1lll1)
logger.info(l111l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l111l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll11ll)
logger.info(l111l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l111l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1llll)
logger.info(l111l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1ll)
l1llll = get_major_version(VERSION)
l1111l = l111111(l1llll, l1l1l1ll)
logger.info(l111l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1llll)
logger.info(l111l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1111l)
logger.info(l111l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l111l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll111():
    if l1ll1111:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lllll1():
    if l1ll1111:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1ll1():
    l1ll111l = l1lll111().read(4)
    while len(l1ll111l) == 4:
        l1llll11 = struct.unpack(l111l (u"ࠨࡀࡊࠤ࡫"), l1ll111l)[0]
        request = l1lll111().read(l1llll11).decode()
        logger.info(l111l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1l1l1(request)
        l1l1ll11(response)
        logger.info(l111l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll111l = l1lll111().read(4)
    logger.info(l111l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1ll11(message):
    message = json.dumps(message).encode()
    l1lll1l1 = struct.pack(l111l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lllll1().write(l1lll1l1)
    l1lllll1().write(message)
    l1lllll1().flush()
def l1l1l1l1(request):
    if request:
        l1lll1ll = json.loads(request)
    try:
        return {
            l111l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l111ll,
            l111l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lllll,
            l111l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1lll
        }[l1lll1ll[l111l (u"ࠢࡢࡥࡷࠦࡳ")]](l1lll1ll)
    except Exception as e:
        logger.error(l111l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l111ll()
def l111ll(l1lll1ll=None):
    l1l1ll1l(l1lll1ll)
    l1ll1l1l = {l111l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll1()}
    l1ll1l1l[l111l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l1111(l1111l)
    return l1ll1l1l
def l1lllll(l1lll1ll):
    url = l1lll1ll[l111l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1ll11 = url.split(l111l (u"ࠬࡀࠧࡸ"))[0]
    return {l111l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11l111(l1ll11, url)}
def l1l1lll(l1lll1ll):
    try:
        l1ll11 = l1111l1(l1111l)
        url = l111l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1ll11, l1lll1ll[l111l (u"ࠨࡣࡦࡸࠬࡻ")], l1lll1ll[l111l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l111l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1ll11, url))
        return {l111l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11l111(l1ll11, url)}
    except Exception as e:
        logger.error(str(e))
        return {l111l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1ll1l(l1lll1ll):
    l1lll11l = l111l (u"࠭ࠧࢀ")
    if l1lll1ll:
        for name in l1lll1ll:
            if name in [l111l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l111l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll11l += l111l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1lll1ll[name]
    if l1lll11l: logger.info(l1lll11l[:-1])
def main():
    try:
        l1lll1l()
        l1ll1ll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l111l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()