#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l111ll = 7
def l1lll1 (l11ll):
    global l1l1l
    l11 = ord (l11ll [-1])
    l1llll = l11ll [:-1]
    l1lll = l11 % len (l1llll)
    l1l = l1llll [:l1lll] + l1llll [l1lll:]
    if l1ll11:
        l1l111 = l11l1l () .join ([unichr (ord (char) - l1l1 - (l111l1 + l11) % l111ll) for l111l1, char in enumerate (l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l11) % l111ll) for l111l1, char in enumerate (l1l)])
    return eval (l1l111)
import json
import struct
from l1111l import *
l1ll11ll = sys.version_info[0] == 2
l1l1l1l1 = l1lll1 (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1lll111 = l1lll1 (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1lll1 (u"ࠥ࠹࠳࠸࠱࠯࠷࠼࠽࠺࠴࠰ࠣࡅ")
l1llll1l = l1lll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1ll1l1l = l1lll111.replace(l1lll1 (u"ࠧࠦࠢࡇ"), l1lll1 (u"ࠨ࡟ࠣࡈ")) + l1lll1 (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1lll1 = {}
if platform.system() == l1lll1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1lll1 (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11ll1l = sys.argv[0]
        try:
            l1l1lll1 = l1ll1l1(l11ll1l)
            l1lll111 = l1l1lll1[l1lll1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1lll1[l1lll1 (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1llll1l = l1l1lll1[l1lll1 (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1ll1l1l = l1lll111.replace(l1lll1 (u"ࠨࠠࠣࡏ"), l1lll1 (u"ࠢࡠࠤࡐ")) + l1lll1 (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll11 = os.path.join(os.environ.get(l1lll1 (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1ll1l1l)
elif platform.system() == l1lll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1lllll1 = os.path.join(os.environ.get(l1lll1 (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1lll1 (u"ࠧ࠴ࠥࡴࠤࡕ") % l1llll1l.split(l1lll1 (u"ࠨࠬࠣࡖ"))[0].replace(l1lll1 (u"ࠢࠡࠤࡗ"), l1lll1 (u"ࠣࡡࠥࡘ")).lower())
    l1ll111l = l1lll1l(l1lllll1 + l1lll1 (u"ࠤ࠲࡙ࠦ"))
    l1l1ll11 = os.path.join(l1ll111l, l1ll1l1l)
elif platform.system() == l1lll1 (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1lllll1 = os.path.join(os.environ.get(l1lll1 (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1lll1 (u"ࠧ࠴ࠥࡴࠤ࡜") % l1llll1l.split(l1lll1 (u"ࠨࠬࠣ࡝"))[0].replace(l1lll1 (u"ࠢࠡࠤ࡞"), l1lll1 (u"ࠣࡡࠥ࡟")).lower())
    l1ll111l = l1lll1l(l1lllll1 + l1lll1 (u"ࠤ࠲ࠦࡠ"))
    l1l1ll11 = os.path.join(l1ll111l, l1ll1l1l)
else:
    l1l1ll11 = os.path.join(l1ll1l1l)
logger = logging.getLogger(l1lll1 (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l111111(logger, l1l1ll11)
logger.info(l1lll1 (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1lll1 (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1lll111)
logger.info(l1lll1 (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1lll1 (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1llll1l)
logger.info(l1lll1 (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1l1l1)
ll = get_major_version(VERSION)
l1ll1l = l1l11ll(ll, l1l1l1l1)
logger.info(l1lll1 (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % ll)
logger.info(l1lll1 (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1ll1l)
logger.info(l1lll1 (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1lll1 (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll1l1():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1lll1ll():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1111():
    l1ll1lll = l1lll1l1().read(4)
    while len(l1ll1lll) == 4:
        l1ll1ll1 = struct.unpack(l1lll1 (u"ࠨࡀࡊࠤ࡫"), l1ll1lll)[0]
        request = l1lll1l1().read(l1ll1ll1).decode()
        logger.info(l1lll1 (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1llll11(request)
        l1l1llll(response)
        logger.info(l1lll1 (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1lll = l1lll1l1().read(4)
    logger.info(l1lll1 (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1llll(message):
    message = json.dumps(message).encode()
    l1l1ll1l = struct.pack(l1lll1 (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1lll1ll().write(l1l1ll1l)
    l1lll1ll().write(message)
    l1lll1ll().flush()
def l1llll11(request):
    if request:
        l1ll1l11 = json.loads(request)
    try:
        return {
            l1lll1 (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1111,
            l1lll1 (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l1l11,
            l1lll1 (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l11l1
        }[l1ll1l11[l1lll1 (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1l11)
    except Exception as e:
        logger.error(l1lll1 (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1111()
def l1111(l1ll1l11=None):
    l1ll11l1(l1ll1l11)
    l1lll11l = {l1lll1 (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l11l1()}
    l1lll11l[l1lll1 (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l111l1l(l1ll1l)
    return l1lll11l
def l1l1l11(l1ll1l11):
    url = l1ll1l11[l1lll1 (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l11l = url.split(l1lll1 (u"ࠬࡀࠧࡸ"))[0]
    return {l1lll1 (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1ll111(l1l11l, url)}
def l1l11l1(l1ll1l11):
    try:
        l1l11l = l11llll(l1ll1l)
        url = l1lll1 (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l11l, l1ll1l11[l1lll1 (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1l11[l1lll1 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1lll1 (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l11l, url))
        return {l1lll1 (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1ll111(l1l11l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1lll1 (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1ll11l1(l1ll1l11):
    l1l1l1ll = l1lll1 (u"࠭ࠧࢀ")
    if l1ll1l11:
        for name in l1ll1l11:
            if name in [l1lll1 (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1lll1 (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1ll += l1lll1 (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1l11[name]
    if l1l1l1ll: logger.info(l1l1l1ll[:-1])
def main():
    try:
        l111l11()
        l1ll1111()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1lll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()