#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1l111 = 7
def l1ll (l111l):
    global l111l1
    l11l = ord (l111l [-1])
    l111ll = l111l [:-1]
    l1l11l = l11l % len (l111ll)
    l1111 = l111ll [:l1l11l] + l111ll [l1l11l:]
    if l11l1:
        l1l1 = l1lll () .join ([unichr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    else:
        l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    return eval (l1l1)
import json
import struct
from ll import *
l1ll11ll = sys.version_info[0] == 2
l1ll1l1l = l1ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1l1l1ll = l1ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll (u"ࠥ࠺࠳࠶࠮࠹࠻࠴࠼࠳࠶ࠢࡅ")
l1lllll1 = l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll111 = l1l1l1ll.replace(l1ll (u"ࠧࠦࠢࡇ"), l1ll (u"ࠨ࡟ࠣࡈ")) + l1ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1l1lll1 = {}
if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111ll1 = sys.argv[0]
        try:
            l1l1lll1 = l11111(l111ll1)
            l1l1l1ll = l1l1lll1[l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1l1lll1[l1ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1lllll1 = l1l1lll1[l1ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll111 = l1l1l1ll.replace(l1ll (u"ࠨࠠࠣࡏ"), l1ll (u"ࠢࡠࠤࡐ")) + l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1ll1l = os.path.join(os.environ.get(l1ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll111)
elif platform.system() == l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll11l1 = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1lllll1.split(l1ll (u"ࠨࠬࠣࡖ"))[0].replace(l1ll (u"ࠢࠡࠤࡗ"), l1ll (u"ࠣࡡࠥࡘ")).lower())
    l1l1ll11 = l1ll1ll(l1ll11l1 + l1ll (u"ࠤ࠲࡙ࠦ"))
    l1l1ll1l = os.path.join(l1l1ll11, l1lll111)
elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll11l1 = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1lllll1.split(l1ll (u"ࠨࠬࠣ࡝"))[0].replace(l1ll (u"ࠢࠡࠤ࡞"), l1ll (u"ࠣࡡࠥ࡟")).lower())
    l1l1ll11 = l1ll1ll(l1ll11l1 + l1ll (u"ࠤ࠲ࠦࡠ"))
    l1l1ll1l = os.path.join(l1l1ll11, l1lll111)
else:
    l1l1ll1l = os.path.join(l1lll111)
logger = logging.getLogger(l1ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l11l11l(logger, l1l1ll1l)
logger.info(l1ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1l1l1ll)
logger.info(l1ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1lllll1)
logger.info(l1ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1l1l)
l1 = get_major_version(VERSION)
l1l1l1 = l1l1l11(l1, l1ll1l1l)
logger.info(l1ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1)
logger.info(l1ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l1l1)
logger.info(l1ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1ll11ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1l1l1():
    if l1ll11ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1ll1ll1():
    l1lll1l1 = l1lll11l().read(4)
    while len(l1lll1l1) == 4:
        l1ll1111 = struct.unpack(l1ll (u"ࠨࡀࡊࠤ࡫"), l1lll1l1)[0]
        request = l1lll11l().read(l1ll1111).decode()
        logger.info(l1ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll1ll(request)
        l1ll111l(response)
        logger.info(l1ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lll1l1 = l1lll11l().read(4)
    logger.info(l1ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll111l(message):
    message = json.dumps(message).encode()
    l1ll1l11 = struct.pack(l1ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1l1l1().write(l1ll1l11)
    l1l1l1l1().write(message)
    l1l1l1l1().flush()
def l1lll1ll(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l1ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l11,
            l1ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l11l1,
            l1ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l11l111
        }[l1llll1l[l1ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l1ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l11()
def l1l11(l1llll1l=None):
    l1llll11(l1llll1l)
    l1l1llll = {l1ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll11()}
    l1l1llll[l1ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l111l11(l1l1l1)
    return l1l1llll
def l1l11l1(l1llll1l):
    url = l1llll1l[l1ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11lll = url.split(l1ll (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11111l(l11lll, url)}
def l11l111(l1llll1l):
    try:
        l11lll = l1lllll(l1l1l1)
        url = l1ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11lll, l1llll1l[l1ll (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l1ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11lll, url))
        return {l1ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11111l(l11lll, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll11(l1llll1l):
    l1ll1lll = l1ll (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l1ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1lll += l1ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1ll1lll: logger.info(l1ll1lll[:-1])
def main():
    try:
        l1111l1()
        l1ll1ll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()