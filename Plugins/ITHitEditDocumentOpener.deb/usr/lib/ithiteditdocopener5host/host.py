#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l11l1 = 2048
l1l1l1 = 7
def l11l (ll):
    global l1ll1
    l11l1l = ord (ll [-1])
    l11ll1 = ll [:-1]
    l1l11 = l11l1l % len (l11ll1)
    l11ll = l11ll1 [:l1l11] + l11ll1 [l1l11:]
    if l1l111:
        l111 = l1ll11 () .join ([unichr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    return eval (l111)
import json
import struct
from l11lll import *
l1ll1ll1 = sys.version_info[0] == 2
l1ll1111 = l11l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1llll11 = l11l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11l (u"ࠥ࠺࠳࠶࠮࠹࠹࠸࠼࠳࠶ࠢࡅ")
l1ll1lll = l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1l1ll = l1llll11.replace(l11l (u"ࠧࠦࠢࡇ"), l11l (u"ࠨ࡟ࠣࡈ")) + l11l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll1ll = {}
if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l1l1l = sys.argv[0]
        try:
            l1lll1ll = l111ll1(l1l1l1l)
            l1llll11 = l1lll1ll[l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll1ll[l11l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1ll1lll = l1lll1ll[l11l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1l1ll = l1llll11.replace(l11l (u"ࠨࠠࠣࡏ"), l11l (u"ࠢࡠࠤࡐ")) + l11l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1ll111l = os.path.join(os.environ.get(l11l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1l1ll)
elif platform.system() == l11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l11 = os.path.join(os.environ.get(l11l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1ll1lll.split(l11l (u"ࠨࠬࠣࡖ"))[0].replace(l11l (u"ࠢࠡࠤࡗ"), l11l (u"ࠣࡡࠥࡘ")).lower())
    l1lllll1 = l1lll11(l1ll1l11 + l11l (u"ࠤ࠲࡙ࠦ"))
    l1ll111l = os.path.join(l1lllll1, l1l1l1ll)
elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l11 = os.path.join(os.environ.get(l11l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1ll1lll.split(l11l (u"ࠨࠬࠣ࡝"))[0].replace(l11l (u"ࠢࠡࠤ࡞"), l11l (u"ࠣࡡࠥ࡟")).lower())
    l1lllll1 = l1lll11(l1ll1l11 + l11l (u"ࠤ࠲ࠦࡠ"))
    l1ll111l = os.path.join(l1lllll1, l1l1l1ll)
else:
    l1ll111l = os.path.join(l1l1l1ll)
logger = logging.getLogger(l11l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll1ll(logger, l1ll111l)
logger.info(l11l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1llll11)
logger.info(l11l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1ll1lll)
logger.info(l11l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll1111)
l1ll = get_major_version(VERSION)
l1lll = l1ll11l(l1ll, l1ll1111)
logger.info(l11l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1ll)
logger.info(l11l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1lll)
logger.info(l11l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll1l1():
    if l1ll1ll1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1l1ll1l():
    if l1ll1ll1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1ll11():
    l1llll1l = l1lll1l1().read(4)
    while len(l1llll1l) == 4:
        l1ll11ll = struct.unpack(l11l (u"ࠨࡀࡊࠤ࡫"), l1llll1l)[0]
        request = l1lll1l1().read(l1ll11ll).decode()
        logger.info(l11l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1lll11l(request)
        l1ll11l1(response)
        logger.info(l11l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1llll1l = l1lll1l1().read(4)
    logger.info(l11l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1ll11l1(message):
    message = json.dumps(message).encode()
    l1l1l1l1 = struct.pack(l11l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1l1ll1l().write(l1l1l1l1)
    l1l1ll1l().write(message)
    l1l1ll1l().flush()
def l1lll11l(request):
    if request:
        l1l1llll = json.loads(request)
    try:
        return {
            l11l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l11l,
            l11l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1111l1,
            l11l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l11ll
        }[l1l1llll[l11l (u"ࠢࡢࡥࡷࠦࡳ")]](l1l1llll)
    except Exception as e:
        logger.error(l11l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l11l()
def l1l11l(l1l1llll=None):
    l1l1lll1(l1l1llll)
    l1ll1l1l = {l11l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l111ll()}
    l1ll1l1l[l11l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1llllll(l1lll)
    return l1ll1l1l
def l1111l1(l1l1llll):
    url = l1l1llll[l11l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1lll1 = url.split(l11l (u"ࠬࡀࠧࡸ"))[0]
    return {l11l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l1111(l1lll1, url)}
def l1l11ll(l1l1llll):
    try:
        l1lll1 = l1ll111(l1lll)
        url = l11l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1lll1, l1l1llll[l11l (u"ࠨࡣࡦࡸࠬࡻ")], l1l1llll[l11l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1lll1, url))
        return {l11l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l1111(l1lll1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1l1lll1(l1l1llll):
    l1lll111 = l11l (u"࠭ࠧࢀ")
    if l1l1llll:
        for name in l1l1llll:
            if name in [l11l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll111 += l11l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1l1llll[name]
    if l1lll111: logger.info(l1lll111[:-1])
def main():
    try:
        l1l11l1()
        l1l1ll11()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()