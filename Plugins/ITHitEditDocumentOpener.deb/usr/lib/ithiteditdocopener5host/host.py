#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111l1 = 2048
l1l111 = 7
def l1l11l (l1ll1l):
    global l1
    l11lll = ord (l1ll1l [-1])
    l1lll = l1ll1l [:-1]
    l111l = l11lll % len (l1lll)
    l1llll = l1lll [:l111l] + l1lll [l111l:]
    if l1l1l:
        l1111l = l1l1l1 () .join ([unichr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    return eval (l1111l)
import json
import struct
from l1l1 import *
l1llll1l = sys.version_info[0] == 2
l1l1ll1l = l1l11l (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll111l = l1l11l (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1l11l (u"ࠥ࠺࠳࠸࠮࠹࠻࠷࠺࠳࠶ࠢࡅ")
l1l1ll11 = l1l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1llll = l1ll111l.replace(l1l11l (u"ࠧࠦࠢࡇ"), l1l11l (u"ࠨ࡟ࠣࡈ")) + l1l11l (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1lll11l = {}
if platform.system() == l1l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1l11l (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l11l1l1 = sys.argv[0]
        try:
            l1lll11l = l1ll1l1(l11l1l1)
            l1ll111l = l1lll11l[l1l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1lll11l[l1l11l (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll11 = l1lll11l[l1l11l (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1llll = l1ll111l.replace(l1l11l (u"ࠨࠠࠣࡏ"), l1l11l (u"ࠢࡠࠤࡐ")) + l1l11l (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1llll11 = os.path.join(os.environ.get(l1l11l (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1llll)
elif platform.system() == l1l11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l11l (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1l11l (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll11.split(l1l11l (u"ࠨࠬࠣࡖ"))[0].replace(l1l11l (u"ࠢࠡࠤࡗ"), l1l11l (u"ࠣࡡࠥࡘ")).lower())
    l1lll111 = l1lllll(l1ll1ll1 + l1l11l (u"ࠤ࠲࡙ࠦ"))
    l1llll11 = os.path.join(l1lll111, l1l1llll)
elif platform.system() == l1l11l (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1ll1 = os.path.join(os.environ.get(l1l11l (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1l11l (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll11.split(l1l11l (u"ࠨࠬࠣ࡝"))[0].replace(l1l11l (u"ࠢࠡࠤ࡞"), l1l11l (u"ࠣࡡࠥ࡟")).lower())
    l1lll111 = l1lllll(l1ll1ll1 + l1l11l (u"ࠤ࠲ࠦࡠ"))
    l1llll11 = os.path.join(l1lll111, l1l1llll)
else:
    l1llll11 = os.path.join(l1l1llll)
logger = logging.getLogger(l1l11l (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1111ll(logger, l1llll11)
logger.info(l1l11l (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1l11l (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll111l)
logger.info(l1l11l (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1l11l (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll11)
logger.info(l1l11l (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1l1ll1l)
l1l1ll = get_major_version(VERSION)
l111ll = l1l111l(l1l1ll, l1l1ll1l)
logger.info(l1l11l (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1l1ll)
logger.info(l1l11l (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l111ll)
logger.info(l1l11l (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1l11l (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll11l1():
    if l1llll1l:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll11ll():
    if l1llll1l:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1lll1ll():
    l1ll1l1l = l1ll11l1().read(4)
    while len(l1ll1l1l) == 4:
        l1lllll1 = struct.unpack(l1l11l (u"ࠨࡀࡊࠤ࡫"), l1ll1l1l)[0]
        request = l1ll11l1().read(l1lllll1).decode()
        logger.info(l1l11l (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1lll1(request)
        l1l1l1ll(response)
        logger.info(l1l11l (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1ll1l1l = l1ll11l1().read(4)
    logger.info(l1l11l (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1l1l1ll(message):
    message = json.dumps(message).encode()
    l1ll1lll = struct.pack(l1l11l (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll11ll().write(l1ll1lll)
    l1ll11ll().write(message)
    l1ll11ll().flush()
def l1l1lll1(request):
    if request:
        l1ll1111 = json.loads(request)
    try:
        return {
            l1l11l (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l,
            l1l11l (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1111l1,
            l1l11l (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111l1l
        }[l1ll1111[l1l11l (u"ࠢࡢࡥࡷࠦࡳ")]](l1ll1111)
    except Exception as e:
        logger.error(l1l11l (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l()
def l1l(l1ll1111=None):
    l1lll1l1(l1ll1111)
    l1l1l1l1 = {l1l11l (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1ll()}
    l1l1l1l1[l1l11l (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1l11ll(l111ll)
    return l1l1l1l1
def l1111l1(l1ll1111):
    url = l1ll1111[l1l11l (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1l11 = url.split(l1l11l (u"ࠬࡀࠧࡸ"))[0]
    return {l1l11l (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l111lll(l1l11, url)}
def l111l1l(l1ll1111):
    try:
        l1l11 = l1l11l1(l111ll)
        url = l1l11l (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1l11, l1ll1111[l1l11l (u"ࠨࡣࡦࡸࠬࡻ")], l1ll1111[l1l11l (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1l11l (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1l11, url))
        return {l1l11l (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l111lll(l1l11, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1l11l (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lll1l1(l1ll1111):
    l1ll1l11 = l1l11l (u"࠭ࠧࢀ")
    if l1ll1111:
        for name in l1ll1111:
            if name in [l1l11l (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1l11l (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1ll1l11 += l1l11l (u"ࠩࠨࡷࠥ࠭ࢃ") % l1ll1111[name]
    if l1ll1l11: logger.info(l1ll1l11[:-1])
def main():
    try:
        l11l11l()
        l1lll1ll()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()