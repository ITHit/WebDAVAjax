#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1l = 2048
l1111 = 7
def l1ll (l11l):
    global l1ll1l
    l1lll1 = ord (l11l [-1])
    l1lll = l11l [:-1]
    ll = l1lll1 % len (l1lll)
    l1ll1 = l1lll [:ll] + l1lll [ll:]
    if l11l1:
        l1llll = l1l1 () .join ([unichr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    return eval (l1llll)
import json
import struct
from l111l1 import *
l1ll1ll1 = sys.version_info[0] == 2
l1lll1l1 = l1ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1l11 = l1ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l1ll (u"ࠥ࠺࠳࠷࠮࠹࠻࠵࠻࠳࠶ࠢࡅ")
l1l1llll = l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1l1ll1l = l1ll1l11.replace(l1ll (u"ࠧࠦࠢࡇ"), l1ll (u"ࠨ࡟ࠣࡈ")) + l1ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1l1l = {}
if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l1ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l111ll1 = sys.argv[0]
        try:
            l1ll1l1l = l1ll1l1(l111ll1)
            l1ll1l11 = l1ll1l1l[l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1l1l[l1ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1llll = l1ll1l1l[l1ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1l1ll1l = l1ll1l11.replace(l1ll (u"ࠨࠠࠣࡏ"), l1ll (u"ࠢࡠࠤࡐ")) + l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1l1ll = os.path.join(os.environ.get(l1ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1l1ll1l)
elif platform.system() == l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1l1lll1 = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l1ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1llll.split(l1ll (u"ࠨࠬࠣࡖ"))[0].replace(l1ll (u"ࠢࠡࠤࡗ"), l1ll (u"ࠣࡡࠥࡘ")).lower())
    l1ll1lll = l1l1lll(l1l1lll1 + l1ll (u"ࠤ࠲࡙ࠦ"))
    l1l1l1ll = os.path.join(l1ll1lll, l1l1ll1l)
elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1l1lll1 = os.path.join(os.environ.get(l1ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l1ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1llll.split(l1ll (u"ࠨࠬࠣ࡝"))[0].replace(l1ll (u"ࠢࠡࠤ࡞"), l1ll (u"ࠣࡡࠥ࡟")).lower())
    l1ll1lll = l1l1lll(l1l1lll1 + l1ll (u"ࠤ࠲ࠦࡠ"))
    l1l1l1ll = os.path.join(l1ll1lll, l1l1ll1l)
else:
    l1l1l1ll = os.path.join(l1l1ll1l)
logger = logging.getLogger(l1ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll111(logger, l1l1l1ll)
logger.info(l1ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l1ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1l11)
logger.info(l1ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l1ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1llll)
logger.info(l1ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1lll1l1)
l11ll = get_major_version(VERSION)
l11l11 = l11l1l1(l11ll, l1lll1l1)
logger.info(l1ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l11ll)
logger.info(l1ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l11l11)
logger.info(l1ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l1ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1ll111l():
    if l1ll1ll1:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll11ll():
    if l1ll1ll1:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1l1l1():
    l1lllll1 = l1ll111l().read(4)
    while len(l1lllll1) == 4:
        l1ll1111 = struct.unpack(l1ll (u"ࠨࡀࡊࠤ࡫"), l1lllll1)[0]
        request = l1ll111l().read(l1ll1111).decode()
        logger.info(l1ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1l1ll11(request)
        l1lll11l(response)
        logger.info(l1ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1lllll1 = l1ll111l().read(4)
    logger.info(l1ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll11l(message):
    message = json.dumps(message).encode()
    l1ll11l1 = struct.pack(l1ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll11ll().write(l1ll11l1)
    l1ll11ll().write(message)
    l1ll11ll().flush()
def l1l1ll11(request):
    if request:
        l1llll11 = json.loads(request)
    try:
        return {
            l1ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l1l111,
            l1ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1l111l,
            l1ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l111lll
        }[l1llll11[l1ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll11)
    except Exception as e:
        logger.error(l1ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l1l111()
def l1l111(l1llll11=None):
    l1llll1l(l1llll11)
    l1lll111 = {l1ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l11l()}
    l1lll111[l1ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1lllll(l11l11)
    return l1lll111
def l1l111l(l1llll11):
    url = l1llll11[l1ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l1111l = url.split(l1ll (u"ࠬࡀࠧࡸ"))[0]
    return {l1ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l1l11l1(l1111l, url)}
def l111lll(l1llll11):
    try:
        l1111l = l11lll1(l11l11)
        url = l1ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l1111l, l1llll11[l1ll (u"ࠨࡣࡦࡸࠬࡻ")], l1llll11[l1ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l1ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l1111l, url))
        return {l1ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l1l11l1(l1111l, url)}
    except Exception as e:
        logger.error(str(e))
        return {l1ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1llll1l(l1llll11):
    l1lll1ll = l1ll (u"࠭ࠧࢀ")
    if l1llll11:
        for name in l1llll11:
            if name in [l1ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l1ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1lll1ll += l1ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll11[name]
    if l1lll1ll: logger.info(l1lll1ll[:-1])
def main():
    try:
        l1ll1ll()
        l1l1l1l1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()