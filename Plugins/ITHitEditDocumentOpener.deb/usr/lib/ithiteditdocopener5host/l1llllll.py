#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll1 = 2048
l11l = 7
def ll (l1):
    global l1l
    l1llll = ord (l1 [-1])
    l1l111 = l1 [:-1]
    l1l1l1 = l1llll % len (l1l111)
    l11lll = l1l111 [:l1l1l1] + l1l111 [l1l1l1:]
    if l11ll:
        l111 = l11l11 () .join ([unichr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    else:
        l111 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    return eval (l111)
import subprocess, threading
from l111l1 import l1111l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l111l():
    l11l1lll = [ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1lll:
        try:
            l11ll1l1 = ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l11ll = winreg.l11ll1ll(winreg.l1l1111l, l11ll1l1)
        except l1l11111:
            continue
        value = winreg.l11l1l1l(l11l11ll, ll (u"ࠦࠧ࢓"))
        return value.split(ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111ll1():
    l1l111l1 = []
    for name in l1l1l111:
        try:
            l11ll1l1 = ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11lll = winreg.l11ll1ll(winreg.l1l1111l, l11ll1l1)
            if winreg.l11l1l1l(l1l11lll, ll (u"ࠢࠣ࢖")):
                l1l111l1.append(name)
        except l1l11111:
            continue
    return l1l111l1
def l1l1111(l1111, l11l1):
    import re
    l1l1l = []
    l11ll11l = winreg.l11ll1ll(winreg.l1l1111l, ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lll11(l11ll11l)[0]):
        try:
            l1l11ll1 = winreg.l11l111l(l11ll11l, i)
            if l1l11ll1.startswith(l11l1):
                l11ll111 = winreg.l1l111ll(l11ll11l, l1l11ll1)
                value, l11l11l1 = winreg.l11l1l11(l11ll111, ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lllll = {ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11l1l = m.group(2)
                    if l1111 == l1l11l1l:
                        m = re.search(l11l1.replace(ll (u"ࠬ࠴࢛ࠧ"), ll (u"࠭࡜࡝࠰ࠪ࢜")) + ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11ll1)
                        l11lllll[ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1l.append(l11lllll)
                else:
                    raise ValueError(ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11111 as ex:
            continue
    return l1l1l
def l11llll1(l11l1l):
    try:
        l11lll1l = ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1l)
        l11l1111 = winreg.l11ll1ll(winreg.l1l1111l, l11lll1l)
        value, l11l11l1 = winreg.l11l1l11(l11l1111, ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(ll (u"ࠬࠨࠧࢢ"))[1]
    except l1l11111:
        pass
    return ll (u"࠭ࠧࢣ")
def l11ll11(l11l1l, url):
    threading.Thread(target=_1l11l11,args=(l11l1l, url)).start()
    return ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11l11(l11l1l, url):
    logger = l1111l()
    l11l1ll1 = l11llll1(l11l1l)
    logger.debug(ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1ll1, url))
    retcode = subprocess.Popen(ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1ll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)