#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11lll = 2048
l1l1 = 7
def l11 (l1l11):
    global l1l11l
    l1111 = ord (l1l11 [-1])
    l1ll1 = l1l11 [:-1]
    l1ll = l1111 % len (l1ll1)
    l1llll = l1ll1 [:l1ll] + l1ll1 [l1ll:]
    if l11ll1:
        l1 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    else:
        l1 = str () .join ([chr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    return eval (l1)
import subprocess, threading
from l11l1l import l1lll1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11ll1l():
    l1l11lll = [l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11lll:
        try:
            l11l1l11 = l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll11l = winreg.l11ll111(winreg.l11lllll, l11l1l11)
        except l11l111l:
            continue
        value = winreg.l11l1ll1(l11ll11l, l11 (u"ࠦࠧ࢓"))
        return value.split(l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1lll1l():
    l11l11l1 = []
    for name in l1l1l111:
        try:
            l11l1l11 = l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1ll = winreg.l11ll111(winreg.l11lllll, l11l1l11)
            if winreg.l11l1ll1(l11ll1ll, l11 (u"ࠢࠣ࢖")):
                l11l11l1.append(name)
        except l11l111l:
            continue
    return l11l11l1
def l11llll(l11ll, l1ll1l):
    import re
    l11l = []
    l11l1l1l = winreg.l11ll111(winreg.l11lllll, l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l11ll(l11l1l1l)[0]):
        try:
            l1l11ll1 = winreg.l1l1111l(l11l1l1l, i)
            if l1l11ll1.startswith(l1ll1l):
                l1l111l1 = winreg.l1l11l11(l11l1l1l, l1l11ll1)
                value, l11l1lll = winreg.l11ll1l1(l1l111l1, l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11l1l = {l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll11 = m.group(2)
                    if l11ll == l11lll11:
                        m = re.search(l1ll1l.replace(l11 (u"ࠬ࠴࢛ࠧ"), l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11ll1)
                        l1l11l1l[l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l.append(l1l11l1l)
                else:
                    raise ValueError(l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l11l
def l11l1111(l1l111):
    try:
        l1l111ll = l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l111)
        l11llll1 = winreg.l11ll111(winreg.l11lllll, l1l111ll)
        value, l11l1lll = winreg.l11ll1l1(l11llll1, l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11 (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l11 (u"࠭ࠧࢣ")
def l11l1l1(l1l111, url):
    threading.Thread(target=_1l11111,args=(l1l111, url)).start()
    return l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11111(l1l111, url):
    logger = l1lll1()
    l11lll1l = l11l1111(l1l111)
    logger.debug(l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lll1l, url))
    retcode = subprocess.Popen(l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lll1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)