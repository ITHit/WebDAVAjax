#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l1l1ll (l1ll):
    global l111l1
    l11l11 = ord (l1ll [-1])
    l11l1 = l1ll [:-1]
    l1l11 = l11l11 % len (l11l1)
    l111l = l11l1 [:l1l11] + l11l1 [l1l11:]
    if l1l1l:
        l1l11l = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    return eval (l1l11l)
import l1l
from l1l1l111 import l1l1l11l
import objc as _11111ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11111ll.l1111l1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l1111ll1(l111l11l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l11l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1ll (u"ࠨࠩࢬ"), {l1l1ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1l1(l1111lll):
    l1111lll = (l1111lll + l1l1ll (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l11 = CFStringCreateWithCString( kCFAllocatorDefault, l1111lll, kCFStringEncodingUTF8 )
    l111llll = CFURLCreateWithString( kCFAllocatorDefault, l1111l11, _11111ll.nil )
    l1111111 = LaunchServices.l111l111( l111llll, LaunchServices.l111ll1l, _11111ll.nil )
    if l1111111[0] is not None:
        return True
    return False
def l1():
    l111111l = []
    for name in l1l1l11l:
        try:
            if l111l1l1(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l11ll(l1l1l1, l1ll1l):
    import plistlib
    import os
    l1ll11 = []
    l1l111 = {}
    for l111l1ll in os.listdir(l1l1ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1ll.startswith(l1ll1l):
            try:
                l111ll11 = l1l1ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1ll
                with open(l111ll11, l1l1ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11 = plist[l1l1ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l1l1ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1l1 == l111lll1:
                        if not l11 in l1l111:
                            l1l111[l11] = version
                        elif l1l.l1111l(version, l1l111[l11]) > 0:
                            l1l111[l11] = version
            except BaseException:
                continue
    for l11 in l1l111:
        l1ll11.append({l1l1ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l111[l11], l1l1ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11})
    return l1ll11