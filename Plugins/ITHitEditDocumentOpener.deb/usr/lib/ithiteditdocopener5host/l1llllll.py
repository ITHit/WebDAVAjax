#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1 = 2048
l1111 = 7
def l11ll (l1ll1l):
    global l11ll1
    l11l1 = ord (l1ll1l [-1])
    l1l = l1ll1l [:-1]
    l1l1ll = l11l1 % len (l1l)
    l11lll = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l111ll:
        l1ll = l11l () .join ([unichr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    return eval (l1ll)
import subprocess, threading
from l1l11 import l1l1l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l1l11():
    l11lll11 = [l11ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lll11:
        try:
            l11l1lll = l11ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11lll = winreg.l11ll111(winreg.l11l1l11, l11l1lll)
        except l1l11ll1:
            continue
        value = winreg.l11lllll(l1l11lll, l11ll (u"ࠦࠧ࢓"))
        return value.split(l11ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll1ll():
    l11l1111 = []
    for name in l1l1l11l:
        try:
            l11l1lll = l11ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l1l = winreg.l11ll111(winreg.l11l1l11, l11l1lll)
            if winreg.l11lllll(l1l11l1l, l11ll (u"ࠢࠣ࢖")):
                l11l1111.append(name)
        except l1l11ll1:
            continue
    return l11l1111
def l11l11l(l1llll, l11l1l):
    import re
    l11 = []
    l11l11ll = winreg.l11ll111(winreg.l11l1l11, l11ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l11(l11l11ll)[0]):
        try:
            l11ll1l1 = winreg.l1l11111(l11l11ll, i)
            if l11ll1l1.startswith(l11l1l):
                l11lll1l = winreg.l11l11l1(l11l11ll, l11ll1l1)
                value, l11l1ll1 = winreg.l11l1l1l(l11lll1l, l11ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll1ll = {l11ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l111l = m.group(2)
                    if l1llll == l11l111l:
                        m = re.search(l11l1l.replace(l11ll (u"ࠬ࠴࢛ࠧ"), l11ll (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1l1)
                        l11ll1ll[l11ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11.append(l11ll1ll)
                else:
                    raise ValueError(l11ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11ll1 as ex:
            continue
    return l11
def l1l111ll(l11l11):
    try:
        l11llll1 = l11ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l11)
        l1l111l1 = winreg.l11ll111(winreg.l11l1l11, l11llll1)
        value, l11l1ll1 = winreg.l11l1l1l(l1l111l1, l11ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll (u"ࠬࠨࠧࢢ"))[1]
    except l1l11ll1:
        pass
    return l11ll (u"࠭ࠧࢣ")
def l1111ll(l11l11, url):
    threading.Thread(target=_1l1111l,args=(l11l11, url)).start()
    return l11ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l1111l(l11l11, url):
    logger = l1l1l1()
    l11ll11l = l1l111ll(l11l11)
    logger.debug(l11ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll11l, url))
    retcode = subprocess.Popen(l11ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll11l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)