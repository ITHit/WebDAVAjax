#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1 = 7
def l11l1l (l11lll):
    global l111ll
    l1lll = ord (l11lll [-1])
    l1l111 = l11lll [:-1]
    l1ll1 = l1lll % len (l1l111)
    l1llll = l1l111 [:l1ll1] + l1l111 [l1ll1:]
    if l11:
        l11l = l111l1 () .join ([unichr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    return eval (l11l)
import subprocess, threading
from l1l11 import l1ll1l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11lll1():
    l1l11lll = [l11l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11lll:
        try:
            l11l111l = l11l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11l1l = winreg.l1l111ll(winreg.l11ll11l, l11l111l)
        except l11l1ll1:
            continue
        value = winreg.l11lll1l(l1l11l1l, l11l1l (u"ࠦࠧ࢓"))
        return value.split(l11l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111ll1():
    l11llll1 = []
    for name in l1l1l11l:
        try:
            l11l111l = l11l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l11ll = winreg.l1l111ll(winreg.l11ll11l, l11l111l)
            if winreg.l11lll1l(l11l11ll, l11l1l (u"ࠢࠣ࢖")):
                l11llll1.append(name)
        except l11l1ll1:
            continue
    return l11llll1
def l1llll1(l1111, l1111l):
    import re
    l11ll = []
    l11lllll = winreg.l1l111ll(winreg.l11ll11l, l11l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11ll1(l11lllll)[0]):
        try:
            l11ll111 = winreg.l11ll1l1(l11lllll, i)
            if l11ll111.startswith(l1111l):
                l11lll11 = winreg.l1l111l1(l11lllll, l11ll111)
                value, l1l11l11 = winreg.l11l1111(l11lll11, l11l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1l1l = {l11l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11111 = m.group(2)
                    if l1111 == l1l11111:
                        m = re.search(l1111l.replace(l11l1l (u"ࠬ࠴࢛ࠧ"), l11l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l11l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll111)
                        l11l1l1l[l11l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11ll.append(l11l1l1l)
                else:
                    raise ValueError(l11l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1ll1 as ex:
            continue
    return l11ll
def l11l1lll(l1l1ll):
    try:
        l11l1l11 = l11l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1ll)
        l11l11l1 = winreg.l1l111ll(winreg.l11ll11l, l11l1l11)
        value, l1l11l11 = winreg.l11l1111(l11l11l1, l11l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1ll1:
        pass
    return l11l1l (u"࠭ࠧࢣ")
def l1l1ll1(l1l1ll, url):
    threading.Thread(target=_1l1111l,args=(l1l1ll, url)).start()
    return l11l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l1111l(l1l1ll, url):
    logger = l1ll1l()
    l11ll1ll = l11l1lll(l1l1ll)
    logger.debug(l11l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll1ll, url))
    retcode = subprocess.Popen(l11l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll1ll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)