#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l1l = 7
def l111 (l1ll):
    global l1l1l1
    l1l11 = ord (l1ll [-1])
    l1 = l1ll [:-1]
    l11lll = l1l11 % len (l1)
    l1l1ll = l1 [:l11lll] + l1 [l11lll:]
    if l1ll11:
        l1111l = l1ll1 () .join ([unichr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l1l11) % l1l) for l111l1, char in enumerate (l1l1ll)])
    return eval (l1111l)
import os
import re
import subprocess
import l1lll1
from l1lll1 import l11l1
def l11l11():
    return []
def l11ll(l1lll, l11l):
    logger = l11l1()
    l1111 = []
    ll = [l111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in ll:
        try:
            output = os.popen(cmd).read()
            l1llll = 0
            l1ll1l = {}
            if l1llll == 0:
                l1l111 = re.compile(l111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111ll = re.compile(l111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1l = re.search(l1l111, line)
                    l11ll1 = l1l1l.group(1)
                    if l1lll == l11ll1:
                        l11 = re.search(l111ll, line)
                        if l11:
                            l111l = l111 (u"ࠨࡦࡤࡺࠬࠄ")+l11.group(1)
                            version = l1l1l.group(0)
                            if not l111l in l1ll1l:
                                l1ll1l[l111l] = version
                            elif l1lll1.l1l11l(version, l1ll1l[l111l]) > 0:
                                l1ll1l[l111l] = version
            for l111l in l1ll1l:
                l1111.append({l111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1l[l111l], l111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l})
        except Exception as e:
            logger.error(str(e))
    return l1111