#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11lll = 2048
l1l1 = 7
def l11 (l1l11):
    global l1l11l
    l1111 = ord (l1l11 [-1])
    l1ll1 = l1l11 [:-1]
    l1ll = l1111 % len (l1ll1)
    l1llll = l1ll1 [:l1ll] + l1ll1 [l1ll:]
    if l11ll1:
        l1 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    else:
        l1 = str () .join ([chr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    return eval (l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll1l1(l11l111=None):
    if platform.system() == l11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1llll1
        props = {}
        try:
            prop_names = (l11 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11111 = l1llll1.l1l1l11(l11l111, l11 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11111l in prop_names:
                l1111l1 = l11 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11111, l11111l)
                props[l11111l] = l1llll1.l1l1l11(l11l111, l1111l1)
        except:
            pass
    return props
def l11l11l(logger, l1l11ll):
    l1ll11l = os.environ.get(l11 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1ll11l = l1ll11l.upper()
    if l1ll11l == l11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l111l = logging.DEBUG
    elif l1ll11l == l11 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l111l = logging.INFO
    elif l1ll11l == l11 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l111l = logging.WARNING
    elif l1ll11l == l11 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l111l = logging.ERROR
    elif l1ll11l == l11 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l111l = logging.CRITICAL
    elif l1ll11l == l11 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l111l = logging.NOTSET
    logger.setLevel(l1l111l)
    l1l1ll1 = RotatingFileHandler(l1l11ll, maxBytes=1024*1024*5, backupCount=3)
    l1l1ll1.setLevel(l1l111l)
    formatter = logging.Formatter(l11 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1ll1.setFormatter(formatter)
    logger.addHandler(l1l1ll1)
    globals()[l11 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1lll1():
    return globals()[l11 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111l1l():
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll1ll
        l1ll1ll.l1l1lll(sys.stdin.fileno(), os.l1111ll)
        l1ll1ll.l1l1lll(sys.stdout.fileno(), os.l1111ll)
def l1l1111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111lll():
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1llllll
        return l1llllll.l11ll1l()
    elif platform.system() == l11 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l1l1():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1llllll
        return l1llllll.l1lll1l()
    elif platform.system() == l11 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1111l
        return l1111l.l1l1l1()
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1lll11
        return l1lll11.l1l1l1()
    return l11 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11lll1(l11ll, l1ll1l):
    if platform.system() == l11 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1llllll
        return l1llllll.l11llll(l11ll, l1ll1l)
    elif platform.system() == l11 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1lll11
        return l1lll11.l1l1ll(l11ll, l1ll1l)
    elif platform.system() == l11 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1111l
        return l1111l.l1l1ll(l11ll, l1ll1l)
    raise ValueError(l11 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l1l1l(l1l111, url):
    if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1llllll
        return l1llllll.l11l1l1(l1l111, url)
    elif platform.system() == l11 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1lll11
        return l11 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1111l
        return l11 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111111():
    if platform.system() == l11 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1llllll
        return l1llllll.l111111()
def l1l11l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11 (u"ࠩ࠱ࠫ࠶"))[0]
def l11l1ll(l1l):
    l11 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1ll111 = l11 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l:
        if l11 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1ll111[3:]) < int(protocol[l11 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1ll111 = protocol[l11 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1ll111
def l111l(l11ll11, l111ll1):
    l11 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11ll11 is None: l11ll11 = l11 (u"ࠩ࠳ࠫ࠽");
    if l111ll1 is None: l111ll1 = l11 (u"ࠪ࠴ࠬ࠾");
    l1lllll = l11ll11.split(l11 (u"ࠫ࠳࠭࠿"))
    l111l11 = l111ll1.split(l11 (u"ࠬ࠴ࠧࡀ"))
    while len(l1lllll) < len(l111l11): l1lllll.append(l11 (u"ࠨ࠰ࠣࡁ"));
    while len(l111l11) < len(l1lllll): l111l11.append(l11 (u"ࠢ࠱ࠤࡂ"));
    l1lllll = [ int(x) for x in l1lllll ]
    l111l11 = [ int(x) for x in l111l11 ]
    for  i in range(len(l1lllll)):
        if len(l111l11) == i:
            return 1
        if l1lllll[i] == l111l11[i]:
            continue
        elif l1lllll[i] > l111l11[i]:
            return 1
        else:
            return -1
    if len(l1lllll) != len(l111l11):
        return -1
    return 0