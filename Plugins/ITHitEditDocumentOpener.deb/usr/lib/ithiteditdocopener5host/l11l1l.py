#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def ll (l111):
    global l111ll
    l1111l = ord (l111 [-1])
    l11ll1 = l111 [:-1]
    l1ll = l1111l % len (l11ll1)
    l1l11 = l11ll1 [:l1ll] + l11ll1 [l1ll:]
    if l1llll:
        l11ll = l1l () .join ([unichr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    return eval (l11ll)
import os
import re
import subprocess
import l111l
from l111l import l1lll
def l11():
    return []
def l1111(l11l11, l1l1l1):
    logger = l1lll()
    l1ll1 = []
    l1ll1l = [ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1l:
        try:
            output = os.popen(cmd).read()
            l11l1 = 0
            l111l1 = {}
            if l11l1 == 0:
                l1l1ll = re.compile(ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11lll = re.compile(ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1 = re.search(l1l1ll, line)
                    l1 = l1l1.group(1)
                    if l11l11 == l1:
                        l11l = re.search(l11lll, line)
                        if l11l:
                            l1ll11 = ll (u"ࠨࡦࡤࡺࠬࠄ")+l11l.group(1)
                            version = l1l1.group(0)
                            if not l1ll11 in l111l1:
                                l111l1[l1ll11] = version
                            elif l111l.l1l11l(version, l111l1[l1ll11]) > 0:
                                l111l1[l1ll11] = version
            for l1ll11 in l111l1:
                l1ll1.append({ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l1[l1ll11], ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll11})
        except Exception as e:
            logger.error(str(e))
    return l1ll1