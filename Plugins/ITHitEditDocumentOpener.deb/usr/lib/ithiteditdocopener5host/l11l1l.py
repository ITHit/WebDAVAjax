#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1111l = 2048
ll = 7
def l1ll (l11l):
    global l1l111
    l1lll = ord (l11l [-1])
    l1l1l1 = l11l [:-1]
    l111l1 = l1lll % len (l1l1l1)
    l11l1 = l1l1l1 [:l111l1] + l1l1l1 [l111l1:]
    if l111l:
        l1l1ll = l111 () .join ([unichr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    return eval (l1l1ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1lll1l(l11lll1=None):
    if platform.system() == l1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1ll1
        props = {}
        try:
            prop_names = (l1ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1llllll = l1l1ll1.l111111(l11lll1, l1ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1ll in prop_names:
                l1l1l1l = l1ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1llllll, l11l1ll)
                props[l11l1ll] = l1l1ll1.l111111(l11lll1, l1l1l1l)
        except:
            pass
    return props
def l11l11l(logger, l111lll):
    l1ll111 = os.environ.get(l1ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1ll111 = l1ll111.upper()
    if l1ll111 == l1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111l1 = logging.DEBUG
    elif l1ll111 == l1ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111l1 = logging.INFO
    elif l1ll111 == l1ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111l1 = logging.WARNING
    elif l1ll111 == l1ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111l1 = logging.ERROR
    elif l1ll111 == l1ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111l1 = logging.CRITICAL
    elif l1ll111 == l1ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111l1 = logging.NOTSET
    logger.setLevel(l1111l1)
    l1ll1l1 = RotatingFileHandler(l111lll, maxBytes=1024*1024*5, backupCount=3)
    l1ll1l1.setLevel(l1111l1)
    formatter = logging.Formatter(l1ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1ll1l1.setFormatter(formatter)
    logger.addHandler(l1ll1l1)
    globals()[l1ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11():
    return globals()[l1ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11llll():
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l111l
        l1l111l.l1llll1(sys.stdin.fileno(), os.l1ll1ll)
        l1l111l.l1llll1(sys.stdout.fileno(), os.l1ll1ll)
def l11111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll1l():
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111ll1
        return l111ll1.l1l1111()
    elif platform.system() == l1ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1lll1():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111ll1
        return l111ll1.l1111ll()
    elif platform.system() == l1ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l1lll1()
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111l1l
        return l111l1l.l1lll1()
    return l1ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1lllll(l111ll, l1l):
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111ll1
        return l111ll1.l11ll11(l111ll, l1l)
    elif platform.system() == l1ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111l1l
        return l111l1l.l1l1l(l111ll, l1l)
    elif platform.system() == l1ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.l1l1l(l111ll, l1l)
    raise ValueError(l1ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l11l1(l1l11l, url):
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111ll1
        return l111ll1.l111l11(l1l11l, url)
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111l1l
        return l1ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return l1ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11111l():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111ll1
        return l111ll1.l11111l()
def l1l1l11(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll (u"ࠩ࠱ࠫ࠶"))[0]
def l11l111(l1111):
    l1ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1lll = l1ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1111:
        if l1ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1lll[3:]) < int(protocol[l1ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1lll = protocol[l1ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1lll
def l1(l1l11ll, l1lll11):
    l1ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l11ll is None: l1l11ll = l1ll (u"ࠩ࠳ࠫ࠽");
    if l1lll11 is None: l1lll11 = l1ll (u"ࠪ࠴ࠬ࠾");
    l1ll11l = l1l11ll.split(l1ll (u"ࠫ࠳࠭࠿"))
    l11l1l1 = l1lll11.split(l1ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll11l) < len(l11l1l1): l1ll11l.append(l1ll (u"ࠨ࠰ࠣࡁ"));
    while len(l11l1l1) < len(l1ll11l): l11l1l1.append(l1ll (u"ࠢ࠱ࠤࡂ"));
    l1ll11l = [ int(x) for x in l1ll11l ]
    l11l1l1 = [ int(x) for x in l11l1l1 ]
    for  i in range(len(l1ll11l)):
        if len(l11l1l1) == i:
            return 1
        if l1ll11l[i] == l11l1l1[i]:
            continue
        elif l1ll11l[i] > l11l1l1[i]:
            return 1
        else:
            return -1
    if len(l1ll11l) != len(l11l1l1):
        return -1
    return 0