#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1 = 7
def l1l1l1 (l111l):
    global l111ll
    l1111 = ord (l111l [-1])
    l1l11l = l111l [:-1]
    ll = l1111 % len (l1l11l)
    l11l11 = l1l11l [:ll] + l1l11l [ll:]
    if l1111l:
        l11lll = l1l111 () .join ([unichr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    return eval (l11lll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll11l(l111lll=None):
    if platform.system() == l1l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11ll11
        props = {}
        try:
            prop_names = (l1l1l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11l11l = l11ll11.l1111l1(l111lll, l1l1l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1l1 in prop_names:
                l1lllll = l1l1l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11l11l, l11l1l1)
                props[l11l1l1] = l11ll11.l1111l1(l111lll, l1lllll)
        except:
            pass
    return props
def l11111l(logger, l1llllll):
    l1l1111 = os.environ.get(l1l1l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1111 = l1l1111.upper()
    if l1l1111 == l1l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111ll1 = logging.DEBUG
    elif l1l1111 == l1l1l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111ll1 = logging.INFO
    elif l1l1111 == l1l1l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111ll1 = logging.WARNING
    elif l1l1111 == l1l1l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111ll1 = logging.ERROR
    elif l1l1111 == l1l1l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111ll1 = logging.CRITICAL
    elif l1l1111 == l1l1l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111ll1 = logging.NOTSET
    logger.setLevel(l111ll1)
    l111l1l = RotatingFileHandler(l1llllll, maxBytes=1024*1024*5, backupCount=3)
    l111l1l.setLevel(l111ll1)
    formatter = logging.Formatter(l1l1l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111l1l.setFormatter(formatter)
    logger.addHandler(l111l1l)
    globals()[l1l1l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1llll():
    return globals()[l1l1l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11llll():
    if platform.system() == l1l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l111l
        l1l111l.l1llll1(sys.stdin.fileno(), os.l111l11)
        l1l111l.l1llll1(sys.stdout.fileno(), os.l111l11)
def l11ll1l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l11ll():
    if platform.system() == l1l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111111
        return l111111.l11l111()
    elif platform.system() == l1l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l111l1():
    if platform.system() == l1l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111111
        return l111111.l1ll1ll()
    elif platform.system() == l1l1l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11
        return l11.l111l1()
    elif platform.system() == l1l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll111
        return l1ll111.l111l1()
    return l1l1l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l11(l1l, l11ll):
    if platform.system() == l1l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111111
        return l111111.l1l1ll1(l1l, l11ll)
    elif platform.system() == l1l1l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll111
        return l1ll111.l11l1l(l1l, l11ll)
    elif platform.system() == l1l1l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11
        return l11.l11l1l(l1l, l11ll)
    raise ValueError(l1l1l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1lll1l(l1lll, url):
    if platform.system() == l1l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111111
        return l111111.l1l11l1(l1lll, url)
    elif platform.system() == l1l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll111
        return l1l1l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11
        return l1l1l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll1l1():
    if platform.system() == l1l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111111
        return l111111.l1ll1l1()
def l1l1lll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1l1l(l1):
    l1l1l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1lll11 = l1l1l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1:
        if l1l1l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1lll11[3:]) < int(protocol[l1l1l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1lll11 = protocol[l1l1l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1lll11
def l1ll(l11l1ll, l11lll1):
    l1l1l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l1ll is None: l11l1ll = l1l1l1 (u"ࠩ࠳ࠫ࠽");
    if l11lll1 is None: l11lll1 = l1l1l1 (u"ࠪ࠴ࠬ࠾");
    l11111 = l11l1ll.split(l1l1l1 (u"ࠫ࠳࠭࠿"))
    l1111ll = l11lll1.split(l1l1l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l11111) < len(l1111ll): l11111.append(l1l1l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1111ll) < len(l11111): l1111ll.append(l1l1l1 (u"ࠢ࠱ࠤࡂ"));
    l11111 = [ int(x) for x in l11111 ]
    l1111ll = [ int(x) for x in l1111ll ]
    for  i in range(len(l11111)):
        if len(l1111ll) == i:
            return 1
        if l11111[i] == l1111ll[i]:
            continue
        elif l11111[i] > l1111ll[i]:
            return 1
        else:
            return -1
    if len(l11111) != len(l1111ll):
        return -1
    return 0