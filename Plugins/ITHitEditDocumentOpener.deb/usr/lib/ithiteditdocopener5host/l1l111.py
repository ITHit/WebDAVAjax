#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l1llll = 2048
l1l11 = 7
def l1ll1 (l1ll11):
    global l1l1l1
    l1111 = ord (l1ll11 [-1])
    ll = l1ll11 [:-1]
    l111l = l1111 % len (ll)
    l11l1l = ll [:l111l] + ll [l111l:]
    if l1l1:
        l11l = l111ll () .join ([unichr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    return eval (l11l)
import os
import re
import subprocess
import l1l1ll
from l1l1ll import l1lll
def l11l1():
    return []
def l111l1(l1l11l, l1l):
    logger = l1lll()
    l11l11 = []
    l1l1l = [l1ll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11 = process.wait()
            l1lll1 = {}
            if l11 == 0:
                l1ll = re.compile(l1ll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll = re.compile(l1ll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111 = re.search(l1ll, line)
                    l1ll1l = l111.group(1)
                    if l1l11l == l1ll1l:
                        l1111l = re.search(l11ll, line)
                        if l1111l:
                            l11lll = l1ll1 (u"ࠨࡦࡤࡺࠬࠄ")+l1111l.group(1)
                            version = l111.group(0)
                            if not l11lll in l1lll1:
                                l1lll1[l11lll] = version
                            elif l1l1ll.l11ll1(version, l1lll1[l11lll]) > 0:
                                l1lll1[l11lll] = version
            for l11lll in l1lll1:
                l11l11.append({l1ll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll1[l11lll], l1ll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11lll})
        except Exception as e:
            logger.error(str(e))
    return l11l11