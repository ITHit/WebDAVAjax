#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1l1 (l1l):
    global l1l1l
    l11l = ord (l1l [-1])
    l11lll = l1l [:-1]
    l1lll = l11l % len (l11lll)
    l1ll = l11lll [:l1lll] + l11lll [l1lll:]
    if l1l11l:
        l1ll11 = l1lll1 () .join ([unichr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    return eval (l1ll11)
import os
import re
import subprocess
import l1l11
from l1l11 import l11l11
def l11l1():
    return []
def ll(l1, l111l1):
    logger = l11l11()
    l11ll = []
    l1ll1 = [l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1:
        try:
            output = os.popen(cmd).read()
            l111 = 0
            l1111l = {}
            if l111 == 0:
                l11ll1 = re.compile(l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1111 = re.compile(l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1llll = re.search(l11ll1, line)
                    l111l = l1llll.group(1)
                    if l1 == l111l:
                        l11 = re.search(l1111, line)
                        if l11:
                            l11l1l = l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l11.group(1)
                            version = l1llll.group(0)
                            if not l11l1l in l1111l:
                                l1111l[l11l1l] = version
                            elif l1l11.l1l1ll(version, l1111l[l11l1l]) > 0:
                                l1111l[l11l1l] = version
            for l11l1l in l1111l:
                l11ll.append({l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111l[l11l1l], l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1l})
        except Exception as e:
            logger.error(str(e))
    return l11ll