#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111ll (l1l1l):
    global l11ll
    l1111l = ord (l1l1l [-1])
    l11l = l1l1l [:-1]
    l11l1l = l1111l % len (l11l)
    l1l11l = l11l [:l11l1l] + l11l [l11l1l:]
    if l1ll11:
        l1ll1l = l1l1l1 () .join ([unichr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import os
import re
import subprocess
import l111l1
from l111l1 import l1l1
def l11lll():
    return []
def l1l1ll(l1l11, l11l1):
    logger = l1l1()
    l1 = []
    l1111 = [l111ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1111:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll1 = process.wait()
            l1ll1 = {}
            if l11ll1 == 0:
                l111 = re.compile(l111ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l = re.compile(l111ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l11 = re.search(l111, line)
                    l1llll = l11l11.group(1)
                    if l1l11 == l1llll:
                        l1lll = re.search(l1l, line)
                        if l1lll:
                            l1lll1 = l111ll (u"ࠨࡦࡤࡺࠬࠄ")+l1lll.group(1)
                            version = l11l11.group(0)
                            if not l1lll1 in l1ll1:
                                l1ll1[l1lll1] = version
                            elif l111l1.l1ll(version, l1ll1[l1lll1]) > 0:
                                l1ll1[l1lll1] = version
            for l1lll1 in l1ll1:
                l1.append({l111ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1[l1lll1], l111ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1lll1})
        except Exception as e:
            logger.error(str(e))
    return l1