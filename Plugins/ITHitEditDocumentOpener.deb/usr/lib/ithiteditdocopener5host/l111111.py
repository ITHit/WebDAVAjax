#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1l11l = 2048
l1lll = 7
def l11ll (l1111):
    global l1l11
    l111 = ord (l1111 [-1])
    l1ll1 = l1111 [:-1]
    l1llll = l111 % len (l1ll1)
    l11 = l1ll1 [:l1llll] + l1ll1 [l1llll:]
    if l1ll:
        l1 = l11l1l () .join ([unichr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    return eval (l1)
import l11l11
from l1l1l11l import l1l1l111
import objc as _1111l11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111l11.l11111l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l111l1l1(l111ll11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll (u"ࠨࠩࢬ"), {l11ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1ll(l111l111):
    l111l111 = (l111l111 + l11ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111111l = CFStringCreateWithCString( kCFAllocatorDefault, l111l111, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l111111l, _1111l11.nil )
    l111lll1 = LaunchServices.l1111l1l( l11111ll, LaunchServices.l1111ll1, _1111l11.nil )
    if l111lll1[0] is not None:
        return True
    return False
def l111l():
    l111l11l = []
    for name in l1l1l111:
        try:
            if l111l1ll(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def ll(l1111l, l11l1):
    import plistlib
    import os
    l1l1ll = []
    l11l = {}
    for l111llll in os.listdir(l11ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l11l1):
            try:
                l111ll1l = l11ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l111ll1l, l11ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1l1 = plist[l11ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l11ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111l == l1111111:
                        if not l1l1l1 in l11l:
                            l11l[l1l1l1] = version
                        elif l11l11.l111l1(version, l11l[l1l1l1]) > 0:
                            l11l[l1l1l1] = version
            except BaseException:
                continue
    for l1l1l1 in l11l:
        l1l1ll.append({l11ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l[l1l1l1], l11ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1l1})
    return l1l1ll