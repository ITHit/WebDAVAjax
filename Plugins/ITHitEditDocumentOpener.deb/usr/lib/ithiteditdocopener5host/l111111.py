#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111l1 = 2048
l1l111 = 7
def l1l11l (l1ll1l):
    global l1
    l11lll = ord (l1ll1l [-1])
    l1lll = l1ll1l [:-1]
    l111l = l11lll % len (l1lll)
    l1llll = l1lll [:l111l] + l1lll [l111l:]
    if l1l1l:
        l1111l = l1l1l1 () .join ([unichr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    return eval (l1111l)
import l1l1
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l111llll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l11l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l111l111(l11111ll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111ll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l11l (u"ࠨࠩࢬ"), {l1l11l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l11l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l11l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l11l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l11l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l11l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l11l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111111l(l111l1ll):
    l111l1ll = (l111l1ll + l1l11l (u"ࠩ࠽ࠫࢴ")).encode()
    l111lll1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l111l11l = CFURLCreateWithString( kCFAllocatorDefault, l111lll1, _1111ll1.nil )
    l1111l11 = LaunchServices.l1111l1l( l111l11l, LaunchServices.l1111lll, _1111ll1.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l1ll():
    l111l1l1 = []
    for name in l1l1l111:
        try:
            if l111111l(name):
                l111l1l1.append(name)
        except:
            continue
    return l111l1l1
def l1l(l1l1ll, ll):
    import plistlib
    import os
    l1ll11 = []
    l111ll = {}
    for l111ll1l in os.listdir(l1l11l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(ll):
            try:
                l111ll11 = l1l11l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l111ll11, l1l11l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l11 = plist[l1l11l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l11l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l11l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l1l11l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1ll == l1111111:
                        if not l1l11 in l111ll:
                            l111ll[l1l11] = version
                        elif l1l1.l11ll(version, l111ll[l1l11]) > 0:
                            l111ll[l1l11] = version
            except BaseException:
                continue
    for l1l11 in l111ll:
        l1ll11.append({l1l11l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111ll[l1l11], l1l11l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l11})
    return l1ll11