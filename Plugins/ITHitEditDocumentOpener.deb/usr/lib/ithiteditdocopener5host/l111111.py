#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1 = 7
def l11l1l (l11lll):
    global l111ll
    l1lll = ord (l11lll [-1])
    l1l111 = l11lll [:-1]
    l1ll1 = l1lll % len (l1l111)
    l1llll = l1l111 [:l1ll1] + l1l111 [l1ll1:]
    if l11:
        l11l = l111l1 () .join ([unichr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l1 - (l1ll11 + l1lll) % l11l1) for l1ll11, char in enumerate (l1llll)])
    return eval (l11l)
import l1l11
from l1l1l111 import l1l1l11l
import objc as _111llll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111llll.l1111l11( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111ll.l111l1ll(l1111l1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l1l (u"ࠨࠩࢬ"), {l11l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111ll1l):
    l111ll1l = (l111ll1l + l11l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111lll1 = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l111lll1, _111llll.nil )
    l1111ll1 = LaunchServices.l111l1l1( l111111l, LaunchServices.l111ll11, _111llll.nil )
    if l1111ll1[0] is not None:
        return True
    return False
def l11l11():
    l11111l1 = []
    for name in l1l1l11l:
        try:
            if l1111111(name):
                l11111l1.append(name)
        except:
            continue
    return l11111l1
def l1(l1111, l1111l):
    import plistlib
    import os
    l11ll = []
    l111l = {}
    for l111l11l in os.listdir(l11l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l11l.startswith(l1111l):
            try:
                l111l111 = l11l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l11l
                with open(l111l111, l11l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1ll = plist[l11l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111lll = version.split(l11l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111 == l1111lll:
                        if not l1l1ll in l111l:
                            l111l[l1l1ll] = version
                        elif l1l11.l11ll1(version, l111l[l1l1ll]) > 0:
                            l111l[l1l1ll] = version
            except BaseException:
                continue
    for l1l1ll in l111l:
        l11ll.append({l11l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111l[l1l1ll], l11l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1ll})
    return l11ll