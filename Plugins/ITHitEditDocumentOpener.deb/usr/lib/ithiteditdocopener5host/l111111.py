#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1l1 = 7
def l1l111 (l111ll):
    global l1l11l
    l11l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l11l1 % len (l1llll)
    ll = l1llll [:l11l] + l1llll [l11l:]
    if l1l11:
        l11 = l1l1ll () .join ([unichr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    else:
        l11 = str () .join ([chr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    return eval (l11)
import l1l
from l1l1l111 import l1l1l11l
import objc as _111lll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111lll1.l111l1l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l111 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l1111l1l(l111l111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l111 (u"ࠨࠩࢬ"), {l1l111 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l111 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l111 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l111 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l111 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l111 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l111 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l111llll):
    l111llll = (l111llll + l1l111 (u"ࠩ࠽ࠫࢴ")).encode()
    l11111ll = CFStringCreateWithCString( kCFAllocatorDefault, l111llll, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l11111ll, _111lll1.nil )
    l111ll1l = LaunchServices.l111ll11( l111111l, LaunchServices.l1111111, _111lll1.nil )
    if l111ll1l[0] is not None:
        return True
    return False
def l11l1l():
    l11111l1 = []
    for name in l1l1l11l:
        try:
            if l111l11l(name):
                l11111l1.append(name)
        except:
            continue
    return l11111l1
def l11ll(l1ll1l, l1l1l):
    import plistlib
    import os
    l1 = []
    l1111 = {}
    for l1111l11 in os.listdir(l1l111 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111l11.startswith(l1l1l):
            try:
                l111l1ll = l1l111 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111l11
                with open(l111l1ll, l1l111 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1lll1 = plist[l1l111 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l111 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l111 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111ll1 = version.split(l1l111 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll1l == l1111ll1:
                        if not l1lll1 in l1111:
                            l1111[l1lll1] = version
                        elif l1l.l11lll(version, l1111[l1lll1]) > 0:
                            l1111[l1lll1] = version
            except BaseException:
                continue
    for l1lll1 in l1111:
        l1.append({l1l111 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111[l1lll1], l1l111 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1lll1})
    return l1