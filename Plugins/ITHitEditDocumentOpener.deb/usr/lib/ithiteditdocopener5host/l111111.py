#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1 = 7
def l1l1l1 (l111l):
    global l111ll
    l1111 = ord (l111l [-1])
    l1l11l = l111l [:-1]
    ll = l1111 % len (l1l11l)
    l11l11 = l1l11l [:ll] + l1l11l [ll:]
    if l1111l:
        l11lll = l1l111 () .join ([unichr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    else:
        l11lll = str () .join ([chr (ord (char) - l1ll1 - (l11ll1 + l1111) % l1l1) for l11ll1, char in enumerate (l11l11)])
    return eval (l11lll)
import subprocess, threading
from l111 import l1llll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l111():
    l1l11ll1 = [l1l1l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11ll1:
        try:
            l1l111l1 = l1l1l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11111 = winreg.l11l1lll(winreg.l11l111l, l1l111l1)
        except l11lll11:
            continue
        value = winreg.l11l1l11(l1l11111, l1l1l1 (u"ࠦࠧ࢓"))
        return value.split(l1l1l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll1ll():
    l1l1111l = []
    for name in l1l1l11l:
        try:
            l1l111l1 = l1l1l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1ll = winreg.l11l1lll(winreg.l11l111l, l1l111l1)
            if winreg.l11l1l11(l11ll1ll, l1l1l1 (u"ࠢࠣ࢖")):
                l1l1111l.append(name)
        except l11lll11:
            continue
    return l1l1111l
def l1l1ll1(l1l, l11ll):
    import re
    l11l1 = []
    l1l11lll = winreg.l11l1lll(winreg.l11l111l, l1l1l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l11ll(l1l11lll)[0]):
        try:
            l11l1l1l = winreg.l11ll111(l1l11lll, i)
            if l11l1l1l.startswith(l11ll):
                l11lllll = winreg.l1l111ll(l1l11lll, l11l1l1l)
                value, l1l11l1l = winreg.l11llll1(l11lllll, l1l1l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1ll1 = {l1l1l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11l11 = m.group(2)
                    if l1l == l1l11l11:
                        m = re.search(l11ll.replace(l1l1l1 (u"ࠬ࠴࢛ࠧ"), l1l1l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1l1l)
                        l11l1ll1[l1l1l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11l1.append(l11l1ll1)
                else:
                    raise ValueError(l1l1l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11lll11 as ex:
            continue
    return l11l1
def l11ll1l1(l1lll):
    try:
        l11l11l1 = l1l1l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1lll)
        l11l1111 = winreg.l11l1lll(winreg.l11l111l, l11l11l1)
        value, l1l11l1l = winreg.l11llll1(l11l1111, l1l1l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1l1 (u"ࠬࠨࠧࢢ"))[1]
    except l11lll11:
        pass
    return l1l1l1 (u"࠭ࠧࢣ")
def l1l11l1(l1lll, url):
    threading.Thread(target=_11lll1l,args=(l1lll, url)).start()
    return l1l1l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lll1l(l1lll, url):
    logger = l1llll()
    l11ll11l = l11ll1l1(l1lll)
    logger.debug(l1l1l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll11l, url))
    retcode = subprocess.Popen(l1l1l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll11l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)