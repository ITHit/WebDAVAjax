#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l1l1ll (l1ll):
    global l111l1
    l11l11 = ord (l1ll [-1])
    l11l1 = l1ll [:-1]
    l1l11 = l11l11 % len (l11l1)
    l111l = l11l1 [:l1l11] + l11l1 [l1l11:]
    if l1l1l:
        l1l11l = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1l - (l11l + l11l11) % ll) for l11l, char in enumerate (l111l)])
    return eval (l1l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll111(l11l1l1=None):
    if platform.system() == l1l1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111ll1
        props = {}
        try:
            prop_names = (l1l1ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11l1ll = l111ll1.l1l111l(l11l1l1, l1l1ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l111 in prop_names:
                l11ll11 = l1l1ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11l1ll, l11l111)
                props[l11l111] = l111ll1.l1l111l(l11l1l1, l11ll11)
        except:
            pass
    return props
def l1ll11l(logger, l11111l):
    l1l1l1l = os.environ.get(l1l1ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l1l1l = l1l1l1l.upper()
    if l1l1l1l == l1l1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l11ll = logging.DEBUG
    elif l1l1l1l == l1l1ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l11ll = logging.INFO
    elif l1l1l1l == l1l1ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l11ll = logging.WARNING
    elif l1l1l1l == l1l1ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l11ll = logging.ERROR
    elif l1l1l1l == l1l1ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l11ll = logging.CRITICAL
    elif l1l1l1l == l1l1ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l11ll = logging.NOTSET
    logger.setLevel(l1l11ll)
    l11llll = RotatingFileHandler(l11111l, maxBytes=1024*1024*5, backupCount=3)
    l11llll.setLevel(l1l11ll)
    formatter = logging.Formatter(l1l1ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11llll.setFormatter(formatter)
    logger.addHandler(l11llll)
    globals()[l1l1ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l111():
    return globals()[l1l1ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll1ll():
    if platform.system() == l1l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1lll11
        l1lll11.l1l1l11(sys.stdin.fileno(), os.l1llll1)
        l1lll11.l1l1l11(sys.stdout.fileno(), os.l1llll1)
def l1l1ll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111lll():
    if platform.system() == l1l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1lllll
        return l1lllll.l111l1l()
    elif platform.system() == l1l1ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1():
    if platform.system() == l1l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1lllll
        return l1lllll.l1l1lll()
    elif platform.system() == l1l1ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1llll
        return l1llll.l1()
    elif platform.system() == l1l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1llllll
        return l1llllll.l1()
    return l1l1ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111111(l1l1l1, l1ll1l):
    if platform.system() == l1l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1lllll
        return l1lllll.l111l11(l1l1l1, l1ll1l)
    elif platform.system() == l1l1ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1llllll
        return l1llllll.l11ll(l1l1l1, l1ll1l)
    elif platform.system() == l1l1ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1llll
        return l1llll.l11ll(l1l1l1, l1ll1l)
    raise ValueError(l1l1ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1111ll(l11, url):
    if platform.system() == l1l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1lllll
        return l1lllll.l1lll1l(l11, url)
    elif platform.system() == l1l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1llllll
        return l1l1ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1llll
        return l1l1ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11l11l():
    if platform.system() == l1l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1lllll
        return l1lllll.l11l11l()
def l1ll1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1ll (u"ࠩ࠱ࠫ࠶"))[0]
def l11lll1(l1l111):
    l1l1ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111 = l1l1ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l111:
        if l1l1ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111[3:]) < int(protocol[l1l1ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111 = protocol[l1l1ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111
def l1111l(l11ll1l, l1111l1):
    l1l1ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11ll1l is None: l11ll1l = l1l1ll (u"ࠩ࠳ࠫ࠽");
    if l1111l1 is None: l1111l1 = l1l1ll (u"ࠪ࠴ࠬ࠾");
    l1l11l1 = l11ll1l.split(l1l1ll (u"ࠫ࠳࠭࠿"))
    l1l1111 = l1111l1.split(l1l1ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1l11l1) < len(l1l1111): l1l11l1.append(l1l1ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1111) < len(l1l11l1): l1l1111.append(l1l1ll (u"ࠢ࠱ࠤࡂ"));
    l1l11l1 = [ int(x) for x in l1l11l1 ]
    l1l1111 = [ int(x) for x in l1l1111 ]
    for  i in range(len(l1l11l1)):
        if len(l1l1111) == i:
            return 1
        if l1l11l1[i] == l1l1111[i]:
            continue
        elif l1l11l1[i] > l1l1111[i]:
            return 1
        else:
            return -1
    if len(l1l11l1) != len(l1l1111):
        return -1
    return 0