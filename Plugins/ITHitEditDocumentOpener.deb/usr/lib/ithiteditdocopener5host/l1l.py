#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l1l (l11ll1):
    global l1l1ll
    l1llll = ord (l11ll1 [-1])
    l11l1l = l11ll1 [:-1]
    l111 = l1llll % len (l11l1l)
    l11lll = l11l1l [:l111] + l11l1l [l111:]
    if l111l1:
        l11l = l111l () .join ([unichr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    return eval (l11l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11l1l1(l1l1lll=None):
    if platform.system() == l1l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1111
        props = {}
        try:
            prop_names = (l1l1l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11llll = l1l1111.l111lll(l1l1lll, l1l1l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111ll1 in prop_names:
                l1111l1 = l1l1l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11llll, l111ll1)
                props[l111ll1] = l1l1111.l111lll(l1l1lll, l1111l1)
        except:
            pass
    return props
def l111111(logger, l1l11ll):
    l1l11l1 = os.environ.get(l1l1l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l11l1 = l1l11l1.upper()
    if l1l11l1 == l1l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111ll = logging.DEBUG
    elif l1l11l1 == l1l1l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111ll = logging.INFO
    elif l1l11l1 == l1l1l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111ll = logging.WARNING
    elif l1l11l1 == l1l1l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111ll = logging.ERROR
    elif l1l11l1 == l1l1l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111ll = logging.CRITICAL
    elif l1l11l1 == l1l1l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111ll = logging.NOTSET
    logger.setLevel(l1111ll)
    l1llll1 = RotatingFileHandler(l1l11ll, maxBytes=1024*1024*5, backupCount=3)
    l1llll1.setLevel(l1111ll)
    formatter = logging.Formatter(l1l1l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1llll1.setFormatter(formatter)
    logger.addHandler(l1llll1)
    globals()[l1l1l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l11():
    return globals()[l1l1l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1ll1():
    if platform.system() == l1l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1lll11
        l1lll11.l1l1l11(sys.stdin.fileno(), os.l1ll111)
        l1lll11.l1l1l11(sys.stdout.fileno(), os.l1ll111)
def l1l1l1l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11111l():
    if platform.system() == l1l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1ll1l1
        return l1ll1l1.l111l1l()
    elif platform.system() == l1l1l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def ll():
    if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1ll1l1
        return l1ll1l1.l111l11()
    elif platform.system() == l1l1l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1lll
        return l1lll.ll()
    elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1lll1l
        return l1lll1l.ll()
    return l1l1l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11ll11(l1ll11, l1l111):
    if platform.system() == l1l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1ll1l1
        return l1ll1l1.l11lll1(l1ll11, l1l111)
    elif platform.system() == l1l1l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1lll1l
        return l1lll1l.l1ll1l(l1ll11, l1l111)
    elif platform.system() == l1l1l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1lll
        return l1lll.l1ll1l(l1ll11, l1l111)
    raise ValueError(l1l1l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l111(l1, url):
    if platform.system() == l1l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1ll1l1
        return l1ll1l1.l11ll1l(l1, url)
    elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1lll1l
        return l1l1l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1lll
        return l1l1l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1ll1ll():
    if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1ll1l1
        return l1ll1l1.l1ll1ll()
def l1l111l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1l (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll11l(l1ll1):
    l1l1l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11111 = l1l1l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1:
        if l1l1l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11111[3:]) < int(protocol[l1l1l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11111 = protocol[l1l1l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11111
def l111ll(l1llllll, l1lllll):
    l1l1l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1llllll is None: l1llllll = l1l1l (u"ࠩ࠳ࠫ࠽");
    if l1lllll is None: l1lllll = l1l1l (u"ࠪ࠴ࠬ࠾");
    l11l11l = l1llllll.split(l1l1l (u"ࠫ࠳࠭࠿"))
    l11l1ll = l1lllll.split(l1l1l (u"ࠬ࠴ࠧࡀ"))
    while len(l11l11l) < len(l11l1ll): l11l11l.append(l1l1l (u"ࠨ࠰ࠣࡁ"));
    while len(l11l1ll) < len(l11l11l): l11l1ll.append(l1l1l (u"ࠢ࠱ࠤࡂ"));
    l11l11l = [ int(x) for x in l11l11l ]
    l11l1ll = [ int(x) for x in l11l1ll ]
    for  i in range(len(l11l11l)):
        if len(l11l1ll) == i:
            return 1
        if l11l11l[i] == l11l1ll[i]:
            continue
        elif l11l11l[i] > l11l1ll[i]:
            return 1
        else:
            return -1
    if len(l11l11l) != len(l11l1ll):
        return -1
    return 0