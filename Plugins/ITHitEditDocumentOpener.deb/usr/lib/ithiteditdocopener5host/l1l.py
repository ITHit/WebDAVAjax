#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1l11 = 2048
l11l1 = 7
def l1llll (l1l1ll):
    global l111
    l11lll = ord (l1l1ll [-1])
    l1111l = l1l1ll [:-1]
    l1 = l11lll % len (l1111l)
    l1lll = l1111l [:l1] + l1111l [l1:]
    if l111l1:
        l1l1l = l111ll () .join ([unichr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    return eval (l1l1l)
import os
import re
import subprocess
import l1ll
from l1ll import l11
def l11l():
    return []
def l1lll1(l11l11, l11ll):
    logger = l11()
    l1l1 = []
    l1ll1 = [l1llll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1llll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l11l = process.wait()
            ll = {}
            if l1l11l == 0:
                l11l1l = re.compile(l1llll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11ll1 = re.compile(l1llll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111l = re.search(l11l1l, line)
                    l1l111 = l111l.group(1)
                    if l11l11 == l1l111:
                        l1l1l1 = re.search(l11ll1, line)
                        if l1l1l1:
                            l1ll1l = l1llll (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l1.group(1)
                            version = l111l.group(0)
                            if not l1ll1l in ll:
                                ll[l1ll1l] = version
                            elif l1ll.l1111(version, ll[l1ll1l]) > 0:
                                ll[l1ll1l] = version
            for l1ll1l in ll:
                l1l1.append({l1llll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): ll[l1ll1l], l1llll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll1l})
        except Exception as e:
            logger.error(str(e))
    return l1l1