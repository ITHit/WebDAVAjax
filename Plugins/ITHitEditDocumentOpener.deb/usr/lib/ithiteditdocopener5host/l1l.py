#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1lll1 = 2048
l111l = 7
def l1l1 (l1ll11):
    global l1
    l1l1l = ord (l1ll11 [-1])
    l11ll1 = l1ll11 [:-1]
    l11l11 = l1l1l % len (l11ll1)
    l1l11l = l11ll1 [:l11l11] + l11ll1 [l11l11:]
    if l1ll1:
        l1llll = l1l111 () .join ([unichr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    return eval (l1llll)
import os
import re
import subprocess
import l11
from l11 import l1lll
def l11l1l():
    return []
def l1ll(l11l1, ll):
    logger = l1lll()
    l1111 = []
    l1ll1l = [l1l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111 = process.wait()
            l11ll = {}
            if l111 == 0:
                l1111l = re.compile(l1l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11 = re.compile(l1l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111ll = re.search(l1111l, line)
                    l1l1l1 = l111ll.group(1)
                    if l11l1 == l1l1l1:
                        l1l1ll = re.search(l1l11, line)
                        if l1l1ll:
                            l11lll = l1l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1ll.group(1)
                            version = l111ll.group(0)
                            if not l11lll in l11ll:
                                l11ll[l11lll] = version
                            elif l11.l11l(version, l11ll[l11lll]) > 0:
                                l11ll[l11lll] = version
            for l11lll in l11ll:
                l1111.append({l1l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11ll[l11lll], l1l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11lll})
        except Exception as e:
            logger.error(str(e))
    return l1111