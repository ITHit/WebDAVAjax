#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l11l1 = 2048
l1l1l1 = 7
def l11l (ll):
    global l1ll1
    l11l1l = ord (ll [-1])
    l11ll1 = ll [:-1]
    l1l11 = l11l1l % len (l11ll1)
    l11ll = l11ll1 [:l1l11] + l11ll1 [l1l11:]
    if l1l111:
        l111 = l1ll11 () .join ([unichr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    return eval (l111)
import os
import re
import subprocess
import l11lll
from l11lll import l1ll1l
def l111ll():
    return []
def l1l11l(l1ll, l1111):
    logger = l1ll1l()
    l111l = []
    l1111l = [l11l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1111l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1l = process.wait()
            l1lll = {}
            if l1l1l == 0:
                l1l1 = re.compile(l11l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1 = re.compile(l11l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1llll = re.search(l1l1, line)
                    l11l11 = l1llll.group(1)
                    if l1ll == l11l11:
                        l111l1 = re.search(l1, line)
                        if l111l1:
                            l1lll1 = l11l (u"ࠨࡦࡤࡺࠬࠄ")+l111l1.group(1)
                            version = l1llll.group(0)
                            if not l1lll1 in l1lll:
                                l1lll[l1lll1] = version
                            elif l11lll.l1l1ll(version, l1lll[l1lll1]) > 0:
                                l1lll[l1lll1] = version
            for l1lll1 in l1lll:
                l111l.append({l11l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll[l1lll1], l11l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1lll1})
        except Exception as e:
            logger.error(str(e))
    return l111l