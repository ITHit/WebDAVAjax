#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1l1 = 7
def l1l111 (l111ll):
    global l1l11l
    l11l1 = ord (l111ll [-1])
    l1llll = l111ll [:-1]
    l11l = l11l1 % len (l1llll)
    ll = l1llll [:l11l] + l1llll [l11l:]
    if l1l11:
        l11 = l1l1ll () .join ([unichr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    else:
        l11 = str () .join ([chr (ord (char) - l1ll11 - (l111l1 + l11l1) % l1l1) for l111l1, char in enumerate (ll)])
    return eval (l11)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1111ll(l1lllll=None):
    if platform.system() == l1l111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1lll11
        props = {}
        try:
            prop_names = (l1l111 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l111 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l111 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l111 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l111 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l111 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l111 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l111 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l111 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l111 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l111 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l111 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11l1l1 = l1lll11.l1l11l1(l1lllll, l1l111 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11ll1l in prop_names:
                l1l1l11 = l1l111 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11l1l1, l11ll1l)
                props[l11ll1l] = l1lll11.l1l11l1(l1lllll, l1l1l11)
        except:
            pass
    return props
def l11l11l(logger, l1llll1):
    l1lll1l = os.environ.get(l1l111 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l111 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1lll1l = l1lll1l.upper()
    if l1lll1l == l1l111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1ll111 = logging.DEBUG
    elif l1lll1l == l1l111 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1ll111 = logging.INFO
    elif l1lll1l == l1l111 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1ll111 = logging.WARNING
    elif l1lll1l == l1l111 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1ll111 = logging.ERROR
    elif l1lll1l == l1l111 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1ll111 = logging.CRITICAL
    elif l1lll1l == l1l111 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1ll111 = logging.NOTSET
    logger.setLevel(l1ll111)
    l1l1l1l = RotatingFileHandler(l1llll1, maxBytes=1024*1024*5, backupCount=3)
    l1l1l1l.setLevel(l1ll111)
    formatter = logging.Formatter(l1l111 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1l1l.setFormatter(formatter)
    logger.addHandler(l1l1l1l)
    globals()[l1l111 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1111l():
    return globals()[l1l111 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l111l():
    if platform.system() == l1l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l111 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1111
        l1l1111.l11111l(sys.stdin.fileno(), os.l1llllll)
        l1l1111.l11111l(sys.stdout.fileno(), os.l1llllll)
def l11llll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l111 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1lll():
    if platform.system() == l1l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111l1l
        return l111l1l.l1l1ll1()
    elif platform.system() == l1l111 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l1l():
    if platform.system() == l1l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111l1l
        return l111l1l.l1ll1l1()
    elif platform.system() == l1l111 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11l11
        return l11l11.l11l1l()
    elif platform.system() == l1l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111111
        return l111111.l11l1l()
    return l1l111 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11111(l1ll1l, l1l1l):
    if platform.system() == l1l111 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111l1l
        return l111l1l.l1ll11l(l1ll1l, l1l1l)
    elif platform.system() == l1l111 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111111
        return l111111.l11ll(l1ll1l, l1l1l)
    elif platform.system() == l1l111 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11l11
        return l11l11.l11ll(l1ll1l, l1l1l)
    raise ValueError(l1l111 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111l11(l1lll1, url):
    if platform.system() == l1l111 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111l1l
        return l111l1l.l111ll1(l1lll1, url)
    elif platform.system() == l1l111 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111111
        return l1l111 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l111 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11l11
        return l1l111 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l111 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11l1ll():
    if platform.system() == l1l111 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111l1l
        return l111l1l.l11l1ll()
def l1ll1ll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l111 (u"ࠩ࠱ࠫ࠶"))[0]
def l11ll11(l1111):
    l1l111 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1111l1 = l1l111 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1111:
        if l1l111 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1111l1[3:]) < int(protocol[l1l111 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1111l1 = protocol[l1l111 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1111l1
def l11lll(l11lll1, l1l11ll):
    l1l111 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11lll1 is None: l11lll1 = l1l111 (u"ࠩ࠳ࠫ࠽");
    if l1l11ll is None: l1l11ll = l1l111 (u"ࠪ࠴ࠬ࠾");
    l11l111 = l11lll1.split(l1l111 (u"ࠫ࠳࠭࠿"))
    l111lll = l1l11ll.split(l1l111 (u"ࠬ࠴ࠧࡀ"))
    while len(l11l111) < len(l111lll): l11l111.append(l1l111 (u"ࠨ࠰ࠣࡁ"));
    while len(l111lll) < len(l11l111): l111lll.append(l1l111 (u"ࠢ࠱ࠤࡂ"));
    l11l111 = [ int(x) for x in l11l111 ]
    l111lll = [ int(x) for x in l111lll ]
    for  i in range(len(l11l111)):
        if len(l111lll) == i:
            return 1
        if l11l111[i] == l111lll[i]:
            continue
        elif l11l111[i] > l111lll[i]:
            return 1
        else:
            return -1
    if len(l11l111) != len(l111lll):
        return -1
    return 0