#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l11l1l = 7
def l11ll (l1ll1):
    global l1l1l
    l1l11 = ord (l1ll1 [-1])
    l11l11 = l1ll1 [:-1]
    l1l111 = l1l11 % len (l11l11)
    l1ll1l = l11l11 [:l1l111] + l11l11 [l1l111:]
    if l1ll11:
        l1 = l11lll () .join ([unichr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    return eval (l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11lll1(l111l11=None):
    if platform.system() == l11ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l11ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11ll1l = l1l1lll.l1111ll(l111l11, l11ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l11l1 in prop_names:
                l11l11l = l11ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11ll1l, l1l11l1)
                props[l1l11l1] = l1l1lll.l1111ll(l111l11, l11l11l)
        except:
            pass
    return props
def l1ll1l1(logger, l1111l1):
    l1lll1l = os.environ.get(l11ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1lll1l = l1lll1l.upper()
    if l1lll1l == l11ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1ll1 = logging.DEBUG
    elif l1lll1l == l11ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1ll1 = logging.INFO
    elif l1lll1l == l11ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1ll1 = logging.WARNING
    elif l1lll1l == l11ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1ll1 = logging.ERROR
    elif l1lll1l == l11ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1ll1 = logging.CRITICAL
    elif l1lll1l == l11ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1ll1 = logging.NOTSET
    logger.setLevel(l1l1ll1)
    l1lllll = RotatingFileHandler(l1111l1, maxBytes=1024*1024*5, backupCount=3)
    l1lllll.setLevel(l1l1ll1)
    formatter = logging.Formatter(l11ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lllll.setFormatter(formatter)
    logger.addHandler(l1lllll)
    globals()[l11ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11l1():
    return globals()[l11ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11llll():
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l111lll
        l111lll.l1ll11l(sys.stdin.fileno(), os.l11l1ll)
        l111lll.l1ll11l(sys.stdout.fileno(), os.l11l1ll)
def l111111(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l1l():
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111ll1
        return l111ll1.l1l11ll()
    elif platform.system() == l11ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111ll1
        return l111ll1.l1ll1ll()
    elif platform.system() == l11ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1lll1
        return l1lll1.l11()
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1llll1
        return l1llll1.l11()
    return l11ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l111l(l111, l11ll1):
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111ll1
        return l111ll1.l1l1111(l111, l11ll1)
    elif platform.system() == l11ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1llll1
        return l1llll1.l11l(l111, l11ll1)
    elif platform.system() == l11ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1lll1
        return l1lll1.l11l(l111, l11ll1)
    raise ValueError(l11ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11l1l1(l1llll, url):
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111ll1
        return l111ll1.l11111(l1llll, url)
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1llll1
        return l11ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1lll1
        return l11ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1lll11():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111ll1
        return l111ll1.l1lll11()
def l1l1l1l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1llllll(l1lll):
    l11ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1ll111 = l11ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1lll:
        if l11ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1ll111[3:]) < int(protocol[l11ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1ll111 = protocol[l11ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1ll111
def l1l(l1l1l11, l11111l):
    l11ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1l11 is None: l1l1l11 = l11ll (u"ࠩ࠳ࠫ࠽");
    if l11111l is None: l11111l = l11ll (u"ࠪ࠴ࠬ࠾");
    l11l111 = l1l1l11.split(l11ll (u"ࠫ࠳࠭࠿"))
    l11ll11 = l11111l.split(l11ll (u"ࠬ࠴ࠧࡀ"))
    while len(l11l111) < len(l11ll11): l11l111.append(l11ll (u"ࠨ࠰ࠣࡁ"));
    while len(l11ll11) < len(l11l111): l11ll11.append(l11ll (u"ࠢ࠱ࠤࡂ"));
    l11l111 = [ int(x) for x in l11l111 ]
    l11ll11 = [ int(x) for x in l11ll11 ]
    for  i in range(len(l11l111)):
        if len(l11ll11) == i:
            return 1
        if l11l111[i] == l11ll11[i]:
            continue
        elif l11l111[i] > l11ll11[i]:
            return 1
        else:
            return -1
    if len(l11l111) != len(l11ll11):
        return -1
    return 0