#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1l = 2048
l11 = 7
def l11l1 (l11l):
    global l111
    l11lll = ord (l11l [-1])
    l1ll1l = l11l [:-1]
    l111ll = l11lll % len (l1ll1l)
    l111l1 = l1ll1l [:l111ll] + l1ll1l [l111ll:]
    if l111l:
        l1ll = l1111l () .join ([unichr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    return eval (l1ll)
import os
import re
import subprocess
import l1
from l1 import l1lll
def l1ll11():
    return []
def l11l11(l11l1l, l1ll1):
    logger = l1lll()
    l11ll1 = []
    l1l111 = [l11l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l111:
        try:
            output = os.popen(cmd).read()
            l11ll = 0
            l1l1l1 = {}
            if l11ll == 0:
                l1l1l = re.compile(l11l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11 = re.compile(l11l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1lll1 = re.search(l1l1l, line)
                    l1llll = l1lll1.group(1)
                    if l11l1l == l1llll:
                        l1l1 = re.search(l1l11, line)
                        if l1l1:
                            l1l11l = l11l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1.group(1)
                            version = l1lll1.group(0)
                            if not l1l11l in l1l1l1:
                                l1l1l1[l1l11l] = version
                            elif l1.l1l1ll(version, l1l1l1[l1l11l]) > 0:
                                l1l1l1[l1l11l] = version
            for l1l11l in l1l1l1:
                l11ll1.append({l11l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l1l1[l1l11l], l11l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l11l})
        except Exception as e:
            logger.error(str(e))
    return l11ll1