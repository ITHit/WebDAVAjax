#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1l = 7
def l1ll (l1):
    global l111l1
    l1l = ord (l1 [-1])
    ll = l1 [:-1]
    l111l = l1l % len (ll)
    l11ll = ll [:l111l] + ll [l111l:]
    if l1ll1:
        l1ll11 = l1l111 () .join ([unichr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    return eval (l1ll11)
import os
import re
import subprocess
import l1l1ll
from l1l1ll import l1l11
def l11lll():
    return []
def l11ll1(l1lll, l11l):
    logger = l1l11()
    l11l11 = []
    l1llll = [l1ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1llll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1lll1 = process.wait()
            l111 = {}
            if l1lll1 == 0:
                l111ll = re.compile(l1ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1l = re.compile(l1ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11 = re.search(l111ll, line)
                    l1l1 = l11.group(1)
                    if l1lll == l1l1:
                        l1l11l = re.search(l11l1l, line)
                        if l1l11l:
                            l11l1 = l1ll (u"ࠨࡦࡤࡺࠬࠄ")+l1l11l.group(1)
                            version = l11.group(0)
                            if not l11l1 in l111:
                                l111[l11l1] = version
                            elif l1l1ll.l1111l(version, l111[l11l1]) > 0:
                                l111[l11l1] = version
            for l11l1 in l111:
                l11l11.append({l1ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111[l11l1], l1ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1})
        except Exception as e:
            logger.error(str(e))
    return l11l11