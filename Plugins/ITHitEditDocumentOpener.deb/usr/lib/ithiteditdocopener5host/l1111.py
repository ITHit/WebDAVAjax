#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111ll = 2048
l1l1l = 7
def l1ll11 (l1l1ll):
    global l11l1l
    l111l = ord (l1l1ll [-1])
    l11l11 = l1l1ll [:-1]
    l1l = l111l % len (l11l11)
    l1llll = l11l11 [:l1l] + l11l11 [l1l:]
    if l1lll1:
        l1111l = l1l11l () .join ([unichr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    return eval (l1111l)
import os
import re
import subprocess
import l1l11
from l1l11 import l1
def ll():
    return []
def l11ll(l1l1, l11l1):
    logger = l1()
    l11 = []
    l111 = [l1ll11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111:
        try:
            output = os.popen(cmd).read()
            l1lll = 0
            l1l1l1 = {}
            if l1lll == 0:
                l11l = re.compile(l1ll11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll = re.compile(l1ll11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll1l = re.search(l11l, line)
                    l11ll1 = l1ll1l.group(1)
                    if l1l1 == l11ll1:
                        l11lll = re.search(l1ll, line)
                        if l11lll:
                            l1l111 = l1ll11 (u"ࠨࡦࡤࡺࠬࠄ")+l11lll.group(1)
                            version = l1ll1l.group(0)
                            if not l1l111 in l1l1l1:
                                l1l1l1[l1l111] = version
                            elif l1l11.l1ll1(version, l1l1l1[l1l111]) > 0:
                                l1l1l1[l1l111] = version
            for l1l111 in l1l1l1:
                l11.append({l1ll11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l1l1[l1l111], l1ll11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l111})
        except Exception as e:
            logger.error(str(e))
    return l11