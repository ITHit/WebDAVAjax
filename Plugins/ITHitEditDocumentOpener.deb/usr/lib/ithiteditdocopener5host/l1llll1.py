#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111l (l1111l):
    global l1l11l
    l111l1 = ord (l1111l [-1])
    l1l111 = l1111l [:-1]
    l111ll = l111l1 % len (l1l111)
    l1 = l1l111 [:l111ll] + l1l111 [l111ll:]
    if l111:
        l1l1 = l1lll () .join ([unichr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    else:
        l1l1 = str () .join ([chr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    return eval (l1l1)
import l1ll11
from l1l1l111 import l1l1l11l
import objc as _11111l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11111l1.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l11.l111l1l1(l111ll11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111l (u"ࠨࠩࢬ"), {l111l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111ll1l):
    l111ll1l = (l111ll1l + l111l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111lll = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l1111lll, _11111l1.nil )
    l1111ll1 = LaunchServices.l1111l1l( l111111l, LaunchServices.l111l11l, _11111l1.nil )
    if l1111ll1[0] is not None:
        return True
    return False
def l1l11():
    l111llll = []
    for name in l1l1l11l:
        try:
            if l1111111(name):
                l111llll.append(name)
        except:
            continue
    return l111llll
def l1l1ll(l1ll1l, l11ll):
    import plistlib
    import os
    l11ll1 = []
    l1ll = {}
    for l111l1ll in os.listdir(l111l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1ll.startswith(l11ll):
            try:
                l111lll1 = l111l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1ll
                with open(l111lll1, l111l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll1 = plist[l111l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l111 = version.split(l111l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll1l == l111l111:
                        if not l1ll1 in l1ll:
                            l1ll[l1ll1] = version
                        elif l1ll11.l11l1(version, l1ll[l1ll1]) > 0:
                            l1ll[l1ll1] = version
            except BaseException:
                continue
    for l1ll1 in l1ll:
        l11ll1.append({l111l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll[l1ll1], l111l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll1})
    return l11ll1