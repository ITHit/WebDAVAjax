#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1l11 = 2048
l11l1 = 7
def l1llll (l1l1ll):
    global l111
    l11lll = ord (l1l1ll [-1])
    l1111l = l1l1ll [:-1]
    l1 = l11lll % len (l1111l)
    l1lll = l1111l [:l1] + l1111l [l1:]
    if l111l1:
        l1l1l = l111ll () .join ([unichr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    return eval (l1l1l)
import l1ll
from l1l1l111 import l1l1l11l
import objc as _111l11l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l11l.l11111l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1llll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111ll.l1111lll(l111l111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1llll (u"ࠨࠩࢬ"), {l1llll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1llll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1llll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1llll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1llll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1llll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1llll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111llll):
    l111llll = (l111llll + l1llll (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1l1 = CFStringCreateWithCString( kCFAllocatorDefault, l111llll, kCFStringEncodingUTF8 )
    l111l1ll = CFURLCreateWithString( kCFAllocatorDefault, l111l1l1, _111l11l.nil )
    l111ll11 = LaunchServices.l1111ll1( l111l1ll, LaunchServices.l111ll1l, _111l11l.nil )
    if l111ll11[0] is not None:
        return True
    return False
def l11l():
    l1111l11 = []
    for name in l1l1l11l:
        try:
            if l1111111(name):
                l1111l11.append(name)
        except:
            continue
    return l1111l11
def l1lll1(l11l11, l11ll):
    import plistlib
    import os
    l1l1 = []
    ll = {}
    for l111111l in os.listdir(l1llll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111111l.startswith(l11ll):
            try:
                l1111l1l = l1llll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111111l
                with open(l1111l1l, l1llll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll1l = plist[l1llll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1llll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1llll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l1llll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l11 == l111lll1:
                        if not l1ll1l in ll:
                            ll[l1ll1l] = version
                        elif l1ll.l1111(version, ll[l1ll1l]) > 0:
                            ll[l1ll1l] = version
            except BaseException:
                continue
    for l1ll1l in ll:
        l1l1.append({l1llll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): ll[l1ll1l], l1llll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll1l})
    return l1l1