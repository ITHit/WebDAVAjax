#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1 = 2048
l1111 = 7
def l11ll (l1ll1l):
    global l11ll1
    l11l1 = ord (l1ll1l [-1])
    l1l = l1ll1l [:-1]
    l1l1ll = l11l1 % len (l1l)
    l11lll = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l111ll:
        l1ll = l11l () .join ([unichr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1l1l + l11l1) % l1111) for l1l1l, char in enumerate (l11lll)])
    return eval (l1ll)
import l1l11
from l1l1l111 import l1l1l11l
import objc as _11111l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11111l1.l111l1ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l1111lll(l1111l1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll (u"ࠨࠩࢬ"), {l11ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l111(l1111111):
    l1111111 = (l1111111 + l11ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll1l = CFStringCreateWithCString( kCFAllocatorDefault, l1111111, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l111ll1l, _11111l1.nil )
    l1111l11 = LaunchServices.l111l1l1( l11111ll, LaunchServices.l111l11l, _11111l1.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l111():
    l111111l = []
    for name in l1l1l11l:
        try:
            if l111l111(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l1l11l(l1llll, l11l1l):
    import plistlib
    import os
    l11 = []
    l1l111 = {}
    for l1111ll1 in os.listdir(l11ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111ll1.startswith(l11l1l):
            try:
                l111ll11 = l11ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111ll1
                with open(l111ll11, l11ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l11 = plist[l11ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111llll = version.split(l11ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1llll == l111llll:
                        if not l11l11 in l1l111:
                            l1l111[l11l11] = version
                        elif l1l11.l1ll11(version, l1l111[l11l11]) > 0:
                            l1l111[l11l11] = version
            except BaseException:
                continue
    for l11l11 in l1l111:
        l11.append({l11ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l111[l11l11], l11ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l11})
    return l11