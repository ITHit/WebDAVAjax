#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll1 = 2048
l11l = 7
def l1l1l (l111ll):
    global l1l1
    l1l11 = ord (l111ll [-1])
    l11l11 = l111ll [:-1]
    l1111l = l1l11 % len (l11l11)
    l1l1ll = l11l11 [:l1111l] + l11l11 [l1111l:]
    if l1ll11:
        l111 = l1l111 () .join ([unichr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    return eval (l111)
import subprocess, threading
from l11lll import l11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1ll1ll():
    l1l11l11 = [l1l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11l11:
        try:
            l11lll1l = l1l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11l1l = winreg.l1l11111(winreg.l11ll1l1, l11lll1l)
        except l11l1l1l:
            continue
        value = winreg.l11l1lll(l1l11l1l, l1l1l (u"ࠦࠧ࢓"))
        return value.split(l1l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1ll1():
    l11llll1 = []
    for name in l1l1l11l:
        try:
            l11lll1l = l1l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111ll = winreg.l1l11111(winreg.l11ll1l1, l11lll1l)
            if winreg.l11l1lll(l1l111ll, l1l1l (u"ࠢࠣ࢖")):
                l11llll1.append(name)
        except l11l1l1l:
            continue
    return l11llll1
def l11lll1(l1lll1, l111l):
    import re
    l1l11l = []
    l11l111l = winreg.l1l11111(winreg.l11ll1l1, l1l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11ll1(l11l111l)[0]):
        try:
            l1l111l1 = winreg.l1l1111l(l11l111l, i)
            if l1l111l1.startswith(l111l):
                l1l11lll = winreg.l11ll111(l11l111l, l1l111l1)
                value, l11l1l11 = winreg.l11l11l1(l1l11lll, l1l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1111 = {l1l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11ll = m.group(2)
                    if l1lll1 == l11l11ll:
                        m = re.search(l111l.replace(l1l1l (u"ࠬ࠴࢛ࠧ"), l1l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l111l1)
                        l11l1111[l1l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l11l.append(l11l1111)
                else:
                    raise ValueError(l1l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1l1l as ex:
            continue
    return l1l11l
def l11lllll(ll):
    try:
        l11ll1ll = l1l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(ll)
        l11ll11l = winreg.l1l11111(winreg.l11ll1l1, l11ll1ll)
        value, l11l1l11 = winreg.l11l11l1(l11ll11l, l1l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1l1l:
        pass
    return l1l1l (u"࠭ࠧࢣ")
def l11l1l1(ll, url):
    threading.Thread(target=_11l1ll1,args=(ll, url)).start()
    return l1l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1ll1(ll, url):
    logger = l11()
    l11lll11 = l11lllll(ll)
    logger.debug(l1l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lll11, url))
    retcode = subprocess.Popen(l1l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lll11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)