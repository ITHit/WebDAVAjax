#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll1 = 7
def l1llll (l11ll1):
    global ll
    l1l11l = ord (l11ll1 [-1])
    l1l1ll = l11ll1 [:-1]
    l11 = l1l11l % len (l1l1ll)
    l1 = l1l1ll [:l11] + l1l1ll [l11:]
    if l11l11:
        l111ll = l11l1 () .join ([unichr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    else:
        l111ll = str () .join ([chr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    return eval (l111ll)
import subprocess, threading
from l1111l import l1l111
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1lll1l():
    l1l11lll = [l1llll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1llll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1llll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1llll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11lll:
        try:
            l1l1111l = l1llll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll1l = winreg.l11ll1l1(winreg.l11lllll, l1l1111l)
        except l1l11ll1:
            continue
        value = winreg.l1l11l1l(l11lll1l, l1llll (u"ࠦࠧ࢓"))
        return value.split(l1llll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll1l1():
    l11l1l11 = []
    for name in l1l1l111:
        try:
            l1l1111l = l1llll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1ll = winreg.l11ll1l1(winreg.l11lllll, l1l1111l)
            if winreg.l1l11l1l(l11ll1ll, l1llll (u"ࠢࠣ࢖")):
                l11l1l11.append(name)
        except l1l11ll1:
            continue
    return l11l1l11
def l1111l1(l111, l1l1l):
    import re
    l1l11 = []
    l11llll1 = winreg.l11ll1l1(winreg.l11lllll, l1llll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l11(l11llll1)[0]):
        try:
            l11l11ll = winreg.l11ll111(l11llll1, i)
            if l11l11ll.startswith(l1l1l):
                l11lll11 = winreg.l11l1lll(l11llll1, l11l11ll)
                value, l11ll11l = winreg.l11l1l1l(l11lll11, l1llll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1llll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11111 = {l1llll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1ll1 = m.group(2)
                    if l111 == l11l1ll1:
                        m = re.search(l1l1l.replace(l1llll (u"ࠬ࠴࢛ࠧ"), l1llll (u"࠭࡜࡝࠰ࠪ࢜")) + l1llll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l11ll)
                        l1l11111[l1llll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l11.append(l1l11111)
                else:
                    raise ValueError(l1llll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11ll1 as ex:
            continue
    return l1l11
def l1l111l1(l11l):
    try:
        l11l1111 = l1llll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l)
        l1l111ll = winreg.l11ll1l1(winreg.l11lllll, l11l1111)
        value, l11ll11l = winreg.l11l1l1l(l1l111ll, l1llll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1llll (u"ࠬࠨࠧࢢ"))[1]
    except l1l11ll1:
        pass
    return l1llll (u"࠭ࠧࢣ")
def l11l1ll(l11l, url):
    threading.Thread(target=_11l11l1,args=(l11l, url)).start()
    return l1llll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l11l1(l11l, url):
    logger = l1l111()
    l11l111l = l1l111l1(l11l)
    logger.debug(l1llll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l111l, url))
    retcode = subprocess.Popen(l1llll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l111l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1llll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1llll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)