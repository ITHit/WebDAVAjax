#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l11l1l = 7
def l11ll (l1ll1):
    global l1l1l
    l1l11 = ord (l1ll1 [-1])
    l11l11 = l1ll1 [:-1]
    l1l111 = l1l11 % len (l11l11)
    l1ll1l = l11l11 [:l1l111] + l11l11 [l1l111:]
    if l1ll11:
        l1 = l11lll () .join ([unichr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    return eval (l1)
import l1111
from l1l1l11l import l1l1l111
import objc as _111lll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111lll1.l1111111( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l1l.l11111ll(l1111l11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll (u"ࠨࠩࢬ"), {l11ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111l1(l1111ll1):
    l1111ll1 = (l1111ll1 + l11ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111111l = CFStringCreateWithCString( kCFAllocatorDefault, l1111ll1, kCFStringEncodingUTF8 )
    l111l111 = CFURLCreateWithString( kCFAllocatorDefault, l111111l, _111lll1.nil )
    l111l1ll = LaunchServices.l111ll11( l111l111, LaunchServices.l111llll, _111lll1.nil )
    if l111l1ll[0] is not None:
        return True
    return False
def l11():
    l111ll1l = []
    for name in l1l1l111:
        try:
            if l11111l1(name):
                l111ll1l.append(name)
        except:
            continue
    return l111ll1l
def l11l(l111, l11ll1):
    import plistlib
    import os
    ll = []
    l1lll = {}
    for l1111lll in os.listdir(l11ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111lll.startswith(l11ll1):
            try:
                l111l1l1 = l11ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111lll
                with open(l111l1l1, l11ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1llll = plist[l11ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l11l = version.split(l11ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111 == l111l11l:
                        if not l1llll in l1lll:
                            l1lll[l1llll] = version
                        elif l1111.l1l(version, l1lll[l1llll]) > 0:
                            l1lll[l1llll] = version
            except BaseException:
                continue
    for l1llll in l1lll:
        ll.append({l11ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll[l1llll], l11ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1llll})
    return ll