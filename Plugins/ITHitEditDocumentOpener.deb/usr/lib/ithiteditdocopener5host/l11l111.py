#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll11 = 2048
l111ll = 7
def l11ll (l11l11):
    global l1111
    l11l1 = ord (l11l11 [-1])
    l1 = l11l11 [:-1]
    ll = l11l1 % len (l1)
    l1ll1 = l1 [:ll] + l1 [ll:]
    if l1l1l1:
        l11l1l = l1l11l () .join ([unichr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1ll11 - (l1lll + l11l1) % l111ll) for l1lll, char in enumerate (l1ll1)])
    return eval (l11l1l)
import l11l
from l1l1l111 import l1l1l11l
import objc as _11111l1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _11111l1.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll1l.l111llll(l111l11l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l11l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll (u"ࠨࠩࢬ"), {l11ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l111ll11):
    l111ll11 = (l111ll11 + l11ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111111l = CFStringCreateWithCString( kCFAllocatorDefault, l111ll11, kCFStringEncodingUTF8 )
    l1111l11 = CFURLCreateWithString( kCFAllocatorDefault, l111111l, _11111l1.nil )
    l1111lll = LaunchServices.l1111ll1( l1111l11, LaunchServices.l111lll1, _11111l1.nil )
    if l1111lll[0] is not None:
        return True
    return False
def l1l11():
    l111l111 = []
    for name in l1l1l11l:
        try:
            if l1111l1l(name):
                l111l111.append(name)
        except:
            continue
    return l111l111
def l1lll1(l11ll1, l111):
    import plistlib
    import os
    l1l111 = []
    l1llll = {}
    for l1111111 in os.listdir(l11ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111111.startswith(l111):
            try:
                l111l1ll = l11ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111111
                with open(l111l1ll, l11ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll = plist[l11ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1l1 = version.split(l11ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11ll1 == l111l1l1:
                        if not l1ll in l1llll:
                            l1llll[l1ll] = version
                        elif l11l.l111l1(version, l1llll[l1ll]) > 0:
                            l1llll[l1ll] = version
            except BaseException:
                continue
    for l1ll in l1llll:
        l1l111.append({l11ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1llll[l1ll], l11ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll})
    return l1l111