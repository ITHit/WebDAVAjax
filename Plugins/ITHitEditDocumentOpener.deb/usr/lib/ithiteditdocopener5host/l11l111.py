#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll = sys.version_info [0] == 2
l11l1l = 2048
l1lll = 7
def l11l11 (l11lll):
    global l11ll1
    l1ll1l = ord (l11lll [-1])
    l1l11 = l11lll [:-1]
    l1111 = l1ll1l % len (l1l11)
    l11 = l1l11 [:l1111] + l1l11 [l1111:]
    if l1l1ll:
        l111l = l1l () .join ([unichr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    return eval (l111l)
import subprocess, threading
from l1ll1 import ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1l11ll():
    l11ll111 = [l11l11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11ll111:
        try:
            l11ll1ll = l11l11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l111l1 = winreg.l11lll11(winreg.l11l1l1l, l11ll1ll)
        except l1l111ll:
            continue
        value = winreg.l11lll1l(l1l111l1, l11l11 (u"ࠦࠧ࢓"))
        return value.split(l11l11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11l11l():
    l1l1111l = []
    for name in l1l1l111:
        try:
            l11ll1ll = l11l11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11lll = winreg.l11lll11(winreg.l11l1l1l, l11ll1ll)
            if winreg.l11lll1l(l1l11lll, l11l11 (u"ࠢࠣ࢖")):
                l1l1111l.append(name)
        except l1l111ll:
            continue
    return l1l1111l
def l1ll11l(l1ll, l111l1):
    import re
    l1 = []
    l1l11111 = winreg.l11lll11(winreg.l11l1l1l, l11l11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1l11(l1l11111)[0]):
        try:
            l11ll11l = winreg.l1l11l1l(l1l11111, i)
            if l11ll11l.startswith(l111l1):
                l11l11l1 = winreg.l11lllll(l1l11111, l11ll11l)
                value, l11l111l = winreg.l1l11ll1(l11l11l1, l11l11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll1l1 = {l11l11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1lll = m.group(2)
                    if l1ll == l11l1lll:
                        m = re.search(l111l1.replace(l11l11 (u"ࠬ࠴࢛ࠧ"), l11l11 (u"࠭࡜࡝࠰ࠪ࢜")) + l11l11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll11l)
                        l11ll1l1[l11l11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1.append(l11ll1l1)
                else:
                    raise ValueError(l11l11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l111ll as ex:
            continue
    return l1
def l11l1ll1(l1l1):
    try:
        l11llll1 = l11l11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1)
        l11l11ll = winreg.l11lll11(winreg.l11l1l1l, l11llll1)
        value, l11l111l = winreg.l1l11ll1(l11l11ll, l11l11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l11 (u"ࠬࠨࠧࢢ"))[1]
    except l1l111ll:
        pass
    return l11l11 (u"࠭ࠧࢣ")
def l1l111l(l1l1, url):
    threading.Thread(target=_11l1111,args=(l1l1, url)).start()
    return l11l11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1111(l1l1, url):
    logger = ll()
    l1l11l11 = l11l1ll1(l1l1)
    logger.debug(l11l11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l11, url))
    retcode = subprocess.Popen(l11l11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)