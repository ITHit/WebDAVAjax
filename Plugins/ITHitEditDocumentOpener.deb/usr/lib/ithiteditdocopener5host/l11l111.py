#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
l1ll1 = 7
def l1llll (l11):
    global l111
    l1lll = ord (l11 [-1])
    l111l1 = l11 [:-1]
    l11ll = l1lll % len (l111l1)
    l1l = l111l1 [:l11ll] + l111l1 [l11ll:]
    if l1ll1l:
        l111l = l111ll () .join ([unichr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    return eval (l111l)
import subprocess, threading
from l1 import l1l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l1111():
    l1l1111l = [l1llll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1llll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1llll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1llll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l1111l:
        try:
            l11l1ll1 = l1llll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l11ll11l(winreg.l11ll1l1, l11l1ll1)
        except l11l1l11:
            continue
        value = winreg.l11lllll(l11l1l1l, l1llll (u"ࠦࠧ࢓"))
        return value.split(l1llll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l111l():
    l11ll111 = []
    for name in l1l1l11l:
        try:
            l11l1ll1 = l1llll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1ll = winreg.l11ll11l(winreg.l11ll1l1, l11l1ll1)
            if winreg.l11lllll(l11ll1ll, l1llll (u"ࠢࠣ࢖")):
                l11ll111.append(name)
        except l11l1l11:
            continue
    return l11ll111
def l1lllll(l1l111, l1lll1):
    import re
    l1111 = []
    l1l11l11 = winreg.l11ll11l(winreg.l11ll1l1, l1llll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11llll1(l1l11l11)[0]):
        try:
            l11l111l = winreg.l11l11ll(l1l11l11, i)
            if l11l111l.startswith(l1lll1):
                l1l111l1 = winreg.l11l1lll(l1l11l11, l11l111l)
                value, l1l11111 = winreg.l1l11lll(l1l111l1, l1llll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1llll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lll1l = {l1llll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lll11 = m.group(2)
                    if l1l111 == l11lll11:
                        m = re.search(l1lll1.replace(l1llll (u"ࠬ࠴࢛ࠧ"), l1llll (u"࠭࡜࡝࠰ࠪ࢜")) + l1llll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l111l)
                        l11lll1l[l1llll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1111.append(l11lll1l)
                else:
                    raise ValueError(l1llll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1l11 as ex:
            continue
    return l1111
def l1l11l1l(l1l1l1):
    try:
        l1l111ll = l1llll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1l1)
        l11l11l1 = winreg.l11ll11l(winreg.l11ll1l1, l1l111ll)
        value, l1l11111 = winreg.l1l11lll(l11l11l1, l1llll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1llll (u"ࠬࠨࠧࢢ"))[1]
    except l11l1l11:
        pass
    return l1llll (u"࠭ࠧࢣ")
def l1ll1ll(l1l1l1, url):
    threading.Thread(target=_11l1111,args=(l1l1l1, url)).start()
    return l1llll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1111(l1l1l1, url):
    logger = l1l1()
    l1l11ll1 = l1l11l1l(l1l1l1)
    logger.debug(l1llll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11ll1, url))
    retcode = subprocess.Popen(l1llll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11ll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1llll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1llll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)