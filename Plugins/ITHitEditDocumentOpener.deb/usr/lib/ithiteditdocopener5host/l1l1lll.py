#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l1l1l = 7
def l11ll1 (ll):
    global l1l1
    l1l1ll = ord (ll [-1])
    l1ll11 = ll [:-1]
    l1l11 = l1l1ll % len (l1ll11)
    l11 = l1ll11 [:l1l11] + l1ll11 [l1l11:]
    if l11l1l:
        l1 = l11lll () .join ([unichr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1ll1 - (l11l11 + l1l1ll) % l1l1l) for l11l11, char in enumerate (l11)])
    return eval (l1)
import subprocess, threading
from l1111l import l1lll1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1lll11():
    l11l111l = [l11ll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l111l:
        try:
            l1l11l1l = l11ll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11lll = winreg.l1l11l11(winreg.l11ll1ll, l1l11l1l)
        except l11llll1:
            continue
        value = winreg.l1l111l1(l1l11lll, l11ll1 (u"ࠦࠧ࢓"))
        return value.split(l11ll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1llll1():
    l11l1lll = []
    for name in l1l1l11l:
        try:
            l1l11l1l = l11ll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lll1l = winreg.l1l11l11(winreg.l11ll1ll, l1l11l1l)
            if winreg.l1l111l1(l11lll1l, l11ll1 (u"ࠢࠣ࢖")):
                l11l1lll.append(name)
        except l11llll1:
            continue
    return l11l1lll
def l1ll111(l1l111, l1l):
    import re
    l11ll = []
    l11l1ll1 = winreg.l1l11l11(winreg.l11ll1ll, l11ll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1111(l11l1ll1)[0]):
        try:
            l11ll1l1 = winreg.l11lllll(l11l1ll1, i)
            if l11ll1l1.startswith(l1l):
                l11l1l1l = winreg.l1l1111l(l11l1ll1, l11ll1l1)
                value, l11ll111 = winreg.l1l111ll(l11l1l1l, l11ll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11ll1 = {l11ll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11ll = m.group(2)
                    if l1l111 == l11l11ll:
                        m = re.search(l1l.replace(l11ll1 (u"ࠬ࠴࢛ࠧ"), l11ll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1l1)
                        l1l11ll1[l11ll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11ll.append(l1l11ll1)
                else:
                    raise ValueError(l11ll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11llll1 as ex:
            continue
    return l11ll
def l11lll11(l1ll):
    try:
        l11ll11l = l11ll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll)
        l1l11111 = winreg.l1l11l11(winreg.l11ll1ll, l11ll11l)
        value, l11ll111 = winreg.l1l111ll(l1l11111, l11ll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11llll1:
        pass
    return l11ll1 (u"࠭ࠧࢣ")
def l111111(l1ll, url):
    threading.Thread(target=_11l1l11,args=(l1ll, url)).start()
    return l11ll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1l11(l1ll, url):
    logger = l1lll1()
    l11l11l1 = l11lll11(l1ll)
    logger.debug(l11ll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11l1, url))
    retcode = subprocess.Popen(l11ll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)