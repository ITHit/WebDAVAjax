#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l11l1):
    global l11l11
    l1l1ll = ord (l11l1 [-1])
    l11l = l11l1 [:-1]
    l1l11 = l1l1ll % len (l11l)
    l1l11l = l11l [:l1l11] + l11l [l1l11:]
    if l1l:
        l1111 = l111ll () .join ([unichr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    else:
        l1111 = str () .join ([chr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    return eval (l1111)
import l1l1l
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111llll.l11111l1(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l1l (u"ࠨࠩࢬ"), {l11l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l111l1ll):
    l111l1ll = (l111l1ll + l11l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l11 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l1111l11, _1111ll1.nil )
    l111lll1 = LaunchServices.l111ll1l( l1111111, LaunchServices.l1111l1l, _1111ll1.nil )
    if l111lll1[0] is not None:
        return True
    return False
def l11ll():
    l111ll11 = []
    for name in l1l1l111:
        try:
            if l111l11l(name):
                l111ll11.append(name)
        except:
            continue
    return l111ll11
def l1llll(l1l1, l1lll1):
    import plistlib
    import os
    l1ll = []
    l1ll1 = {}
    for l111l1l1 in os.listdir(l11l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l1lll1):
            try:
                l111111l = l11l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l111111l, l11l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l111l = plist[l11l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l111 = version.split(l11l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1 == l111l111:
                        if not l111l in l1ll1:
                            l1ll1[l111l] = version
                        elif l1l1l.l1ll11(version, l1ll1[l111l]) > 0:
                            l1ll1[l111l] = version
            except BaseException:
                continue
    for l111l in l1ll1:
        l1ll.append({l11l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1[l111l], l11l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l111l})
    return l1ll