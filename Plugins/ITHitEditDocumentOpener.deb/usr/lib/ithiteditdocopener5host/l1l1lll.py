#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll = sys.version_info [0] == 2
l1l111 = 2048
l111 = 7
def l11 (l11l1):
    global l1111l
    l11l = ord (l11l1 [-1])
    l111ll = l11l1 [:-1]
    l1l11 = l11l % len (l111ll)
    l1l1l1 = l111ll [:l1l11] + l111ll [l1l11:]
    if l1lll:
        l1 = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    return eval (l1)
import ll
from l1l1l11l import l1l1l111
import objc as _1111l11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111l11.l111111l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll11.l111l1ll(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11 (u"ࠨࠩࢬ"), {l11 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l111(l111l1l1):
    l111l1l1 = (l111l1l1 + l11 (u"ࠩ࠽ࠫࢴ")).encode()
    l111lll1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1l1, kCFStringEncodingUTF8 )
    l1111l1l = CFURLCreateWithString( kCFAllocatorDefault, l111lll1, _1111l11.nil )
    l11111ll = LaunchServices.l11111l1( l1111l1l, LaunchServices.l1111111, _1111l11.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l1ll():
    l111l11l = []
    for name in l1l1l111:
        try:
            if l111l111(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def l11l11(l11ll, l11ll1):
    import plistlib
    import os
    l11l1l = []
    l111l = {}
    for l111ll1l in os.listdir(l11 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(l11ll1):
            try:
                l111llll = l11 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l111llll, l11 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1 = plist[l11 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111ll1 = version.split(l11 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11ll == l1111ll1:
                        if not l1l1 in l111l:
                            l111l[l1l1] = version
                        elif ll.l1l1ll(version, l111l[l1l1]) > 0:
                            l111l[l1l1] = version
            except BaseException:
                continue
    for l1l1 in l111l:
        l11l1l.append({l11 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111l[l1l1], l11 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1})
    return l11l1l