#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l111l (l11):
    global l1lll
    l11l = ord (l11 [-1])
    l11ll1 = l11 [:-1]
    l1l1 = l11l % len (l11ll1)
    l1lll1 = l11ll1 [:l1l1] + l11ll1 [l1l1:]
    if l1ll1l:
        l111l1 = l1ll () .join ([unichr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    return eval (l111l1)
import subprocess, threading
from l1l11 import l1ll11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1lll11():
    l11lllll = [l111l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l111l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l111l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l111l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lllll:
        try:
            l1l111ll = l111l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll11 = winreg.l11l11ll(winreg.l11l1ll1, l1l111ll)
        except l1l1111l:
            continue
        value = winreg.l11l1111(l11lll11, l111l (u"ࠦࠧ࢓"))
        return value.split(l111l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1ll11l():
    l11ll111 = []
    for name in l1l1l11l:
        try:
            l1l111ll = l111l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1ll = winreg.l11l11ll(winreg.l11l1ll1, l1l111ll)
            if winreg.l11l1111(l11ll1ll, l111l (u"ࠢࠣ࢖")):
                l11ll111.append(name)
        except l1l1111l:
            continue
    return l11ll111
def l1111ll(l11ll, l111ll):
    import re
    l1 = []
    l11l1l1l = winreg.l11l11ll(winreg.l11l1ll1, l111l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l1l(l11l1l1l)[0]):
        try:
            l1l11111 = winreg.l1l11lll(l11l1l1l, i)
            if l1l11111.startswith(l111ll):
                l1l11l11 = winreg.l11l111l(l11l1l1l, l1l11111)
                value, l1l111l1 = winreg.l11ll1l1(l1l11l11, l111l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l111l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11lll1l = {l111l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11llll1 = m.group(2)
                    if l11ll == l11llll1:
                        m = re.search(l111ll.replace(l111l (u"ࠬ࠴࢛ࠧ"), l111l (u"࠭࡜࡝࠰ࠪ࢜")) + l111l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11111)
                        l11lll1l[l111l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1.append(l11lll1l)
                else:
                    raise ValueError(l111l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l1111l as ex:
            continue
    return l1
def l11ll11l(l1l1l):
    try:
        l11l1l11 = l111l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1l)
        l11l1lll = winreg.l11l11ll(winreg.l11l1ll1, l11l1l11)
        value, l1l111l1 = winreg.l11ll1l1(l11l1lll, l111l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l111l (u"ࠬࠨࠧࢢ"))[1]
    except l1l1111l:
        pass
    return l111l (u"࠭ࠧࢣ")
def l11111(l1l1l, url):
    threading.Thread(target=_11l11l1,args=(l1l1l, url)).start()
    return l111l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l11l1(l1l1l, url):
    logger = l1ll11()
    l1l11ll1 = l11ll11l(l1l1l)
    logger.debug(l111l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11ll1, url))
    retcode = subprocess.Popen(l111l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11ll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l111l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l111l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)