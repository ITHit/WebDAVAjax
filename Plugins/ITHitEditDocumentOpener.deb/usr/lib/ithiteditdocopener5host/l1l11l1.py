#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1lll1 = 2048
l111l = 7
def l1l1 (l1ll11):
    global l1
    l1l1l = ord (l1ll11 [-1])
    l11ll1 = l1ll11 [:-1]
    l11l11 = l1l1l % len (l11ll1)
    l1l11l = l11ll1 [:l11l11] + l11ll1 [l11l11:]
    if l1ll1:
        l1llll = l1l111 () .join ([unichr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    return eval (l1llll)
import l11
from l1l1l11l import l1l1l111
import objc as _111111l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111111l.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111llll.l1111l1l(l1111l11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111l11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1 (u"ࠨࠩࢬ"), {l1l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111ll1l(l1111lll):
    l1111lll = (l1111lll + l1l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll11 = CFStringCreateWithCString( kCFAllocatorDefault, l1111lll, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l111ll11, _111111l.nil )
    l111l1l1 = LaunchServices.l1111ll1( l1111111, LaunchServices.l11111l1, _111111l.nil )
    if l111l1l1[0] is not None:
        return True
    return False
def l11l1l():
    l111lll1 = []
    for name in l1l1l111:
        try:
            if l111ll1l(name):
                l111lll1.append(name)
        except:
            continue
    return l111lll1
def l1ll(l11l1, ll):
    import plistlib
    import os
    l1111 = []
    l11ll = {}
    for l111l111 in os.listdir(l1l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l111.startswith(ll):
            try:
                l111l11l = l1l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l111
                with open(l111l11l, l1l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11lll = plist[l1l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1ll = version.split(l1l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l1 == l111l1ll:
                        if not l11lll in l11ll:
                            l11ll[l11lll] = version
                        elif l11.l11l(version, l11ll[l11lll]) > 0:
                            l11ll[l11lll] = version
            except BaseException:
                continue
    for l11lll in l11ll:
        l1111.append({l1l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11ll[l11lll], l1l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11lll})
    return l1111