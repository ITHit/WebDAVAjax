#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1lll1 = 2048
l1l11l = 7
def l1l1l (l11ll1):
    global l1l1ll
    l1llll = ord (l11ll1 [-1])
    l11l1l = l11ll1 [:-1]
    l111 = l1llll % len (l11l1l)
    l11lll = l11l1l [:l111] + l11l1l [l111:]
    if l111l1:
        l11l = l111l () .join ([unichr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1lll1 - (l11 + l1llll) % l1l11l) for l11, char in enumerate (l11lll)])
    return eval (l11l)
import l1l
from l1l1l111 import l1l1l11l
import objc as _111l111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l111.l111llll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111lll.l111l11l(l1111ll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111ll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1l (u"ࠨࠩࢬ"), {l1l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1l1(l111ll1l):
    l111ll1l = (l111ll1l + l1l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111111 = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l11111l1 = CFURLCreateWithString( kCFAllocatorDefault, l1111111, _111l111.nil )
    l111111l = LaunchServices.l111ll11( l11111l1, LaunchServices.l111l1ll, _111l111.nil )
    if l111111l[0] is not None:
        return True
    return False
def ll():
    l111lll1 = []
    for name in l1l1l11l:
        try:
            if l111l1l1(name):
                l111lll1.append(name)
        except:
            continue
    return l111lll1
def l1ll1l(l1ll11, l1l111):
    import plistlib
    import os
    l1l1 = []
    l1ll1 = {}
    for l11111ll in os.listdir(l1l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111ll.startswith(l1l111):
            try:
                l1111l1l = l1l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111ll
                with open(l1111l1l, l1l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1 = plist[l1l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l1l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1ll11 == l1111l11:
                        if not l1 in l1ll1:
                            l1ll1[l1] = version
                        elif l1l.l111ll(version, l1ll1[l1]) > 0:
                            l1ll1[l1] = version
            except BaseException:
                continue
    for l1 in l1ll1:
        l1l1.append({l1l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1[l1], l1l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1})
    return l1l1