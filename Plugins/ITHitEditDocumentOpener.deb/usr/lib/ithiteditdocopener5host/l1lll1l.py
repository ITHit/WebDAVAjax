#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1 = 2048
l111 = 7
def l1lll (l1l111):
    global l11l1l
    l1l = ord (l1l111 [-1])
    l11lll = l1l111 [:-1]
    l1ll1 = l1l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l1l1l:
        l1l1ll = l1ll11 () .join ([unichr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    return eval (l1l1ll)
import l111ll
from l1l1l111 import l1l1l11l
import objc as _111ll1l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll1l.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1lll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l1ll.l1111111(l111l1l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1lll (u"ࠨࠩࢬ"), {l1lll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1lll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1lll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1lll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1lll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1lll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1lll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111llll(l111l111):
    l111l111 = (l111l111 + l1lll (u"ࠩ࠽ࠫࢴ")).encode()
    l11111ll = CFStringCreateWithCString( kCFAllocatorDefault, l111l111, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l11111ll, _111ll1l.nil )
    l1111l11 = LaunchServices.l111ll11( l111111l, LaunchServices.l11111l1, _111ll1l.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l1ll():
    l111l11l = []
    for name in l1l1l11l:
        try:
            if l111llll(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def ll(l11ll1, l111l1):
    import plistlib
    import os
    l11l1 = []
    l1111l = {}
    for l111lll1 in os.listdir(l1lll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111lll1.startswith(l111l1):
            try:
                l1111lll = l1lll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111lll1
                with open(l1111lll, l1lll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1lll1 = plist[l1lll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1lll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1lll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l1l = version.split(l1lll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11ll1 == l1111l1l:
                        if not l1lll1 in l1111l:
                            l1111l[l1lll1] = version
                        elif l111ll.l1l11l(version, l1111l[l1lll1]) > 0:
                            l1111l[l1lll1] = version
            except BaseException:
                continue
    for l1lll1 in l1111l:
        l11l1.append({l1lll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111l[l1lll1], l1lll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1lll1})
    return l11l1