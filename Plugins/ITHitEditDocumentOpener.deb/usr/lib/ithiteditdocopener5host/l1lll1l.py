#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1 = 2048
l1lll = 7
def l1ll11 (l1111l):
    global l1ll
    l11ll = ord (l1111l [-1])
    l111ll = l1111l [:-1]
    l1llll = l11ll % len (l111ll)
    l1l = l111ll [:l1llll] + l111ll [l1llll:]
    if l11:
        l11l1l = l111l1 () .join ([unichr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    else:
        l11l1l = str () .join ([chr (ord (char) - l1 - (l1l1l + l11ll) % l1lll) for l1l1l, char in enumerate (l1l)])
    return eval (l11l1l)
import subprocess, threading
from l1l1 import l111l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l11l():
    l11lll11 = [l1ll11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lll11:
        try:
            l11l11ll = l1ll11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll11l = winreg.l1l11lll(winreg.l11llll1, l11l11ll)
        except l1l11ll1:
            continue
        value = winreg.l11l1l11(l11ll11l, l1ll11 (u"ࠦࠧ࢓"))
        return value.split(l1ll11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1111l1():
    l1l11111 = []
    for name in l1l1l11l:
        try:
            l11l11ll = l1ll11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111ll = winreg.l1l11lll(winreg.l11llll1, l11l11ll)
            if winreg.l11l1l11(l1l111ll, l1ll11 (u"ࠢࠣ࢖")):
                l1l11111.append(name)
        except l1l11ll1:
            continue
    return l1l11111
def l1llll1(l11l11, l1l1ll):
    import re
    l1lll1 = []
    l11l111l = winreg.l1l11lll(winreg.l11llll1, l1ll11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l1l(l11l111l)[0]):
        try:
            l11ll1l1 = winreg.l11l1111(l11l111l, i)
            if l11ll1l1.startswith(l1l1ll):
                l11l1ll1 = winreg.l11ll111(l11l111l, l11ll1l1)
                value, l11ll1ll = winreg.l11lll1l(l11l1ll1, l1ll11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1l1l = {l1ll11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11lllll = m.group(2)
                    if l11l11 == l11lllll:
                        m = re.search(l1l1ll.replace(l1ll11 (u"ࠬ࠴࢛ࠧ"), l1ll11 (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1l1)
                        l11l1l1l[l1ll11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1lll1.append(l11l1l1l)
                else:
                    raise ValueError(l1ll11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11ll1 as ex:
            continue
    return l1lll1
def l1l1111l(l1l1l1):
    try:
        l11l1lll = l1ll11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l1l1)
        l1l11l11 = winreg.l1l11lll(winreg.l11llll1, l11l1lll)
        value, l11ll1ll = winreg.l11lll1l(l1l11l11, l1ll11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll11 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11ll1:
        pass
    return l1ll11 (u"࠭ࠧࢣ")
def l11l111(l1l1l1, url):
    threading.Thread(target=_11l11l1,args=(l1l1l1, url)).start()
    return l1ll11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l11l1(l1l1l1, url):
    logger = l111l()
    l1l111l1 = l1l1111l(l1l1l1)
    logger.debug(l1ll11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l111l1, url))
    retcode = subprocess.Popen(l1ll11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l111l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)