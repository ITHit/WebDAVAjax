#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def ll (l111):
    global l111ll
    l1111l = ord (l111 [-1])
    l11ll1 = l111 [:-1]
    l1ll = l1111l % len (l11ll1)
    l1l11 = l11ll1 [:l1ll] + l11ll1 [l1ll:]
    if l1llll:
        l11ll = l1l () .join ([unichr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    return eval (l11ll)
import _winreg
import subprocess, threading
from l111l import l1lll
from l1l1l111 import l1l11lll
def l1lllll():
    l11lll11 = [ll (u"ࠢࡆࡺࡦࡩࡱࠨ࢏"), ll (u"࡙ࠣࡲࡶࡩࠨ࢐"), ll (u"ࠤࡓࡳࡼ࡫ࡲࡑࡱ࡬ࡲࡹࠨ࢑"), ll (u"ࠥࡓࡺࡺ࡬ࡰࡱ࡮ࠦ࢒")]
    for part in l11lll11:
        try:
            l11lll1l = ll (u"ࠦࢀ࠶ࡽ࠯ࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡢ࡜ࡄࡷࡵ࡚ࡪࡸࠢ࢓").format(part)
            l1l111ll = _winreg.l11ll1ll(_winreg.l1l11l11, l11lll1l)
        except l1l11ll1:
            continue
        value = _winreg.l11l1lll(l1l111ll, ll (u"ࠧࠨ࢔"))
        return value.split(ll (u"ࠨ࠮ࠣ࢕"))[-1]
    return None
def l1111l1():
    l11ll1l1 = []
    for name in l1l11lll:
        try:
            l11lll1l = ll (u"ࠢࡼ࠲ࢀࡠࡡࡹࡨࡦ࡮࡯ࡠࡡࡵࡰࡦࡰ࡟ࡠࡨࡵ࡭࡮ࡣࡱࡨࠧ࢖").format(name)
            l11llll1 = _winreg.l11ll1ll(_winreg.l1l11l11, l11lll1l)
            if _winreg.l11l1lll(l11llll1, ll (u"ࠣࠤࢗ")):
                l11ll1l1.append(name)
        except l1l11ll1:
            continue
    return l11ll1l1
def l111ll1(l11l11, l1l1l1):
    import re
    l1ll1 = []
    l11l1l1l = _winreg.l11ll1ll(_winreg.l1l11l11, ll (u"ࠤࡄࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࡳࠣ࢘"))
    for i in range(0, _winreg.l11ll111(l11l1l1l)[0]):
        try:
            l11l11l1 = _winreg.l11ll11l(l11l1l1l, i)
            if l11l11l1.startswith(l1l1l1):
                l1l111l1 = _winreg.l11l111l(l11l1l1l, l11l11l1)
                value, l111llll = _winreg.l11l11ll(l1l111l1, ll (u"ࠪࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡆࡶࡰࡏࡣࡰࡩ࢙ࠬ"))
                m = re.search(ll (u"ࠫࡻ࠮ࠨ࡜࡞ࡧࡡࢀ࠷ࠬࡾࠫ࡟࠲ࡠࡢࡤ࡞ࡽ࠴࠰ࢂࡢ࠮࡜࡞ࡧࡡࢀ࠷ࠬࡾ࡝࡟࠲ࡠࡢࡤ࡞ࡽ࠴࠰ࢂࡣ࠿࢚ࠪࠩ"), value)
                if m:
                    l1l11l1l = {ll (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࢛࠭"): m.group(1)}
                    l11l1ll1 = m.group(2)
                    if l11l11 == l11l1ll1:
                        m = re.search(l1l1l1.replace(ll (u"࠭࠮ࠨ࢜"), ll (u"ࠧ࡝࡞࠱ࠫ࢝")) + ll (u"ࠨࠪ࡞ࡠࡼࡣࠪࠪ࡞࠱ࡩࡽ࡫ࠧ࢞"), l11l11l1)
                        l1l11l1l[ll (u"ࠩࡳࡶࡴࡺ࡯ࡤࡱ࡯ࠫ࢟")] = m.group(1)
                        l1ll1.append(l1l11l1l)
                else:
                    raise ValueError(ll (u"ࠥࡇࡦࡴࠧࡵࠢࡪࡩࡹࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡧࡴࡲࡱ࠿ࠦࠥࡴࠢࠥࢠ") % value)
        except l1l11ll1 as ex:
            continue
    return l1ll1
def l11l1111(l1ll11):
    try:
        l11lllll = ll (u"ࠦࢀ࠶ࡽ࡝࡞ࡶ࡬ࡪࡲ࡬࡝࡞ࡲࡴࡪࡴ࡜࡝ࡥࡲࡱࡲࡧ࡮ࡥࠤࢡ").format(l1ll11)
        l1l11111 = _winreg.l11ll1ll(_winreg.l1l11l11, l11lllll)
        value, l111llll = _winreg.l11l11ll(l1l11111, ll (u"ࠬ࠭ࢢ"))
        if value:
            return value.split(ll (u"࠭ࠢࠨࢣ"))[1]
    except l1l11ll1:
        pass
    return ll (u"ࠧࠨࢤ")
def l111111(l1ll11, url):
    threading.Thread(target=_11l1l11,args=(l1ll11, url)).start()
    return ll (u"ࠣࡕࡸࡧࡨ࡫ࡳࡴࠤࢥ")
def _11l1l11(l1ll11, url):
    logger = l1lll()
    l1l1111l = l11l1111(l1ll11)
    logger.debug(ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l1111l, url))
    retcode = subprocess.Popen(ll (u"ࡵࠫࠧࠫࡳࠣࠢࠨࡷࠬࢧ") % (l1l1111l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡼࡧࡳࠡࡶࡨࡶࡲ࡯࡮ࡢࡶࡨࡨࠥࡨࡹࠡࡵ࡬࡫ࡳࡧ࡬࠭ࠢࠨࡷࠧࢨ") % retcode)
    else:
        logger.info(ll (u"ࠧࡕࡰࡦࡰࡨࡶࠥࡸࡥࡵࡷࡵࡲࡪࡪࠬࠡࠧࡶࠦࢩ") % retcode)