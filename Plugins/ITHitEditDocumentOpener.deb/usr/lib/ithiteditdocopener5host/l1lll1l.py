#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l11l1 = 2048
l1l1l1 = 7
def l11l (ll):
    global l1ll1
    l11l1l = ord (ll [-1])
    l11ll1 = ll [:-1]
    l1l11 = l11l1l % len (l11ll1)
    l11ll = l11ll1 [:l1l11] + l11ll1 [l1l11:]
    if l1l111:
        l111 = l1ll11 () .join ([unichr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    return eval (l111)
import subprocess, threading
from l11lll import l1ll1l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1llll1():
    l11l1ll1 = [l11l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1ll1:
        try:
            l11l11ll = l11l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll1l1 = winreg.l11ll11l(winreg.l11l1l11, l11l11ll)
        except l1l11l1l:
            continue
        value = winreg.l11lll1l(l11ll1l1, l11l (u"ࠦࠧ࢓"))
        return value.split(l11l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1lllll():
    l1l111ll = []
    for name in l1l1l111:
        try:
            l11l11ll = l11l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l111l = winreg.l11ll11l(winreg.l11l1l11, l11l11ll)
            if winreg.l11lll1l(l11l111l, l11l (u"ࠢࠣ࢖")):
                l1l111ll.append(name)
        except l1l11l1l:
            continue
    return l1l111ll
def l1l1ll1(l1ll, l1111):
    import re
    l111l = []
    l1l11lll = winreg.l11ll11l(winreg.l11l1l11, l11l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1lll(l1l11lll)[0]):
        try:
            l11ll111 = winreg.l1l1111l(l1l11lll, i)
            if l11ll111.startswith(l1111):
                l1l111l1 = winreg.l1l11111(l1l11lll, l11ll111)
                value, l11l1111 = winreg.l11l1l1l(l1l111l1, l11l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11llll1 = {l11l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll1ll = m.group(2)
                    if l1ll == l11ll1ll:
                        m = re.search(l1111.replace(l11l (u"ࠬ࠴࢛ࠧ"), l11l (u"࠭࡜࡝࠰ࠪ࢜")) + l11l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll111)
                        l11llll1[l11l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111l.append(l11llll1)
                else:
                    raise ValueError(l11l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11l1l as ex:
            continue
    return l111l
def l1l11ll1(l1lll1):
    try:
        l11lllll = l11l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1lll1)
        l1l11l11 = winreg.l11ll11l(winreg.l11l1l11, l11lllll)
        value, l11l1111 = winreg.l11l1l1l(l1l11l11, l11l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l (u"ࠬࠨࠧࢢ"))[1]
    except l1l11l1l:
        pass
    return l11l (u"࠭ࠧࢣ")
def l1111l1(l1lll1, url):
    threading.Thread(target=_11l11l1,args=(l1lll1, url)).start()
    return l11l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l11l1(l1lll1, url):
    logger = l1ll1l()
    l11lll11 = l1l11ll1(l1lll1)
    logger.debug(l11l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lll11, url))
    retcode = subprocess.Popen(l11l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lll11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)