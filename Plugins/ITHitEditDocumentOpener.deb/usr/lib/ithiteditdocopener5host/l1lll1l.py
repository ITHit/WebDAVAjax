#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111l1 = 2048
l1l111 = 7
def l1l11l (l1ll1l):
    global l1
    l11lll = ord (l1ll1l [-1])
    l1lll = l1ll1l [:-1]
    l111l = l11lll % len (l1lll)
    l1llll = l1lll [:l111l] + l1lll [l111l:]
    if l1l1l:
        l1111l = l1l1l1 () .join ([unichr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    return eval (l1111l)
import subprocess, threading
from l1l1 import l1111
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11111l():
    l11ll111 = [l1l11l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l11l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l11l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l11l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11ll111:
        try:
            l1l111l1 = l1l11l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll1ll = winreg.l1l111ll(winreg.l1l11lll, l1l111l1)
        except l11l11l1:
            continue
        value = winreg.l1l11111(l11ll1ll, l1l11l (u"ࠦࠧ࢓"))
        return value.split(l1l11l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11ll1l():
    l1l11l11 = []
    for name in l1l1l111:
        try:
            l1l111l1 = l1l11l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1ll1 = winreg.l1l111ll(winreg.l1l11lll, l1l111l1)
            if winreg.l1l11111(l11l1ll1, l1l11l (u"ࠢࠣ࢖")):
                l1l11l11.append(name)
        except l11l11l1:
            continue
    return l1l11l11
def l11ll11(l1l1ll, ll):
    import re
    l1ll11 = []
    l1l11l1l = winreg.l1l111ll(winreg.l1l11lll, l1l11l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll1l1(l1l11l1l)[0]):
        try:
            l11lll1l = winreg.l11lllll(l1l11l1l, i)
            if l11lll1l.startswith(ll):
                l11l1l1l = winreg.l11l1lll(l1l11l1l, l11lll1l)
                value, l1l11ll1 = winreg.l11llll1(l11l1l1l, l1l11l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l11l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1111 = {l1l11l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11ll = m.group(2)
                    if l1l1ll == l11l11ll:
                        m = re.search(ll.replace(l1l11l (u"ࠬ࠴࢛ࠧ"), l1l11l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l11l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll1l)
                        l11l1111[l1l11l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1ll11.append(l11l1111)
                else:
                    raise ValueError(l1l11l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l11l1 as ex:
            continue
    return l1ll11
def l11l111l(l1l11):
    try:
        l1l1111l = l1l11l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11)
        l11ll11l = winreg.l1l111ll(winreg.l1l11lll, l1l1111l)
        value, l1l11ll1 = winreg.l11llll1(l11ll11l, l1l11l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l11l (u"ࠬࠨࠧࢢ"))[1]
    except l11l11l1:
        pass
    return l1l11l (u"࠭ࠧࢣ")
def l1111l1(l1l11, url):
    threading.Thread(target=_11lll11,args=(l1l11, url)).start()
    return l1l11l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lll11(l1l11, url):
    logger = l1111()
    l11l1l11 = l11l111l(l1l11)
    logger.debug(l1l11l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1l11, url))
    retcode = subprocess.Popen(l1l11l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l11l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l11l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)