#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11lll = 2048
l1lll1 = 7
def l1l1l (l111l1):
    global l111l
    l111 = ord (l111l1 [-1])
    l1 = l111l1 [:-1]
    l1ll11 = l111 % len (l1)
    l11ll1 = l1 [:l1ll11] + l1 [l1ll11:]
    if l1ll1:
        l1l11 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    else:
        l1l11 = str () .join ([chr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    return eval (l1l11)
import subprocess, threading
from l11ll import ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1111ll():
    l11l11ll = [l1l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l11ll:
        try:
            l11l1111 = l1l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l111l1 = winreg.l11ll11l(winreg.l1l11l1l, l11l1111)
        except l1l11lll:
            continue
        value = winreg.l1l1111l(l1l111l1, l1l1l (u"ࠦࠧ࢓"))
        return value.split(l1l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111111():
    l11l11l1 = []
    for name in l1l1l11l:
        try:
            l11l1111 = l1l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11llll1 = winreg.l11ll11l(winreg.l1l11l1l, l11l1111)
            if winreg.l1l1111l(l11llll1, l1l1l (u"ࠢࠣ࢖")):
                l11l11l1.append(name)
        except l1l11lll:
            continue
    return l11l11l1
def l11l1ll(l1l11l, l1ll1l):
    import re
    l1llll = []
    l11l1ll1 = winreg.l11ll11l(winreg.l1l11l1l, l1l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11111(l11l1ll1)[0]):
        try:
            l11l1l11 = winreg.l11lllll(l11l1ll1, i)
            if l11l1l11.startswith(l1ll1l):
                l1l11l11 = winreg.l11lll1l(l11l1ll1, l11l1l11)
                value, l1l111ll = winreg.l11ll1ll(l1l11l11, l1l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1lll = {l1l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1l1l = m.group(2)
                    if l1l11l == l11l1l1l:
                        m = re.search(l1ll1l.replace(l1l1l (u"ࠬ࠴࢛ࠧ"), l1l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1l11)
                        l11l1lll[l1l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1llll.append(l11l1lll)
                else:
                    raise ValueError(l1l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11lll as ex:
            continue
    return l1llll
def l11ll1l1(l111ll):
    try:
        l11lll11 = l1l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l111ll)
        l11l111l = winreg.l11ll11l(winreg.l1l11l1l, l11lll11)
        value, l1l111ll = winreg.l11ll1ll(l11l111l, l1l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1l (u"ࠬࠨࠧࢢ"))[1]
    except l1l11lll:
        pass
    return l1l1l (u"࠭ࠧࢣ")
def l1l1l1l(l111ll, url):
    threading.Thread(target=_1l11ll1,args=(l111ll, url)).start()
    return l1l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11ll1(l111ll, url):
    logger = ll()
    l11ll111 = l11ll1l1(l111ll)
    logger.debug(l1l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll111, url))
    retcode = subprocess.Popen(l1l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll111, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)