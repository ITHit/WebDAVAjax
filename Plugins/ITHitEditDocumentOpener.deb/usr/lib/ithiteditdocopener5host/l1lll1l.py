#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l11ll = 2048
l111 = 7
def l1111l (l1l1):
    global l11l
    l1ll1l = ord (l1l1 [-1])
    l1l11 = l1l1 [:-1]
    l1lll1 = l1ll1l % len (l1l11)
    l111ll = l1l11 [:l1lll1] + l1l11 [l1lll1:]
    if l1l:
        l11l11 = l11ll1 () .join ([unichr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    return eval (l11l11)
import _winreg
import subprocess, threading
from l11l1l import l1l1l
from l1l1l11l import l1l1l111
def l1lllll():
    l1l11lll = [l1111l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1111l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1111l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1111l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11lll:
        try:
            l11ll1l1 = l1111l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1ll1 = _winreg.l11llll1(_winreg.l1l111l1, l11ll1l1)
        except l11l111l:
            continue
        value = _winreg.l1l11ll1(l11l1ll1, l1111l (u"ࠦࠧ࢓"))
        return value.split(l1111l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1l1l():
    l11ll111 = []
    for name in l1l1l111:
        try:
            l11ll1l1 = l1111l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l11 = _winreg.l11llll1(_winreg.l1l111l1, l11ll1l1)
            if _winreg.l1l11ll1(l1l11l11, l1111l (u"ࠢࠣ࢖")):
                l11ll111.append(name)
        except l11l111l:
            continue
    return l11ll111
def l11l1ll(l111l, l1l1ll):
    import re
    l1l1l1 = []
    l11l1l11 = _winreg.l11llll1(_winreg.l1l111l1, l1111l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, _winreg.l11l11ll(l11l1l11)[0]):
        try:
            l11ll1ll = _winreg.l1l111ll(l11l1l11, i)
            if l11ll1ll.startswith(l1l1ll):
                l11lll11 = _winreg.l11l1111(l11l1l11, l11ll1ll)
                value, l11l1lll = _winreg.l1l11l1l(l11lll11, l1111l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1111l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11111 = {l1111l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l1111l = m.group(2)
                    if l111l == l1l1111l:
                        m = re.search(l1l1ll.replace(l1111l (u"ࠬ࠴࢛ࠧ"), l1111l (u"࠭࡜࡝࠰ࠪ࢜")) + l1111l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll1ll)
                        l1l11111[l1111l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1l1.append(l1l11111)
                else:
                    raise ValueError(l1111l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l1l1l1
def l11l11l1(l1l111):
    try:
        l11lll1l = l1111l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l111)
        l11l1l1l = _winreg.l11llll1(_winreg.l1l111l1, l11lll1l)
        value, l11l1lll = _winreg.l1l11l1l(l11l1l1l, l1111l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1111l (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l1111l (u"࠭ࠧࢣ")
def l11lll1(l1l111, url):
    threading.Thread(target=_11ll11l,args=(l1l111, url)).start()
    return l1111l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll11l(l1l111, url):
    logger = l1l1l()
    l11lllll = l11l11l1(l1l111)
    logger.debug(l1111l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lllll, url))
    retcode = subprocess.Popen(l1111l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lllll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1111l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1111l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)