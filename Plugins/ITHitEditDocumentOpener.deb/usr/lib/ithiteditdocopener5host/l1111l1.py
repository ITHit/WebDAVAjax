#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll1 = 2048
l11l = 7
def l1l1l (l111ll):
    global l1l1
    l1l11 = ord (l111ll [-1])
    l11l11 = l111ll [:-1]
    l1111l = l1l11 % len (l11l11)
    l1l1ll = l11l11 [:l1111l] + l11l11 [l1111l:]
    if l1ll11:
        l111 = l1l111 () .join ([unichr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    return eval (l111)
import l11lll
from l1l1l111 import l1l1l11l
import objc as _1111l11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111l11.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111111.l111lll1(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1l (u"ࠨࠩࢬ"), {l1l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l111l1ll):
    l111l1ll = (l111l1ll + l1l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l1l = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l111l111 = CFURLCreateWithString( kCFAllocatorDefault, l1111l1l, _1111l11.nil )
    l111111l = LaunchServices.l11111l1( l111l111, LaunchServices.l111ll11, _1111l11.nil )
    if l111111l[0] is not None:
        return True
    return False
def l1lll():
    l11111ll = []
    for name in l1l1l11l:
        try:
            if l111l11l(name):
                l11111ll.append(name)
        except:
            continue
    return l11111ll
def l11l1l(l1lll1, l111l):
    import plistlib
    import os
    l1l11l = []
    l1111 = {}
    for l111llll in os.listdir(l1l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l111l):
            try:
                l111l1l1 = l1l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l111l1l1, l1l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    ll = plist[l1l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111ll1l = version.split(l1l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1lll1 == l111ll1l:
                        if not ll in l1111:
                            l1111[ll] = version
                        elif l11lll.l111l1(version, l1111[ll]) > 0:
                            l1111[ll] = version
            except BaseException:
                continue
    for ll in l1111:
        l1l11l.append({l1l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111[ll], l1l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): ll})
    return l1l11l