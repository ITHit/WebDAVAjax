#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1ll11 = 2048
l1l1ll = 7
def l11l (ll):
    global l111l1
    l1l11 = ord (ll [-1])
    l11ll1 = ll [:-1]
    l11ll = l1l11 % len (l11ll1)
    l1ll1 = l11ll1 [:l11ll] + l11ll1 [l11ll:]
    if l111ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    return eval (l1l1l1)
import l1lll
from l1l1l11l import l1l1l111
import objc as _111ll11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll11.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l111.l1111l11(l111ll1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l (u"ࠨࠩࢬ"), {l11l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111l1(l111111l):
    l111111l = (l111111l + l11l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l1l = CFStringCreateWithCString( kCFAllocatorDefault, l111111l, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l1111l1l, _111ll11.nil )
    l111l1l1 = LaunchServices.l111lll1( l11111ll, LaunchServices.l1111111, _111ll11.nil )
    if l111l1l1[0] is not None:
        return True
    return False
def l1l():
    l111llll = []
    for name in l1l1l111:
        try:
            if l11111l1(name):
                l111llll.append(name)
        except:
            continue
    return l111llll
def l11l1l(l111, l1111l):
    import plistlib
    import os
    l11lll = []
    l1ll = {}
    for l1111lll in os.listdir(l11l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l1111lll.startswith(l1111l):
            try:
                l111l11l = l11l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l1111lll
                with open(l111l11l, l11l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1 = plist[l11l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1ll = version.split(l11l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111 == l111l1ll:
                        if not l11l1 in l1ll:
                            l1ll[l11l1] = version
                        elif l1lll.l11(version, l1ll[l11l1]) > 0:
                            l1ll[l11l1] = version
            except BaseException:
                continue
    for l11l1 in l1ll:
        l11lll.append({l11l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll[l11l1], l11l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1})
    return l11lll