#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l = sys.version_info [0] == 2
l1111 = 2048
l111 = 7
def l1l1 (l1llll):
    global l1l11
    l1l11l = ord (l1llll [-1])
    l11l11 = l1llll [:-1]
    l1l1l = l1l11l % len (l11l11)
    l111ll = l11l11 [:l1l1l] + l11l11 [l1l1l:]
    if l11l:
        l1 = l1l () .join ([unichr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    else:
        l1 = str () .join ([chr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    return eval (l1)
import l1ll1l
from l1l1l11l import l1l1l111
import objc as _111l11l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l11l.l1111111( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l111l1ll(l111111l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111111l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1 (u"ࠨࠩࢬ"), {l1l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111lll(l111ll1l):
    l111ll1l = (l111ll1l + l1l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l111l111 = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _111l11l.nil )
    l1111ll1 = LaunchServices.l11111l1( l111l111, LaunchServices.l111ll11, _111l11l.nil )
    if l1111ll1[0] is not None:
        return True
    return False
def l11l1():
    l1111l1l = []
    for name in l1l1l111:
        try:
            if l1111lll(name):
                l1111l1l.append(name)
        except:
            continue
    return l1111l1l
def l11(l111l, l1l1l1):
    import plistlib
    import os
    l1l1ll = []
    l1lll1 = {}
    for l11111ll in os.listdir(l1l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111ll.startswith(l1l1l1):
            try:
                l1111l11 = l1l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111ll
                with open(l1111l11, l1l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l111l1 = plist[l1l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1l1 = version.split(l1l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111l == l111l1l1:
                        if not l111l1 in l1lll1:
                            l1lll1[l111l1] = version
                        elif l1ll1l.l1111l(version, l1lll1[l111l1]) > 0:
                            l1lll1[l111l1] = version
            except BaseException:
                continue
    for l111l1 in l1lll1:
        l1l1ll.append({l1l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll1[l111l1], l1l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l111l1})
    return l1l1ll