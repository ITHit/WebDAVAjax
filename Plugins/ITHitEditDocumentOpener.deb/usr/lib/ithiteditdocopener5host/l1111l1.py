#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11l1 = 2048
l11 = 7
def l1lll1 (l1111l):
    global l1ll1
    l1llll = ord (l1111l [-1])
    l1lll = l1111l [:-1]
    l1l1 = l1llll % len (l1lll)
    l11l11 = l1lll [:l1l1] + l1lll [l1l1:]
    if l111l:
        l111ll = l11lll () .join ([unichr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    return eval (l111ll)
import ll
from l1l1l111 import l1l1l11l
import objc as _111l111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l111.l111111l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1lll1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l1l.l1111l11(l111l1l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l1l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1lll1 (u"ࠨࠩࢬ"), {l1lll1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1lll1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1lll1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1lll1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1lll1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1lll1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1lll1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111l1(l1111ll1):
    l1111ll1 = (l1111ll1 + l1lll1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111ll11 = CFStringCreateWithCString( kCFAllocatorDefault, l1111ll1, kCFStringEncodingUTF8 )
    l111l11l = CFURLCreateWithString( kCFAllocatorDefault, l111ll11, _111l111.nil )
    l111lll1 = LaunchServices.l11111ll( l111l11l, LaunchServices.l111l1ll, _111l111.nil )
    if l111lll1[0] is not None:
        return True
    return False
def l1111():
    l1111111 = []
    for name in l1l1l11l:
        try:
            if l11111l1(name):
                l1111111.append(name)
        except:
            continue
    return l1111111
def l1l(l11l, l1):
    import plistlib
    import os
    l1l111 = []
    l111 = {}
    for l111ll1l in os.listdir(l1lll1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll1l.startswith(l1):
            try:
                l1111lll = l1lll1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll1l
                with open(l1111lll, l1lll1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l11 = plist[l1lll1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1lll1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1lll1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111llll = version.split(l1lll1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l == l111llll:
                        if not l1l11 in l111:
                            l111[l1l11] = version
                        elif ll.l1ll1l(version, l111[l1l11]) > 0:
                            l111[l1l11] = version
            except BaseException:
                continue
    for l1l11 in l111:
        l1l111.append({l1lll1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111[l1l11], l1lll1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l11})
    return l1l111