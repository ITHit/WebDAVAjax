#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1111l = 2048
l1ll = 7
def l1l11l (l1):
    global l11l11
    l111l1 = ord (l1 [-1])
    l1llll = l1 [:-1]
    l1ll11 = l111l1 % len (l1llll)
    l1l1ll = l1llll [:l1ll11] + l1llll [l1ll11:]
    if l111ll:
        l11l1 = l1l () .join ([unichr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1111l - (l1ll1l + l111l1) % l1ll) for l1ll1l, char in enumerate (l1l1ll)])
    return eval (l11l1)
import l111l
from l1l1l111 import l1l1l11l
import objc as _1111111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111111.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l11l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll11.l1111lll(l111111l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111111l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l11l (u"ࠨࠩࢬ"), {l1l11l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l11l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l11l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l11l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l11l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l11l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l11l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l1l1(l111l1ll):
    l111l1ll = (l111l1ll + l1l11l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l11 = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l111l11l = CFURLCreateWithString( kCFAllocatorDefault, l1111l11, _1111111.nil )
    l11111ll = LaunchServices.l111ll1l( l111l11l, LaunchServices.l111l111, _1111111.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l1l1l1():
    l11111l1 = []
    for name in l1l1l11l:
        try:
            if l111l1l1(name):
                l11111l1.append(name)
        except:
            continue
    return l11111l1
def l1l11(l1lll1, l1ll1):
    import plistlib
    import os
    l11 = []
    l1l111 = {}
    for l111llll in os.listdir(l1l11l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l1ll1):
            try:
                l111lll1 = l1l11l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l111lll1, l1l11l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11ll = plist[l1l11l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l11l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l11l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l1l = version.split(l1l11l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1lll1 == l1111l1l:
                        if not l11ll in l1l111:
                            l1l111[l11ll] = version
                        elif l111l.l11lll(version, l1l111[l11ll]) > 0:
                            l1l111[l11ll] = version
            except BaseException:
                continue
    for l11ll in l1l111:
        l11.append({l1l11l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l111[l11ll], l1l11l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11ll})
    return l11