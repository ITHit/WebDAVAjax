#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll = sys.version_info [0] == 2
l111l1 = 2048
l1ll1 = 7
def l11ll1 (l1l1l1):
    global l1l11
    l111ll = ord (l1l1l1 [-1])
    l1l1l = l1l1l1 [:-1]
    l1 = l111ll % len (l1l1l)
    l1111 = l1l1l [:l1] + l1l1l [l1:]
    if l11lll:
        l1l11l = l111l () .join ([unichr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l1 - (l11l + l111ll) % l1ll1) for l11l, char in enumerate (l1111)])
    return eval (l1l11l)
import subprocess, threading
from l1111l import l1ll11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1ll1ll():
    l11llll1 = [l11ll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11llll1:
        try:
            l11lll1l = l11ll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll1ll = winreg.l11lll11(winreg.l1l11l11, l11lll1l)
        except l11ll1l1:
            continue
        value = winreg.l11l1111(l11ll1ll, l11ll1 (u"ࠦࠧ࢓"))
        return value.split(l11ll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111l1l():
    l11l1lll = []
    for name in l1l1l11l:
        try:
            l11lll1l = l11ll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l111l = winreg.l11lll11(winreg.l1l11l11, l11lll1l)
            if winreg.l11l1111(l11l111l, l11ll1 (u"ࠢࠣ࢖")):
                l11l1lll.append(name)
        except l11ll1l1:
            continue
    return l11l1lll
def l1lll11(l11l11, l1l):
    import re
    l1l111 = []
    l11ll111 = winreg.l11lll11(winreg.l1l11l11, l11ll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1l1l(l11ll111)[0]):
        try:
            l11l1ll1 = winreg.l1l111ll(l11ll111, i)
            if l11l1ll1.startswith(l1l):
                l1l111l1 = winreg.l1l11ll1(l11ll111, l11l1ll1)
                value, l11l11ll = winreg.l1l11l1l(l1l111l1, l11ll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11l1 = {l11ll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11111 = m.group(2)
                    if l11l11 == l1l11111:
                        m = re.search(l1l.replace(l11ll1 (u"ࠬ࠴࢛ࠧ"), l11ll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1ll1)
                        l11l11l1[l11ll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l111.append(l11l11l1)
                else:
                    raise ValueError(l11ll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll1l1 as ex:
            continue
    return l1l111
def l1l1111l(l111):
    try:
        l1l11lll = l11ll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l111)
        l11l1l11 = winreg.l11lll11(winreg.l1l11l11, l1l11lll)
        value, l11l11ll = winreg.l1l11l1l(l11l1l11, l11ll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11ll1l1:
        pass
    return l11ll1 (u"࠭ࠧࢣ")
def l1ll1l1(l111, url):
    threading.Thread(target=_11lllll,args=(l111, url)).start()
    return l11ll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lllll(l111, url):
    logger = l1ll11()
    l11ll11l = l1l1111l(l111)
    logger.debug(l11ll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll11l, url))
    retcode = subprocess.Popen(l11ll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll11l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)