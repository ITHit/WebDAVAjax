#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11lll = 2048
l1lll1 = 7
def l1l1l (l111l1):
    global l111l
    l111 = ord (l111l1 [-1])
    l1 = l111l1 [:-1]
    l1ll11 = l111 % len (l1)
    l11ll1 = l1 [:l1ll11] + l1 [l1ll11:]
    if l1ll1:
        l1l11 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    else:
        l1l11 = str () .join ([chr (ord (char) - l11lll - (l1l1ll + l111) % l1lll1) for l1l1ll, char in enumerate (l11ll1)])
    return eval (l1l11)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l11ll(l1ll111=None):
    if platform.system() == l1l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l1l1l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111lll = l1l1lll.l1ll11l(l1ll111, l1l1l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11llll in prop_names:
                l11l1l1 = l1l1l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111lll, l11llll)
                props[l11llll] = l1l1lll.l1ll11l(l1ll111, l11l1l1)
        except:
            pass
    return props
def l11111(logger, l1lllll):
    l11l111 = os.environ.get(l1l1l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l111 = l11l111.upper()
    if l11l111 == l1l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111l1l = logging.DEBUG
    elif l11l111 == l1l1l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111l1l = logging.INFO
    elif l11l111 == l1l1l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111l1l = logging.WARNING
    elif l11l111 == l1l1l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111l1l = logging.ERROR
    elif l11l111 == l1l1l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111l1l = logging.CRITICAL
    elif l11l111 == l1l1l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111l1l = logging.NOTSET
    logger.setLevel(l111l1l)
    l11lll1 = RotatingFileHandler(l1lllll, maxBytes=1024*1024*5, backupCount=3)
    l11lll1.setLevel(l111l1l)
    formatter = logging.Formatter(l1l1l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11lll1.setFormatter(formatter)
    logger.addHandler(l11lll1)
    globals()[l1l1l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def ll():
    return globals()[l1l1l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1111l1():
    if platform.system() == l1l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11ll1l
        l11ll1l.l1l1111(sys.stdin.fileno(), os.l111l11)
        l11ll1l.l1l1111(sys.stdout.fileno(), os.l111l11)
def l1ll1ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll11():
    if platform.system() == l1l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1lll1l
        return l1lll1l.l1111ll()
    elif platform.system() == l1l1l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1lll():
    if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1lll1l
        return l1lll1l.l111111()
    elif platform.system() == l1l1l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11l
        return l11l.l1lll()
    elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11111l
        return l11111l.l1lll()
    return l1l1l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l111l(l1l11l, l1ll1l):
    if platform.system() == l1l1l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1lll1l
        return l1lll1l.l11l1ll(l1l11l, l1ll1l)
    elif platform.system() == l1l1l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11111l
        return l11111l.l1111(l1l11l, l1ll1l)
    elif platform.system() == l1l1l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11l
        return l11l.l1111(l1l11l, l1ll1l)
    raise ValueError(l1l1l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111ll1(l111ll, url):
    if platform.system() == l1l1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1lll1l
        return l1lll1l.l1l1l1l(l111ll, url)
    elif platform.system() == l1l1l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11111l
        return l1l1l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11l
        return l1l1l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l11l1():
    if platform.system() == l1l1l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1lll1l
        return l1lll1l.l1l11l1()
def l1llllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1l (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1ll1(l11l1l):
    l1l1l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1l11 = l1l1l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11l1l:
        if l1l1l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1l11[3:]) < int(protocol[l1l1l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1l11 = protocol[l1l1l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1l11
def l1l1l1(l1lll11, l1llll1):
    l1l1l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1lll11 is None: l1lll11 = l1l1l (u"ࠩ࠳ࠫ࠽");
    if l1llll1 is None: l1llll1 = l1l1l (u"ࠪ࠴ࠬ࠾");
    l11l11l = l1lll11.split(l1l1l (u"ࠫ࠳࠭࠿"))
    l1ll1l1 = l1llll1.split(l1l1l (u"ࠬ࠴ࠧࡀ"))
    while len(l11l11l) < len(l1ll1l1): l11l11l.append(l1l1l (u"ࠨ࠰ࠣࡁ"));
    while len(l1ll1l1) < len(l11l11l): l1ll1l1.append(l1l1l (u"ࠢ࠱ࠤࡂ"));
    l11l11l = [ int(x) for x in l11l11l ]
    l1ll1l1 = [ int(x) for x in l1ll1l1 ]
    for  i in range(len(l11l11l)):
        if len(l1ll1l1) == i:
            return 1
        if l11l11l[i] == l1ll1l1[i]:
            continue
        elif l11l11l[i] > l1ll1l1[i]:
            return 1
        else:
            return -1
    if len(l11l11l) != len(l1ll1l1):
        return -1
    return 0