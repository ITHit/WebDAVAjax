#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l1l1ll = 2048
l1111 = 7
def l11l (l111ll):
    global l1l111
    l111l1 = ord (l111ll [-1])
    l1111l = l111ll [:-1]
    l11 = l111l1 % len (l1111l)
    l1ll1l = l1111l [:l11] + l1111l [l11:]
    if ll:
        l1l1l1 = l11l1 () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    return eval (l1l1l1)
import os
import re
import subprocess
import l1ll
from l1ll import l1llll
def l11ll1():
    return []
def l1ll11(l1l1l, l111l):
    logger = l1llll()
    l1lll1 = []
    l1l1 = [l11l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l11 = process.wait()
            l1l = {}
            if l1l11 == 0:
                l111 = re.compile(l11l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1l = re.compile(l11l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l11l = re.search(l111, line)
                    l1ll1 = l1l11l.group(1)
                    if l1l1l == l1ll1:
                        l11lll = re.search(l11l1l, line)
                        if l11lll:
                            l1 = l11l (u"ࠨࡦࡤࡺࠬࠄ")+l11lll.group(1)
                            version = l1l11l.group(0)
                            if not l1 in l1l:
                                l1l[l1] = version
                            elif l1ll.l1lll(version, l1l[l1]) > 0:
                                l1l[l1] = version
            for l1 in l1l:
                l1lll1.append({l11l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l[l1], l11l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1})
        except Exception as e:
            logger.error(str(e))
    return l1lll1