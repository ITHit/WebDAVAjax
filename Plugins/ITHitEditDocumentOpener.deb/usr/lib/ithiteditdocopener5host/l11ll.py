#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l11ll1 = 2048
l11l = 7
def l1l1l (l111ll):
    global l1l1
    l1l11 = ord (l111ll [-1])
    l11l11 = l111ll [:-1]
    l1111l = l1l11 % len (l11l11)
    l1l1ll = l11l11 [:l1111l] + l11l11 [l1111l:]
    if l1ll11:
        l111 = l1l111 () .join ([unichr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11ll1 - (l1l1l1 + l1l11) % l11l) for l1l1l1, char in enumerate (l1l1ll)])
    return eval (l111)
import os
import re
import subprocess
import l11lll
from l11lll import l11
def l1lll():
    return []
def l11l1l(l1lll1, l111l):
    logger = l11()
    l1l11l = []
    l1ll = [l1l1l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l = process.wait()
            l1111 = {}
            if l1l == 0:
                l1llll = re.compile(l1l1l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1 = re.compile(l1l1l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1 = re.search(l1llll, line)
                    l1ll1 = l11l1.group(1)
                    if l1lll1 == l1ll1:
                        l1ll1l = re.search(l1, line)
                        if l1ll1l:
                            ll = l1l1l (u"ࠨࡦࡤࡺࠬࠄ")+l1ll1l.group(1)
                            version = l11l1.group(0)
                            if not ll in l1111:
                                l1111[ll] = version
                            elif l11lll.l111l1(version, l1111[ll]) > 0:
                                l1111[ll] = version
            for ll in l1111:
                l1l11l.append({l1l1l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111[ll], l1l1l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): ll})
        except Exception as e:
            logger.error(str(e))
    return l1l11l