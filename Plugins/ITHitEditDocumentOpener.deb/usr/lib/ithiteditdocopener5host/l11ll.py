#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll1 = 7
def l1llll (l11ll1):
    global ll
    l1l11l = ord (l11ll1 [-1])
    l1l1ll = l11ll1 [:-1]
    l11 = l1l11l % len (l1l1ll)
    l1 = l1l1ll [:l11] + l1l1ll [l11:]
    if l11l11:
        l111ll = l11l1 () .join ([unichr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    else:
        l111ll = str () .join ([chr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    return eval (l111ll)
import os
import re
import subprocess
import l1111l
from l1111l import l1l111
def l11lll():
    return []
def l1l1l1(l111, l1l1l):
    logger = l1l111()
    l1l11 = []
    l1l = [l1llll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1llll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll1l = process.wait()
            l1lll = {}
            if l1ll1l == 0:
                l1lll1 = re.compile(l1llll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l111l = re.compile(l1llll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll = re.search(l1lll1, line)
                    l111l1 = l1ll.group(1)
                    if l111 == l111l1:
                        l1111 = re.search(l111l, line)
                        if l1111:
                            l11l = l1llll (u"ࠨࡦࡤࡺࠬࠄ")+l1111.group(1)
                            version = l1ll.group(0)
                            if not l11l in l1lll:
                                l1lll[l11l] = version
                            elif l1111l.l11l1l(version, l1lll[l11l]) > 0:
                                l1lll[l11l] = version
            for l11l in l1lll:
                l1l11.append({l1llll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll[l11l], l1llll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l})
        except Exception as e:
            logger.error(str(e))
    return l1l11