#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1l11l = 2048
l1lll = 7
def l11ll (l1111):
    global l1l11
    l111 = ord (l1111 [-1])
    l1ll1 = l1111 [:-1]
    l1llll = l111 % len (l1ll1)
    l11 = l1ll1 [:l1llll] + l1ll1 [l1llll:]
    if l1ll:
        l1 = l11l1l () .join ([unichr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    return eval (l1)
import os
import re
import subprocess
import l11l11
from l11l11 import l11ll1
def l111l():
    return []
def ll(l1111l, l11l1):
    logger = l11ll1()
    l1l1ll = []
    l1l = [l11ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l1 = process.wait()
            l11l = {}
            if l1l1 == 0:
                l1lll1 = re.compile(l11ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll11 = re.compile(l11ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11lll = re.search(l1lll1, line)
                    l1l111 = l11lll.group(1)
                    if l1111l == l1l111:
                        l111ll = re.search(l1ll11, line)
                        if l111ll:
                            l1l1l1 = l11ll (u"ࠨࡦࡤࡺࠬࠄ")+l111ll.group(1)
                            version = l11lll.group(0)
                            if not l1l1l1 in l11l:
                                l11l[l1l1l1] = version
                            elif l11l11.l111l1(version, l11l[l1l1l1]) > 0:
                                l11l[l1l1l1] = version
            for l1l1l1 in l11l:
                l1l1ll.append({l11ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11l[l1l1l1], l11ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1l1})
        except Exception as e:
            logger.error(str(e))
    return l1l1ll