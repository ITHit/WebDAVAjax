#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll1 = 2048
l11l = 7
def ll (l1):
    global l1l
    l1llll = ord (l1 [-1])
    l1l111 = l1 [:-1]
    l1l1l1 = l1llll % len (l1l111)
    l11lll = l1l111 [:l1l1l1] + l1l111 [l1l1l1:]
    if l11ll:
        l111 = l11l11 () .join ([unichr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    else:
        l111 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    return eval (l111)
import os
import re
import subprocess
import l111l1
from l111l1 import l1111l
def l11ll1():
    return []
def l1lll(l1111, l11l1):
    logger = l1111l()
    l1l1l = []
    l1l1ll = [ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1ll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1ll = process.wait()
            l1lll1 = {}
            if l1ll == 0:
                l1l11l = re.compile(ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11 = re.compile(ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1 = re.search(l1l11l, line)
                    l111ll = l1l1.group(1)
                    if l1111 == l111ll:
                        l1l11 = re.search(l11, line)
                        if l1l11:
                            l11l1l = ll (u"ࠨࡦࡤࡺࠬࠄ")+l1l11.group(1)
                            version = l1l1.group(0)
                            if not l11l1l in l1lll1:
                                l1lll1[l11l1l] = version
                            elif l111l1.l1ll11(version, l1lll1[l11l1l]) > 0:
                                l1lll1[l11l1l] = version
            for l11l1l in l1lll1:
                l1l1l.append({ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll1[l11l1l], ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1l})
        except Exception as e:
            logger.error(str(e))
    return l1l1l