#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1 = 2048
l111 = 7
def l1lll (l1l111):
    global l11l1l
    l1l = ord (l1l111 [-1])
    l11lll = l1l111 [:-1]
    l1ll1 = l1l % len (l11lll)
    l11l11 = l11lll [:l1ll1] + l11lll [l1ll1:]
    if l1l1l:
        l1l1ll = l1ll11 () .join ([unichr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1 - (l1l1 + l1l) % l111) for l1l1, char in enumerate (l11l11)])
    return eval (l1l1ll)
import os
import re
import subprocess
import l111ll
from l111ll import l1111
def l1ll():
    return []
def ll(l11ll1, l111l1):
    logger = l1111()
    l11l1 = []
    l111l = [l1lll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1lll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11 = process.wait()
            l1111l = {}
            if l11 == 0:
                l11ll = re.compile(l1lll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l = re.compile(l1lll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l11 = re.search(l11ll, line)
                    l1llll = l1l11.group(1)
                    if l11ll1 == l1llll:
                        l1l1l1 = re.search(l11l, line)
                        if l1l1l1:
                            l1lll1 = l1lll (u"ࠨࡦࡤࡺࠬࠄ")+l1l1l1.group(1)
                            version = l1l11.group(0)
                            if not l1lll1 in l1111l:
                                l1111l[l1lll1] = version
                            elif l111ll.l1l11l(version, l1111l[l1lll1]) > 0:
                                l1111l[l1lll1] = version
            for l1lll1 in l1111l:
                l11l1.append({l1lll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111l[l1lll1], l1lll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1lll1})
        except Exception as e:
            logger.error(str(e))
    return l11l1