#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll = sys.version_info [0] == 2
l1l111 = 2048
l111 = 7
def l11 (l11l1):
    global l1111l
    l11l = ord (l11l1 [-1])
    l111ll = l11l1 [:-1]
    l1l11 = l11l % len (l111ll)
    l1l1l1 = l111ll [:l1l11] + l111ll [l1l11:]
    if l1lll:
        l1 = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    return eval (l1)
import os
import re
import subprocess
import ll
from ll import l1ll1
def l1ll():
    return []
def l11l11(l11ll, l11ll1):
    logger = l1ll1()
    l11l1l = []
    l111l1 = [l11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1llll = process.wait()
            l111l = {}
            if l1llll == 0:
                l1l = re.compile(l11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11lll = re.compile(l11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1ll11 = re.search(l1l, line)
                    l1lll1 = l1ll11.group(1)
                    if l11ll == l1lll1:
                        l1111 = re.search(l11lll, line)
                        if l1111:
                            l1l1 = l11 (u"ࠨࡦࡤࡺࠬࠄ")+l1111.group(1)
                            version = l1ll11.group(0)
                            if not l1l1 in l111l:
                                l111l[l1l1] = version
                            elif ll.l1l1ll(version, l111l[l1l1]) > 0:
                                l111l[l1l1] = version
            for l1l1 in l111l:
                l11l1l.append({l11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l[l1l1], l11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1})
        except Exception as e:
            logger.error(str(e))
    return l11l1l