#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11ll = 2048
l1llll = 7
def l1ll11 (l1l1):
    global l1ll1
    l11l1 = ord (l1l1 [-1])
    l1l = l1l1 [:-1]
    l111 = l11l1 % len (l1l)
    l11lll = l1l [:l111] + l1l [l111:]
    if l111l:
        l1l111 = l11l11 () .join ([unichr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    return eval (l1l111)
import os
import re
import subprocess
import l1111l
from l1111l import l1111
def l11l1l():
    return []
def l1l11(l1lll1, l1l1l1):
    logger = l1111()
    l1l1ll = []
    l1 = [l1ll11 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll11 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll1 = process.wait()
            l1l1l = {}
            if l11ll1 == 0:
                l11l = re.compile(l1ll11 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll = re.compile(l1ll11 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l11l = re.search(l11l, line)
                    l11 = l1l11l.group(1)
                    if l1lll1 == l11:
                        l1lll = re.search(l1ll, line)
                        if l1lll:
                            l111l1 = l1ll11 (u"ࠨࡦࡤࡺࠬࠄ")+l1lll.group(1)
                            version = l1l11l.group(0)
                            if not l111l1 in l1l1l:
                                l1l1l[l111l1] = version
                            elif l1111l.ll(version, l1l1l[l111l1]) > 0:
                                l1l1l[l111l1] = version
            for l111l1 in l1l1l:
                l1l1ll.append({l1ll11 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l1l[l111l1], l1ll11 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l111l1})
        except Exception as e:
            logger.error(str(e))
    return l1l1ll