#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1ll11 = 2048
l1l1ll = 7
def l11l (ll):
    global l111l1
    l1l11 = ord (ll [-1])
    l11ll1 = ll [:-1]
    l11ll = l1l11 % len (l11ll1)
    l1ll1 = l11ll1 [:l11ll] + l11ll1 [l11ll:]
    if l111ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    return eval (l1l1l1)
import os
import re
import subprocess
import l1lll
from l1lll import l1l11l
def l1l():
    return []
def l11l1l(l111, l1111l):
    logger = l1l11l()
    l11lll = []
    l111l = [l11l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l111l:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1l111 = process.wait()
            l1ll = {}
            if l1l111 == 0:
                l11l11 = re.compile(l11l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1 = re.compile(l11l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1l = re.search(l11l11, line)
                    l1lll1 = l1l1l.group(1)
                    if l111 == l1lll1:
                        l1 = re.search(l1l1, line)
                        if l1:
                            l11l1 = l11l (u"ࠨࡦࡤࡺࠬࠄ")+l1.group(1)
                            version = l1l1l.group(0)
                            if not l11l1 in l1ll:
                                l1ll[l11l1] = version
                            elif l1lll.l11(version, l1ll[l11l1]) > 0:
                                l1ll[l11l1] = version
            for l11l1 in l1ll:
                l11lll.append({l11l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll[l11l1], l11l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1})
        except Exception as e:
            logger.error(str(e))
    return l11lll