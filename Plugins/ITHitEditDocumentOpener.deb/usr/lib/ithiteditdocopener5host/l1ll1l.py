#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1111l = 2048
ll = 7
def l1ll (l11l):
    global l1l111
    l1lll = ord (l11l [-1])
    l1l1l1 = l11l [:-1]
    l111l1 = l1lll % len (l1l1l1)
    l11l1 = l1l1l1 [:l111l1] + l1l1l1 [l111l1:]
    if l111l:
        l1l1ll = l111 () .join ([unichr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l1111l - (l11ll + l1lll) % ll) for l11ll, char in enumerate (l11l1)])
    return eval (l1l1ll)
import os
import re
import subprocess
import l11l1l
from l11l1l import l11
def l1lll1():
    return []
def l1l1l(l111ll, l1l):
    logger = l11()
    l1l1 = []
    l11lll = [l1ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l11ll1 = process.wait()
            l1111 = {}
            if l11ll1 == 0:
                l1ll11 = re.compile(l1ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11 = re.compile(l1ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l11 = re.search(l1ll11, line)
                    l1llll = l11l11.group(1)
                    if l111ll == l1llll:
                        l1ll1 = re.search(l1l11, line)
                        if l1ll1:
                            l1l11l = l1ll (u"ࠨࡦࡤࡺࠬࠄ")+l1ll1.group(1)
                            version = l11l11.group(0)
                            if not l1l11l in l1111:
                                l1111[l1l11l] = version
                            elif l11l1l.l1(version, l1111[l1l11l]) > 0:
                                l1111[l1l11l] = version
            for l1l11l in l1111:
                l1l1.append({l1ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111[l1l11l], l1ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l11l})
        except Exception as e:
            logger.error(str(e))
    return l1l1