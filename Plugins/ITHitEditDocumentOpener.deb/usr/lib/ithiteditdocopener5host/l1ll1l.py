#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l = sys.version_info [0] == 2
l1111 = 2048
l111 = 7
def l1l1 (l1llll):
    global l1l11
    l1l11l = ord (l1llll [-1])
    l11l11 = l1llll [:-1]
    l1l1l = l1l11l % len (l11l11)
    l111ll = l11l11 [:l1l1l] + l11l11 [l1l1l:]
    if l11l:
        l1 = l1l () .join ([unichr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    else:
        l1 = str () .join ([chr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    return eval (l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1111ll(l11111=None):
    if platform.system() == l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111ll1
        props = {}
        try:
            prop_names = (l1l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1ll11l = l111ll1.l11111l(l11111, l1l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l111l1l in prop_names:
                l1ll1l1 = l1l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1ll11l, l111l1l)
                props[l111l1l] = l111ll1.l11111l(l11111, l1ll1l1)
        except:
            pass
    return props
def l11ll1l(logger, l1l11ll):
    l1llllll = os.environ.get(l1l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1llllll = l1llllll.upper()
    if l1llllll == l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l1lll = logging.DEBUG
    elif l1llllll == l1l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l1lll = logging.INFO
    elif l1llllll == l1l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l1lll = logging.WARNING
    elif l1llllll == l1l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l1lll = logging.ERROR
    elif l1llllll == l1l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l1lll = logging.CRITICAL
    elif l1llllll == l1l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l1lll = logging.NOTSET
    logger.setLevel(l1l1lll)
    l1lll1l = RotatingFileHandler(l1l11ll, maxBytes=1024*1024*5, backupCount=3)
    l1lll1l.setLevel(l1l1lll)
    formatter = logging.Formatter(l1l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lll1l.setFormatter(formatter)
    logger.addHandler(l1lll1l)
    globals()[l1l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1ll1():
    return globals()[l1l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111lll():
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l1l1
        l11l1l1.l11ll11(sys.stdin.fileno(), os.l11lll1)
        l11l1l1.l11ll11(sys.stdout.fileno(), os.l11lll1)
def l11l1ll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11llll():
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1lllll
        return l1lllll.l1lll11()
    elif platform.system() == l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l1():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1lllll
        return l1lllll.l1l1l1l()
    elif platform.system() == l1l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import ll
        return ll.l11l1()
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1111l1
        return l1111l1.l11l1()
    return l1l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l11l1(l111l, l1l1l1):
    if platform.system() == l1l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1lllll
        return l1lllll.l1l1ll1(l111l, l1l1l1)
    elif platform.system() == l1l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1111l1
        return l1111l1.l11(l111l, l1l1l1)
    elif platform.system() == l1l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import ll
        return ll.l11(l111l, l1l1l1)
    raise ValueError(l1l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111111(l111l1, url):
    if platform.system() == l1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1lllll
        return l1lllll.l111l11(l111l1, url)
    elif platform.system() == l1l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1111l1
        return l1l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import ll
        return l1l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l11l111():
    if platform.system() == l1l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1lllll
        return l1lllll.l11l111()
def l1llll1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll111(l1lll1):
    l1l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1ll1ll = l1l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1lll1:
        if l1l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1ll1ll[3:]) < int(protocol[l1l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1ll1ll = protocol[l1l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1ll1ll
def l1111l(l11l11l, l1l111l):
    l1l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11l11l is None: l11l11l = l1l1 (u"ࠩ࠳ࠫ࠽");
    if l1l111l is None: l1l111l = l1l1 (u"ࠪ࠴ࠬ࠾");
    l1l1111 = l11l11l.split(l1l1 (u"ࠫ࠳࠭࠿"))
    l1l1l11 = l1l111l.split(l1l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1111) < len(l1l1l11): l1l1111.append(l1l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l1l1l11) < len(l1l1111): l1l1l11.append(l1l1 (u"ࠢ࠱ࠤࡂ"));
    l1l1111 = [ int(x) for x in l1l1111 ]
    l1l1l11 = [ int(x) for x in l1l1l11 ]
    for  i in range(len(l1l1111)):
        if len(l1l1l11) == i:
            return 1
        if l1l1111[i] == l1l1l11[i]:
            continue
        elif l1l1111[i] > l1l1l11[i]:
            return 1
        else:
            return -1
    if len(l1l1111) != len(l1l1l11):
        return -1
    return 0