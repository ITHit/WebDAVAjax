#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1ll11 = 2048
l1llll = 7
def l1 (l11lll):
    global l1l1
    l11ll1 = ord (l11lll [-1])
    l111l = l11lll [:-1]
    l1l = l11ll1 % len (l111l)
    l111ll = l111l [:l1l] + l111l [l1l:]
    if l11l1:
        l1111 = l1l1l () .join ([unichr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll11 - (l11l1l + l11ll1) % l1llll) for l11l1l, char in enumerate (l111ll)])
    return eval (l1111)
import os
import re
import subprocess
import l1l1l1
from l1l1l1 import l111l1
def l111():
    return []
def l1lll1(l11l11, l11l):
    logger = l111l1()
    l11 = []
    ll = [l1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in ll:
        try:
            output = os.popen(cmd).read()
            l1111l = 0
            l1lll = {}
            if l1111l == 0:
                l1ll1 = re.compile(l1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll = re.compile(l1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l11 = re.search(l1ll1, line)
                    l1l1ll = l1l11.group(1)
                    if l11l11 == l1l1ll:
                        l1l111 = re.search(l1ll, line)
                        if l1l111:
                            l1l11l = l1 (u"ࠨࡦࡤࡺࠬࠄ")+l1l111.group(1)
                            version = l1l11.group(0)
                            if not l1l11l in l1lll:
                                l1lll[l1l11l] = version
                            elif l1l1l1.l11ll(version, l1lll[l1l11l]) > 0:
                                l1lll[l1l11l] = version
            for l1l11l in l1lll:
                l11.append({l1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1lll[l1l11l], l1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l11l})
        except Exception as e:
            logger.error(str(e))
    return l11