#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1l = 7
def l1ll (l1):
    global l111l1
    l1l = ord (l1 [-1])
    ll = l1 [:-1]
    l111l = l1l % len (ll)
    l11ll = ll [:l111l] + ll [l111l:]
    if l1ll1:
        l1ll11 = l1l111 () .join ([unichr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    return eval (l1ll11)
import l1l1ll
from l1l1l11l import l1l1l111
import objc as _111ll11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll11.l1111lll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l111l111(l111llll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111llll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll (u"ࠨࠩࢬ"), {l1ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l1111l11):
    l1111l11 = (l1111l11 + l1ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111l1ll = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l111l1ll, _111ll11.nil )
    l111ll1l = LaunchServices.l11111l1( l11111ll, LaunchServices.l111l11l, _111ll11.nil )
    if l111ll1l[0] is not None:
        return True
    return False
def l11lll():
    l111111l = []
    for name in l1l1l111:
        try:
            if l1111l1l(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l11ll1(l1lll, l11l):
    import plistlib
    import os
    l11l11 = []
    l111 = {}
    for l111l1l1 in os.listdir(l1ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l11l):
            try:
                l1111ll1 = l1ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l1111ll1, l1ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1 = plist[l1ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l1ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1lll == l1111111:
                        if not l11l1 in l111:
                            l111[l11l1] = version
                        elif l1l1ll.l1111l(version, l111[l11l1]) > 0:
                            l111[l11l1] = version
            except BaseException:
                continue
    for l11l1 in l111:
        l11l11.append({l1ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111[l11l1], l1ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1})
    return l11l11