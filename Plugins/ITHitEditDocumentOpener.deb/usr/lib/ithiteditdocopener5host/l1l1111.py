#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1111 = 7
def l1l1l (l1111l):
    global l1l111
    l11lll = ord (l1111l [-1])
    l1l11l = l1111l [:-1]
    l1ll11 = l11lll % len (l1l11l)
    l11 = l1l11l [:l1ll11] + l1l11l [l1ll11:]
    if l1l1:
        l111ll = l1llll () .join ([unichr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l111l1 + l11lll) % l1111) for l111l1, char in enumerate (l11)])
    return eval (l111ll)
import subprocess, threading
from l1l import l11l11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l111l11():
    l11l1111 = [l1l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1111:
        try:
            l1l11lll = l1l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l11ll = winreg.l11lll11(winreg.l11l111l, l1l11lll)
        except l11llll1:
            continue
        value = winreg.l11ll111(l11l11ll, l1l1l (u"ࠦࠧ࢓"))
        return value.split(l1l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l11l1():
    l11l11l1 = []
    for name in l1l1l11l:
        try:
            l1l11lll = l1l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll11l = winreg.l11lll11(winreg.l11l111l, l1l11lll)
            if winreg.l11ll111(l11ll11l, l1l1l (u"ࠢࠣ࢖")):
                l11l11l1.append(name)
        except l11llll1:
            continue
    return l11l11l1
def l1l111l(l1lll, l1):
    import re
    ll = []
    l11lll1l = winreg.l11lll11(winreg.l11l111l, l1l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l1l(l11lll1l)[0]):
        try:
            l1l11ll1 = winreg.l11ll1ll(l11lll1l, i)
            if l1l11ll1.startswith(l1):
                l11l1l1l = winreg.l11lllll(l11lll1l, l1l11ll1)
                value, l1l11111 = winreg.l1l1111l(l11l1l1l, l1l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111l1 = {l1l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1lll = m.group(2)
                    if l1lll == l11l1lll:
                        m = re.search(l1.replace(l1l1l (u"ࠬ࠴࢛ࠧ"), l1l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11ll1)
                        l1l111l1[l1l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        ll.append(l1l111l1)
                else:
                    raise ValueError(l1l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11llll1 as ex:
            continue
    return ll
def l11l1l11(l11ll):
    try:
        l11l1ll1 = l1l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11ll)
        l1l111ll = winreg.l11lll11(winreg.l11l111l, l11l1ll1)
        value, l1l11111 = winreg.l1l1111l(l1l111ll, l1l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11llll1:
        pass
    return l1l1l (u"࠭ࠧࢣ")
def l111111(l11ll, url):
    threading.Thread(target=_1l11l11,args=(l11ll, url)).start()
    return l1l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11l11(l11ll, url):
    logger = l11l11()
    l11ll1l1 = l11l1l11(l11ll)
    logger.debug(l1l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll1l1, url))
    retcode = subprocess.Popen(l1l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll1l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)