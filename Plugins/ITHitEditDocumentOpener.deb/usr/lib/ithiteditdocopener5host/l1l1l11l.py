#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1ll1 = 7
def l1l1l (l11lll):
    global l11l1
    l1l111 = ord (l11lll [-1])
    l1l = l11lll [:-1]
    l1l1ll = l1l111 % len (l1l)
    l1l1 = l1l [:l1l1ll] + l1l [l1l1ll:]
    if l1llll:
        l1111 = l1111l () .join ([unichr (ord (char) - l1ll - (l1 + l1l111) % l1ll1) for l1, char in enumerate (l1l1)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll - (l1 + l1l111) % l1ll1) for l1, char in enumerate (l1l1)])
    return eval (l1111)
l1l1l111 = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]