#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l = 2048
l1l1l1 = 7
def l111l (l11ll):
    global l1l1l
    l1l1ll = ord (l11ll [-1])
    l11l11 = l11ll [:-1]
    l11l1l = l1l1ll % len (l11l11)
    l1l111 = l11l11 [:l11l1l] + l11l11 [l11l1l:]
    if l1:
        l1lll1 = ll () .join ([unichr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    return eval (l1lll1)
l1l1l111 = [l111l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l111l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l111l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l111l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l111l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l111l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l111l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l111l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l111l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]