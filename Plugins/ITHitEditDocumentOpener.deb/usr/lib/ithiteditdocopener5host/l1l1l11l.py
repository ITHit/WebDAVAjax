#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l1llll = 2048
l1l11 = 7
def l1ll1 (l1ll11):
    global l1l1l1
    l1111 = ord (l1ll11 [-1])
    ll = l1ll11 [:-1]
    l111l = l1111 % len (ll)
    l11l1l = ll [:l111l] + ll [l111l:]
    if l1l1:
        l11l = l111ll () .join ([unichr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    else:
        l11l = str () .join ([chr (ord (char) - l1llll - (l1 + l1111) % l1l11) for l1, char in enumerate (l11l1l)])
    return eval (l11l)
l1l1l111 = [l1ll1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]