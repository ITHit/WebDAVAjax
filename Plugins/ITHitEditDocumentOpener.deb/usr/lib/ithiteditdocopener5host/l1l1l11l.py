#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l11lll = 2048
l111ll = 7
def l11 (l1l1l):
    global l1111l
    l1lll1 = ord (l1l1l [-1])
    l1l11 = l1l1l [:-1]
    l11ll = l1lll1 % len (l1l11)
    l1l1 = l1l11 [:l11ll] + l1l11 [l11ll:]
    if l1ll:
        l111l1 = l111 () .join ([unichr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11lll - (l11l1l + l1lll1) % l111ll) for l11l1l, char in enumerate (l1l1)])
    return eval (l111l1)
l1l1l111 = [l11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]