#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll = sys.version_info [0] == 2
l1l111 = 2048
l111 = 7
def l11 (l11l1):
    global l1111l
    l11l = ord (l11l1 [-1])
    l111ll = l11l1 [:-1]
    l1l11 = l11l % len (l111ll)
    l1l1l1 = l111ll [:l1l11] + l111ll [l1l11:]
    if l1lll:
        l1 = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l111 - (l1l11l + l11l) % l111) for l1l11l, char in enumerate (l1l1l1)])
    return eval (l1)
l1l1l111 = [l11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]