#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l11 = 2048
l1l1 = 7
def l11l1l (l1l1ll):
    global l1lll
    l11 = ord (l1l1ll [-1])
    l1 = l1l1ll [:-1]
    l11l1 = l11 % len (l1)
    l1ll = l1 [:l11l1] + l1 [l11l1:]
    if l1111:
        ll = l1l () .join ([unichr (ord (char) - l1l11 - (l1l1l + l11) % l1l1) for l1l1l, char in enumerate (l1ll)])
    else:
        ll = str () .join ([chr (ord (char) - l1l11 - (l1l1l + l11) % l1l1) for l1l1l, char in enumerate (l1ll)])
    return eval (ll)
l1l1l111 = [l11l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]