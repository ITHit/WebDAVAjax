#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll1 = 7
def l1llll (l11ll1):
    global ll
    l1l11l = ord (l11ll1 [-1])
    l1l1ll = l11ll1 [:-1]
    l11 = l1l11l % len (l1l1ll)
    l1 = l1l1ll [:l11] + l1l1ll [l11:]
    if l11l11:
        l111ll = l11l1 () .join ([unichr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    else:
        l111ll = str () .join ([chr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    return eval (l111ll)
l1l1l111 = [l1llll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1llll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1llll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1llll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1llll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1llll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1llll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1llll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1llll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]