#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l11ll = 2048
l111 = 7
def l1111l (l1l1):
    global l11l
    l1ll1l = ord (l1l1 [-1])
    l1l11 = l1l1 [:-1]
    l1lll1 = l1ll1l % len (l1l11)
    l111ll = l1l11 [:l1lll1] + l1l11 [l1lll1:]
    if l1l:
        l11l11 = l11ll1 () .join ([unichr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    else:
        l11l11 = str () .join ([chr (ord (char) - l11ll - (l1l11l + l1ll1l) % l111) for l1l11l, char in enumerate (l111ll)])
    return eval (l11l11)
l1l1l111 = [l1111l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1111l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1111l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1111l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1111l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1111l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1111l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1111l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1111l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]