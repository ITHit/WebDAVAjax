#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1lll = 7
def l1l1 (l1lll1):
    global l1l1l
    l111ll = ord (l1lll1 [-1])
    l11l = l1lll1 [:-1]
    l111 = l111ll % len (l11l)
    l1l11l = l11l [:l111] + l11l [l111:]
    if l1llll:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    return eval (l1ll1l)
l1l1l111 = [l1l1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]