#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1l11l = 2048
l1lll = 7
def l11ll (l1111):
    global l1l11
    l111 = ord (l1111 [-1])
    l1ll1 = l1111 [:-1]
    l1llll = l111 % len (l1ll1)
    l11 = l1ll1 [:l1llll] + l1ll1 [l1llll:]
    if l1ll:
        l1 = l11l1l () .join ([unichr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l11l - (l1l1l + l111) % l1lll) for l1l1l, char in enumerate (l11)])
    return eval (l1)
l1l1l111 = [l11ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]