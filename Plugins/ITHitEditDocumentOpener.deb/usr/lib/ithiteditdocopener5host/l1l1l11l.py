#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1l = 7
def l1ll (l1):
    global l111l1
    l1l = ord (l1 [-1])
    ll = l1 [:-1]
    l111l = l1l % len (ll)
    l11ll = ll [:l111l] + ll [l111l:]
    if l1ll1:
        l1ll11 = l1l111 () .join ([unichr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l - (l1l1l1 + l1l) % l1ll1l) for l1l1l1, char in enumerate (l11ll)])
    return eval (l1ll11)
l1l1l111 = [l1ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]