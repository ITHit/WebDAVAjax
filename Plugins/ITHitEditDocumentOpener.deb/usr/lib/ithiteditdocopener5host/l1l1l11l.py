#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l11lll = 2048
l1l1 = 7
def l11 (l1l11):
    global l1l11l
    l1111 = ord (l1l11 [-1])
    l1ll1 = l1l11 [:-1]
    l1ll = l1111 % len (l1ll1)
    l1llll = l1ll1 [:l1ll] + l1ll1 [l1ll:]
    if l11ll1:
        l1 = l11l1 () .join ([unichr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    else:
        l1 = str () .join ([chr (ord (char) - l11lll - (l1lll + l1111) % l1l1) for l1lll, char in enumerate (l1llll)])
    return eval (l1)
l1l1l111 = [l11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]