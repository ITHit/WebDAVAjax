#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1ll11 = 2048
l1l1ll = 7
def l11l (ll):
    global l111l1
    l1l11 = ord (ll [-1])
    l11ll1 = ll [:-1]
    l11ll = l1l11 % len (l11ll1)
    l1ll1 = l11ll1 [:l11ll] + l11ll1 [l11ll:]
    if l111ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll11 - (l1llll + l1l11) % l1l1ll) for l1llll, char in enumerate (l1ll1)])
    return eval (l1l1l1)
l1l1l111 = [l11l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]