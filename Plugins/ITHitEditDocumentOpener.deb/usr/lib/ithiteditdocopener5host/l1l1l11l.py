#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111ll = 2048
l11lll = 7
def l1ll1l (l11ll):
    global l1
    l11 = ord (l11ll [-1])
    l11ll1 = l11ll [:-1]
    l1ll11 = l11 % len (l11ll1)
    l1111 = l11ll1 [:l1ll11] + l11ll1 [l1ll11:]
    if l1l1l:
        l111 = l111l () .join ([unichr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    else:
        l111 = str () .join ([chr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    return eval (l111)
l1l1l111 = [l1ll1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]