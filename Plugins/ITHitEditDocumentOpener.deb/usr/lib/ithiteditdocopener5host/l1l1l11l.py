#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111l1 = 2048
l1l111 = 7
def l1l11l (l1ll1l):
    global l1
    l11lll = ord (l1ll1l [-1])
    l1lll = l1ll1l [:-1]
    l111l = l11lll % len (l1lll)
    l1llll = l1lll [:l111l] + l1lll [l111l:]
    if l1l1l:
        l1111l = l1l1l1 () .join ([unichr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111l1 - (l111 + l11lll) % l1l111) for l111, char in enumerate (l1llll)])
    return eval (l1111l)
l1l1l111 = [l1l11l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l11l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l11l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l11l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l11l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l11l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l11l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l11l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l11l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]