#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l11l1l = 7
def l11ll (l1ll1):
    global l1l1l
    l1l11 = ord (l1ll1 [-1])
    l11l11 = l1ll1 [:-1]
    l1l111 = l1l11 % len (l11l11)
    l1ll1l = l11l11 [:l1l111] + l11l11 [l1l111:]
    if l1ll11:
        l1 = l11lll () .join ([unichr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    else:
        l1 = str () .join ([chr (ord (char) - l1l1 - (l111l + l1l11) % l11l1l) for l111l, char in enumerate (l1ll1l)])
    return eval (l1)
l1l1l111 = [l11ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]