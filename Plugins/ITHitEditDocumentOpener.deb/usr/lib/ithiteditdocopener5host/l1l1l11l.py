#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l11l1 = 2048
l1l1l1 = 7
def l11l (ll):
    global l1ll1
    l11l1l = ord (ll [-1])
    l11ll1 = ll [:-1]
    l1l11 = l11l1l % len (l11ll1)
    l11ll = l11ll1 [:l1l11] + l11ll1 [l1l11:]
    if l1l111:
        l111 = l1ll11 () .join ([unichr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    return eval (l111)
l1l1l111 = [l11l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]