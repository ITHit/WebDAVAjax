#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l111l = 2048
l1l = 7
def l11ll (l1111):
    global l11
    l111l1 = ord (l1111 [-1])
    l1l1ll = l1111 [:-1]
    l1l1 = l111l1 % len (l1l1ll)
    l111 = l1l1ll [:l1l1] + l1l1ll [l1l1:]
    if l1111l:
        l1l11l = l1 () .join ([unichr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    return eval (l1l11l)
l1l1l111 = [l11ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]