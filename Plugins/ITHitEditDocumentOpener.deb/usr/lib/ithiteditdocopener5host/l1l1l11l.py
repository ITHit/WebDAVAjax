#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll1 = 7
def l11l (l1l11l):
    global ll
    l1llll = ord (l1l11l [-1])
    l11l1 = l1l11l [:-1]
    l1l1 = l1llll % len (l11l1)
    l1lll = l11l1 [:l1l1] + l11l1 [l1l1:]
    if l1:
        l1l111 = l11lll () .join ([unichr (ord (char) - l1l1ll - (l1ll + l1llll) % l1ll1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1ll - (l1ll + l1llll) % l1ll1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l111)
l1l1l111 = [l11l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]