#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l1l1ll = 2048
l1111 = 7
def l11l (l111ll):
    global l1l111
    l111l1 = ord (l111ll [-1])
    l1111l = l111ll [:-1]
    l11 = l111l1 % len (l1111l)
    l1ll1l = l1111l [:l11] + l1111l [l11:]
    if ll:
        l1l1l1 = l11l1 () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    return eval (l1l1l1)
l1l1l111 = [l11l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]