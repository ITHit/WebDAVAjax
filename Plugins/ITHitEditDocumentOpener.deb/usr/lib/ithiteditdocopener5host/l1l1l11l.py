#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l11l1):
    global l11l11
    l1l1ll = ord (l11l1 [-1])
    l11l = l11l1 [:-1]
    l1l11 = l1l1ll % len (l11l)
    l1l11l = l11l [:l1l11] + l11l [l1l11:]
    if l1l:
        l1111 = l111ll () .join ([unichr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    else:
        l1111 = str () .join ([chr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    return eval (l1111)
l1l1l111 = [l11l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]