#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll = sys.version_info [0] == 2
l11l1l = 2048
l1lll = 7
def l11l11 (l11lll):
    global l11ll1
    l1ll1l = ord (l11lll [-1])
    l1l11 = l11lll [:-1]
    l1111 = l1ll1l % len (l1l11)
    l11 = l1l11 [:l1111] + l1l11 [l1111:]
    if l1l1ll:
        l111l = l1l () .join ([unichr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1ll11 + l1ll1l) % l1lll) for l1ll11, char in enumerate (l11)])
    return eval (l111l)
l1l1l111 = [l11l11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11l11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11l11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11l11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11l11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11l11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11l11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11l11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11l11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]