#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1 = sys.version_info [0] == 2
l111ll = 2048
l1l1l = 7
def l1ll11 (l1l1ll):
    global l11l1l
    l111l = ord (l1l1ll [-1])
    l11l11 = l1l1ll [:-1]
    l1l = l111l % len (l11l11)
    l1llll = l11l11 [:l1l] + l11l11 [l1l:]
    if l1lll1:
        l1111l = l1l11l () .join ([unichr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    else:
        l1111l = str () .join ([chr (ord (char) - l111ll - (l111l1 + l111l) % l1l1l) for l111l1, char in enumerate (l1llll)])
    return eval (l1111l)
l1l1l111 = [l1ll11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]