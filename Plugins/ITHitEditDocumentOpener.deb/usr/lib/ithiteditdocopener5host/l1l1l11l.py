#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1ll = 2048
l1111 = 7
def l1ll1 (l1ll1l):
    global l111ll
    l11ll = ord (l1ll1l [-1])
    l111 = l1ll1l [:-1]
    l111l1 = l11ll % len (l111)
    ll = l111 [:l111l1] + l111 [l111l1:]
    if l111l:
        l1l = l1l111 () .join ([unichr (ord (char) - l1ll - (l1l1l1 + l11ll) % l1111) for l1l1l1, char in enumerate (ll)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l1l1l1 + l11ll) % l1111) for l1l1l1, char in enumerate (ll)])
    return eval (l1l)
l1l1l111 = [l1ll1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]