#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1l = 2048
l1111 = 7
def l1ll (l11l):
    global l1ll1l
    l1lll1 = ord (l11l [-1])
    l1lll = l11l [:-1]
    ll = l1lll1 % len (l1lll)
    l1ll1 = l1lll [:ll] + l1lll [ll:]
    if l11l1:
        l1llll = l1l1 () .join ([unichr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    return eval (l1llll)
l1l1l111 = [l1ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]