#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1lll1 = 2048
l111l = 7
def l1l1 (l1ll11):
    global l1
    l1l1l = ord (l1ll11 [-1])
    l11ll1 = l1ll11 [:-1]
    l11l11 = l1l1l % len (l11ll1)
    l1l11l = l11ll1 [:l11l11] + l11ll1 [l11l11:]
    if l1ll1:
        l1llll = l1l111 () .join ([unichr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1lll1 - (l111l1 + l1l1l) % l111l) for l111l1, char in enumerate (l1l11l)])
    return eval (l1llll)
l1l1l111 = [l1l1 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]