#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1ll = 2048
l111l = 7
def l1l1l (ll):
    global l11ll
    l1111 = ord (ll [-1])
    l1lll = ll [:-1]
    l1ll1l = l1111 % len (l1lll)
    l1l11 = l1lll [:l1ll1l] + l1lll [l1ll1l:]
    if l1l1l1:
        l1l = l111ll () .join ([unichr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l11l1 + l1111) % l111l) for l11l1, char in enumerate (l1l11)])
    return eval (l1l)
l1l1l111 = [l1l1l (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1l1l (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1l1l (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1l1l (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1l1l (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1l1l (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1l1l (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1l1l (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1l1l (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]