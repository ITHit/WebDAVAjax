#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11ll = 2048
l1llll = 7
def l1ll11 (l1l1):
    global l1ll1
    l11l1 = ord (l1l1 [-1])
    l1l = l1l1 [:-1]
    l111 = l11l1 % len (l1l)
    l11lll = l1l [:l111] + l1l [l111:]
    if l111l:
        l1l111 = l11l11 () .join ([unichr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    return eval (l1l111)
l1l1l111 = [l1ll11 (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l1ll11 (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l1ll11 (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l1ll11 (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l1ll11 (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l1ll11 (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l1ll11 (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l1ll11 (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l1ll11 (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]