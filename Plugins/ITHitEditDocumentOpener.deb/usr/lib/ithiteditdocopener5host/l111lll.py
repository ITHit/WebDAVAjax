#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111ll (l1l1l):
    global l11ll
    l1111l = ord (l1l1l [-1])
    l11l = l1l1l [:-1]
    l11l1l = l1111l % len (l11l)
    l1l11l = l11l [:l11l1l] + l11l [l11l1l:]
    if l1ll11:
        l1ll1l = l1l1l1 () .join ([unichr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import l111l1
from l1l1l111 import l1l1l11l
import objc as _111l111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l111.l1111l1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l111lll1(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111ll (u"ࠨࠩࢬ"), {l111ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111ll1l(l111ll11):
    l111ll11 = (l111ll11 + l111ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l111ll11, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _111l111.nil )
    l111l1ll = LaunchServices.l11111ll( l1111111, LaunchServices.l111l11l, _111l111.nil )
    if l111l1ll[0] is not None:
        return True
    return False
def l11lll():
    l111111l = []
    for name in l1l1l11l:
        try:
            if l111ll1l(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l1l1ll(l1l11, l11l1):
    import plistlib
    import os
    l1 = []
    l1ll1 = {}
    for l111l1l1 in os.listdir(l111ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l11l1):
            try:
                l1111ll1 = l111ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l1111ll1, l111ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1lll1 = plist[l111ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l111ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l11 == l1111l11:
                        if not l1lll1 in l1ll1:
                            l1ll1[l1lll1] = version
                        elif l111l1.l1ll(version, l1ll1[l1lll1]) > 0:
                            l1ll1[l1lll1] = version
            except BaseException:
                continue
    for l1lll1 in l1ll1:
        l1.append({l111ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1[l1lll1], l111ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1lll1})
    return l1