#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11l1 = 2048
l11 = 7
def l1lll1 (l1111l):
    global l1ll1
    l1llll = ord (l1111l [-1])
    l1lll = l1111l [:-1]
    l1l1 = l1llll % len (l1lll)
    l11l11 = l1lll [:l1l1] + l1lll [l1l1:]
    if l111l:
        l111ll = l11lll () .join ([unichr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l1 - (l11l1l + l1llll) % l11) for l11l1l, char in enumerate (l11l11)])
    return eval (l111ll)
import subprocess, threading
from ll import l11ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l1l1():
    l11ll111 = [l1lll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1lll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1lll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1lll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11ll111:
        try:
            l1l1111l = l1lll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll1l1 = winreg.l1l11l11(winreg.l11l1lll, l1l1111l)
        except l11l111l:
            continue
        value = winreg.l11lll1l(l11ll1l1, l1lll1 (u"ࠦࠧ࢓"))
        return value.split(l1lll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1lllll():
    l11l1l11 = []
    for name in l1l1l11l:
        try:
            l1l1111l = l1lll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lllll = winreg.l1l11l11(winreg.l11l1lll, l1l1111l)
            if winreg.l11lll1l(l11lllll, l1lll1 (u"ࠢࠣ࢖")):
                l11l1l11.append(name)
        except l11l111l:
            continue
    return l11l1l11
def l11111l(l11l, l1):
    import re
    l1l111 = []
    l11l1ll1 = winreg.l1l11l11(winreg.l11l1lll, l1lll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l1l(l11l1ll1)[0]):
        try:
            l1l11ll1 = winreg.l1l11111(l11l1ll1, i)
            if l1l11ll1.startswith(l1):
                l11ll11l = winreg.l1l11lll(l11l1ll1, l1l11ll1)
                value, l11lll11 = winreg.l11l1l1l(l11ll11l, l1lll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1lll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11llll1 = {l1lll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l111l1 = m.group(2)
                    if l11l == l1l111l1:
                        m = re.search(l1.replace(l1lll1 (u"ࠬ࠴࢛ࠧ"), l1lll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1lll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11ll1)
                        l11llll1[l1lll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l111.append(l11llll1)
                else:
                    raise ValueError(l1lll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l1l111
def l11ll1ll(l1l11):
    try:
        l11l11ll = l1lll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11)
        l11l1111 = winreg.l1l11l11(winreg.l11l1lll, l11l11ll)
        value, l11lll11 = winreg.l11l1l1l(l11l1111, l1lll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1lll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l1lll1 (u"࠭ࠧࢣ")
def l11l111(l1l11, url):
    threading.Thread(target=_1l111ll,args=(l1l11, url)).start()
    return l1lll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l111ll(l1l11, url):
    logger = l11ll()
    l11l11l1 = l11ll1ll(l1l11)
    logger.debug(l1lll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l11l1, url))
    retcode = subprocess.Popen(l1lll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l11l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1lll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1lll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)