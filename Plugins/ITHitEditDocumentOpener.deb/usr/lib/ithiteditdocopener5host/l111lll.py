#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1ll11 = 2048
l1111 = 7
def l1l (l1l1):
    global l11l1l
    l11ll = ord (l1l1 [-1])
    l1lll1 = l1l1 [:-1]
    l1111l = l11ll % len (l1lll1)
    l1l11l = l1lll1 [:l1111l] + l1lll1 [l1111l:]
    if l1l1l:
        l1lll = l1llll () .join ([unichr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1ll11 - (l1ll1 + l11ll) % l1111) for l1ll1, char in enumerate (l1l11l)])
    return eval (l1lll)
import subprocess, threading
from l111ll import l111l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l1ll():
    l1l11ll1 = [l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11ll1:
        try:
            l1l111ll = l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11111 = winreg.l1l11lll(winreg.l11lll1l, l1l111ll)
        except l11l1111:
            continue
        value = winreg.l11lll11(l1l11111, l1l (u"ࠦࠧ࢓"))
        return value.split(l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111ll1():
    l11lllll = []
    for name in l1l1l11l:
        try:
            l1l111ll = l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111l1 = winreg.l1l11lll(winreg.l11lll1l, l1l111ll)
            if winreg.l11lll11(l1l111l1, l1l (u"ࠢࠣ࢖")):
                l11lllll.append(name)
        except l11l1111:
            continue
    return l11lllll
def l111l1l(l1l111, l11l11):
    import re
    l111l = []
    l11l1ll1 = winreg.l1l11lll(winreg.l11lll1l, l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11ll111(l11l1ll1)[0]):
        try:
            l11llll1 = winreg.l1l11l1l(l11l1ll1, i)
            if l11llll1.startswith(l11l11):
                l11ll11l = winreg.l11ll1l1(l11l1ll1, l11llll1)
                value, l11l11ll = winreg.l11ll1ll(l11ll11l, l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11l1 = {l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11l11 = m.group(2)
                    if l1l111 == l1l11l11:
                        m = re.search(l11l11.replace(l1l (u"ࠬ࠴࢛ࠧ"), l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11llll1)
                        l11l11l1[l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111l.append(l11l11l1)
                else:
                    raise ValueError(l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1111 as ex:
            continue
    return l111l
def l11l1l11(l11ll1):
    try:
        l1l1111l = l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11ll1)
        l11l1lll = winreg.l1l11lll(winreg.l11lll1l, l1l1111l)
        value, l11l11ll = winreg.l11ll1ll(l11l1lll, l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1111:
        pass
    return l1l (u"࠭ࠧࢣ")
def l11lll1(l11ll1, url):
    threading.Thread(target=_11l1l1l,args=(l11ll1, url)).start()
    return l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1l1l(l11ll1, url):
    logger = l111l1()
    l11l111l = l11l1l11(l11ll1)
    logger.debug(l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l111l, url))
    retcode = subprocess.Popen(l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l111l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)