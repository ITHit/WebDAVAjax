#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l11l1 = 2048
l1 = 7
def l1ll1 (l11l11):
    global l1l1ll
    l111l = ord (l11l11 [-1])
    l1l = l11l11 [:-1]
    l1llll = l111l % len (l1l)
    l1lll = l1l [:l1llll] + l1l [l1llll:]
    if ll:
        l1l1l1 = l1111 () .join ([unichr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l11l1 - (l1ll + l111l) % l1) for l1ll, char in enumerate (l1lll)])
    return eval (l1l1l1)
import l1111l
from l1l1l11l import l1l1l111
import objc as _111ll1l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll1l.l11111ll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll11.l111l11l(l11111l1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l11111l1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll1 (u"ࠨࠩࢬ"), {l1ll1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111111l):
    l111111l = (l111111l + l1ll1 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l11 = CFStringCreateWithCString( kCFAllocatorDefault, l111111l, kCFStringEncodingUTF8 )
    l111llll = CFURLCreateWithString( kCFAllocatorDefault, l1111l11, _111ll1l.nil )
    l1111l1l = LaunchServices.l1111ll1( l111llll, LaunchServices.l1111lll, _111ll1l.nil )
    if l1111l1l[0] is not None:
        return True
    return False
def l1lll1():
    l111l1ll = []
    for name in l1l1l111:
        try:
            if l1111111(name):
                l111l1ll.append(name)
        except:
            continue
    return l111l1ll
def l1ll11(l111ll, l11ll):
    import plistlib
    import os
    l11l1l = []
    l11l = {}
    for l111l111 in os.listdir(l1ll1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l111.startswith(l11ll):
            try:
                l111lll1 = l1ll1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l111
                with open(l111lll1, l1ll1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1 = plist[l1ll1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1l1 = version.split(l1ll1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111ll == l111l1l1:
                        if not l1l1 in l11l:
                            l11l[l1l1] = version
                        elif l1111l.l11(version, l11l[l1l1]) > 0:
                            l11l[l1l1] = version
            except BaseException:
                continue
    for l1l1 in l11l:
        l11l1l.append({l1ll1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l[l1l1], l1ll1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1})
    return l11l1l