#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll1 = 7
def l1llll (l11ll1):
    global ll
    l1l11l = ord (l11ll1 [-1])
    l1l1ll = l11ll1 [:-1]
    l11 = l1l11l % len (l1l1ll)
    l1 = l1l1ll [:l11] + l1l1ll [l11:]
    if l11l11:
        l111ll = l11l1 () .join ([unichr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    else:
        l111ll = str () .join ([chr (ord (char) - l1ll11 - (l1l1 + l1l11l) % l1ll1) for l1l1, char in enumerate (l1)])
    return eval (l111ll)
import l1111l
from l1l1l11l import l1l1l111
import objc as _1111111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111111.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1llll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l1l1.l111l1ll(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1llll (u"ࠨࠩࢬ"), {l1llll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1llll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1llll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1llll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1llll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1llll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1llll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l1111ll1):
    l1111ll1 = (l1111ll1 + l1llll (u"ࠩ࠽ࠫࢴ")).encode()
    l111l111 = CFStringCreateWithCString( kCFAllocatorDefault, l1111ll1, kCFStringEncodingUTF8 )
    l111llll = CFURLCreateWithString( kCFAllocatorDefault, l111l111, _1111111.nil )
    l11111ll = LaunchServices.l111ll1l( l111llll, LaunchServices.l11111l1, _1111111.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l11lll():
    l111111l = []
    for name in l1l1l111:
        try:
            if l1111l1l(name):
                l111111l.append(name)
        except:
            continue
    return l111111l
def l1l1l1(l111, l1l1l):
    import plistlib
    import os
    l1l11 = []
    l1lll = {}
    for l111ll11 in os.listdir(l1llll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll11.startswith(l1l1l):
            try:
                l111l11l = l1llll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll11
                with open(l111l11l, l1llll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l = plist[l1llll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1llll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1llll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l11 = version.split(l1llll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111 == l1111l11:
                        if not l11l in l1lll:
                            l1lll[l11l] = version
                        elif l1111l.l11l1l(version, l1lll[l11l]) > 0:
                            l1lll[l11l] = version
            except BaseException:
                continue
    for l11l in l1lll:
        l1l11.append({l1llll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll[l11l], l1llll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l})
    return l1l11