#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111ll = 2048
l11lll = 7
def l1ll1l (l11ll):
    global l1
    l11 = ord (l11ll [-1])
    l11ll1 = l11ll [:-1]
    l1ll11 = l11 % len (l11ll1)
    l1111 = l11ll1 [:l1ll11] + l11ll1 [l1ll11:]
    if l1l1l:
        l111 = l111l () .join ([unichr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    else:
        l111 = str () .join ([chr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    return eval (l111)
import subprocess, threading
from l1llll import l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1ll111():
    l11lllll = [l1ll1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lllll:
        try:
            l11l1l1l = l1ll1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll1l = winreg.l11l11l1(winreg.l1l11l11, l11l1l1l)
        except l11l1111:
            continue
        value = winreg.l11l11ll(l11lll1l, l1ll1l (u"ࠦࠧ࢓"))
        return value.split(l1ll1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11ll1l():
    l11ll11l = []
    for name in l1l1l111:
        try:
            l11l1l1l = l1ll1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1lll = winreg.l11l11l1(winreg.l1l11l11, l11l1l1l)
            if winreg.l11l11ll(l11l1lll, l1ll1l (u"ࠢࠣ࢖")):
                l11ll11l.append(name)
        except l11l1111:
            continue
    return l11ll11l
def l1ll11l(l1111l, l1ll1):
    import re
    l1l11 = []
    l11l111l = winreg.l11l11l1(winreg.l1l11l11, l1ll1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l111l1(l11l111l)[0]):
        try:
            l1l11l1l = winreg.l11llll1(l11l111l, i)
            if l1l11l1l.startswith(l1ll1):
                l11ll1ll = winreg.l11ll111(l11l111l, l1l11l1l)
                value, l1l11111 = winreg.l1l1111l(l11ll1ll, l1ll1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111ll = {l1ll1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1ll1 = m.group(2)
                    if l1111l == l11l1ll1:
                        m = re.search(l1ll1.replace(l1ll1l (u"ࠬ࠴࢛ࠧ"), l1ll1l (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11l1l)
                        l1l111ll[l1ll1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l11.append(l1l111ll)
                else:
                    raise ValueError(l1ll1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1111 as ex:
            continue
    return l1l11
def l11ll1l1(l11l1l):
    try:
        l11lll11 = l1ll1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1l)
        l1l11lll = winreg.l11l11l1(winreg.l1l11l11, l11lll11)
        value, l1l11111 = winreg.l1l1111l(l1l11lll, l1ll1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l1111:
        pass
    return l1ll1l (u"࠭ࠧࢣ")
def l11111l(l11l1l, url):
    threading.Thread(target=_11l1l11,args=(l11l1l, url)).start()
    return l1ll1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1l11(l11l1l, url):
    logger = l11l()
    l1l11ll1 = l11ll1l1(l11l1l)
    logger.debug(l1ll1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11ll1, url))
    retcode = subprocess.Popen(l1ll1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11ll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)