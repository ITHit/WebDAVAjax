#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l111l (l11):
    global l1lll
    l11l = ord (l11 [-1])
    l11ll1 = l11 [:-1]
    l1l1 = l11l % len (l11ll1)
    l1lll1 = l11ll1 [:l1l1] + l11ll1 [l1l1:]
    if l1ll1l:
        l111l1 = l1ll () .join ([unichr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    return eval (l111l1)
import l1l11
from l1l1l111 import l1l1l11l
import objc as _111llll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111llll.l1111111( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l111l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll11.l111l1ll(l111ll1l (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll1l (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l111l (u"ࠨࠩࢬ"), {l111l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l111l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l111l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l111l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l111l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l111l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l111l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111lll(l111111l):
    l111111l = (l111111l + l111l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111l1l = CFStringCreateWithCString( kCFAllocatorDefault, l111111l, kCFStringEncodingUTF8 )
    l111lll1 = CFURLCreateWithString( kCFAllocatorDefault, l1111l1l, _111llll.nil )
    l11111ll = LaunchServices.l11111l1( l111lll1, LaunchServices.l1111l11, _111llll.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l11l1():
    l111l1l1 = []
    for name in l1l1l11l:
        try:
            if l1111lll(name):
                l111l1l1.append(name)
        except:
            continue
    return l111l1l1
def l1111l(l11ll, l111ll):
    import plistlib
    import os
    l1 = []
    l1111 = {}
    for l111l11l in os.listdir(l111l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l11l.startswith(l111ll):
            try:
                l111l111 = l111l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l11l
                with open(l111l111, l111l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1l1l = plist[l111l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l111l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l111l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111ll1 = version.split(l111l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11ll == l1111ll1:
                        if not l1l1l in l1111:
                            l1111[l1l1l] = version
                        elif l1l11.l1l11l(version, l1111[l1l1l]) > 0:
                            l1111[l1l1l] = version
            except BaseException:
                continue
    for l1l1l in l1111:
        l1.append({l111l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111[l1l1l], l111l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1l1l})
    return l1