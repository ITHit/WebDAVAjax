#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1l1ll (l1l11):
    global l11ll1
    l1ll11 = ord (l1l11 [-1])
    l111ll = l1l11 [:-1]
    l1lll = l1ll11 % len (l111ll)
    l1ll1l = l111ll [:l1lll] + l111ll [l1lll:]
    if l1llll:
        l1lll1 = l11l1l () .join ([unichr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    return eval (l1lll1)
import l1
from l1l1l111 import l1l1l11l
import objc as _1111l11
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111l11.l111ll1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111ll.l111111l(l111l111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1ll (u"ࠨࠩࢬ"), {l1l1ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111l11l(l111l1ll):
    l111l1ll = (l111l1ll + l1l1ll (u"ࠩ࠽ࠫࢴ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l111l1ll, kCFStringEncodingUTF8 )
    l1111ll1 = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _1111l11.nil )
    l1111lll = LaunchServices.l111ll11( l1111ll1, LaunchServices.l1111111, _1111l11.nil )
    if l1111lll[0] is not None:
        return True
    return False
def l11ll():
    l111l1l1 = []
    for name in l1l1l11l:
        try:
            if l111l11l(name):
                l111l1l1.append(name)
        except:
            continue
    return l111l1l1
def l1ll1(l11l11, l1l1l1):
    import plistlib
    import os
    l1l1l = []
    l111l = {}
    for l111lll1 in os.listdir(l1l1ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111lll1.startswith(l1l1l1):
            try:
                l11111l1 = l1l1ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111lll1
                with open(l11111l1, l1l1ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1ll = plist[l1l1ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l1l = version.split(l1l1ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11l11 == l1111l1l:
                        if not l1ll in l111l:
                            l111l[l1ll] = version
                        elif l1.l1l11l(version, l111l[l1ll]) > 0:
                            l111l[l1ll] = version
            except BaseException:
                continue
    for l1ll in l111l:
        l1l1l.append({l1l1ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l111l[l1ll], l1l1ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1ll})
    return l1l1l