#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1l11 = 2048
l11l1 = 7
def l1llll (l1l1ll):
    global l111
    l11lll = ord (l1l1ll [-1])
    l1111l = l1l1ll [:-1]
    l1 = l11lll % len (l1111l)
    l1lll = l1111l [:l1] + l1111l [l1:]
    if l111l1:
        l1l1l = l111ll () .join ([unichr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1l11 - (l1ll11 + l11lll) % l11l1) for l1ll11, char in enumerate (l1lll)])
    return eval (l1l1l)
import subprocess, threading
from l1ll import l11
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l1l11ll():
    l11l1111 = [l1llll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1llll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1llll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1llll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1111:
        try:
            l1l1111l = l1llll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lllll = winreg.l1l11l1l(winreg.l11ll1l1, l1l1111l)
        except l11l11ll:
            continue
        value = winreg.l1l11lll(l11lllll, l1llll (u"ࠦࠧ࢓"))
        return value.split(l1llll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11l111():
    l1l111l1 = []
    for name in l1l1l11l:
        try:
            l1l1111l = l1llll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lll11 = winreg.l1l11l1l(winreg.l11ll1l1, l1l1111l)
            if winreg.l1l11lll(l11lll11, l1llll (u"ࠢࠣ࢖")):
                l1l111l1.append(name)
        except l11l11ll:
            continue
    return l1l111l1
def l111lll(l11l11, l11ll):
    import re
    l1l1 = []
    l11l111l = winreg.l1l11l1l(winreg.l11ll1l1, l1llll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11llll1(l11l111l)[0]):
        try:
            l1l11111 = winreg.l11ll111(l11l111l, i)
            if l1l11111.startswith(l11ll):
                l1l11ll1 = winreg.l11ll11l(l11l111l, l1l11111)
                value, l11l11l1 = winreg.l11lll1l(l1l11ll1, l1llll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1llll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1ll1 = {l1llll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1l1l = m.group(2)
                    if l11l11 == l11l1l1l:
                        m = re.search(l11ll.replace(l1llll (u"ࠬ࠴࢛ࠧ"), l1llll (u"࠭࡜࡝࠰ࠪ࢜")) + l1llll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11111)
                        l11l1ll1[l1llll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1.append(l11l1ll1)
                else:
                    raise ValueError(l1llll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l11ll as ex:
            continue
    return l1l1
def l1l11l11(l1ll1l):
    try:
        l11l1l11 = l1llll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1ll1l)
        l11ll1ll = winreg.l1l11l1l(winreg.l11ll1l1, l11l1l11)
        value, l11l11l1 = winreg.l11lll1l(l11ll1ll, l1llll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1llll (u"ࠬࠨࠧࢢ"))[1]
    except l11l11ll:
        pass
    return l1llll (u"࠭ࠧࢣ")
def l1l1ll1(l1ll1l, url):
    threading.Thread(target=_1l111ll,args=(l1ll1l, url)).start()
    return l1llll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l111ll(l1ll1l, url):
    logger = l11()
    l11l1lll = l1l11l11(l1ll1l)
    logger.debug(l1llll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11l1lll, url))
    retcode = subprocess.Popen(l1llll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11l1lll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1llll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1llll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)