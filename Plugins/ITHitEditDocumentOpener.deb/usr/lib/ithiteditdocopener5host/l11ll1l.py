#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l11ll = 2048
l1llll = 7
def l1ll11 (l1l1):
    global l1ll1
    l11l1 = ord (l1l1 [-1])
    l1l = l1l1 [:-1]
    l111 = l11l1 % len (l1l)
    l11lll = l1l [:l111] + l1l [l111:]
    if l111l:
        l1l111 = l11l11 () .join ([unichr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l11ll - (l111ll + l11l1) % l1llll) for l111ll, char in enumerate (l11lll)])
    return eval (l1l111)
import subprocess, threading
from l1111l import l1111
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11111():
    l11l11ll = [l1ll11 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll11 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll11 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll11 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l11ll:
        try:
            l1l1111l = l1ll11 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11l1l = winreg.l11l11l1(winreg.l11l1ll1, l1l1111l)
        except l1l11l11:
            continue
        value = winreg.l11ll1l1(l1l11l1l, l1ll11 (u"ࠦࠧ࢓"))
        return value.split(l1ll11 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l111lll():
    l11lllll = []
    for name in l1l1l111:
        try:
            l1l1111l = l1ll11 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11111 = winreg.l11l11l1(winreg.l11l1ll1, l1l1111l)
            if winreg.l11ll1l1(l1l11111, l1ll11 (u"ࠢࠣ࢖")):
                l11lllll.append(name)
        except l1l11l11:
            continue
    return l11lllll
def l111l1l(l1lll1, l1l1l1):
    import re
    l1l1ll = []
    l1l11lll = winreg.l11l11l1(winreg.l11l1ll1, l1ll11 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l111l(l1l11lll)[0]):
        try:
            l11l1lll = winreg.l11lll11(l1l11lll, i)
            if l11l1lll.startswith(l1l1l1):
                l11ll1ll = winreg.l11l1l11(l1l11lll, l11l1lll)
                value, l11lll1l = winreg.l11ll11l(l11ll1ll, l1ll11 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll11 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll111 = {l1ll11 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1l1l = m.group(2)
                    if l1lll1 == l11l1l1l:
                        m = re.search(l1l1l1.replace(l1ll11 (u"ࠬ࠴࢛ࠧ"), l1ll11 (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll11 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1lll)
                        l11ll111[l1ll11 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1ll.append(l11ll111)
                else:
                    raise ValueError(l1ll11 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11l11 as ex:
            continue
    return l1l1ll
def l1l11ll1(l111l1):
    try:
        l11l1111 = l1ll11 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l111l1)
        l1l111l1 = winreg.l11l11l1(winreg.l11l1ll1, l11l1111)
        value, l11lll1l = winreg.l11ll11l(l1l111l1, l1ll11 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll11 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11l11:
        pass
    return l1ll11 (u"࠭ࠧࢣ")
def l1lll1l(l111l1, url):
    threading.Thread(target=_1l111ll,args=(l111l1, url)).start()
    return l1ll11 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l111ll(l111l1, url):
    logger = l1111()
    l11llll1 = l1l11ll1(l111l1)
    logger.debug(l1ll11 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11llll1, url))
    retcode = subprocess.Popen(l1ll11 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11llll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll11 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll11 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)