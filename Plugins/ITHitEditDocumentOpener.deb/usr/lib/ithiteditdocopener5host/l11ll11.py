#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11l1l = 2048
l11l1 = 7
def l111l1 (l1l11l):
    global l11
    ll = ord (l1l11l [-1])
    l1ll = l1l11l [:-1]
    l1111 = ll % len (l1ll)
    l11ll = l1ll [:l1111] + l1ll [l1111:]
    if l1ll1:
        l11lll = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    return eval (l11lll)
import _winreg
import subprocess, threading
from l111ll import l11l11
from l1l1ll1l import l1l1lll1
def l1l11ll():
    l1l1l111 = [l111l1 (u"ࠢࡆࡺࡦࡩࡱࠨ࢈"), l111l1 (u"࡙ࠣࡲࡶࡩࠨࢉ"), l111l1 (u"ࠤࡓࡳࡼ࡫ࡲࡑࡱ࡬ࡲࡹࠨࢊ"), l111l1 (u"ࠥࡓࡺࡺ࡬ࡰࡱ࡮ࠦࢋ")]
    for part in l1l1l111:
        try:
            l11ll111 = l111l1 (u"ࠦࢀ࠶ࡽ࠯ࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡢ࡜ࡄࡷࡵ࡚ࡪࡸࠢࢌ").format(part)
            l11l1l1l = _winreg.l1l1l11l(_winreg.l1l1111l, l11ll111)
        except l1l11ll1:
            continue
        value = _winreg.l1l1l1l1(l11l1l1l, l111l1 (u"ࠧࠨࢍ"))
        return value.split(l111l1 (u"ࠨ࠮ࠣࢎ"))[-1]
    return None
def l1l11l1():
    l11ll11l = []
    for name in l1l1lll1:
        try:
            l11ll111 = l111l1 (u"ࠢࡼ࠲ࢀࡠࡡࡹࡨࡦ࡮࡯ࡠࡡࡵࡰࡦࡰ࡟ࡠࡨࡵ࡭࡮ࡣࡱࡨࠧ࢏").format(name)
            l1l111l1 = _winreg.l1l1l11l(_winreg.l1l1111l, l11ll111)
            if _winreg.l1l1l1l1(l1l111l1, l111l1 (u"ࠣࠤ࢐")):
                l11ll11l.append(name)
        except l1l11ll1:
            continue
    return l11ll11l
def l1ll1l1(l1l111, l1):
    import re
    l1l = []
    l1l11lll = _winreg.l1l1l11l(_winreg.l1l1111l, l111l1 (u"ࠤࡄࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࡳࠣ࢑"))
    for i in range(0, _winreg.l1l11l11(l1l11lll)[0]):
        try:
            l1l1l1ll = _winreg.l1l11111(l1l11lll, i)
            if l1l1l1ll.startswith(l1):
                l11ll1l1 = _winreg.l1l111ll(l1l11lll, l1l1l1ll)
                value, l11l1lll = _winreg.l11lllll(l11ll1l1, l111l1 (u"ࠪࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡆࡶࡰࡏࡣࡰࡩࠬ࢒"))
                m = re.search(l111l1 (u"ࠫࡻ࠮ࠨ࡜࡞ࡧࡡࢀ࠷ࠬࡾࠫ࡟࠲ࡠࡢࡤ࡞ࡽ࠴࠰ࢂࡢ࠮࡜࡞ࡧࡡࢀ࠷ࠬࡾ࡝࡟࠲ࡠࡢࡤ࡞ࡽ࠴࠰ࢂࡣ࠿ࠪࠩ࢓"), value)
                if m:
                    l11ll1ll = {l111l1 (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭࢔"): m.group(1)}
                    l11l1ll1 = m.group(2)
                    if l1l111 == l11l1ll1:
                        m = re.search(l1.replace(l111l1 (u"࠭࠮ࠨ࢕"), l111l1 (u"ࠧ࡝࡞࠱ࠫ࢖")) + l111l1 (u"ࠨࠪ࡞ࡠࡼࡣࠪࠪ࡞࠱ࡩࡽ࡫ࠧࢗ"), l1l1l1ll)
                        l11ll1ll[l111l1 (u"ࠩࡳࡶࡴࡺ࡯ࡤࡱ࡯ࠫ࢘")] = m.group(1)
                        l1l.append(l11ll1ll)
                else:
                    raise ValueError(l111l1 (u"ࠥࡇࡦࡴࠧࡵࠢࡪࡩࡹࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡧࡴࡲࡱ࠿ࠦࠥࡴ࢙ࠢࠥ") % value)
        except l1l11ll1 as ex:
            continue
    return l1l
def l11lll11(l111l):
    try:
        l11lll1l = l111l1 (u"ࠦࢀ࠶ࡽ࡝࡞ࡶ࡬ࡪࡲ࡬࡝࡞ࡲࡴࡪࡴ࡜࡝ࡥࡲࡱࡲࡧ࡮ࡥࠤ࢚").format(l111l)
        l1l11l1l = _winreg.l1l1l11l(_winreg.l1l1111l, l11lll1l)
        value, l11l1lll = _winreg.l11lllll(l1l11l1l, l111l1 (u"࢛ࠬ࠭"))
        if value:
            return value.split(l111l1 (u"࠭ࠢࠨ࢜"))[1]
    except l1l11ll1:
        pass
    return l111l1 (u"ࠧࠨ࢝")
def l111l1l(l111l, url):
    threading.Thread(target=_1l1ll11,args=(l111l, url)).start()
    return l111l1 (u"ࠣࡕࡸࡧࡨ࡫ࡳࡴࠤ࢞")
def _1l1ll11(l111l, url):
    logger = l11l11()
    l11llll1 = l11lll11(l111l)
    logger.debug(l111l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫ࢟") % (l11llll1, url))
    retcode = subprocess.Popen(l111l1 (u"ࡵࠫࠧࠫࡳࠣࠢࠨࡷࠬࢠ") % (l11llll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l111l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡼࡧࡳࠡࡶࡨࡶࡲ࡯࡮ࡢࡶࡨࡨࠥࡨࡹࠡࡵ࡬࡫ࡳࡧ࡬࠭ࠢࠨࡷࠧࢡ") % retcode)
    else:
        logger.info(l111l1 (u"ࠧࡕࡰࡦࡰࡨࡶࠥࡸࡥࡵࡷࡵࡲࡪࡪࠬࠡࠧࡶࠦࢢ") % retcode)