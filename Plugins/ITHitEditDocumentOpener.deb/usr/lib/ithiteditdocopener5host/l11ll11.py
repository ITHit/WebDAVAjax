#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1ll = 2048
l1l111 = 7
def l1ll (l111l):
    global l111l1
    l11l = ord (l111l [-1])
    l111ll = l111l [:-1]
    l1l11l = l11l % len (l111ll)
    l1111 = l111ll [:l1l11l] + l111ll [l1l11l:]
    if l11l1:
        l1l1 = l1lll () .join ([unichr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    else:
        l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l1l + l11l) % l1l111) for l11l1l, char in enumerate (l1111)])
    return eval (l1l1)
import ll
from l1l1l111 import l1l1l11l
import objc as _111l111
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l111.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l11l.l111111l(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll (u"ࠨࠩࢬ"), {l1ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111ll1(l111ll1l):
    l111ll1l = (l111ll1l + l1ll (u"ࠩ࠽ࠫࢴ")).encode()
    l1111111 = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l1111111, _111l111.nil )
    l1111l11 = LaunchServices.l1111l1l( l111ll11, LaunchServices.l11111ll, _111l111.nil )
    if l1111l11[0] is not None:
        return True
    return False
def l1ll11():
    l11111l1 = []
    for name in l1l1l11l:
        try:
            if l1111ll1(name):
                l11111l1.append(name)
        except:
            continue
    return l11111l1
def l1l11(l1, l11l11):
    import plistlib
    import os
    l1lll1 = []
    l1l1l1 = {}
    for l111llll in os.listdir(l1ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l11l11):
            try:
                l111l1ll = l1ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l111l1ll, l1ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11lll = plist[l1ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1l1 = version.split(l1ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1 == l111l1l1:
                        if not l11lll in l1l1l1:
                            l1l1l1[l11lll] = version
                        elif ll.l11ll(version, l1l1l1[l11lll]) > 0:
                            l1l1l1[l11lll] = version
            except BaseException:
                continue
    for l11lll in l1l1l1:
        l1lll1.append({l1ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l1l1[l11lll], l1ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11lll})
    return l1lll1