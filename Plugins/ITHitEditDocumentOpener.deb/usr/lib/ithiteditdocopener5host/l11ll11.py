#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1ll = 2048
l1lll = 7
def l1l1 (l1lll1):
    global l1l1l
    l111ll = ord (l1lll1 [-1])
    l11l = l1lll1 [:-1]
    l111 = l111ll % len (l11l)
    l1l11l = l11l [:l111] + l11l [l111:]
    if l1llll:
        l1ll1l = l111l () .join ([unichr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l1ll - (l11l11 + l111ll) % l1lll) for l11l11, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import l1l11
from l1l1l11l import l1l1l111
import objc as _1111lll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111lll.l111llll( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111ll11.l11111ll(l1111111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1 (u"ࠨࠩࢬ"), {l1l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111ll1(l111l11l):
    l111l11l = (l111l11l + l1l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l111lll1 = CFStringCreateWithCString( kCFAllocatorDefault, l111l11l, kCFStringEncodingUTF8 )
    l111l1l1 = CFURLCreateWithString( kCFAllocatorDefault, l111lll1, _1111lll.nil )
    l1111l1l = LaunchServices.l111l111( l111l1l1, LaunchServices.l111ll1l, _1111lll.nil )
    if l1111l1l[0] is not None:
        return True
    return False
def l1():
    l111l1ll = []
    for name in l1l1l111:
        try:
            if l1111ll1(name):
                l111l1ll.append(name)
        except:
            continue
    return l111l1ll
def l1l(l11lll, l1l1l1):
    import plistlib
    import os
    l11l1 = []
    l1ll1 = {}
    for l111111l in os.listdir(l1l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111111l.startswith(l1l1l1):
            try:
                l1111l11 = l1l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111111l
                with open(l1111l11, l1l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1l = plist[l1l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l11111l1 = version.split(l1l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l11lll == l11111l1:
                        if not l11l1l in l1ll1:
                            l1ll1[l11l1l] = version
                        elif l1l11.ll(version, l1ll1[l11l1l]) > 0:
                            l1ll1[l11l1l] = version
            except BaseException:
                continue
    for l11l1l in l1ll1:
        l11l1.append({l1l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll1[l11l1l], l1l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1l})
    return l11l1