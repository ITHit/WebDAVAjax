#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll11 = 7
def l1111l (l1llll):
    global l111l
    l11l11 = ord (l1llll [-1])
    l11ll = l1llll [:-1]
    l1l11 = l11l11 % len (l11ll)
    l1ll = l11ll [:l1l11] + l11ll [l1l11:]
    if l1l111:
        l1l1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    return eval (l1l1l1)
import l1ll1
from l1l1ll1l import l1l1lll1
import objc as _1111lll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111lll.l11l11l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1111l (u"࠭ࡌࡔࡅࡲࡴࡾࡊࡥࡧࡣࡸࡰࡹࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡘࡖࡑࡌ࡯ࡳࡗࡕࡐࠬࢣ"), LaunchServices._111ll1l.l1111ll1(l111lll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡎࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢤ"), l111lll1 (u"ࠨࡠࡾࡣࡤࡉࡆࡖࡔࡏࡁࢂࡤࡻࡠࡡࡆࡊ࡚ࡘࡌ࠾ࡿࡌࡢࡣࢁ࡟ࡠࡅࡉࡉࡷࡸ࡯ࡳ࠿ࢀࠫࢥ")), l1111l (u"ࠩࠪࢦ"), {l1111l (u"ࠪࡶࡪࡺࡶࡢ࡮ࠪࢧ"): {l1111l (u"ࠫࡦࡲࡲࡦࡣࡧࡽࡤࡩࡦࡳࡧࡷࡥ࡮ࡴࡥࡥࠩࢨ"): True}, l1111l (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨࢩ"): {2: {l1111l (u"࠭࡮ࡶ࡮࡯ࡣࡦࡩࡣࡦࡲࡷࡩࡩ࠭ࢪ"): True, l1111l (u"ࠧࡢ࡮ࡵࡩࡦࡪࡹࡠࡥࡩࡶࡪࡺࡡࡪࡰࡨࡨࠬࢫ"): True, l1111l (u"ࠨࡶࡼࡴࡪࡥ࡭ࡰࡦ࡬ࡪ࡮࡫ࡲࠨࢬ"): l1111l (u"ࠩࡲࠫࢭ")}}}),
        ])
except:
    pass
def l11l1111(l1111l1l):
    l1111l1l = (l1111l1l + l1111l (u"ࠪ࠾ࠬࢮ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l1111l1l, kCFStringEncodingUTF8 )
    l11l111l = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _1111lll.nil )
    l111l1ll = LaunchServices.l11l1l11( l11l111l, LaunchServices.l111l1l1, _1111lll.nil )
    if l111l1ll[0] is not None:
        return True
    return False
def l1l1l():
    l111l11l = []
    for name in l1l1lll1:
        try:
            if l11l1111(name):
                l111l11l.append(name)
        except:
            continue
    return l111l11l
def l11l1l(l11lll, l11ll1):
    import plistlib
    import os
    l11l1 = []
    l111ll = {}
    for l111ll11 in os.listdir(l1111l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶࠦࢯ")):
        if l111ll11.startswith(l11ll1):
            try:
                l11l11ll = l1111l (u"ࠧ࠵ࡁࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡷ࠴ࠫࡳ࠰ࡅࡲࡲࡹ࡫࡮ࡵࡵ࠲ࡍࡳ࡬࡯࠯ࡲ࡯࡭ࡸࡺࠢࢰ") % l111ll11
                with open(l11l11ll, l1111l (u"࠭ࡲࡣࠩࢱ")) as f:
                    plist = plistlib.load(f)
                    l111l1 = plist[l1111l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐ࡙ࡿࡰࡦࡵࠥࢲ")][0][l1111l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧࡘࡖࡑ࡙ࡣࡩࡧࡰࡩࡸࠨࢳ")][0]
                    version = plist[l1111l (u"ࠤࡆࡊࡇࡻ࡮ࡥ࡮ࡨ࡚ࡪࡸࡳࡪࡱࡱࠦࢴ")]
                    l111l111 = version.split(l1111l (u"ࠥ࠲ࠧࢵ"))[0]
                    if l11lll == l111l111:
                        if not l111l1 in l111ll:
                            l111ll[l111l1] = version
                        elif l1ll1.l1l11l(version, l111ll[l111l1]) > 0:
                            l111ll[l111l1] = version
            except BaseException:
                continue
    for l111l1 in l111ll:
        l11l1.append({l1111l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬࢶ"): l111ll[l111l1], l1111l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧࢷ"): l111l1})
    return l11l1