#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1l1 (l1l):
    global l1l1l
    l11l = ord (l1l [-1])
    l11lll = l1l [:-1]
    l1lll = l11l % len (l11lll)
    l1ll = l11lll [:l1lll] + l11lll [l1lll:]
    if l1l11l:
        l1ll11 = l1lll1 () .join ([unichr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1l1l1 - (l111ll + l11l) % l1ll1l) for l111ll, char in enumerate (l1ll)])
    return eval (l1ll11)
import l1l11
from l1l1l111 import l1l1l11l
import objc as _111l11l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l11l.l111ll1l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1l1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._11111l1.l111llll(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1l1 (u"ࠨࠩࢬ"), {l1l1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1l1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1l1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1l1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1l1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1l1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1l1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l11111ll):
    l11111ll = (l11111ll + l1l1 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111ll1 = CFStringCreateWithCString( kCFAllocatorDefault, l11111ll, kCFStringEncodingUTF8 )
    l111111l = CFURLCreateWithString( kCFAllocatorDefault, l1111ll1, _111l11l.nil )
    l111l1ll = LaunchServices.l1111l11( l111111l, LaunchServices.l111l111, _111l11l.nil )
    if l111l1ll[0] is not None:
        return True
    return False
def l11l1():
    l111lll1 = []
    for name in l1l1l11l:
        try:
            if l1111111(name):
                l111lll1.append(name)
        except:
            continue
    return l111lll1
def ll(l1, l111l1):
    import plistlib
    import os
    l11ll = []
    l1111l = {}
    for l111ll11 in os.listdir(l1l1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111ll11.startswith(l111l1):
            try:
                l111l1l1 = l1l1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111ll11
                with open(l111l1l1, l1l1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1l = plist[l1l1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1l1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1l1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111l1l = version.split(l1l1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1 == l1111l1l:
                        if not l11l1l in l1111l:
                            l1111l[l11l1l] = version
                        elif l1l11.l1l1ll(version, l1111l[l11l1l]) > 0:
                            l1111l[l11l1l] = version
            except BaseException:
                continue
    for l11l1l in l1111l:
        l11ll.append({l1l1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1111l[l11l1l], l1l1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1l})
    return l11ll