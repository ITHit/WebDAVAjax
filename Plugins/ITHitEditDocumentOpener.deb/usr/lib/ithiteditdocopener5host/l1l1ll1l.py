#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l11l1l = 2048
l11l1 = 7
def l111l1 (l1l11l):
    global l11
    ll = ord (l1l11l [-1])
    l1ll = l1l11l [:-1]
    l1111 = ll % len (l1ll)
    l11ll = l1ll [:l1111] + l1ll [l1111:]
    if l1ll1:
        l11lll = l1lll1 () .join ([unichr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1l - (l11ll1 + ll) % l11l1) for l11ll1, char in enumerate (l11ll)])
    return eval (l11lll)
l1l1lll1 = [l111l1 (u"ࠧࡳࡳ࠮ࡹࡲࡶࡩࠨࡿ"), l111l1 (u"ࠨ࡭ࡴ࠯ࡳࡳࡼ࡫ࡲࡱࡱ࡬ࡲࡹࠨࢀ"), l111l1 (u"ࠢ࡮ࡵ࠰ࡩࡽࡩࡥ࡭ࠤࢁ"), l111l1 (u"ࠣ࡯ࡶ࠱ࡻ࡯ࡳࡪࡱࠥࢂ"), l111l1 (u"ࠤࡰࡷ࠲ࡧࡣࡤࡧࡶࡷࠧࢃ"), l111l1 (u"ࠥࡱࡸ࠳ࡰࡳࡱ࡭ࡩࡨࡺࠢࢄ"), l111l1 (u"ࠦࡲࡹ࠭ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴࠥࢅ"),
                      l111l1 (u"ࠧࡳࡳ࠮ࡵࡳࡨࠧࢆ"), l111l1 (u"ࠨ࡭ࡴ࠯࡬ࡲ࡫ࡵࡰࡢࡶ࡫ࠦࢇ")]