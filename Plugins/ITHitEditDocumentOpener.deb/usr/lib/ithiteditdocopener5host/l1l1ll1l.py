#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll11 = 7
def l1111l (l1llll):
    global l111l
    l11l11 = ord (l1llll [-1])
    l11ll = l1llll [:-1]
    l1l11 = l11l11 % len (l11ll)
    l1ll = l11ll [:l1l11] + l11ll [l1l11:]
    if l1l111:
        l1l1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    return eval (l1l1l1)
l1l1lll1 = [l1111l (u"ࠧࡳࡳ࠮ࡹࡲࡶࡩࠨࡿ"), l1111l (u"ࠨ࡭ࡴ࠯ࡳࡳࡼ࡫ࡲࡱࡱ࡬ࡲࡹࠨࢀ"), l1111l (u"ࠢ࡮ࡵ࠰ࡩࡽࡩࡥ࡭ࠤࢁ"), l1111l (u"ࠣ࡯ࡶ࠱ࡻ࡯ࡳࡪࡱࠥࢂ"), l1111l (u"ࠤࡰࡷ࠲ࡧࡣࡤࡧࡶࡷࠧࢃ"), l1111l (u"ࠥࡱࡸ࠳ࡰࡳࡱ࡭ࡩࡨࡺࠢࢄ"), l1111l (u"ࠦࡲࡹ࠭ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴࠥࢅ"),
                      l1111l (u"ࠧࡳࡳ࠮ࡵࡳࡨࠧࢆ"), l1111l (u"ࠨ࡭ࡴ࠯࡬ࡲ࡫ࡵࡰࡢࡶ࡫ࠦࢇ")]