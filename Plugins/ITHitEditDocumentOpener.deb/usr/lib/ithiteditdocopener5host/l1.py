#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
l1ll1 = 7
def l1llll (l11):
    global l111
    l1lll = ord (l11 [-1])
    l111l1 = l11 [:-1]
    l11ll = l1lll % len (l111l1)
    l1l = l111l1 [:l11ll] + l111l1 [l11ll:]
    if l1ll1l:
        l111l = l111ll () .join ([unichr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    else:
        l111l = str () .join ([chr (ord (char) - l11l1l - (l1l1l + l1lll) % l1ll1) for l1l1l, char in enumerate (l1l)])
    return eval (l111l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1l1lll(l11ll11=None):
    if platform.system() == l1llll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1l1l
        props = {}
        try:
            prop_names = (l1llll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1llll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1llll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1llll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1llll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1llll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1llll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1llll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1llll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1llll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1llll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1llll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11ll1l = l1l1l1l.l1l11l1(l11ll11, l1llll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11l1l1 in prop_names:
                l1ll11l = l1llll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11ll1l, l11l1l1)
                props[l11l1l1] = l1l1l1l.l1l11l1(l11ll11, l1ll11l)
        except:
            pass
    return props
def l11lll1(logger, l1lll1l):
    l11llll = os.environ.get(l1llll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1llll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11llll = l11llll.upper()
    if l11llll == l1llll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1lll11 = logging.DEBUG
    elif l11llll == l1llll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1lll11 = logging.INFO
    elif l11llll == l1llll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1lll11 = logging.WARNING
    elif l11llll == l1llll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1lll11 = logging.ERROR
    elif l11llll == l1llll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1lll11 = logging.CRITICAL
    elif l11llll == l1llll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1lll11 = logging.NOTSET
    logger.setLevel(l1lll11)
    l11111 = RotatingFileHandler(l1lll1l, maxBytes=1024*1024*5, backupCount=3)
    l11111.setLevel(l1lll11)
    formatter = logging.Formatter(l1llll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11111.setFormatter(formatter)
    logger.addHandler(l11111)
    globals()[l1llll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l1():
    return globals()[l1llll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l111111():
    if platform.system() == l1llll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1llll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l11ll
        l1l11ll.l111ll1(sys.stdin.fileno(), os.l1111l1)
        l1l11ll.l111ll1(sys.stdout.fileno(), os.l1111l1)
def l1l1ll1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1llll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    if platform.system() == l1llll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11l111
        return l11l111.l1l1111()
    elif platform.system() == l1llll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1llll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11l1():
    if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11l111
        return l11l111.l1l111l()
    elif platform.system() == l1llll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll11
        return l1ll11.l11l1()
    elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111l11
        return l111l11.l11l1()
    return l1llll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111l1l(l1l111, l1lll1):
    if platform.system() == l1llll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11l111
        return l11l111.l1lllll(l1l111, l1lll1)
    elif platform.system() == l1llll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111l11
        return l111l11.l11l(l1l111, l1lll1)
    elif platform.system() == l1llll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll11
        return l1ll11.l11l(l1l111, l1lll1)
    raise ValueError(l1llll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11111l(l1l1l1, url):
    if platform.system() == l1llll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11l111
        return l11l111.l1ll1ll(l1l1l1, url)
    elif platform.system() == l1llll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111l11
        return l1llll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1llll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll11
        return l1llll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1llll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1111ll():
    if platform.system() == l1llll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11l111
        return l11l111.l1111ll()
def l11l11l(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1llll (u"ࠩ࠱ࠫ࠶"))[0]
def l111lll(l1111l):
    l1llll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1l1l11 = l1llll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1111l:
        if l1llll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1l1l11[3:]) < int(protocol[l1llll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1l1l11 = protocol[l1llll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1l1l11
def l1l11(l1ll111, l1llllll):
    l1llll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll111 is None: l1ll111 = l1llll (u"ࠩ࠳ࠫ࠽");
    if l1llllll is None: l1llllll = l1llll (u"ࠪ࠴ࠬ࠾");
    l11l1ll = l1ll111.split(l1llll (u"ࠫ࠳࠭࠿"))
    l1llll1 = l1llllll.split(l1llll (u"ࠬ࠴ࠧࡀ"))
    while len(l11l1ll) < len(l1llll1): l11l1ll.append(l1llll (u"ࠨ࠰ࠣࡁ"));
    while len(l1llll1) < len(l11l1ll): l1llll1.append(l1llll (u"ࠢ࠱ࠤࡂ"));
    l11l1ll = [ int(x) for x in l11l1ll ]
    l1llll1 = [ int(x) for x in l1llll1 ]
    for  i in range(len(l11l1ll)):
        if len(l1llll1) == i:
            return 1
        if l11l1ll[i] == l1llll1[i]:
            continue
        elif l11l1ll[i] > l1llll1[i]:
            return 1
        else:
            return -1
    if len(l11l1ll) != len(l1llll1):
        return -1
    return 0