#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1l = 2048
l11 = 7
def l11l1 (l11l):
    global l111
    l11lll = ord (l11l [-1])
    l1ll1l = l11l [:-1]
    l111ll = l11lll % len (l1ll1l)
    l111l1 = l1ll1l [:l111ll] + l1ll1l [l111ll:]
    if l111l:
        l1ll = l1111l () .join ([unichr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    return eval (l1ll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll111(l11l1l1=None):
    if platform.system() == l11l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1111l1
        props = {}
        try:
            prop_names = (l11l1 (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l1 (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l1 (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l1 (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l1 (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l1 (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l1 (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l1 (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l1 (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l1 (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l1 (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l1 (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111l1l = l1111l1.l11l11l(l11l1l1, l11l1 (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1ll1l1 in prop_names:
                l11llll = l11l1 (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111l1l, l1ll1l1)
                props[l1ll1l1] = l1111l1.l11l11l(l11l1l1, l11llll)
        except:
            pass
    return props
def l1l111l(logger, l111l11):
    l1llllll = os.environ.get(l11l1 (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l1 (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1llllll = l1llllll.upper()
    if l1llllll == l11l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1111ll = logging.DEBUG
    elif l1llllll == l11l1 (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1111ll = logging.INFO
    elif l1llllll == l11l1 (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1111ll = logging.WARNING
    elif l1llllll == l11l1 (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1111ll = logging.ERROR
    elif l1llllll == l11l1 (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1111ll = logging.CRITICAL
    elif l1llllll == l11l1 (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1111ll = logging.NOTSET
    logger.setLevel(l1111ll)
    l111lll = RotatingFileHandler(l111l11, maxBytes=1024*1024*5, backupCount=3)
    l111lll.setLevel(l1111ll)
    formatter = logging.Formatter(l11l1 (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l111lll.setFormatter(formatter)
    logger.addHandler(l111lll)
    globals()[l11l1 (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1lll():
    return globals()[l11l1 (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1l1l():
    if platform.system() == l11l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l1 (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1ll1
        l1l1ll1.l1l11l1(sys.stdin.fileno(), os.l1lllll)
        l1l1ll1.l1l11l1(sys.stdout.fileno(), os.l1lllll)
def l1l1l11(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l1 (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l1ll():
    if platform.system() == l11l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l11ll
        return l1l11ll.l111111()
    elif platform.system() == l11l1 (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1ll11():
    if platform.system() == l11l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l11ll
        return l1l11ll.l1l1lll()
    elif platform.system() == l11l1 (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1111
        return l1111.l1ll11()
    elif platform.system() == l11l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1ll
        return l1ll1ll.l1ll11()
    return l11l1 (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111ll1(l11l1l, l1ll1):
    if platform.system() == l11l1 (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l11ll
        return l1l11ll.l11111l(l11l1l, l1ll1)
    elif platform.system() == l11l1 (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1ll
        return l1ll1ll.l11l11(l11l1l, l1ll1)
    elif platform.system() == l11l1 (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1111
        return l1111.l11l11(l11l1l, l1ll1)
    raise ValueError(l11l1 (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1llll1(l1l11l, url):
    if platform.system() == l11l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l11ll
        return l1l11ll.l1lll11(l1l11l, url)
    elif platform.system() == l11l1 (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1ll
        return l11l1 (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l1 (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1111
        return l11l1 (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l1 (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l1111():
    if platform.system() == l11l1 (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l11ll
        return l1l11ll.l1l1111()
def l11111(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l1 (u"ࠩ࠱ࠫ࠶"))[0]
def l11l111(l1l1l1):
    l11l1 (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11ll1l = l11l1 (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l1l1:
        if l11l1 (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11ll1l[3:]) < int(protocol[l11l1 (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11ll1l = protocol[l11l1 (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11ll1l
def l1l1ll(l1lll1l, l1ll11l):
    l11l1 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1lll1l is None: l1lll1l = l11l1 (u"ࠩ࠳ࠫ࠽");
    if l1ll11l is None: l1ll11l = l11l1 (u"ࠪ࠴ࠬ࠾");
    l11ll11 = l1lll1l.split(l11l1 (u"ࠫ࠳࠭࠿"))
    l11lll1 = l1ll11l.split(l11l1 (u"ࠬ࠴ࠧࡀ"))
    while len(l11ll11) < len(l11lll1): l11ll11.append(l11l1 (u"ࠨ࠰ࠣࡁ"));
    while len(l11lll1) < len(l11ll11): l11lll1.append(l11l1 (u"ࠢ࠱ࠤࡂ"));
    l11ll11 = [ int(x) for x in l11ll11 ]
    l11lll1 = [ int(x) for x in l11lll1 ]
    for  i in range(len(l11ll11)):
        if len(l11lll1) == i:
            return 1
        if l11ll11[i] == l11lll1[i]:
            continue
        elif l11ll11[i] > l11lll1[i]:
            return 1
        else:
            return -1
    if len(l11ll11) != len(l11lll1):
        return -1
    return 0