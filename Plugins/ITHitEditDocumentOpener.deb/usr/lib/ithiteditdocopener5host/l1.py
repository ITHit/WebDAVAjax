#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1ll = 2048
l1111 = 7
def l1ll1 (l1ll1l):
    global l111ll
    l11ll = ord (l1ll1l [-1])
    l111 = l1ll1l [:-1]
    l111l1 = l11ll % len (l111)
    ll = l111 [:l111l1] + l111 [l111l1:]
    if l111l:
        l1l = l1l111 () .join ([unichr (ord (char) - l1ll - (l1l1l1 + l11ll) % l1111) for l1l1l1, char in enumerate (ll)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l1l1l1 + l11ll) % l1111) for l1l1l1, char in enumerate (ll)])
    return eval (l1l)
import os
import re
import subprocess
import l1l11
from l1l11 import l11l
def l1l11l():
    return []
def l11l1(l11ll1, l11l11):
    logger = l11l()
    l1lll1 = []
    l11lll = [l1ll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1ll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11lll:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1llll = process.wait()
            l1ll11 = {}
            if l1llll == 0:
                l1lll = re.compile(l1ll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1 = re.compile(l1ll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11 = re.search(l1lll, line)
                    l1l1l = l11.group(1)
                    if l11ll1 == l1l1l:
                        l1l1ll = re.search(l1l1, line)
                        if l1l1ll:
                            l1111l = l1ll1 (u"ࠨࡦࡤࡺࠬࠄ")+l1l1ll.group(1)
                            version = l11.group(0)
                            if not l1111l in l1ll11:
                                l1ll11[l1111l] = version
                            elif l1l11.l11l1l(version, l1ll11[l1111l]) > 0:
                                l1ll11[l1111l] = version
            for l1111l in l1ll11:
                l1lll1.append({l1ll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll11[l1111l], l1ll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1111l})
        except Exception as e:
            logger.error(str(e))
    return l1lll1