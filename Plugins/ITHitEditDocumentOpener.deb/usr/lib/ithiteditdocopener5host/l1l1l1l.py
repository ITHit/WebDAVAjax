#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1lll1 (l11):
    global l11l11
    l1111l = ord (l11 [-1])
    l1lll = l11 [:-1]
    l1l1ll = l1111l % len (l1lll)
    l1l = l1lll [:l1l1ll] + l1lll [l1l1ll:]
    if l1:
        l11ll = l1111 () .join ([unichr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    return eval (l11ll)
import l1l11
from l1l1l111 import l1l1l11l
import objc as _111ll1l
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111ll1l.l1111ll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1lll1 (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l1l1.l11111ll(l111l111 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111l111 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1lll1 (u"ࠨࠩࢬ"), {l1lll1 (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1lll1 (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1lll1 (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1lll1 (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1lll1 (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1lll1 (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1lll1 (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l111111l(l11111l1):
    l11111l1 = (l11111l1 + l1lll1 (u"ࠩ࠽ࠫࢴ")).encode()
    l1111lll = CFStringCreateWithCString( kCFAllocatorDefault, l11111l1, kCFStringEncodingUTF8 )
    l111ll11 = CFURLCreateWithString( kCFAllocatorDefault, l1111lll, _111ll1l.nil )
    l111lll1 = LaunchServices.l111l11l( l111ll11, LaunchServices.l111l1ll, _111ll1l.nil )
    if l111lll1[0] is not None:
        return True
    return False
def l111():
    l1111l1l = []
    for name in l1l1l11l:
        try:
            if l111111l(name):
                l1111l1l.append(name)
        except:
            continue
    return l1111l1l
def l1l111(l1l1, l111ll):
    import plistlib
    import os
    l111l = []
    l1ll11 = {}
    for l111llll in os.listdir(l1lll1 (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111llll.startswith(l111ll):
            try:
                l1111l11 = l1lll1 (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111llll
                with open(l1111l11, l1lll1 (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l = plist[l1lll1 (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1lll1 (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1lll1 (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l1lll1 (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1 == l1111111:
                        if not l11l in l1ll11:
                            l1ll11[l11l] = version
                        elif l1l11.l1l1l(version, l1ll11[l11l]) > 0:
                            l1ll11[l11l] = version
            except BaseException:
                continue
    for l11l in l1ll11:
        l111l.append({l1lll1 (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1ll11[l11l], l1lll1 (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l})
    return l111l