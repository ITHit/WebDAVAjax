#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l111ll = 2048
l11lll = 7
def l1ll1l (l11ll):
    global l1
    l11 = ord (l11ll [-1])
    l11ll1 = l11ll [:-1]
    l1ll11 = l11 % len (l11ll1)
    l1111 = l11ll1 [:l1ll11] + l11ll1 [l1ll11:]
    if l1l1l:
        l111 = l111l () .join ([unichr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    else:
        l111 = str () .join ([chr (ord (char) - l111ll - (l1l111 + l11) % l11lll) for l1l111, char in enumerate (l1111)])
    return eval (l111)
import l1llll
from l1l1l11l import l1l1l111
import objc as _111l1ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1ll.l111ll11( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l1ll1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l1l.l11111ll(l1111lll (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l1ll1l (u"ࠨࠩࢬ"), {l1ll1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l1ll1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l1ll1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l1ll1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l1ll1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l1ll1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l1ll1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111111(l111ll1l):
    l111ll1l = (l111ll1l + l1ll1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l111ll1l, kCFStringEncodingUTF8 )
    l1111l11 = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _111l1ll.nil )
    l111111l = LaunchServices.l11111l1( l1111l11, LaunchServices.l111l11l, _111l1ll.nil )
    if l111111l[0] is not None:
        return True
    return False
def l1l():
    l111l111 = []
    for name in l1l1l111:
        try:
            if l1111111(name):
                l111l111.append(name)
        except:
            continue
    return l111l111
def l1l1ll(l1111l, l1ll1):
    import plistlib
    import os
    l1l11 = []
    l11l1 = {}
    for l111l1l1 in os.listdir(l1ll1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l1l1.startswith(l1ll1):
            try:
                l1111ll1 = l1ll1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l1l1
                with open(l1111ll1, l1ll1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1l = plist[l1ll1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l1ll1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l1ll1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111lll1 = version.split(l1ll1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1111l == l111lll1:
                        if not l11l1l in l11l1:
                            l11l1[l11l1l] = version
                        elif l1llll.ll(version, l11l1[l11l1l]) > 0:
                            l11l1[l11l1l] = version
            except BaseException:
                continue
    for l11l1l in l11l1:
        l1l11.append({l1ll1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l11l1[l11l1l], l1ll1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1l})
    return l1l11