#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l11 = 2048
l1l1 = 7
def l11l1l (l1l1ll):
    global l1lll
    l11 = ord (l1l1ll [-1])
    l1 = l1l1ll [:-1]
    l11l1 = l11 % len (l1)
    l1ll = l1 [:l11l1] + l1 [l11l1:]
    if l1111:
        ll = l1l () .join ([unichr (ord (char) - l1l11 - (l1l1l + l11) % l1l1) for l1l1l, char in enumerate (l1ll)])
    else:
        ll = str () .join ([chr (ord (char) - l1l11 - (l1l1l + l11) % l1l1) for l1l1l, char in enumerate (l1ll)])
    return eval (ll)
import l111l1
from l1l1l11l import l1l1l111
import objc as _111l1ll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111l1ll.l111l11l( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l1l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._1111l11.l11111l1(l1111ll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111ll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l1l (u"ࠨࠩࢬ"), {l11l1l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l1l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l1l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l1l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l1l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l1l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l1l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l111ll11):
    l111ll11 = (l111ll11 + l11l1l (u"ࠩ࠽ࠫࢴ")).encode()
    l111llll = CFStringCreateWithCString( kCFAllocatorDefault, l111ll11, kCFStringEncodingUTF8 )
    l11111ll = CFURLCreateWithString( kCFAllocatorDefault, l111llll, _111l1ll.nil )
    l111ll1l = LaunchServices.l111l1l1( l11111ll, LaunchServices.l1111lll, _111l1ll.nil )
    if l111ll1l[0] is not None:
        return True
    return False
def l1ll1l():
    l111l111 = []
    for name in l1l1l111:
        try:
            if l1111l1l(name):
                l111l111.append(name)
        except:
            continue
    return l111l111
def l1llll(l111l, l1111l):
    import plistlib
    import os
    l1ll1 = []
    l1lll1 = {}
    for l111111l in os.listdir(l11l1l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111111l.startswith(l1111l):
            try:
                l111lll1 = l11l1l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111111l
                with open(l111lll1, l11l1l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11lll = plist[l11l1l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l1l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l1l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l1111111 = version.split(l11l1l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l111l == l1111111:
                        if not l11lll in l1lll1:
                            l1lll1[l11lll] = version
                        elif l111l1.l11l11(version, l1lll1[l11lll]) > 0:
                            l1lll1[l11lll] = version
            except BaseException:
                continue
    for l11lll in l1lll1:
        l1ll1.append({l11l1l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1lll1[l11lll], l11l1l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11lll})
    return l1ll1