#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l1l1ll = 2048
l1ll11 = 7
def l1111l (l1llll):
    global l111l
    l11l11 = ord (l1llll [-1])
    l11ll = l1llll [:-1]
    l1l11 = l11l11 % len (l11ll)
    l1ll = l11ll [:l1l11] + l11ll [l1l11:]
    if l1l111:
        l1l1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l111 + l11l11) % l1ll11) for l111, char in enumerate (l1ll)])
    return eval (l1l1l1)
import _winreg
import subprocess, threading
from l1ll1 import l11l
from l1l1ll1l import l1l1lll1
def l11l11l():
    l11l1l1l = [l1111l (u"ࠢࡆࡺࡦࡩࡱࠨ࢈"), l1111l (u"࡙ࠣࡲࡶࡩࠨࢉ"), l1111l (u"ࠤࡓࡳࡼ࡫ࡲࡑࡱ࡬ࡲࡹࠨࢊ"), l1111l (u"ࠥࡓࡺࡺ࡬ࡰࡱ࡮ࠦࢋ")]
    for part in l11l1l1l:
        try:
            l1l111l1 = l1111l (u"ࠦࢀ࠶ࡽ࠯ࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡢ࡜ࡄࡷࡵ࡚ࡪࡸࠢࢌ").format(part)
            l11ll11l = _winreg.l1l1111l(_winreg.l1l1l1l1, l1l111l1)
        except l11llll1:
            continue
        value = _winreg.l11lllll(l11ll11l, l1111l (u"ࠧࠨࢍ"))
        return value.split(l1111l (u"ࠨ࠮ࠣࢎ"))[-1]
    return None
def l11111l():
    l1l11111 = []
    for name in l1l1lll1:
        try:
            l1l111l1 = l1111l (u"ࠢࡼ࠲ࢀࡠࡡࡹࡨࡦ࡮࡯ࡠࡡࡵࡰࡦࡰ࡟ࡠࡨࡵ࡭࡮ࡣࡱࡨࠧ࢏").format(name)
            l11lll1l = _winreg.l1l1111l(_winreg.l1l1l1l1, l1l111l1)
            if _winreg.l11lllll(l11lll1l, l1111l (u"ࠣࠤ࢐")):
                l1l11111.append(name)
        except l11llll1:
            continue
    return l1l11111
def l111lll(l11lll, l11ll1):
    import re
    l11l1 = []
    l11l1ll1 = _winreg.l1l1111l(_winreg.l1l1l1l1, l1111l (u"ࠤࡄࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࡳࠣ࢑"))
    for i in range(0, _winreg.l1l111ll(l11l1ll1)[0]):
        try:
            l1l11lll = _winreg.l11ll1ll(l11l1ll1, i)
            if l1l11lll.startswith(l11ll1):
                l11ll1l1 = _winreg.l11ll111(l11l1ll1, l1l11lll)
                value, l1l11ll1 = _winreg.l11l1lll(l11ll1l1, l1111l (u"ࠪࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡆࡶࡰࡏࡣࡰࡩࠬ࢒"))
                m = re.search(l1111l (u"ࠫࡻ࠮ࠨ࡜࡞ࡧࡡࢀ࠷ࠬࡾࠫ࡟࠲ࡠࡢࡤ࡞ࡽ࠴࠰ࢂࡢ࠮࡜࡞ࡧࡡࢀ࠷ࠬࡾ࡝࡟࠲ࡠࡢࡤ࡞ࡽ࠴࠰ࢂࡣ࠿ࠪࠩ࢓"), value)
                if m:
                    l1l1l11l = {l1111l (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭࢔"): m.group(1)}
                    l11lll11 = m.group(2)
                    if l11lll == l11lll11:
                        m = re.search(l11ll1.replace(l1111l (u"࠭࠮ࠨ࢕"), l1111l (u"ࠧ࡝࡞࠱ࠫ࢖")) + l1111l (u"ࠨࠪ࡞ࡠࡼࡣࠪࠪ࡞࠱ࡩࡽ࡫ࠧࢗ"), l1l11lll)
                        l1l1l11l[l1111l (u"ࠩࡳࡶࡴࡺ࡯ࡤࡱ࡯ࠫ࢘")] = m.group(1)
                        l11l1.append(l1l1l11l)
                else:
                    raise ValueError(l1111l (u"ࠥࡇࡦࡴࠧࡵࠢࡪࡩࡹࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡧࡴࡲࡱ࠿ࠦࠥࡴ࢙ࠢࠥ") % value)
        except l11llll1 as ex:
            continue
    return l11l1
def l1l1l111(l111l1):
    try:
        l1l1l1ll = l1111l (u"ࠦࢀ࠶ࡽ࡝࡞ࡶ࡬ࡪࡲ࡬࡝࡞ࡲࡴࡪࡴ࡜࡝ࡥࡲࡱࡲࡧ࡮ࡥࠤ࢚").format(l111l1)
        l1l1ll11 = _winreg.l1l1111l(_winreg.l1l1l1l1, l1l1l1ll)
        value, l1l11ll1 = _winreg.l11l1lll(l1l1ll11, l1111l (u"࢛ࠬ࠭"))
        if value:
            return value.split(l1111l (u"࠭ࠢࠨ࢜"))[1]
    except l11llll1:
        pass
    return l1111l (u"ࠧࠨ࢝")
def l1111ll(l111l1, url):
    threading.Thread(target=_1l11l11,args=(l111l1, url)).start()
    return l1111l (u"ࠣࡕࡸࡧࡨ࡫ࡳࡴࠤ࢞")
def _1l11l11(l111l1, url):
    logger = l11l()
    l1l11l1l = l1l1l111(l111l1)
    logger.debug(l1111l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫ࢟") % (l1l11l1l, url))
    retcode = subprocess.Popen(l1111l (u"ࡵࠫࠧࠫࡳࠣࠢࠨࡷࠬࢠ") % (l1l11l1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1111l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡼࡧࡳࠡࡶࡨࡶࡲ࡯࡮ࡢࡶࡨࡨࠥࡨࡹࠡࡵ࡬࡫ࡳࡧ࡬࠭ࠢࠨࡷࠧࢡ") % retcode)
    else:
        logger.info(l1111l (u"ࠧࡕࡰࡦࡰࡨࡶࠥࡸࡥࡵࡷࡵࡲࡪࡪࠬࠡࠧࡶࠦࢢ") % retcode)