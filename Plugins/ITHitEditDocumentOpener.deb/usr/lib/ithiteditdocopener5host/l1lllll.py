#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l11l1):
    global l11l11
    l1l1ll = ord (l11l1 [-1])
    l11l = l11l1 [:-1]
    l1l11 = l1l1ll % len (l11l)
    l1l11l = l11l [:l1l11] + l11l [l1l11:]
    if l1l:
        l1111 = l111ll () .join ([unichr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    else:
        l1111 = str () .join ([chr (ord (char) - l111 - (l11lll + l1l1ll) % l1lll) for l11lll, char in enumerate (l1l11l)])
    return eval (l1111)
import subprocess, threading
from l1l1l import l11ll1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1llllll():
    l1l11ll1 = [l11l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11ll1:
        try:
            l11ll11l = l11l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1ll1 = winreg.l11ll1l1(winreg.l11l11l1, l11ll11l)
        except l11lllll:
            continue
        value = winreg.l1l11111(l11l1ll1, l11l1l (u"ࠦࠧ࢓"))
        return value.split(l11l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11ll1l():
    l11lll1l = []
    for name in l1l1l111:
        try:
            l11ll11l = l11l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11llll1 = winreg.l11ll1l1(winreg.l11l11l1, l11ll11l)
            if winreg.l1l11111(l11llll1, l11l1l (u"ࠢࠣ࢖")):
                l11lll1l.append(name)
        except l11lllll:
            continue
    return l11lll1l
def l1l11l1(l1l1, l1lll1):
    import re
    l1ll = []
    l11l1lll = winreg.l11ll1l1(winreg.l11l11l1, l11l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l11(l11l1lll)[0]):
        try:
            l11lll11 = winreg.l11ll1ll(l11l1lll, i)
            if l11lll11.startswith(l1lll1):
                l11ll111 = winreg.l11l111l(l11l1lll, l11lll11)
                value, l1l111ll = winreg.l11l1l1l(l11ll111, l11l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11ll = {l11l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l1111l = m.group(2)
                    if l1l1 == l1l1111l:
                        m = re.search(l1lll1.replace(l11l1l (u"ࠬ࠴࢛ࠧ"), l11l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l11l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll11)
                        l11l11ll[l11l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1ll.append(l11l11ll)
                else:
                    raise ValueError(l11l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11lllll as ex:
            continue
    return l1ll
def l11l1l11(l111l):
    try:
        l11l1111 = l11l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l111l)
        l1l11lll = winreg.l11ll1l1(winreg.l11l11l1, l11l1111)
        value, l1l111ll = winreg.l11l1l1l(l1l11lll, l11l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11lllll:
        pass
    return l11l1l (u"࠭ࠧࢣ")
def l1lll1l(l111l, url):
    threading.Thread(target=_1l111l1,args=(l111l, url)).start()
    return l11l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l111l1(l111l, url):
    logger = l11ll1()
    l1l11l1l = l11l1l11(l111l)
    logger.debug(l11l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l1l, url))
    retcode = subprocess.Popen(l11l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)