#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l = sys.version_info [0] == 2
l1111 = 2048
l111 = 7
def l1l1 (l1llll):
    global l1l11
    l1l11l = ord (l1llll [-1])
    l11l11 = l1llll [:-1]
    l1l1l = l1l11l % len (l11l11)
    l111ll = l11l11 [:l1l1l] + l11l11 [l1l1l:]
    if l11l:
        l1 = l1l () .join ([unichr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    else:
        l1 = str () .join ([chr (ord (char) - l1111 - (l11ll1 + l1l11l) % l111) for l11ll1, char in enumerate (l111ll)])
    return eval (l1)
import subprocess, threading
from l1ll1l import l1ll1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1lll11():
    l11l1l11 = [l1l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1l11:
        try:
            l11l1lll = l1l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1l1l = winreg.l1l111ll(winreg.l1l11l11, l11l1lll)
        except l1l11ll1:
            continue
        value = winreg.l1l11lll(l11l1l1l, l1l1 (u"ࠦࠧ࢓"))
        return value.split(l1l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1l1l():
    l11ll111 = []
    for name in l1l1l111:
        try:
            l11l1lll = l1l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l1l = winreg.l1l111ll(winreg.l1l11l11, l11l1lll)
            if winreg.l1l11lll(l1l11l1l, l1l1 (u"ࠢࠣ࢖")):
                l11ll111.append(name)
        except l1l11ll1:
            continue
    return l11ll111
def l1l1ll1(l111l, l1l1l1):
    import re
    l1l1ll = []
    l11llll1 = winreg.l1l111ll(winreg.l1l11l11, l1l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11111(l11llll1)[0]):
        try:
            l11l11ll = winreg.l11l1111(l11llll1, i)
            if l11l11ll.startswith(l1l1l1):
                l1l1111l = winreg.l11lllll(l11llll1, l11l11ll)
                value, l11lll1l = winreg.l11l11l1(l1l1111l, l1l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll11l = {l1l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1ll1 = m.group(2)
                    if l111l == l11l1ll1:
                        m = re.search(l1l1l1.replace(l1l1 (u"ࠬ࠴࢛ࠧ"), l1l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l11ll)
                        l11ll11l[l1l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l1ll.append(l11ll11l)
                else:
                    raise ValueError(l1l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l1l11ll1 as ex:
            continue
    return l1l1ll
def l11lll11(l111l1):
    try:
        l1l111l1 = l1l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l111l1)
        l11l111l = winreg.l1l111ll(winreg.l1l11l11, l1l111l1)
        value, l11lll1l = winreg.l11l11l1(l11l111l, l1l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1 (u"ࠬࠨࠧࢢ"))[1]
    except l1l11ll1:
        pass
    return l1l1 (u"࠭ࠧࢣ")
def l111l11(l111l1, url):
    threading.Thread(target=_11ll1ll,args=(l111l1, url)).start()
    return l1l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11ll1ll(l111l1, url):
    logger = l1ll1()
    l11ll1l1 = l11lll11(l111l1)
    logger.debug(l1l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll1l1, url))
    retcode = subprocess.Popen(l1l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll1l1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)