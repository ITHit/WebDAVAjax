#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l111ll = 7
def l1lll1 (l11ll):
    global l1l1l
    l11 = ord (l11ll [-1])
    l1llll = l11ll [:-1]
    l1lll = l11 % len (l1llll)
    l1l = l1llll [:l1lll] + l1llll [l1lll:]
    if l1ll11:
        l1l111 = l11l1l () .join ([unichr (ord (char) - l1l1 - (l111l1 + l11) % l111ll) for l111l1, char in enumerate (l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l11) % l111ll) for l111l1, char in enumerate (l1l)])
    return eval (l1l111)
import subprocess, threading
from l1111l import l1ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11111l():
    l11lllll = [l1lll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1lll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1lll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1lll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11lllll:
        try:
            l11l11ll = l1lll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11ll1 = winreg.l11l1lll(winreg.l11l1ll1, l11l11ll)
        except l11l111l:
            continue
        value = winreg.l11l1l1l(l1l11ll1, l1lll1 (u"ࠦࠧ࢓"))
        return value.split(l1lll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1l1l():
    l1l11lll = []
    for name in l1l1l11l:
        try:
            l11l11ll = l1lll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11ll1l1 = winreg.l11l1lll(winreg.l11l1ll1, l11l11ll)
            if winreg.l11l1l1l(l11ll1l1, l1lll1 (u"ࠢࠣ࢖")):
                l1l11lll.append(name)
        except l11l111l:
            continue
    return l1l11lll
def l1llllll(ll, l11l11):
    import re
    l1l11 = []
    l11lll1l = winreg.l11l1lll(winreg.l11l1ll1, l1lll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l111l1(l11lll1l)[0]):
        try:
            l11ll11l = winreg.l1l11111(l11lll1l, i)
            if l11ll11l.startswith(l11l11):
                l1l11l11 = winreg.l11ll111(l11lll1l, l11ll11l)
                value, l1l1111l = winreg.l11lll11(l1l11l11, l1lll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1lll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1111 = {l1lll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll1ll = m.group(2)
                    if ll == l11ll1ll:
                        m = re.search(l11l11.replace(l1lll1 (u"ࠬ࠴࢛ࠧ"), l1lll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1lll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11ll11l)
                        l11l1111[l1lll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1l11.append(l11l1111)
                else:
                    raise ValueError(l1lll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l1l11
def l11l1l11(l1l11l):
    try:
        l11llll1 = l1lll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11l)
        l11l11l1 = winreg.l11l1lll(winreg.l11l1ll1, l11llll1)
        value, l1l1111l = winreg.l11lll11(l11l11l1, l1lll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1lll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l1lll1 (u"࠭ࠧࢣ")
def l1l1l11(l1l11l, url):
    threading.Thread(target=_1l111ll,args=(l1l11l, url)).start()
    return l1lll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l111ll(l1l11l, url):
    logger = l1ll()
    l1l11l1l = l11l1l11(l1l11l)
    logger.debug(l1lll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l1l, url))
    retcode = subprocess.Popen(l1lll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l1l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1lll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1lll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)