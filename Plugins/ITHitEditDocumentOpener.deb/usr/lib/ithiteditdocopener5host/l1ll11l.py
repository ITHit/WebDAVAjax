#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l111l = 2048
l1l = 7
def l11ll (l1111):
    global l11
    l111l1 = ord (l1111 [-1])
    l1l1ll = l1111 [:-1]
    l1l1 = l111l1 % len (l1l1ll)
    l111 = l1l1ll [:l1l1] + l1l1ll [l1l1:]
    if l1111l:
        l1l11l = l1 () .join ([unichr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l111l - (l1lll + l111l1) % l1l) for l1lll, char in enumerate (l111)])
    return eval (l1l11l)
import subprocess, threading
from l1ll11 import l11l1
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1ll1l1():
    l1l11l11 = [l11ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11l11:
        try:
            l1l11111 = l11ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11llll1 = winreg.l11l1l1l(winreg.l11l1111, l1l11111)
        except l11ll1l1:
            continue
        value = winreg.l1l11l1l(l11llll1, l11ll (u"ࠦࠧ࢓"))
        return value.split(l11ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11l111():
    l1l11ll1 = []
    for name in l1l1l111:
        try:
            l1l11111 = l11ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l1ll1 = winreg.l11l1l1l(winreg.l11l1111, l1l11111)
            if winreg.l1l11l1l(l11l1ll1, l11ll (u"ࠢࠣ࢖")):
                l1l11ll1.append(name)
        except l11ll1l1:
            continue
    return l1l11ll1
def l1l1l1l(l11lll, l1l1l):
    import re
    l111ll = []
    l11lllll = winreg.l11l1l1l(winreg.l11l1111, l11ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lll11(l11lllll)[0]):
        try:
            l11lll1l = winreg.l1l11lll(l11lllll, i)
            if l11lll1l.startswith(l1l1l):
                l11l1lll = winreg.l11ll1ll(l11lllll, l11lll1l)
                value, l11l11l1 = winreg.l11l11ll(l11l1lll, l11ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11ll11l = {l11ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll111 = m.group(2)
                    if l11lll == l11ll111:
                        m = re.search(l1l1l.replace(l11ll (u"ࠬ࠴࢛ࠧ"), l11ll (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll1l)
                        l11ll11l[l11ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111ll.append(l11ll11l)
                else:
                    raise ValueError(l11ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll1l1 as ex:
            continue
    return l111ll
def l1l111ll(l1l11):
    try:
        l1l111l1 = l11ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11)
        l11l111l = winreg.l11l1l1l(winreg.l11l1111, l1l111l1)
        value, l11l11l1 = winreg.l11l11ll(l11l111l, l11ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll (u"ࠬࠨࠧࢢ"))[1]
    except l11ll1l1:
        pass
    return l11ll (u"࠭ࠧࢣ")
def l1l1ll1(l1l11, url):
    threading.Thread(target=_11l1l11,args=(l1l11, url)).start()
    return l11ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1l11(l1l11, url):
    logger = l11l1()
    l1l1111l = l1l111ll(l1l11)
    logger.debug(l11ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l1111l, url))
    retcode = subprocess.Popen(l11ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l1111l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)