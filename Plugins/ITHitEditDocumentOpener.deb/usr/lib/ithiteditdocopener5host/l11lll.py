#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l111 = sys.version_info [0] == 2
l11l1 = 2048
l1l1l1 = 7
def l11l (ll):
    global l1ll1
    l11l1l = ord (ll [-1])
    l11ll1 = ll [:-1]
    l1l11 = l11l1l % len (l11ll1)
    l11ll = l11ll1 [:l1l11] + l11ll1 [l1l11:]
    if l1l111:
        l111 = l1ll11 () .join ([unichr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    else:
        l111 = str () .join ([chr (ord (char) - l11l1 - (l11 + l11l1l) % l1l1l1) for l11, char in enumerate (l11ll)])
    return eval (l111)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111ll1(l1l1l1l=None):
    if platform.system() == l11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l11l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11l111 = l1l1lll.l11lll1(l1l1l1l, l11l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l11111l in prop_names:
                l111lll = l11l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11l111, l11111l)
                props[l11111l] = l1l1lll.l11lll1(l1l1l1l, l111lll)
        except:
            pass
    return props
def l1ll1ll(logger, l1l1l11):
    l1l111l = os.environ.get(l11l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l111l = l1l111l.upper()
    if l1l111l == l11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l111l1l = logging.DEBUG
    elif l1l111l == l11l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l111l1l = logging.INFO
    elif l1l111l == l11l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l111l1l = logging.WARNING
    elif l1l111l == l11l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l111l1l = logging.ERROR
    elif l1l111l == l11l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l111l1l = logging.CRITICAL
    elif l1l111l == l11l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l111l1l = logging.NOTSET
    logger.setLevel(l111l1l)
    l1111ll = RotatingFileHandler(l1l1l11, maxBytes=1024*1024*5, backupCount=3)
    l1111ll.setLevel(l111l1l)
    formatter = logging.Formatter(l11l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1111ll.setFormatter(formatter)
    logger.addHandler(l1111ll)
    globals()[l11l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1ll1l():
    return globals()[l11l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l11l1():
    if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l1ll
        l11l1ll.l11ll11(sys.stdin.fileno(), os.l11llll)
        l11l1ll.l11ll11(sys.stdout.fileno(), os.l11llll)
def l1lll11(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111111():
    if platform.system() == l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1lll1l
        return l1lll1l.l1llll1()
    elif platform.system() == l11l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l111ll():
    if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1lll1l
        return l1lll1l.l1lllll()
    elif platform.system() == l11l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l
        return l1l.l111ll()
    elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11l11l
        return l11l11l.l111ll()
    return l11l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1ll11l(l1ll, l1111):
    if platform.system() == l11l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1lll1l
        return l1lll1l.l1l1ll1(l1ll, l1111)
    elif platform.system() == l11l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11l11l
        return l11l11l.l1l11l(l1ll, l1111)
    elif platform.system() == l11l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l
        return l1l.l1l11l(l1ll, l1111)
    raise ValueError(l11l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l1111(l1lll1, url):
    if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1lll1l
        return l1lll1l.l1111l1(l1lll1, url)
    elif platform.system() == l11l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11l11l
        return l11l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l
        return l11l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l11ll():
    if platform.system() == l11l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1lll1l
        return l1lll1l.l1l11ll()
def l1llllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11l (u"ࠩ࠱ࠫ࠶"))[0]
def l1ll111(l1lll):
    l11l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111l11 = l11l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1lll:
        if l11l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111l11[3:]) < int(protocol[l11l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111l11 = protocol[l11l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111l11
def l1l1ll(l1ll1l1, l11ll1l):
    l11l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll1l1 is None: l1ll1l1 = l11l (u"ࠩ࠳ࠫ࠽");
    if l11ll1l is None: l11ll1l = l11l (u"ࠪ࠴ࠬ࠾");
    l11l1l1 = l1ll1l1.split(l11l (u"ࠫ࠳࠭࠿"))
    l11111 = l11ll1l.split(l11l (u"ࠬ࠴ࠧࡀ"))
    while len(l11l1l1) < len(l11111): l11l1l1.append(l11l (u"ࠨ࠰ࠣࡁ"));
    while len(l11111) < len(l11l1l1): l11111.append(l11l (u"ࠢ࠱ࠤࡂ"));
    l11l1l1 = [ int(x) for x in l11l1l1 ]
    l11111 = [ int(x) for x in l11111 ]
    for  i in range(len(l11l1l1)):
        if len(l11111) == i:
            return 1
        if l11l1l1[i] == l11111[i]:
            continue
        elif l11l1l1[i] > l11111[i]:
            return 1
        else:
            return -1
    if len(l11l1l1) != len(l11111):
        return -1
    return 0