#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll = sys.version_info [0] == 2
l1l1ll = 2048
l1l1l1 = 7
def l1111 (l1ll):
    global l1ll1
    l1l = ord (l1ll [-1])
    l1lll1 = l1ll [:-1]
    l1llll = l1l % len (l1lll1)
    l1 = l1lll1 [:l1llll] + l1lll1 [l1llll:]
    if l111ll:
        l111l = l11l1l () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    else:
        l111l = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l1l) % l1l1l1) for l11l11, char in enumerate (l1)])
    return eval (l111l)
import os
import re
import subprocess
import l1lll
from l1lll import ll
def l1ll11():
    return []
def l1l11(l111l1, l1l1):
    logger = ll()
    l11l1 = []
    l11 = [l1111 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1111 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1111l = process.wait()
            l11ll1 = {}
            if l1111l == 0:
                l11ll = re.compile(l1111 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1l = re.compile(l1111 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l111 = re.search(l11ll, line)
                    l1l111 = l111.group(1)
                    if l111l1 == l1l111:
                        l1l11l = re.search(l1ll1l, line)
                        if l1l11l:
                            l1l1l = l1111 (u"ࠨࡦࡤࡺࠬࠄ")+l1l11l.group(1)
                            version = l111.group(0)
                            if not l1l1l in l11ll1:
                                l11ll1[l1l1l] = version
                            elif l1lll.l11l(version, l11ll1[l1l1l]) > 0:
                                l11ll1[l1l1l] = version
            for l1l1l in l11ll1:
                l11l1.append({l1111 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l11ll1[l1l1l], l1111 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1l})
        except Exception as e:
            logger.error(str(e))
    return l11l1