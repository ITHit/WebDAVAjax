#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1111l = 2048
l1l1 = 7
def l1l1ll (l1l11):
    global l11ll1
    l1ll11 = ord (l1l11 [-1])
    l111ll = l1l11 [:-1]
    l1lll = l1ll11 % len (l111ll)
    l1ll1l = l111ll [:l1lll] + l111ll [l1lll:]
    if l1llll:
        l1lll1 = l11l1l () .join ([unichr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1111l - (l111 + l1ll11) % l1l1) for l111, char in enumerate (l1ll1l)])
    return eval (l1lll1)
import os
import re
import subprocess
import l1
from l1 import l11l
def l11ll():
    return []
def l1ll1(l11l11, l1l1l1):
    logger = l11l()
    l1l1l = []
    l1l111 = [l1l1ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1l1ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l111:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            l111l = {}
            if l111l1 == 0:
                l11 = re.compile(l1l1ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                ll = re.compile(l1l1ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l = re.search(l11, line)
                    l11l1 = l1l.group(1)
                    if l11l11 == l11l1:
                        l1111 = re.search(ll, line)
                        if l1111:
                            l1ll = l1l1ll (u"ࠨࡦࡤࡺࠬࠄ")+l1111.group(1)
                            version = l1l.group(0)
                            if not l1ll in l111l:
                                l111l[l1ll] = version
                            elif l1.l1l11l(version, l111l[l1ll]) > 0:
                                l111l[l1ll] = version
            for l1ll in l111l:
                l1l1l.append({l1l1ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l111l[l1ll], l1l1ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll})
        except Exception as e:
            logger.error(str(e))
    return l1l1l