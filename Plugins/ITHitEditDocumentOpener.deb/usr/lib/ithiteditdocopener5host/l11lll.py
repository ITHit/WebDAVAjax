#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111l (l1111l):
    global l1l11l
    l111l1 = ord (l1111l [-1])
    l1l111 = l1111l [:-1]
    l111ll = l111l1 % len (l1l111)
    l1 = l1l111 [:l111ll] + l1l111 [l111ll:]
    if l111:
        l1l1 = l1lll () .join ([unichr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    else:
        l1l1 = str () .join ([chr (ord (char) - ll - (l1llll + l111l1) % l11) for l1llll, char in enumerate (l1)])
    return eval (l1l1)
import os
import re
import subprocess
import l1ll11
from l1ll11 import l11l
def l1l11():
    return []
def l1l1ll(l1ll1l, l11ll):
    logger = l11l()
    l11ll1 = []
    l11l11 = [l111l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l11l11:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l1111 = process.wait()
            l1ll = {}
            if l1111 == 0:
                l1l1l = re.compile(l111l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l11l1l = re.compile(l111l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l1l1 = re.search(l1l1l, line)
                    l1l = l1l1l1.group(1)
                    if l1ll1l == l1l:
                        l1lll1 = re.search(l11l1l, line)
                        if l1lll1:
                            l1ll1 = l111l (u"ࠨࡦࡤࡺࠬࠄ")+l1lll1.group(1)
                            version = l1l1l1.group(0)
                            if not l1ll1 in l1ll:
                                l1ll[l1ll1] = version
                            elif l1ll11.l11l1(version, l1ll[l1ll1]) > 0:
                                l1ll[l1ll1] = version
            for l1ll1 in l1ll:
                l11ll1.append({l111l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll[l1ll1], l111l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1ll1})
        except Exception as e:
            logger.error(str(e))
    return l11ll1