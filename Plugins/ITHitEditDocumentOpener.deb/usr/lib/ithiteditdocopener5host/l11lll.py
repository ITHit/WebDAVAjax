#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l11l1l = 2048
ll = 7
def l111l (l11):
    global l1lll
    l11l = ord (l11 [-1])
    l11ll1 = l11 [:-1]
    l1l1 = l11l % len (l11ll1)
    l1lll1 = l11ll1 [:l1l1] + l11ll1 [l1l1:]
    if l1ll1l:
        l111l1 = l1ll () .join ([unichr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l11l1l - (l1llll + l11l) % ll) for l1llll, char in enumerate (l1lll1)])
    return eval (l111l1)
import os
import re
import subprocess
import l1l11
from l1l11 import l1ll11
def l11l1():
    return []
def l1111l(l11ll, l111ll):
    logger = l1ll11()
    l1 = []
    l1l111 = [l111l (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l111l (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l111:
        try:
            output = os.popen(cmd).read()
            l1ll1 = 0
            l1111 = {}
            if l1ll1 == 0:
                l1l1ll = re.compile(l111l (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1l1 = re.compile(l111l (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l = re.search(l1l1ll, line)
                    l111 = l1l.group(1)
                    if l11ll == l111:
                        l11l11 = re.search(l1l1l1, line)
                        if l11l11:
                            l1l1l = l111l (u"ࠨࡦࡤࡺࠬࠄ")+l11l11.group(1)
                            version = l1l.group(0)
                            if not l1l1l in l1111:
                                l1111[l1l1l] = version
                            elif l1l11.l1l11l(version, l1111[l1l1l]) > 0:
                                l1111[l1l1l] = version
            for l1l1l in l1111:
                l1.append({l111l (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1111[l1l1l], l111l (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l1l})
        except Exception as e:
            logger.error(str(e))
    return l1