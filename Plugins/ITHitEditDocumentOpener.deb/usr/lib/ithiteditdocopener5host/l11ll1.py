#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1lll1 (l11):
    global l11l11
    l1111l = ord (l11 [-1])
    l1lll = l11 [:-1]
    l1l1ll = l1111l % len (l1lll)
    l1l = l1lll [:l1l1ll] + l1lll [l1l1ll:]
    if l1:
        l11ll = l1111 () .join ([unichr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    return eval (l11ll)
import os
import re
import subprocess
import l1l11
from l1l11 import l11lll
def l111():
    return []
def l1l111(l1l1, l111ll):
    logger = l11lll()
    l111l = []
    l1ll1 = [l1lll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1lll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l1 = process.wait()
            l1ll11 = {}
            if l111l1 == 0:
                l1llll = re.compile(l1lll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l11l = re.compile(l1lll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11l1l = re.search(l1llll, line)
                    l11l1 = l11l1l.group(1)
                    if l1l1 == l11l1:
                        ll = re.search(l1l11l, line)
                        if ll:
                            l11l = l1lll1 (u"ࠨࡦࡤࡺࠬࠄ")+ll.group(1)
                            version = l11l1l.group(0)
                            if not l11l in l1ll11:
                                l1ll11[l11l] = version
                            elif l1l11.l1l1l(version, l1ll11[l11l]) > 0:
                                l1ll11[l11l] = version
            for l11l in l1ll11:
                l111l.append({l1lll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll11[l11l], l1lll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l})
        except Exception as e:
            logger.error(str(e))
    return l111l