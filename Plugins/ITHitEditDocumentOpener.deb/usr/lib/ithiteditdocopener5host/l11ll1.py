#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
l1l1 = 2048
l111ll = 7
def l1lll1 (l11ll):
    global l1l1l
    l11 = ord (l11ll [-1])
    l1llll = l11ll [:-1]
    l1lll = l11 % len (l1llll)
    l1l = l1llll [:l1lll] + l1llll [l1lll:]
    if l1ll11:
        l1l111 = l11l1l () .join ([unichr (ord (char) - l1l1 - (l111l1 + l11) % l111ll) for l111l1, char in enumerate (l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1 - (l111l1 + l11) % l111ll) for l111l1, char in enumerate (l1l)])
    return eval (l1l111)
import os
import re
import subprocess
import l1111l
from l1111l import l1ll
def l11l1():
    return []
def l1111(ll, l11l11):
    logger = l1ll()
    l1l11 = []
    l1l1l1 = [l1lll1 (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l1lll1 (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1l1l1:
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            output, error = process.communicate()
            output = str(output)
            l111l = process.wait()
            l1ll1l = {}
            if l111l == 0:
                l11l = re.compile(l1lll1 (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1l1ll = re.compile(l1lll1 (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l11lll = re.search(l11l, line)
                    l1ll1 = l11lll.group(1)
                    if ll == l1ll1:
                        l1 = re.search(l1l1ll, line)
                        if l1:
                            l1l11l = l1lll1 (u"ࠨࡦࡤࡺࠬࠄ")+l1.group(1)
                            version = l11lll.group(0)
                            if not l1l11l in l1ll1l:
                                l1ll1l[l1l11l] = version
                            elif l1111l.l111(version, l1ll1l[l1l11l]) > 0:
                                l1ll1l[l1l11l] = version
            for l1l11l in l1ll1l:
                l1l11.append({l1lll1 (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1ll1l[l1l11l], l1lll1 (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l1l11l})
        except Exception as e:
            logger.error(str(e))
    return l1l11