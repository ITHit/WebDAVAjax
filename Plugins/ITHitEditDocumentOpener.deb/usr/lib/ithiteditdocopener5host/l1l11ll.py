#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l111 = 2048
l1lll = 7
def l11l1l (l1l11l):
    global l11lll
    l1l1l = ord (l1l11l [-1])
    l1l11 = l1l11l [:-1]
    l11l = l1l1l % len (l1l11)
    l11l1 = l1l11 [:l11l] + l1l11 [l11l:]
    if l1l1l1:
        l1l1ll = l1lll1 () .join ([unichr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    else:
        l1l1ll = str () .join ([chr (ord (char) - l111 - (l1ll11 + l1l1l) % l1lll) for l1ll11, char in enumerate (l11l1)])
    return eval (l1l1ll)
import subprocess, threading
from l111ll import l1ll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l11l1l1():
    l11l1lll = [l11l1l (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l1l (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l1l (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l1l (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1lll:
        try:
            l11ll1ll = l11l1l (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11lll11 = winreg.l11l1l1l(winreg.l1l11ll1, l11ll1ll)
        except l11l111l:
            continue
        value = winreg.l1l11l11(l11lll11, l11l1l (u"ࠦࠧ࢓"))
        return value.split(l11l1l (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l11l1():
    l11l1111 = []
    for name in l1l1l11l:
        try:
            l11ll1ll = l11l1l (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11l11ll = winreg.l11l1l1l(winreg.l1l11ll1, l11ll1ll)
            if winreg.l1l11l11(l11l11ll, l11l1l (u"ࠢࠣ࢖")):
                l11l1111.append(name)
        except l11l111l:
            continue
    return l11l1111
def l11ll1l(l1111, ll):
    import re
    l111l1 = []
    l11l1ll1 = winreg.l11l1l1l(winreg.l1l11ll1, l11l1l (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l111ll(l11l1ll1)[0]):
        try:
            l11lll1l = winreg.l11ll111(l11l1ll1, i)
            if l11lll1l.startswith(ll):
                l11l1l11 = winreg.l11l11l1(l11l1ll1, l11lll1l)
                value, l11ll1l1 = winreg.l11lllll(l11l1l11, l11l1l (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l1l (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11l1l = {l11l1l (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11lll = m.group(2)
                    if l1111 == l1l11lll:
                        m = re.search(ll.replace(l11l1l (u"ࠬ࠴࢛ࠧ"), l11l1l (u"࠭࡜࡝࠰ࠪ࢜")) + l11l1l (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll1l)
                        l1l11l1l[l11l1l (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111l1.append(l1l11l1l)
                else:
                    raise ValueError(l11l1l (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l111l1
def l1l11111(l1):
    try:
        l1l1111l = l11l1l (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1)
        l1l111l1 = winreg.l11l1l1l(winreg.l1l11ll1, l1l1111l)
        value, l11ll1l1 = winreg.l11lllll(l1l111l1, l11l1l (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l1l (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l11l1l (u"࠭ࠧࢣ")
def l1llllll(l1, url):
    threading.Thread(target=_11llll1,args=(l1, url)).start()
    return l11l1l (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11llll1(l1, url):
    logger = l1ll()
    l11ll11l = l1l11111(l1)
    logger.debug(l11l1l (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll11l, url))
    retcode = subprocess.Popen(l11l1l (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll11l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l1l (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l1l (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)