#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def ll (l111):
    global l111ll
    l1111l = ord (l111 [-1])
    l11ll1 = l111 [:-1]
    l1ll = l1111l % len (l11ll1)
    l1l11 = l11ll1 [:l1ll] + l11ll1 [l1ll:]
    if l1llll:
        l11ll = l1l () .join ([unichr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1lll1 - (l1l111 + l1111l) % l1l1l) for l1l111, char in enumerate (l1l11)])
    return eval (l11ll)
import l111l
from l1l1l111 import l1l11lll
import objc as _111lll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111lll1.l111ll11( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (ll (u"࠭ࡌࡔࡅࡲࡴࡾࡊࡥࡧࡣࡸࡰࡹࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡘࡖࡑࡌ࡯ࡳࡗࡕࡐࠬࢪ"), LaunchServices._1111111.l1111l11(l1111lll (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡎࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ"), l1111lll (u"ࠨࡠࡾࡣࡤࡉࡆࡖࡔࡏࡁࢂࡤࡻࡠࡡࡆࡊ࡚ࡘࡌ࠾ࡿࡌࡢࡣࢁ࡟ࡠࡅࡉࡉࡷࡸ࡯ࡳ࠿ࢀࠫࢬ")), ll (u"ࠩࠪࢭ"), {ll (u"ࠪࡶࡪࡺࡶࡢ࡮ࠪࢮ"): {ll (u"ࠫࡦࡲࡲࡦࡣࡧࡽࡤࡩࡦࡳࡧࡷࡥ࡮ࡴࡥࡥࠩࢯ"): True}, ll (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨࢰ"): {2: {ll (u"࠭࡮ࡶ࡮࡯ࡣࡦࡩࡣࡦࡲࡷࡩࡩ࠭ࢱ"): True, ll (u"ࠧࡢ࡮ࡵࡩࡦࡪࡹࡠࡥࡩࡶࡪࡺࡡࡪࡰࡨࡨࠬࢲ"): True, ll (u"ࠨࡶࡼࡴࡪࡥ࡭ࡰࡦ࡬ࡪ࡮࡫ࡲࠨࢳ"): ll (u"ࠩࡲࠫࢴ")}}}),
        ])
except:
    pass
def l11111l1(l1111ll1):
    l1111ll1 = (l1111ll1 + ll (u"ࠪ࠾ࠬࢵ")).encode()
    l111l11l = CFStringCreateWithCString( kCFAllocatorDefault, l1111ll1, kCFStringEncodingUTF8 )
    l111l1ll = CFURLCreateWithString( kCFAllocatorDefault, l111l11l, _111lll1.nil )
    l11111ll = LaunchServices.l111ll1l( l111l1ll, LaunchServices.l1lllllll, _111lll1.nil )
    if l11111ll[0] is not None:
        return True
    return False
def l11():
    l111l1l1 = []
    for name in l1l11lll:
        try:
            if l11111l1(name):
                l111l1l1.append(name)
        except:
            continue
    return l111l1l1
def l1111(l11l11, l1l1l1):
    import plistlib
    import os
    l1ll1 = []
    l111l1 = {}
    for l111111l in os.listdir(ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶࠦࢶ")):
        if l111111l.startswith(l1l1l1):
            try:
                l1111l1l = ll (u"ࠧ࠵ࡁࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡷ࠴ࠫࡳ࠰ࡅࡲࡲࡹ࡫࡮ࡵࡵ࠲ࡍࡳ࡬࡯࠯ࡲ࡯࡭ࡸࡺࠢࢷ") % l111111l
                with open(l1111l1l, ll (u"࠭ࡲࡣࠩࢸ")) as f:
                    plist = plistlib.load(f)
                    l1ll11 = plist[ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐ࡙ࡿࡰࡦࡵࠥࢹ")][0][ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧࡘࡖࡑ࡙ࡣࡩࡧࡰࡩࡸࠨࢺ")][0]
                    version = plist[ll (u"ࠤࡆࡊࡇࡻ࡮ࡥ࡮ࡨ࡚ࡪࡸࡳࡪࡱࡱࠦࢻ")]
                    l111l111 = version.split(ll (u"ࠥ࠲ࠧࢼ"))[0]
                    if l11l11 == l111l111:
                        if not l1ll11 in l111l1:
                            l111l1[l1ll11] = version
                        elif l111l.l1l11l(version, l111l1[l1ll11]) > 0:
                            l111l1[l1ll11] = version
            except BaseException:
                continue
    for l1ll11 in l111l1:
        l1ll1.append({ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬࢽ"): l111l1[l1ll11], ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧࢾ"): l1ll11})
    return l1ll1