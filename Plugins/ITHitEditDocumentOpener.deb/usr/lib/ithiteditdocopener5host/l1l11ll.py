#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l1l1 = 2048
l1ll1l = 7
def l1lll1 (l11):
    global l11l11
    l1111l = ord (l11 [-1])
    l1lll = l11 [:-1]
    l1l1ll = l1111l % len (l1lll)
    l1l = l1lll [:l1l1ll] + l1lll [l1l1ll:]
    if l1:
        l11ll = l1111 () .join ([unichr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l1l1 - (l1ll + l1111l) % l1ll1l) for l1ll, char in enumerate (l1l)])
    return eval (l11ll)
import subprocess, threading
from l1l11 import l11lll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l111ll1():
    l11l1ll1 = [l1lll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1lll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1lll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1lll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1ll1:
        try:
            l11llll1 = l1lll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11ll1l1 = winreg.l11l111l(winreg.l11lll1l, l11llll1)
        except l11l11ll:
            continue
        value = winreg.l11lll11(l11ll1l1, l1lll1 (u"ࠦࠧ࢓"))
        return value.split(l1lll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1llll1():
    l1l11l1l = []
    for name in l1l1l11l:
        try:
            l11llll1 = l1lll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11lll = winreg.l11l111l(winreg.l11lll1l, l11llll1)
            if winreg.l11lll11(l1l11lll, l1lll1 (u"ࠢࠣ࢖")):
                l1l11l1l.append(name)
        except l11l11ll:
            continue
    return l1l11l1l
def l1l1l11(l1l1, l111ll):
    import re
    l111l = []
    l11ll11l = winreg.l11l111l(winreg.l11lll1l, l1lll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l1111l(l11ll11l)[0]):
        try:
            l11l1l1l = winreg.l1l111l1(l11ll11l, i)
            if l11l1l1l.startswith(l111ll):
                l11l1lll = winreg.l11lllll(l11ll11l, l11l1l1l)
                value, l11l1111 = winreg.l11l1l11(l11l1lll, l1lll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1lll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l11111 = {l1lll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11l1 = m.group(2)
                    if l1l1 == l11l11l1:
                        m = re.search(l111ll.replace(l1lll1 (u"ࠬ࠴࢛ࠧ"), l1lll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1lll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1l1l)
                        l1l11111[l1lll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l111l.append(l1l11111)
                else:
                    raise ValueError(l1lll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l11ll as ex:
            continue
    return l111l
def l11ll1ll(l11l):
    try:
        l1l111ll = l1lll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l)
        l11ll111 = winreg.l11l111l(winreg.l11lll1l, l1l111ll)
        value, l11l1111 = winreg.l11l1l11(l11ll111, l1lll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1lll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11l11ll:
        pass
    return l1lll1 (u"࠭ࠧࢣ")
def l11ll1l(l11l, url):
    threading.Thread(target=_1l11ll1,args=(l11l, url)).start()
    return l1lll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l11ll1(l11l, url):
    logger = l11lll()
    l1l11l11 = l11ll1ll(l11l)
    logger.debug(l1lll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l11l11, url))
    retcode = subprocess.Popen(l1lll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l11l11, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1lll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1lll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)