#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1l = 2048
l11 = 7
def l11l1 (l11l):
    global l111
    l11lll = ord (l11l [-1])
    l1ll1l = l11l [:-1]
    l111ll = l11lll % len (l1ll1l)
    l111l1 = l1ll1l [:l111ll] + l1ll1l [l111ll:]
    if l111l:
        l1ll = l1111l () .join ([unichr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1l - (ll + l11lll) % l11) for ll, char in enumerate (l111l1)])
    return eval (l1ll)
import subprocess, threading
from l1 import l1lll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l111 import l1l1l11l
def l111111():
    l1l11111 = [l11l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11111:
        try:
            l1l111l1 = l11l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l11l1111 = winreg.l1l11l1l(winreg.l1l11ll1, l1l111l1)
        except l11l1l1l:
            continue
        value = winreg.l11ll11l(l11l1111, l11l1 (u"ࠦࠧ࢓"))
        return value.split(l11l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1lll():
    l11l11ll = []
    for name in l1l1l11l:
        try:
            l1l111l1 = l11l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l11 = winreg.l1l11l1l(winreg.l1l11ll1, l1l111l1)
            if winreg.l11ll11l(l1l11l11, l11l1 (u"ࠢࠣ࢖")):
                l11l11ll.append(name)
        except l11l1l1l:
            continue
    return l11l11ll
def l11111l(l11l1l, l1ll1):
    import re
    l11ll1 = []
    l11l11l1 = winreg.l1l11l1l(winreg.l1l11ll1, l11l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11l1l11(l11l11l1)[0]):
        try:
            l11lll11 = winreg.l11lll1l(l11l11l1, i)
            if l11lll11.startswith(l1ll1):
                l11ll111 = winreg.l11l111l(l11l11l1, l11lll11)
                value, l1l1111l = winreg.l11llll1(l11ll111, l11l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1lll = {l11l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l1l11lll = m.group(2)
                    if l11l1l == l1l11lll:
                        m = re.search(l1ll1.replace(l11l1 (u"ࠬ࠴࢛ࠧ"), l11l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l11l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11lll11)
                        l11l1lll[l11l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l11ll1.append(l11l1lll)
                else:
                    raise ValueError(l11l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l1l1l as ex:
            continue
    return l11ll1
def l11ll1ll(l1l11l):
    try:
        l11ll1l1 = l11l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l11l)
        l1l111ll = winreg.l1l11l1l(winreg.l1l11ll1, l11ll1l1)
        value, l1l1111l = winreg.l11llll1(l1l111ll, l11l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11l1 (u"ࠬࠨࠧࢢ"))[1]
    except l11l1l1l:
        pass
    return l11l1 (u"࠭ࠧࢣ")
def l1lll11(l1l11l, url):
    threading.Thread(target=_11l1ll1,args=(l1l11l, url)).start()
    return l11l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11l1ll1(l1l11l, url):
    logger = l1lll()
    l11lllll = l11ll1ll(l1l11l)
    logger.debug(l11l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11lllll, url))
    retcode = subprocess.Popen(l11l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11lllll, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)