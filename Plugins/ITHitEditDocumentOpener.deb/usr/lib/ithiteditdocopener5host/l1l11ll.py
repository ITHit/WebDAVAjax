#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1 = sys.version_info [0] == 2
l1l111 = 2048
l11ll1 = 7
def l1l1 (l11):
    global l1ll11
    l1llll = ord (l11 [-1])
    l1ll1 = l11 [:-1]
    l111l = l1llll % len (l1ll1)
    l1111l = l1ll1 [:l111l] + l1ll1 [l111l:]
    if l1l1l1:
        ll = l1l1l () .join ([unichr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    else:
        ll = str () .join ([chr (ord (char) - l1l111 - (l1lll + l1llll) % l11ll1) for l1lll, char in enumerate (l1111l)])
    return eval (ll)
import subprocess, threading
from l1l1ll import l11lll
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l11ll11():
    l11l1111 = [l1l1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1l1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1l1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1l1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l11l1111:
        try:
            l11ll1ll = l1l1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11lll = winreg.l11l1l11(winreg.l11l1l1l, l11ll1ll)
        except l11ll11l:
            continue
        value = winreg.l1l11l1l(l1l11lll, l1l1 (u"ࠦࠧ࢓"))
        return value.split(l1l1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1111ll():
    l1l11ll1 = []
    for name in l1l1l111:
        try:
            l11ll1ll = l1l1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l11lll1l = winreg.l11l1l11(winreg.l11l1l1l, l11ll1ll)
            if winreg.l1l11l1l(l11lll1l, l1l1 (u"ࠢࠣ࢖")):
                l1l11ll1.append(name)
        except l11ll11l:
            continue
    return l1l11ll1
def l11l1ll(l11l1l, l1):
    import re
    l1lll1 = []
    l11l111l = winreg.l11l1l11(winreg.l11l1l1l, l1l1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l1l11l11(l11l111l)[0]):
        try:
            l11llll1 = winreg.l11l11l1(l11l111l, i)
            if l11llll1.startswith(l1):
                l1l111ll = winreg.l11ll1l1(l11l111l, l11llll1)
                value, l1l111l1 = winreg.l11l1lll(l1l111ll, l1l1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1l1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l11ll = {l1l1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11ll111 = m.group(2)
                    if l11l1l == l11ll111:
                        m = re.search(l1.replace(l1l1 (u"ࠬ࠴࢛ࠧ"), l1l1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1l1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11llll1)
                        l11l11ll[l1l1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1lll1.append(l11l11ll)
                else:
                    raise ValueError(l1l1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11ll11l as ex:
            continue
    return l1lll1
def l11l1ll1(l1l):
    try:
        l1l11111 = l1l1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1l)
        l11lll11 = winreg.l11l1l11(winreg.l11l1l1l, l1l11111)
        value, l1l111l1 = winreg.l11l1lll(l11lll11, l1l1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1l1 (u"ࠬࠨࠧࢢ"))[1]
    except l11ll11l:
        pass
    return l1l1 (u"࠭ࠧࢣ")
def l1l1ll1(l1l, url):
    threading.Thread(target=_11lllll,args=(l1l, url)).start()
    return l1l1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lllll(l1l, url):
    logger = l11lll()
    l1l1111l = l11l1ll1(l1l)
    logger.debug(l1l1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l1l1111l, url))
    retcode = subprocess.Popen(l1l1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l1l1111l, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1l1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1l1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)