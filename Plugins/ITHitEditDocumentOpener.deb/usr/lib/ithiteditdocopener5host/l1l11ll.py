#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
ll = sys.version_info [0] == 2
l1l1ll = 2048
l1111 = 7
def l11l (l111ll):
    global l1l111
    l111l1 = ord (l111ll [-1])
    l1111l = l111ll [:-1]
    l11 = l111l1 % len (l1111l)
    l1ll1l = l1111l [:l11] + l1111l [l11:]
    if ll:
        l1l1l1 = l11l1 () .join ([unichr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1ll - (l11l11 + l111l1) % l1111) for l11l11, char in enumerate (l1ll1l)])
    return eval (l1l1l1)
import l1ll
from l1l1l11l import l1l1l111
import objc as _1111ll1
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _1111ll1.l111lll1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11l (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111l1ll.l111l1l1(l111ll11 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l111ll11 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11l (u"ࠨࠩࢬ"), {l11l (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11l (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11l (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11l (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11l (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11l (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11l (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l1111l1l(l1111l11):
    l1111l11 = (l1111l11 + l11l (u"ࠩ࠽ࠫࢴ")).encode()
    l1111lll = CFStringCreateWithCString( kCFAllocatorDefault, l1111l11, kCFStringEncodingUTF8 )
    l1111111 = CFURLCreateWithString( kCFAllocatorDefault, l1111lll, _1111ll1.nil )
    l111llll = LaunchServices.l11111l1( l1111111, LaunchServices.l111l111, _1111ll1.nil )
    if l111llll[0] is not None:
        return True
    return False
def l11ll1():
    l111ll1l = []
    for name in l1l1l111:
        try:
            if l1111l1l(name):
                l111ll1l.append(name)
        except:
            continue
    return l111ll1l
def l1ll11(l1l1l, l111l):
    import plistlib
    import os
    l1lll1 = []
    l1l = {}
    for l11111ll in os.listdir(l11l (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l11111ll.startswith(l111l):
            try:
                l111l11l = l11l (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l11111ll
                with open(l111l11l, l11l (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l1 = plist[l11l (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11l (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11l (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111111l = version.split(l11l (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1l1l == l111111l:
                        if not l1 in l1l:
                            l1l[l1] = version
                        elif l1ll.l1lll(version, l1l[l1]) > 0:
                            l1l[l1] = version
            except BaseException:
                continue
    for l1 in l1l:
        l1lll1.append({l11l (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l[l1], l11l (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l1})
    return l1lll1