#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l = sys.version_info [0] == 2
l1ll = 2048
l1111 = 7
def l1ll1 (l1ll1l):
    global l111ll
    l11ll = ord (l1ll1l [-1])
    l111 = l1ll1l [:-1]
    l111l1 = l11ll % len (l111)
    ll = l111 [:l111l1] + l111 [l111l1:]
    if l111l:
        l1l = l1l111 () .join ([unichr (ord (char) - l1ll - (l1l1l1 + l11ll) % l1111) for l1l1l1, char in enumerate (ll)])
    else:
        l1l = str () .join ([chr (ord (char) - l1ll - (l1l1l1 + l11ll) % l1111) for l1l1l1, char in enumerate (ll)])
    return eval (l1l)
import subprocess, threading
from l1l11 import l11l
try:
    import _winreg as winreg
except:
    import winreg
from l1l1l11l import l1l1l111
def l1ll11l():
    l1l11111 = [l1ll1 (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l1ll1 (u"ࠢࡘࡱࡵࡨࠧ࢏"), l1ll1 (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l1ll1 (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11111:
        try:
            l11l1l1l = l1ll1 (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l1111l = winreg.l1l11ll1(winreg.l11l1lll, l11l1l1l)
        except l11l111l:
            continue
        value = winreg.l11ll1ll(l1l1111l, l1ll1 (u"ࠦࠧ࢓"))
        return value.split(l1ll1 (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l1l1l11():
    l11ll1l1 = []
    for name in l1l1l111:
        try:
            l11l1l1l = l1ll1 (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l11l11 = winreg.l1l11ll1(winreg.l11l1lll, l11l1l1l)
            if winreg.l11ll1ll(l1l11l11, l1ll1 (u"ࠢࠣ࢖")):
                l11ll1l1.append(name)
        except l11l111l:
            continue
    return l11ll1l1
def l1ll1ll(l11ll1, l11l11):
    import re
    l1lll1 = []
    l11lllll = winreg.l1l11ll1(winreg.l11l1lll, l1ll1 (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, winreg.l11lll1l(l11lllll)[0]):
        try:
            l1l11lll = winreg.l11l1111(l11lllll, i)
            if l1l11lll.startswith(l11l11):
                l1l111ll = winreg.l11ll111(l11lllll, l1l11lll)
                value, l11ll11l = winreg.l11l1ll1(l1l111ll, l1ll1 (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l1ll1 (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l1l111l1 = {l1ll1 (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l11l1 = m.group(2)
                    if l11ll1 == l11l11l1:
                        m = re.search(l11l11.replace(l1ll1 (u"ࠬ࠴࢛ࠧ"), l1ll1 (u"࠭࡜࡝࠰ࠪ࢜")) + l1ll1 (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l1l11lll)
                        l1l111l1[l1ll1 (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1lll1.append(l1l111l1)
                else:
                    raise ValueError(l1ll1 (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l111l as ex:
            continue
    return l1lll1
def l11l11ll(l1111l):
    try:
        l11l1l11 = l1ll1 (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l1111l)
        l1l11l1l = winreg.l1l11ll1(winreg.l11l1lll, l11l1l11)
        value, l11ll11l = winreg.l11l1ll1(l1l11l1l, l1ll1 (u"ࠫࠬࢡ"))
        if value:
            return value.split(l1ll1 (u"ࠬࠨࠧࢢ"))[1]
    except l11l111l:
        pass
    return l1ll1 (u"࠭ࠧࢣ")
def l1llllll(l1111l, url):
    threading.Thread(target=_11lll11,args=(l1111l, url)).start()
    return l1ll1 (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _11lll11(l1111l, url):
    logger = l11l()
    l11llll1 = l11l11ll(l1111l)
    logger.debug(l1ll1 (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11llll1, url))
    retcode = subprocess.Popen(l1ll1 (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11llll1, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l1ll1 (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l1ll1 (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)