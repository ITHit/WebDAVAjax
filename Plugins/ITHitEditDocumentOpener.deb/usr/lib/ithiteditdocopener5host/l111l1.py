#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll = sys.version_info [0] == 2
l1ll1 = 2048
l11l = 7
def ll (l1):
    global l1l
    l1llll = ord (l1 [-1])
    l1l111 = l1 [:-1]
    l1l1l1 = l1llll % len (l1l111)
    l11lll = l1l111 [:l1l1l1] + l1l111 [l1l1l1:]
    if l11ll:
        l111 = l11l11 () .join ([unichr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    else:
        l111 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l1llll) % l11l) for l111l, char in enumerate (l11lll)])
    return eval (l111)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11ll1l(l1llll1=None):
    if platform.system() == ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11lll1
        props = {}
        try:
            prop_names = (ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1l11l1 = l11lll1.l11111l(l1llll1, ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1lll11 in prop_names:
                l1111ll = ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1l11l1, l1lll11)
                props[l1lll11] = l11lll1.l11111l(l1llll1, l1111ll)
        except:
            pass
    return props
def l1l1l1l(logger, l11l11l):
    l111lll = os.environ.get(ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l111lll = l111lll.upper()
    if l111lll == ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11l1ll = logging.DEBUG
    elif l111lll == ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11l1ll = logging.INFO
    elif l111lll == ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11l1ll = logging.WARNING
    elif l111lll == ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11l1ll = logging.ERROR
    elif l111lll == ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11l1ll = logging.CRITICAL
    elif l111lll == ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11l1ll = logging.NOTSET
    logger.setLevel(l11l1ll)
    l1lllll = RotatingFileHandler(l11l11l, maxBytes=1024*1024*5, backupCount=3)
    l1lllll.setLevel(l11l1ll)
    formatter = logging.Formatter(ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lllll.setFormatter(formatter)
    logger.addHandler(l1lllll)
    globals()[ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1111l():
    return globals()[ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll1ll():
    if platform.system() == ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1l1lll
        l1l1lll.l11111(sys.stdin.fileno(), os.l11l111)
        l1l1lll.l11111(sys.stdout.fileno(), os.l11l111)
def l1lll1l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1ll1():
    if platform.system() == ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1llllll
        return l1llllll.l1l111l()
    elif platform.system() == ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11ll1():
    if platform.system() == ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1llllll
        return l1llllll.l111ll1()
    elif platform.system() == ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll1l
        return l1ll1l.l11ll1()
    elif platform.system() == ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1ll1l1
        return l1ll1l1.l11ll1()
    return ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l1l1l11(l1111, l11l1):
    if platform.system() == ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1llllll
        return l1llllll.l1l1111(l1111, l11l1)
    elif platform.system() == ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1ll1l1
        return l1ll1l1.l1lll(l1111, l11l1)
    elif platform.system() == ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll1l
        return l1ll1l.l1lll(l1111, l11l1)
    raise ValueError(ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l111111(l11l1l, url):
    if platform.system() == ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1llllll
        return l1llllll.l11ll11(l11l1l, url)
    elif platform.system() == ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1ll1l1
        return ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll1l
        return ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1111l1():
    if platform.system() == ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1llllll
        return l1llllll.l1111l1()
def l11l1l1(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(ll (u"ࠩ࠱ࠫ࠶"))[0]
def l11llll(l1lll1):
    ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l111l11 = ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1lll1:
        if ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l111l11[3:]) < int(protocol[ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l111l11 = protocol[ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l111l11
def l1ll11(l111l1l, l1l11ll):
    ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l111l1l is None: l111l1l = ll (u"ࠩ࠳ࠫ࠽");
    if l1l11ll is None: l1l11ll = ll (u"ࠪ࠴ࠬ࠾");
    l1ll111 = l111l1l.split(ll (u"ࠫ࠳࠭࠿"))
    l1ll11l = l1l11ll.split(ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll111) < len(l1ll11l): l1ll111.append(ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1ll11l) < len(l1ll111): l1ll11l.append(ll (u"ࠢ࠱ࠤࡂ"));
    l1ll111 = [ int(x) for x in l1ll111 ]
    l1ll11l = [ int(x) for x in l1ll11l ]
    for  i in range(len(l1ll111)):
        if len(l1ll11l) == i:
            return 1
        if l1ll111[i] == l1ll11l[i]:
            continue
        elif l1ll111[i] > l1ll11l[i]:
            return 1
        else:
            return -1
    if len(l1ll111) != len(l1ll11l):
        return -1
    return 0