#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11 = sys.version_info [0] == 2
ll = 2048
l11 = 7
def l111ll (l1l1l):
    global l11ll
    l1111l = ord (l1l1l [-1])
    l11l = l1l1l [:-1]
    l11l1l = l1111l % len (l11l)
    l1l11l = l11l [:l11l1l] + l11l [l11l1l:]
    if l1ll11:
        l1ll1l = l1l1l1 () .join ([unichr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - ll - (l111l + l1111l) % l11) for l111l, char in enumerate (l1l11l)])
    return eval (l1ll1l)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll11l(l1lll1l=None):
    if platform.system() == l111ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l1l1lll
        props = {}
        try:
            prop_names = (l111ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l11ll11 = l1l1lll.l111l11(l1lll1l, l111ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l1l11 in prop_names:
                l111l1l = l111ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l11ll11, l1l1l11)
                props[l1l1l11] = l1l1lll.l111l11(l1lll1l, l111l1l)
        except:
            pass
    return props
def l11l11l(logger, l1l1l1l):
    l1l11ll = os.environ.get(l111ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1l11ll = l1l11ll.upper()
    if l1l11ll == l111ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l1l111l = logging.DEBUG
    elif l1l11ll == l111ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l1l111l = logging.INFO
    elif l1l11ll == l111ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l1l111l = logging.WARNING
    elif l1l11ll == l111ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l1l111l = logging.ERROR
    elif l1l11ll == l111ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l1l111l = logging.CRITICAL
    elif l1l11ll == l111ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l1l111l = logging.NOTSET
    logger.setLevel(l1l111l)
    l11111 = RotatingFileHandler(l1l1l1l, maxBytes=1024*1024*5, backupCount=3)
    l11111.setLevel(l1l111l)
    formatter = logging.Formatter(l111ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l11111.setFormatter(formatter)
    logger.addHandler(l11111)
    globals()[l111ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l1():
    return globals()[l111ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l11l1ll():
    if platform.system() == l111ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11111l
        l11111l.l1111l1(sys.stdin.fileno(), os.l1ll1l1)
        l11111l.l1111l1(sys.stdout.fileno(), os.l1ll1l1)
def l1l11l1(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l111():
    if platform.system() == l111ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l111ll1
        return l111ll1.l1llll1()
    elif platform.system() == l111ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11lll():
    if platform.system() == l111ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l111ll1
        return l111ll1.l11llll()
    elif platform.system() == l111ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l111
        return l1l111.l11lll()
    elif platform.system() == l111ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l111lll
        return l111lll.l11lll()
    return l111ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11lll1(l1l11, l11l1):
    if platform.system() == l111ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l111ll1
        return l111ll1.l1ll111(l1l11, l11l1)
    elif platform.system() == l111ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l111lll
        return l111lll.l1l1ll(l1l11, l11l1)
    elif platform.system() == l111ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l111
        return l1l111.l1l1ll(l1l11, l11l1)
    raise ValueError(l111ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1ll1ll(l1lll1, url):
    if platform.system() == l111ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l111ll1
        return l111ll1.l11l1l1(l1lll1, url)
    elif platform.system() == l111ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l111lll
        return l111ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l111
        return l111ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1llllll():
    if platform.system() == l111ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l111ll1
        return l111ll1.l1llllll()
def l1lllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111ll (u"ࠩ࠱ࠫ࠶"))[0]
def l111111(l1ll1):
    l111ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11ll1l = l111ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1:
        if l111ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11ll1l[3:]) < int(protocol[l111ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11ll1l = protocol[l111ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11ll1l
def l1ll(l1l1111, l1l1ll1):
    l111ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1l1111 is None: l1l1111 = l111ll (u"ࠩ࠳ࠫ࠽");
    if l1l1ll1 is None: l1l1ll1 = l111ll (u"ࠪ࠴ࠬ࠾");
    l1111ll = l1l1111.split(l111ll (u"ࠫ࠳࠭࠿"))
    l1lll11 = l1l1ll1.split(l111ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1111ll) < len(l1lll11): l1111ll.append(l111ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1lll11) < len(l1111ll): l1lll11.append(l111ll (u"ࠢ࠱ࠤࡂ"));
    l1111ll = [ int(x) for x in l1111ll ]
    l1lll11 = [ int(x) for x in l1lll11 ]
    for  i in range(len(l1111ll)):
        if len(l1lll11) == i:
            return 1
        if l1111ll[i] == l1lll11[i]:
            continue
        elif l1111ll[i] > l1lll11[i]:
            return 1
        else:
            return -1
    if len(l1111ll) != len(l1lll11):
        return -1
    return 0