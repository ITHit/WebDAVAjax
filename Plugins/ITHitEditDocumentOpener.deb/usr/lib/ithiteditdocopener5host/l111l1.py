#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1 = sys.version_info [0] == 2
l1l1l = 2048
l1111 = 7
def l1ll (l11l):
    global l1ll1l
    l1lll1 = ord (l11l [-1])
    l1lll = l11l [:-1]
    ll = l1lll1 % len (l1lll)
    l1ll1 = l1lll [:ll] + l1lll [ll:]
    if l11l1:
        l1llll = l1l1 () .join ([unichr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    else:
        l1llll = str () .join ([chr (ord (char) - l1l1l - (l111ll + l1lll1) % l1111) for l111ll, char in enumerate (l1ll1)])
    return eval (l1llll)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l1ll1l1(l111ll1=None):
    if platform.system() == l1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11ll11
        props = {}
        try:
            prop_names = (l1ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l1ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l1ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l1ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l1ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l1ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l1ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l1ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l1ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l1ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l1ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l1ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111l11 = l11ll11.l11111l(l111ll1, l1ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1lll11 in prop_names:
                l1llll1 = l1ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111l11, l1lll11)
                props[l1lll11] = l11ll11.l11111l(l111ll1, l1llll1)
        except:
            pass
    return props
def l1ll111(logger, l11111):
    l1llllll = os.environ.get(l1ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l1ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l1llllll = l1llllll.upper()
    if l1llllll == l1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11l1ll = logging.DEBUG
    elif l1llllll == l1ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11l1ll = logging.INFO
    elif l1llllll == l1ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11l1ll = logging.WARNING
    elif l1llllll == l1ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11l1ll = logging.ERROR
    elif l1llllll == l1ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11l1ll = logging.CRITICAL
    elif l1llllll == l1ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11l1ll = logging.NOTSET
    logger.setLevel(l11l1ll)
    l1l1ll1 = RotatingFileHandler(l11111, maxBytes=1024*1024*5, backupCount=3)
    l1l1ll1.setLevel(l11l1ll)
    formatter = logging.Formatter(l1ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l1ll1.setFormatter(formatter)
    logger.addHandler(l1l1ll1)
    globals()[l1ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l11lll():
    return globals()[l1ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1ll1ll():
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l1ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l11l111
        l11l111.l1ll11l(sys.stdin.fileno(), os.l111111)
        l11l111.l1ll11l(sys.stdout.fileno(), os.l111111)
def l1l1lll(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l1ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l1l():
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l11llll
        return l11llll.l1l1l11()
    elif platform.system() == l1ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l11l():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l11llll
        return l11llll.l1111ll()
    elif platform.system() == l1ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1l11
        return l1l11.l1l11l()
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1l1l
        return l1l1l1l.l1l11l()
    return l1ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11l1l1(l11ll, l11ll1):
    if platform.system() == l1ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l11llll
        return l11llll.l1111l1(l11ll, l11ll1)
    elif platform.system() == l1ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1l1l
        return l1l1l1l.l1l111(l11ll, l11ll1)
    elif platform.system() == l1ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1l11
        return l1l11.l1l111(l11ll, l11ll1)
    raise ValueError(l1ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l1l11l1(l1111l, url):
    if platform.system() == l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l11llll
        return l11llll.l1l111l(l1111l, url)
    elif platform.system() == l1ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1l1l
        return l1ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l1ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1l11
        return l1ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l1ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l111lll():
    if platform.system() == l1ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l11llll
        return l11llll.l111lll()
def l1lllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l1ll (u"ࠩ࠱ࠫ࠶"))[0]
def l11lll1(l11l11):
    l1ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l11l = l1ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l11l11:
        if l1ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l11l[3:]) < int(protocol[l1ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l11l = protocol[l1ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l11l
def l1l1ll(l11ll1l, l1l11ll):
    l1ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11ll1l is None: l11ll1l = l1ll (u"ࠩ࠳ࠫ࠽");
    if l1l11ll is None: l1l11ll = l1ll (u"ࠪ࠴ࠬ࠾");
    l1l1111 = l11ll1l.split(l1ll (u"ࠫ࠳࠭࠿"))
    l1lll1l = l1l11ll.split(l1ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1111) < len(l1lll1l): l1l1111.append(l1ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1lll1l) < len(l1l1111): l1lll1l.append(l1ll (u"ࠢ࠱ࠤࡂ"));
    l1l1111 = [ int(x) for x in l1l1111 ]
    l1lll1l = [ int(x) for x in l1lll1l ]
    for  i in range(len(l1l1111)):
        if len(l1lll1l) == i:
            return 1
        if l1l1111[i] == l1lll1l[i]:
            continue
        elif l1l1111[i] > l1lll1l[i]:
            return 1
        else:
            return -1
    if len(l1l1111) != len(l1lll1l):
        return -1
    return 0