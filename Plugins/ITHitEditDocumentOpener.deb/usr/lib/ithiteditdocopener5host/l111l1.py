#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l1l = 2048
l1l1l1 = 7
def l111l (l11ll):
    global l1l1l
    l1l1ll = ord (l11ll [-1])
    l11l11 = l11ll [:-1]
    l11l1l = l1l1ll % len (l11l11)
    l1l111 = l11l11 [:l11l1l] + l11l11 [l11l1l:]
    if l1:
        l1lll1 = ll () .join ([unichr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    else:
        l1lll1 = str () .join ([chr (ord (char) - l1l - (l1ll11 + l1l1ll) % l1l1l1) for l1ll11, char in enumerate (l1l111)])
    return eval (l1lll1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l11111(l1ll1l1=None):
    if platform.system() == l111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l11lll1
        props = {}
        try:
            prop_names = (l111l (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l111l (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l111l (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l111l (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l111l (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l111l (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l111l (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l111l (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l111l (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l111l (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l111l (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l111l (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l111ll1 = l11lll1.l11ll11(l1ll1l1, l111l (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1llll1 in prop_names:
                l111111 = l111l (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l111ll1, l1llll1)
                props[l1llll1] = l11lll1.l11ll11(l1ll1l1, l111111)
        except:
            pass
    return props
def l1111l1(logger, l1l11l1):
    l11l111 = os.environ.get(l111l (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l111l (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l111 = l11l111.upper()
    if l11l111 == l111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11ll1l = logging.DEBUG
    elif l11l111 == l111l (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11ll1l = logging.INFO
    elif l11l111 == l111l (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11ll1l = logging.WARNING
    elif l11l111 == l111l (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11ll1l = logging.ERROR
    elif l11l111 == l111l (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11ll1l = logging.CRITICAL
    elif l11l111 == l111l (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11ll1l = logging.NOTSET
    logger.setLevel(l11ll1l)
    l1lll11 = RotatingFileHandler(l1l11l1, maxBytes=1024*1024*5, backupCount=3)
    l1lll11.setLevel(l11ll1l)
    formatter = logging.Formatter(l111l (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1lll11.setFormatter(formatter)
    logger.addHandler(l1lll11)
    globals()[l111l (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l111ll():
    return globals()[l111l (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1ll1():
    if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l111l (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1ll1ll
        l1ll1ll.l11l1ll(sys.stdin.fileno(), os.l1l1lll)
        l1ll1ll.l11l1ll(sys.stdout.fileno(), os.l1l1lll)
def l1ll11l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l111l (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1111ll():
    if platform.system() == l111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1l111l
        return l1l111l.l1l1l1l()
    elif platform.system() == l111l (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l11lll():
    if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1l111l
        return l1l111l.l11l11l()
    elif platform.system() == l111l (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l11l1
        return l11l1.l11lll()
    elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l11111l
        return l11111l.l11lll()
    return l111l (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l111lll(l1ll1l, l1llll):
    if platform.system() == l111l (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1l111l
        return l1l111l.l1lll1l(l1ll1l, l1llll)
    elif platform.system() == l111l (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l11111l
        return l11111l.l1l11l(l1ll1l, l1llll)
    elif platform.system() == l111l (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l11l1
        return l11l1.l1l11l(l1ll1l, l1llll)
    raise ValueError(l111l (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11llll(l11, url):
    if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1l111l
        return l1l111l.l111l1l(l11, url)
    elif platform.system() == l111l (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l11111l
        return l111l (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l111l (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l11l1
        return l111l (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l111l (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1llllll():
    if platform.system() == l111l (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1l111l
        return l1l111l.l1llllll()
def l1lllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l111l (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1111(l1ll1):
    l111l (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l11l1l1 = l111l (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1ll1:
        if l111l (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l11l1l1[3:]) < int(protocol[l111l (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l11l1l1 = protocol[l111l (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l11l1l1
def l1111l(l1ll111, l111l11):
    l111l (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l1ll111 is None: l1ll111 = l111l (u"ࠩ࠳ࠫ࠽");
    if l111l11 is None: l111l11 = l111l (u"ࠪ࠴ࠬ࠾");
    l1l1l11 = l1ll111.split(l111l (u"ࠫ࠳࠭࠿"))
    l1l11ll = l111l11.split(l111l (u"ࠬ࠴ࠧࡀ"))
    while len(l1l1l11) < len(l1l11ll): l1l1l11.append(l111l (u"ࠨ࠰ࠣࡁ"));
    while len(l1l11ll) < len(l1l1l11): l1l11ll.append(l111l (u"ࠢ࠱ࠤࡂ"));
    l1l1l11 = [ int(x) for x in l1l1l11 ]
    l1l11ll = [ int(x) for x in l1l11ll ]
    for  i in range(len(l1l1l11)):
        if len(l1l11ll) == i:
            return 1
        if l1l1l11[i] == l1l11ll[i]:
            continue
        elif l1l1l11[i] > l1l11ll[i]:
            return 1
        else:
            return -1
    if len(l1l1l11) != len(l1l11ll):
        return -1
    return 0