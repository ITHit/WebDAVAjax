#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1l11l1 = 2048
l1l = 7
def l1l11l (l1lll1l1):
    global l1l111l
    l1ll11ll = ord (l1lll1l1 [-1])
    l111ll1 = l1lll1l1 [:-1]
    l111l1 = l1ll11ll % len (l111ll1)
    l111111 = l111ll1 [:l111l1] + l111ll1 [l111l1:]
    if l1l1lll:
        l1111ll = l11l11 () .join ([unichr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    return eval (l1111ll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11llll import l1lll11l
from configobj import ConfigObj
l11lllll = l1l11l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1l1l1 = l1l11l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠷࠶࠳࠶ࠢࡤ")
l1l1l1ll = l1l11l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l11l (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠶࠵࠲࠵ࠨࡦ")
l1l11l1l=os.path.join(os.environ.get(l1l11l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l11l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1l1ll.replace(l1l11l (u"ࠦࠥࠨࡩ"), l1l11l (u"ࠧࡥࠢࡪ")).lower())
l11ll1ll=os.environ.get(l1l11l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l11l11=l1l1l1l1.replace(l1l11l (u"ࠣࠢࠥ࡭"), l1l11l (u"ࠤࡢࠦ࡮"))+l1l11l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1ll1l=os.path.join(os.environ.get(l1l11l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l11l11)
elif platform.system() == l1l11l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11lll11=l1lll11l(l1l11l1l+l1l11l (u"ࠢ࠰ࠤࡳ"))
    l1l1ll1l = os.path.join(l11lll11, l1l11l11)
else:
    l1l1ll1l = os.path.join( l1l11l11)
l11ll1ll=l11ll1ll.upper()
if l11ll1ll == l1l11l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11lll=logging.DEBUG
elif l11ll1ll == l1l11l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11lll = logging.INFO
elif l11ll1ll == l1l11l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11lll = logging.WARNING
elif l11ll1ll == l1l11l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11lll = logging.ERROR
elif l11ll1ll == l1l11l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11lll = logging.CRITICAL
elif l11ll1ll == l1l11l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11lll = logging.NOTSET
logger = logging.getLogger(l1l11l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11lll)
l11llll1 = logging.FileHandler(l1l1ll1l, mode=l1l11l (u"ࠣࡹ࠮ࠦࡻ"))
l11llll1.setLevel(l1l11lll)
formatter = logging.Formatter(l1l11l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l11l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11llll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11lll)
l1l1111l = SysLogHandler(address=l1l11l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1111l.setFormatter(formatter)
logger.addHandler(l11llll1)
logger.addHandler(ch)
logger.addHandler(l1l1111l)
class Settings():
    l11lll1l = l1l11l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11ll1 = l1l11l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1llll = l1l11l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l1l1):
        self.l1l111l1 = self._11ll11l(l1l1l1l1)
        self._11ll111()
    def _11ll11l(self, l1l1l1l1):
        l1l1l11l = l1l1l1l1.split(l1l11l (u"ࠣࠢࠥࢂ"))
        l1l1l11l = l1l11l (u"ࠤࠣࠦࢃ").join(l1l1l11l)
        if platform.system() == l1l11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l111l1 = os.path.join(l1l11l1l, l1l11l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l11l + l1l11l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l111l1
    def l1l11111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1lll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l11l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l11l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11l1lll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll111(self):
        if not os.path.exists(os.path.dirname(self.l1l111l1)):
            os.makedirs(os.path.dirname(self.l1l111l1))
        if not os.path.exists(self.l1l111l1):
            self.config = ConfigObj(self.l1l111l1)
            self.config[l1l11l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l11l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l11l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1llll
            self.config[l1l11l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l11l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11ll1
            self.config[l1l11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11lll1l
            self.config[l1l11l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l111l1)
            self.l1l1llll = self.get_value(l1l11l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l11l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11ll1 = self.get_value(l1l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l11l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11lll1l = self.get_value(l1l11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l111ll(self):
        l1l1l111 = l1l11l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11lll1l
        l1l1l111 += l1l11l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11ll1
        l1l1l111 += l1l11l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1llll
        return l1l1l111
    def __unicode__(self):
        return self._1l111ll()
    def __str__(self):
        return self._1l111ll()
    def __del__(self):
        self.config.write()
l11ll1l1 = Settings(l1l1l1l1)