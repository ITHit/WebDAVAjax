#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1111 = 7
def l111l (l1lll1l1):
    global l111ll
    l1ll11ll = ord (l1lll1l1 [-1])
    l1lll11 = l1lll1l1 [:-1]
    l1 = l1ll11ll % len (l1lll11)
    l111l1l = l1lll11 [:l1] + l1lll11 [l1:]
    if l1111:
        l1l111 = l11ll1l () .join ([unichr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    return eval (l1l111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll11l1 import l111l1
from configobj import ConfigObj
l11ll11l = l111l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11lllll = l111l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠺࠼࠻࠳࠶ࠢࡤ")
l1l1l1l1 = l111l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l111l (u"ࠣ࠷࠱࠶࠶࠴࠵࠹࠻࠺࠲࠵ࠨࡦ")
l11ll1l1=os.path.join(os.environ.get(l111l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l111l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1l1l1.replace(l111l (u"ࠦࠥࠨࡩ"), l111l (u"ࠧࡥࠢࡪ")).lower())
l11llll1=os.environ.get(l111l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll1l=l11lllll.replace(l111l (u"ࠣࠢࠥ࡭"), l111l (u"ࠤࡢࠦ࡮"))+l111l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l111l1=os.path.join(os.environ.get(l111l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll1l)
elif platform.system() == l111l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll1ll=l111l1(l11ll1l1+l111l (u"ࠢ࠰ࠤࡳ"))
    l1l111l1 = os.path.join(l11ll1ll, l11lll1l)
else:
    l1l111l1 = os.path.join( l11lll1l)
l11llll1=l11llll1.upper()
if l11llll1 == l111l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1lll1=logging.DEBUG
elif l11llll1 == l111l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1lll1 = logging.INFO
elif l11llll1 == l111l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1lll1 = logging.WARNING
elif l11llll1 == l111l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1lll1 = logging.ERROR
elif l11llll1 == l111l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1lll1 = logging.CRITICAL
elif l11llll1 == l111l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1lll1 = logging.NOTSET
logger = logging.getLogger(l111l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1lll1)
l1l11111 = logging.FileHandler(l1l111l1, mode=l111l (u"ࠣࡹ࠮ࠦࡻ"))
l1l11111.setLevel(l1l1lll1)
formatter = logging.Formatter(l111l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l111l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11111.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1lll1)
l1l1l1ll = SysLogHandler(address=l111l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1l1ll.setFormatter(formatter)
logger.addHandler(l1l11111)
logger.addHandler(ch)
logger.addHandler(l1l1l1ll)
class Settings():
    l1l11lll = l111l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1ll1l = l111l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l11l11 = l111l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11lllll):
        self.l11lll11 = self._1l1l11l(l11lllll)
        self._1l1llll()
    def _1l1l11l(self, l11lllll):
        l11ll111 = l11lllll.split(l111l (u"ࠣࠢࠥࢂ"))
        l11ll111 = l111l (u"ࠤࠣࠦࢃ").join(l11ll111)
        if platform.system() == l111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11lll11 = os.path.join(l11ll1l1, l111l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11ll111 + l111l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11lll11
    def l11l1lll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1llll(self):
        if not os.path.exists(os.path.dirname(self.l11lll11)):
            os.makedirs(os.path.dirname(self.l11lll11))
        if not os.path.exists(self.l11lll11):
            self.config = ConfigObj(self.l11lll11)
            self.config[l111l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l111l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l111l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l11l11
            self.config[l111l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1ll1l
            self.config[l111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l11lll
            self.config[l111l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lll11)
            self.l1l11l11 = self.get_value(l111l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l111l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1ll1l = self.get_value(l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l11lll = self.get_value(l111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l111ll(self):
        l1l1111l = l111l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l11lll
        l1l1111l += l111l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1ll1l
        l1l1111l += l111l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l11l11
        return l1l1111l
    def __unicode__(self):
        return self._1l111ll()
    def __str__(self):
        return self._1l111ll()
    def __del__(self):
        self.config.write()
l1l11ll1 = Settings(l11lllll)