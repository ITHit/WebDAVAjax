#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l1lll = 2048
l11l1l1 = 7
def l11ll11 (l1ll1lll):
    global l1llllll
    l111111 = ord (l1ll1lll [-1])
    l1lll11l = l1ll1lll [:-1]
    l11111l = l111111 % len (l1lll11l)
    l11l111 = l1lll11l [:l11111l] + l1lll11l [l11111l:]
    if l1lll111:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    return eval (l11l11l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l11l1 import l1ll1l1
from configobj import ConfigObj
l11ll1ll = l11ll11 (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l111ll = l11ll11 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠺࠼࠴࠳࠶ࠢࡤ")
l1l1lll1 = l11ll11 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11ll11 (u"ࠣ࠷࠱࠶࠶࠴࠵࠹࠻࠳࠲࠵ࠨࡦ")
l1l1l11l=os.path.join(os.environ.get(l11ll11 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11ll11 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1lll1.replace(l11ll11 (u"ࠦࠥࠨࡩ"), l11ll11 (u"ࠧࡥࠢࡪ")).lower())
l11lll11=os.environ.get(l11ll11 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11ll11 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lllll=l1l111ll.replace(l11ll11 (u"ࠣࠢࠥ࡭"), l11ll11 (u"ࠤࡢࠦ࡮"))+l11ll11 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11ll11 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11ll1=os.path.join(os.environ.get(l11ll11 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lllll)
elif platform.system() == l11ll11 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l11l1l=l1ll1l1(l1l1l11l+l11ll11 (u"ࠢ࠰ࠤࡳ"))
    l1l11ll1 = os.path.join(l1l11l1l, l11lllll)
else:
    l1l11ll1 = os.path.join( l11lllll)
l11lll11=l11lll11.upper()
if l11lll11 == l11ll11 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11l1lll=logging.DEBUG
elif l11lll11 == l11ll11 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11l1lll = logging.INFO
elif l11lll11 == l11ll11 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11l1lll = logging.WARNING
elif l11lll11 == l11ll11 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11l1lll = logging.ERROR
elif l11lll11 == l11ll11 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11l1lll = logging.CRITICAL
elif l11lll11 == l11ll11 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11l1lll = logging.NOTSET
logger = logging.getLogger(l11ll11 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11l1lll)
l11ll11l = logging.FileHandler(l1l11ll1, mode=l11ll11 (u"ࠣࡹ࠮ࠦࡻ"))
l11ll11l.setLevel(l11l1lll)
formatter = logging.Formatter(l11ll11 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11ll11 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11ll11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11l1lll)
l1l1llll = SysLogHandler(address=l11ll11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1llll.setFormatter(formatter)
logger.addHandler(l11ll11l)
logger.addHandler(ch)
logger.addHandler(l1l1llll)
class Settings():
    l1l1l1l1 = l11ll11 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11111 = l11ll11 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l1ll = l11ll11 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l111ll):
        self.l11ll111 = self._11ll1l1(l1l111ll)
        self._11lll1l()
    def _11ll1l1(self, l1l111ll):
        l1l111l1 = l1l111ll.split(l11ll11 (u"ࠣࠢࠥࢂ"))
        l1l111l1 = l11ll11 (u"ࠤࠣࠦࢃ").join(l1l111l1)
        if platform.system() == l11ll11 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11ll111 = os.path.join(l1l1l11l, l11ll11 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l111l1 + l11ll11 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11ll111
    def l1l1l111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11ll11 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11ll11 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1111l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll1l(self):
        if not os.path.exists(os.path.dirname(self.l11ll111)):
            os.makedirs(os.path.dirname(self.l11ll111))
        if not os.path.exists(self.l11ll111):
            self.config = ConfigObj(self.l11ll111)
            self.config[l11ll11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11ll11 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11ll11 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l1ll
            self.config[l11ll11 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11ll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11ll11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11111
            self.config[l11ll11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11ll11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l1l1
            self.config[l11ll11 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll111)
            self.l1l1l1ll = self.get_value(l11ll11 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11ll11 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11111 = self.get_value(l11ll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11ll11 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l1l1 = self.get_value(l11ll11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11ll11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11lll(self):
        l1l1ll1l = l11ll11 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l1l1
        l1l1ll1l += l11ll11 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11111
        l1l1ll1l += l11ll11 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l1ll
        return l1l1ll1l
    def __unicode__(self):
        return self._1l11lll()
    def __str__(self):
        return self._1l11lll()
    def __del__(self):
        self.config.write()
l11llll1 = Settings(l1l111ll)