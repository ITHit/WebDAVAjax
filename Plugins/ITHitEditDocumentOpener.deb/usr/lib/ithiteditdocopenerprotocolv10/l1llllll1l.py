#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111lll = 2048
l1lll11 = 7
def l1l1l11 (l1l11):
    global l111l
    l1ll1l11 = ord (l1l11 [-1])
    l11l = l1l11 [:-1]
    l1lll = l1ll1l11 % len (l11l)
    l1lll11l = l11l [:l1lll] + l11l [l1lll:]
    if l1ll1l:
        l11ll1l = l1llll1l () .join ([unichr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    return eval (l11ll1l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1ll1=logging.WARNING
logger = logging.getLogger(l1l1l11 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll1ll1)
l1l1l111 = SysLogHandler(address=l1l1l11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1l1l11 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l1l111.setFormatter(formatter)
logger.addHandler(l1l1l111)
ch = logging.StreamHandler()
ch.setLevel(l1llll1ll1)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l1l1l11 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1l1l11 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll11ll1, l1lll1l111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11ll1 = l1lll11ll1
            self.l1lll1l111 = l1lll1l111
            if not options:
                options = l1l1l11 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1l11 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll11ll1,
                                              self.l1lll1l111,
                                              self.options,
                                              self.d,
                                              self.p)
    l11111111 = os.path.join(os.path.sep, l1l1l11 (u"ࠨࡧࡷࡧࠬঅ"), l1l1l11 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lll1ll1l = path
        else:
            self._1lll1ll1l = self.l11111111
        super(l1llll1l1l, self).__init__(self._1lll1ll1l, l1l1l11 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll11lll(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l1l1l11 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1l1l11 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1l11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1l11 (u"ࠢࠤࠤঋ")):
                    yield self._1lll11lll(line)
            except ValueError:
                pass
    def l1lll111ll(self, attr, value):
        for entry in self.entries:
            l1lll1l1l1 = getattr(entry, attr)
            if l1lll1l1l1 == value:
                return entry
        return None
    def l1lllll111(self, entry):
        if self.l1lll111ll(l1l1l11 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1l1l11 (u"ࠩ࡟ࡲࠬ঍")).encode(l1l1l11 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1llll1l11(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1l11 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1l11 (u"ࠧࠩࠢঐ")):
                if self._1lll11lll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1l11 (u"࠭ࠧ঑").join(lines).encode(l1l1l11 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1llll(cls, l1lll11ll1, path=None):
        l1lll1l1ll = cls(path=path)
        entry = l1lll1l1ll.l1lll111ll(l1l1l11 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll11ll1)
        if entry:
            return l1lll1l1ll.l1llll1l11(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11ll1, l1lll1l111, options=None, path=None):
        return cls(path=path).l1lllll111(l1llll1l1l.Entry(device,
                                                    l1lll11ll1, l1lll1l111,
                                                    options=options))
class l1lllll11l(object):
    def __init__(self, l1lll11l1l):
        self.l1llllllll=l1l1l11 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll11l11=l1l1l11 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1lll11l1l=l1lll11l1l
        self.l1lll1l11l()
        self.l1lll1ll11()
        self.l1llllll11()
        self.l1lll111l1()
        self.l1llll11ll()
    def l1lll1l11l(self):
        temp_file=open(l1lll1lll1,l1l1l11 (u"ࠫࡷ࠭খ"))
        l1l111=temp_file.read()
        data=json.loads(l1l111)
        self.user=data[l1l1l11 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1ll1l1l=data[l1l1l11 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1llll=data[l1l1l11 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l111l11=data[l1l1l11 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lllll1ll=data[l1l1l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1llll1111=data[l1l1l11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1llllll11(self):
        l1llll1=os.path.join(l1l1l11 (u"ࠦ࠴ࠨঝ"),l1l1l11 (u"ࠧࡻࡳࡳࠤঞ"),l1l1l11 (u"ࠨࡳࡣ࡫ࡱࠦট"),l1l1l11 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1l1l11 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1llll1)
    def l1llll11ll(self):
        logger.info(l1l1l11 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1llll=os.path.join(self.l111l11,self.l1llllllll)
        l1llll111l = pwd.getpwnam(self.user).pw_uid
        l1lllllll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1llll):
            os.makedirs(l1llll)
            os.system(l1l1l11 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1llll))
            logger.debug(l1l1l11 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1llll)
        else:
            logger.debug(l1l1l11 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1llll)
        l1llll1=os.path.join(l1llll, self.l1lll11l11)
        print(l1llll1)
        logger.debug(l1l1l11 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1llll1)
        with open(l1llll1, l1l1l11 (u"ࠢࡸ࠭ࠥধ")) as l1llll11l1:
            logger.debug(self.l1ll1l1l + l1l1l11 (u"ࠨࠢࠪন")+self.l1lllll1ll+l1l1l11 (u"ࠩࠣࠦࠬ঩")+self.l1llll1111+l1l1l11 (u"ࠪࠦࠬপ"))
            l1llll11l1.writelines(self.l1ll1l1l + l1l1l11 (u"ࠫࠥ࠭ফ")+self.l1lllll1ll+l1l1l11 (u"ࠬࠦࠢࠨব")+self.l1llll1111+l1l1l11 (u"࠭ࠢࠨভ"))
        os.chmod(l1llll1, 0o600)
        os.chown(l1llll1, l1llll111l, l1lllllll1)
    def l1lll1ll11(self, l1llll1lll=l1l1l11 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1l1l11 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll1lll in groups:
            logger.info(l1l1l11 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llll1lll))
        else:
            logger.warning(l1l1l11 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llll1lll))
            l1ll11ll=l1l1l11 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llll1lll,self.user)
            logger.debug(l1l1l11 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1ll11ll)
            os.system(l1ll11ll)
            logger.debug(l1l1l11 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll111l1(self):
        logger.debug(l1l1l11 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lll1l1ll=l1llll1l1l()
        l1lll1l1ll.add(self.l1ll1l1l, self.l1llll, l1lll1l111=l1l1l11 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1l1l11 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1l1l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1lll1 = urllib.parse.unquote(sys.argv[1])
        if l1lll1lll1:
            l1lllll1l1=l1lllll11l(l1lll1lll1)
        else:
            raise (l1l1l11 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1l1l11 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise