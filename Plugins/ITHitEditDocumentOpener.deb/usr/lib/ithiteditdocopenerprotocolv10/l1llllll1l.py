#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1l1 = 2048
l1ll11 = 7
def l1lll11 (ll):
    global l11l1
    l11l111 = ord (ll [-1])
    l11ll1l = ll [:-1]
    l1l11 = l11l111 % len (l11ll1l)
    l111l1 = l11ll1l [:l1l11] + l11ll1l [l1l11:]
    if l11l1l:
        l1l111l = l1ll11l1 () .join ([unichr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    else:
        l1l111l = str () .join ([chr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    return eval (l1l111l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l1l1=logging.WARNING
logger = logging.getLogger(l1lll11 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l1l1)
l1l111ll = SysLogHandler(address=l1lll11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll11 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l111ll.setFormatter(formatter)
logger.addHandler(l1l111ll)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l1l1)
logger.addHandler(ch)
class l1llll1lll(io.FileIO):
    l1lll11 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll11 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11ll1, l1llll1ll1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11ll1 = l1lll11ll1
            self.l1llll1ll1 = l1llll1ll1
            if not options:
                options = l1lll11 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll11 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11ll1,
                                              self.l1llll1ll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l1ll = os.path.join(os.path.sep, l1lll11 (u"ࠪࡩࡹࡩࠧই"), l1lll11 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll11l11 = path
        else:
            self._1lll11l11 = self.l1lll1l1ll
        super(l1llll1lll, self).__init__(self._1lll11l11, l1lll11 (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1111(self, line):
        return l1llll1lll.Entry(*[x for x in line.strip(l1lll11 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll11 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll11 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll11 (u"ࠤࠦࠦ঍")):
                    yield self._1llll1111(line)
            except ValueError:
                pass
    def l1llll11l1(self, attr, value):
        for entry in self.entries:
            l1lllll1ll = getattr(entry, attr)
            if l1lllll1ll == value:
                return entry
        return None
    def l1lll1ll1l(self, entry):
        if self.l1llll11l1(l1lll11 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll11 (u"ࠫࡡࡴࠧএ")).encode(l1lll11 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll111l(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll11 (u"ࠢࠤࠤ঒")):
                if self._1llll1111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll11 (u"ࠨࠩও").join(lines).encode(l1lll11 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llll1l1l(cls, l1lll11ll1, path=None):
        l1lll1l11l = cls(path=path)
        entry = l1lll1l11l.l1llll11l1(l1lll11 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11ll1)
        if entry:
            return l1lll1l11l.l1llll111l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11ll1, l1llll1ll1, options=None, path=None):
        return cls(path=path).l1lll1ll1l(l1llll1lll.Entry(device,
                                                    l1lll11ll1, l1llll1ll1,
                                                    options=options))
class l1llll11ll(object):
    def __init__(self, l1llll1l11):
        self.l1lll111l1=l1lll11 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lllllll1=l1lll11 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll1l11=l1llll1l11
        self.l1lll111ll()
        self.l1lll1llll()
        self.l1llllll11()
        self.l1lllll11l()
        self.l1lll1l111()
    def l1lll111ll(self):
        temp_file=open(l1lll1ll11,l1lll11 (u"࠭ࡲࠨঘ"))
        l111l11=temp_file.read()
        data=json.loads(l111l11)
        self.user=data[l1lll11 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l11=data[l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll1l1=data[l1lll11 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l111=data[l1lll11 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll111=data[l1lll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll11lll=data[l1lll11 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llllll11(self):
        l1l1l11=os.path.join(l1lll11 (u"ࠨ࠯ࠣট"),l1lll11 (u"ࠢࡶࡵࡵࠦঠ"),l1lll11 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll11 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll11 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l1l11)
    def l1lll1l111(self):
        logger.info(l1lll11 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll1l1=os.path.join(self.l1l111,self.l1lll111l1)
        l1lll1lll1 = pwd.getpwnam(self.user).pw_uid
        l1lll11l1l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll1l1):
            os.makedirs(l1ll1l1)
            os.system(l1lll11 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll1l1))
            logger.debug(l1lll11 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll1l1)
        else:
            logger.debug(l1lll11 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll1l1)
        l1l1l11=os.path.join(l1ll1l1, self.l1lllllll1)
        print(l1l1l11)
        logger.debug(l1lll11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l1l11)
        with open(l1l1l11, l1lll11 (u"ࠤࡺ࠯ࠧ঩")) as l1lllll1l1:
            logger.debug(self.l11l11 + l1lll11 (u"ࠪࠤࠬপ")+self.l1lllll111+l1lll11 (u"ࠫࠥࠨࠧফ")+self.l1lll11lll+l1lll11 (u"ࠬࠨࠧব"))
            l1lllll1l1.writelines(self.l11l11 + l1lll11 (u"࠭ࠠࠨভ")+self.l1lllll111+l1lll11 (u"ࠧࠡࠤࠪম")+self.l1lll11lll+l1lll11 (u"ࠨࠤࠪয"))
        os.chmod(l1l1l11, 0o600)
        os.chown(l1l1l11, l1lll1lll1, l1lll11l1l)
    def l1lll1llll(self, l1lll1111l=l1lll11 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll11 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1111l in groups:
            logger.info(l1lll11 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1111l))
        else:
            logger.warning(l1lll11 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1111l))
            l1lllll1=l1lll11 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1111l,self.user)
            logger.debug(l1lll11 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1lllll1)
            os.system(l1lllll1)
            logger.debug(l1lll11 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lllll11l(self):
        logger.debug(l1lll11 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l11l=l1llll1lll()
        l1lll1l11l.add(self.l11l11, self.l1ll1l1, l1llll1ll1=l1lll11 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll11 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll11 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1ll11 = urllib.parse.unquote(sys.argv[1])
        if l1lll1ll11:
            l1lll11111=l1llll11ll(l1lll1ll11)
        else:
            raise (l1lll11 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll11 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise