#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11ll = sys.version_info [0] == 2
l1l111 = 2048
l1l1l1 = 7
def l11111l (l1ll11l):
    global l1l1lll
    l11ll11 = ord (l1ll11l [-1])
    l1l1111 = l1ll11l [:-1]
    l111ll = l11ll11 % len (l1l1111)
    l1ll1lll = l1l1111 [:l111ll] + l1l1111 [l111ll:]
    if l1l11ll:
        l1ll111 = l1ll1l1l () .join ([unichr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1ll111 = str () .join ([chr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1ll111)
import re
class l1lll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111111 = kwargs.get(l11111l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1lllll1 = kwargs.get(l11111l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll1ll = self.l11111l1(args)
        if l1llll1ll:
            args=args+ l1llll1ll
        self.args = [a for a in args]
    def l11111l1(self, *args):
        l1llll1ll=None
        l11ll111 = args[0][0]
        if re.search(l11111l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11ll111):
            l1llll1ll = (l11111l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1111111
                            ,)
        return l1llll1ll
class l1lll1lll(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1ll = self.l11111l1(args)
        if l1llll1ll:
            args = args + l1llll1ll
        self.args = [a for a in args]
    def l11111l1(self, *args):
        s = l11111l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11111l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lllll11(Exception):
    pass
class l11l11(Exception):
    pass
class l1llll1l1(Exception):
    def __init__(self, message, l1lllll1l, url):
        super(l1llll1l1,self).__init__(message)
        self.l1lllll1l = l1lllll1l
        self.url = url
class l111111l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l111ll11(Exception):
    pass