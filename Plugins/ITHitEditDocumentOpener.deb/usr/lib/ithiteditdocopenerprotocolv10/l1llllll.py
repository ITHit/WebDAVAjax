#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1llll11 = 2048
l11l11 = 7
def l1lllll (l1lll):
    global l1ll1ll1
    l1ll1lll = ord (l1lll [-1])
    l111l11 = l1lll [:-1]
    l1ll11l = l1ll1lll % len (l111l11)
    l1111 = l111l11 [:l1ll11l] + l111l11 [l1ll11l:]
    if l1ll1:
        l111lll = l1l1ll1 () .join ([unichr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    else:
        l111lll = str () .join ([chr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    return eval (l111lll)
import gi
gi.require_version(l1lllll (u"ࠨࡉࡷ࡯ࠬঽ"), l1lllll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1ll1l
import logging
logger = logging.getLogger(l1lllll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l111l1l(Gtk.Window):
    def __init__(self, l1ll111ll1, l1ll1l1l11):
        Gtk.Window.__init__(self)
        self.l1ll11ll=30
        self.l1l1llll11 = False
        self.service = l1ll111ll1
        self.l1lll1=l1ll1l1l11
        self.l1l11=l1l1ll1l.l11lllll
        self.l1l1l1lll1 = Gtk.ListStore(str)
        self.l1l1ll1l1l()
    def l1l11l11ll(self, service):
        l1l1l11ll1 = self.l1l11.l1l1ll11(l1lllll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1l11ll1
    def l1l1ll1l1l(self, l1ll111ll1=None):
        if l1ll111ll1:
            self.l1l1l1lll1.clear()
            l1l1lllll1=self.l1l11l11ll(l1ll111ll1)
            self.l1l1l1lll1.append([l1lllll (u"ࠧࠨু")])
            for l1lll1 in l1l1lllll1:
                self.l1l1l1lll1.append([l1lll1])
        else:
            self.l1l1l1lll1.clear()
            self.l1l1l1lll1.append([l1lllll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1l1l11l(self, widget, data=None):
        l1l1lll1ll= widget.get_active()
        if data == l1lllll (u"ࠢ࠲ࠤৃ") and l1l1lll1ll:
            self.l1l1ll1l1l()
            self.l1l1l1l111.set_active(0)
            self.l1ll1ll1l1.set_text(l1lllll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1ll1l1.set_sensitive(False)
            self.l1l1l1l111.set_sensitive(False)
        else:
            self.l1l1ll1l1l(l1ll111ll1=self.service)
            self.l1l1l1l111.set_active(0)
            self.l1ll1ll1l1.set_text(l1lllll (u"ࠤࠥ৅"))
            self.l1l1l1l111.set_sensitive(True)
            self.l1ll1ll1l1.set_sensitive(True)
    def l1l11lll1l(self, widget):
        if widget.get_active():
            l1lll1 = widget.get_child().get_text()
        else:
            l1lll1 = self.l1l1l1lll1[widget.get_active()][0]
        password = self.l1ll1l1111(self.service, l1lll1)
        if password:
            self.l1ll1ll1l1.set_text(password)
        else:
            self.l1ll1ll1l1.set_text(l1lllll (u"ࠥࠦ৆"))
    def l1ll1llll1(self, l1lll1, pwd, service):
        keyring.set_password(service, l1lll1, pwd)
        l1l1l11ll1=self.l1l11.l1l1ll11(l1lllll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1lll1 in l1l1l11ll1:
            value = self.l1l11.get_value(l1lllll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l11.l1l1l1ll(l1lllll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1lllll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1lll1))
    def l1ll1l1111(self, service, l1lll1):
        l1l1l1l1ll = keyring.get_password(service, l1lll1)
        return l1l1l1l1ll
    def l1ll11ll1l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l11llll1(self, widget, data=None):
        self.l1l1llll11=widget.get_active()
    def l1l1l1(self, message, title=l1lllll (u"ࠨࠩো"), l11ll11l1=True):
        if l11ll11l1:
            l1l1l11111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1l111l = Gtk.MessageDialog(self,
            l1l1l11111,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1l111l.set_title(title)
        l1ll1l111l.set_default_response(Gtk.ResponseType.OK)
        l1ll111lll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l11l1l = Gtk.VBox()
        l1ll1l1l1l = Gtk.Box(spacing=1)
        l1ll1l1l1l.set_homogeneous(False)
        l1l1l111l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l111l1.set_homogeneous(False)
        l1ll11lll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11lll1.set_homogeneous(False)
        l1ll1l1l1l.pack_start(l1l1l111l1, True, True, 0)
        l1ll1l1l1l.pack_start(l1ll11lll1, True, True, 0)
        l1ll1lll11 = l1ll1l111l.get_content_area()
        l1l1lll111 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll1lll11.pack_start(l1l1lll111, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1ll1111 = Gtk.Label()
        l1l11l1ll1 = Gtk.Label()
        l1l11l1ll1.set_text(l1lllll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l11l1ll1, True, True, 0)
        l1l1ll1111.set_text(l1lllll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1ll1111.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1ll1111, 0, 1, 0, 1)
        l1l1ll1l11 = Gtk.RadioButton.new_with_label_from_widget(None, l1lllll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1ll1l11.connect(l1lllll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1l1l11l, l1lllll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1ll1l11, 1, 2, 0, 1)
        l1ll111l1l = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1l11, l1lllll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll111l1l.connect(l1lllll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1l1l11l, l1lllll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll111l1l, 1, 2, 1, 2)
        l1ll1l1lll = Gtk.Label()
        l1ll1l1lll.set_text(l1lllll (u"ࠥࠤࠧ৔"))
        table.attach(l1ll1l1lll, 0, 1, 4, 6)
        l1ll111l11 = Gtk.Label()
        l1ll111l11.set_text(l1lllll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll111l11.set_justify(Gtk.Justification.RIGHT)
        l1ll111l11.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l1l111 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1lll1)
        self.l1l1l1l111.set_entry_text_column(0)
        table.attach(l1ll111l11, 0, 1, 6, 8)
        table.attach(self.l1l1l1l111, 1, 3, 6, 8)
        self.l1l1l1l111.connect(l1lllll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l11lll1l)
        l1l11l1lll = Gtk.Label()
        l1l11l1lll.set_text(l1lllll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l11l1lll.set_justify(Gtk.Justification.RIGHT)
        l1l11l1lll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1ll1l1 = Gtk.Entry()
        self.l1ll1ll1l1.set_visibility(False)
        self.l1ll1ll1l1.connect(l1lllll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1ll11ll1l, l1ll1l111l)
        table.attach(l1l11l1lll, 0, 1, 8, 10)
        table.attach(self.l1ll1ll1l1, 1, 3, 8, 10)
        l1l11lllll = Gtk.CheckButton(l1lllll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l11lllll.connect(l1lllll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l11llll1, l1l11lllll)
        l1l11lllll.set_active(False)
        table.attach(l1l11lllll, 1, 3, 12, 14)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l1lllll (u"ࠥࠤࠧ৛") * 5)
        l1l1l11l1l.pack_start(l1ll1111ll, True, True, 0)
        if self.l1lll1:
            l1ll111l1l.set_active(True)
            self.l1l1l1l111.set_active(0)
            self.l1l1l1l111.set_sensitive(True)
            self.l1ll1ll1l1.set_text(l1lllll (u"ࠦࠧড়"))
            self.l1ll1ll1l1.set_sensitive(True)
        else:
            self.l1l1l1l111.set_active(0)
            self.l1l1l1l111.set_sensitive(False)
            self.l1ll1ll1l1.set_text(l1lllll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1ll1l1.set_sensitive(False)
        l1ll111lll.pack_start(vbox, True, True, 0)
        l1ll111lll.pack_start(table, True, True, 0)
        l1ll111lll.pack_end(l1l1l11l1l, True, True, 0)
        l1l1lll111.pack_start(l1ll111lll, True, True, 0)
        l1ll1l111l.show_all()
        response = l1ll1l111l.run()
        if self.l1l1l1l111.get_active():
            l1lll1 = self.l1l1l1l111.get_child().get_text()
        else:
            l1lll1 = self.l1l1l1lll1[self.l1l1l1l111.get_active()][0]
        pwd = self.l1ll1ll1l1.get_text()
        l1ll1l111l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1llll11:
                self.l1ll1llll1(l1lll1, pwd, self.service)
            return l1lll1, pwd
        else:
            return l1lllll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1lllll (u"ࠧࠨয়")
class l1l1l1l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1lll1l1(self, l11ll1l1):
        l1ll1l11l1 = Gtk.ScrolledWindow()
        l1ll1l11l1.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1lll11l=None
        self.l1l1llllll = Gtk.TextBuffer()
        self.l1l1llllll.set_text(l11ll1l1)
        self.set_style()
        regexp= l1lllll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll11111l = self._1l1l1l1l1(l11ll1l1, regexp)
        self.l1ll11ll11(l1ll11111l, self.l1l1llllll.get_start_iter())
        self.l1l1l1llll = Gtk.TextView(buffer=self.l1l1llllll)
        self.l1l1l1llll.set_property(l1lllll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1l1llll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l1llll.connect(l1lllll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1llll1l)
        self.l1l1l1llll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1l11l1.set_size_request(300,100)
        self.l1l1l1llll.show()
        l1ll1l11l1.add(self.l1l1l1llll)
        l1ll1l11l1.show()
        return l1ll1l11l1
    def _1l1llll1l(self, *args, **kwargs):
        l1l1l1111l, l1l1ll111l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l1111l, l1l1ll111l).get_tags()
        if not self.l1l1lll11l:
            self.l1l1lll11l = args[1].window.get_cursor()
            self.l1ll1ll1ll = Gdk.Cursor(Gdk.CursorType.l1l1ll1ll1)
        elif tag:
            args[1].window.set_cursor(self.l1ll1ll1ll)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1lll11l:
                args[1].window.set_cursor(self.l1l1lll11l)
    def _1l1l1l1l1(self, l11ll1l1, l1l11ll1ll):
        res=[]
        l1l1l11l11=re.findall(l1l11ll1ll,l11ll1l1)
        for l1ll11l111 in l1l1l11l11:
            for el in l1ll11l111:
                if el:
                    res.append(el)
        return res
    def l1ll11ll11(self, l1ll11111l, start):
        l1ll1lllll=0
        for text in l1ll11111l:
            end = self.l1l1llllll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1lllll+=1
                l1l11l1l1l, l1l11lll11 = match
                tag = self.l1l1llllll.create_tag(str(l1ll1lllll), foreground=l1lllll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1lllll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll11l11l, text)
                self.l1l1llllll.apply_tag(tag, l1l11l1l1l, l1l11lll11)
                self.l1ll11ll11(l1ll11111l, l1l11lll11)
    def _1ll11l11l(self, tag, widget, l1l11l1l11, _1l11ll1l1, text):
        _1l1ll11ll = l1l11l1l11.type
        _1ll1lll1l = l1l11l1l11.window
        if _1l1ll11ll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1ll11ll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l11l1l11.button
            self.l1l1lll11l = Gdk.Cursor(Gdk.CursorType.l1l1ll1ll1)
            if _1l1ll11ll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1lllll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l11l1l1ll(self, message, title=l1lllll (u"ࠧࠨ০"), l11ll11l1=True, l1ll1l11ll=None):
        if l11ll11l1:
            l1l1l11111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1l11111,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll1l11ll:
            l1ll1lll11 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1l1l1l = Gtk.HBox(spacing=0)
            l1l1l1ll1l = Gtk.HBox(spacing=5)
            l1l1l11lll = Gtk.Label()
            l1l1l11lll.set_markup(l1lllll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1l11lll.set_line_wrap(True)
            l1l1l11lll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1lllll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1ll11l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11l1.show()
            l1ll111111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111111.show()
            l1ll1ll111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll111.show()
            l1ll1l1l1l.pack_start(separator, True, True, 0)
            l1ll1l1l1l.pack_start(l1l1ll11l1, True, True, 0)
            l1ll1l1l1l.pack_start(l1ll111111, True, True, 0)
            l1ll1l1l1l.pack_start(l1ll1ll111, True, True, 0)
            l1ll1l1l1l.pack_start(l1l1l11lll, False, True, 0)
            l1ll1ll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll11l.show()
            l1ll1l1l1l.pack_end(l1ll1ll11l, True, True, 0)
            l1ll11l1l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11l1l1.show()
            vbox.pack_start(l1ll1l1l1l, True, True, 0)
            l1ll1l11l1=self.__1l1lll1l1(l11ll1l1=l1ll1l11ll)
            vbox.pack_start(l1ll1l11l1, False, False, 0)
            vbox.pack_end(l1ll11l1l1, False, False, 0)
            l1l1l1ll1l.pack_start(vbox, True, True,5)
            l1l1l1ll1l.show()
            l1ll1lll11.pack_end(l1l1l1ll1l, False, False, 0)
            vbox.show()
            l1ll1l1l1l.show()
        window.run()
class l1ll11ll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l1ll11(self, widget, l1l11ll11l):
        if l1l11ll11l == Gtk.ResponseType.OK:
            self.result = l1lllll (u"ࠥࡓࡐࠨ৩")
        elif l1l11ll11l == Gtk.ResponseType.CANCEL:
            self.result = l1lllll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l11ll11l == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1lllll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11111lll(self, title=l1lllll (u"ࠨࠢ৬"), message=l1lllll (u"ࠢࠣ৭") , l11ll11l1=True):
        if l11ll11l1:
            l1l1l11111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l11111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1lllll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1l1ll11)
        window.run()
class l1l1l111ll(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l11ll111=None
        self.result = None
    def l1l1l1ll11(self, widget, l1l11ll11l):
        print(widget, l1l11ll11l)
        if l1l11ll11l == Gtk.ResponseType.OK:
            self.result = True
        elif l1l11ll11l == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l11ll11l == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l11llll1(self, widget, l1ll11l1ll):
        if l1ll11l1ll.get_active():
            self.l1l11ll111 = 1
        else:
            self.l1l11ll111 = 0
    def l1ll1111l1(self, title=l1lllll (u"ࠤࠥ৯"), message=l1lllll (u"ࠥࠦৰ"), l1l1ll1lll =l1lllll (u"ࠦࠧৱ"),l11ll11l1=True):
        if l11ll11l1:
            l1l1l11111= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l11111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1lllll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1l1ll11)
        l1l11lllll = Gtk.CheckButton(l1l1ll1lll)
        l1l11lllll.connect(l1lllll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l11llll1, l1l11lllll)
        l1l11lllll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l11lllll, expand=True, fill=True, padding=0)
        l1l11lllll.show()
        window.run()
def l111l1l11(title, msg, l1l1ll1lll=l1lllll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11ll11l1=True):
    result=None
    try:
        l1ll11llll = l1l1l111ll()
        l1ll11llll.l1ll1111l1(title, msg, l1l1ll1lll, l11ll11l1)
        result = {l1lllll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1ll11llll.result,  l1lllll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1ll11llll.l1l11ll111}
    except Exception as e:
        logger.exception(l1lllll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1lllll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1ll11lll = l1l1l1l11()
    message= l1lllll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll1l1ll1 = l1lllll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1ll11lll.l11l1l1ll(message, l1lllll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11ll11l1=True, l1ll1l11ll=l1ll1l1ll1)