#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1111 = 7
def l111l (l1lll1l1):
    global l111ll
    l1ll11ll = ord (l1lll1l1 [-1])
    l1lll11 = l1lll1l1 [:-1]
    l1 = l1ll11ll % len (l1lll11)
    l111l1l = l1lll11 [:l1] + l1lll11 [l1:]
    if l1111:
        l1l111 = l11ll1l () .join ([unichr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    return eval (l1l111)
import logging
import os
import re
from l1lllll1 import l1lll1lll
logger = logging.getLogger(l111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l11ll():
    try:
        out = os.popen(l111l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l111l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l111l (u"ࠤࠥॸ").join(result)
                logger.info(l111l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l111l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l111l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l111l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll1lll(l111l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l111l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111l1(l111l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))