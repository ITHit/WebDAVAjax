#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import logging
import os
import re
from l111l import l1llll1l1
logger = logging.getLogger(l1lll1l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l11lll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1l (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1111():
    try:
        out = os.popen(l1lll1l (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1lll1l (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1lll1l (u"ࠢࠣॶ").join(result)
                logger.info(l1lll1l (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1lll1l (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1lll1l (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1lll1l (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1l1(l1lll1l (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1lll1l (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l11lll1(l1lll1l (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))