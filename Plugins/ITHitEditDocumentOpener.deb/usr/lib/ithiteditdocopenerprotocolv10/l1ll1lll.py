#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import hashlib
import os
import l11ll1
from l11l1ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11ll1 import l1111ll
from l1l1111 import l1ll1ll1, l11l11
import logging
logger = logging.getLogger(l1l11l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11ll1l():
    def __init__(self, l1lll1,l111l11, l11l111= None, l1llll=None):
        self.l1llll1=False
        self.l1ll11l = self._1ll()
        self.l111l11 = l111l11
        self.l11l111 = l11l111
        self.l1llll1l = l1lll1
        if l11l111:
            self.l1l11l1 = True
        else:
            self.l1l11l1 = False
        self.l1llll = l1llll
    def _1ll(self):
        try:
            return l11ll1.l111() is not None
        except:
            return False
    def open(self):
        l1l11l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll11l:
            raise NotImplementedError(l1l11l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l11l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11111l = self.l1llll1l
        if self.l111l11.lower().startswith(self.l1llll1l.lower()):
            l1lll11 = re.compile(re.escape(self.l1llll1l), re.IGNORECASE)
            l111l11 = l1lll11.sub(l1l11l (u"ࠨࠩࠄ"), self.l111l11)
            l111l11 = l111l11.replace(l1l11l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l11l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1l1(self.l1llll1l, l11111l, l111l11, self.l11l111)
    def l1l1l1(self,l1llll1l, l11111l, l111l11, l11l111):
        l1l11l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l11l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11l11l = l1lll11l(l1llll1l)
        l111l1 = self.l1lll(l11l11l)
        logger.info(l1l11l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11l11l)
        if l111l1:
            logger.info(l1l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111ll(l11l11l)
            l11l11l = l1ll111(l1llll1l, l11111l, l11l111, self.l1llll)
        logger.debug(l1l11l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l1l=l11l11l + l1l11l (u"ࠤ࠲ࠦࠌ") + l111l11
        l1l11 = l1l11l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l1l+ l1l11l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l11)
        l1lll1l = os.system(l1l11)
        if (l1lll1l != 0):
            raise IOError(l1l11l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l1l, l1lll1l))
    def l1lll(self, l11l11l):
        if os.path.exists(l11l11l):
            if os.path.islink(l11l11l):
                l11l11l = os.readlink(l11l11l)
            if os.path.ismount(l11l11l):
                return True
        return False
def l1lll11l(l1llll1l):
    l11lll1 = l1llll1l.replace(l1l11l (u"࠭࡜࡝ࠩࠐ"), l1l11l (u"ࠧࡠࠩࠑ")).replace(l1l11l (u"ࠨ࠱ࠪࠒ"), l1l11l (u"ࠩࡢࠫࠓ"))
    l1l1ll = l1l11l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    ll=os.environ[l1l11l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1l1l=os.path.join(ll,l1l1ll, l11lll1)
    l111ll1=os.path.abspath(l1l1l1l)
    return l111ll1
def l1l1l(l1):
    if not os.path.exists(l1):
        os.makedirs(l1)
def l111l1l(l1llll1l, l11111l, l11llll=None, password=None):
    l1l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1 = l1lll11l(l1llll1l)
    l1l1l(l1)
    if not l11llll:
        l1llll11 = l11l1()
        l1lllll1 =l1llll11.l11(l1l11l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11111l + l1l11l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11111l + l1l11l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lllll1, str):
            l11llll, password = l1lllll1
        else:
            raise l11l11()
        logger.info(l1l11l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1))
    l1llllll = pwd.getpwuid( os.getuid())[0]
    l1111l=os.environ[l1l11l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l111l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll1ll={l1l11l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1llllll, l1l11l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1llll1l, l1l11l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1, l1l11l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1111l, l1l11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11llll, l1l11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll1ll, temp_file)
        if not os.path.exists(os.path.join(l111l, l1l11l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll1ll=l1l11l (u"ࠦࡵࡿࠢࠣ")
            key=l1l11l (u"ࠧࠨࠤ")
        else:
            l1lll1ll=l1l11l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l11l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111lll=l1l11l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll1ll,temp_file.name)
        l1lll1l1=[l1l11l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l11l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l111l, l111lll)]
        p = subprocess.Popen(l1lll1l1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l11l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l11l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l11l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1
    logger.debug(l1l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111ll1=os.path.abspath(l1)
    logger.debug(l1l11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111ll1)
    return l111ll1
def l1ll111(l1llll1l, l11111l, l11l111, l1llll):
    l1l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l111111(title):
        l1l1=30
        if len(title)>l1l1:
            l1l1lll=title.split(l1l11l (u"ࠨ࠯ࠣ࠳"))
            l1111l1=l1l11l (u"ࠧࠨ࠴")
            for block in l1l1lll:
                l1111l1+=block+l1l11l (u"ࠣ࠱ࠥ࠵")
                if len(l1111l1) > l1l1:
                    l1111l1+=l1l11l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1111l1
        return title
    l11llll = l1l11l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1l11l (u"ࠦࠧ࠸")
    os.system(l1l11l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1ll1l1l = l1lll11l(l1llll1l)
    l1 = l1lll11l(hashlib.sha1(l1llll1l.encode()).hexdigest()[:10])
    l1l1l(l1)
    logger.info(l1l11l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1))
    if l11l111:
        l11l = [l1l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1l11l (u"ࠤ࠰ࡸࠧ࠽"), l1l11l (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1l11l (u"ࠫ࠲ࡵࠧ࠿"), l1l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l11llll, l11l111),
                    urllib.parse.unquote(l11111l), os.path.abspath(l1)]
    else:
        l11llll, password = l1l111(l1, l11111l, l1llll)
        if l11llll.lower() != l1l11l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l11l = [l1l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l11l (u"ࠤ࠰ࡸࠧࡄ"), l1l11l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l11l (u"ࠫ࠲ࡵࠧࡆ"), l1l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l11llll,
                        urllib.parse.unquote(l11111l), os.path.abspath(l1)]
        else:
            raise l11l11()
    logger.info(l1l11l (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1l11l (u"ࠢࠡࠤࡉ").join(l11l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1l11ll = l1l11l (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1l11ll.encode())
    if len(err) > 0:
        l1lll111 = l1l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1lll111)
        raise l1ll1ll1(l1lll111, l1ll111=l11ll1.l111(), l11111l=l11111l)
    logger.info(l1l11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1l11l (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1, l1ll1l1l))
    l111ll1=os.path.abspath(l1ll1l1l)
    return l111ll1
def l1l111(l1llll1l, l11111l, l1llll):
    l1ll1l11 = os.path.join(os.environ[l1l11l (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1l11l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1l11l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1ll1l11)):
       os.makedirs(os.path.dirname(l1ll1l11))
    l11ll11 = l1llll.get_value(l1l11l (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1l11l (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1llll11 = l11l1(l1llll1l, l11ll11)
    l11llll, password = l1llll11.l11(l1l11l (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11111l + l1l11l (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11111l + l1l11l (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l11llll != l1l11l (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1ll11ll(l1llll1l, l11llll):
        l1ll1 = l1l11l (u"ࠢࠡࠤࡗ").join([l1llll1l, l11llll, l1l11l (u"ࠨࠤࠪࡘ") + password + l1l11l (u"࡙ࠩࠥࠫ"), l1l11l (u"ࠪࡠࡳ࡚࠭")])
        with open(l1ll1l11, l1l11l (u"ࠫࡼ࠱࡛ࠧ")) as l11l1l1:
            l11l1l1.write(l1ll1)
        os.chmod(l1ll1l11, 0o600)
    return l11llll, password
def l1ll11ll(l1llll1l, l11llll):
    l1ll1l11 = l1ll1l1 = os.path.join(os.environ[l1l11l (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1l11l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1l11l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1ll1l11):
        with open(l1ll1l11, l1l11l (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1l111l = data[0].split(l1l11l (u"ࠤࠣࠦࡠ"))
            if l1llll1l == l1l111l[0] and l11llll == l1l111l[1]:
                return True
    return False