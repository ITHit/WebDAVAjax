#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1111 = 7
def l111l (l1lll1l1):
    global l111ll
    l1ll11ll = ord (l1lll1l1 [-1])
    l1lll11 = l1lll1l1 [:-1]
    l1 = l1ll11ll % len (l1lll11)
    l111l1l = l1lll11 [:l1] + l1lll11 [l1:]
    if l1111:
        l1l111 = l11ll1l () .join ([unichr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    return eval (l1l111)
import re
class l11111(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111l1 = kwargs.get(l111l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1llll = kwargs.get(l111l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1111111 = self.l1llll111(args)
        if l1111111:
            args=args+ l1111111
        self.args = [a for a in args]
    def l1llll111(self, *args):
        l1111111=None
        l1l1111l = args[0][0]
        if re.search(l111l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1111l):
            l1111111 = (l111l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l11111l1
                            ,)
        return l1111111
class l1lll1lll(Exception):
    def __init__(self, *args, **kwargs):
        l1111111 = self.l1llll111(args)
        if l1111111:
            args = args + l1111111
        self.args = [a for a in args]
    def l1llll111(self, *args):
        s = l111l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l111l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1111l11(Exception):
    pass
class l1l1111(Exception):
    pass
class l1lll1l1l(Exception):
    def __init__(self, message, l1llll1ll, url):
        super(l1lll1l1l,self).__init__(message)
        self.l1llll1ll = l1llll1ll
        self.url = url
class l1lllll11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l11111ll(Exception):
    pass
class l111111l(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111ll1l(Exception):
    pass