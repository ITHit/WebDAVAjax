#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l = sys.version_info [0] == 2
l1llll11 = 2048
l1l11l = 7
def l11l1l1 (l1l111):
    global l1llllll
    l1lll = ord (l1l111 [-1])
    l1lll1l = l1l111 [:-1]
    l1ll1l1 = l1lll % len (l1lll1l)
    l11l11 = l1lll1l [:l1ll1l1] + l1lll1l [l1ll1l1:]
    if l1ll11l:
        l1l = l1111l () .join ([unichr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    return eval (l1l)
import logging
import os
import re
from l1l1l1l import l11111l1
logger = logging.getLogger(l11l1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1ll11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11l1l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111111():
    try:
        out = os.popen(l11l1l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11l1l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11l1l1 (u"ࠤࠥॸ").join(result)
                logger.info(l11l1l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11l1l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11l1l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11l1l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111l1(l11l1l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11l1l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1ll11(l11l1l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))