#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1l1 = 2048
l1ll11 = 7
def l1lll11 (ll):
    global l11l1
    l11l111 = ord (ll [-1])
    l11ll1l = ll [:-1]
    l1l11 = l11l111 % len (l11ll1l)
    l111l1 = l11ll1l [:l1l11] + l11ll1l [l1l11:]
    if l11l1l:
        l1l111l = l1ll11l1 () .join ([unichr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    else:
        l1l111l = str () .join ([chr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    return eval (l1l111l)
import re
class l11llll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllll1l = kwargs.get(l1lll11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l11ll = kwargs.get(l1lll11 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll1l1 = self.l1lll1lll(args)
        if l1llll1l1:
            args=args+ l1llll1l1
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        l1llll1l1=None
        l11lll1l = args[0][0]
        if re.search(l1lll11 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11lll1l):
            l1llll1l1 = (l1lll11 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lllll1l
                            ,)
        return l1llll1l1
class l111111l(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1l1 = self.l1lll1lll(args)
        if l1llll1l1:
            args = args + l1llll1l1
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        s = l1lll11 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll11 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1111111(Exception):
    pass
class l1ll11ll(Exception):
    pass
class l1lll1l11(Exception):
    def __init__(self, message, l11111l1, url):
        super(l1lll1l11,self).__init__(message)
        self.l11111l1 = l11111l1
        self.url = url
class l1llll11l(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1111l11(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111ll1l(Exception):
    pass