#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll1 = sys.version_info [0] == 2
l111111 = 2048
l111ll1 = 7
def l1lll1ll (l1ll1l1l):
    global l111lll
    l1ll11ll = ord (l1ll1l1l [-1])
    l1llll = l1ll1l1l [:-1]
    l111l = l1ll11ll % len (l1llll)
    l11l1l = l1llll [:l111l] + l1llll [l111l:]
    if l11lll1:
        l1l1ll1 = l111l1l () .join ([unichr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    else:
        l1l1ll1 = str () .join ([chr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    return eval (l1l1ll1)
import re
class l111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1l11 = kwargs.get(l1lll1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11ll = kwargs.get(l1lll1ll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll11l = self.l11111l1(args)
        if l1llll11l:
            args=args+ l1llll11l
        self.args = [a for a in args]
    def l11111l1(self, *args):
        l1llll11l=None
        l1l11l1l = args[0][0]
        if re.search(l1lll1ll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11l1l):
            l1llll11l = (l1lll1ll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1l11
                            ,)
        return l1llll11l
class l1llll1ll(Exception):
    def __init__(self, *args, **kwargs):
        l1llll11l = self.l11111l1(args)
        if l1llll11l:
            args = args + l1llll11l
        self.args = [a for a in args]
    def l11111l1(self, *args):
        s = l1lll1ll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll1ll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll111(Exception):
    pass
class l1l11l1(Exception):
    pass
class l1llllll1(Exception):
    def __init__(self, message, l1lllll1l, url):
        super(l1llllll1,self).__init__(message)
        self.l1lllll1l = l1lllll1l
        self.url = url
class l1111l11(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111111l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1111lll(Exception):
    pass