#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1lll111 = 2048
l1111 = 7
def l1ll (l11lll):
    global l1l1l1
    l1ll1l1 = ord (l11lll [-1])
    l1l1lll = l11lll [:-1]
    l1ll11l1 = l1ll1l1 % len (l1l1lll)
    l111 = l1l1lll [:l1ll11l1] + l1l1lll [l1ll11l1:]
    if l111ll1:
        l11llll = l1ll1l11 () .join ([unichr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    else:
        l11llll = str () .join ([chr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    return eval (l11llll)
import hashlib
import os
import l111111
from l1ll11l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111111 import l1l11ll
from l11l1l1 import l1111ll, l1ll111l
import logging
logger = logging.getLogger(l1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11111():
    def __init__(self, l1ll1l,l111ll, l1111l= None, l11l11l=None):
        self.l111l1l=False
        self.l1ll1111 = self._1lll11l()
        self.l111ll = l111ll
        self.l1111l = l1111l
        self.l111l11 = l1ll1l
        if l1111l:
            self.l1lll1l = True
        else:
            self.l1lll1l = False
        self.l11l11l = l11l11l
    def _1lll11l(self):
        try:
            return l111111.l111l() is not None
        except:
            return False
    def open(self):
        l1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1111:
            raise NotImplementedError(l1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1llllll = self.l111l11
        if self.l111ll.lower().startswith(self.l111l11.lower()):
            l1l1l11 = re.compile(re.escape(self.l111l11), re.IGNORECASE)
            l111ll = l1l1l11.sub(l1ll (u"ࠨࠩࠄ"), self.l111ll)
            l111ll = l111ll.replace(l1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1111l1(self.l111l11, l1llllll, l111ll, self.l1111l)
    def l1111l1(self,l111l11, l1llllll, l111ll, l1111l):
        l1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11l = l11111l(l111l11)
        l1lllll = self.l1l11(l11l)
        logger.info(l1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11l)
        if l1lllll:
            logger.info(l1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l11ll(l11l)
            l11l = l1l(l111l11, l1llllll, l1111l, self.l11l11l)
        logger.debug(l1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1l1l=l11l + l1ll (u"ࠤ࠲ࠦࠌ") + l111ll
        ll = l1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1l1l+ l1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(ll)
        l1l1 = os.system(ll)
        if (l1l1 != 0):
            raise IOError(l1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1l1l, l1l1))
    def l1l11(self, l11l):
        if os.path.exists(l11l):
            if os.path.islink(l11l):
                l11l = os.readlink(l11l)
            if os.path.ismount(l11l):
                return True
        return False
def l11111l(l111l11):
    l1ll11 = l111l11.replace(l1ll (u"࠭࡜࡝ࠩࠐ"), l1ll (u"ࠧࡠࠩࠑ")).replace(l1ll (u"ࠨ࠱ࠪࠒ"), l1ll (u"ࠩࡢࠫࠓ"))
    l11ll = l1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1llll=os.environ[l1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1111=os.path.join(l1llll,l11ll, l1ll11)
    l11l1=os.path.abspath(l1l1111)
    return l11l1
def l1l1ll1(l1):
    if not os.path.exists(l1):
        os.makedirs(l1)
def l1lllll1(l111l11, l1llllll, l1l1ll=None, password=None):
    l1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1 = l11111l(l111l11)
    l1l1ll1(l1)
    if not l1l1ll:
        l1ll1l1l = l1ll1lll()
        l11ll1l =l1ll1l1l.l11l1ll(l1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1llllll + l1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1llllll + l1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11ll1l, str):
            l1l1ll, password = l11ll1l
        else:
            raise l1ll111l()
        logger.info(l1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1))
    l1llll11 = pwd.getpwuid( os.getuid())[0]
    l1l111l=os.environ[l1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l11l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll1l1={l1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1llll11, l1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111l11, l1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1, l1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l111l, l1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1ll, l1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll1l1, temp_file)
        if not os.path.exists(os.path.join(l1l11l1, l1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll11=l1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1ll (u"ࠧࠨࠤ")
        else:
            l1lll11=l1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11l111=l1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll11,temp_file.name)
        l1ll1ll=[l1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l11l1, l11l111)]
        p = subprocess.Popen(l1ll1ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1
    logger.debug(l1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11l1=os.path.abspath(l1)
    logger.debug(l1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11l1)
    return l11l1
def l1l(l111l11, l1llllll, l1111l, l11l11l):
    l1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11ll1(title):
        l11=30
        if len(title)>l11:
            l1ll111=title.split(l1ll (u"ࠨ࠯ࠣ࠳"))
            l1ll11ll=l1ll (u"ࠧࠨ࠴")
            for block in l1ll111:
                l1ll11ll+=block+l1ll (u"ࠣ࠱ࠥ࠵")
                if len(l1ll11ll) > l11:
                    l1ll11ll+=l1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll11ll
        return title
    def l1lll(l11l1l, password):
        l1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll (u"ࠧࠦࠢ࠹").join(l11l1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11lll1 = l1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11lll1.encode())
        l1llll1l = [l1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll1 = l1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll1)
            for e in l1llll1l:
                if e in l1ll1: return False
            raise l1111ll(l1ll1, l1l=l111111.l111l(), l1llllll=l1llllll)
        logger.info(l1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l1ll = l1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll (u"ࠦࠧ࠿")
    os.system(l1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11l11 = l11111l(l111l11)
    l1 = l11111l(hashlib.sha1(l111l11.encode()).hexdigest()[:10])
    l1l1ll1(l1)
    logger.info(l1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1))
    if l1111l:
        l11l1l = [l1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll (u"ࠤ࠰ࡸࠧࡄ"), l1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll (u"ࠫ࠲ࡵࠧࡆ"), l1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l1ll, l1111l),
                    urllib.parse.unquote(l1llllll), os.path.abspath(l1)]
        l1lll(l11l1l, password)
    else:
        while True:
            l1l1ll, password = l1llll1(l1, l1llllll, l11l11l)
            if l1l1ll.lower() != l1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l1l = [l1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll (u"ࠤ࠰ࡸࠧࡋ"), l1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll (u"ࠫ࠲ࡵࠧࡍ"), l1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l1ll,
                            urllib.parse.unquote(l1llllll), os.path.abspath(l1)]
            else:
                raise l1ll111l()
            if l1lll(l11l1l, password): break
    os.system(l1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1, l11l11))
    l11l1=os.path.abspath(l11l11)
    return l11l1
def l1llll1(l111l11, l1llllll, l11l11l):
    l1l1l = os.path.join(os.environ[l1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l1l)):
       os.makedirs(os.path.dirname(l1l1l))
    l1lll1ll = l11l11l.get_value(l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll1l1l = l1ll1lll(l111l11, l1lll1ll)
    l1l1ll, password = l1ll1l1l.l11l1ll(l1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1llllll + l1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1llllll + l1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l1ll != l1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11ll11(l111l11, l1l1ll):
        l1ll1ll1 = l1ll (u"ࠤ࡙ࠣࠦ").join([l111l11, l1l1ll, l1ll (u"࡚ࠪࠦࠬ") + password + l1ll (u"࡛ࠫࠧ࠭"), l1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l1l, l1ll (u"࠭ࡷࠬࠩ࡝")) as l111lll:
            l111lll.write(l1ll1ll1)
        os.chmod(l1l1l, 0o600)
    return l1l1ll, password
def l11ll11(l111l11, l1l1ll):
    l1l1l = l111l1 = os.path.join(os.environ[l1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l1l):
        with open(l1l1l, l1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l11l = data[0].split(l1ll (u"ࠦࠥࠨࡢ"))
            if l111l11 == l1l11l[0] and l1l1ll == l1l11l[1]:
                return True
    return False