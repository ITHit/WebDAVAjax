#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111lll = 2048
l1lll11 = 7
def l1l1l11 (l1l11):
    global l111l
    l1ll1l11 = ord (l1l11 [-1])
    l11l = l1l11 [:-1]
    l1lll = l1ll1l11 % len (l11l)
    l1lll11l = l11l [:l1lll] + l11l [l1lll:]
    if l1ll1l:
        l11ll1l = l1llll1l () .join ([unichr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    return eval (l11ll1l)
import gi
gi.require_version(l1l1l11 (u"࠭ࡇࡵ࡭ࠪ঻"), l1l1l11 (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1111l
import logging
logger = logging.getLogger(l1l1l11 (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l11l1l(Gtk.Window):
    def __init__(self, l1l11lll1l, l1l1l11111):
        Gtk.Window.__init__(self)
        self.l1lllll=30
        self.l1l1l1l1l1 = False
        self.service = l1l11lll1l
        self.l1l1l1l=l1l1l11111
        self.l11lll1=l1l1111l.l1l1ll11
        self.l1ll1l1111 = Gtk.ListStore(str)
        self.l1ll11l11l()
    def l1ll111lll(self, service):
        l1lll1111l = self.l11lll1.l11lll11(l1l1l11 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1lll1111l
    def l1ll11l11l(self, l1l11lll1l=None):
        if l1l11lll1l:
            self.l1ll1l1111.clear()
            l1l1l1ll1l=self.l1ll111lll(l1l11lll1l)
            self.l1ll1l1111.append([l1l1l11 (u"ࠥࠦি")])
            for l1l1l1l in l1l1l1ll1l:
                self.l1ll1l1111.append([l1l1l1l])
        else:
            self.l1ll1l1111.clear()
            self.l1ll1l1111.append([l1l1l11 (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1ll1l11ll(self, widget, data=None):
        l1l1l11lll= widget.get_active()
        if data == l1l1l11 (u"ࠧ࠷ࠢু") and l1l1l11lll:
            self.l1ll11l11l()
            self.l1ll111l1l.set_active(0)
            self.l1ll1111l1.set_text(l1l1l11 (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1ll1111l1.set_sensitive(False)
            self.l1ll111l1l.set_sensitive(False)
        else:
            self.l1ll11l11l(l1l11lll1l=self.service)
            self.l1ll111l1l.set_active(0)
            self.l1ll1111l1.set_text(l1l1l11 (u"ࠢࠣৃ"))
            self.l1ll111l1l.set_sensitive(True)
            self.l1ll1111l1.set_sensitive(True)
    def l1ll11111l(self, widget):
        if widget.get_active():
            l1l1l1l = widget.get_child().get_text()
        else:
            l1l1l1l = self.l1ll1l1111[widget.get_active()][0]
        password = self.l1l11l1ll1(self.service, l1l1l1l)
        if password:
            self.l1ll1111l1.set_text(password)
        else:
            self.l1ll1111l1.set_text(l1l1l11 (u"ࠣࠤৄ"))
    def l1l11ll1ll(self, l1l1l1l, pwd, service):
        keyring.set_password(service, l1l1l1l, pwd)
        l1lll1111l=self.l11lll1.l11lll11(l1l1l11 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l1l1l1l in l1lll1111l:
            value = self.l11lll1.get_value(l1l1l11 (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l11lll1.l1l11l1l(l1l1l11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l1l1l11 (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l1l1l1l))
    def l1l11l1ll1(self, service, l1l1l1l):
        l1l1llllll = keyring.get_password(service, l1l1l1l)
        return l1l1llllll
    def l1l11lll11(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l11llll1(self, widget, data=None):
        self.l1l1l1l1l1=widget.get_active()
    def l111111(self, message, title=l1l1l11 (u"࠭ࠧ৉"), l11111l11=True):
        if l11111l11:
            l1l1lll11l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1ll111 = Gtk.MessageDialog(self,
            l1l1lll11l,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1ll111.set_title(title)
        l1ll1ll111.set_default_response(Gtk.ResponseType.OK)
        l1l11lllll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l11ll11l = Gtk.VBox()
        l1l11ll1l1 = Gtk.Box(spacing=1)
        l1l11ll1l1.set_homogeneous(False)
        l1l1ll111l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1ll111l.set_homogeneous(False)
        l1l1lll111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll111.set_homogeneous(False)
        l1l11ll1l1.pack_start(l1l1ll111l, True, True, 0)
        l1l11ll1l1.pack_start(l1l1lll111, True, True, 0)
        l1l1llll11 = l1ll1ll111.get_content_area()
        l1ll1111ll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1llll11.pack_start(l1ll1111ll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll11ll1l = Gtk.Label()
        l1ll11l1l1 = Gtk.Label()
        l1ll11l1l1.set_text(l1l1l11 (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1ll11l1l1, True, True, 0)
        l1ll11ll1l.set_text(l1l1l11 (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1ll11ll1l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll11ll1l, 0, 1, 0, 1)
        l1l1ll1111 = Gtk.RadioButton.new_with_label_from_widget(None, l1l1l11 (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1l1ll1111.connect(l1l1l11 (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1ll1l11ll, l1l1l11 (u"ࠦ࠶ࠨৎ"))
        table.attach(l1l1ll1111, 1, 2, 0, 1)
        l1ll1lll11 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1111, l1l1l11 (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1ll1lll11.connect(l1l1l11 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1ll1l11ll, l1l1l11 (u"ࠢ࠳ࠤ৑"))
        table.attach(l1ll1lll11, 1, 2, 1, 2)
        l1l1ll11l1 = Gtk.Label()
        l1l1ll11l1.set_text(l1l1l11 (u"ࠣࠢࠥ৒"))
        table.attach(l1l1ll11l1, 0, 1, 4, 6)
        l1l1ll1l11 = Gtk.Label()
        l1l1ll1l11.set_text(l1l1l11 (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1l1ll1l11.set_justify(Gtk.Justification.RIGHT)
        l1l1ll1l11.set_alignment(xalign=1, yalign=0.5)
        self.l1ll111l1l = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1l1111)
        self.l1ll111l1l.set_entry_text_column(0)
        table.attach(l1l1ll1l11, 0, 1, 6, 8)
        table.attach(self.l1ll111l1l, 1, 3, 6, 8)
        self.l1ll111l1l.connect(l1l1l11 (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1ll11111l)
        l1l1l1l111 = Gtk.Label()
        l1l1l1l111.set_text(l1l1l11 (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1l1l1l111.set_justify(Gtk.Justification.RIGHT)
        l1l1l1l111.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1111l1 = Gtk.Entry()
        self.l1ll1111l1.set_visibility(False)
        self.l1ll1111l1.connect(l1l1l11 (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1l11lll11, l1ll1ll111)
        table.attach(l1l1l1l111, 0, 1, 8, 10)
        table.attach(self.l1ll1111l1, 1, 3, 8, 10)
        l1l1l1l1ll = Gtk.CheckButton(l1l1l11 (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1l1l1l1ll.connect(l1l1l11 (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1l11llll1, l1l1l1l1ll)
        l1l1l1l1ll.set_active(False)
        table.attach(l1l1l1l1ll, 1, 3, 12, 14)
        l1ll11llll = Gtk.Label()
        l1ll11llll.set_text(l1l1l11 (u"ࠣࠢࠥ৙") * 5)
        l1l11ll11l.pack_start(l1ll11llll, True, True, 0)
        if self.l1l1l1l:
            l1ll1lll11.set_active(True)
            self.l1ll111l1l.set_active(0)
            self.l1ll111l1l.set_sensitive(True)
            self.l1ll1111l1.set_text(l1l1l11 (u"ࠤࠥ৚"))
            self.l1ll1111l1.set_sensitive(True)
        else:
            self.l1ll111l1l.set_active(0)
            self.l1ll111l1l.set_sensitive(False)
            self.l1ll1111l1.set_text(l1l1l11 (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1ll1111l1.set_sensitive(False)
        l1l11lllll.pack_start(vbox, True, True, 0)
        l1l11lllll.pack_start(table, True, True, 0)
        l1l11lllll.pack_end(l1l11ll11l, True, True, 0)
        l1ll1111ll.pack_start(l1l11lllll, True, True, 0)
        l1ll1ll111.show_all()
        response = l1ll1ll111.run()
        if self.l1ll111l1l.get_active():
            l1l1l1l = self.l1ll111l1l.get_child().get_text()
        else:
            l1l1l1l = self.l1ll1l1111[self.l1ll111l1l.get_active()][0]
        pwd = self.l1ll1111l1.get_text()
        l1ll1ll111.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1l1l1l1:
                self.l1l11ll1ll(l1l1l1l, pwd, self.service)
            return l1l1l1l, pwd
        else:
            return l1l1l11 (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l1l1l11 (u"ࠬ࠭ঢ়")
class l1l1l11l1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1lll1ll(self, l1l11l11):
        l1ll1l1l11 = Gtk.ScrolledWindow()
        l1ll1l1l11.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll1ll1l1=None
        self.l1l1l11l11 = Gtk.TextBuffer()
        self.l1l1l11l11.set_text(l1l11l11)
        self.set_style()
        regexp= l1l1l11 (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1l1l1lll1 = self._1ll11ll11(l1l11l11, regexp)
        self.l1l11l1lll(l1l1l1lll1, self.l1l1l11l11.get_start_iter())
        self.l1lll11111 = Gtk.TextView(buffer=self.l1l1l11l11)
        self.l1lll11111.set_property(l1l1l11 (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1lll11111.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1lll11111.connect(l1l1l11 (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1ll1l1lll)
        self.l1lll11111.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1l1l11.set_size_request(300,100)
        self.l1lll11111.show()
        l1ll1l1l11.add(self.l1lll11111)
        l1ll1l1l11.show()
        return l1ll1l1l11
    def _1ll1l1lll(self, *args, **kwargs):
        l1l1ll11ll, l1l1l11l1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1ll11ll, l1l1l11l1l).get_tags()
        if not self.l1ll1ll1l1:
            self.l1ll1ll1l1 = args[1].window.get_cursor()
            self.l1l1l1ll11 = Gdk.Cursor(Gdk.CursorType.l1ll11l1ll)
        elif tag:
            args[1].window.set_cursor(self.l1l1l1ll11)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll1ll1l1:
                args[1].window.set_cursor(self.l1ll1ll1l1)
    def _1ll11ll11(self, l1l11l11, l1ll11l111):
        res=[]
        l1ll1ll1ll=re.findall(l1ll11l111,l1l11l11)
        for l1ll1lllll in l1ll1ll1ll:
            for el in l1ll1lllll:
                if el:
                    res.append(el)
        return res
    def l1l11l1lll(self, l1l1l1lll1, start):
        l1l1l1l11l=0
        for text in l1l1l1lll1:
            end = self.l1l1l11l11.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l1l11l+=1
                l1l1llll1l, l1ll1ll11l = match
                tag = self.l1l1l11l11.create_tag(str(l1l1l1l11l), foreground=l1l1l11 (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1l1l11 (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1ll1l1ll1, text)
                self.l1l1l11l11.apply_tag(tag, l1l1llll1l, l1ll1ll11l)
                self.l1l11l1lll(l1l1l1lll1, l1ll1ll11l)
    def _1ll1l1ll1(self, tag, widget, l1l1ll1l1l, _1ll11lll1, text):
        _1ll1l111l = l1l1ll1l1l.type
        _1ll111ll1 = l1l1ll1l1l.window
        if _1ll1l111l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll1l111l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1ll1l1l.button
            self.l1ll1ll1l1 = Gdk.Cursor(Gdk.CursorType.l1ll11l1ll)
            if _1ll1l111l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1l1l11 (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1ll11lll(self, message, title=l1l1l11 (u"ࠬ࠭৤"), l11111l11=True, l1l1ll1lll=None):
        if l11111l11:
            l1l1lll11l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1lll11l,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1ll1lll:
            l1l1llll11 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l11ll1l1 = Gtk.HBox(spacing=0)
            l1l1lllll1 = Gtk.HBox(spacing=5)
            l1l11ll111 = Gtk.Label()
            l1l11ll111.set_markup(l1l1l11 (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1l11ll111.set_line_wrap(True)
            l1l11ll111.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1l1l11 (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1l1llll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1llll.show()
            l1ll1l11l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l11l1.show()
            l1ll1l1l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l1l.show()
            l1l11ll1l1.pack_start(separator, True, True, 0)
            l1l11ll1l1.pack_start(l1l1l1llll, True, True, 0)
            l1l11ll1l1.pack_start(l1ll1l11l1, True, True, 0)
            l1l11ll1l1.pack_start(l1ll1l1l1l, True, True, 0)
            l1l11ll1l1.pack_start(l1l11ll111, False, True, 0)
            l1ll111111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111111.show()
            l1l11ll1l1.pack_end(l1ll111111, True, True, 0)
            l1l1ll1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1ll1.show()
            vbox.pack_start(l1l11ll1l1, True, True, 0)
            l1ll1l1l11=self.__1l1lll1ll(l1l11l11=l1l1ll1lll)
            vbox.pack_start(l1ll1l1l11, False, False, 0)
            vbox.pack_end(l1l1ll1ll1, False, False, 0)
            l1l1lllll1.pack_start(vbox, True, True,5)
            l1l1lllll1.show()
            l1l1llll11.pack_end(l1l1lllll1, False, False, 0)
            vbox.show()
            l1l11ll1l1.show()
        window.run()
class l1l1lllll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l111l1(self, widget, l1ll111l11):
        if l1ll111l11 == Gtk.ResponseType.OK:
            self.result = l1l1l11 (u"ࠣࡑࡎࠦ১")
        elif l1ll111l11 == Gtk.ResponseType.CANCEL:
            self.result = l1l1l11 (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1ll111l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1l1l11 (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1111111l(self, title=l1l1l11 (u"ࠦࠧ৪"), message=l1l1l11 (u"ࠧࠨ৫") , l11111l11=True):
        if l11111l11:
            l1l1lll11l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll11l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1l1l11 (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1l1l111l1)
        window.run()
class l1l1l11ll1(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1llll1=None
        self.result = None
    def l1l1l111l1(self, widget, l1ll111l11):
        print(widget, l1ll111l11)
        if l1ll111l11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll111l11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll111l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l11llll1(self, widget, l1l1l1111l):
        if l1l1l1111l.get_active():
            self.l1ll1llll1 = 1
        else:
            self.l1ll1llll1 = 0
    def l1l1lll1l1(self, title=l1l1l11 (u"ࠢࠣ৭"), message=l1l1l11 (u"ࠣࠤ৮"), l1l11l1l1l =l1l1l11 (u"ࠤࠥ৯"),l11111l11=True):
        if l11111l11:
            l1l1lll11l= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll11l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1l1l11 (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1l1l111l1)
        l1l1l1l1ll = Gtk.CheckButton(l1l11l1l1l)
        l1l1l1l1ll.connect(l1l1l11 (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1l11llll1, l1l1l1l1ll)
        l1l1l1l1ll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1l1l1ll, expand=True, fill=True, padding=0)
        l1l1l1l1ll.show()
        window.run()
def l1ll1l11l(title, msg, l1l11l1l1l=l1l1l11 (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l11111l11=True):
    result=None
    try:
        l1ll1lll1l = l1l1l11ll1()
        l1ll1lll1l.l1l1lll1l1(title, msg, l1l11l1l1l, l11111l11)
        result = {l1l1l11 (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1ll1lll1l.result,  l1l1l11 (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1ll1lll1l.l1ll1llll1}
    except Exception as e:
        logger.exception(l1l1l11 (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l1l1l11 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l1ll111l1 = l1l1l11l1()
    message= l1l1l11 (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1l1l111ll = l1l1l11 (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l1ll111l1.l1ll11lll(message, l1l1l11 (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l11111l11=True, l1l1ll1lll=l1l1l111ll)