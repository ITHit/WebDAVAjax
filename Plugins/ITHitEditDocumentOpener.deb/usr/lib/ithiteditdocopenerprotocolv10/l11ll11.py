#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1l11 = 7
def l1ll1lll (l1):
    global l1l1lll
    l1lll1l1 = ord (l1 [-1])
    l1l11l1 = l1 [:-1]
    l111l = l1lll1l1 % len (l1l11l1)
    l1ll1l1 = l1l11l1 [:l111l] + l1l11l1 [l111l:]
    if l1l1:
        l11lll = l11llll () .join ([unichr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    return eval (l11lll)
import logging
import os
import re
from l11l11l import l11111l1
logger = logging.getLogger(l1ll1lll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111l11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1lll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111ll1():
    try:
        out = os.popen(l1ll1lll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1lll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1lll (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1lll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1lll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1lll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1lll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111l1(l1ll1lll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1lll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111l11(l1ll1lll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))