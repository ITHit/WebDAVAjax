#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l11l1 (l1llll11):
    global l11l11l
    l1l1l1l = ord (l1llll11 [-1])
    l1llll1l = l1llll11 [:-1]
    l111ll = l1l1l1l % len (l1llll1l)
    l1l11 = l1llll1l [:l111ll] + l1llll1l [l111ll:]
    if l1l11l:
        l11ll1l = l1111 () .join ([unichr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    return eval (l11ll1l)
import re
class l1lll(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111ll = kwargs.get(l11l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1lll1ll = kwargs.get(l11l1 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111l11 = self.l1llll111(args)
        if l1111l11:
            args=args+ l1111l11
        self.args = [a for a in args]
    def l1llll111(self, *args):
        l1111l11=None
        l1l111ll = args[0][0]
        if re.search(l11l1 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l111ll):
            l1111l11 = (l11l1 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l11111ll
                            ,)
        return l1111l11
class l1lllllll(Exception):
    def __init__(self, *args, **kwargs):
        l1111l11 = self.l1llll111(args)
        if l1111l11:
            args = args + l1111l11
        self.args = [a for a in args]
    def l1llll111(self, *args):
        s = l11l1 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l11l1 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1111111(Exception):
    pass
class l111lll(Exception):
    pass
class l11111l1(Exception):
    def __init__(self, message, l1llll1ll, url):
        super(l11111l1,self).__init__(message)
        self.l1llll1ll = l1llll1ll
        self.url = url
class l1lllll11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l111111l(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1111l1l(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1111ll1(Exception):
    pass
class l11l1l1l(Exception):
    pass