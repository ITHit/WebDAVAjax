#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1l111l = 7
def l1ll1l1l (l11ll1l):
    global l1l11
    l1 = ord (l11ll1l [-1])
    l1lll = l11ll1l [:-1]
    l1lllll = l1 % len (l1lll)
    l1lll11 = l1lll [:l1lllll] + l1lll [l1lllll:]
    if l1l1ll1:
        l1l11l = l111l11 () .join ([unichr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    return eval (l1l11l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11l1l1 import l1111l
from configobj import ConfigObj
l1l1l1l1 = l1ll1l1l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11l1lll = l1ll1l1l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠺࠼࠹࠳࠶ࠢࡤ")
l1l111l1 = l1ll1l1l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll1l1l (u"ࠣ࠷࠱࠶࠶࠴࠵࠹࠻࠸࠲࠵ࠨࡦ")
l1l11l1l=os.path.join(os.environ.get(l1ll1l1l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll1l1l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l111l1.replace(l1ll1l1l (u"ࠦࠥࠨࡩ"), l1ll1l1l (u"ࠧࡥࠢࡪ")).lower())
l1l1l1ll=os.environ.get(l1ll1l1l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll1l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1111l=l11l1lll.replace(l1ll1l1l (u"ࠣࠢࠥ࡭"), l1ll1l1l (u"ࠤࡢࠦ࡮"))+l1ll1l1l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll1l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11111=os.path.join(os.environ.get(l1ll1l1l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1111l)
elif platform.system() == l1ll1l1l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l11lll=l1111l(l1l11l1l+l1ll1l1l (u"ࠢ࠰ࠤࡳ"))
    l1l11111 = os.path.join(l1l11lll, l1l1111l)
else:
    l1l11111 = os.path.join( l1l1111l)
l1l1l1ll=l1l1l1ll.upper()
if l1l1l1ll == l1ll1l1l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1l111=logging.DEBUG
elif l1l1l1ll == l1ll1l1l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1l111 = logging.INFO
elif l1l1l1ll == l1ll1l1l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1l111 = logging.WARNING
elif l1l1l1ll == l1ll1l1l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1l111 = logging.ERROR
elif l1l1l1ll == l1ll1l1l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1l111 = logging.CRITICAL
elif l1l1l1ll == l1ll1l1l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1l111 = logging.NOTSET
logger = logging.getLogger(l1ll1l1l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1l111)
l1l1l11l = logging.FileHandler(l1l11111, mode=l1ll1l1l (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l11l.setLevel(l1l1l111)
formatter = logging.Formatter(l1ll1l1l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll1l1l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l111)
l1l11l11 = SysLogHandler(address=l1ll1l1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l1l11l)
logger.addHandler(ch)
logger.addHandler(l1l11l11)
class Settings():
    l11ll11l = l1ll1l1l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11llll1 = l1ll1l1l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11lll11 = l1ll1l1l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11l1lll):
        self.l11lllll = self._1l111ll(l11l1lll)
        self._11ll1l1()
    def _1l111ll(self, l11l1lll):
        l11ll111 = l11l1lll.split(l1ll1l1l (u"ࠣࠢࠥࢂ"))
        l11ll111 = l1ll1l1l (u"ࠤࠣࠦࢃ").join(l11ll111)
        if platform.system() == l1ll1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11lllll = os.path.join(l1l11l1l, l1ll1l1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11ll111 + l1ll1l1l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11lllll
    def l1l1ll1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11ll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1l1l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1l1l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1ll11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll1l1(self):
        if not os.path.exists(os.path.dirname(self.l11lllll)):
            os.makedirs(os.path.dirname(self.l11lllll))
        if not os.path.exists(self.l11lllll):
            self.config = ConfigObj(self.l11lllll)
            self.config[l1ll1l1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll1l1l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll1l1l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11lll11
            self.config[l1ll1l1l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1l1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11llll1
            self.config[l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll11l
            self.config[l1ll1l1l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lllll)
            self.l11lll11 = self.get_value(l1ll1l1l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll1l1l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11llll1 = self.get_value(l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1l1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll11l = self.get_value(l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lll1l(self):
        l1l1lll1 = l1ll1l1l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll11l
        l1l1lll1 += l1ll1l1l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11llll1
        l1l1lll1 += l1ll1l1l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11lll11
        return l1l1lll1
    def __unicode__(self):
        return self._11lll1l()
    def __str__(self):
        return self._11lll1l()
    def __del__(self):
        self.config.write()
l11ll1ll = Settings(l11l1lll)