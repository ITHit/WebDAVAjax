#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def l111l (l111l1l):
    global l1l1ll1
    l1l11l1 = ord (l111l1l [-1])
    l1lllll1 = l111l1l [:-1]
    l1l1l1 = l1l11l1 % len (l1lllll1)
    l1ll1lll = l1lllll1 [:l1l1l1] + l1lllll1 [l1l1l1:]
    if l11l11:
        l1llll1l = l111l1 () .join ([unichr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1llll1l = str () .join ([chr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1llll1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll11l import l11l1ll
from configobj import ConfigObj
l1l111ll = l111l (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l11ll1 = l111l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠷࠶࠱࠴ࠧࡢ")
l1l111l1 = l111l (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l111l (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠶࠵࠰࠳ࠦࡤ")
l11lll11=os.path.join(os.environ.get(l111l (u"ࠧࡉࡑࡐࡉࠬࡥ")),l111l (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l111l1.replace(l111l (u"ࠤࠣࠦࡧ"), l111l (u"ࠥࡣࠧࡨ")).lower())
l1ll1111=os.environ.get(l111l (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l111l (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l11lll1l=l1l11ll1.replace(l111l (u"ࠨࠠࠣ࡫"), l111l (u"ࠢࡠࠤ࡬"))+l111l (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1l111=os.path.join(os.environ.get(l111l (u"ࠪࡘࡊࡓࡐࠨ࡯")),l11lll1l)
elif platform.system() == l111l (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l11l11=l11l1ll(l11lll11+l111l (u"ࠧ࠵ࠢࡱ"))
    l1l1l111 = os.path.join(l1l11l11, l11lll1l)
else:
    l1l1l111 = os.path.join( l11lll1l)
l1ll1111=l1ll1111.upper()
if l1ll1111 == l111l (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l1l1ll=logging.DEBUG
elif l1ll1111 == l111l (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l1l1ll = logging.INFO
elif l1ll1111 == l111l (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l1l1ll = logging.WARNING
elif l1ll1111 == l111l (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l1l1ll = logging.ERROR
elif l1ll1111 == l111l (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l1l1ll = logging.CRITICAL
elif l1ll1111 == l111l (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l1l1ll = logging.NOTSET
logger = logging.getLogger(l111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l1l1ll)
l1l1l1l1 = logging.FileHandler(l1l1l111, mode=l111l (u"ࠨࡷࠬࠤࡹ"))
l1l1l1l1.setLevel(l1l1l1ll)
formatter = logging.Formatter(l111l (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l111l (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l1l1l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l1ll)
l11ll1l1 = SysLogHandler(address=l111l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l11ll1l1.setFormatter(formatter)
logger.addHandler(l1l1l1l1)
logger.addHandler(ch)
logger.addHandler(l11ll1l1)
class Settings():
    l1ll111l = l111l (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11llll1 = l111l (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l1l11l = l111l (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l11ll1):
        self.l1l11l1l = self._11lllll(l1l11ll1)
        self._1l1ll1l()
    def _11lllll(self, l1l11ll1):
        l11ll11l = l1l11ll1.split(l111l (u"ࠨࠠࠣࢀ"))
        l11ll11l = l111l (u"ࠢࠡࠤࢁ").join(l11ll11l)
        if platform.system() == l111l (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l11l1l = os.path.join(l11lll11, l111l (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l11ll11l + l111l (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l11l1l
    def l1l1lll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111l (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111l (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1111l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1ll1l(self):
        if not os.path.exists(os.path.dirname(self.l1l11l1l)):
            os.makedirs(os.path.dirname(self.l1l11l1l))
        if not os.path.exists(self.l1l11l1l):
            self.config = ConfigObj(self.l1l11l1l)
            self.config[l111l (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l111l (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l111l (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l1l11l
            self.config[l111l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l111l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11llll1
            self.config[l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1ll111l
            self.config[l111l (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11l1l)
            self.l1l1l11l = self.get_value(l111l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l111l (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11llll1 = self.get_value(l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l111l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1ll111l = self.get_value(l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1ll11(self):
        l1l11111 = l111l (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1ll111l
        l1l11111 += l111l (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11llll1
        l1l11111 += l111l (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l1l11l
        return l1l11111
    def __unicode__(self):
        return self._1l1ll11()
    def __str__(self):
        return self._1l1ll11()
    def __del__(self):
        self.config.write()
l1l11lll = Settings(l1l11ll1)