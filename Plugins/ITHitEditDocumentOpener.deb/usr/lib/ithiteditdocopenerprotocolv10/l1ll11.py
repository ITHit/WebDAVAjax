#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l1 = sys.version_info [0] == 2
l111ll = 2048
l11111l = 7
def l1ll1ll (l11llll):
    global l1ll11l
    l111lll = ord (l11llll [-1])
    l1l1 = l11llll [:-1]
    l1llll1l = l111lll % len (l1l1)
    l1l1l1l = l1l1 [:l1llll1l] + l1l1 [l1llll1l:]
    if l1l11l1:
        l1ll1l1l = l1111ll () .join ([unichr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    else:
        l1ll1l1l = str () .join ([chr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    return eval (l1ll1l1l)
import re
class l1llll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllllll = kwargs.get(l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11lll1 = kwargs.get(l1ll1ll (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1lllll1l = self.l1llllll1(args)
        if l1lllll1l:
            args=args+ l1lllll1l
        self.args = [a for a in args]
    def l1llllll1(self, *args):
        l1lllll1l=None
        l11ll1ll = args[0][0]
        if re.search(l1ll1ll (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l11ll1ll):
            l1lllll1l = (l1ll1ll (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1lllllll
                            ,)
        return l1lllll1l
class l1llll1ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll1l = self.l1llllll1(args)
        if l1lllll1l:
            args = args + l1lllll1l
        self.args = [a for a in args]
    def l1llllll1(self, *args):
        s = l1ll1ll (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1ll1ll (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1111ll1(Exception):
    pass
class l11l1l1(Exception):
    pass
class l11111ll(Exception):
    def __init__(self, message, l1111l1l, url):
        super(l11111ll,self).__init__(message)
        self.l1111l1l = l1111l1l
        self.url = url
class l1lll1l1l(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1111l11(Exception):
    pass
class l111111l(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111ll1l(Exception):
    pass