#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l11 = sys.version_info [0] == 2
l1 = 2048
l1ll11ll = 7
def l1l1lll (l11l11):
    global l11l11l
    l11l1l = ord (l11l11 [-1])
    l1ll1111 = l11l11 [:-1]
    l1ll11l = l11l1l % len (l1ll1111)
    l1l1l1l = l1ll1111 [:l1ll11l] + l1ll1111 [l1ll11l:]
    if l111l11:
        l1ll = ll () .join ([unichr (ord (char) - l1 - (l1ll1ll1 + l11l1l) % l1ll11ll) for l1ll1ll1, char in enumerate (l1l1l1l)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1ll1ll1 + l11l1l) % l1ll11ll) for l1ll1ll1, char in enumerate (l1l1l1l)])
    return eval (l1ll)
import logging
import os
import re
from l1lll1l import l1lllllll
logger = logging.getLogger(l1l1lll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1l1ll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1lll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l111l():
    try:
        out = os.popen(l1l1lll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l1lll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l1lll (u"ࠤࠥॸ").join(result)
                logger.info(l1l1lll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l1lll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l1lll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l1lll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lllllll(l1l1lll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l1lll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1l1ll1(l1l1lll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))