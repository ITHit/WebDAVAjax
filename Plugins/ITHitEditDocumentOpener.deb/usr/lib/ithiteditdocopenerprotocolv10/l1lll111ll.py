#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def l111l (l111l1l):
    global l1l1ll1
    l1l11l1 = ord (l111l1l [-1])
    l1lllll1 = l111l1l [:-1]
    l1l1l1 = l1l11l1 % len (l1lllll1)
    l1ll1lll = l1lllll1 [:l1l1l1] + l1lllll1 [l1l1l1:]
    if l11l11:
        l1llll1l = l111l1 () .join ([unichr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1llll1l = str () .join ([chr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1llll1l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11l1=logging.WARNING
logger = logging.getLogger(l111l (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll11l1)
l11ll1l1 = SysLogHandler(address=l111l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l111l (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l11ll1l1.setFormatter(formatter)
logger.addHandler(l11ll1l1)
ch = logging.StreamHandler()
ch.setLevel(l1llll11l1)
logger.addHandler(ch)
class l1lll1llll(io.FileIO):
    l111l (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l111l (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1llllll11, l1lll1lll1,
                     options, d=0, p=0):
            self.device = device
            self.l1llllll11 = l1llllll11
            self.l1lll1lll1 = l1lll1lll1
            if not options:
                options = l111l (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l111l (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1llllll11,
                                              self.l1lll1lll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lllll11l = os.path.join(os.path.sep, l111l (u"ࠨࡧࡷࡧࠬঅ"), l111l (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l111 = path
        else:
            self._1lll1l111 = self.l1lllll11l
        super(l1lll1llll, self).__init__(self._1lll1l111, l111l (u"ࠪࡶࡧ࠱ࠧই"))
    def _1llll111l(self, line):
        return l1lll1llll.Entry(*[x for x in line.strip(l111l (u"ࠦࡡࡴࠢঈ")).split() if x not in (l111l (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l111l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l111l (u"ࠢࠤࠤঋ")):
                    yield self._1llll111l(line)
            except ValueError:
                pass
    def l1lll111l1(self, attr, value):
        for entry in self.entries:
            l1lll11l11 = getattr(entry, attr)
            if l1lll11l11 == value:
                return entry
        return None
    def l11111111(self, entry):
        if self.l1lll111l1(l111l (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l111l (u"ࠩ࡟ࡲࠬ঍")).encode(l111l (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll11lll(self, entry):
        self.seek(0)
        lines = [l.decode(l111l (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l111l (u"ࠧࠩࠢঐ")):
                if self._1llll111l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l111l (u"࠭ࠧ঑").join(lines).encode(l111l (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll11(cls, l1llllll11, path=None):
        l1lllllll1 = cls(path=path)
        entry = l1lllllll1.l1lll111l1(l111l (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1llllll11)
        if entry:
            return l1lllllll1.l1lll11lll(entry)
        return False
    @classmethod
    def add(cls, device, l1llllll11, l1lll1lll1, options=None, path=None):
        return cls(path=path).l11111111(l1lll1llll.Entry(device,
                                                    l1llllll11, l1lll1lll1,
                                                    options=options))
class l1llll1l11(object):
    def __init__(self, l1lll1l1ll):
        self.l1lllll111=l111l (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1llll1lll=l111l (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1lll1l1ll=l1lll1l1ll
        self.l1lll11ll1()
        self.l1llll1111()
        self.l1lllll1ll()
        self.l1lll1l1l1()
        self.l1lll1l11l()
    def l1lll11ll1(self):
        temp_file=open(l1llll11ll,l111l (u"ࠫࡷ࠭খ"))
        l1ll1=temp_file.read()
        data=json.loads(l1ll1)
        self.user=data[l111l (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1111ll=data[l111l (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1l1ll=data[l111l (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1ll11ll=data[l111l (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lllll1l1=data[l111l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1llll1l1l=data[l111l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lllll1ll(self):
        l11l11l=os.path.join(l111l (u"ࠦ࠴ࠨঝ"),l111l (u"ࠧࡻࡳࡳࠤঞ"),l111l (u"ࠨࡳࡣ࡫ࡱࠦট"),l111l (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l111l (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l11l11l)
    def l1lll1l11l(self):
        logger.info(l111l (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1l1ll=os.path.join(self.l1ll11ll,self.l1lllll111)
        l1llllllll = pwd.getpwnam(self.user).pw_uid
        l1lll11l1l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l1ll):
            os.makedirs(l1l1ll)
            os.system(l111l (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1l1ll))
            logger.debug(l111l (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1l1ll)
        else:
            logger.debug(l111l (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1l1ll)
        l11l11l=os.path.join(l1l1ll, self.l1llll1lll)
        print(l11l11l)
        logger.debug(l111l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l11l11l)
        with open(l11l11l, l111l (u"ࠢࡸ࠭ࠥধ")) as l1llll1ll1:
            logger.debug(self.l1111ll + l111l (u"ࠨࠢࠪন")+self.l1lllll1l1+l111l (u"ࠩࠣࠦࠬ঩")+self.l1llll1l1l+l111l (u"ࠪࠦࠬপ"))
            l1llll1ll1.writelines(self.l1111ll + l111l (u"ࠫࠥ࠭ফ")+self.l1lllll1l1+l111l (u"ࠬࠦࠢࠨব")+self.l1llll1l1l+l111l (u"࠭ࠢࠨভ"))
        os.chmod(l11l11l, 0o600)
        os.chown(l11l11l, l1llllllll, l1lll11l1l)
    def l1llll1111(self, l1llllll1l=l111l (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l111l (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll1l in groups:
            logger.info(l111l (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llllll1l))
        else:
            logger.warning(l111l (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llllll1l))
            l11ll11=l111l (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llllll1l,self.user)
            logger.debug(l111l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l11ll11)
            os.system(l11ll11)
            logger.debug(l111l (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll1l1l1(self):
        logger.debug(l111l (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lllllll1=l1lll1llll()
        l1lllllll1.add(self.l1111ll, self.l1l1ll, l1lll1lll1=l111l (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l111l (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l111l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llll11ll = urllib.parse.unquote(sys.argv[1])
        if l1llll11ll:
            l1lll1ll1l=l1llll1l11(l1llll11ll)
        else:
            raise (l111l (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l111l (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise