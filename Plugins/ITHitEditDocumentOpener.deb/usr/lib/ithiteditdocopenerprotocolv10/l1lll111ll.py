#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1111=logging.WARNING
logger = logging.getLogger(l1lll1l (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll1111)
l1l1ll11 = SysLogHandler(address=l1lll1l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1lll1l (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l1ll11.setFormatter(formatter)
logger.addHandler(l1l1ll11)
ch = logging.StreamHandler()
ch.setLevel(l1llll1111)
logger.addHandler(ch)
class l1lll1ll11(io.FileIO):
    l1lll1l (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1lll1l (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1llllll1l, l1lll11ll1,
                     options, d=0, p=0):
            self.device = device
            self.l1llllll1l = l1llllll1l
            self.l1lll11ll1 = l1lll11ll1
            if not options:
                options = l1lll1l (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1l (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1llllll1l,
                                              self.l1lll11ll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1l11 = os.path.join(os.path.sep, l1lll1l (u"ࠨࡧࡷࡧࠬঅ"), l1lll1l (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lllll11l = path
        else:
            self._1lllll11l = self.l1llll1l11
        super(l1lll1ll11, self).__init__(self._1lllll11l, l1lll1l (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll1lll1(self, line):
        return l1lll1ll11.Entry(*[x for x in line.strip(l1lll1l (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1lll1l (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1l (u"ࠢࠤࠤঋ")):
                    yield self._1lll1lll1(line)
            except ValueError:
                pass
    def l1llll11l1(self, attr, value):
        for entry in self.entries:
            l1llllllll = getattr(entry, attr)
            if l1llllllll == value:
                return entry
        return None
    def l1lll1l1ll(self, entry):
        if self.l1llll11l1(l1lll1l (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1lll1l (u"ࠩ࡟ࡲࠬ঍")).encode(l1lll1l (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lllll111(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1l (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1l (u"ࠧࠩࠢঐ")):
                if self._1lll1lll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1l (u"࠭ࠧ঑").join(lines).encode(l1lll1l (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l11l(cls, l1llllll1l, path=None):
        l1lll111l1 = cls(path=path)
        entry = l1lll111l1.l1llll11l1(l1lll1l (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1llllll1l)
        if entry:
            return l1lll111l1.l1lllll111(entry)
        return False
    @classmethod
    def add(cls, device, l1llllll1l, l1lll11ll1, options=None, path=None):
        return cls(path=path).l1lll1l1ll(l1lll1ll11.Entry(device,
                                                    l1llllll1l, l1lll11ll1,
                                                    options=options))
class l1lllll1ll(object):
    def __init__(self, l1llllll11):
        self.l1llll1ll1=l1lll1l (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll11lll=l1lll1l (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llllll11=l1llllll11
        self.l1llll11ll()
        self.l1llll1lll()
        self.l1lll11l11()
        self.l1llll111l()
        self.l1lll1l111()
    def l1llll11ll(self):
        temp_file=open(l1lll1ll1l,l1lll1l (u"ࠫࡷ࠭খ"))
        l1=temp_file.read()
        data=json.loads(l1)
        self.user=data[l1lll1l (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1l111l=data[l1lll1l (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11111=data[l1lll1l (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l11ll=data[l1lll1l (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll1l1l1=data[l1lll1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lllll1l1=data[l1lll1l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll11l11(self):
        l1l1l11=os.path.join(l1lll1l (u"ࠦ࠴ࠨঝ"),l1lll1l (u"ࠧࡻࡳࡳࠤঞ"),l1lll1l (u"ࠨࡳࡣ࡫ࡱࠦট"),l1lll1l (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1lll1l (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1l1l11)
    def l1lll1l111(self):
        logger.info(l1lll1l (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11111=os.path.join(self.l11ll,self.l1llll1ll1)
        l1llll1l1l = pwd.getpwnam(self.user).pw_uid
        l1lll1llll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11111):
            os.makedirs(l11111)
            os.system(l1lll1l (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11111))
            logger.debug(l1lll1l (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11111)
        else:
            logger.debug(l1lll1l (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11111)
        l1l1l11=os.path.join(l11111, self.l1lll11lll)
        print(l1l1l11)
        logger.debug(l1lll1l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1l1l11)
        with open(l1l1l11, l1lll1l (u"ࠢࡸ࠭ࠥধ")) as l1lllllll1:
            logger.debug(self.l1l111l + l1lll1l (u"ࠨࠢࠪন")+self.l1lll1l1l1+l1lll1l (u"ࠩࠣࠦࠬ঩")+self.l1lllll1l1+l1lll1l (u"ࠪࠦࠬপ"))
            l1lllllll1.writelines(self.l1l111l + l1lll1l (u"ࠫࠥ࠭ফ")+self.l1lll1l1l1+l1lll1l (u"ࠬࠦࠢࠨব")+self.l1lllll1l1+l1lll1l (u"࠭ࠢࠨভ"))
        os.chmod(l1l1l11, 0o600)
        os.chown(l1l1l11, l1llll1l1l, l1lll1llll)
    def l1llll1lll(self, l11111111=l1lll1l (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1lll1l (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l11111111 in groups:
            logger.info(l1lll1l (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l11111111))
        else:
            logger.warning(l1lll1l (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l11111111))
            l11l111=l1lll1l (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l11111111,self.user)
            logger.debug(l1lll1l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l11l111)
            os.system(l11l111)
            logger.debug(l1lll1l (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1llll111l(self):
        logger.debug(l1lll1l (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lll111l1=l1lll1ll11()
        l1lll111l1.add(self.l1l111l, self.l11111, l1lll11ll1=l1lll1l (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1lll1l (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1lll1l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1ll1l = urllib.parse.unquote(sys.argv[1])
        if l1lll1ll1l:
            l1lll11l1l=l1lllll1ll(l1lll1ll1l)
        else:
            raise (l1lll1l (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1lll1l (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise