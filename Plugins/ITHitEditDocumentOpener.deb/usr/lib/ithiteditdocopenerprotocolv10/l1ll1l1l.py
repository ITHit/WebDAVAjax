#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l1ll = 2048
l1l1 = 7
def l1lll1l (l1l111):
    global l1l111l
    l1lll1ll = ord (l1l111 [-1])
    l1lllll = l1l111 [:-1]
    l11111 = l1lll1ll % len (l1lllll)
    l1ll1l11 = l1lllll [:l11111] + l1lllll [l11111:]
    if l1ll1ll:
        l1ll11 = l1l1l () .join ([unichr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    return eval (l1ll11)
import re
class l1ll111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1lll = kwargs.get(l1lll1l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11l1 = kwargs.get(l1lll1l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllllll = self.l1lll1l11(args)
        if l1lllllll:
            args=args+ l1lllllll
        self.args = [a for a in args]
    def l1lll1l11(self, *args):
        l1lllllll=None
        l11ll111 = args[0][0]
        if re.search(l1lll1l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11ll111):
            l1lllllll = (l1lll1l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1lll
                            ,)
        return l1lllllll
class l1lll11ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lllllll = self.l1lll1l11(args)
        if l1lllllll:
            args = args + l1lllllll
        self.args = [a for a in args]
    def l1lll1l11(self, *args):
        s = l1lll1l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll1l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llllll1(Exception):
    pass
class l1llllll(Exception):
    pass
class l1llll11l(Exception):
    def __init__(self, message, l11111ll, url):
        super(l1llll11l,self).__init__(message)
        self.l11111ll = l11111ll
        self.url = url
class l1llll111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1111111(Exception):
    pass
class l1111l11(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l111111l(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l11l1ll1(Exception):
    pass