#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l11 = sys.version_info [0] == 2
l1 = 2048
l1ll11ll = 7
def l1l1lll (l11l11):
    global l11l11l
    l11l1l = ord (l11l11 [-1])
    l1ll1111 = l11l11 [:-1]
    l1ll11l = l11l1l % len (l1ll1111)
    l1l1l1l = l1ll1111 [:l1ll11l] + l1ll1111 [l1ll11l:]
    if l111l11:
        l1ll = ll () .join ([unichr (ord (char) - l1 - (l1ll1ll1 + l11l1l) % l1ll11ll) for l1ll1ll1, char in enumerate (l1l1l1l)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1ll1ll1 + l11l1l) % l1ll11ll) for l1ll1ll1, char in enumerate (l1l1l1l)])
    return eval (l1ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11l11=logging.WARNING
logger = logging.getLogger(l1l1lll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11l11)
l1l1llll = SysLogHandler(address=l1l1lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l1lll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1llll.setFormatter(formatter)
logger.addHandler(l1l1llll)
ch = logging.StreamHandler()
ch.setLevel(l1lll11l11)
logger.addHandler(ch)
class l1lll11ll1(io.FileIO):
    l1l1lll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l1lll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11lll, l1llllll1l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11lll = l1lll11lll
            self.l1llllll1l = l1llllll1l
            if not options:
                options = l1l1lll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1lll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11lll,
                                              self.l1llllll1l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll11ll = os.path.join(os.path.sep, l1l1lll (u"ࠪࡩࡹࡩࠧই"), l1l1lll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1l1 = path
        else:
            self._1lll1l1l1 = self.l1llll11ll
        super(l1lll11ll1, self).__init__(self._1lll1l1l1, l1l1lll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l11(self, line):
        return l1lll11ll1.Entry(*[x for x in line.strip(l1l1lll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l1lll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1lll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1lll (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l11(line)
            except ValueError:
                pass
    def l1lll1l11l(self, attr, value):
        for entry in self.entries:
            l1lll111ll = getattr(entry, attr)
            if l1lll111ll == value:
                return entry
        return None
    def l1llll1l1l(self, entry):
        if self.l1lll1l11l(l1l1lll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l1lll (u"ࠫࡡࡴࠧএ")).encode(l1l1lll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1111l(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1lll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1lll (u"ࠢࠤࠤ঒")):
                if self._1llll1l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1lll (u"ࠨࠩও").join(lines).encode(l1l1lll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllllll1(cls, l1lll11lll, path=None):
        l1lll1l111 = cls(path=path)
        entry = l1lll1l111.l1lll1l11l(l1l1lll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11lll)
        if entry:
            return l1lll1l111.l1lll1111l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11lll, l1llllll1l, options=None, path=None):
        return cls(path=path).l1llll1l1l(l1lll11ll1.Entry(device,
                                                    l1lll11lll, l1llllll1l,
                                                    options=options))
class l1lll1ll11(object):
    def __init__(self, l1lll1llll):
        self.l1lll1l1ll=l1l1lll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lllll1l1=l1l1lll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1llll=l1lll1llll
        self.l1lll11111()
        self.l1lllll11l()
        self.l1lll1ll1l()
        self.l1llll11l1()
        self.l1llll1ll1()
    def l1lll11111(self):
        temp_file=open(l1lllll111,l1l1lll (u"࠭ࡲࠨঘ"))
        l111l1=temp_file.read()
        data=json.loads(l111l1)
        self.user=data[l1l1lll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11ll1=data[l1l1lll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll1=data[l1l1lll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll1l1=data[l1l1lll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1lll1=data[l1l1lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1lll=data[l1l1lll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1ll1l(self):
        l111lll=os.path.join(l1l1lll (u"ࠨ࠯ࠣট"),l1l1lll (u"ࠢࡶࡵࡵࠦঠ"),l1l1lll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l1lll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l1lll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111lll)
    def l1llll1ll1(self):
        logger.info(l1l1lll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll1=os.path.join(self.l1ll1l1,self.l1lll1l1ll)
        l1lllll1ll = pwd.getpwnam(self.user).pw_uid
        l1llll111l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll1):
            os.makedirs(l1ll1)
            os.system(l1l1lll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll1))
            logger.debug(l1l1lll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll1)
        else:
            logger.debug(l1l1lll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll1)
        l111lll=os.path.join(l1ll1, self.l1lllll1l1)
        print(l111lll)
        logger.debug(l1l1lll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111lll)
        with open(l111lll, l1l1lll (u"ࠤࡺ࠯ࠧ঩")) as l1lll11l1l:
            logger.debug(self.l11ll1 + l1l1lll (u"ࠪࠤࠬপ")+self.l1lll1lll1+l1l1lll (u"ࠫࠥࠨࠧফ")+self.l1llll1lll+l1l1lll (u"ࠬࠨࠧব"))
            l1lll11l1l.writelines(self.l11ll1 + l1l1lll (u"࠭ࠠࠨভ")+self.l1lll1lll1+l1l1lll (u"ࠧࠡࠤࠪম")+self.l1llll1lll+l1l1lll (u"ࠨࠤࠪয"))
        os.chmod(l111lll, 0o600)
        os.chown(l111lll, l1lllll1ll, l1llll111l)
    def l1lllll11l(self, l1llllll11=l1l1lll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l1lll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll11 in groups:
            logger.info(l1l1lll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llllll11))
        else:
            logger.warning(l1l1lll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llllll11))
            l1lll11l=l1l1lll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llllll11,self.user)
            logger.debug(l1l1lll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1lll11l)
            os.system(l1lll11l)
            logger.debug(l1l1lll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll11l1(self):
        logger.debug(l1l1lll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l111=l1lll11ll1()
        l1lll1l111.add(self.l11ll1, self.l1ll1, l1llllll1l=l1l1lll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l1lll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l1lll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll111 = urllib.parse.unquote(sys.argv[1])
        if l1lllll111:
            l1lll111l1=l1lll1ll11(l1lllll111)
        else:
            raise (l1l1lll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l1lll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise