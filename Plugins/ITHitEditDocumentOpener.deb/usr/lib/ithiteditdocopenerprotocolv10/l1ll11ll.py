#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l1 = sys.version_info [0] == 2
l1l1l11 = 2048
l1ll1l1l = 7
def l11ll1l (l1l11ll):
    global l1lll1l1
    l1l11 = ord (l1l11ll [-1])
    l1 = l1l11ll [:-1]
    l1ll111 = l1l11 % len (l1)
    ll = l1 [:l1ll111] + l1 [l1ll111:]
    if l11l1l1:
        l1l1l1 = l1lll11l () .join ([unichr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    return eval (l1l1l1)
import hashlib
import os
import l1ll1lll
from l11lll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll1lll import l1ll111l
from l11l1l import l11l111, l1ll1
import logging
logger = logging.getLogger(l11ll1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l():
    def __init__(self, l1llll11,l1111l, l11ll11= None, l1ll11l=None):
        self.l11l=False
        self.l1111l1 = self._111l11()
        self.l1111l = l1111l
        self.l11ll11 = l11ll11
        self.l1ll1l = l1llll11
        if l11ll11:
            self.l111l1l = True
        else:
            self.l111l1l = False
        self.l1ll11l = l1ll11l
    def _111l11(self):
        try:
            return l1ll1lll.l1l111() is not None
        except:
            return False
    def open(self):
        l11ll1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1111l1:
            raise NotImplementedError(l11ll1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11ll1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l111 = self.l1ll1l
        if self.l1111l.lower().startswith(self.l1ll1l.lower()):
            l11l11 = re.compile(re.escape(self.l1ll1l), re.IGNORECASE)
            l1111l = l11l11.sub(l11ll1l (u"ࠨࠩࠄ"), self.l1111l)
            l1111l = l1111l.replace(l11ll1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l11ll1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lllll1(self.l1ll1l, l111, l1111l, self.l11ll11)
    def l1lllll1(self,l1ll1l, l111, l1111l, l11ll11):
        l11ll1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11ll1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1l = l1l1ll1(l1ll1l)
        l111ll1 = self.l1lll1ll(l1l1l)
        logger.info(l11ll1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1l)
        if l111ll1:
            logger.info(l11ll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll111l(l1l1l)
            l1l1l = l1ll1l1(l1ll1l, l111, l11ll11, self.l1ll11l)
        logger.debug(l11ll1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1111=l1l1l + l11ll1l (u"ࠤ࠲ࠦࠌ") + l1111l
        l1lll111 = l11ll1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1111+ l11ll1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1lll111)
        l1ll1ll1 = os.system(l1lll111)
        if (l1ll1ll1 != 0):
            raise IOError(l11ll1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1111, l1ll1ll1))
    def l1lll1ll(self, l1l1l):
        if os.path.exists(l1l1l):
            if os.path.islink(l1l1l):
                l1l1l = os.readlink(l1l1l)
            if os.path.ismount(l1l1l):
                return True
        return False
def l1l1ll1(l1ll1l):
    l1ll1111 = l1ll1l.replace(l11ll1l (u"࠭࡜࡝ࠩࠐ"), l11ll1l (u"ࠧࡠࠩࠑ")).replace(l11ll1l (u"ࠨ࠱ࠪࠒ"), l11ll1l (u"ࠩࡢࠫࠓ"))
    l1ll1l11 = l11ll1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l1=os.environ[l11ll1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11=os.path.join(l1l1,l1ll1l11, l1ll1111)
    l111ll=os.path.abspath(l11)
    return l111ll
def l1llll1(l1ll):
    if not os.path.exists(l1ll):
        os.makedirs(l1ll)
def l1l11l(l1ll1l, l111, l1lll1=None, password=None):
    l11ll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll = l1l1ll1(l1ll1l)
    l1llll1(l1ll)
    if not l1lll1:
        l11111 = l1ll11l1()
        l1lll1l =l11111.l11l1ll(l11ll1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l111 + l11ll1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l111 + l11ll1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll1l, str):
            l1lll1, password = l1lll1l
        else:
            raise l1ll1()
        logger.info(l11ll1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll))
    l11l11l = pwd.getpwuid( os.getuid())[0]
    l1ll1ll=os.environ[l11ll1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l111l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l1l1l={l11ll1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11l, l11ll1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1l, l11ll1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll, l11ll1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll1ll, l11ll1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll1, l11ll1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l1l1l, temp_file)
        if not os.path.exists(os.path.join(l111l, l11ll1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lllll=l11ll1l (u"ࠦࡵࡿࠢࠣ")
            key=l11ll1l (u"ࠧࠨࠤ")
        else:
            l1lllll=l11ll1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11ll1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1111=l11ll1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lllll,temp_file.name)
        l1llll=[l11ll1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11ll1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l111l, l1l1111)]
        p = subprocess.Popen(l1llll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11ll1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11ll1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11ll1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll
    logger.debug(l11ll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11ll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11ll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11ll1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111ll=os.path.abspath(l1ll)
    logger.debug(l11ll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111ll)
    return l111ll
def l1ll1l1(l1ll1l, l111, l11ll11, l1ll11l):
    l11ll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1ll(title):
        l111lll=30
        if len(title)>l111lll:
            l1lll=title.split(l11ll1l (u"ࠨ࠯ࠣ࠳"))
            l11llll=l11ll1l (u"ࠧࠨ࠴")
            for block in l1lll:
                l11llll+=block+l11ll1l (u"ࠣ࠱ࠥ࠵")
                if len(l11llll) > l111lll:
                    l11llll+=l11ll1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11llll
        return title
    def l1l1lll(l11l1, password):
        l11ll1l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11ll1l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11ll1l (u"ࠧࠦࠢ࠹").join(l11l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1lll11 = l11ll1l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1lll11.encode())
        l1l11l1 = [l11ll1l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1llll1l = l11ll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1llll1l)
            for e in l1l11l1:
                if e in l1llll1l: return False
            raise l11l111(l1llll1l, l1ll1l1=l1ll1lll.l1l111(), l111=l111)
        logger.info(l11ll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll1 = l11ll1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11ll1l (u"ࠦࠧ࠿")
    os.system(l11ll1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11ll = l1l1ll1(l1ll1l)
    l1ll = l1l1ll1(hashlib.sha1(l1ll1l.encode()).hexdigest()[:10])
    l1llll1(l1ll)
    logger.info(l11ll1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll))
    if l11ll11:
        l11l1 = [l11ll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11ll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11ll1l (u"ࠤ࠰ࡸࠧࡄ"), l11ll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11ll1l (u"ࠫ࠲ࡵࠧࡆ"), l11ll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll1, l11ll11),
                    urllib.parse.unquote(l111), os.path.abspath(l1ll)]
        l1l1lll(l11l1, password)
    else:
        while True:
            l1lll1, password = l11111l(l1ll, l111, l1ll11l)
            if l1lll1.lower() != l11ll1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l1 = [l11ll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11ll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11ll1l (u"ࠤ࠰ࡸࠧࡋ"), l11ll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11ll1l (u"ࠫ࠲ࡵࠧࡍ"), l11ll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll1,
                            urllib.parse.unquote(l111), os.path.abspath(l1ll)]
            else:
                raise l1ll1()
            if l1l1lll(l11l1, password): break
    os.system(l11ll1l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll, l11ll))
    l111ll=os.path.abspath(l11ll)
    return l111ll
def l11111l(l1ll1l, l111, l1ll11l):
    l1l111l = os.path.join(os.environ[l11ll1l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11ll1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11ll1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l111l)):
       os.makedirs(os.path.dirname(l1l111l))
    l1llllll = l1ll11l.get_value(l11ll1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11ll1l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11111 = l1ll11l1(l1ll1l, l1llllll)
    l1lll1, password = l11111.l11l1ll(l11ll1l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l111 + l11ll1l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l111 + l11ll1l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll1 != l11ll1l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll11(l1ll1l, l1lll1):
        l1111ll = l11ll1l (u"ࠤ࡙ࠣࠦ").join([l1ll1l, l1lll1, l11ll1l (u"࡚ࠪࠦࠬ") + password + l11ll1l (u"࡛ࠫࠧ࠭"), l11ll1l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l111l, l11ll1l (u"࠭ࡷࠬࠩ࡝")) as l111111:
            l111111.write(l1111ll)
        os.chmod(l1l111l, 0o600)
    return l1lll1, password
def l1ll11(l1ll1l, l1lll1):
    l1l111l = l11ll1 = os.path.join(os.environ[l11ll1l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11ll1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11ll1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l111l):
        with open(l1l111l, l11ll1l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11lll1 = data[0].split(l11ll1l (u"ࠦࠥࠨࡢ"))
            if l1ll1l == l11lll1[0] and l1lll1 == l11lll1[1]:
                return True
    return False