#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1l11 = 7
def l1ll1lll (l1):
    global l1l1lll
    l1lll1l1 = ord (l1 [-1])
    l1l11l1 = l1 [:-1]
    l111l = l1lll1l1 % len (l1l11l1)
    l1ll1l1 = l1l11l1 [:l111l] + l1l11l1 [l111l:]
    if l1l1:
        l11lll = l11llll () .join ([unichr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    return eval (l11lll)
import hashlib
import os
import l11ll11
from l1llll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11ll11 import l111l11
from l11l11l import l11ll, l111lll
import logging
logger = logging.getLogger(l1ll1lll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11111():
    def __init__(self, l1l1l1l,ll, l1l1111= None, l1ll111l=None):
        self.l1ll11l1=False
        self.l1l11 = self._11111l()
        self.ll = ll
        self.l1l1111 = l1l1111
        self.l11l1l = l1l1l1l
        if l1l1111:
            self.l1ll1ll1 = True
        else:
            self.l1ll1ll1 = False
        self.l1ll111l = l1ll111l
    def _11111l(self):
        try:
            return l11ll11.l111ll1() is not None
        except:
            return False
    def open(self):
        l1ll1lll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l11:
            raise NotImplementedError(l1ll1lll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1lll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1ll1 = self.l11l1l
        if self.ll.lower().startswith(self.l11l1l.lower()):
            l11l1ll = re.compile(re.escape(self.l11l1l), re.IGNORECASE)
            ll = l11l1ll.sub(l1ll1lll (u"ࠨࠩࠄ"), self.ll)
            ll = ll.replace(l1ll1lll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1lll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l11ll(self.l11l1l, l1l1ll1, ll, self.l1l1111)
    def l1l11ll(self,l11l1l, l1l1ll1, ll, l1l1111):
        l1ll1lll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1lll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll1l = l11l(l11l1l)
        l1llll11 = self.l1111l(l1lll1l)
        logger.info(l1ll1lll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll1l)
        if l1llll11:
            logger.info(l1ll1lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111l11(l1lll1l)
            l1lll1l = l1lllll(l11l1l, l1l1ll1, l1l1111, self.l1ll111l)
        logger.debug(l1ll1lll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll11l=l1lll1l + l1ll1lll (u"ࠤ࠲ࠦࠌ") + ll
        l111l1l = l1ll1lll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll11l+ l1ll1lll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111l1l)
        l1111ll = os.system(l111l1l)
        if (l1111ll != 0):
            raise IOError(l1ll1lll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll11l, l1111ll))
    def l1111l(self, l1lll1l):
        if os.path.exists(l1lll1l):
            if os.path.islink(l1lll1l):
                l1lll1l = os.readlink(l1lll1l)
            if os.path.ismount(l1lll1l):
                return True
        return False
def l11l(l11l1l):
    l1l1l1 = l11l1l.replace(l1ll1lll (u"࠭࡜࡝ࠩࠐ"), l1ll1lll (u"ࠧࡠࠩࠑ")).replace(l1ll1lll (u"ࠨ࠱ࠪࠒ"), l1ll1lll (u"ࠩࡢࠫࠓ"))
    l1l1l11 = l1ll1lll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll1=os.environ[l1ll1lll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lllll1=os.path.join(l11ll1,l1l1l11, l1l1l1)
    l1111=os.path.abspath(l1lllll1)
    return l1111
def l11ll1l(l1l1ll):
    if not os.path.exists(l1l1ll):
        os.makedirs(l1l1ll)
def l111ll(l11l1l, l1l1ll1, l1llll1=None, password=None):
    l1ll1lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l1ll = l11l(l11l1l)
    l11ll1l(l1l1ll)
    if not l1llll1:
        l1l11l = l1l111()
        l11l111 =l1l11l.l1111l1(l1ll1lll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1ll1 + l1ll1lll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1ll1 + l1ll1lll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l111, str):
            l1llll1, password = l11l111
        else:
            raise l111lll()
        logger.info(l1ll1lll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l1ll))
    l111 = pwd.getpwuid( os.getuid())[0]
    l1ll1111=os.environ[l1ll1lll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l={l1ll1lll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111, l1ll1lll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l1l, l1ll1lll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l1ll, l1ll1lll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll1111, l1ll1lll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1llll1, l1ll1lll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l, temp_file)
        if not os.path.exists(os.path.join(l1ll1l, l1ll1lll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11l11=l1ll1lll (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1lll (u"ࠧࠨࠤ")
        else:
            l11l11=l1ll1lll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1lll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1ll=l1ll1lll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11l11,temp_file.name)
        l1lll111=[l1ll1lll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1lll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1l, l1ll1ll)]
        p = subprocess.Popen(l1lll111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1lll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1lll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1lll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l1ll
    logger.debug(l1ll1lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1lll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1111=os.path.abspath(l1l1ll)
    logger.debug(l1ll1lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1111)
    return l1111
def l1lllll(l11l1l, l1l1ll1, l1l1111, l1ll111l):
    l1ll1lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11(title):
        l11l1l1=30
        if len(title)>l11l1l1:
            l1lll11=title.split(l1ll1lll (u"ࠨ࠯ࠣ࠳"))
            l1ll111=l1ll1lll (u"ࠧࠨ࠴")
            for block in l1lll11:
                l1ll111+=block+l1ll1lll (u"ࠣ࠱ࠥ࠵")
                if len(l1ll111) > l11l1l1:
                    l1ll111+=l1ll1lll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll111
        return title
    def l1lll1(l111111, password):
        l1ll1lll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1lll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1lll (u"ࠧࠦࠢ࠹").join(l111111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1lll1ll = l1ll1lll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1lll1ll.encode())
        l1ll = [l1ll1lll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11lll1 = l1ll1lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11lll1)
            for e in l1ll:
                if e in l11lll1: return False
            raise l11ll(l11lll1, l1lllll=l11ll11.l111ll1(), l1l1ll1=l1l1ll1)
        logger.info(l1ll1lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1llll1 = l1ll1lll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1lll (u"ࠦࠧ࠿")
    os.system(l1ll1lll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1llll1l = l11l(l11l1l)
    l1l1ll = l11l(hashlib.sha1(l11l1l.encode()).hexdigest()[:10])
    l11ll1l(l1l1ll)
    logger.info(l1ll1lll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1l1ll))
    if l1l1111:
        l111111 = [l1ll1lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1lll (u"ࠤ࠰ࡸࠧࡄ"), l1ll1lll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1lll (u"ࠫ࠲ࡵࠧࡆ"), l1ll1lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1llll1, l1l1111),
                    urllib.parse.unquote(l1l1ll1), os.path.abspath(l1l1ll)]
        l1lll1(l111111, password)
    else:
        while True:
            l1llll1, password = l1ll11l(l1l1ll, l1l1ll1, l1ll111l)
            if l1llll1.lower() != l1ll1lll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l111111 = [l1ll1lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1lll (u"ࠤ࠰ࡸࠧࡋ"), l1ll1lll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1lll (u"ࠫ࠲ࡵࠧࡍ"), l1ll1lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1llll1,
                            urllib.parse.unquote(l1l1ll1), os.path.abspath(l1l1ll)]
            else:
                raise l111lll()
            if l1lll1(l111111, password): break
    os.system(l1ll1lll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1l1ll, l1llll1l))
    l1111=os.path.abspath(l1llll1l)
    return l1111
def l1ll11l(l11l1l, l1l1ll1, l1ll111l):
    l1ll1 = os.path.join(os.environ[l1ll1lll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1)):
       os.makedirs(os.path.dirname(l1ll1))
    l1l111l = l1ll111l.get_value(l1ll1lll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1lll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l11l = l1l111(l11l1l, l1l111l)
    l1llll1, password = l1l11l.l1111l1(l1ll1lll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1ll1 + l1ll1lll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1ll1 + l1ll1lll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1llll1 != l1ll1lll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1lll(l11l1l, l1llll1):
        l111l1 = l1ll1lll (u"ࠤ࡙ࠣࠦ").join([l11l1l, l1llll1, l1ll1lll (u"࡚ࠪࠦࠬ") + password + l1ll1lll (u"࡛ࠫࠧ࠭"), l1ll1lll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1, l1ll1lll (u"࠭ࡷࠬࠩ࡝")) as l1ll1l1l:
            l1ll1l1l.write(l111l1)
        os.chmod(l1ll1, 0o600)
    return l1llll1, password
def l1lll(l11l1l, l1llll1):
    l1ll1 = l1l1l = os.path.join(os.environ[l1ll1lll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1):
        with open(l1ll1, l1ll1lll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll11 = data[0].split(l1ll1lll (u"ࠦࠥࠨࡢ"))
            if l11l1l == l1ll11[0] and l1llll1 == l1ll11[1]:
                return True
    return False