#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l11111 = 7
def l11 (l1l111l):
    global l1lll11
    l11l11 = ord (l1l111l [-1])
    l1l1ll1 = l1l111l [:-1]
    l1llll = l11l11 % len (l1l1ll1)
    l1lll1ll = l1l1ll1 [:l1llll] + l1l1ll1 [l1llll:]
    if l11l1l:
        l1l1l1 = l1ll1l1 () .join ([unichr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    return eval (l1l1l1)
import hashlib
import os
import l1ll1l
from l11l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll1l import l1llllll
from l1lll import l1l11l1, l1ll11l
import logging
logger = logging.getLogger(l11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1lll1l1():
    def __init__(self, l11llll,l111l11, l1l1l= None, l1l1=None):
        self.l11lll=False
        self.l1lllll = self._1ll1lll()
        self.l111l11 = l111l11
        self.l1l1l = l1l1l
        self.l1llll11 = l11llll
        if l1l1l:
            self.l1l1lll = True
        else:
            self.l1l1lll = False
        self.l1l1 = l1l1
    def _1ll1lll(self):
        try:
            return l1ll1l.l11ll11() is not None
        except:
            return False
    def open(self):
        l11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lllll:
            raise NotImplementedError(l11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l11l = self.l1llll11
        if self.l111l11.lower().startswith(self.l1llll11.lower()):
            l1llll1 = re.compile(re.escape(self.l1llll11), re.IGNORECASE)
            l111l11 = l1llll1.sub(l11 (u"ࠨࠩࠄ"), self.l111l11)
            l111l11 = l111l11.replace(l11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll111(self.l1llll11, l1l11l, l111l11, self.l1l1l)
    def l1lll111(self,l1llll11, l1l11l, l111l11, l1l1l):
        l11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1111l1 = l1lll11l(l1llll11)
        l111l1 = self.l1111l(l1111l1)
        logger.info(l11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1111l1)
        if l111l1:
            logger.info(l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1llllll(l1111l1)
            l1111l1 = l1l1111(l1llll11, l1l11l, l1l1l, self.l1l1)
        logger.debug(l11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l11l=l1111l1 + l11 (u"ࠤ࠲ࠦࠌ") + l111l11
        l1l1ll = l11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l11l+ l11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1ll)
        l11l1ll = os.system(l1l1ll)
        if (l11l1ll != 0):
            raise IOError(l11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l11l, l11l1ll))
    def l1111l(self, l1111l1):
        if os.path.exists(l1111l1):
            if os.path.islink(l1111l1):
                l1111l1 = os.readlink(l1111l1)
            if os.path.ismount(l1111l1):
                return True
        return False
def l1lll11l(l1llll11):
    l1ll11l1 = l1llll11.replace(l11 (u"࠭࡜࡝ࠩࠐ"), l11 (u"ࠧࡠࠩࠑ")).replace(l11 (u"ࠨ࠱ࠪࠒ"), l11 (u"ࠩࡢࠫࠓ"))
    l1ll111 = l11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll=os.environ[l11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11111l=os.path.join(l11ll,l1ll111, l1ll11l1)
    l1lll1l=os.path.abspath(l11111l)
    return l1lll1l
def l1llll1l(l1l111):
    if not os.path.exists(l1l111):
        os.makedirs(l1l111)
def l111ll(l1llll11, l1l11l, l11l=None, password=None):
    l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l111 = l1lll11l(l1llll11)
    l1llll1l(l1l111)
    if not l11l:
        l1l = l1lllll1()
        l11l111 =l1l.l1ll1ll(l11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l11l + l11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l11l + l11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l111, str):
            l11l, password = l11l111
        else:
            raise l1ll11l()
        logger.info(l11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l111))
    l111ll1 = pwd.getpwuid( os.getuid())[0]
    l1l11=os.environ[l11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11lll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11ll1={l11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111ll1, l11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1llll11, l11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l111, l11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l11, l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l, l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11ll1, temp_file)
        if not os.path.exists(os.path.join(l11lll1, l11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1111ll=l11 (u"ࠦࡵࡿࠢࠣ")
            key=l11 (u"ࠧࠨࠤ")
        else:
            l1111ll=l11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l11ll=l11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1111ll,temp_file.name)
        l1ll1l1l=[l11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11lll1, l1l11ll)]
        p = subprocess.Popen(l1ll1l1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l111
    logger.debug(l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll1l=os.path.abspath(l1l111)
    logger.debug(l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll1l)
    return l1lll1l
def l1l1111(l1llll11, l1l11l, l1l1l, l1l1):
    l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll11(title):
        l111l1l=30
        if len(title)>l111l1l:
            l111111=title.split(l11 (u"ࠨ࠯ࠣ࠳"))
            l11ll1l=l11 (u"ࠧࠨ࠴")
            for block in l111111:
                l11ll1l+=block+l11 (u"ࠣ࠱ࠥ࠵")
                if len(l11ll1l) > l111l1l:
                    l11ll1l+=l11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11ll1l
        return title
    l11l = l11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l11 (u"ࠦࠧ࠸")
    os.system(l11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1 = l1lll11l(l1llll11)
    l1l111 = l1lll11l(hashlib.sha1(l1llll11.encode()).hexdigest()[:10])
    l1llll1l(l1l111)
    logger.info(l11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1l111))
    if l1l1l:
        l1l1l1l = [l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l11 (u"ࠤ࠰ࡸࠧ࠽"), l11 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l11 (u"ࠫ࠲ࡵࠧ࠿"), l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l11l, l1l1l),
                    urllib.parse.unquote(l1l11l), os.path.abspath(l1l111)]
    else:
        l11l, password = l1l1l11(l1l111, l1l11l, l1l1)
        if l11l.lower() != l11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1l1l1l = [l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11 (u"ࠤ࠰ࡸࠧࡄ"), l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11 (u"ࠫ࠲ࡵࠧࡆ"), l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l11l,
                        urllib.parse.unquote(l1l11l), os.path.abspath(l1l111)]
        else:
            raise l1ll11l()
    logger.info(l11 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l11 (u"ࠢࠡࠤࡉ").join(l1l1l1l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1ll1l11 = l11 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1ll1l11.encode())
    if len(err) > 0:
        l11l1l1 = l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l11l1l1)
        raise l1l11l1(l11l1l1, l1l1111=l1ll1l.l11ll11(), l1l11l=l1l11l)
    logger.info(l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l11 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1l111, l1))
    l1lll1l=os.path.abspath(l1)
    return l1lll1l
def l1l1l11(l1llll11, l1l11l, l1l1):
    l1ll = os.path.join(os.environ[l11 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1ll)):
       os.makedirs(os.path.dirname(l1ll))
    ll = l1l1.get_value(l11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l11 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l = l1lllll1(l1llll11, ll)
    l11l, password = l1l.l1ll1ll(l11 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1l11l + l11 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1l11l + l11 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l11l != l11 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1lll1(l1llll11, l11l):
        l1111 = l11 (u"ࠢࠡࠤࡗ").join([l1llll11, l11l, l11 (u"ࠨࠤࠪࡘ") + password + l11 (u"࡙ࠩࠥࠫ"), l11 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1ll, l11 (u"ࠫࡼ࠱࡛ࠧ")) as l111:
            l111.write(l1111)
        os.chmod(l1ll, 0o600)
    return l11l, password
def l1lll1(l1llll11, l11l):
    l1ll = l1ll1ll1 = os.path.join(os.environ[l11 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1ll):
        with open(l1ll, l11 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l111lll = data[0].split(l11 (u"ࠤࠣࠦࡠ"))
            if l1llll11 == l111lll[0] and l11l == l111lll[1]:
                return True
    return False