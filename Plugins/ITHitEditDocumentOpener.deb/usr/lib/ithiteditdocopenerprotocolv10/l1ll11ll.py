#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1l = 2048
l1llll1l = 7
def l11l (l11ll1):
    global l1lll11l
    l1ll1 = ord (l11ll1 [-1])
    l11ll11 = l11ll1 [:-1]
    l11l111 = l1ll1 % len (l11ll11)
    l1l1l = l11ll11 [:l11l111] + l11ll11 [l11l111:]
    if l111ll1:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    return eval (l11l11l)
import re
class l11111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111l1l = kwargs.get(l11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1l111l = kwargs.get(l11l (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l11111ll = self.l1llll111(args)
        if l11111ll:
            args=args+ l11111ll
        self.args = [a for a in args]
    def l1llll111(self, *args):
        l11111ll=None
        l1l1l1ll = args[0][0]
        if re.search(l11l (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l1l1ll):
            l11111ll = (l11l (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1111l1l
                            ,)
        return l11111ll
class l1111ll1(Exception):
    def __init__(self, *args, **kwargs):
        l11111ll = self.l1llll111(args)
        if l11111ll:
            args = args + l11111ll
        self.args = [a for a in args]
    def l1llll111(self, *args):
        s = l11l (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l11l (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1lllllll(Exception):
    pass
class l111(Exception):
    pass
class l1llll1l1(Exception):
    def __init__(self, message, l1llllll1, url):
        super(l1llll1l1,self).__init__(message)
        self.l1llllll1 = l1llllll1
        self.url = url
class l11111l1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1111111(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l111111l(Exception):
    pass
class l1111l11(Exception):
    pass
class l11l111l(Exception):
    pass