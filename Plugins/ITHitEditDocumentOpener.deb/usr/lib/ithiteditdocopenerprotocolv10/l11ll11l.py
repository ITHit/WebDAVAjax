#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l1ll1l1 = 2048
l1lll1l1 = 7
def l1l1ll (l1ll1l1l):
    global l111l1
    l1l11l1 = ord (l1ll1l1l [-1])
    l1lll1l = l1ll1l1l [:-1]
    l1llll1 = l1l11l1 % len (l1lll1l)
    ll = l1lll1l [:l1llll1] + l1lll1l [l1llll1:]
    if l1l1111:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    return eval (l1111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11ll import l1lll1
from configobj import ConfigObj
l1l1ll1l = l1l1ll (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1ll1111 = l1l1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠳࠳࠱࠴ࠧࡢ")
l1l11l11 = l1l1ll (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1l1ll (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠲࠲࠰࠳ࠦࡤ")
l1l1l11l=os.path.join(os.environ.get(l1l1ll (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1l1ll (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l11l11.replace(l1l1ll (u"ࠤࠣࠦࡧ"), l1l1ll (u"ࠥࡣࠧࡨ")).lower())
l11llll1=os.environ.get(l1l1ll (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1l1ll (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l1ll11=l1ll1111.replace(l1l1ll (u"ࠨࠠࠣ࡫"), l1l1ll (u"ࠢࡠࠤ࡬"))+l1l1ll (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1l1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1111l=os.path.join(os.environ.get(l1l1ll (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l1ll11)
elif platform.system() == l1l1ll (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l1llll=l1lll1(l1l1l11l+l1l1ll (u"ࠧ࠵ࠢࡱ"))
    l1l1111l = os.path.join(l1l1llll, l1l1ll11)
else:
    l1l1111l = os.path.join( l1l1ll11)
l11llll1=l11llll1.upper()
if l11llll1 == l1l1ll (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l11l1l=logging.DEBUG
elif l11llll1 == l1l1ll (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l11l1l = logging.INFO
elif l11llll1 == l1l1ll (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l11l1l = logging.WARNING
elif l11llll1 == l1l1ll (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l11l1l = logging.ERROR
elif l11llll1 == l1l1ll (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l11l1l = logging.CRITICAL
elif l11llll1 == l1l1ll (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l11l1l = logging.NOTSET
logger = logging.getLogger(l1l1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l11l1l)
l1l11lll = logging.FileHandler(l1l1111l, mode=l1l1ll (u"ࠨࡷࠬࠤࡹ"))
l1l11lll.setLevel(l1l11l1l)
formatter = logging.Formatter(l1l1ll (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1l1ll (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l11lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11l1l)
l11ll1ll = SysLogHandler(address=l1l1ll (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l1l11lll)
logger.addHandler(ch)
logger.addHandler(l11ll1ll)
class Settings():
    l1ll111l = l1l1ll (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l1l111 = l1l1ll (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l11lllll = l1l1ll (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1ll1111):
        self.l11lll1l = self._1l111ll(l1ll1111)
        self._11lll11()
    def _1l111ll(self, l1ll1111):
        l1l111l1 = l1ll1111.split(l1l1ll (u"ࠨࠠࠣࢀ"))
        l1l111l1 = l1l1ll (u"ࠢࠡࠤࢁ").join(l1l111l1)
        if platform.system() == l1l1ll (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11lll1l = os.path.join(l1l1l11l, l1l1ll (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l111l1 + l1l1ll (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11lll1l
    def l1l11ll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1ll (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1ll (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll11(self):
        if not os.path.exists(os.path.dirname(self.l11lll1l)):
            os.makedirs(os.path.dirname(self.l11lll1l))
        if not os.path.exists(self.l11lll1l):
            self.config = ConfigObj(self.l11lll1l)
            self.config[l1l1ll (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1l1ll (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1l1ll (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l11lllll
            self.config[l1l1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1l1ll (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l1l111
            self.config[l1l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1ll111l
            self.config[l1l1ll (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lll1l)
            self.l11lllll = self.get_value(l1l1ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1l1ll (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l1l111 = self.get_value(l1l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1l1ll (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1ll111l = self.get_value(l1l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11ll1l1(self):
        l1l1lll1 = l1l1ll (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1ll111l
        l1l1lll1 += l1l1ll (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l1l111
        l1l1lll1 += l1l1ll (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l11lllll
        return l1l1lll1
    def __unicode__(self):
        return self._11ll1l1()
    def __str__(self):
        return self._11ll1l1()
    def __del__(self):
        self.config.write()
l1l1l1l1 = Settings(l1ll1111)