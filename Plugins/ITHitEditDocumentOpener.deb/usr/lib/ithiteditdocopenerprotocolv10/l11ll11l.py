#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1111ll = 2048
l1l1l11 = 7
def l1ll1l1l (l1l1ll1):
    global l1lll
    l1lll1l = ord (l1l1ll1 [-1])
    l1ll = l1l1ll1 [:-1]
    l11l1ll = l1lll1l % len (l1ll)
    l1lllll1 = l1ll [:l11l1ll] + l1ll [l11l1ll:]
    if l1l1l1l:
        l1111l1 = l1llll1l () .join ([unichr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    return eval (l1111l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l1l import l111
from configobj import ConfigObj
l1l11111 = l1ll1l1l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1l111 = l1ll1l1l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠷࠵࠳࠶ࠢࡤ")
l11l1lll = l1ll1l1l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll1l1l (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠶࠴࠲࠵ࠨࡦ")
l1l11ll1=os.path.join(os.environ.get(l1ll1l1l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll1l1l (u"ࠥ࠲ࠪࡹࠢࡨ") %l11l1lll.replace(l1ll1l1l (u"ࠦࠥࠨࡩ"), l1ll1l1l (u"ࠧࡥࠢࡪ")).lower())
l1l1l1ll=os.environ.get(l1ll1l1l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll1l1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1lll1=l1l1l111.replace(l1ll1l1l (u"ࠣࠢࠥ࡭"), l1ll1l1l (u"ࠤࡢࠦ࡮"))+l1ll1l1l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll1l1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1111l=os.path.join(os.environ.get(l1ll1l1l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1lll1)
elif platform.system() == l1ll1l1l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11llll1=l111(l1l11ll1+l1ll1l1l (u"ࠢ࠰ࠤࡳ"))
    l1l1111l = os.path.join(l11llll1, l1l1lll1)
else:
    l1l1111l = os.path.join( l1l1lll1)
l1l1l1ll=l1l1l1ll.upper()
if l1l1l1ll == l1ll1l1l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1ll1l=logging.DEBUG
elif l1l1l1ll == l1ll1l1l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1ll1l = logging.INFO
elif l1l1l1ll == l1ll1l1l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1ll1l = logging.WARNING
elif l1l1l1ll == l1ll1l1l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1ll1l = logging.ERROR
elif l1l1l1ll == l1ll1l1l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1ll1l = logging.CRITICAL
elif l1l1l1ll == l1ll1l1l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1ll1l = logging.NOTSET
logger = logging.getLogger(l1ll1l1l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1ll1l)
l1l1l11l = logging.FileHandler(l1l1111l, mode=l1ll1l1l (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l11l.setLevel(l1l1ll1l)
formatter = logging.Formatter(l1ll1l1l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll1l1l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1ll1l)
l11ll1ll = SysLogHandler(address=l1ll1l1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l1l1l11l)
logger.addHandler(ch)
logger.addHandler(l11ll1ll)
class Settings():
    l11ll111 = l1ll1l1l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11l11 = l1ll1l1l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111l1 = l1ll1l1l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l111):
        self.l1l111ll = self._11lll11(l1l1l111)
        self._1l1l1l1()
    def _11lll11(self, l1l1l111):
        l1l11l1l = l1l1l111.split(l1ll1l1l (u"ࠣࠢࠥࢂ"))
        l1l11l1l = l1ll1l1l (u"ࠤࠣࠦࢃ").join(l1l11l1l)
        if platform.system() == l1ll1l1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l111ll = os.path.join(l1l11ll1, l1ll1l1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11l1l + l1ll1l1l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l111ll
    def l11ll1l1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1l1l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1l1l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1ll11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1l1l1(self):
        if not os.path.exists(os.path.dirname(self.l1l111ll)):
            os.makedirs(os.path.dirname(self.l1l111ll))
        if not os.path.exists(self.l1l111ll):
            self.config = ConfigObj(self.l1l111ll)
            self.config[l1ll1l1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll1l1l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll1l1l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111l1
            self.config[l1ll1l1l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1l1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11l11
            self.config[l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll111
            self.config[l1ll1l1l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l111ll)
            self.l1l111l1 = self.get_value(l1ll1l1l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll1l1l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11l11 = self.get_value(l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1l1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll111 = self.get_value(l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11lll(self):
        l11lllll = l1ll1l1l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll111
        l11lllll += l1ll1l1l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11l11
        l11lllll += l1ll1l1l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111l1
        return l11lllll
    def __unicode__(self):
        return self._1l11lll()
    def __str__(self):
        return self._1l11lll()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l1l1l111)