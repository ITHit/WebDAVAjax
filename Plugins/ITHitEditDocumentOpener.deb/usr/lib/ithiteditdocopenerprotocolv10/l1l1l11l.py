#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll111 import l11llll
from configobj import ConfigObj
l1l1ll1l = l111lll (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l11l1l = l111lll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠺࠸࠳࠶ࠢࡤ")
l1l1111l = l111lll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l111lll (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠹࠷࠲࠵ࠨࡦ")
l11ll11l=os.path.join(os.environ.get(l111lll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l111lll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1111l.replace(l111lll (u"ࠦࠥࠨࡩ"), l111lll (u"ࠧࡥࠢࡪ")).lower())
l1l1l1l1=os.environ.get(l111lll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l111lll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll11=l1l11l1l.replace(l111lll (u"ࠣࠢࠥ࡭"), l111lll (u"ࠤࡢࠦ࡮"))+l111lll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l111lll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11l1lll=os.path.join(os.environ.get(l111lll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll11)
elif platform.system() == l111lll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1ll11=l11llll(l11ll11l+l111lll (u"ࠢ࠰ࠤࡳ"))
    l11l1lll = os.path.join(l1l1ll11, l11lll11)
else:
    l11l1lll = os.path.join( l11lll11)
l1l1l1l1=l1l1l1l1.upper()
if l1l1l1l1 == l111lll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11lll=logging.DEBUG
elif l1l1l1l1 == l111lll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11lll = logging.INFO
elif l1l1l1l1 == l111lll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11lll = logging.WARNING
elif l1l1l1l1 == l111lll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11lll = logging.ERROR
elif l1l1l1l1 == l111lll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11lll = logging.CRITICAL
elif l1l1l1l1 == l111lll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11lll = logging.NOTSET
logger = logging.getLogger(l111lll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11lll)
l1l1llll = logging.FileHandler(l11l1lll, mode=l111lll (u"ࠣࡹ࠮ࠦࡻ"))
l1l1llll.setLevel(l1l11lll)
formatter = logging.Formatter(l111lll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l111lll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1llll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11lll)
l1l1lll1 = SysLogHandler(address=l111lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1lll1.setFormatter(formatter)
logger.addHandler(l1l1llll)
logger.addHandler(ch)
logger.addHandler(l1l1lll1)
class Settings():
    l1l1l1ll = l111lll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11l11 = l111lll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111ll = l111lll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l11l1l):
        self.l11lll1l = self._1l111l1(l1l11l1l)
        self._11ll1l1()
    def _1l111l1(self, l1l11l1l):
        l1l11111 = l1l11l1l.split(l111lll (u"ࠣࠢࠥࢂ"))
        l1l11111 = l111lll (u"ࠤࠣࠦࢃ").join(l1l11111)
        if platform.system() == l111lll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11lll1l = os.path.join(l11ll11l, l111lll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11111 + l111lll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11lll1l
    def l11ll111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l111(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111lll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111lll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11llll1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11ll1l1(self):
        if not os.path.exists(os.path.dirname(self.l11lll1l)):
            os.makedirs(os.path.dirname(self.l11lll1l))
        if not os.path.exists(self.l11lll1l):
            self.config = ConfigObj(self.l11lll1l)
            self.config[l111lll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l111lll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l111lll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111ll
            self.config[l111lll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l111lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111lll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11l11
            self.config[l111lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l111lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l1ll
            self.config[l111lll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lll1l)
            self.l1l111ll = self.get_value(l111lll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l111lll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11l11 = self.get_value(l111lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111lll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l1ll = self.get_value(l111lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l111lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lllll(self):
        l1l11ll1 = l111lll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l1ll
        l1l11ll1 += l111lll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11l11
        l1l11ll1 += l111lll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111ll
        return l1l11ll1
    def __unicode__(self):
        return self._11lllll()
    def __str__(self):
        return self._11lllll()
    def __del__(self):
        self.config.write()
l11ll1ll = Settings(l1l11l1l)