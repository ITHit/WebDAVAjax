#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l1l1ll1 = 7
def l111lll (l11):
    global l111l1
    l1ll1l1 = ord (l11 [-1])
    l1lllll1 = l11 [:-1]
    l1l1111 = l1ll1l1 % len (l1lllll1)
    l1l11ll = l1lllll1 [:l1l1111] + l1lllll1 [l1l1111:]
    if l1ll111:
        l1ll11l1 = l1l11l1 () .join ([unichr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    else:
        l1ll11l1 = str () .join ([chr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    return eval (l1ll11l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll11l import l1l111l
from configobj import ConfigObj
l11ll1ll = l111lll (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11l1lll = l111lll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠹࠽࠳࠶ࠢࡤ")
l1l11111 = l111lll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l111lll (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠸࠼࠲࠵ࠨࡦ")
l1l1lll1=os.path.join(os.environ.get(l111lll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l111lll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11111.replace(l111lll (u"ࠦࠥࠨࡩ"), l111lll (u"ࠧࡥࠢࡪ")).lower())
l1l1llll=os.environ.get(l111lll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l111lll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l111l1=l11l1lll.replace(l111lll (u"ࠣࠢࠥ࡭"), l111lll (u"ࠤࡢࠦ࡮"))+l111lll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l111lll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1l1ll=os.path.join(os.environ.get(l111lll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l111l1)
elif platform.system() == l111lll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11llll1=l1l111l(l1l1lll1+l111lll (u"ࠢ࠰ࠤࡳ"))
    l1l1l1ll = os.path.join(l11llll1, l1l111l1)
else:
    l1l1l1ll = os.path.join( l1l111l1)
l1l1llll=l1l1llll.upper()
if l1l1llll == l111lll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lll11=logging.DEBUG
elif l1l1llll == l111lll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lll11 = logging.INFO
elif l1l1llll == l111lll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lll11 = logging.WARNING
elif l1l1llll == l111lll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lll11 = logging.ERROR
elif l1l1llll == l111lll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lll11 = logging.CRITICAL
elif l1l1llll == l111lll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lll11 = logging.NOTSET
logger = logging.getLogger(l111lll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lll11)
l1l111ll = logging.FileHandler(l1l1l1ll, mode=l111lll (u"ࠣࡹ࠮ࠦࡻ"))
l1l111ll.setLevel(l11lll11)
formatter = logging.Formatter(l111lll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l111lll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l111ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll11)
l11ll111 = SysLogHandler(address=l111lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll111.setFormatter(formatter)
logger.addHandler(l1l111ll)
logger.addHandler(ch)
logger.addHandler(l11ll111)
class Settings():
    l1l1l111 = l111lll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11lll = l111lll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11ll11l = l111lll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11l1lll):
        self.l1l1ll1l = self._1l11l1l(l11l1lll)
        self._11lll1l()
    def _1l11l1l(self, l11l1lll):
        l1l1ll11 = l11l1lll.split(l111lll (u"ࠣࠢࠥࢂ"))
        l1l1ll11 = l111lll (u"ࠤࠣࠦࢃ").join(l1l1ll11)
        if platform.system() == l111lll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1ll1l = os.path.join(l1l1lll1, l111lll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1ll11 + l111lll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1ll1l
    def l1l1l1l1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111lll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111lll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1111l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll1l(self):
        if not os.path.exists(os.path.dirname(self.l1l1ll1l)):
            os.makedirs(os.path.dirname(self.l1l1ll1l))
        if not os.path.exists(self.l1l1ll1l):
            self.config = ConfigObj(self.l1l1ll1l)
            self.config[l111lll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l111lll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l111lll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11ll11l
            self.config[l111lll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l111lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111lll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11lll
            self.config[l111lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l111lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l111
            self.config[l111lll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1ll1l)
            self.l11ll11l = self.get_value(l111lll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l111lll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11lll = self.get_value(l111lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111lll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l111 = self.get_value(l111lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l111lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11lllll(self):
        l1l11ll1 = l111lll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l111
        l1l11ll1 += l111lll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11lll
        l1l11ll1 += l111lll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11ll11l
        return l1l11ll1
    def __unicode__(self):
        return self._11lllll()
    def __str__(self):
        return self._11lllll()
    def __del__(self):
        self.config.write()
l11ll1l1 = Settings(l11l1lll)