#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1111ll = 2048
l1l1l11 = 7
def l1ll1l1l (l1l1ll1):
    global l1lll
    l1lll1l = ord (l1l1ll1 [-1])
    l1ll = l1l1ll1 [:-1]
    l11l1ll = l1lll1l % len (l1ll)
    l1lllll1 = l1ll [:l11l1ll] + l1ll [l11l1ll:]
    if l1l1l1l:
        l1111l1 = l1llll1l () .join ([unichr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    return eval (l1111l1)
import logging
import os
import re
from l1l111l import l1111l11
logger = logging.getLogger(l1ll1l1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1l1l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1ll1():
    try:
        out = os.popen(l1ll1l1l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1l1l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1l1l (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1l1l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1l1l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1l1l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1l1l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1111l11(l1ll1l1l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1l1l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111(l1ll1l1l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))