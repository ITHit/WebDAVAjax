#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l = sys.version_info [0] == 2
ll = 2048
l1 = 7
def l1111l1 (l1ll1lll):
    global l1ll1l1
    l1111 = ord (l1ll1lll [-1])
    l1l1lll = l1ll1lll [:-1]
    l11l1 = l1111 % len (l1l1lll)
    l1l1111 = l1l1lll [:l11l1] + l1l1lll [l11l1:]
    if l1lll1l:
        l1ll1ll1 = l1l1l () .join ([unichr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    else:
        l1ll1ll1 = str () .join ([chr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    return eval (l1ll1ll1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll111l import l11lll1
from configobj import ConfigObj
l1l11ll1 = l1111l1 (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1l1ll = l1111l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠷࠹࠳࠶ࠢࡤ")
l11ll11l = l1111l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1111l1 (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠶࠸࠲࠵ࠨࡦ")
l1l1ll1l=os.path.join(os.environ.get(l1111l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1111l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll11l.replace(l1111l1 (u"ࠦࠥࠨࡩ"), l1111l1 (u"ࠧࡥࠢࡪ")).lower())
l11lllll=os.environ.get(l1111l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1111l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll1l=l1l1l1ll.replace(l1111l1 (u"ࠣࠢࠥ࡭"), l1111l1 (u"ࠤࡢࠦ࡮"))+l1111l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1111l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll111=os.path.join(os.environ.get(l1111l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll1l)
elif platform.system() == l1111l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll1ll=l11lll1(l1l1ll1l+l1111l1 (u"ࠢ࠰ࠤࡳ"))
    l11ll111 = os.path.join(l11ll1ll, l11lll1l)
else:
    l11ll111 = os.path.join( l11lll1l)
l11lllll=l11lllll.upper()
if l11lllll == l1111l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11l1lll=logging.DEBUG
elif l11lllll == l1111l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11l1lll = logging.INFO
elif l11lllll == l1111l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11l1lll = logging.WARNING
elif l11lllll == l1111l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11l1lll = logging.ERROR
elif l11lllll == l1111l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11l1lll = logging.CRITICAL
elif l11lllll == l1111l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11l1lll = logging.NOTSET
logger = logging.getLogger(l1111l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11l1lll)
l1l1111l = logging.FileHandler(l11ll111, mode=l1111l1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1111l.setLevel(l11l1lll)
formatter = logging.Formatter(l1111l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1111l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1111l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11l1lll)
l1l11l1l = SysLogHandler(address=l1111l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11l1l.setFormatter(formatter)
logger.addHandler(l1l1111l)
logger.addHandler(ch)
logger.addHandler(l1l11l1l)
class Settings():
    l1l1l1l1 = l1111l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11l11 = l1111l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1ll11 = l1111l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l1ll):
        self.l1l11111 = self._1l1lll1(l1l1l1ll)
        self._11llll1()
    def _1l1lll1(self, l1l1l1ll):
        l1l11lll = l1l1l1ll.split(l1111l1 (u"ࠣࠢࠥࢂ"))
        l1l11lll = l1111l1 (u"ࠤࠣࠦࢃ").join(l1l11lll)
        if platform.system() == l1111l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11111 = os.path.join(l1l1ll1l, l1111l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11lll + l1111l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11111
    def l1l1l11l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1llll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1111l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1111l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11llll1(self):
        if not os.path.exists(os.path.dirname(self.l1l11111)):
            os.makedirs(os.path.dirname(self.l1l11111))
        if not os.path.exists(self.l1l11111):
            self.config = ConfigObj(self.l1l11111)
            self.config[l1111l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1111l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1111l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1ll11
            self.config[l1111l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1111l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1111l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11l11
            self.config[l1111l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1111l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l1l1
            self.config[l1111l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11111)
            self.l1l1ll11 = self.get_value(l1111l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1111l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11l11 = self.get_value(l1111l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1111l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l1l1 = self.get_value(l1111l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1111l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l111l1(self):
        l1l111ll = l1111l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l1l1
        l1l111ll += l1111l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11l11
        l1l111ll += l1111l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1ll11
        return l1l111ll
    def __unicode__(self):
        return self._1l111l1()
    def __str__(self):
        return self._1l111l1()
    def __del__(self):
        self.config.write()
l11ll1l1 = Settings(l1l1l1ll)