#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l = 2048
l1lll11l = 7
def l11lll1 (l1ll1l1):
    global l1lll1
    l1111l = ord (l1ll1l1 [-1])
    l11111l = l1ll1l1 [:-1]
    l1l11l1 = l1111l % len (l11111l)
    l11l1l1 = l11111l [:l1l11l1] + l11111l [l1l11l1:]
    if l1l11l:
        l11ll = l1l111l () .join ([unichr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    return eval (l11ll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1111l1 import l111l11
from configobj import ConfigObj
l1l1l11l = l11lll1 (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11l1lll = l11lll1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠺࠻࠻࠳࠶ࠢࡤ")
l1l11lll = l11lll1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11lll1 (u"ࠣ࠷࠱࠶࠶࠴࠵࠹࠺࠺࠲࠵ࠨࡦ")
l1l111ll=os.path.join(os.environ.get(l11lll1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11lll1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11lll.replace(l11lll1 (u"ࠦࠥࠨࡩ"), l11lll1 (u"ࠧࡥࠢࡪ")).lower())
l11lll1l=os.environ.get(l11lll1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11lll1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1111l=l11l1lll.replace(l11lll1 (u"ࠣࠢࠥ࡭"), l11lll1 (u"ࠤࡢࠦ࡮"))+l11lll1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11lll1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll1l1=os.path.join(os.environ.get(l11lll1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1111l)
elif platform.system() == l11lll1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll111=l111l11(l1l111ll+l11lll1 (u"ࠢ࠰ࠤࡳ"))
    l11ll1l1 = os.path.join(l11ll111, l1l1111l)
else:
    l11ll1l1 = os.path.join( l1l1111l)
l11lll1l=l11lll1l.upper()
if l11lll1l == l11lll1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1l1l1=logging.DEBUG
elif l11lll1l == l11lll1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1l1l1 = logging.INFO
elif l11lll1l == l11lll1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1l1l1 = logging.WARNING
elif l11lll1l == l11lll1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1l1l1 = logging.ERROR
elif l11lll1l == l11lll1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1l1l1 = logging.CRITICAL
elif l11lll1l == l11lll1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1l1l1 = logging.NOTSET
logger = logging.getLogger(l11lll1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1l1l1)
l1l1ll1l = logging.FileHandler(l11ll1l1, mode=l11lll1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1ll1l.setLevel(l1l1l1l1)
formatter = logging.Formatter(l11lll1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11lll1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1ll1l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l1l1)
l1l11ll1 = SysLogHandler(address=l11lll1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11ll1.setFormatter(formatter)
logger.addHandler(l1l1ll1l)
logger.addHandler(ch)
logger.addHandler(l1l11ll1)
class Settings():
    l11llll1 = l11lll1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11ll11l = l11lll1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1ll11 = l11lll1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11l1lll):
        self.l1l11l11 = self._1l1l1ll(l11l1lll)
        self._1l1lll1()
    def _1l1l1ll(self, l11l1lll):
        l1l1l111 = l11l1lll.split(l11lll1 (u"ࠣࠢࠥࢂ"))
        l1l1l111 = l11lll1 (u"ࠤࠣࠦࢃ").join(l1l1l111)
        if platform.system() == l11lll1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11l11 = os.path.join(l1l111ll, l11lll1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l111 + l11lll1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11l11
    def l1l11111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11lll1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11lll1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11lllll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1lll1(self):
        if not os.path.exists(os.path.dirname(self.l1l11l11)):
            os.makedirs(os.path.dirname(self.l1l11l11))
        if not os.path.exists(self.l1l11l11):
            self.config = ConfigObj(self.l1l11l11)
            self.config[l11lll1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11lll1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11lll1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1ll11
            self.config[l11lll1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11lll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11lll1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11ll11l
            self.config[l11lll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11lll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11llll1
            self.config[l11lll1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11l11)
            self.l1l1ll11 = self.get_value(l11lll1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11lll1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11ll11l = self.get_value(l11lll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11lll1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11llll1 = self.get_value(l11lll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11lll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11l1l(self):
        l1l111l1 = l11lll1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11llll1
        l1l111l1 += l11lll1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11ll11l
        l1l111l1 += l11lll1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1ll11
        return l1l111l1
    def __unicode__(self):
        return self._1l11l1l()
    def __str__(self):
        return self._1l11l1l()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l11l1lll)