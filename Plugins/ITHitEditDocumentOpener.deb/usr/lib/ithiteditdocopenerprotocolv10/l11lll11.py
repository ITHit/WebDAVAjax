#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1lll111 = 2048
l1111 = 7
def l1ll (l11lll):
    global l1l1l1
    l1ll1l1 = ord (l11lll [-1])
    l1l1lll = l11lll [:-1]
    l1ll11l1 = l1ll1l1 % len (l1l1lll)
    l111 = l1l1lll [:l1ll11l1] + l1l1lll [l1ll11l1:]
    if l111ll1:
        l11llll = l1ll1l11 () .join ([unichr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    else:
        l11llll = str () .join ([chr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    return eval (l11llll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l111111 import l1l11ll
from configobj import ConfigObj
l1l11l1l = l1ll (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1l1ll = l1ll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠹࠴࠳࠶ࠢࡤ")
l1l1ll11 = l1ll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠸࠳࠲࠵ࠨࡦ")
l1l11111=os.path.join(os.environ.get(l1ll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1ll11.replace(l1ll (u"ࠦࠥࠨࡩ"), l1ll (u"ࠧࡥࠢࡪ")).lower())
l1l111l1=os.environ.get(l1ll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll1l=l1l1l1ll.replace(l1ll (u"ࠣࠢࠥ࡭"), l1ll (u"ࠤࡢࠦ࡮"))+l1ll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll1ll=os.path.join(os.environ.get(l1ll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll1l)
elif platform.system() == l1ll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l11l=l1l11ll(l1l11111+l1ll (u"ࠢ࠰ࠤࡳ"))
    l11ll1ll = os.path.join(l1l1l11l, l11lll1l)
else:
    l11ll1ll = os.path.join( l11lll1l)
l1l111l1=l1l111l1.upper()
if l1l111l1 == l1ll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11l11=logging.DEBUG
elif l1l111l1 == l1ll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11l11 = logging.INFO
elif l1l111l1 == l1ll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11l11 = logging.WARNING
elif l1l111l1 == l1ll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11l11 = logging.ERROR
elif l1l111l1 == l1ll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11l11 = logging.CRITICAL
elif l1l111l1 == l1ll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11l11 = logging.NOTSET
logger = logging.getLogger(l1ll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11l11)
l1l111ll = logging.FileHandler(l11ll1ll, mode=l1ll (u"ࠣࡹ࠮ࠦࡻ"))
l1l111ll.setLevel(l1l11l11)
formatter = logging.Formatter(l1ll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l111ll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11l11)
l11lllll = SysLogHandler(address=l1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11lllll.setFormatter(formatter)
logger.addHandler(l1l111ll)
logger.addHandler(ch)
logger.addHandler(l11lllll)
class Settings():
    l1l1l111 = l1ll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11llll1 = l1ll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l1l1 = l1ll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l1ll):
        self.l1l11ll1 = self._1l1lll1(l1l1l1ll)
        self._1l1111l()
    def _1l1lll1(self, l1l1l1ll):
        l1l1ll1l = l1l1l1ll.split(l1ll (u"ࠣࠢࠥࢂ"))
        l1l1ll1l = l1ll (u"ࠤࠣࠦࢃ").join(l1l1ll1l)
        if platform.system() == l1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11ll1 = os.path.join(l1l11111, l1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1ll1l + l1ll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11ll1
    def l11l1lll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll111(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11ll1l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1111l(self):
        if not os.path.exists(os.path.dirname(self.l1l11ll1)):
            os.makedirs(os.path.dirname(self.l1l11ll1))
        if not os.path.exists(self.l1l11ll1):
            self.config = ConfigObj(self.l1l11ll1)
            self.config[l1ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l1l1
            self.config[l1ll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11llll1
            self.config[l1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l111
            self.config[l1ll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11ll1)
            self.l1l1l1l1 = self.get_value(l1ll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11llll1 = self.get_value(l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l111 = self.get_value(l1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1llll(self):
        l11ll11l = l1ll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l111
        l11ll11l += l1ll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11llll1
        l11ll11l += l1ll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l1l1
        return l11ll11l
    def __unicode__(self):
        return self._1l1llll()
    def __str__(self):
        return self._1l1llll()
    def __del__(self):
        self.config.write()
l1l11lll = Settings(l1l1l1ll)