#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l1 = sys.version_info [0] == 2
l111ll = 2048
l11111l = 7
def l1ll1ll (l11llll):
    global l1ll11l
    l111lll = ord (l11llll [-1])
    l1l1 = l11llll [:-1]
    l1llll1l = l111lll % len (l1l1)
    l1l1l1l = l1l1 [:l1llll1l] + l1l1 [l1llll1l:]
    if l1l11l1:
        l1ll1l1l = l1111ll () .join ([unichr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    else:
        l1ll1l1l = str () .join ([chr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    return eval (l1ll1l1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1111l1 import l1l1l11
from configobj import ConfigObj
l1l1llll = l1ll1ll (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l11llll1 = l1ll1ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠶࠲࠱࠴ࠧࡢ")
l11ll1l1 = l1ll1ll (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1ll1ll (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠵࠱࠰࠳ࠦࡤ")
l1l1111l=os.path.join(os.environ.get(l1ll1ll (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1ll1ll (u"ࠣ࠰ࠨࡷࠧࡦ") %l11ll1l1.replace(l1ll1ll (u"ࠤࠣࠦࡧ"), l1ll1ll (u"ࠥࡣࠧࡨ")).lower())
l1ll1111=os.environ.get(l1ll1ll (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1ll1ll (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l11lll=l11llll1.replace(l1ll1ll (u"ࠨࠠࠣ࡫"), l1ll1ll (u"ࠢࡠࠤ࡬"))+l1ll1ll (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1ll1ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1ll1l=os.path.join(os.environ.get(l1ll1ll (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l11lll)
elif platform.system() == l1ll1ll (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l111ll=l1l1l11(l1l1111l+l1ll1ll (u"ࠧ࠵ࠢࡱ"))
    l1l1ll1l = os.path.join(l1l111ll, l1l11lll)
else:
    l1l1ll1l = os.path.join( l1l11lll)
l1ll1111=l1ll1111.upper()
if l1ll1111 == l1ll1ll (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l1ll11=logging.DEBUG
elif l1ll1111 == l1ll1ll (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l1ll11 = logging.INFO
elif l1ll1111 == l1ll1ll (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l1ll11 = logging.WARNING
elif l1ll1111 == l1ll1ll (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l1ll11 = logging.ERROR
elif l1ll1111 == l1ll1ll (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l1ll11 = logging.CRITICAL
elif l1ll1111 == l1ll1ll (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l1ll11 = logging.NOTSET
logger = logging.getLogger(l1ll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l1ll11)
l11lllll = logging.FileHandler(l1l1ll1l, mode=l1ll1ll (u"ࠨࡷࠬࠤࡹ"))
l11lllll.setLevel(l1l1ll11)
formatter = logging.Formatter(l1ll1ll (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1ll1ll (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l11lllll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1ll11)
l1l1lll1 = SysLogHandler(address=l1ll1ll (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l1lll1.setFormatter(formatter)
logger.addHandler(l11lllll)
logger.addHandler(ch)
logger.addHandler(l1l1lll1)
class Settings():
    l11ll11l = l1ll1ll (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1ll111l = l1ll1ll (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l1l11l = l1ll1ll (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l11llll1):
        self.l1l111l1 = self._1l11l1l(l11llll1)
        self._1l1l1ll()
    def _1l11l1l(self, l11llll1):
        l1l11ll1 = l11llll1.split(l1ll1ll (u"ࠨࠠࠣࢀ"))
        l1l11ll1 = l1ll1ll (u"ࠢࠡࠤࢁ").join(l1l11ll1)
        if platform.system() == l1ll1ll (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l111l1 = os.path.join(l1l1111l, l1ll1ll (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l11ll1 + l1ll1ll (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l111l1
    def l1l1l111(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1ll (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1ll (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l1l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1l1ll(self):
        if not os.path.exists(os.path.dirname(self.l1l111l1)):
            os.makedirs(os.path.dirname(self.l1l111l1))
        if not os.path.exists(self.l1l111l1):
            self.config = ConfigObj(self.l1l111l1)
            self.config[l1ll1ll (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1ll1ll (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1ll1ll (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l1l11l
            self.config[l1ll1ll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1ll1ll (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1ll111l
            self.config[l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l11ll11l
            self.config[l1ll1ll (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l111l1)
            self.l1l1l11l = self.get_value(l1ll1ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1ll1ll (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1ll111l = self.get_value(l1ll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1ll1ll (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l11ll11l = self.get_value(l1ll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l11111(self):
        l11ll1ll = l1ll1ll (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l11ll11l
        l11ll1ll += l1ll1ll (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1ll111l
        l11ll1ll += l1ll1ll (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l1l11l
        return l11ll1ll
    def __unicode__(self):
        return self._1l11111()
    def __str__(self):
        return self._1l11111()
    def __del__(self):
        self.config.write()
l1l11l11 = Settings(l11llll1)