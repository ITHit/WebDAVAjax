#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1ll = 7
def l11ll11 (l1lll11l):
    global l1ll
    l1l1ll1 = ord (l1lll11l [-1])
    l11l1l1 = l1lll11l [:-1]
    l111ll1 = l1l1ll1 % len (l11l1l1)
    l11lll = l11l1l1 [:l111ll1] + l11l1l1 [l111ll1:]
    if l1l1l:
        l1lll = l111111 () .join ([unichr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    return eval (l1lll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1llll1 import l1l1111
from configobj import ConfigObj
l1l1llll = l11ll11 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l1ll11 = l11ll11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠵࠺࠱࠴ࠧࡢ")
l1l11111 = l11ll11 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l11ll11 (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠴࠹࠰࠳ࠦࡤ")
l11lll1l=os.path.join(os.environ.get(l11ll11 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l11ll11 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l11111.replace(l11ll11 (u"ࠤࠣࠦࡧ"), l11ll11 (u"ࠥࡣࠧࡨ")).lower())
l1l11lll=os.environ.get(l11ll11 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l11ll11 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l1l11l=l1l1ll11.replace(l11ll11 (u"ࠨࠠࠣ࡫"), l11ll11 (u"ࠢࡠࠤ࡬"))+l11ll11 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l11ll11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l11l1l=os.path.join(os.environ.get(l11ll11 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l1l11l)
elif platform.system() == l11ll11 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l11l11=l1l1111(l11lll1l+l11ll11 (u"ࠧ࠵ࠢࡱ"))
    l1l11l1l = os.path.join(l1l11l11, l1l1l11l)
else:
    l1l11l1l = os.path.join( l1l1l11l)
l1l11lll=l1l11lll.upper()
if l1l11lll == l11ll11 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l111ll=logging.DEBUG
elif l1l11lll == l11ll11 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l111ll = logging.INFO
elif l1l11lll == l11ll11 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l111ll = logging.WARNING
elif l1l11lll == l11ll11 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l111ll = logging.ERROR
elif l1l11lll == l11ll11 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l111ll = logging.CRITICAL
elif l1l11lll == l11ll11 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l111ll = logging.NOTSET
logger = logging.getLogger(l11ll11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l111ll)
l1ll1111 = logging.FileHandler(l1l11l1l, mode=l11ll11 (u"ࠨࡷࠬࠤࡹ"))
l1ll1111.setLevel(l1l111ll)
formatter = logging.Formatter(l11ll11 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l11ll11 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1ll1111.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l111ll)
l1l1ll1l = SysLogHandler(address=l11ll11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l1ll1111)
logger.addHandler(ch)
logger.addHandler(l1l1ll1l)
class Settings():
    l1l1l111 = l11ll11 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11ll1ll = l11ll11 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l11llll1 = l11ll11 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l1ll11):
        self.l11ll1l1 = self._1l1l1l1(l1l1ll11)
        self._1l11ll1()
    def _1l1l1l1(self, l1l1ll11):
        l11ll11l = l1l1ll11.split(l11ll11 (u"ࠨࠠࠣࢀ"))
        l11ll11l = l11ll11 (u"ࠢࠡࠤࢁ").join(l11ll11l)
        if platform.system() == l11ll11 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11ll1l1 = os.path.join(l11lll1l, l11ll11 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l11ll11l + l11ll11 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11ll1l1
    def l1l111l1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11ll11 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11ll11 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1111l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11ll1(self):
        if not os.path.exists(os.path.dirname(self.l11ll1l1)):
            os.makedirs(os.path.dirname(self.l11ll1l1))
        if not os.path.exists(self.l11ll1l1):
            self.config = ConfigObj(self.l11ll1l1)
            self.config[l11ll11 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l11ll11 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l11ll11 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l11llll1
            self.config[l11ll11 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l11ll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l11ll11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11ll1ll
            self.config[l11ll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11ll11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1l111
            self.config[l11ll11 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll1l1)
            self.l11llll1 = self.get_value(l11ll11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l11ll11 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11ll1ll = self.get_value(l11ll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l11ll11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1l111 = self.get_value(l11ll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11ll11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1lll1(self):
        l11lll11 = l11ll11 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1l111
        l11lll11 += l11ll11 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11ll1ll
        l11lll11 += l11ll11 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l11llll1
        return l11lll11
    def __unicode__(self):
        return self._1l1lll1()
    def __str__(self):
        return self._1l1lll1()
    def __del__(self):
        self.config.write()
l1ll111l = Settings(l1l1ll11)