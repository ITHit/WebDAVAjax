#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l11l = 2048
l1l1l11 = 7
def l111l11 (l1ll):
    global l11lll
    l1ll1l1l = ord (l1ll [-1])
    l11ll1l = l1ll [:-1]
    l1l1 = l1ll1l1l % len (l11ll1l)
    l11l1ll = l11ll1l [:l1l1] + l11ll1l [l1l1:]
    if l1ll1ll:
        l1l11l1 = l1ll1ll1 () .join ([unichr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    return eval (l1l11l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll1ll import l11lll1
from configobj import ConfigObj
l1l1lll1 = l111l11 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l11ll1l1 = l111l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠲࠸࠱࠴ࠧࡢ")
l1l11111 = l111l11 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l111l11 (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠱࠷࠰࠳ࠦࡤ")
l11ll1ll=os.path.join(os.environ.get(l111l11 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l111l11 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l11111.replace(l111l11 (u"ࠤࠣࠦࡧ"), l111l11 (u"ࠥࡣࠧࡨ")).lower())
l1l11lll=os.environ.get(l111l11 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l111l11 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l111ll=l11ll1l1.replace(l111l11 (u"ࠨࠠࠣ࡫"), l111l11 (u"ࠢࡠࠤ࡬"))+l111l11 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l111l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l11l1l=os.path.join(os.environ.get(l111l11 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l111ll)
elif platform.system() == l111l11 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l1l11l=l11lll1(l11ll1ll+l111l11 (u"ࠧ࠵ࠢࡱ"))
    l1l11l1l = os.path.join(l1l1l11l, l1l111ll)
else:
    l1l11l1l = os.path.join( l1l111ll)
l1l11lll=l1l11lll.upper()
if l1l11lll == l111l11 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11ll11l=logging.DEBUG
elif l1l11lll == l111l11 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11ll11l = logging.INFO
elif l1l11lll == l111l11 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11ll11l = logging.WARNING
elif l1l11lll == l111l11 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11ll11l = logging.ERROR
elif l1l11lll == l111l11 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11ll11l = logging.CRITICAL
elif l1l11lll == l111l11 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11ll11l = logging.NOTSET
logger = logging.getLogger(l111l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11ll11l)
l1l11ll1 = logging.FileHandler(l1l11l1l, mode=l111l11 (u"ࠨࡷࠬࠤࡹ"))
l1l11ll1.setLevel(l11ll11l)
formatter = logging.Formatter(l111l11 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l111l11 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l11ll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll11l)
l1l1llll = SysLogHandler(address=l111l11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l1llll.setFormatter(formatter)
logger.addHandler(l1l11ll1)
logger.addHandler(ch)
logger.addHandler(l1l1llll)
class Settings():
    l1l1l1l1 = l111l11 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l11l11 = l111l11 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l111l1 = l111l11 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l11ll1l1):
        self.l1ll1111 = self._11llll1(l11ll1l1)
        self._11lll1l()
    def _11llll1(self, l11ll1l1):
        l1l1l111 = l11ll1l1.split(l111l11 (u"ࠨࠠࠣࢀ"))
        l1l1l111 = l111l11 (u"ࠢࠡࠤࢁ").join(l1l1l111)
        if platform.system() == l111l11 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1ll1111 = os.path.join(l11ll1ll, l111l11 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1l111 + l111l11 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1ll1111
    def l1l1ll1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l111l11 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l111l11 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l1ll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll1l(self):
        if not os.path.exists(os.path.dirname(self.l1ll1111)):
            os.makedirs(os.path.dirname(self.l1ll1111))
        if not os.path.exists(self.l1ll1111):
            self.config = ConfigObj(self.l1ll1111)
            self.config[l111l11 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l111l11 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l111l11 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l111l1
            self.config[l111l11 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l111l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l111l11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l11l11
            self.config[l111l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l111l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1l1l1
            self.config[l111l11 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1ll1111)
            self.l1l111l1 = self.get_value(l111l11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l111l11 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l11l11 = self.get_value(l111l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l111l11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1l1l1 = self.get_value(l111l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l111l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1111l(self):
        l1l1ll11 = l111l11 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1l1l1
        l1l1ll11 += l111l11 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l11l11
        l1l1ll11 += l111l11 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l111l1
        return l1l1ll11
    def __unicode__(self):
        return self._1l1111l()
    def __str__(self):
        return self._1l1111l()
    def __del__(self):
        self.config.write()
l1ll111l = Settings(l11ll1l1)