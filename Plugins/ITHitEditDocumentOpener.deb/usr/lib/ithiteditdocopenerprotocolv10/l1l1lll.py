#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l1ll = 2048
l1l1 = 7
def l1lll1l (l1l111):
    global l1l111l
    l1lll1ll = ord (l1l111 [-1])
    l1lllll = l1l111 [:-1]
    l11111 = l1lll1ll % len (l1lllll)
    l1ll1l11 = l1lllll [:l11111] + l1lllll [l11111:]
    if l1ll1ll:
        l1ll11 = l1l1l () .join ([unichr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    return eval (l1ll11)
import gi
gi.require_version(l1lll1l (u"ࠨࡉࡷ࡯ࠬঽ"), l1lll1l (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11llll1
import logging
logger = logging.getLogger(l1lll1l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1lllll1(Gtk.Window):
    def __init__(self, l1l1ll111l, l1ll111ll1):
        Gtk.Window.__init__(self)
        self.l1lll1l1=30
        self.l1l1lll1ll = False
        self.service = l1l1ll111l
        self.l11l1l=l1ll111ll1
        self.l1=l11llll1.l1l1l1l1
        self.l1l1l1ll11 = Gtk.ListStore(str)
        self.l1ll1l111l()
    def l1l1l1l1l1(self, service):
        l1l11ll111 = self.l1.l1l111ll(l1lll1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l11ll111
    def l1ll1l111l(self, l1l1ll111l=None):
        if l1l1ll111l:
            self.l1l1l1ll11.clear()
            l1ll11l1l1=self.l1l1l1l1l1(l1l1ll111l)
            self.l1l1l1ll11.append([l1lll1l (u"ࠧࠨু")])
            for l11l1l in l1ll11l1l1:
                self.l1l1l1ll11.append([l11l1l])
        else:
            self.l1l1l1ll11.clear()
            self.l1l1l1ll11.append([l1lll1l (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll1llll1(self, widget, data=None):
        l1l11lll1l= widget.get_active()
        if data == l1lll1l (u"ࠢ࠲ࠤৃ") and l1l11lll1l:
            self.l1ll1l111l()
            self.l1ll11l1ll.set_active(0)
            self.l1l1lll111.set_text(l1lll1l (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1lll111.set_sensitive(False)
            self.l1ll11l1ll.set_sensitive(False)
        else:
            self.l1ll1l111l(l1l1ll111l=self.service)
            self.l1ll11l1ll.set_active(0)
            self.l1l1lll111.set_text(l1lll1l (u"ࠤࠥ৅"))
            self.l1ll11l1ll.set_sensitive(True)
            self.l1l1lll111.set_sensitive(True)
    def l1l1llll1l(self, widget):
        if widget.get_active():
            l11l1l = widget.get_child().get_text()
        else:
            l11l1l = self.l1l1l1ll11[widget.get_active()][0]
        password = self.l1ll1lll11(self.service, l11l1l)
        if password:
            self.l1l1lll111.set_text(password)
        else:
            self.l1l1lll111.set_text(l1lll1l (u"ࠥࠦ৆"))
    def l1ll1l1ll1(self, l11l1l, pwd, service):
        keyring.set_password(service, l11l1l, pwd)
        l1l11ll111=self.l1.l1l111ll(l1lll1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11l1l in l1l11ll111:
            value = self.l1.get_value(l1lll1l (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1.l1l1l1ll(l1lll1l (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1lll1l (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11l1l))
    def l1ll1lll11(self, service, l11l1l):
        l1l1l11lll = keyring.get_password(service, l11l1l)
        return l1l1l11lll
    def l1ll11111l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1l1111(self, widget, data=None):
        self.l1l1lll1ll=widget.get_active()
    def l1lll(self, message, title=l1lll1l (u"ࠨࠩো"), l1l11ll1l=True):
        if l1l11ll1l:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1l11l1 = Gtk.MessageDialog(self,
            l1l11l1l11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1l11l1.set_title(title)
        l1ll1l11l1.set_default_response(Gtk.ResponseType.OK)
        l1l1lll11l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1lll1l1 = Gtk.VBox()
        l1ll1ll11l = Gtk.Box(spacing=1)
        l1ll1ll11l.set_homogeneous(False)
        l1ll11l111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11l111.set_homogeneous(False)
        l1ll11l11l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11l11l.set_homogeneous(False)
        l1ll1ll11l.pack_start(l1ll11l111, True, True, 0)
        l1ll1ll11l.pack_start(l1ll11l11l, True, True, 0)
        l1l1l1l111 = l1ll1l11l1.get_content_area()
        l1ll1lllll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l111.pack_start(l1ll1lllll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l11llll1 = Gtk.Label()
        l1l11ll1ll = Gtk.Label()
        l1l11ll1ll.set_text(l1lll1l (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l11ll1ll, True, True, 0)
        l1l11llll1.set_text(l1lll1l (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l11llll1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l11llll1, 0, 1, 0, 1)
        l1l1ll1ll1 = Gtk.RadioButton.new_with_label_from_widget(None, l1lll1l (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l1ll1ll1.connect(l1lll1l (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll1llll1, l1lll1l (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l1ll1ll1, 1, 2, 0, 1)
        l1l1l11111 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1ll1, l1lll1l (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1l11111.connect(l1lll1l (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll1llll1, l1lll1l (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1l11111, 1, 2, 1, 2)
        l1ll1l1l11 = Gtk.Label()
        l1ll1l1l11.set_text(l1lll1l (u"ࠥࠤࠧ৔"))
        table.attach(l1ll1l1l11, 0, 1, 4, 6)
        l1ll111l1l = Gtk.Label()
        l1ll111l1l.set_text(l1lll1l (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll111l1l.set_justify(Gtk.Justification.RIGHT)
        l1ll111l1l.set_alignment(xalign=1, yalign=0.5)
        self.l1ll11l1ll = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1ll11)
        self.l1ll11l1ll.set_entry_text_column(0)
        table.attach(l1ll111l1l, 0, 1, 6, 8)
        table.attach(self.l1ll11l1ll, 1, 3, 6, 8)
        self.l1ll11l1ll.connect(l1lll1l (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1llll1l)
        l1l11lll11 = Gtk.Label()
        l1l11lll11.set_text(l1lll1l (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l11lll11.set_justify(Gtk.Justification.RIGHT)
        l1l11lll11.set_alignment(xalign=1, yalign=0.5)
        self.l1l1lll111 = Gtk.Entry()
        self.l1l1lll111.set_visibility(False)
        self.l1l1lll111.connect(l1lll1l (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1ll11111l, l1ll1l11l1)
        table.attach(l1l11lll11, 0, 1, 8, 10)
        table.attach(self.l1l1lll111, 1, 3, 8, 10)
        l1l1ll1l11 = Gtk.CheckButton(l1lll1l (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1ll1l11.connect(l1lll1l (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll1l1111, l1l1ll1l11)
        l1l1ll1l11.set_active(False)
        table.attach(l1l1ll1l11, 1, 3, 12, 14)
        l1l11l1ll1 = Gtk.Label()
        l1l11l1ll1.set_text(l1lll1l (u"ࠥࠤࠧ৛") * 5)
        l1l1lll1l1.pack_start(l1l11l1ll1, True, True, 0)
        if self.l11l1l:
            l1l1l11111.set_active(True)
            self.l1ll11l1ll.set_active(0)
            self.l1ll11l1ll.set_sensitive(True)
            self.l1l1lll111.set_text(l1lll1l (u"ࠦࠧড়"))
            self.l1l1lll111.set_sensitive(True)
        else:
            self.l1ll11l1ll.set_active(0)
            self.l1ll11l1ll.set_sensitive(False)
            self.l1l1lll111.set_text(l1lll1l (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1lll111.set_sensitive(False)
        l1l1lll11l.pack_start(vbox, True, True, 0)
        l1l1lll11l.pack_start(table, True, True, 0)
        l1l1lll11l.pack_end(l1l1lll1l1, True, True, 0)
        l1ll1lllll.pack_start(l1l1lll11l, True, True, 0)
        l1ll1l11l1.show_all()
        response = l1ll1l11l1.run()
        if self.l1ll11l1ll.get_active():
            l11l1l = self.l1ll11l1ll.get_child().get_text()
        else:
            l11l1l = self.l1l1l1ll11[self.l1ll11l1ll.get_active()][0]
        pwd = self.l1l1lll111.get_text()
        l1ll1l11l1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1lll1ll:
                self.l1ll1l1ll1(l11l1l, pwd, self.service)
            return l11l1l, pwd
        else:
            return l1lll1l (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1lll1l (u"ࠧࠨয়")
class l1ll1l111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1llllll(self, l11ll111):
        l1ll11ll1l = Gtk.ScrolledWindow()
        l1ll11ll1l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11lll1=None
        self.l1l1ll11ll = Gtk.TextBuffer()
        self.l1l1ll11ll.set_text(l11ll111)
        self.set_style()
        regexp= l1lll1l (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l1l1ll1l = self._1l1ll11l1(l11ll111, regexp)
        self.l1l11l11ll(l1l1l1ll1l, self.l1l1ll11ll.get_start_iter())
        self.l1ll1l1lll = Gtk.TextView(buffer=self.l1l1ll11ll)
        self.l1ll1l1lll.set_property(l1lll1l (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll1l1lll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll1l1lll.connect(l1lll1l (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l11l1lll)
        self.l1ll1l1lll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll11ll1l.set_size_request(300,100)
        self.l1ll1l1lll.show()
        l1ll11ll1l.add(self.l1ll1l1lll)
        l1ll11ll1l.show()
        return l1ll11ll1l
    def _1l11l1lll(self, *args, **kwargs):
        l1ll1111l1, l1l1l1111l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1111l1, l1l1l1111l).get_tags()
        if not self.l1ll11lll1:
            self.l1ll11lll1 = args[1].window.get_cursor()
            self.l1l1ll1l1l = Gdk.Cursor(Gdk.CursorType.l1ll1l11ll)
        elif tag:
            args[1].window.set_cursor(self.l1l1ll1l1l)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11lll1:
                args[1].window.set_cursor(self.l1ll11lll1)
    def _1l1ll11l1(self, l11ll111, l1ll1l1l1l):
        res=[]
        l1l1l111l1=re.findall(l1ll1l1l1l,l11ll111)
        for l1ll111111 in l1l1l111l1:
            for el in l1ll111111:
                if el:
                    res.append(el)
        return res
    def l1l11l11ll(self, l1l1l1ll1l, start):
        l1l1l1llll=0
        for text in l1l1l1ll1l:
            end = self.l1l1ll11ll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l1llll+=1
                l1l11lllll, l1ll111lll = match
                tag = self.l1l1ll11ll.create_tag(str(l1l1l1llll), foreground=l1lll1l (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1lll1l (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll1ll111, text)
                self.l1l1ll11ll.apply_tag(tag, l1l11lllll, l1ll111lll)
                self.l1l11l11ll(l1l1l1ll1l, l1ll111lll)
    def _1ll1ll111(self, tag, widget, l1ll11llll, _1l1l1l1ll, text):
        _1l1l1lll1 = l1ll11llll.type
        _1ll1lll1l = l1ll11llll.window
        if _1l1l1lll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l1lll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll11llll.button
            self.l1ll11lll1 = Gdk.Cursor(Gdk.CursorType.l1ll1l11ll)
            if _1l1l1lll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1lll1l (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l111l11l1(self, message, title=l1lll1l (u"ࠧࠨ০"), l1l11ll1l=True, l1l1ll1111=None):
        if l1l11ll1l:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l11l1l11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1ll1111:
            l1l1l1l111 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1ll11l = Gtk.HBox(spacing=0)
            l1l11ll1l1 = Gtk.HBox(spacing=5)
            l1l1l11l11 = Gtk.Label()
            l1l1l11l11.set_markup(l1lll1l (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1l11l11.set_line_wrap(True)
            l1l1l11l11.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1lll1l (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1ll1l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll1l1.show()
            l1ll1ll1ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll1ll.show()
            l1l1l11ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11ll1.show()
            l1ll1ll11l.pack_start(separator, True, True, 0)
            l1ll1ll11l.pack_start(l1ll1ll1l1, True, True, 0)
            l1ll1ll11l.pack_start(l1ll1ll1ll, True, True, 0)
            l1ll1ll11l.pack_start(l1l1l11ll1, True, True, 0)
            l1ll1ll11l.pack_start(l1l1l11l11, False, True, 0)
            l1l1l11l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11l1l.show()
            l1ll1ll11l.pack_end(l1l1l11l1l, True, True, 0)
            l1ll1111ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1111ll.show()
            vbox.pack_start(l1ll1ll11l, True, True, 0)
            l1ll11ll1l=self.__1l1llllll(l11ll111=l1l1ll1111)
            vbox.pack_start(l1ll11ll1l, False, False, 0)
            vbox.pack_end(l1ll1111ll, False, False, 0)
            l1l11ll1l1.pack_start(vbox, True, True,5)
            l1l11ll1l1.show()
            l1l1l1l111.pack_end(l1l11ll1l1, False, False, 0)
            vbox.show()
            l1ll1ll11l.show()
        window.run()
class l1lll11l1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll11ll11(self, widget, l1l1lllll1):
        if l1l1lllll1 == Gtk.ResponseType.OK:
            self.result = l1lll1l (u"ࠥࡓࡐࠨ৩")
        elif l1l1lllll1 == Gtk.ResponseType.CANCEL:
            self.result = l1lll1l (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1lllll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1lll1l (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11l11111(self, title=l1lll1l (u"ࠨࠢ৬"), message=l1lll1l (u"ࠢࠣ৭") , l1l11ll1l=True):
        if l1l11ll1l:
            l1l11l1l11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1l11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1lll1l (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1ll11ll11)
        window.run()
class l1l11ll11l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1l11l=None
        self.result = None
    def l1ll11ll11(self, widget, l1l1lllll1):
        print(widget, l1l1lllll1)
        if l1l1lllll1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1lllll1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1lllll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1l1111(self, widget, l1l1l111ll):
        if l1l1l111ll.get_active():
            self.l1l1l1l11l = 1
        else:
            self.l1l1l1l11l = 0
    def l1l1llll11(self, title=l1lll1l (u"ࠤࠥ৯"), message=l1lll1l (u"ࠥࠦৰ"), l1l1ll1lll =l1lll1l (u"ࠦࠧৱ"),l1l11ll1l=True):
        if l1l11ll1l:
            l1l11l1l11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1l11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1l11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1lll1l (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1ll11ll11)
        l1l1ll1l11 = Gtk.CheckButton(l1l1ll1lll)
        l1l1ll1l11.connect(l1lll1l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll1l1111, l1l1ll1l11)
        l1l1ll1l11.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll1l11, expand=True, fill=True, padding=0)
        l1l1ll1l11.show()
        window.run()
def l1l111l11(title, msg, l1l1ll1lll=l1lll1l (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1l11ll1l=True):
    result=None
    try:
        l1l11l1l1l = l1l11ll11l()
        l1l11l1l1l.l1l1llll11(title, msg, l1l1ll1lll, l1l11ll1l)
        result = {l1lll1l (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l11l1l1l.result,  l1lll1l (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l11l1l1l.l1l1l1l11l}
    except Exception as e:
        logger.exception(l1lll1l (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1lll1l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11lll1l1 = l1ll1l111()
    message= l1lll1l (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll111l11 = l1lll1l (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11lll1l1.l111l11l1(message, l1lll1l (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1l11ll1l=True, l1l1ll1111=l1ll111l11)