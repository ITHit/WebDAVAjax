#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l1 = sys.version_info [0] == 2
l11 = 2048
l1ll11ll = 7
def l1lll1ll (l1lll111):
    global l1l1ll1
    l1l11 = ord (l1lll111 [-1])
    l1llll11 = l1lll111 [:-1]
    l1l1 = l1l11 % len (l1llll11)
    l1l1111 = l1llll11 [:l1l1] + l1llll11 [l1l1:]
    if l1ll11l1:
        l1111ll = l111l1 () .join ([unichr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    return eval (l1111ll)
import logging
import os
import re
from l1lll import l11111ll
logger = logging.getLogger(l1lll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1ll1l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1ll (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l():
    try:
        out = os.popen(l1lll1ll (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1lll1ll (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1lll1ll (u"ࠢࠣॶ").join(result)
                logger.info(l1lll1ll (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1lll1ll (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1lll1ll (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1lll1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l11111ll(l1lll1ll (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1lll1ll (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1ll1l1(l1lll1ll (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))