#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import logging
logger = logging.getLogger(l1llll1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1llllll import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1l11(object):
    def __init__(self, l111ll11=None):
        self.l11l1lll = 0x019db1ded53e8000
        self.l111ll11 = l111ll11
    def run(self):
        if self.l111ll11:
            l11l11ll = self.l111l1ll()
        else:
            logger.error(l1llll1 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l11l1(l1llll1 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l11ll
    def l111lll1(self, host, path, secure, expires, name, value, l11l1ll1=None, l111llll=None, session=None):
        __doc__ = l1llll1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1llll1 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1llll1 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1llll1 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l1ll1, l1llll1 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l111llll, l1llll1 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l11l111l(self, l111l11l):
        if l111l11l < self.l11l1lll:
            raise ValueError(l1llll1 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l111l11l, self.l11l1lll))
        return divmod((l111l11l - self.l11l1lll), 10000000)[0]
    def _111l111(self, l111l1l1):
        l1llll1 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111l1l1:
            l11ll111 = l111l1l1 - self.l11l1lll
            res = l11ll111 / 1000000
        return res
    def _1111lll(self, string, initial):
        res = l1llll1 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l1ll(self):
        l11l11ll = http.cookiejar.CookieJar()
        if self.l111ll11:
            for l11l1l1l in self.l111ll11:
                l11l11ll.set_cookie(self.l111ll1l(l11l1l1l))
        return l11l11ll
    def l111ll1l(self, l11l1111):
        now = int(time.time())
        flags = l11l1111[l1llll1 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1ll1 = ((flags & (1 << 2)) != 0)
        l111llll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1llll1 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1111:
            l111l11l = l11l1111[l1llll1 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l11l1lll
            expires = self.l11l111l(l111l11l)
        else:
            expires = None
        domain = l11l1111[l1llll1 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1111[l1llll1 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l111lll1(domain, path, secure, expires, l11l1111[l1llll1 (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1111[l1llll1 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l1ll1,
                               l111llll, session)
        return c