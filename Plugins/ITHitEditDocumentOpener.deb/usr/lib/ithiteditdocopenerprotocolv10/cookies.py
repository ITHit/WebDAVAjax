#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1llll11 = 2048
l11l11 = 7
def l1lllll (l1lll):
    global l1ll1ll1
    l1ll1lll = ord (l1lll [-1])
    l111l11 = l1lll [:-1]
    l1ll11l = l1ll1lll % len (l111l11)
    l1111 = l111l11 [:l1ll11l] + l111l11 [l1ll11l:]
    if l1ll1:
        l111lll = l1l1ll1 () .join ([unichr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    else:
        l111lll = str () .join ([chr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    return eval (l111lll)
import logging
logger = logging.getLogger(l1lllll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l11l import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1111(object):
    def __init__(self, l11l11l1=None):
        self.l1111ll1 = 0x019db1ded53e8000
        self.l11l11l1 = l11l11l1
    def run(self):
        if self.l11l11l1:
            l1111l1l = self.l111llll()
        else:
            logger.error(l1lllll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l11l1l1l(l1lllll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l1111l1l
    def l111l11l(self, host, path, secure, expires, name, value, l111ll11=None, l111ll1l=None, session=None):
        __doc__ = l1lllll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lllll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1lllll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lllll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111ll11, l1lllll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111ll1l, l1lllll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l1l1(self, l111l111):
        if l111l111 < self.l1111ll1:
            raise ValueError(l1lllll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111l111, self.l1111ll1))
        return divmod((l111l111 - self.l1111ll1), 10000000)[0]
    def _11l111l(self, l11l1ll1):
        l1lllll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l1ll1:
            l1111lll = l11l1ll1 - self.l1111ll1
            res = l1111lll / 1000000
        return res
    def _11l11ll(self, string, initial):
        res = l1lllll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111llll(self):
        l1111l1l = http.cookiejar.CookieJar()
        if self.l11l11l1:
            for l111l1ll in self.l11l11l1:
                l1111l1l.set_cookie(self.l11l1l11(l111l1ll))
        return l1111l1l
    def l11l1l11(self, l111lll1):
        now = int(time.time())
        flags = l111lll1[l1lllll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111ll11 = ((flags & (1 << 2)) != 0)
        l111ll1l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lllll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111lll1:
            l111l111 = l111lll1[l1lllll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l1111ll1
            expires = self.l111l1l1(l111l111)
        else:
            expires = None
        domain = l111lll1[l1lllll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111lll1[l1lllll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l11l(domain, path, secure, expires, l111lll1[l1lllll (u"ࠣࡍࡈ࡝ࠧࢬ")], l111lll1[l1lllll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111ll11,
                               l111ll1l, session)
        return c