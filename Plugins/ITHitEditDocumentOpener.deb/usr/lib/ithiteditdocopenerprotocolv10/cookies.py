#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l1ll1l1 = 2048
l1lll1l1 = 7
def l1l1ll (l1ll1l1l):
    global l111l1
    l1l11l1 = ord (l1ll1l1l [-1])
    l1lll1l = l1ll1l1l [:-1]
    l1llll1 = l1l11l1 % len (l1lll1l)
    ll = l1lll1l [:l1llll1] + l1lll1l [l1llll1:]
    if l1l1111:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    return eval (l1111)
import logging
logger = logging.getLogger(l1l1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l11ll1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l11l(object):
    def __init__(self, l11l1lll=None):
        self.l111lll1 = 0x019db1ded53e8000
        self.l11l1lll = l11l1lll
    def run(self):
        if self.l11l1lll:
            l11l1ll1 = self.l11l11ll()
        else:
            logger.error(l1l1ll (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111llll(l1l1ll (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l1ll1
    def l111ll11(self, host, path, secure, expires, name, value, l11l1l11=None, l11l111l=None, session=None):
        __doc__ = l1l1ll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l1ll (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1l1ll (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l1ll (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l1l11, l1l1ll (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l111l, l1l1ll (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111ll1l(self, l11l1111):
        if l11l1111 < self.l111lll1:
            raise ValueError(l1l1ll (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l1111, self.l111lll1))
        return divmod((l11l1111 - self.l111lll1), 10000000)[0]
    def _111l111(self, l111l1l1):
        l1l1ll (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111l1l1:
            l11l11l1 = l111l1l1 - self.l111lll1
            res = l11l11l1 / 1000000
        return res
    def _111l1ll(self, string, initial):
        res = l1l1ll (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11ll(self):
        l11l1ll1 = http.cookiejar.CookieJar()
        if self.l11l1lll:
            for l11ll111 in self.l11l1lll:
                l11l1ll1.set_cookie(self.l1111lll(l11ll111))
        return l11l1ll1
    def l1111lll(self, l11l1l1l):
        now = int(time.time())
        flags = l11l1l1l[l1l1ll (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1l11 = ((flags & (1 << 2)) != 0)
        l11l111l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l1ll (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1l1l:
            l11l1111 = l11l1l1l[l1l1ll (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l111lll1
            expires = self.l111ll1l(l11l1111)
        else:
            expires = None
        domain = l11l1l1l[l1l1ll (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1l1l[l1l1ll (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l111ll11(domain, path, secure, expires, l11l1l1l[l1l1ll (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1l1l[l1l1ll (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l1l11,
                               l11l111l, session)
        return c