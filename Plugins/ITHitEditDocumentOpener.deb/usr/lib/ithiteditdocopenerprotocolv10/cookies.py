#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1ll = 7
def l1l111 (l11ll):
    global l1lll11l
    l1ll1l1l = ord (l11ll [-1])
    l111 = l11ll [:-1]
    l11 = l1ll1l1l % len (l111)
    l1ll1ll = l111 [:l11] + l111 [l11:]
    if l1llll:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    return eval (l1ll1l1)
import logging
logger = logging.getLogger(l1l111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11111 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1l11(object):
    def __init__(self, l11l1111=None):
        self.l111lll1 = 0x019db1ded53e8000
        self.l11l1111 = l11l1111
    def run(self):
        if self.l11l1111:
            l111llll = self.l111l111()
        else:
            logger.error(l1l111 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l11l1l1l(l1l111 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111llll
    def l111l1l1(self, host, path, secure, expires, name, value, l1111l1l=None, l11l11l1=None, session=None):
        __doc__ = l1l111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l111 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l111 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l111 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l1111l1l, l1l111 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l11l1, l1l111 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l1ll(self, l11l111l):
        if l11l111l < self.l111lll1:
            raise ValueError(l1l111 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l111l, self.l111lll1))
        return divmod((l11l111l - self.l111lll1), 10000000)[0]
    def _1111ll1(self, l1111lll):
        l1l111 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l1111lll:
            l11l1ll1 = l1111lll - self.l111lll1
            res = l11l1ll1 / 1000000
        return res
    def _111ll1l(self, string, initial):
        res = l1l111 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l111(self):
        l111llll = http.cookiejar.CookieJar()
        if self.l11l1111:
            for l11l11ll in self.l11l1111:
                l111llll.set_cookie(self.l111ll11(l11l11ll))
        return l111llll
    def l111ll11(self, l111l11l):
        now = int(time.time())
        flags = l111l11l[l1l111 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l1111l1l = ((flags & (1 << 2)) != 0)
        l11l11l1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l111 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111l11l:
            l11l111l = l111l11l[l1l111 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111lll1
            expires = self.l111l1ll(l11l111l)
        else:
            expires = None
        domain = l111l11l[l1l111 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111l11l[l1l111 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l1l1(domain, path, secure, expires, l111l11l[l1l111 (u"ࠣࡍࡈ࡝ࠧࢬ")], l111l11l[l1l111 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l1111l1l,
                               l11l11l1, session)
        return c