#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1l = 7
def l11 (l1ll11l1):
    global l1l1111
    l1lll = ord (l1ll11l1 [-1])
    l1llllll = l1ll11l1 [:-1]
    l1l11l = l1lll % len (l1llllll)
    l1111ll = l1llllll [:l1l11l] + l1llllll [l1l11l:]
    if l111l1l:
        l11l = l11l1l1 () .join ([unichr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    return eval (l11l)
import logging
logger = logging.getLogger(l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l1ll1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l1111lll(object):
    def __init__(self, l111l1l1=None):
        self.l11l1l11 = 0x019db1ded53e8000
        self.l111l1l1 = l111l1l1
    def run(self):
        if self.l111l1l1:
            l11l1l1l = self.l111l111()
        else:
            logger.error(l11 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111ll11(l11 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l1l1l
    def l111ll1l(self, host, path, secure, expires, name, value, l111l1ll=None, l111lll1=None, session=None):
        __doc__ = l11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l11 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111l1ll, l11 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111lll1, l11 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111llll(self, l11l111l):
        if l11l111l < self.l11l1l11:
            raise ValueError(l11 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l111l, self.l11l1l11))
        return divmod((l11l111l - self.l11l1l11), 10000000)[0]
    def _111l11l(self, l11l11l1):
        l11 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l11l1:
            l11l11ll = l11l11l1 - self.l11l1l11
            res = l11l11ll / 1000000
        return res
    def _11l1111(self, string, initial):
        res = l11 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l111(self):
        l11l1l1l = http.cookiejar.CookieJar()
        if self.l111l1l1:
            for l11l1ll1 in self.l111l1l1:
                l11l1l1l.set_cookie(self.l1111ll1(l11l1ll1))
        return l11l1l1l
    def l1111ll1(self, l1111l1l):
        now = int(time.time())
        flags = l1111l1l[l11 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l1ll = ((flags & (1 << 2)) != 0)
        l111lll1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l1111l1l:
            l11l111l = l1111l1l[l11 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1l11
            expires = self.l111llll(l11l111l)
        else:
            expires = None
        domain = l1111l1l[l11 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l1111l1l[l11 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111ll1l(domain, path, secure, expires, l1111l1l[l11 (u"ࠣࡍࡈ࡝ࠧࢬ")], l1111l1l[l11 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111l1ll,
                               l111lll1, session)
        return c