#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import logging
logger = logging.getLogger(l1lll1l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l111l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111lll1(object):
    def __init__(self, l111ll11=None):
        self.l11ll111 = 0x019db1ded53e8000
        self.l111ll11 = l111ll11
    def run(self):
        if self.l111ll11:
            l111l1ll = self.l11l11ll()
        else:
            logger.error(l1lll1l (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111l11l(l1lll1l (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l111l1ll
    def l11l1111(self, host, path, secure, expires, name, value, l1111lll=None, l11l111l=None, session=None):
        __doc__ = l1lll1l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lll1l (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1lll1l (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lll1l (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l1111lll, l1lll1l (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l111l, l1lll1l (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111l1l1(self, l111ll1l):
        if l111ll1l < self.l11ll111:
            raise ValueError(l1lll1l (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l111ll1l, self.l11ll111))
        return divmod((l111ll1l - self.l11ll111), 10000000)[0]
    def _11l1l11(self, l111l111):
        l1lll1l (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111l111:
            l11l11l1 = l111l111 - self.l11ll111
            res = l11l11l1 / 1000000
        return res
    def _11l1l1l(self, string, initial):
        res = l1lll1l (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11ll(self):
        l111l1ll = http.cookiejar.CookieJar()
        if self.l111ll11:
            for l111llll in self.l111ll11:
                l111l1ll.set_cookie(self.l11l1ll1(l111llll))
        return l111l1ll
    def l11l1ll1(self, l11l1lll):
        now = int(time.time())
        flags = l11l1lll[l1lll1l (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l1111lll = ((flags & (1 << 2)) != 0)
        l11l111l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lll1l (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1lll:
            l111ll1l = l11l1lll[l1lll1l (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l11ll111
            expires = self.l111l1l1(l111ll1l)
        else:
            expires = None
        domain = l11l1lll[l1lll1l (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1lll[l1lll1l (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11l1111(domain, path, secure, expires, l11l1lll[l1lll1l (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1lll[l1lll1l (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l1111lll,
                               l11l111l, session)
        return c