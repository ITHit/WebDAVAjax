#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import logging
logger = logging.getLogger(l1ll11l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l11l1l1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll11(object):
    def __init__(self, l111ll1l=None):
        self.l11l1l1l = 0x019db1ded53e8000
        self.l111ll1l = l111ll1l
    def run(self):
        if self.l111ll1l:
            l11l11ll = self.l11l1lll()
        else:
            logger.error(l1ll11l1 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111lll1(l1ll11l1 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l11ll
    def l11l1ll1(self, host, path, secure, expires, name, value, l11l1111=None, l1111lll=None, session=None):
        __doc__ = l1ll11l1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll11l1 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1ll11l1 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll11l1 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l1111, l1ll11l1 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l1111lll, l1ll11l1 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111l1l1(self, l11l11l1):
        if l11l11l1 < self.l11l1l1l:
            raise ValueError(l1ll11l1 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l11l1, self.l11l1l1l))
        return divmod((l11l11l1 - self.l11l1l1l), 10000000)[0]
    def _111l1ll(self, l11l1l11):
        l1ll11l1 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l11l1l11:
            l11ll111 = l11l1l11 - self.l11l1l1l
            res = l11ll111 / 1000000
        return res
    def _111l11l(self, string, initial):
        res = l1ll11l1 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1lll(self):
        l11l11ll = http.cookiejar.CookieJar()
        if self.l111ll1l:
            for l111llll in self.l111ll1l:
                l11l11ll.set_cookie(self.l111l111(l111llll))
        return l11l11ll
    def l111l111(self, l11l111l):
        now = int(time.time())
        flags = l11l111l[l1ll11l1 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1111 = ((flags & (1 << 2)) != 0)
        l1111lll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll11l1 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l111l:
            l11l11l1 = l11l111l[l1ll11l1 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l11l1l1l
            expires = self.l111l1l1(l11l11l1)
        else:
            expires = None
        domain = l11l111l[l1ll11l1 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l111l[l1ll11l1 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11l1ll1(domain, path, secure, expires, l11l111l[l1ll11l1 (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l111l[l1ll11l1 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l1111,
                               l1111lll, session)
        return c