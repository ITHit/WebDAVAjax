#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import logging
logger = logging.getLogger(l111lll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l1l11 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll11(object):
    def __init__(self, l111l11l=None):
        self.l111lll1 = 0x019db1ded53e8000
        self.l111l11l = l111l11l
    def run(self):
        if self.l111l11l:
            l11l11ll = self.l111l1ll()
        else:
            logger.error(l111lll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l1l1(l111lll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l11ll
    def l11l1l1l(self, host, path, secure, expires, name, value, l11l1l11=None, l1111lll=None, session=None):
        __doc__ = l111lll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l111lll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l111lll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l111lll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l1l11, l111lll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l1111lll, l111lll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111llll(self, l1111ll1):
        if l1111ll1 < self.l111lll1:
            raise ValueError(l111lll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l1111ll1, self.l111lll1))
        return divmod((l1111ll1 - self.l111lll1), 10000000)[0]
    def _11l11l1(self, l1111l1l):
        l111lll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l1111l1l:
            l111l111 = l1111l1l - self.l111lll1
            res = l111l111 / 1000000
        return res
    def _11l111l(self, string, initial):
        res = l111lll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l1ll(self):
        l11l11ll = http.cookiejar.CookieJar()
        if self.l111l11l:
            for l11l1ll1 in self.l111l11l:
                l11l11ll.set_cookie(self.l111ll1l(l11l1ll1))
        return l11l11ll
    def l111ll1l(self, l11l1111):
        now = int(time.time())
        flags = l11l1111[l111lll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1l11 = ((flags & (1 << 2)) != 0)
        l1111lll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l111lll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1111:
            l1111ll1 = l11l1111[l111lll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111lll1
            expires = self.l111llll(l1111ll1)
        else:
            expires = None
        domain = l11l1111[l111lll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1111[l111lll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l1l1l(domain, path, secure, expires, l11l1111[l111lll (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1111[l111lll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l1l11,
                               l1111lll, session)
        return c