#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l1 = sys.version_info [0] == 2
l1l1l11 = 2048
l1ll1l1l = 7
def l11ll1l (l1l11ll):
    global l1lll1l1
    l1l11 = ord (l1l11ll [-1])
    l1 = l1l11ll [:-1]
    l1ll111 = l1l11 % len (l1)
    ll = l1 [:l1ll111] + l1 [l1ll111:]
    if l11l1l1:
        l1l1l1 = l1lll11l () .join ([unichr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    return eval (l1l1l1)
import logging
logger = logging.getLogger(l11ll1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll11(object):
    def __init__(self, l11l1l11=None):
        self.l111llll = 0x019db1ded53e8000
        self.l11l1l11 = l11l1l11
    def run(self):
        if self.l11l1l11:
            l111l1l1 = self.l111ll1l()
        else:
            logger.error(l11ll1l (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111l1l(l11ll1l (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111l1l1
    def l11l1l1l(self, host, path, secure, expires, name, value, l111lll1=None, l111l1ll=None, session=None):
        __doc__ = l11ll1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11ll1l (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l11ll1l (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11ll1l (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111lll1, l11ll1l (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111l1ll, l11ll1l (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l11l11ll(self, l111l111):
        if l111l111 < self.l111llll:
            raise ValueError(l11ll1l (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111l111, self.l111llll))
        return divmod((l111l111 - self.l111llll), 10000000)[0]
    def _11l111l(self, l11l1111):
        l11ll1l (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l1111:
            l11l11l1 = l11l1111 - self.l111llll
            res = l11l11l1 / 1000000
        return res
    def _111l11l(self, string, initial):
        res = l11ll1l (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111ll1l(self):
        l111l1l1 = http.cookiejar.CookieJar()
        if self.l11l1l11:
            for l1111lll in self.l11l1l11:
                l111l1l1.set_cookie(self.l11l1ll1(l1111lll))
        return l111l1l1
    def l11l1ll1(self, l1111ll1):
        now = int(time.time())
        flags = l1111ll1[l11ll1l (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111lll1 = ((flags & (1 << 2)) != 0)
        l111l1ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11ll1l (u"ࠦࡍࡏࡘࡑࠤࢨ") in l1111ll1:
            l111l111 = l1111ll1[l11ll1l (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111llll
            expires = self.l11l11ll(l111l111)
        else:
            expires = None
        domain = l1111ll1[l11ll1l (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l1111ll1[l11ll1l (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l1l1l(domain, path, secure, expires, l1111ll1[l11ll1l (u"ࠣࡍࡈ࡝ࠧࢬ")], l1111ll1[l11ll1l (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111lll1,
                               l111l1ll, session)
        return c