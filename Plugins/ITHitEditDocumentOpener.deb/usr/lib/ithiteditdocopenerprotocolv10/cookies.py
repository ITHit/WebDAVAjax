#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l1 = sys.version_info [0] == 2
l11 = 2048
l1ll11ll = 7
def l1lll1ll (l1lll111):
    global l1l1ll1
    l1l11 = ord (l1lll111 [-1])
    l1llll11 = l1lll111 [:-1]
    l1l1 = l1l11 % len (l1llll11)
    l1l1111 = l1llll11 [:l1l1] + l1llll11 [l1l1:]
    if l1ll11l1:
        l1111ll = l111l1 () .join ([unichr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    return eval (l1111ll)
import logging
logger = logging.getLogger(l1lll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1lll import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l1l1(object):
    def __init__(self, l111lll1=None):
        self.l11l1l11 = 0x019db1ded53e8000
        self.l111lll1 = l111lll1
    def run(self):
        if self.l111lll1:
            l11l1lll = self.l11ll111()
        else:
            logger.error(l1lll1ll (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111ll11(l1lll1ll (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l1lll
    def l11l111l(self, host, path, secure, expires, name, value, l111l1ll=None, l11l11ll=None, session=None):
        __doc__ = l1lll1ll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lll1ll (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1lll1ll (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lll1ll (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l111l1ll, l1lll1ll (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l11ll, l1lll1ll (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l11l1ll1(self, l11l11l1):
        if l11l11l1 < self.l11l1l11:
            raise ValueError(l1lll1ll (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l11l1, self.l11l1l11))
        return divmod((l11l11l1 - self.l11l1l11), 10000000)[0]
    def _111l111(self, l111ll1l):
        l1lll1ll (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111ll1l:
            l111llll = l111ll1l - self.l11l1l11
            res = l111llll / 1000000
        return res
    def _111l11l(self, string, initial):
        res = l1lll1ll (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11ll111(self):
        l11l1lll = http.cookiejar.CookieJar()
        if self.l111lll1:
            for l11l1111 in self.l111lll1:
                l11l1lll.set_cookie(self.l1111lll(l11l1111))
        return l11l1lll
    def l1111lll(self, l11l1l1l):
        now = int(time.time())
        flags = l11l1l1l[l1lll1ll (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l1ll = ((flags & (1 << 2)) != 0)
        l11l11ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lll1ll (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1l1l:
            l11l11l1 = l11l1l1l[l1lll1ll (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l11l1l11
            expires = self.l11l1ll1(l11l11l1)
        else:
            expires = None
        domain = l11l1l1l[l1lll1ll (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1l1l[l1lll1ll (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11l111l(domain, path, secure, expires, l11l1l1l[l1lll1ll (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1l1l[l1lll1ll (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l111l1ll,
                               l11l11ll, session)
        return c