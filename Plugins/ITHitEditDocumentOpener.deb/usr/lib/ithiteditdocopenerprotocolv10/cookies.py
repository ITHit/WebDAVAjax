#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1l11l1 = 2048
l1l = 7
def l1l11l (l1lll1l1):
    global l1l111l
    l1ll11ll = ord (l1lll1l1 [-1])
    l111ll1 = l1lll1l1 [:-1]
    l111l1 = l1ll11ll % len (l111ll1)
    l111111 = l111ll1 [:l111l1] + l111ll1 [l111l1:]
    if l1l1lll:
        l1111ll = l11l11 () .join ([unichr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    return eval (l1111ll)
import logging
logger = logging.getLogger(l1l11l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1ll1l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l111l(object):
    def __init__(self, l111lll1=None):
        self.l111ll1l = 0x019db1ded53e8000
        self.l111lll1 = l111lll1
    def run(self):
        if self.l111lll1:
            l111ll11 = self.l111l1ll()
        else:
            logger.error(l1l11l (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l111(l1l11l (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111ll11
    def l11l1111(self, host, path, secure, expires, name, value, l1111ll1=None, l1111l1l=None, session=None):
        __doc__ = l1l11l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l11l (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l11l (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l11l (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l1111ll1, l1l11l (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l1111l1l, l1l11l (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111llll(self, l11l1l11):
        if l11l1l11 < self.l111ll1l:
            raise ValueError(l1l11l (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1l11, self.l111ll1l))
        return divmod((l11l1l11 - self.l111ll1l), 10000000)[0]
    def _11l1l1l(self, l11l11ll):
        l1l11l (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l11ll:
            l111l11l = l11l11ll - self.l111ll1l
            res = l111l11l / 1000000
        return res
    def _11l1ll1(self, string, initial):
        res = l1l11l (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l1ll(self):
        l111ll11 = http.cookiejar.CookieJar()
        if self.l111lll1:
            for l1111lll in self.l111lll1:
                l111ll11.set_cookie(self.l111l1l1(l1111lll))
        return l111ll11
    def l111l1l1(self, l11l11l1):
        now = int(time.time())
        flags = l11l11l1[l1l11l (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l1111ll1 = ((flags & (1 << 2)) != 0)
        l1111l1l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l11l (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l11l1:
            l11l1l11 = l11l11l1[l1l11l (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111ll1l
            expires = self.l111llll(l11l1l11)
        else:
            expires = None
        domain = l11l11l1[l1l11l (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l11l1[l1l11l (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l1111(domain, path, secure, expires, l11l11l1[l1l11l (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l11l1[l1l11l (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l1111ll1,
                               l1111l1l, session)
        return c