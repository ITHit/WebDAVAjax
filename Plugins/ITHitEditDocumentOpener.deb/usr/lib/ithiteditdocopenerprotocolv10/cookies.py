#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1lll111 = 2048
l1111 = 7
def l1ll (l11lll):
    global l1l1l1
    l1ll1l1 = ord (l11lll [-1])
    l1l1lll = l11lll [:-1]
    l1ll11l1 = l1ll1l1 % len (l1l1lll)
    l111 = l1l1lll [:l1ll11l1] + l1l1lll [l1ll11l1:]
    if l111ll1:
        l11llll = l1ll1l11 () .join ([unichr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    else:
        l11llll = str () .join ([chr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    return eval (l11llll)
import logging
logger = logging.getLogger(l1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l11l1l1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111lll1(object):
    def __init__(self, l111l1ll=None):
        self.l1111ll1 = 0x019db1ded53e8000
        self.l111l1ll = l111l1ll
    def run(self):
        if self.l111l1ll:
            l11l1l1l = self.l11l11ll()
        else:
            logger.error(l1ll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111llll(l1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l1l1l
    def l1111l1l(self, host, path, secure, expires, name, value, l1111lll=None, l11l1111=None, session=None):
        __doc__ = l1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1ll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l1111lll, l1ll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l1111, l1ll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111ll11(self, l111l1l1):
        if l111l1l1 < self.l1111ll1:
            raise ValueError(l1ll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111l1l1, self.l1111ll1))
        return divmod((l111l1l1 - self.l1111ll1), 10000000)[0]
    def _11l11l1(self, l11l1l11):
        l1ll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l1l11:
            l111l111 = l11l1l11 - self.l1111ll1
            res = l111l111 / 1000000
        return res
    def _111l11l(self, string, initial):
        res = l1ll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11ll(self):
        l11l1l1l = http.cookiejar.CookieJar()
        if self.l111l1ll:
            for l111ll1l in self.l111l1ll:
                l11l1l1l.set_cookie(self.l11l111l(l111ll1l))
        return l11l1l1l
    def l11l111l(self, l11l1ll1):
        now = int(time.time())
        flags = l11l1ll1[l1ll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l1111lll = ((flags & (1 << 2)) != 0)
        l11l1111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1ll1:
            l111l1l1 = l11l1ll1[l1ll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l1111ll1
            expires = self.l111ll11(l111l1l1)
        else:
            expires = None
        domain = l11l1ll1[l1ll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1ll1[l1ll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l1111l1l(domain, path, secure, expires, l11l1ll1[l1ll (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1ll1[l1ll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l1111lll,
                               l11l1111, session)
        return c