#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l11111 = 7
def l11 (l1l111l):
    global l1lll11
    l11l11 = ord (l1l111l [-1])
    l1l1ll1 = l1l111l [:-1]
    l1llll = l11l11 % len (l1l1ll1)
    l1lll1ll = l1l1ll1 [:l1llll] + l1l1ll1 [l1llll:]
    if l11l1l:
        l1l1l1 = l1ll1l1 () .join ([unichr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    return eval (l1l1l1)
import logging
logger = logging.getLogger(l11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1lll import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l1l1(object):
    def __init__(self, l11l1lll=None):
        self.l111llll = 0x019db1ded53e8000
        self.l11l1lll = l11l1lll
    def run(self):
        if self.l11l1lll:
            l1111lll = self.l11l1111()
        else:
            logger.error(l11 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111l11l(l11 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l1111lll
    def l11l1l11(self, host, path, secure, expires, name, value, l111lll1=None, l111l1ll=None, session=None):
        __doc__ = l11 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l11 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l111lll1, l11 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l111l1ll, l11 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l11l1l1l(self, l11l1ll1):
        if l11l1ll1 < self.l111llll:
            raise ValueError(l11 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l1ll1, self.l111llll))
        return divmod((l11l1ll1 - self.l111llll), 10000000)[0]
    def _111ll1l(self, l111l111):
        l11 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111l111:
            l11l11ll = l111l111 - self.l111llll
            res = l11l11ll / 1000000
        return res
    def _11l111l(self, string, initial):
        res = l11 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1111(self):
        l1111lll = http.cookiejar.CookieJar()
        if self.l11l1lll:
            for l11ll111 in self.l11l1lll:
                l1111lll.set_cookie(self.l11l11l1(l11ll111))
        return l1111lll
    def l11l11l1(self, l111ll11):
        now = int(time.time())
        flags = l111ll11[l11 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l111lll1 = ((flags & (1 << 2)) != 0)
        l111l1ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l111ll11:
            l11l1ll1 = l111ll11[l11 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l111llll
            expires = self.l11l1l1l(l11l1ll1)
        else:
            expires = None
        domain = l111ll11[l11 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l111ll11[l11 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11l1l11(domain, path, secure, expires, l111ll11[l11 (u"ࠨࡋࡆ࡛ࠥࢪ")], l111ll11[l11 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l111lll1,
                               l111l1ll, session)
        return c