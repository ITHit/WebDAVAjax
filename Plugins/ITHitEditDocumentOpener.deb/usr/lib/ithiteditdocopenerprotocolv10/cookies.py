#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1l111l = 7
def l1ll1l1l (l11ll1l):
    global l1l11
    l1 = ord (l11ll1l [-1])
    l1lll = l11ll1l [:-1]
    l1lllll = l1 % len (l1lll)
    l1lll11 = l1lll [:l1lllll] + l1lll [l1lllll:]
    if l1l1ll1:
        l1l11l = l111l11 () .join ([unichr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    return eval (l1l11l)
import logging
logger = logging.getLogger(l1ll1l1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1ll1lll import *
try:
    import json
except ImportError:
    import simplejson as json
class l111llll(object):
    def __init__(self, l111l1ll=None):
        self.l11l1l1l = 0x019db1ded53e8000
        self.l111l1ll = l111l1ll
    def run(self):
        if self.l111l1ll:
            l11l1111 = self.l11l1ll1()
        else:
            logger.error(l1ll1l1l (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111l1l(l1ll1l1l (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l1111
    def l111l11l(self, host, path, secure, expires, name, value, l111lll1=None, l1111ll1=None, session=None):
        __doc__ = l1ll1l1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll1l1l (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1ll1l1l (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll1l1l (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111lll1, l1ll1l1l (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l1111ll1, l1ll1l1l (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l1l1(self, l11l1l11):
        if l11l1l11 < self.l11l1l1l:
            raise ValueError(l1ll1l1l (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1l11, self.l11l1l1l))
        return divmod((l11l1l11 - self.l11l1l1l), 10000000)[0]
    def _11l111l(self, l1111lll):
        l1ll1l1l (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l1111lll:
            l111l111 = l1111lll - self.l11l1l1l
            res = l111l111 / 1000000
        return res
    def _111ll1l(self, string, initial):
        res = l1ll1l1l (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1ll1(self):
        l11l1111 = http.cookiejar.CookieJar()
        if self.l111l1ll:
            for l11l11l1 in self.l111l1ll:
                l11l1111.set_cookie(self.l111ll11(l11l11l1))
        return l11l1111
    def l111ll11(self, l11l11ll):
        now = int(time.time())
        flags = l11l11ll[l1ll1l1l (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111lll1 = ((flags & (1 << 2)) != 0)
        l1111ll1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll1l1l (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l11ll:
            l11l1l11 = l11l11ll[l1ll1l1l (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1l1l
            expires = self.l111l1l1(l11l1l11)
        else:
            expires = None
        domain = l11l11ll[l1ll1l1l (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l11ll[l1ll1l1l (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l11l(domain, path, secure, expires, l11l11ll[l1ll1l1l (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l11ll[l1ll1l1l (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111lll1,
                               l1111ll1, session)
        return c