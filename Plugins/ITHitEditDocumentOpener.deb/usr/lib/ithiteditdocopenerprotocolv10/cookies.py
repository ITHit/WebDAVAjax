#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1111 = 7
def l111l (l1lll1l1):
    global l111ll
    l1ll11ll = ord (l1lll1l1 [-1])
    l1lll11 = l1lll1l1 [:-1]
    l1 = l1ll11ll % len (l1lll11)
    l111l1l = l1lll11 [:l1] + l1lll11 [l1:]
    if l1111:
        l1l111 = l11ll1l () .join ([unichr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    return eval (l1l111)
import logging
logger = logging.getLogger(l111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1lllll1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1l11(object):
    def __init__(self, l1111ll1=None):
        self.l11l11l1 = 0x019db1ded53e8000
        self.l1111ll1 = l1111ll1
    def run(self):
        if self.l1111ll1:
            l111l1l1 = self.l11l1l1l()
        else:
            logger.error(l111l (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111ll1l(l111l (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l111l1l1
    def l111lll1(self, host, path, secure, expires, name, value, l111l1ll=None, l11l1111=None, session=None):
        __doc__ = l111l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l111l (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l111l (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l111l (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111l1ll, l111l (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l1111, l111l (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111llll(self, l11l111l):
        if l11l111l < self.l11l11l1:
            raise ValueError(l111l (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l111l, self.l11l11l1))
        return divmod((l11l111l - self.l11l11l1), 10000000)[0]
    def _111ll11(self, l111l11l):
        l111l (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111l11l:
            l11l1ll1 = l111l11l - self.l11l11l1
            res = l11l1ll1 / 1000000
        return res
    def _1111l1l(self, string, initial):
        res = l111l (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l1l(self):
        l111l1l1 = http.cookiejar.CookieJar()
        if self.l1111ll1:
            for l1111lll in self.l1111ll1:
                l111l1l1.set_cookie(self.l111l111(l1111lll))
        return l111l1l1
    def l111l111(self, l11l11ll):
        now = int(time.time())
        flags = l11l11ll[l111l (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l1ll = ((flags & (1 << 2)) != 0)
        l11l1111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l111l (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l11ll:
            l11l111l = l11l11ll[l111l (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l11l1
            expires = self.l111llll(l11l111l)
        else:
            expires = None
        domain = l11l11ll[l111l (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l11ll[l111l (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111lll1(domain, path, secure, expires, l11l11ll[l111l (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l11ll[l111l (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111l1ll,
                               l11l1111, session)
        return c