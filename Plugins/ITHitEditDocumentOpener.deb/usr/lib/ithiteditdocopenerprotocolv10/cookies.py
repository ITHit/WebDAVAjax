#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llllll = sys.version_info [0] == 2
l11ll1 = 2048
l1111ll = 7
def l1ll1l1 (l11ll11):
    global l1lll11
    l1lll111 = ord (l11ll11 [-1])
    l1ll11l1 = l11ll11 [:-1]
    l11l111 = l1lll111 % len (l1ll11l1)
    l1llll1 = l1ll11l1 [:l11l111] + l1ll11l1 [l11l111:]
    if l1llllll:
        l1lll1l = l1l1l1 () .join ([unichr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    else:
        l1lll1l = str () .join ([chr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    return eval (l1lll1l)
import logging
logger = logging.getLogger(l1ll1l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l11ll(object):
    def __init__(self, l111l1l1=None):
        self.l1111lll = 0x019db1ded53e8000
        self.l111l1l1 = l111l1l1
    def run(self):
        if self.l111l1l1:
            l11l1ll1 = self.l111l11l()
        else:
            logger.error(l1ll1l1 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l11l1(l1ll1l1 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l1ll1
    def l11ll111(self, host, path, secure, expires, name, value, l11l111l=None, l111l111=None, session=None):
        __doc__ = l1ll1l1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll1l1 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1ll1l1 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll1l1 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l111l, l1ll1l1 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l111l111, l1ll1l1 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111lll1(self, l111ll1l):
        if l111ll1l < self.l1111lll:
            raise ValueError(l1ll1l1 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l111ll1l, self.l1111lll))
        return divmod((l111ll1l - self.l1111lll), 10000000)[0]
    def _111l1ll(self, l111ll11):
        l1ll1l1 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111ll11:
            l11l1lll = l111ll11 - self.l1111lll
            res = l11l1lll / 1000000
        return res
    def _111llll(self, string, initial):
        res = l1ll1l1 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l11l(self):
        l11l1ll1 = http.cookiejar.CookieJar()
        if self.l111l1l1:
            for l11l1111 in self.l111l1l1:
                l11l1ll1.set_cookie(self.l11l1l1l(l11l1111))
        return l11l1ll1
    def l11l1l1l(self, l11l1l11):
        now = int(time.time())
        flags = l11l1l11[l1ll1l1 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l111l = ((flags & (1 << 2)) != 0)
        l111l111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll1l1 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1l11:
            l111ll1l = l11l1l11[l1ll1l1 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l1111lll
            expires = self.l111lll1(l111ll1l)
        else:
            expires = None
        domain = l11l1l11[l1ll1l1 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1l11[l1ll1l1 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11ll111(domain, path, secure, expires, l11l1l11[l1ll1l1 (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1l11[l1ll1l1 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l111l,
                               l111l111, session)
        return c