#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1ll = 7
def l11ll11 (l1lll11l):
    global l1ll
    l1l1ll1 = ord (l1lll11l [-1])
    l11l1l1 = l1lll11l [:-1]
    l111ll1 = l1l1ll1 % len (l11l1l1)
    l11lll = l11l1l1 [:l111ll1] + l11l1l1 [l111ll1:]
    if l1l1l:
        l1lll = l111111 () .join ([unichr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    return eval (l1lll)
import logging
logger = logging.getLogger(l11ll11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l1l1(object):
    def __init__(self, l11l1111=None):
        self.l111l1ll = 0x019db1ded53e8000
        self.l11l1111 = l11l1111
    def run(self):
        if self.l11l1111:
            l111llll = self.l11l1l1l()
        else:
            logger.error(l11ll11 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l1ll1(l11ll11 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l111llll
    def l111l111(self, host, path, secure, expires, name, value, l11l11ll=None, l11l111l=None, session=None):
        __doc__ = l11ll11 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11ll11 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l11ll11 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11ll11 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l11ll, l11ll11 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l111l, l11ll11 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l11l11l1(self, l11ll111):
        if l11ll111 < self.l111l1ll:
            raise ValueError(l11ll11 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11ll111, self.l111l1ll))
        return divmod((l11ll111 - self.l111l1ll), 10000000)[0]
    def _111l11l(self, l111ll1l):
        l11ll11 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111ll1l:
            l111ll11 = l111ll1l - self.l111l1ll
            res = l111ll11 / 1000000
        return res
    def _11l1l11(self, string, initial):
        res = l11ll11 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l1l(self):
        l111llll = http.cookiejar.CookieJar()
        if self.l11l1111:
            for l1111lll in self.l11l1111:
                l111llll.set_cookie(self.l11l1lll(l1111lll))
        return l111llll
    def l11l1lll(self, l111lll1):
        now = int(time.time())
        flags = l111lll1[l11ll11 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l11ll = ((flags & (1 << 2)) != 0)
        l11l111l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11ll11 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l111lll1:
            l11ll111 = l111lll1[l11ll11 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l111l1ll
            expires = self.l11l11l1(l11ll111)
        else:
            expires = None
        domain = l111lll1[l11ll11 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l111lll1[l11ll11 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l111l111(domain, path, secure, expires, l111lll1[l11ll11 (u"ࠨࡋࡆ࡛ࠥࢪ")], l111lll1[l11ll11 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l11ll,
                               l11l111l, session)
        return c