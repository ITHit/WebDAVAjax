#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import logging
logger = logging.getLogger(l1l11l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1l1111 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l11ll(object):
    def __init__(self, l111lll1=None):
        self.l111l11l = 0x019db1ded53e8000
        self.l111lll1 = l111lll1
    def run(self):
        if self.l111lll1:
            l11l1111 = self.l11l1l1l()
        else:
            logger.error(l1l11l (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l1lll(l1l11l (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l1111
    def l11ll111(self, host, path, secure, expires, name, value, l111llll=None, l11l1l11=None, session=None):
        __doc__ = l1l11l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l11l (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1l11l (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l11l (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l111llll, l1l11l (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l1l11, l1l11l (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l11l111l(self, l1111lll):
        if l1111lll < self.l111l11l:
            raise ValueError(l1l11l (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l1111lll, self.l111l11l))
        return divmod((l1111lll - self.l111l11l), 10000000)[0]
    def _111ll1l(self, l111l111):
        l1l11l (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111l111:
            l11l11l1 = l111l111 - self.l111l11l
            res = l11l11l1 / 1000000
        return res
    def _11l1ll1(self, string, initial):
        res = l1l11l (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l1l(self):
        l11l1111 = http.cookiejar.CookieJar()
        if self.l111lll1:
            for l111l1l1 in self.l111lll1:
                l11l1111.set_cookie(self.l111ll11(l111l1l1))
        return l11l1111
    def l111ll11(self, l111l1ll):
        now = int(time.time())
        flags = l111l1ll[l1l11l (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l111llll = ((flags & (1 << 2)) != 0)
        l11l1l11 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l11l (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l111l1ll:
            l1111lll = l111l1ll[l1l11l (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l111l11l
            expires = self.l11l111l(l1111lll)
        else:
            expires = None
        domain = l111l1ll[l1l11l (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l111l1ll[l1l11l (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11ll111(domain, path, secure, expires, l111l1ll[l1l11l (u"ࠨࡋࡆ࡛ࠥࢪ")], l111l1ll[l1l11l (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l111llll,
                               l11l1l11, session)
        return c