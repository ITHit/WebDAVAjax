#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l1 = sys.version_info [0] == 2
l111ll = 2048
l11111l = 7
def l1ll1ll (l11llll):
    global l1ll11l
    l111lll = ord (l11llll [-1])
    l1l1 = l11llll [:-1]
    l1llll1l = l111lll % len (l1l1)
    l1l1l1l = l1l1 [:l1llll1l] + l1l1 [l1llll1l:]
    if l1l11l1:
        l1ll1l1l = l1111ll () .join ([unichr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    else:
        l1ll1l1l = str () .join ([chr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    return eval (l1ll1l1l)
import logging
logger = logging.getLogger(l1ll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1ll11 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111lll1(object):
    def __init__(self, l11l1l1l=None):
        self.l11l111l = 0x019db1ded53e8000
        self.l11l1l1l = l11l1l1l
    def run(self):
        if self.l11l1l1l:
            l111ll11 = self.l111l11l()
        else:
            logger.error(l1ll1ll (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111ll1l(l1ll1ll (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l111ll11
    def l11ll111(self, host, path, secure, expires, name, value, l11l11ll=None, l111l1ll=None, session=None):
        __doc__ = l1ll1ll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll1ll (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1ll1ll (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll1ll (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l11ll, l1ll1ll (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l111l1ll, l1ll1ll (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l1111lll(self, l11l11l1):
        if l11l11l1 < self.l11l111l:
            raise ValueError(l1ll1ll (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l11l1, self.l11l111l))
        return divmod((l11l11l1 - self.l11l111l), 10000000)[0]
    def _111l111(self, l11l1ll1):
        l1ll1ll (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l11l1ll1:
            l111l1l1 = l11l1ll1 - self.l11l111l
            res = l111l1l1 / 1000000
        return res
    def _11l1lll(self, string, initial):
        res = l1ll1ll (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l11l(self):
        l111ll11 = http.cookiejar.CookieJar()
        if self.l11l1l1l:
            for l11l1l11 in self.l11l1l1l:
                l111ll11.set_cookie(self.l111llll(l11l1l11))
        return l111ll11
    def l111llll(self, l11l1111):
        now = int(time.time())
        flags = l11l1111[l1ll1ll (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l11ll = ((flags & (1 << 2)) != 0)
        l111l1ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll1ll (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1111:
            l11l11l1 = l11l1111[l1ll1ll (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l11l111l
            expires = self.l1111lll(l11l11l1)
        else:
            expires = None
        domain = l11l1111[l1ll1ll (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1111[l1ll1ll (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11ll111(domain, path, secure, expires, l11l1111[l1ll1ll (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1111[l1ll1ll (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l11ll,
                               l111l1ll, session)
        return c