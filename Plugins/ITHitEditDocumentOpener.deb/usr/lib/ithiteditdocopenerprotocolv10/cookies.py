#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l1l1ll1 (l11ll1):
    global l1llll1
    l1ll111 = ord (l11ll1 [-1])
    l1lll1 = l11ll1 [:-1]
    l1l1111 = l1ll111 % len (l1lll1)
    l1lll1l = l1lll1 [:l1l1111] + l1lll1 [l1l1111:]
    if l1:
        l111ll = l1ll1111 () .join ([unichr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    return eval (l111ll)
import logging
logger = logging.getLogger(l1l1ll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1111ll import *
try:
    import json
except ImportError:
    import simplejson as json
class l111lll1(object):
    def __init__(self, l11l111l=None):
        self.l11l1l1l = 0x019db1ded53e8000
        self.l11l111l = l11l111l
    def run(self):
        if self.l11l111l:
            l11l11ll = self.l1111lll()
        else:
            logger.error(l1l1ll1 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111ll11(l1l1ll1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l11ll
    def l111ll1l(self, host, path, secure, expires, name, value, l11l11l1=None, l111l1l1=None, session=None):
        __doc__ = l1l1ll1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l1ll1 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l1ll1 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l1ll1 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l11l1, l1l1ll1 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111l1l1, l1l1ll1 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l111(self, l11l1ll1):
        if l11l1ll1 < self.l11l1l1l:
            raise ValueError(l1l1ll1 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l1ll1, self.l11l1l1l))
        return divmod((l11l1ll1 - self.l11l1l1l), 10000000)[0]
    def _1111ll1(self, l111llll):
        l1l1ll1 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111llll:
            l1111l1l = l111llll - self.l11l1l1l
            res = l1111l1l / 1000000
        return res
    def _111l11l(self, string, initial):
        res = l1l1ll1 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l1111lll(self):
        l11l11ll = http.cookiejar.CookieJar()
        if self.l11l111l:
            for l11l1111 in self.l11l111l:
                l11l11ll.set_cookie(self.l111l1ll(l11l1111))
        return l11l11ll
    def l111l1ll(self, l11l1l11):
        now = int(time.time())
        flags = l11l1l11[l1l1ll1 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l11l1 = ((flags & (1 << 2)) != 0)
        l111l1l1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l1ll1 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l11:
            l11l1ll1 = l11l1l11[l1l1ll1 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1l1l
            expires = self.l111l111(l11l1ll1)
        else:
            expires = None
        domain = l11l1l11[l1l1ll1 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l11[l1l1ll1 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111ll1l(domain, path, secure, expires, l11l1l11[l1l1ll1 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l11[l1l1ll1 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l11l1,
                               l111l1l1, session)
        return c