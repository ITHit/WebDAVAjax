#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll1lll = 2048
l11ll1 = 7
def l1lll111 (l1111l1):
    global l1llll1l
    l1l1lll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l111ll1 = l1l1lll % len (l1l1l11)
    l1ll1 = l1l1l11 [:l111ll1] + l1l1l11 [l111ll1:]
    if l11l11:
        l11l1 = l1l11l1 () .join ([unichr (ord (char) - l1ll1lll - (l1l1111 + l1l1lll) % l11ll1) for l1l1111, char in enumerate (l1ll1)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1ll1lll - (l1l1111 + l1l1lll) % l11ll1) for l1l1111, char in enumerate (l1ll1)])
    return eval (l11l1)
import logging
logger = logging.getLogger(l1lll111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1ll11l1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1l11(object):
    def __init__(self, l111ll1l=None):
        self.l11l111l = 0x019db1ded53e8000
        self.l111ll1l = l111ll1l
    def run(self):
        if self.l111ll1l:
            l1111ll1 = self.l11l11l1()
        else:
            logger.error(l1lll111 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l11l1l1l(l1lll111 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l1111ll1
    def l111l111(self, host, path, secure, expires, name, value, l11l1ll1=None, l111l1ll=None, session=None):
        __doc__ = l1lll111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lll111 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1lll111 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lll111 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l1ll1, l1lll111 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111l1ll, l1lll111 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l1111l1l(self, l111lll1):
        if l111lll1 < self.l11l111l:
            raise ValueError(l1lll111 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111lll1, self.l11l111l))
        return divmod((l111lll1 - self.l11l111l), 10000000)[0]
    def _11l11ll(self, l111l11l):
        l1lll111 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111l11l:
            l111l1l1 = l111l11l - self.l11l111l
            res = l111l1l1 / 1000000
        return res
    def _11l1111(self, string, initial):
        res = l1lll111 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11l1(self):
        l1111ll1 = http.cookiejar.CookieJar()
        if self.l111ll1l:
            for l1111lll in self.l111ll1l:
                l1111ll1.set_cookie(self.l111llll(l1111lll))
        return l1111ll1
    def l111llll(self, l111ll11):
        now = int(time.time())
        flags = l111ll11[l1lll111 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1ll1 = ((flags & (1 << 2)) != 0)
        l111l1ll = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lll111 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l111ll11:
            l111lll1 = l111ll11[l1lll111 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l111l
            expires = self.l1111l1l(l111lll1)
        else:
            expires = None
        domain = l111ll11[l1lll111 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l111ll11[l1lll111 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l111(domain, path, secure, expires, l111ll11[l1lll111 (u"ࠣࡍࡈ࡝ࠧࢬ")], l111ll11[l1lll111 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l1ll1,
                               l111l1ll, session)
        return c