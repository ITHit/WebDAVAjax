#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll1 = sys.version_info [0] == 2
l111111 = 2048
l111ll1 = 7
def l1lll1ll (l1ll1l1l):
    global l111lll
    l1ll11ll = ord (l1ll1l1l [-1])
    l1llll = l1ll1l1l [:-1]
    l111l = l1ll11ll % len (l1llll)
    l11l1l = l1llll [:l111l] + l1llll [l111l:]
    if l11lll1:
        l1l1ll1 = l111l1l () .join ([unichr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    else:
        l1l1ll1 = str () .join ([chr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    return eval (l1l1ll1)
import logging
logger = logging.getLogger(l1lll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1lll1 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l11l(object):
    def __init__(self, l111llll=None):
        self.l11l1111 = 0x019db1ded53e8000
        self.l111llll = l111llll
    def run(self):
        if self.l111llll:
            l1111ll1 = self.l11l1l11()
        else:
            logger.error(l1lll1ll (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l1111lll(l1lll1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l1111ll1
    def l111l1ll(self, host, path, secure, expires, name, value, l1111l1l=None, l11l1ll1=None, session=None):
        __doc__ = l1lll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1lll1ll (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1lll1ll (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1lll1ll (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l1111l1l, l1lll1ll (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l11l1ll1, l1lll1ll (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111ll1l(self, l111l111):
        if l111l111 < self.l11l1111:
            raise ValueError(l1lll1ll (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111l111, self.l11l1111))
        return divmod((l111l111 - self.l11l1111), 10000000)[0]
    def _11l11ll(self, l111l1l1):
        l1lll1ll (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111l1l1:
            l11l1l1l = l111l1l1 - self.l11l1111
            res = l11l1l1l / 1000000
        return res
    def _111lll1(self, string, initial):
        res = l1lll1ll (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l11(self):
        l1111ll1 = http.cookiejar.CookieJar()
        if self.l111llll:
            for l11l11l1 in self.l111llll:
                l1111ll1.set_cookie(self.l111ll11(l11l11l1))
        return l1111ll1
    def l111ll11(self, l11l111l):
        now = int(time.time())
        flags = l11l111l[l1lll1ll (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l1111l1l = ((flags & (1 << 2)) != 0)
        l11l1ll1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1lll1ll (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l111l:
            l111l111 = l11l111l[l1lll1ll (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l11l1111
            expires = self.l111ll1l(l111l111)
        else:
            expires = None
        domain = l11l111l[l1lll1ll (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l111l[l1lll1ll (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l1ll(domain, path, secure, expires, l11l111l[l1lll1ll (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l111l[l1lll1ll (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l1111l1l,
                               l11l1ll1, session)
        return c