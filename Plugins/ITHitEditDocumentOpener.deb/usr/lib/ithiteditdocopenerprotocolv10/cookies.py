#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import logging
logger = logging.getLogger(l11llll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1111l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111l1ll(object):
    def __init__(self, l11l1lll=None):
        self.l11l1l1l = 0x019db1ded53e8000
        self.l11l1lll = l11l1lll
    def run(self):
        if self.l11l1lll:
            l11l1ll1 = self.l11l11ll()
        else:
            logger.error(l11llll (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l111l111(l11llll (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11l1ll1
    def l111llll(self, host, path, secure, expires, name, value, l11l11l1=None, l111l1l1=None, session=None):
        __doc__ = l11llll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11llll (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l11llll (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11llll (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l11l1, l11llll (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l111l1l1, l11llll (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l1111lll(self, l11l111l):
        if l11l111l < self.l11l1l1l:
            raise ValueError(l11llll (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l111l, self.l11l1l1l))
        return divmod((l11l111l - self.l11l1l1l), 10000000)[0]
    def _11l1l11(self, l111ll11):
        l11llll (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111ll11:
            l111l11l = l111ll11 - self.l11l1l1l
            res = l111l11l / 1000000
        return res
    def _11l1111(self, string, initial):
        res = l11llll (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l11ll(self):
        l11l1ll1 = http.cookiejar.CookieJar()
        if self.l11l1lll:
            for l111ll1l in self.l11l1lll:
                l11l1ll1.set_cookie(self.l111lll1(l111ll1l))
        return l11l1ll1
    def l111lll1(self, l11ll111):
        now = int(time.time())
        flags = l11ll111[l11llll (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l11l1 = ((flags & (1 << 2)) != 0)
        l111l1l1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11llll (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11ll111:
            l11l111l = l11ll111[l11llll (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l11l1l1l
            expires = self.l1111lll(l11l111l)
        else:
            expires = None
        domain = l11ll111[l11llll (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11ll111[l11llll (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l111llll(domain, path, secure, expires, l11ll111[l11llll (u"ࠨࡋࡆ࡛ࠥࢪ")], l11ll111[l11llll (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l11l1,
                               l111l1l1, session)
        return c