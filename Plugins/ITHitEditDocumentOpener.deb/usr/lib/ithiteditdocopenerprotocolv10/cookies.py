#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l11l1 (l1llll11):
    global l11l11l
    l1l1l1l = ord (l1llll11 [-1])
    l1llll1l = l1llll11 [:-1]
    l111ll = l1l1l1l % len (l1llll1l)
    l1l11 = l1llll1l [:l111ll] + l1llll1l [l111ll:]
    if l1l11l:
        l11ll1l = l1111 () .join ([unichr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    return eval (l11ll1l)
import logging
logger = logging.getLogger(l11l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l11ll11 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l111l(object):
    def __init__(self, l111l11l=None):
        self.l1111lll = 0x019db1ded53e8000
        self.l111l11l = l111l11l
    def run(self):
        if self.l111l11l:
            l11ll111 = self.l111ll11()
        else:
            logger.error(l11l1 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l1l1l(l11l1 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l11ll111
    def l11l1lll(self, host, path, secure, expires, name, value, l11l1111=None, l11l1l11=None, session=None):
        __doc__ = l11l1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11l1 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l11l1 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11l1 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l1111, l11l1 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l1l11, l11l1 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111ll1l(self, l111l111):
        if l111l111 < self.l1111lll:
            raise ValueError(l11l1 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l111l111, self.l1111lll))
        return divmod((l111l111 - self.l1111lll), 10000000)[0]
    def _11l11ll(self, l111l1l1):
        l11l1 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l111l1l1:
            l11l11l1 = l111l1l1 - self.l1111lll
            res = l11l11l1 / 1000000
        return res
    def _111lll1(self, string, initial):
        res = l11l1 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111ll11(self):
        l11ll111 = http.cookiejar.CookieJar()
        if self.l111l11l:
            for l111l1ll in self.l111l11l:
                l11ll111.set_cookie(self.l11l1ll1(l111l1ll))
        return l11ll111
    def l11l1ll1(self, l111llll):
        now = int(time.time())
        flags = l111llll[l11l1 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1111 = ((flags & (1 << 2)) != 0)
        l11l1l11 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11l1 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l111llll:
            l111l111 = l111llll[l11l1 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l1111lll
            expires = self.l111ll1l(l111l111)
        else:
            expires = None
        domain = l111llll[l11l1 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l111llll[l11l1 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11l1lll(domain, path, secure, expires, l111llll[l11l1 (u"ࠨࡋࡆ࡛ࠥࢪ")], l111llll[l11l1 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l1111,
                               l11l1l11, session)
        return c