#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l1 = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1l1l = 7
def l1ll1 (l11l1l1):
    global l1lll11
    l111l11 = ord (l11l1l1 [-1])
    l1111l1 = l11l1l1 [:-1]
    l1l1ll = l111l11 % len (l1111l1)
    l1l1l1 = l1111l1 [:l1l1ll] + l1111l1 [l1l1ll:]
    if l1lll1l1:
        l1111l = l11ll11 () .join ([unichr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    return eval (l1111l)
import logging
logger = logging.getLogger(l1ll1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l1ll1lll import *
try:
    import json
except ImportError:
    import simplejson as json
class l111lll1(object):
    def __init__(self, l11l11ll=None):
        self.l111llll = 0x019db1ded53e8000
        self.l11l11ll = l11l11ll
    def run(self):
        if self.l11l11ll:
            l111ll1l = self.l111l1l1()
        else:
            logger.error(l1ll1 (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l1ll1(l1ll1 (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l111ll1l
    def l11ll111(self, host, path, secure, expires, name, value, l111l111=None, l11l11l1=None, session=None):
        __doc__ = l1ll1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1ll1 (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1ll1 (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1ll1 (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l111l111, l1ll1 (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l11l1, l1ll1 (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111l11l(self, l11l111l):
        if l11l111l < self.l111llll:
            raise ValueError(l1ll1 (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l111l, self.l111llll))
        return divmod((l11l111l - self.l111llll), 10000000)[0]
    def _11l1lll(self, l11l1111):
        l1ll1 (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l11l1111:
            l1111lll = l11l1111 - self.l111llll
            res = l1111lll / 1000000
        return res
    def _111l1ll(self, string, initial):
        res = l1ll1 (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l1l1(self):
        l111ll1l = http.cookiejar.CookieJar()
        if self.l11l11ll:
            for l111ll11 in self.l11l11ll:
                l111ll1l.set_cookie(self.l11l1l1l(l111ll11))
        return l111ll1l
    def l11l1l1l(self, l11l1l11):
        now = int(time.time())
        flags = l11l1l11[l1ll1 (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l111l111 = ((flags & (1 << 2)) != 0)
        l11l11l1 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1ll1 (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l11l1l11:
            l11l111l = l11l1l11[l1ll1 (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l111llll
            expires = self.l111l11l(l11l111l)
        else:
            expires = None
        domain = l11l1l11[l1ll1 (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l11l1l11[l1ll1 (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l11ll111(domain, path, secure, expires, l11l1l11[l1ll1 (u"ࠨࡋࡆ࡛ࠥࢪ")], l11l1l11[l1ll1 (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l111l111,
                               l11l11l1, session)
        return c