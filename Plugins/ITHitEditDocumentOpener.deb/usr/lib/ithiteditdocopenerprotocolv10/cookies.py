#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l1l1lll = 2048
l11ll = 7
def l1l111 (l11l1l1):
    global l1llll
    l111ll = ord (l11l1l1 [-1])
    l1llll1l = l11l1l1 [:-1]
    l11l1 = l111ll % len (l1llll1l)
    l1l111l = l1llll1l [:l11l1] + l1llll1l [l11l1:]
    if l1llll1:
        l1l = l1ll1111 () .join ([unichr (ord (char) - l1l1lll - (l1llllll + l111ll) % l11ll) for l1llllll, char in enumerate (l1l111l)])
    else:
        l1l = str () .join ([chr (ord (char) - l1l1lll - (l1llllll + l111ll) % l11ll) for l1llllll, char in enumerate (l1l111l)])
    return eval (l1l)
import logging
logger = logging.getLogger(l1l111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1ll111 import *
try:
    import json
except ImportError:
    import simplejson as json
class l11l1111(object):
    def __init__(self, l1111ll1=None):
        self.l111l111 = 0x019db1ded53e8000
        self.l1111ll1 = l1111ll1
    def run(self):
        if self.l1111ll1:
            l11l1l11 = self.l111l11l()
        else:
            logger.error(l1l111 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l11l1ll1(l1l111 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l1l11
    def l11l11l1(self, host, path, secure, expires, name, value, l11l111l=None, l111ll1l=None, session=None):
        __doc__ = l1l111 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l111 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1l111 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l111 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l11l111l, l1l111 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111ll1l, l1l111 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111llll(self, l111ll11):
        if l111ll11 < self.l111l111:
            raise ValueError(l1l111 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111ll11, self.l111l111))
        return divmod((l111ll11 - self.l111l111), 10000000)[0]
    def _111lll1(self, l111l1ll):
        l1l111 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111l1ll:
            l111l1l1 = l111l1ll - self.l111l111
            res = l111l1l1 / 1000000
        return res
    def _1111lll(self, string, initial):
        res = l1l111 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l11l(self):
        l11l1l11 = http.cookiejar.CookieJar()
        if self.l1111ll1:
            for l11l11ll in self.l1111ll1:
                l11l1l11.set_cookie(self.l1111l1l(l11l11ll))
        return l11l1l11
    def l1111l1l(self, l11l1l1l):
        now = int(time.time())
        flags = l11l1l1l[l1l111 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l111l = ((flags & (1 << 2)) != 0)
        l111ll1l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l111 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l1l:
            l111ll11 = l11l1l1l[l1l111 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111l111
            expires = self.l111llll(l111ll11)
        else:
            expires = None
        domain = l11l1l1l[l1l111 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l1l[l1l111 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l11l1(domain, path, secure, expires, l11l1l1l[l1l111 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l1l[l1l111 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l11l111l,
                               l111ll1l, session)
        return c