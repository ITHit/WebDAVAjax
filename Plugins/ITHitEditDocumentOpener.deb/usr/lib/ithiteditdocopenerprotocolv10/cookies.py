#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l = sys.version_info [0] == 2
ll = 2048
l1 = 7
def l1111l1 (l1ll1lll):
    global l1ll1l1
    l1111 = ord (l1ll1lll [-1])
    l1l1lll = l1ll1lll [:-1]
    l11l1 = l1111 % len (l1l1lll)
    l1l1111 = l1l1lll [:l11l1] + l1l1lll [l11l1:]
    if l1lll1l:
        l1ll1ll1 = l1l1l () .join ([unichr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    else:
        l1ll1ll1 = str () .join ([chr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    return eval (l1ll1ll1)
import logging
logger = logging.getLogger(l1111l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1lll11 import *
try:
    import json
except ImportError:
    import simplejson as json
class l111lll1(object):
    def __init__(self, l111l1l1=None):
        self.l111l11l = 0x019db1ded53e8000
        self.l111l1l1 = l111l1l1
    def run(self):
        if self.l111l1l1:
            l11l111l = self.l11l1l11()
        else:
            logger.error(l1111l1 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l111(l1111l1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l111l
    def l11l1ll1(self, host, path, secure, expires, name, value, l111ll1l=None, l1111l1l=None, session=None):
        __doc__ = l1111l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1111l1 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l1111l1 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1111l1 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111ll1l, l1111l1 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l1111l1l, l1111l1 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l1111ll1(self, l11l11l1):
        if l11l11l1 < self.l111l11l:
            raise ValueError(l1111l1 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l11l11l1, self.l111l11l))
        return divmod((l11l11l1 - self.l111l11l), 10000000)[0]
    def _11l11ll(self, l111ll11):
        l1111l1 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l111ll11:
            l11l1l1l = l111ll11 - self.l111l11l
            res = l11l1l1l / 1000000
        return res
    def _111l1ll(self, string, initial):
        res = l1111l1 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1l11(self):
        l11l111l = http.cookiejar.CookieJar()
        if self.l111l1l1:
            for l111llll in self.l111l1l1:
                l11l111l.set_cookie(self.l11l1111(l111llll))
        return l11l111l
    def l11l1111(self, l1111lll):
        now = int(time.time())
        flags = l1111lll[l1111l1 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111ll1l = ((flags & (1 << 2)) != 0)
        l1111l1l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1111l1 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l1111lll:
            l11l11l1 = l1111lll[l1111l1 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111l11l
            expires = self.l1111ll1(l11l11l1)
        else:
            expires = None
        domain = l1111lll[l1111l1 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l1111lll[l1111l1 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l11l1ll1(domain, path, secure, expires, l1111lll[l1111l1 (u"ࠣࡍࡈ࡝ࠧࢬ")], l1111lll[l1111l1 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111ll1l,
                               l1111l1l, session)
        return c