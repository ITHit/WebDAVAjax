#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l11 = 7
def l1l111l (l11ll1):
    global l1l1l
    l11lll1 = ord (l11ll1 [-1])
    l111 = l11ll1 [:-1]
    l1l = l11lll1 % len (l111)
    l11lll = l111 [:l1l] + l111 [l1l:]
    if l1ll111:
        l1l11l1 = l11l11l () .join ([unichr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    return eval (l1l11l1)
import logging
logger = logging.getLogger(l1l111l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨ࢙"))
import time
import http.cookiejar
from l11l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l111ll1l(object):
    def __init__(self, l11l1l11=None):
        self.l111lll1 = 0x019db1ded53e8000
        self.l11l1l11 = l11l1l11
    def run(self):
        if self.l11l1l11:
            l111l11l = self.l111l1ll()
        else:
            logger.error(l1l111l (u"ࠦࡈࡧ࡮ࠨࡶࠣࡪ࡮ࡴࡤࠡࡥࡲࡳࡰ࡯ࡥࡴࠢ࡭ࡷࡴࡴࠬࠡࡲࡵࡳࡧࡧࡢ࡭ࡻࠣ࡭ࡹࠦࡷࡢࡵࠣࡲࡴࡺࠠࡱࡣࡶࡷࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮࢚ࠣ"))
            raise l11l11ll(l1l111l (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡷࡸࠦࡣࡰࡱ࡮࡭ࡪࡹࠬࠡࡥࡲࡳࡰ࡯ࡥࡴࠢࡰࡥࡾࠦࡢࡦࠢࡷࡳࡴࠦ࡬ࡰࡰࡪ࠲࢛ࠬ"))
        return l111l11l
    def l111l1l1(self, host, path, secure, expires, name, value, l11l1l1l=None, l11l1111=None, session=None):
        __doc__ = l1l111l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡣࡰࡱ࡮࡭ࡪࠦࡳࡵࡴࡸࡧࡹࡻࡲࡦࡦࠥ࢜")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l1l111l (u"ࠧ࠯ࠩ࢝")),
                               domain_initial_dot=host.startswith(l1l111l (u"ࠨ࠰ࠪ࢞")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l1l111l (u"ࠩࡋࡸࡹࡶࡏ࡯࡮ࡼࠫ࢟"): l11l1l1l, l1l111l (u"ࠪࡌࡴࡹࡴࡐࡰ࡯ࡽࠬࢠ"): l11l1111, l1l111l (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬࢡ"): session},
                               rfc2109=False
                               )
        return res
    def l111llll(self, l11l1lll):
        if l11l1lll < self.l111lll1:
            raise ValueError(l1l111l (u"ࠧ࡬ࡩ࡭ࡧࡷ࡭ࡲ࡫ࠠࠩࠧࡧ࠭ࠥ࡯ࡳࠡࡤࡨࡪࡴࡸࡥࠡࡧࡳࡳࡨ࡮ࠠࠩࠧࡧ࠭ࠧࢢ") %
                             (l11l1lll, self.l111lll1))
        return divmod((l11l1lll - self.l111lll1), 10000000)[0]
    def _11l11l1(self, l11ll111):
        l1l111l (u"࠭ࠧࠨࡅ࡫ࡶࡴࡳࡥࠡࡵࡷࡳࡷ࡫ࡳࠡ࡫ࡷࡷࠥࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡴࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡝ࡩ࡯ࡦࡲࡻࡸࠦࡇࡳࡧࡪࡳࡷ࡯ࡡ࡯ࠢࡨࡴࡴࡩࡨࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡦࡳࡳࡼࡥࡳࡶࠣ࡭ࡹࠦࡴࡰࠢࡸࡲ࡮ࡾࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪࠫࠬࢣ")
        res = 0
        if l11ll111:
            l11l111l = l11ll111 - self.l111lll1
            res = l11l111l / 1000000
        return res
    def _1111lll(self, string, initial):
        res = l1l111l (u"ࠢࠣࢤ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l111l1ll(self):
        l111l11l = http.cookiejar.CookieJar()
        if self.l11l1l11:
            for l111ll11 in self.l11l1l11:
                l111l11l.set_cookie(self.l11l1ll1(l111ll11))
        return l111l11l
    def l11l1ll1(self, l111l111):
        now = int(time.time())
        flags = l111l111[l1l111l (u"ࠣࡈࡏࡅࡌ࡙ࠢࢥ")]
        secure = ((flags & (1 << 1)) != 0)
        l11l1l1l = ((flags & (1 << 2)) != 0)
        l11l1111 = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l1l111l (u"ࠤࡋࡍ࡝ࡖࠢࢦ") in l111l111:
            l11l1lll = l111l111[l1l111l (u"ࠥࡌࡎ࡞ࡐࠣࢧ")] * 10000 + self.l111lll1
            expires = self.l111llll(l11l1lll)
        else:
            expires = None
        domain = l111l111[l1l111l (u"ࠦࡉࡕࡍࡂࡋࡑࠦࢨ")]
        path = l111l111[l1l111l (u"ࠧࡖࡁࡕࡊࠥࢩ")]
        c = self.l111l1l1(domain, path, secure, expires, l111l111[l1l111l (u"ࠨࡋࡆ࡛ࠥࢪ")], l111l111[l1l111l (u"ࠢࡗࡃࡏ࡙ࡊࠨࢫ")], l11l1l1l,
                               l11l1111, session)
        return c