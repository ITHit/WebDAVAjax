#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l = sys.version_info [0] == 2
l1llll11 = 2048
l1l11l = 7
def l11l1l1 (l1l111):
    global l1llllll
    l1lll = ord (l1l111 [-1])
    l1lll1l = l1l111 [:-1]
    l1ll1l1 = l1lll % len (l1lll1l)
    l11l11 = l1lll1l [:l1ll1l1] + l1lll1l [l1ll1l1:]
    if l1ll11l:
        l1l = l1111l () .join ([unichr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    return eval (l1l)
import logging
logger = logging.getLogger(l11l1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸ࠮ࡤࡱࡲ࡯࡮࡫ࡳ࢛ࠣ"))
import time
import http.cookiejar
from l1l1l1l import *
try:
    import json
except ImportError:
    import simplejson as json
class l1111ll1(object):
    def __init__(self, l11l11l1=None):
        self.l111ll11 = 0x019db1ded53e8000
        self.l11l11l1 = l11l11l1
    def run(self):
        if self.l11l11l1:
            l11l111l = self.l11l1111()
        else:
            logger.error(l11l1l1 (u"ࠨࡃࡢࡰࠪࡸࠥ࡬ࡩ࡯ࡦࠣࡧࡴࡵ࡫ࡪࡧࡶࠤ࡯ࡹ࡯࡯࠮ࠣࡴࡷࡵࡢࡢࡤ࡯ࡽࠥ࡯ࡴࠡࡹࡤࡷࠥࡴ࡯ࡵࠢࡳࡥࡸࡹࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡳࡹࡩࡰࡰࠥ࢜"))
            raise l111l111(l11l1l1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡹࡳࠡࡥࡲࡳࡰ࡯ࡥࡴ࠮ࠣࡧࡴࡵ࡫ࡪࡧࡶࠤࡲࡧࡹࠡࡤࡨࠤࡹࡵ࡯ࠡ࡮ࡲࡲ࡬࠴ࠧ࢝"))
        return l11l111l
    def l111l1ll(self, host, path, secure, expires, name, value, l111lll1=None, l111ll1l=None, session=None):
        __doc__ = l11l1l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡥࡲࡳࡰ࡯ࡥࠡࡵࡷࡶࡺࡩࡴࡶࡴࡨࡨࠧ࢞")
        res = http.cookiejar.Cookie(version=0,
                               name=name,
                               value=value,
                               port=None,
                               port_specified=False,
                               domain=host,
                               domain_specified=host.startswith(l11l1l1 (u"ࠩ࠱ࠫ࢟")),
                               domain_initial_dot=host.startswith(l11l1l1 (u"ࠪ࠲ࠬࢠ")),
                               path=path,
                               path_specified=True,
                               secure=secure,
                               expires=expires,
                               discard=False,
                               comment=None,
                               comment_url=None,
                               rest={l11l1l1 (u"ࠫࡍࡺࡴࡱࡑࡱࡰࡾ࠭ࢡ"): l111lll1, l11l1l1 (u"ࠬࡎ࡯ࡴࡶࡒࡲࡱࡿࠧࢢ"): l111ll1l, l11l1l1 (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧࢣ"): session},
                               rfc2109=False
                               )
        return res
    def l111l1l1(self, l111llll):
        if l111llll < self.l111ll11:
            raise ValueError(l11l1l1 (u"ࠢࡧ࡫࡯ࡩࡹ࡯࡭ࡦࠢࠫࠩࡩ࠯ࠠࡪࡵࠣࡦࡪ࡬࡯ࡳࡧࠣࡩࡵࡵࡣࡩࠢࠫࠩࡩ࠯ࠢࢤ") %
                             (l111llll, self.l111ll11))
        return divmod((l111llll - self.l111ll11), 10000000)[0]
    def _1111lll(self, l11l1ll1):
        l11l1l1 (u"ࠨࠩࠪࡇ࡭ࡸ࡯࡮ࡧࠣࡷࡹࡵࡲࡦࡵࠣ࡭ࡹࡹࠠࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡶࠤࡺࡹࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡘ࡫ࡱࡨࡴࡽࡳࠡࡉࡵࡩ࡬ࡵࡲࡪࡣࡱࠤࡪࡶ࡯ࡤࡪࠍࠤࠥࠦࠠࠡࠢࠣࠤࡹ࡮ࡩࡴࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡨࡵ࡮ࡷࡧࡵࡸࠥ࡯ࡴࠡࡶࡲࠤࡺࡴࡩࡹࠢࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࠭ࠧࢥ")
        res = 0
        if l11l1ll1:
            l11l1l1l = l11l1ll1 - self.l111ll11
            res = l11l1l1l / 1000000
        return res
    def _11l11ll(self, string, initial):
        res = l11l1l1 (u"ࠤࠥࢦ")
        if len(initial) > len(string):
            res = False
        else:
            res = string[:len(initial)] == initial
        return res
    def l11l1111(self):
        l11l111l = http.cookiejar.CookieJar()
        if self.l11l11l1:
            for l111l11l in self.l11l11l1:
                l11l111l.set_cookie(self.l1111l1l(l111l11l))
        return l11l111l
    def l1111l1l(self, l11l1l11):
        now = int(time.time())
        flags = l11l1l11[l11l1l1 (u"ࠥࡊࡑࡇࡇࡔࠤࢧ")]
        secure = ((flags & (1 << 1)) != 0)
        l111lll1 = ((flags & (1 << 2)) != 0)
        l111ll1l = ((flags & (1 << 3)) != 0)
        session = ((flags & (1 << 4)) != 0)
        if l11l1l1 (u"ࠦࡍࡏࡘࡑࠤࢨ") in l11l1l11:
            l111llll = l11l1l11[l11l1l1 (u"ࠧࡎࡉ࡙ࡒࠥࢩ")] * 10000 + self.l111ll11
            expires = self.l111l1l1(l111llll)
        else:
            expires = None
        domain = l11l1l11[l11l1l1 (u"ࠨࡄࡐࡏࡄࡍࡓࠨࢪ")]
        path = l11l1l11[l11l1l1 (u"ࠢࡑࡃࡗࡌࠧࢫ")]
        c = self.l111l1ll(domain, path, secure, expires, l11l1l11[l11l1l1 (u"ࠣࡍࡈ࡝ࠧࢬ")], l11l1l11[l11l1l1 (u"ࠤ࡙ࡅࡑ࡛ࡅࠣࢭ")], l111lll1,
                               l111ll1l, session)
        return c