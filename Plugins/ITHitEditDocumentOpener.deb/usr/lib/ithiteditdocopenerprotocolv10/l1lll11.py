#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1l = 2048
l1llll1l = 7
def l11l (l11ll1):
    global l1lll11l
    l1ll1 = ord (l11ll1 [-1])
    l11ll11 = l11ll1 [:-1]
    l11l111 = l1ll1 % len (l11ll11)
    l1l1l = l11ll11 [:l11l111] + l11ll11 [l11l111:]
    if l111ll1:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    return eval (l11l11l)
import logging
import os
import re
from l1ll11ll import l1111ll1
logger = logging.getLogger(l11l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1lllll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11l (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11lll1():
    try:
        out = os.popen(l11l (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l11l (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l11l (u"ࠢࠣॶ").join(result)
                logger.info(l11l (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l11l (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l11l (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l11l (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1111ll1(l11l (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l11l (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1lllll(l11l (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))