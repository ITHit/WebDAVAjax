#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l = sys.version_info [0] == 2
ll = 2048
l1 = 7
def l1111l1 (l1ll1lll):
    global l1ll1l1
    l1111 = ord (l1ll1lll [-1])
    l1l1lll = l1ll1lll [:-1]
    l11l1 = l1111 % len (l1l1lll)
    l1l1111 = l1l1lll [:l11l1] + l1l1lll [l11l1:]
    if l1lll1l:
        l1ll1ll1 = l1l1l () .join ([unichr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    else:
        l1ll1ll1 = str () .join ([chr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    return eval (l1ll1ll1)
import re
class l11111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llllll1 = kwargs.get(l1111l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11l = kwargs.get(l1111l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll1ll1 = self.l111111l(args)
        if l1lll1ll1:
            args=args+ l1lll1ll1
        self.args = [a for a in args]
    def l111111l(self, *args):
        l1lll1ll1=None
        l1l111ll = args[0][0]
        if re.search(l1111l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l111ll):
            l1lll1ll1 = (l1111l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1llllll1
                            ,)
        return l1lll1ll1
class l1lll1l11(Exception):
    def __init__(self, *args, **kwargs):
        l1lll1ll1 = self.l111111l(args)
        if l1lll1ll1:
            args = args + l1lll1ll1
        self.args = [a for a in args]
    def l111111l(self, *args):
        s = l1111l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1111l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll111(Exception):
    pass
class l1111l(Exception):
    pass
class l11111l1(Exception):
    def __init__(self, message, l1llll1ll, url):
        super(l11111l1,self).__init__(message)
        self.l1llll1ll = l1llll1ll
        self.url = url
class l1lllll1l(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l111l111(Exception):
    pass