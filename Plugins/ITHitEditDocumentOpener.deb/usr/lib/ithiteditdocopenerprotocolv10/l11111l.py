#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l1ll = 2048
l1l1 = 7
def l1lll1l (l1l111):
    global l1l111l
    l1lll1ll = ord (l1l111 [-1])
    l1lllll = l1l111 [:-1]
    l11111 = l1lll1ll % len (l1lllll)
    l1ll1l11 = l1lllll [:l11111] + l1lllll [l11111:]
    if l1ll1ll:
        l1ll11 = l1l1l () .join ([unichr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    return eval (l1ll11)
import logging
import os
import re
from l1ll1l1l import l1lll11ll
logger = logging.getLogger(l1lll1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11ll():
    try:
        out = os.popen(l1lll1l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll1l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll1l (u"ࠤࠥॸ").join(result)
                logger.info(l1lll1l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll1l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll1l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll1l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll11ll(l1lll1l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll1l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l(l1lll1l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))