#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l1l1ll = 7
def l1ll11 (l1l1ll1):
    global l1llll1
    l111 = ord (l1l1ll1 [-1])
    l1ll11l = l1l1ll1 [:-1]
    l11l11l = l111 % len (l1ll11l)
    l1llll = l1ll11l [:l11l11l] + l1ll11l [l11l11l:]
    if l111l1:
        l1111l1 = l11111l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    return eval (l1111l1)
import hashlib
import os
import l1l11
from l1111l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l11 import l1l1l
from l1ll1ll import l1ll1, l1ll1l1l
import logging
logger = logging.getLogger(l1ll11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1lll1l():
    def __init__(self, l1,l1111, l1l11l1= None, l1lllll=None):
        self.l111l1l=False
        self.l1111ll = self._11lll()
        self.l1111 = l1111
        self.l1l11l1 = l1l11l1
        self.l11l = l1
        if l1l11l1:
            self.l1l1l11 = True
        else:
            self.l1l1l11 = False
        self.l1lllll = l1lllll
    def _11lll(self):
        try:
            return l1l11.l1llll1l() is not None
        except:
            return False
    def open(self):
        l1ll11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1111ll:
            raise NotImplementedError(l1ll11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll111 = self.l11l
        if self.l1111.lower().startswith(self.l11l.lower()):
            l1lll1l1 = re.compile(re.escape(self.l11l), re.IGNORECASE)
            l1111 = l1lll1l1.sub(l1ll11 (u"ࠨࠩࠄ"), self.l1111)
            l1111 = l1111.replace(l1ll11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll(self.l11l, l1ll111, l1111, self.l1l11l1)
    def l11ll(self,l11l, l1ll111, l1111, l1l11l1):
        l1ll11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111l11 = l11111(l11l)
        l11ll11 = self.l1l111l(l111l11)
        logger.info(l1ll11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111l11)
        if l11ll11:
            logger.info(l1ll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1l(l111l11)
            l111l11 = l11(l11l, l1ll111, l1l11l1, self.l1lllll)
        logger.debug(l1ll11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l1ll=l111l11 + l1ll11 (u"ࠤ࠲ࠦࠌ") + l1111
        l1llll11 = l1ll11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l1ll+ l1ll11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1llll11)
        l111ll1 = os.system(l1llll11)
        if (l111ll1 != 0):
            raise IOError(l1ll11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l1ll, l111ll1))
    def l1l111l(self, l111l11):
        if os.path.exists(l111l11):
            if os.path.islink(l111l11):
                l111l11 = os.readlink(l111l11)
            if os.path.ismount(l111l11):
                return True
        return False
def l11111(l11l):
    l1lll = l11l.replace(l1ll11 (u"࠭࡜࡝ࠩࠐ"), l1ll11 (u"ࠧࡠࠩࠑ")).replace(l1ll11 (u"ࠨ࠱ࠪࠒ"), l1ll11 (u"ࠩࡢࠫࠓ"))
    l11lll1 = l1ll11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111l=os.environ[l1ll11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l111ll=os.path.join(l111l,l11lll1, l1lll)
    l1llllll=os.path.abspath(l111ll)
    return l1llllll
def l11l1(l1lll111):
    if not os.path.exists(l1lll111):
        os.makedirs(l1lll111)
def l1l(l11l, l1ll111, l11llll=None, password=None):
    l1ll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll111 = l11111(l11l)
    l11l1(l1lll111)
    if not l11llll:
        l11l111 = l11l1l()
        l1ll1l11 =l11l111.l1l1111(l1ll11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll111 + l1ll11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll111 + l1ll11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll1l11, str):
            l11llll, password = l1ll1l11
        else:
            raise l1ll1l1l()
        logger.info(l1ll11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll111))
    l11l1l1 = pwd.getpwuid( os.getuid())[0]
    l1lll1=os.environ[l1ll11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l1={l1ll11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l1l1, l1ll11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l, l1ll11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll111, l1ll11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll1, l1ll11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11llll, l1ll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l1, temp_file)
        if not os.path.exists(os.path.join(l1ll1l1, l1ll11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11l11=l1ll11 (u"ࠦࡵࡿࠢࠣ")
            key=l1ll11 (u"ࠧࠨࠤ")
        else:
            l11l11=l1ll11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1lll=l1ll11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11l11,temp_file.name)
        l1l111=[l1ll11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1l1, l1ll1lll)]
        p = subprocess.Popen(l1l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll111
    logger.debug(l1ll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llllll=os.path.abspath(l1lll111)
    logger.debug(l1ll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llllll)
    return l1llllll
def l11(l11l, l1ll111, l1l11l1, l1lllll):
    l1ll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll11(title):
        l1lllll1=30
        if len(title)>l1lllll1:
            l1l1lll=title.split(l1ll11 (u"ࠨ࠯ࠣ࠳"))
            l1l1l1l=l1ll11 (u"ࠧࠨ࠴")
            for block in l1l1lll:
                l1l1l1l+=block+l1ll11 (u"ࠣ࠱ࠥ࠵")
                if len(l1l1l1l) > l1lllll1:
                    l1l1l1l+=l1ll11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l1l1l
        return title
    l11llll = l1ll11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1ll11 (u"ࠦࠧ࠸")
    os.system(l1ll11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1ll = l11111(l11l)
    l1lll111 = l11111(hashlib.sha1(l11l.encode()).hexdigest()[:10])
    l11l1(l1lll111)
    logger.info(l1ll11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1lll111))
    if l1l11l1:
        l11ll1l = [l1ll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1ll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1ll11 (u"ࠤ࠰ࡸࠧ࠽"), l1ll11 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1ll11 (u"ࠫ࠲ࡵࠧ࠿"), l1ll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l11llll, l1l11l1),
                    urllib.parse.unquote(l1ll111), os.path.abspath(l1lll111)]
    else:
        l11llll, password = l111111(l1lll111, l1ll111, l1lllll)
        if l11llll.lower() != l1ll11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l11ll1l = [l1ll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll11 (u"ࠤ࠰ࡸࠧࡄ"), l1ll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll11 (u"ࠫ࠲ࡵࠧࡆ"), l1ll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l11llll,
                        urllib.parse.unquote(l1ll111), os.path.abspath(l1lll111)]
        else:
            raise l1ll1l1l()
    logger.info(l1ll11 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1ll11 (u"ࠢࠡࠤࡉ").join(l11ll1l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ll = l1ll11 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(ll.encode())
    if len(err) > 0:
        l1lll1ll = l1ll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1lll1ll)
        raise l1ll1(l1lll1ll, l11=l1l11.l1llll1l(), l1ll111=l1ll111)
    logger.info(l1ll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1ll11 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1lll111, l1ll))
    l1llllll=os.path.abspath(l1ll)
    return l1llllll
def l111111(l11l, l1ll111, l1lllll):
    l1l11ll = os.path.join(os.environ[l1ll11 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1ll11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1ll11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1l11ll)):
       os.makedirs(os.path.dirname(l1l11ll))
    l1ll1l = l1lllll.get_value(l1ll11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1ll11 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l11l111 = l11l1l(l11l, l1ll1l)
    l11llll, password = l11l111.l1l1111(l1ll11 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1ll111 + l1ll11 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1ll111 + l1ll11 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l11llll != l1ll11 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l11ll1(l11l, l11llll):
        l1ll11ll = l1ll11 (u"ࠢࠡࠤࡗ").join([l11l, l11llll, l1ll11 (u"ࠨࠤࠪࡘ") + password + l1ll11 (u"࡙ࠩࠥࠫ"), l1ll11 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1l11ll, l1ll11 (u"ࠫࡼ࠱࡛ࠧ")) as l1l1l1:
            l1l1l1.write(l1ll11ll)
        os.chmod(l1l11ll, 0o600)
    return l11llll, password
def l11ll1(l11l, l11llll):
    l1l11ll = l111lll = os.path.join(os.environ[l1ll11 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1ll11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1ll11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1l11ll):
        with open(l1l11ll, l1ll11 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1l11l = data[0].split(l1ll11 (u"ࠤࠣࠦࡠ"))
            if l11l == l1l11l[0] and l11llll == l1l11l[1]:
                return True
    return False