#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1ll = 7
def l11ll11 (l1lll11l):
    global l1ll
    l1l1ll1 = ord (l1lll11l [-1])
    l11l1l1 = l1lll11l [:-1]
    l111ll1 = l1l1ll1 % len (l11l1l1)
    l11lll = l11l1l1 [:l111ll1] + l11l1l1 [l111ll1:]
    if l1l1l:
        l1lll = l111111 () .join ([unichr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    return eval (l1lll)
import hashlib
import os
import l1llll1
from l1lll1l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1llll1 import l1l1111
from l1l import l1lllll1, l11111
import logging
logger = logging.getLogger(l11ll11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111l1():
    def __init__(self, l11l1,l111l1, l1lllll= None, l1ll1l=None):
        self.l1111l=False
        self.l1ll1 = self._1ll1ll()
        self.l111l1 = l111l1
        self.l1lllll = l1lllll
        self.l11ll1l = l11l1
        if l1lllll:
            self.l111l1l = True
        else:
            self.l111l1l = False
        self.l1ll1l = l1ll1l
    def _1ll1ll(self):
        try:
            return l1llll1.l1lll1ll() is not None
        except:
            return False
    def open(self):
        l11ll11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1:
            raise NotImplementedError(l11ll11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11ll11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11lll1 = self.l11ll1l
        if self.l111l1.lower().startswith(self.l11ll1l.lower()):
            l1l1l1l = re.compile(re.escape(self.l11ll1l), re.IGNORECASE)
            l111l1 = l1l1l1l.sub(l11ll11 (u"ࠨࠩࠄ"), self.l111l1)
            l111l1 = l111l1.replace(l11ll11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11ll11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll1(self.l11ll1l, l11lll1, l111l1, self.l1lllll)
    def l1lll1(self,l11ll1l, l11lll1, l111l1, l1lllll):
        l11ll11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11ll11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l111l = l1ll1l1(l11ll1l)
        l1l11l1 = self.l11l11(l1l111l)
        logger.info(l11ll11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l111l)
        if l1l11l1:
            logger.info(l11ll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1111(l1l111l)
            l1l111l = l11l(l11ll1l, l11lll1, l1lllll, self.l1ll1l)
        logger.debug(l11ll11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l111=l1l111l + l11ll11 (u"ࠤ࠲ࠦࠌ") + l111l1
        l1l11l = l11ll11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l111+ l11ll11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l11l)
        l11l11l = os.system(l1l11l)
        if (l11l11l != 0):
            raise IOError(l11ll11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l111, l11l11l))
    def l11l11(self, l1l111l):
        if os.path.exists(l1l111l):
            if os.path.islink(l1l111l):
                l1l111l = os.readlink(l1l111l)
            if os.path.ismount(l1l111l):
                return True
        return False
def l1ll1l1(l11ll1l):
    l111lll = l11ll1l.replace(l11ll11 (u"࠭࡜࡝ࠩࠐ"), l11ll11 (u"ࠧࡠࠩࠑ")).replace(l11ll11 (u"ࠨ࠱ࠪࠒ"), l11ll11 (u"ࠩࡢࠫࠓ"))
    l1llll1l = l11ll11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l11ll=os.environ[l11ll11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1lll=os.path.join(l1l11ll,l1llll1l, l111lll)
    l1l1ll=os.path.abspath(l1ll1lll)
    return l1l1ll
def l11(l11111l):
    if not os.path.exists(l11111l):
        os.makedirs(l11111l)
def l1llll11(l11ll1l, l11lll1, l1l1=None, password=None):
    l11ll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11111l = l1ll1l1(l11ll1l)
    l11(l11111l)
    if not l1l1:
        l11ll = l1l11()
        l111 =l11ll.l111l11(l11ll11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11lll1 + l11ll11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11lll1 + l11ll11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l111, str):
            l1l1, password = l111
        else:
            raise l11111()
        logger.info(l11ll11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11111l))
    l1lll111 = pwd.getpwuid( os.getuid())[0]
    l1ll111=os.environ[l11ll11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11l1={l11ll11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lll111, l11ll11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll1l, l11ll11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11111l, l11ll11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll111, l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1, l11ll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11l1, temp_file)
        if not os.path.exists(os.path.join(l1llll, l11ll11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll11=l11ll11 (u"ࠦࡵࡿࠢࠣ")
            key=l11ll11 (u"ࠧࠨࠤ")
        else:
            l1ll11=l11ll11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11ll11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1l=l11ll11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll11,temp_file.name)
        l11ll1=[l11ll11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11ll11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll, l1lll1l)]
        p = subprocess.Popen(l11ll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11ll11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11ll11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11ll11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11111l
    logger.debug(l11ll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11ll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11ll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11ll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1ll=os.path.abspath(l11111l)
    logger.debug(l11ll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1ll)
    return l1l1ll
def l11l(l11ll1l, l11lll1, l1lllll, l1ll1l):
    l11ll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1lll(title):
        l111ll=30
        if len(title)>l111ll:
            l1ll11ll=title.split(l11ll11 (u"ࠨ࠯ࠣ࠳"))
            l1lll11=l11ll11 (u"ࠧࠨ࠴")
            for block in l1ll11ll:
                l1lll11+=block+l11ll11 (u"ࠣ࠱ࠥ࠵")
                if len(l1lll11) > l111ll:
                    l1lll11+=l11ll11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll11
        return title
    l1l1 = l11ll11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l11ll11 (u"ࠦࠧ࠸")
    os.system(l11ll11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1llllll = l1ll1l1(l11ll1l)
    l11111l = l1ll1l1(hashlib.sha1(l11ll1l.encode()).hexdigest()[:10])
    l11(l11111l)
    logger.info(l11ll11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11111l))
    if l1lllll:
        ll = [l11ll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l11ll11 (u"ࠤ࠰ࡸࠧ࠽"), l11ll11 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l11ll11 (u"ࠫ࠲ࡵࠧ࠿"), l11ll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1l1, l1lllll),
                    urllib.parse.unquote(l11lll1), os.path.abspath(l11111l)]
    else:
        l1l1, password = l1l1l1(l11111l, l11lll1, l1ll1l)
        if l1l1.lower() != l11ll11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            ll = [l11ll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11ll11 (u"ࠤ࠰ࡸࠧࡄ"), l11ll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11ll11 (u"ࠫ࠲ࡵࠧࡆ"), l11ll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1l1,
                        urllib.parse.unquote(l11lll1), os.path.abspath(l11111l)]
        else:
            raise l11111()
    logger.info(l11ll11 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l11ll11 (u"ࠢࠡࠤࡉ").join(ll)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1111ll = l11ll11 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1111ll.encode())
    if len(err) > 0:
        l11l1l = l11ll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l11l1l)
        raise l1lllll1(l11l1l, l11l=l1llll1.l1lll1ll(), l11lll1=l11lll1)
    logger.info(l11ll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l11ll11 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11111l, l1llllll))
    l1l1ll=os.path.abspath(l1llllll)
    return l1l1ll
def l1l1l1(l11ll1l, l11lll1, l1ll1l):
    l11llll = os.path.join(os.environ[l11ll11 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l11ll11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l11ll11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l11llll)):
       os.makedirs(os.path.dirname(l11llll))
    l1111 = l1ll1l.get_value(l11ll11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l11ll11 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l11ll = l1l11(l11ll1l, l1111)
    l1l1, password = l11ll.l111l11(l11ll11 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11lll1 + l11ll11 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11lll1 + l11ll11 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1l1 != l11ll11 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l111l(l11ll1l, l1l1):
        l1ll1l11 = l11ll11 (u"ࠢࠡࠤࡗ").join([l11ll1l, l1l1, l11ll11 (u"ࠨࠤࠪࡘ") + password + l11ll11 (u"࡙ࠩࠥࠫ"), l11ll11 (u"ࠪࡠࡳ࡚࠭")])
        with open(l11llll, l11ll11 (u"ࠫࡼ࠱࡛ࠧ")) as l1:
            l1.write(l1ll1l11)
        os.chmod(l11llll, 0o600)
    return l1l1, password
def l111l(l11ll1l, l1l1):
    l11llll = l11l111 = os.path.join(os.environ[l11ll11 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l11ll11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l11ll11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l11llll):
        with open(l11llll, l11ll11 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1ll1l1l = data[0].split(l11ll11 (u"ࠤࠣࠦࡠ"))
            if l11ll1l == l1ll1l1l[0] and l1l1 == l1ll1l1l[1]:
                return True
    return False