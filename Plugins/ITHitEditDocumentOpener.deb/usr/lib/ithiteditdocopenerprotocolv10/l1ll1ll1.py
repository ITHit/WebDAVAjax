#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l1lll = 2048
l11l1l1 = 7
def l11ll11 (l1ll1lll):
    global l1llllll
    l111111 = ord (l1ll1lll [-1])
    l1lll11l = l1ll1lll [:-1]
    l11111l = l111111 % len (l1lll11l)
    l11l111 = l1lll11l [:l11111l] + l1lll11l [l11111l:]
    if l1lll111:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    return eval (l11l11l)
import re
class l1l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllll1l = kwargs.get(l11ll11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1llll1 = kwargs.get(l11ll11 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1111111 = self.l1lll1lll(args)
        if l1111111:
            args=args+ l1111111
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        l1111111=None
        l1l1ll1l = args[0][0]
        if re.search(l11ll11 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1ll1l):
            l1111111 = (l11ll11 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lllll1l
                            ,)
        return l1111111
class l1lll11ll(Exception):
    def __init__(self, *args, **kwargs):
        l1111111 = self.l1lll1lll(args)
        if l1111111:
            args = args + l1111111
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        s = l11ll11 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11ll11 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll11l(Exception):
    pass
class l1lll1(Exception):
    pass
class l1111l11(Exception):
    def __init__(self, message, l1lllllll, url):
        super(l1111l11,self).__init__(message)
        self.l1lllllll = l1lllllll
        self.url = url
class l11111l1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l111111l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l11l1111(Exception):
    pass