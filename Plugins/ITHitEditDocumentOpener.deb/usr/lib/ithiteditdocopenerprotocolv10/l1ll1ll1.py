#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l1 = sys.version_info [0] == 2
l111ll = 2048
l11111l = 7
def l1ll1ll (l11llll):
    global l1ll11l
    l111lll = ord (l11llll [-1])
    l1l1 = l11llll [:-1]
    l1llll1l = l111lll % len (l1l1)
    l1l1l1l = l1l1 [:l1llll1l] + l1l1 [l1llll1l:]
    if l1l11l1:
        l1ll1l1l = l1111ll () .join ([unichr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    else:
        l1ll1l1l = str () .join ([chr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    return eval (l1ll1l1l)
import hashlib
import os
import l1111l1
from l1l11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1111l1 import l1l1l11
from l1ll11 import l1llll, l11l1l1
import logging
logger = logging.getLogger(l1ll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1lll1():
    def __init__(self, l11ll1,l1ll111, l11111= None, l111l1=None):
        self.l11l11l=False
        self.l11l111 = self._1l111l()
        self.l1ll111 = l1ll111
        self.l11111 = l11111
        self.l11ll11 = l11ll1
        if l11111:
            self.l11l1 = True
        else:
            self.l11l1 = False
        self.l111l1 = l111l1
    def _1l111l(self):
        try:
            return l1111l1.l1ll() is not None
        except:
            return False
    def open(self):
        l1ll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l111:
            raise NotImplementedError(l1ll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11lll1 = self.l11ll11
        if self.l1ll111.lower().startswith(self.l11ll11.lower()):
            l1lll111 = re.compile(re.escape(self.l11ll11), re.IGNORECASE)
            l1ll111 = l1lll111.sub(l1ll1ll (u"ࠨࠩࠄ"), self.l1ll111)
            l1ll111 = l1ll111.replace(l1ll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1111l(self.l11ll11, l11lll1, l1ll111, self.l11111)
    def l1111l(self,l11ll11, l11lll1, l1ll111, l11111):
        l1ll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11ll1l = l11l11(l11ll11)
        l1l1lll = self.l1lll11(l11ll1l)
        logger.info(l1ll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11ll1l)
        if l1l1lll:
            logger.info(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1l11(l11ll1l)
            l11ll1l = l1l1111(l11ll11, l11lll1, l11111, self.l111l1)
        logger.debug(l1ll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l1ll=l11ll1l + l1ll1ll (u"ࠤ࠲ࠦࠌ") + l1ll111
        l1l1ll = l1ll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l1ll+ l1ll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1ll)
        l1l11ll = os.system(l1l1ll)
        if (l1l11ll != 0):
            raise IOError(l1ll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l1ll, l1l11ll))
    def l1lll11(self, l11ll1l):
        if os.path.exists(l11ll1l):
            if os.path.islink(l11ll1l):
                l11ll1l = os.readlink(l11ll1l)
            if os.path.ismount(l11ll1l):
                return True
        return False
def l11l11(l11ll11):
    l1llll1 = l11ll11.replace(l1ll1ll (u"࠭࡜࡝ࠩࠐ"), l1ll1ll (u"ࠧࡠࠩࠑ")).replace(l1ll1ll (u"ࠨ࠱ࠪࠒ"), l1ll1ll (u"ࠩࡢࠫࠓ"))
    l11lll = l1ll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll=os.environ[l1ll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lllll1=os.path.join(l11ll,l11lll, l1llll1)
    l1llllll=os.path.abspath(l1lllll1)
    return l1llllll
def l1ll1l11(l1lll1l):
    if not os.path.exists(l1lll1l):
        os.makedirs(l1lll1l)
def l1l(l11ll11, l11lll1, l11l=None, password=None):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll1l = l11l11(l11ll11)
    l1ll1l11(l1lll1l)
    if not l11l:
        l111ll1 = l1ll1l()
        l11l1l =l111ll1.l1l1l1(l1ll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11lll1 + l1ll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11lll1 + l1ll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l1l, str):
            l11l, password = l11l1l
        else:
            raise l11l1l1()
        logger.info(l1ll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll1l))
    l1 = pwd.getpwuid( os.getuid())[0]
    l11=os.environ[l1ll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l11l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l111={l1ll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1, l1ll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll11, l1ll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll1l, l1ll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11, l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l, l1ll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l111, temp_file)
        if not os.path.exists(os.path.join(l1l11l, l1ll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lllll=l1ll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1ll (u"ࠧࠨࠤ")
        else:
            l1lllll=l1ll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1lll=l1ll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lllll,temp_file.name)
        l111=[l1ll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l11l, l1ll1lll)]
        p = subprocess.Popen(l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll1l
    logger.debug(l1ll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llllll=os.path.abspath(l1lll1l)
    logger.debug(l1ll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llllll)
    return l1llllll
def l1l1111(l11ll11, l11lll1, l11111, l111l1):
    l1ll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def ll(title):
        l1l1l=30
        if len(title)>l1l1l:
            l1lll=title.split(l1ll1ll (u"ࠨ࠯ࠣ࠳"))
            l1lll1l1=l1ll1ll (u"ࠧࠨ࠴")
            for block in l1lll:
                l1lll1l1+=block+l1ll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l1lll1l1) > l1l1l:
                    l1lll1l1+=l1ll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll1l1
        return title
    l11l = l1ll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1ll1ll (u"ࠦࠧ࠸")
    os.system(l1ll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1llll11 = l11l11(l11ll11)
    l1lll1l = l11l11(hashlib.sha1(l11ll11.encode()).hexdigest()[:10])
    l1ll1l11(l1lll1l)
    logger.info(l1ll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1lll1l))
    if l11111:
        l1lll1ll = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1ll1ll (u"ࠤ࠰ࡸࠧ࠽"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1ll1ll (u"ࠫ࠲ࡵࠧ࠿"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l11l, l11111),
                    urllib.parse.unquote(l11lll1), os.path.abspath(l1lll1l)]
    else:
        l11l, password = l1ll1(l1lll1l, l11lll1, l111l1)
        if l11l.lower() != l1ll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1lll1ll = [l1ll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1ll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1ll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l11l,
                        urllib.parse.unquote(l11lll1), os.path.abspath(l1lll1l)]
        else:
            raise l11l1l1()
    logger.info(l1ll1ll (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1ll1ll (u"ࠢࠡࠤࡉ").join(l1lll1ll)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1l1ll1 = l1ll1ll (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1l1ll1.encode())
    if len(err) > 0:
        l111l1l = l1ll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l111l1l)
        raise l1llll(l111l1l, l1l1111=l1111l1.l1ll(), l11lll1=l11lll1)
    logger.info(l1ll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1ll1ll (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1lll1l, l1llll11))
    l1llllll=os.path.abspath(l1llll11)
    return l1llllll
def l1ll1(l11ll11, l11lll1, l111l1):
    l1lll11l = os.path.join(os.environ[l1ll1ll (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1ll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1ll1ll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1lll11l)):
       os.makedirs(os.path.dirname(l1lll11l))
    l111l = l111l1.get_value(l1ll1ll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1ll1ll (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l111ll1 = l1ll1l(l11ll11, l111l)
    l11l, password = l111ll1.l1l1l1(l1ll1ll (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11lll1 + l1ll1ll (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11lll1 + l1ll1ll (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l11l != l1ll1ll (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l111l11(l11ll11, l11l):
        l111111 = l1ll1ll (u"ࠢࠡࠤࡗ").join([l11ll11, l11l, l1ll1ll (u"ࠨࠤࠪࡘ") + password + l1ll1ll (u"࡙ࠩࠥࠫ"), l1ll1ll (u"ࠪࡠࡳ࡚࠭")])
        with open(l1lll11l, l1ll1ll (u"ࠫࡼ࠱࡛ࠧ")) as l1111:
            l1111.write(l111111)
        os.chmod(l1lll11l, 0o600)
    return l11l, password
def l111l11(l11ll11, l11l):
    l1lll11l = l1ll1l1 = os.path.join(os.environ[l1ll1ll (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1ll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1ll1ll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1lll11l):
        with open(l1lll11l, l1ll1ll (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1ll11ll = data[0].split(l1ll1ll (u"ࠤࠣࠦࡠ"))
            if l11ll11 == l1ll11ll[0] and l11l == l1ll11ll[1]:
                return True
    return False