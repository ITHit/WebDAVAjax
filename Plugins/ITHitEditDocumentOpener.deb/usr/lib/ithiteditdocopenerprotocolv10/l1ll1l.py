#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l11l1 (l1llll11):
    global l11l11l
    l1l1l1l = ord (l1llll11 [-1])
    l1llll1l = l1llll11 [:-1]
    l111ll = l1l1l1l % len (l1llll1l)
    l1l11 = l1llll1l [:l111ll] + l1llll1l [l111ll:]
    if l1l11l:
        l11ll1l = l1111 () .join ([unichr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    return eval (l11ll1l)
import logging
import os
import re
from l11ll11 import l1lllllll
logger = logging.getLogger(l11l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1l1ll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11l1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll1l():
    try:
        out = os.popen(l11l1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l11l1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l11l1 (u"ࠢࠣॶ").join(result)
                logger.info(l11l1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l11l1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l11l1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l11l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1lllllll(l11l1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l11l1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1l1ll(l11l1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))