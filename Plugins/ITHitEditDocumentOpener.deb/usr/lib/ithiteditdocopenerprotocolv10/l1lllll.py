#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l11 = sys.version_info [0] == 2
l1 = 2048
l1ll11ll = 7
def l1l1lll (l11l11):
    global l11l11l
    l11l1l = ord (l11l11 [-1])
    l1ll1111 = l11l11 [:-1]
    l1ll11l = l11l1l % len (l1ll1111)
    l1l1l1l = l1ll1111 [:l1ll11l] + l1ll1111 [l1ll11l:]
    if l111l11:
        l1ll = ll () .join ([unichr (ord (char) - l1 - (l1ll1ll1 + l11l1l) % l1ll11ll) for l1ll1ll1, char in enumerate (l1l1l1l)])
    else:
        l1ll = str () .join ([chr (ord (char) - l1 - (l1ll1ll1 + l11l1l) % l1ll11ll) for l1ll1ll1, char in enumerate (l1l1l1l)])
    return eval (l1ll)
import hashlib
import os
import l1ll11
from l1111ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll11 import l1l1ll1
from l1lll1l import l1lll1l1, l11ll
import logging
logger = logging.getLogger(l1l1lll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1llll1l():
    def __init__(self, l1l11l1,l11l1ll, l1111l1= None, l111l1l=None):
        self.l11lll=False
        self.l111 = self._1lll()
        self.l11l1ll = l11l1ll
        self.l1111l1 = l1111l1
        self.l11ll1 = l1l11l1
        if l1111l1:
            self.l1ll111l = True
        else:
            self.l1ll111l = False
        self.l111l1l = l111l1l
    def _1lll(self):
        try:
            return l1ll11.l1l111l() is not None
        except:
            return False
    def open(self):
        l1l1lll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111:
            raise NotImplementedError(l1l1lll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1lll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1l = self.l11ll1
        if self.l11l1ll.lower().startswith(self.l11ll1.lower()):
            l1111 = re.compile(re.escape(self.l11ll1), re.IGNORECASE)
            l11l1ll = l1111.sub(l1l1lll (u"ࠨࠩࠄ"), self.l11l1ll)
            l11l1ll = l11l1ll.replace(l1l1lll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1lll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l11ll(self.l11ll1, l1ll1l, l11l1ll, self.l1111l1)
    def l1l11ll(self,l11ll1, l1ll1l, l11l1ll, l1111l1):
        l1l1lll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1lll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1llll11 = l11l111(l11ll1)
        l1l1 = self.l1l11l(l1llll11)
        logger.info(l1l1lll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1llll11)
        if l1l1:
            logger.info(l1l1lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1ll1(l1llll11)
            l1llll11 = l1ll1l11(l11ll1, l1ll1l, l1111l1, self.l111l1l)
        logger.debug(l1l1lll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11llll=l1llll11 + l1l1lll (u"ࠤ࠲ࠦࠌ") + l11l1ll
        l11l1 = l1l1lll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11llll+ l1l1lll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11l1)
        l1llllll = os.system(l11l1)
        if (l1llllll != 0):
            raise IOError(l1l1lll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11llll, l1llllll))
    def l1l11l(self, l1llll11):
        if os.path.exists(l1llll11):
            if os.path.islink(l1llll11):
                l1llll11 = os.readlink(l1llll11)
            if os.path.ismount(l1llll11):
                return True
        return False
def l11l111(l11ll1):
    l11111l = l11ll1.replace(l1l1lll (u"࠭࡜࡝ࠩࠐ"), l1l1lll (u"ࠧࡠࠩࠑ")).replace(l1l1lll (u"ࠨ࠱ࠪࠒ"), l1l1lll (u"ࠩࡢࠫࠓ"))
    l11l1l1 = l1l1lll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll1ll=os.environ[l1l1lll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll1l=os.path.join(l1ll1ll,l11l1l1, l11111l)
    l1ll111=os.path.abspath(l11ll1l)
    return l1ll111
def l1llll1(l1ll1):
    if not os.path.exists(l1ll1):
        os.makedirs(l1ll1)
def l11(l11ll1, l1ll1l, l1111l=None, password=None):
    l1l1lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll1 = l11l111(l11ll1)
    l1llll1(l1ll1)
    if not l1111l:
        l11111 = l1lll11()
        l1llll =l11111.l111ll1(l1l1lll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1l + l1l1lll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1l + l1l1lll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll, str):
            l1111l, password = l1llll
        else:
            raise l11ll()
        logger.info(l1l1lll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll1))
    l1l1l = pwd.getpwuid( os.getuid())[0]
    l1ll1l1=os.environ[l1l1lll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l111={l1l1lll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l1l, l1l1lll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll1, l1l1lll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll1, l1l1lll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll1l1, l1l1lll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1111l, l1l1lll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l111, temp_file)
        if not os.path.exists(os.path.join(l11l, l1l1lll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111111=l1l1lll (u"ࠦࡵࡿࠢࠣ")
            key=l1l1lll (u"ࠧࠨࠤ")
        else:
            l111111=l1l1lll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1lll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1111=l1l1lll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111111,temp_file.name)
        l1lll11l=[l1l1lll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1lll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l, l1l1111)]
        p = subprocess.Popen(l1lll11l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1lll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1lll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1lll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll1
    logger.debug(l1l1lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1lll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll111=os.path.abspath(l1ll1)
    logger.debug(l1l1lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll111)
    return l1ll111
def l1ll1l11(l11ll1, l1ll1l, l1111l1, l111l1l):
    l1l1lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l11(title):
        l111ll=30
        if len(title)>l111ll:
            l1ll1l1l=title.split(l1l1lll (u"ࠨ࠯ࠣ࠳"))
            l1lll111=l1l1lll (u"ࠧࠨ࠴")
            for block in l1ll1l1l:
                l1lll111+=block+l1l1lll (u"ࠣ࠱ࠥ࠵")
                if len(l1lll111) > l111ll:
                    l1lll111+=l1l1lll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll111
        return title
    def l1l1l1(l1l1l11, password):
        l1l1lll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l1lll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l1lll (u"ࠧࠦࠢ࠹").join(l1l1l11)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll1lll = l1l1lll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll1lll.encode())
        l1l = [l1l1lll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll11l1 = l1l1lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll11l1)
            for e in l1l:
                if e in l1ll11l1: return False
            raise l1lll1l1(l1ll11l1, l1ll1l11=l1ll11.l1l111l(), l1ll1l=l1ll1l)
        logger.info(l1l1lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1111l = l1l1lll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l1lll (u"ࠦࠧ࠿")
    os.system(l1l1lll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11ll11 = l11l111(l11ll1)
    l1ll1 = l11l111(hashlib.sha1(l11ll1.encode()).hexdigest()[:10])
    l1llll1(l1ll1)
    logger.info(l1l1lll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll1))
    if l1111l1:
        l1l1l11 = [l1l1lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1lll (u"ࠤ࠰ࡸࠧࡄ"), l1l1lll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1lll (u"ࠫ࠲ࡵࠧࡆ"), l1l1lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1111l, l1111l1),
                    urllib.parse.unquote(l1ll1l), os.path.abspath(l1ll1)]
        l1l1l1(l1l1l11, password)
    else:
        while True:
            l1111l, password = l111l(l1ll1, l1ll1l, l111l1l)
            if l1111l.lower() != l1l1lll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1l1l11 = [l1l1lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l1lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l1lll (u"ࠤ࠰ࡸࠧࡋ"), l1l1lll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l1lll (u"ࠫ࠲ࡵࠧࡍ"), l1l1lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1111l,
                            urllib.parse.unquote(l1ll1l), os.path.abspath(l1ll1)]
            else:
                raise l11ll()
            if l1l1l1(l1l1l11, password): break
    os.system(l1l1lll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll1, l11ll11))
    l1ll111=os.path.abspath(l11ll11)
    return l1ll111
def l111l(l11ll1, l1ll1l, l111l1l):
    l11lll1 = os.path.join(os.environ[l1l1lll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l1lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l1lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11lll1)):
       os.makedirs(os.path.dirname(l11lll1))
    l1lll1ll = l111l1l.get_value(l1l1lll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l1lll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11111 = l1lll11(l11ll1, l1lll1ll)
    l1111l, password = l11111.l111ll1(l1l1lll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll1l + l1l1lll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll1l + l1l1lll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1111l != l1l1lll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1lllll1(l11ll1, l1111l):
        l1lll1 = l1l1lll (u"ࠤ࡙ࠣࠦ").join([l11ll1, l1111l, l1l1lll (u"࡚ࠪࠦࠬ") + password + l1l1lll (u"࡛ࠫࠧ࠭"), l1l1lll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11lll1, l1l1lll (u"࠭ࡷࠬࠩ࡝")) as l111l1:
            l111l1.write(l1lll1)
        os.chmod(l11lll1, 0o600)
    return l1111l, password
def l1lllll1(l11ll1, l1111l):
    l11lll1 = l111lll = os.path.join(os.environ[l1l1lll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l1lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l1lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11lll1):
        with open(l11lll1, l1l1lll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l1ll = data[0].split(l1l1lll (u"ࠦࠥࠨࡢ"))
            if l11ll1 == l1l1ll[0] and l1111l == l1l1ll[1]:
                return True
    return False