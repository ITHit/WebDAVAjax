#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll1 = sys.version_info [0] == 2
l111111 = 2048
l111ll1 = 7
def l1lll1ll (l1ll1l1l):
    global l111lll
    l1ll11ll = ord (l1ll1l1l [-1])
    l1llll = l1ll1l1l [:-1]
    l111l = l1ll11ll % len (l1llll)
    l11l1l = l1llll [:l111l] + l1llll [l111l:]
    if l11lll1:
        l1l1ll1 = l111l1l () .join ([unichr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    else:
        l1l1ll1 = str () .join ([chr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    return eval (l1l1ll1)
import hashlib
import os
import l11l111
from l1ll1ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11l111 import l1111l1
from l1lll1 import l111, l1l11l1
import logging
logger = logging.getLogger(l1lll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1():
    def __init__(self, l111l1,l1111ll, l1l1ll= None, l1l1=None):
        self.l1l1l=False
        self.l1lll = self._1llll11()
        self.l1111ll = l1111ll
        self.l1l1ll = l1l1ll
        self.l11l1ll = l111l1
        if l1l1ll:
            self.l11111 = True
        else:
            self.l11111 = False
        self.l1l1 = l1l1
    def _1llll11(self):
        try:
            return l11l111.l11() is not None
        except:
            return False
    def open(self):
        l1lll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lll:
            raise NotImplementedError(l1lll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll = self.l11l1ll
        if self.l1111ll.lower().startswith(self.l11l1ll.lower()):
            ll = re.compile(re.escape(self.l11l1ll), re.IGNORECASE)
            l1111ll = ll.sub(l1lll1ll (u"ࠨࠩࠄ"), self.l1111ll)
            l1111ll = l1111ll.replace(l1lll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll111l(self.l11l1ll, l11ll, l1111ll, self.l1l1ll)
    def l1ll111l(self,l11l1ll, l11ll, l1111ll, l1l1ll):
        l1lll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l11 = l1l(l11l1ll)
        l1l1l11 = self.l1lll1l1(l1l11)
        logger.info(l1lll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l11)
        if l1l1l11:
            logger.info(l1lll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111l1(l1l11)
            l1l11 = l11llll(l11l1ll, l11ll, l1l1ll, self.l1l1)
        logger.debug(l1lll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1111=l1l11 + l1lll1ll (u"ࠤ࠲ࠦࠌ") + l1111ll
        l11l1l1 = l1lll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1111+ l1lll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11l1l1)
        l1l1l1 = os.system(l11l1l1)
        if (l1l1l1 != 0):
            raise IOError(l1lll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1111, l1l1l1))
    def l1lll1l1(self, l1l11):
        if os.path.exists(l1l11):
            if os.path.islink(l1l11):
                l1l11 = os.readlink(l1l11)
            if os.path.ismount(l1l11):
                return True
        return False
def l1l(l11l1ll):
    l1l111 = l11l1ll.replace(l1lll1ll (u"࠭࡜࡝ࠩࠐ"), l1lll1ll (u"ࠧࡠࠩࠑ")).replace(l1lll1ll (u"ࠨ࠱ࠪࠒ"), l1lll1ll (u"ࠩࡢࠫࠓ"))
    l11ll1l = l1lll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1lllll1=os.environ[l1lll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11111l=os.path.join(l1lllll1,l11ll1l, l1l111)
    l111l11=os.path.abspath(l11111l)
    return l111l11
def l1l11ll(l1ll111):
    if not os.path.exists(l1ll111):
        os.makedirs(l1ll111)
def l1ll1ll1(l11l1ll, l11ll, l1ll1l1=None, password=None):
    l1lll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll111 = l1l(l11l1ll)
    l1l11ll(l1ll111)
    if not l1ll1l1:
        l1ll1l = l1111()
        l1llll1l =l1ll1l.l11l11(l1lll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll + l1lll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll + l1lll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll1l, str):
            l1ll1l1, password = l1llll1l
        else:
            raise l1l11l1()
        logger.info(l1lll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll111))
    l11ll11 = pwd.getpwuid( os.getuid())[0]
    l1llllll=os.environ[l1lll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll={l1lll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11ll11, l1lll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l1ll, l1lll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll111, l1lll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1llllll, l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll1l1, l1lll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll, temp_file)
        if not os.path.exists(os.path.join(l1ll1, l1lll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll111=l1lll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1ll (u"ࠧࠨࠤ")
        else:
            l1lll111=l1lll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l11=l1lll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll111,temp_file.name)
        l11lll=[l1lll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1, l1ll1l11)]
        p = subprocess.Popen(l11lll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll111
    logger.debug(l1lll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111l11=os.path.abspath(l1ll111)
    logger.debug(l1lll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111l11)
    return l111l11
def l11llll(l11l1ll, l11ll, l1l1ll, l1l1):
    l1lll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1111(title):
        l1llll1=30
        if len(title)>l1llll1:
            l11ll1=title.split(l1lll1ll (u"ࠨ࠯ࠣ࠳"))
            l11l11l=l1lll1ll (u"ࠧࠨ࠴")
            for block in l11ll1:
                l11l11l+=block+l1lll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l11l11l) > l1llll1:
                    l11l11l+=l1lll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l11l
        return title
    def l1l1l1l(l1l1lll, password):
        l1lll1ll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll1ll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll1ll (u"ࠧࠦࠢ࠹").join(l1l1lll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l11l = l1lll1ll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l11l.encode())
        l11l = [l1lll1ll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l111l = l1lll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l111l)
            for e in l11l:
                if e in l1l111l: return False
            raise l111(l1l111l, l11llll=l11l111.l11(), l11ll=l11ll)
        logger.info(l1lll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1ll1l1 = l1lll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll1ll (u"ࠦࠧ࠿")
    os.system(l1lll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1lll = l1l(l11l1ll)
    l1ll111 = l1l(hashlib.sha1(l11l1ll.encode()).hexdigest()[:10])
    l1l11ll(l1ll111)
    logger.info(l1lll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll111))
    if l1l1ll:
        l1l1lll = [l1lll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1lll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1lll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1ll1l1, l1l1ll),
                    urllib.parse.unquote(l11ll), os.path.abspath(l1ll111)]
        l1l1l1l(l1l1lll, password)
    else:
        while True:
            l1ll1l1, password = l11l1(l1ll111, l11ll, l1l1)
            if l1ll1l1.lower() != l1lll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1l1lll = [l1lll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll1ll (u"ࠤ࠰ࡸࠧࡋ"), l1lll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll1ll (u"ࠫ࠲ࡵࠧࡍ"), l1lll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1ll1l1,
                            urllib.parse.unquote(l11ll), os.path.abspath(l1ll111)]
            else:
                raise l1l11l1()
            if l1l1l1l(l1l1lll, password): break
    os.system(l1lll1ll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll111, l1ll1lll))
    l111l11=os.path.abspath(l1ll1lll)
    return l111l11
def l11l1(l11l1ll, l11ll, l1l1):
    l1lll11 = os.path.join(os.environ[l1lll1ll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll11)):
       os.makedirs(os.path.dirname(l1lll11))
    l1ll11 = l1l1.get_value(l1lll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll1ll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll1l = l1111(l11l1ll, l1ll11)
    l1ll1l1, password = l1ll1l.l11l11(l1lll1ll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11ll + l1lll1ll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11ll + l1lll1ll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1ll1l1 != l1lll1ll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll11l(l11l1ll, l1ll1l1):
        l1lll11l = l1lll1ll (u"ࠤ࡙ࠣࠦ").join([l11l1ll, l1ll1l1, l1lll1ll (u"࡚ࠪࠦࠬ") + password + l1lll1ll (u"࡛ࠫࠧ࠭"), l1lll1ll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll11, l1lll1ll (u"࠭ࡷࠬࠩ࡝")) as l1ll11l1:
            l1ll11l1.write(l1lll11l)
        os.chmod(l1lll11, 0o600)
    return l1ll1l1, password
def l1ll11l(l11l1ll, l1ll1l1):
    l1lll11 = l111ll = os.path.join(os.environ[l1lll1ll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll1ll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll1ll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll11):
        with open(l1lll11, l1lll1ll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lll1l = data[0].split(l1lll1ll (u"ࠦࠥࠨࡢ"))
            if l11l1ll == l1lll1l[0] and l1ll1l1 == l1lll1l[1]:
                return True
    return False