#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1l = 7
def l11 (l1ll11l1):
    global l1l1111
    l1lll = ord (l1ll11l1 [-1])
    l1llllll = l1ll11l1 [:-1]
    l1l11l = l1lll % len (l1llllll)
    l1111ll = l1llllll [:l1l11l] + l1llllll [l1l11l:]
    if l111l1l:
        l11l = l11l1l1 () .join ([unichr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    return eval (l11l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1llll=logging.WARNING
logger = logging.getLogger(l11 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1llll)
l11ll11l = SysLogHandler(address=l11 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll11l.setFormatter(formatter)
logger.addHandler(l11ll11l)
ch = logging.StreamHandler()
ch.setLevel(l1lll1llll)
logger.addHandler(ch)
class l1llll111l(io.FileIO):
    l11 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll11ll, l1lll111l1,
                     options, d=0, p=0):
            self.device = device
            self.l1llll11ll = l1llll11ll
            self.l1lll111l1 = l1lll111l1
            if not options:
                options = l11 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll11ll,
                                              self.l1lll111l1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llllll1l = os.path.join(os.path.sep, l11 (u"ࠪࡩࡹࡩࠧই"), l11 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l111 = path
        else:
            self._1lll1l111 = self.l1llllll1l
        super(l1llll111l, self).__init__(self._1lll1l111, l11 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11lll(self, line):
        return l1llll111l.Entry(*[x for x in line.strip(l11 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11 (u"ࠤࠦࠦ঍")):
                    yield self._1lll11lll(line)
            except ValueError:
                pass
    def l1lll1l1l1(self, attr, value):
        for entry in self.entries:
            l1lll11ll1 = getattr(entry, attr)
            if l1lll11ll1 == value:
                return entry
        return None
    def l1lll1l11l(self, entry):
        if self.l1lll1l1l1(l11 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11 (u"ࠫࡡࡴࠧএ")).encode(l11 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllllll1(self, entry):
        self.seek(0)
        lines = [l.decode(l11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11 (u"ࠢࠤࠤ঒")):
                if self._1lll11lll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11 (u"ࠨࠩও").join(lines).encode(l11 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll1l(cls, l1llll11ll, path=None):
        l1lll1l1ll = cls(path=path)
        entry = l1lll1l1ll.l1lll1l1l1(l11 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll11ll)
        if entry:
            return l1lll1l1ll.l1lllllll1(entry)
        return False
    @classmethod
    def add(cls, device, l1llll11ll, l1lll111l1, options=None, path=None):
        return cls(path=path).l1lll1l11l(l1llll111l.Entry(device,
                                                    l1llll11ll, l1lll111l1,
                                                    options=options))
class l1lll111ll(object):
    def __init__(self, l1lllll1l1):
        self.l1lll11111=l11 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1111l=l11 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll1l1=l1lllll1l1
        self.l1lllll111()
        self.l1lll1ll11()
        self.l1lllll11l()
        self.l1llll1lll()
        self.l1llll1l1l()
    def l1lllll111(self):
        temp_file=open(l1llll11l1,l11 (u"࠭ࡲࠨঘ"))
        l1111l=temp_file.read()
        data=json.loads(l1111l)
        self.user=data[l11 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11ll1l=data[l11 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1llll1l=data[l11 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l1ll=data[l11 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll1111=data[l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1l11=data[l11 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lllll11l(self):
        l11lll=os.path.join(l11 (u"ࠨ࠯ࠣট"),l11 (u"ࠢࡶࡵࡵࠦঠ"),l11 (u"ࠣࡵࡥ࡭ࡳࠨড"),l11 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11lll)
    def l1llll1l1l(self):
        logger.info(l11 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1llll1l=os.path.join(self.l1l1ll,self.l1lll11111)
        l1llll1ll1 = pwd.getpwnam(self.user).pw_uid
        l1lllll1ll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1llll1l):
            os.makedirs(l1llll1l)
            os.system(l11 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1llll1l))
            logger.debug(l11 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1llll1l)
        else:
            logger.debug(l11 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1llll1l)
        l11lll=os.path.join(l1llll1l, self.l1lll1111l)
        print(l11lll)
        logger.debug(l11 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11lll)
        with open(l11lll, l11 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1lll1:
            logger.debug(self.l11ll1l + l11 (u"ࠪࠤࠬপ")+self.l1llll1111+l11 (u"ࠫࠥࠨࠧফ")+self.l1llll1l11+l11 (u"ࠬࠨࠧব"))
            l1lll1lll1.writelines(self.l11ll1l + l11 (u"࠭ࠠࠨভ")+self.l1llll1111+l11 (u"ࠧࠡࠤࠪম")+self.l1llll1l11+l11 (u"ࠨࠤࠪয"))
        os.chmod(l11lll, 0o600)
        os.chown(l11lll, l1llll1ll1, l1lllll1ll)
    def l1lll1ll11(self, l1lll11l11=l11 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11l11 in groups:
            logger.info(l11 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11l11))
        else:
            logger.warning(l11 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11l11))
            ll=l11 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11l11,self.user)
            logger.debug(l11 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %ll)
            os.system(ll)
            logger.debug(l11 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll1lll(self):
        logger.debug(l11 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l1ll=l1llll111l()
        l1lll1l1ll.add(self.l11ll1l, self.l1llll1l, l1lll111l1=l11 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll11l1 = urllib.parse.unquote(sys.argv[1])
        if l1llll11l1:
            l1lll11l1l=l1lll111ll(l1llll11l1)
        else:
            raise (l11 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise