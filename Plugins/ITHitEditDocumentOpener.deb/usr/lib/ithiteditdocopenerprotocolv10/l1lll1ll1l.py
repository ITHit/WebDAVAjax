#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11ll=logging.WARNING
logger = logging.getLogger(l111lll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll11ll)
l1l1lll1 = SysLogHandler(address=l111lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l111lll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1lll1.setFormatter(formatter)
logger.addHandler(l1l1lll1)
ch = logging.StreamHandler()
ch.setLevel(l1llll11ll)
logger.addHandler(ch)
class l1lllll1ll(io.FileIO):
    l111lll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l111lll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1llll, l1lll11l1l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1llll = l1lll1llll
            self.l1lll11l1l = l1lll11l1l
            if not options:
                options = l111lll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l111lll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1llll,
                                              self.l1lll11l1l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll111ll = os.path.join(os.path.sep, l111lll (u"ࠪࡩࡹࡩࠧই"), l111lll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llll1111 = path
        else:
            self._1llll1111 = self.l1lll111ll
        super(l1lllll1ll, self).__init__(self._1llll1111, l111lll (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11l11(self, line):
        return l1lllll1ll.Entry(*[x for x in line.strip(l111lll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l111lll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l111lll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l111lll (u"ࠤࠦࠦ঍")):
                    yield self._1lll11l11(line)
            except ValueError:
                pass
    def l1lll111l1(self, attr, value):
        for entry in self.entries:
            l1lll1l111 = getattr(entry, attr)
            if l1lll1l111 == value:
                return entry
        return None
    def l1lll1l1ll(self, entry):
        if self.l1lll111l1(l111lll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l111lll (u"ࠫࡡࡴࠧএ")).encode(l111lll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllllll1(self, entry):
        self.seek(0)
        lines = [l.decode(l111lll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l111lll (u"ࠢࠤࠤ঒")):
                if self._1lll11l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l111lll (u"ࠨࠩও").join(lines).encode(l111lll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllll111(cls, l1lll1llll, path=None):
        l1llllll1l = cls(path=path)
        entry = l1llllll1l.l1lll111l1(l111lll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1llll)
        if entry:
            return l1llllll1l.l1lllllll1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1llll, l1lll11l1l, options=None, path=None):
        return cls(path=path).l1lll1l1ll(l1lllll1ll.Entry(device,
                                                    l1lll1llll, l1lll11l1l,
                                                    options=options))
class l1llllll11(object):
    def __init__(self, l1lllll1l1):
        self.l1llll1lll=l111lll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll11l1=l111lll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll1l1=l1lllll1l1
        self.l1lll1lll1()
        self.l1lllll11l()
        self.l1llll1l1l()
        self.l1llll111l()
        self.l1lll11ll1()
    def l1lll1lll1(self):
        temp_file=open(l1lll11lll,l111lll (u"࠭ࡲࠨঘ"))
        l1ll1l1=temp_file.read()
        data=json.loads(l1ll1l1)
        self.user=data[l111lll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll1l11=data[l111lll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1lll1=data[l111lll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l1111=data[l111lll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1l11l=data[l111lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1ll11=data[l111lll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1l1l(self):
        l1ll1ll=os.path.join(l111lll (u"ࠨ࠯ࠣট"),l111lll (u"ࠢࡶࡵࡵࠦঠ"),l111lll (u"ࠣࡵࡥ࡭ࡳࠨড"),l111lll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l111lll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll1ll)
    def l1lll11ll1(self):
        logger.info(l111lll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1lll1=os.path.join(self.l1l1111,self.l1llll1lll)
        l1lll11111 = pwd.getpwnam(self.user).pw_uid
        l1llll1l11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1lll1):
            os.makedirs(l1lll1)
            os.system(l111lll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1lll1))
            logger.debug(l111lll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1lll1)
        else:
            logger.debug(l111lll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1lll1)
        l1ll1ll=os.path.join(l1lll1, self.l1llll11l1)
        print(l1ll1ll)
        logger.debug(l111lll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll1ll)
        with open(l1ll1ll, l111lll (u"ࠤࡺ࠯ࠧ঩")) as l1llll1ll1:
            logger.debug(self.l1ll1l11 + l111lll (u"ࠪࠤࠬপ")+self.l1lll1l11l+l111lll (u"ࠫࠥࠨࠧফ")+self.l1lll1ll11+l111lll (u"ࠬࠨࠧব"))
            l1llll1ll1.writelines(self.l1ll1l11 + l111lll (u"࠭ࠠࠨভ")+self.l1lll1l11l+l111lll (u"ࠧࠡࠤࠪম")+self.l1lll1ll11+l111lll (u"ࠨࠤࠪয"))
        os.chmod(l1ll1ll, 0o600)
        os.chown(l1ll1ll, l1lll11111, l1llll1l11)
    def l1lllll11l(self, l1lll1l1l1=l111lll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l111lll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1l1l1 in groups:
            logger.info(l111lll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1l1l1))
        else:
            logger.warning(l111lll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1l1l1))
            l111=l111lll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1l1l1,self.user)
            logger.debug(l111lll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l111)
            os.system(l111)
            logger.debug(l111lll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll111l(self):
        logger.debug(l111lll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llllll1l=l1lllll1ll()
        l1llllll1l.add(self.l1ll1l11, self.l1lll1, l1lll11l1l=l111lll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l111lll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l111lll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll11lll = urllib.parse.unquote(sys.argv[1])
        if l1lll11lll:
            l1lll1111l=l1llllll11(l1lll11lll)
        else:
            raise (l111lll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l111lll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise