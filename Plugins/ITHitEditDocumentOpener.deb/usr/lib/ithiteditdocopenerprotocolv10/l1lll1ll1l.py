#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1llll11 = 2048
l11l11 = 7
def l1lllll (l1lll):
    global l1ll1ll1
    l1ll1lll = ord (l1lll [-1])
    l111l11 = l1lll [:-1]
    l1ll11l = l1ll1lll % len (l111l11)
    l1111 = l111l11 [:l1ll11l] + l111l11 [l1ll11l:]
    if l1ll1:
        l111lll = l1l1ll1 () .join ([unichr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    else:
        l111lll = str () .join ([chr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    return eval (l111lll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l111=logging.WARNING
logger = logging.getLogger(l1lllll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l111)
l11llll1 = SysLogHandler(address=l1lllll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lllll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11llll1.setFormatter(formatter)
logger.addHandler(l11llll1)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l111)
logger.addHandler(ch)
class l1llll111l(io.FileIO):
    l1lllll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lllll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lllll1l1, l1lll1l1ll,
                     options, d=0, p=0):
            self.device = device
            self.l1lllll1l1 = l1lllll1l1
            self.l1lll1l1ll = l1lll1l1ll
            if not options:
                options = l1lllll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lllll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lllll1l1,
                                              self.l1lll1l1ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1l11 = os.path.join(os.path.sep, l1lllll (u"ࠪࡩࡹࡩࠧই"), l1lllll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llllll11 = path
        else:
            self._1llllll11 = self.l1llll1l11
        super(l1llll111l, self).__init__(self._1llllll11, l1lllll (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1llll(self, line):
        return l1llll111l.Entry(*[x for x in line.strip(l1lllll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lllll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lllll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lllll (u"ࠤࠦࠦ঍")):
                    yield self._1lll1llll(line)
            except ValueError:
                pass
    def l1lllll11l(self, attr, value):
        for entry in self.entries:
            l1llll11l1 = getattr(entry, attr)
            if l1llll11l1 == value:
                return entry
        return None
    def l1lll111ll(self, entry):
        if self.l1lllll11l(l1lllll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lllll (u"ࠫࡡࡴࠧএ")).encode(l1lllll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1l1l(self, entry):
        self.seek(0)
        lines = [l.decode(l1lllll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lllll (u"ࠢࠤࠤ঒")):
                if self._1lll1llll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lllll (u"ࠨࠩও").join(lines).encode(l1lllll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llllll1l(cls, l1lllll1l1, path=None):
        l1lll1ll11 = cls(path=path)
        entry = l1lll1ll11.l1lllll11l(l1lllll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lllll1l1)
        if entry:
            return l1lll1ll11.l1llll1l1l(entry)
        return False
    @classmethod
    def add(cls, device, l1lllll1l1, l1lll1l1ll, options=None, path=None):
        return cls(path=path).l1lll111ll(l1llll111l.Entry(device,
                                                    l1lllll1l1, l1lll1l1ll,
                                                    options=options))
class l1llll1lll(object):
    def __init__(self, l1lll1l11l):
        self.l1lll1111l=l1lllll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1lll1=l1lllll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll1l11l=l1lll1l11l
        self.l1lll1l1l1()
        self.l1lll111l1()
        self.l1llll11ll()
        self.l1lll11l11()
        self.l1lllllll1()
    def l1lll1l1l1(self):
        temp_file=open(l1lll11l1l,l1lllll (u"࠭ࡲࠨঘ"))
        l1lll11=temp_file.read()
        data=json.loads(l1lll11)
        self.user=data[l1lllll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l111l1=data[l1lllll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11ll=data[l1lllll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll11l1=data[l1lllll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll1111=data[l1lllll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllll1ll=data[l1lllll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll11ll(self):
        l11lll1=os.path.join(l1lllll (u"ࠨ࠯ࠣট"),l1lllll (u"ࠢࡶࡵࡵࠦঠ"),l1lllll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lllll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lllll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11lll1)
    def l1lllllll1(self):
        logger.info(l1lllll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11ll=os.path.join(self.l1ll11l1,self.l1lll1111l)
        l1lll11111 = pwd.getpwnam(self.user).pw_uid
        l1lll11ll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11ll):
            os.makedirs(l11ll)
            os.system(l1lllll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11ll))
            logger.debug(l1lllll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11ll)
        else:
            logger.debug(l1lllll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11ll)
        l11lll1=os.path.join(l11ll, self.l1lll1lll1)
        print(l11lll1)
        logger.debug(l1lllll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11lll1)
        with open(l11lll1, l1lllll (u"ࠤࡺ࠯ࠧ঩")) as l1llll1ll1:
            logger.debug(self.l111l1 + l1lllll (u"ࠪࠤࠬপ")+self.l1llll1111+l1lllll (u"ࠫࠥࠨࠧফ")+self.l1lllll1ll+l1lllll (u"ࠬࠨࠧব"))
            l1llll1ll1.writelines(self.l111l1 + l1lllll (u"࠭ࠠࠨভ")+self.l1llll1111+l1lllll (u"ࠧࠡࠤࠪম")+self.l1lllll1ll+l1lllll (u"ࠨࠤࠪয"))
        os.chmod(l11lll1, 0o600)
        os.chown(l11lll1, l1lll11111, l1lll11ll1)
    def l1lll111l1(self, l1lll11lll=l1lllll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lllll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11lll in groups:
            logger.info(l1lllll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11lll))
        else:
            logger.warning(l1lllll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11lll))
            l11llll=l1lllll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11lll,self.user)
            logger.debug(l1lllll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l11llll)
            os.system(l11llll)
            logger.debug(l1lllll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll11l11(self):
        logger.debug(l1lllll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1ll11=l1llll111l()
        l1lll1ll11.add(self.l111l1, self.l11ll, l1lll1l1ll=l1lllll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lllll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lllll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll11l1l = urllib.parse.unquote(sys.argv[1])
        if l1lll11l1l:
            l1lllll111=l1llll1lll(l1lll11l1l)
        else:
            raise (l1lllll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lllll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise