#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l1l1ll = 7
def l1ll11 (l1l1ll1):
    global l1llll1
    l111 = ord (l1l1ll1 [-1])
    l1ll11l = l1l1ll1 [:-1]
    l11l11l = l111 % len (l1ll11l)
    l1llll = l1ll11l [:l11l11l] + l1ll11l [l11l11l:]
    if l111l1:
        l1111l1 = l11111l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    return eval (l1111l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llllll11=logging.WARNING
logger = logging.getLogger(l1ll11 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llllll11)
l1l11l11 = SysLogHandler(address=l1ll11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1ll11 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l11l11)
ch = logging.StreamHandler()
ch.setLevel(l1llllll11)
logger.addHandler(ch)
class l1lll11ll1(io.FileIO):
    l1ll11 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1ll11 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1llll1111, l1lll11lll,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1111 = l1llll1111
            self.l1lll11lll = l1lll11lll
            if not options:
                options = l1ll11 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll11 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1llll1111,
                                              self.l1lll11lll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1l11 = os.path.join(os.path.sep, l1ll11 (u"ࠨࡧࡷࡧࠬঅ"), l1ll11 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1llll1lll = path
        else:
            self._1llll1lll = self.l1llll1l11
        super(l1lll11ll1, self).__init__(self._1llll1lll, l1ll11 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lllllll1(self, line):
        return l1lll11ll1.Entry(*[x for x in line.strip(l1ll11 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1ll11 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll11 (u"ࠢࠤࠤঋ")):
                    yield self._1lllllll1(line)
            except ValueError:
                pass
    def l1lllll11l(self, attr, value):
        for entry in self.entries:
            l1lll1l111 = getattr(entry, attr)
            if l1lll1l111 == value:
                return entry
        return None
    def l1lll1l11l(self, entry):
        if self.l1lllll11l(l1ll11 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1ll11 (u"ࠩ࡟ࡲࠬ঍")).encode(l1ll11 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll1llll(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll11 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll11 (u"ࠧࠩࠢঐ")):
                if self._1lllllll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll11 (u"࠭ࠧ঑").join(lines).encode(l1ll11 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1llll1ll1(cls, l1llll1111, path=None):
        l11111111 = cls(path=path)
        entry = l11111111.l1lllll11l(l1ll11 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1llll1111)
        if entry:
            return l11111111.l1lll1llll(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1111, l1lll11lll, options=None, path=None):
        return cls(path=path).l1lll1l11l(l1lll11ll1.Entry(device,
                                                    l1llll1111, l1lll11lll,
                                                    options=options))
class l1lll11l1l(object):
    def __init__(self, l1llll11l1):
        self.l1llll11ll=l1ll11 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll1ll11=l1ll11 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll11l1=l1llll11l1
        self.l1lll111l1()
        self.l1llll1l1l()
        self.l1lll1l1ll()
        self.l1lllll111()
        self.l1lllll1ll()
    def l1lll111l1(self):
        temp_file=open(l1llllllll,l1ll11 (u"ࠫࡷ࠭খ"))
        l1l1l1=temp_file.read()
        data=json.loads(l1l1l1)
        self.user=data[l1ll11 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l11l=data[l1ll11 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1lll111=data[l1ll11 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1lll1=data[l1ll11 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lllll1l1=data[l1ll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll11l11=data[l1ll11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll1l1ll(self):
        l111lll=os.path.join(l1ll11 (u"ࠦ࠴ࠨঝ"),l1ll11 (u"ࠧࡻࡳࡳࠤঞ"),l1ll11 (u"ࠨࡳࡣ࡫ࡱࠦট"),l1ll11 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1ll11 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l111lll)
    def l1lllll1ll(self):
        logger.info(l1ll11 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1lll111=os.path.join(self.l1lll1,self.l1llll11ll)
        l1llllll1l = pwd.getpwnam(self.user).pw_uid
        l1lll1l1l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1lll111):
            os.makedirs(l1lll111)
            os.system(l1ll11 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1lll111))
            logger.debug(l1ll11 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1lll111)
        else:
            logger.debug(l1ll11 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1lll111)
        l111lll=os.path.join(l1lll111, self.l1lll1ll11)
        print(l111lll)
        logger.debug(l1ll11 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l111lll)
        with open(l111lll, l1ll11 (u"ࠢࡸ࠭ࠥধ")) as l1lll1lll1:
            logger.debug(self.l11l + l1ll11 (u"ࠨࠢࠪন")+self.l1lllll1l1+l1ll11 (u"ࠩࠣࠦࠬ঩")+self.l1lll11l11+l1ll11 (u"ࠪࠦࠬপ"))
            l1lll1lll1.writelines(self.l11l + l1ll11 (u"ࠫࠥ࠭ফ")+self.l1lllll1l1+l1ll11 (u"ࠬࠦࠢࠨব")+self.l1lll11l11+l1ll11 (u"࠭ࠢࠨভ"))
        os.chmod(l111lll, 0o600)
        os.chown(l111lll, l1llllll1l, l1lll1l1l1)
    def l1llll1l1l(self, l1llll111l=l1ll11 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1ll11 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll111l in groups:
            logger.info(l1ll11 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llll111l))
        else:
            logger.warning(l1ll11 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llll111l))
            l1l111=l1ll11 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llll111l,self.user)
            logger.debug(l1ll11 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1l111)
            os.system(l1l111)
            logger.debug(l1ll11 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lllll111(self):
        logger.debug(l1ll11 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l11111111=l1lll11ll1()
        l11111111.add(self.l11l, self.l1lll111, l1lll11lll=l1ll11 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1ll11 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1ll11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llllllll = urllib.parse.unquote(sys.argv[1])
        if l1llllllll:
            l1lll111ll=l1lll11l1l(l1llllllll)
        else:
            raise (l1ll11 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1ll11 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise