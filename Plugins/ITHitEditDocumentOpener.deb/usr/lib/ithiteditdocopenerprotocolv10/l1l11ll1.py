#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l11111l = 7
def l1ll11l (l1lll1l1):
    global l111111
    l1ll1l1 = ord (l1lll1l1 [-1])
    l1ll111 = l1lll1l1 [:-1]
    l11l1 = l1ll1l1 % len (l1ll111)
    l1l1111 = l1ll111 [:l11l1] + l1ll111 [l11l1:]
    if l11ll1:
        l1ll11 = l1llll1l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    return eval (l1ll11)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l1l11 import l1llll1
from configobj import ConfigObj
l1l1l11l = l1ll11l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11l1lll = l1ll11l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠺࠹࠳࠶ࠢࡤ")
l11ll1l1 = l1ll11l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll11l (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠹࠸࠲࠵ࠨࡦ")
l1l1l111=os.path.join(os.environ.get(l1ll11l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll11l (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll1l1.replace(l1ll11l (u"ࠦࠥࠨࡩ"), l1ll11l (u"ࠧࡥࠢࡪ")).lower())
l11llll1=os.environ.get(l1ll11l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll11l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll11=l11l1lll.replace(l1ll11l (u"ࠣࠢࠥ࡭"), l1ll11l (u"ࠤࡢࠦ࡮"))+l1ll11l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll11l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11lll=os.path.join(os.environ.get(l1ll11l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll11)
elif platform.system() == l1ll11l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll11l=l1llll1(l1l1l111+l1ll11l (u"ࠢ࠰ࠤࡳ"))
    l1l11lll = os.path.join(l11ll11l, l11lll11)
else:
    l1l11lll = os.path.join( l11lll11)
l11llll1=l11llll1.upper()
if l11llll1 == l1ll11l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11ll111=logging.DEBUG
elif l11llll1 == l1ll11l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11ll111 = logging.INFO
elif l11llll1 == l1ll11l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11ll111 = logging.WARNING
elif l11llll1 == l1ll11l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11ll111 = logging.ERROR
elif l11llll1 == l1ll11l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11ll111 = logging.CRITICAL
elif l11llll1 == l1ll11l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11ll111 = logging.NOTSET
logger = logging.getLogger(l1ll11l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11ll111)
l11lllll = logging.FileHandler(l1l11lll, mode=l1ll11l (u"ࠣࡹ࠮ࠦࡻ"))
l11lllll.setLevel(l11ll111)
formatter = logging.Formatter(l1ll11l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll11l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11lllll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll111)
l1l1111l = SysLogHandler(address=l1ll11l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1111l.setFormatter(formatter)
logger.addHandler(l11lllll)
logger.addHandler(ch)
logger.addHandler(l1l1111l)
class Settings():
    l1l1ll11 = l1ll11l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1llll = l1ll11l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11lll1l = l1ll11l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11l1lll):
        self.l1l1ll1l = self._1l11111(l11l1lll)
        self._1l1l1ll()
    def _1l11111(self, l11l1lll):
        l1l1lll1 = l11l1lll.split(l1ll11l (u"ࠣࠢࠥࢂ"))
        l1l1lll1 = l1ll11l (u"ࠤࠣࠦࢃ").join(l1l1lll1)
        if platform.system() == l1ll11l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1ll1l = os.path.join(l1l1l111, l1ll11l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1lll1 + l1ll11l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1ll1l
    def l1l1l1l1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l111ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll11l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll11l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l111l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1l1ll(self):
        if not os.path.exists(os.path.dirname(self.l1l1ll1l)):
            os.makedirs(os.path.dirname(self.l1l1ll1l))
        if not os.path.exists(self.l1l1ll1l):
            self.config = ConfigObj(self.l1l1ll1l)
            self.config[l1ll11l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll11l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll11l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11lll1l
            self.config[l1ll11l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll11l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1llll
            self.config[l1ll11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1ll11
            self.config[l1ll11l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1ll1l)
            self.l11lll1l = self.get_value(l1ll11l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll11l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1llll = self.get_value(l1ll11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll11l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1ll11 = self.get_value(l1ll11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11l1l(self):
        l1l11l11 = l1ll11l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1ll11
        l1l11l11 += l1ll11l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1llll
        l1l11l11 += l1ll11l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11lll1l
        return l1l11l11
    def __unicode__(self):
        return self._1l11l1l()
    def __str__(self):
        return self._1l11l1l()
    def __del__(self):
        self.config.write()
l11ll1ll = Settings(l11l1lll)