#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l11l1 (l1llll11):
    global l11l11l
    l1l1l1l = ord (l1llll11 [-1])
    l1llll1l = l1llll11 [:-1]
    l111ll = l1l1l1l % len (l1llll1l)
    l1l11 = l1llll1l [:l111ll] + l1llll1l [l111ll:]
    if l1l11l:
        l11ll1l = l1111 () .join ([unichr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    return eval (l11ll1l)
import hashlib
import os
import l1ll1l
from l11ll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll1l import l1l1ll
from l11ll11 import l1lll, l111lll
import logging
logger = logging.getLogger(l11l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l():
    def __init__(self, l11l1l,l1lllll, l1lll111= None, l1l1ll1=None):
        self.l1llllll=False
        self.ll = self._1llll()
        self.l1lllll = l1lllll
        self.l1lll111 = l1lll111
        self.l11l1ll = l11l1l
        if l1lll111:
            self.l1lllll1 = True
        else:
            self.l1lllll1 = False
        self.l1l1ll1 = l1l1ll1
    def _1llll(self):
        try:
            return l1ll1l.l1lll1l() is not None
        except:
            return False
    def open(self):
        l11l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.ll:
            raise NotImplementedError(l11l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1lll1ll = self.l11l1ll
        if self.l1lllll.lower().startswith(self.l11l1ll.lower()):
            l1l111l = re.compile(re.escape(self.l11l1ll), re.IGNORECASE)
            l1lllll = l1l111l.sub(l11l1 (u"ࠨࠩࠄ"), self.l1lllll)
            l1lllll = l1lllll.replace(l11l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11111l(self.l11l1ll, l1lll1ll, l1lllll, self.l1lll111)
    def l11111l(self,l11l1ll, l1lll1ll, l1lllll, l1lll111):
        l11l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll = l111l(l11l1ll)
        l1111ll = self.l1ll1l11(l1ll)
        logger.info(l11l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll)
        if l1111ll:
            logger.info(l11l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1ll(l1ll)
            l1ll = l1ll1l1(l11l1ll, l1lll1ll, l1lll111, self.l1l1ll1)
        logger.debug(l11l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11111=l1ll + l11l1 (u"ࠤ࠲ࠦࠌ") + l1lllll
        l1ll1l1l = l11l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11111+ l11l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1l1l)
        l11l111 = os.system(l1ll1l1l)
        if (l11l111 != 0):
            raise IOError(l11l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11111, l11l111))
    def l1ll1l11(self, l1ll):
        if os.path.exists(l1ll):
            if os.path.islink(l1ll):
                l1ll = os.readlink(l1ll)
            if os.path.ismount(l1ll):
                return True
        return False
def l111l(l11l1ll):
    l1ll11ll = l11l1ll.replace(l11l1 (u"࠭࡜࡝ࠩࠐ"), l11l1 (u"ࠧࡠࠩࠑ")).replace(l11l1 (u"ࠨ࠱ࠪࠒ"), l11l1 (u"ࠩࡢࠫࠓ"))
    l1l11l1 = l11l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l1lll=os.environ[l11l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1l11=os.path.join(l1l1lll,l1l11l1, l1ll11ll)
    l1llll1=os.path.abspath(l1l1l11)
    return l1llll1
def l1ll111(l11):
    if not os.path.exists(l11):
        os.makedirs(l11)
def l1ll11l1(l11l1ll, l1lll1ll, l111l11=None, password=None):
    l11l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11 = l111l(l11l1ll)
    l1ll111(l11)
    if not l111l11:
        l1l111 = l1111l()
        l11llll =l1l111.l111l1l(l11l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1lll1ll + l11l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1lll1ll + l11l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11llll, str):
            l111l11, password = l11llll
        else:
            raise l111lll()
        logger.info(l11l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11))
    l11l11 = pwd.getpwuid( os.getuid())[0]
    l1=os.environ[l11l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11l={l11l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11, l11l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l1ll, l11l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11, l11l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1, l11l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111l11, l11l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11l, temp_file)
        if not os.path.exists(os.path.join(l1l1, l11l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11lll1=l11l1 (u"ࠦࡵࡿࠢࠣ")
            key=l11l1 (u"ࠧࠨࠤ")
        else:
            l11lll1=l11l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll11=l11l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11lll1,temp_file.name)
        l1l1111=[l11l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1, l1lll11)]
        p = subprocess.Popen(l1l1111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11
    logger.debug(l11l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llll1=os.path.abspath(l11)
    logger.debug(l11l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llll1)
    return l1llll1
def l1ll1l1(l11l1ll, l1lll1ll, l1lll111, l1l1ll1):
    l11l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll1l1(title):
        l1lll11l=30
        if len(title)>l1lll11l:
            l1lll1=title.split(l11l1 (u"ࠨ࠯ࠣ࠳"))
            l1ll11=l11l1 (u"ࠧࠨ࠴")
            for block in l1lll1:
                l1ll11+=block+l11l1 (u"ࠣ࠱ࠥ࠵")
                if len(l1ll11) > l1lll11l:
                    l1ll11+=l11l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll11
        return title
    l111l11 = l11l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l11l1 (u"ࠦࠧ࠸")
    os.system(l11l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1l11ll = l111l(l11l1ll)
    l11 = l111l(hashlib.sha1(l11l1ll.encode()).hexdigest()[:10])
    l1ll111(l11)
    logger.info(l11l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11))
    if l1lll111:
        l1l1l1 = [l11l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l11l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l11l1 (u"ࠤ࠰ࡸࠧ࠽"), l11l1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l11l1 (u"ࠫ࠲ࡵࠧ࠿"), l11l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l111l11, l1lll111),
                    urllib.parse.unquote(l1lll1ll), os.path.abspath(l11)]
    else:
        l111l11, password = l1ll1ll1(l11, l1lll1ll, l1l1ll1)
        if l111l11.lower() != l11l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1l1l1 = [l11l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11l1 (u"ࠤ࠰ࡸࠧࡄ"), l11l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11l1 (u"ࠫ࠲ࡵࠧࡆ"), l11l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l111l11,
                        urllib.parse.unquote(l1lll1ll), os.path.abspath(l11)]
        else:
            raise l111lll()
    logger.info(l11l1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l11l1 (u"ࠢࠡࠤࡉ").join(l1l1l1)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11ll = l11l1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11ll.encode())
    if len(err) > 0:
        l111ll1 = l11l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l111ll1)
        raise l1lll(l111ll1, l1ll1l1=l1ll1l.l1lll1l(), l1lll1ll=l1lll1ll)
    logger.info(l11l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l11l1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11, l1l11ll))
    l1llll1=os.path.abspath(l1l11ll)
    return l1llll1
def l1ll1ll1(l11l1ll, l1lll1ll, l1l1ll1):
    l1ll1 = os.path.join(os.environ[l11l1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l11l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l11l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1ll1)):
       os.makedirs(os.path.dirname(l1ll1))
    l1ll1lll = l1l1ll1.get_value(l11l1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l11l1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l111 = l1111l(l11l1ll, l1ll1lll)
    l111l11, password = l1l111.l111l1l(l11l1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1lll1ll + l11l1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1lll1ll + l11l1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l111l11 != l11l1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l11lll(l11l1ll, l111l11):
        l111 = l11l1 (u"ࠢࠡࠤࡗ").join([l11l1ll, l111l11, l11l1 (u"ࠨࠤࠪࡘ") + password + l11l1 (u"࡙ࠩࠥࠫ"), l11l1 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1ll1, l11l1 (u"ࠫࡼ࠱࡛ࠧ")) as l11l1l1:
            l11l1l1.write(l111)
        os.chmod(l1ll1, 0o600)
    return l111l11, password
def l11lll(l11l1ll, l111l11):
    l1ll1 = l1l1l = os.path.join(os.environ[l11l1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l11l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l11l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1ll1):
        with open(l1ll1, l11l1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1ll1ll = data[0].split(l11l1 (u"ࠤࠣࠦࡠ"))
            if l11l1ll == l1ll1ll[0] and l111l11 == l1ll1ll[1]:
                return True
    return False