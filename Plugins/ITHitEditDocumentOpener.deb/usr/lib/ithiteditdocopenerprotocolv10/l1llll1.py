#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1llllll = 2048
l11ll1 = 7
def l1lll1 (l1l1lll):
    global l1lllll1
    l11l1l = ord (l1l1lll [-1])
    l1ll111 = l1l1lll [:-1]
    l11l = l11l1l % len (l1ll111)
    l11111l = l1ll111 [:l11l] + l1ll111 [l11l:]
    if l1l11l:
        l1lll = l1 () .join ([unichr (ord (char) - l1llllll - (l11llll + l11l1l) % l11ll1) for l11llll, char in enumerate (l11111l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1llllll - (l11llll + l11l1l) % l11ll1) for l11llll, char in enumerate (l11111l)])
    return eval (l1lll)
import hashlib
import os
import l1l1l11
from l1l1l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1l11 import l111l11
from l1111l import l1ll11l, l111111
import logging
logger = logging.getLogger(l1lll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111ll():
    def __init__(self, l1ll1ll,l1l111, ll= None, l11l1l1=None):
        self.l111ll=False
        self.l1ll111l = self._1l1ll()
        self.l1l111 = l1l111
        self.ll = ll
        self.l111lll = l1ll1ll
        if ll:
            self.l1ll1l = True
        else:
            self.l1ll1l = False
        self.l11l1l1 = l11l1l1
    def _1l1ll(self):
        try:
            return l1l1l11.l111l1() is not None
        except:
            return False
    def open(self):
        l1lll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll111l:
            raise NotImplementedError(l1lll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll11l1 = self.l111lll
        if self.l1l111.lower().startswith(self.l111lll.lower()):
            l111l = re.compile(re.escape(self.l111lll), re.IGNORECASE)
            l1l111 = l111l.sub(l1lll1 (u"ࠨࠩࠄ"), self.l1l111)
            l1l111 = l1l111.replace(l1lll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1111(self.l111lll, l1ll11l1, l1l111, self.ll)
    def l1111(self,l111lll, l1ll11l1, l1l111, ll):
        l1lll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1l1l = l11lll1(l111lll)
        l1ll = self.l1l1(l1ll1l1l)
        logger.info(l1lll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1l1l)
        if l1ll:
            logger.info(l1lll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111l11(l1ll1l1l)
            l1ll1l1l = l1111l1(l111lll, l1ll11l1, ll, self.l11l1l1)
        logger.debug(l1lll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1llll1l=l1ll1l1l + l1lll1 (u"ࠤ࠲ࠦࠌ") + l1l111
        l1l = l1lll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1llll1l+ l1lll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l)
        l1lll1l1 = os.system(l1l)
        if (l1lll1l1 != 0):
            raise IOError(l1lll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1llll1l, l1lll1l1))
    def l1l1(self, l1ll1l1l):
        if os.path.exists(l1ll1l1l):
            if os.path.islink(l1ll1l1l):
                l1ll1l1l = os.readlink(l1ll1l1l)
            if os.path.ismount(l1ll1l1l):
                return True
        return False
def l11lll1(l111lll):
    l1l11l1 = l111lll.replace(l1lll1 (u"࠭࡜࡝ࠩࠐ"), l1lll1 (u"ࠧࡠࠩࠑ")).replace(l1lll1 (u"ࠨ࠱ࠪࠒ"), l1lll1 (u"ࠩࡢࠫࠓ"))
    l1l11ll = l1lll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1lll1l=os.environ[l1lll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l1ll=os.path.join(l1lll1l,l1l11ll, l1l11l1)
    l1lll11l=os.path.abspath(l11l1ll)
    return l1lll11l
def l1lllll(l11l1):
    if not os.path.exists(l11l1):
        os.makedirs(l11l1)
def l1lll111(l111lll, l1ll11l1, l1l11=None, password=None):
    l1lll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l1 = l11lll1(l111lll)
    l1lllll(l11l1)
    if not l1l11:
        l1ll1111 = l1lll11()
        l1l1l1l =l1ll1111.l1ll1lll(l1lll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll11l1 + l1lll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll11l1 + l1lll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l1l1l, str):
            l1l11, password = l1l1l1l
        else:
            raise l111111()
        logger.info(l1lll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l1))
    l1ll1 = pwd.getpwuid( os.getuid())[0]
    l1l1ll1=os.environ[l1lll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11ll={l1lll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1, l1lll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111lll, l1lll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l1, l1lll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1ll1, l1lll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l11, l1lll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11ll, temp_file)
        if not os.path.exists(os.path.join(l11ll, l1lll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l111l=l1lll1 (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1 (u"ࠧࠨࠤ")
        else:
            l1l111l=l1lll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111=l1lll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l111l,temp_file.name)
        l1llll11=[l1lll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11ll, l111)]
        p = subprocess.Popen(l1llll11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l1
    logger.debug(l1lll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll11l=os.path.abspath(l11l1)
    logger.debug(l1lll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll11l)
    return l1lll11l
def l1111l1(l111lll, l1ll11l1, ll, l11l1l1):
    l1lll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll1ll(title):
        l1l1111=30
        if len(title)>l1l1111:
            l111ll1=title.split(l1lll1 (u"ࠨ࠯ࠣ࠳"))
            l11l11=l1lll1 (u"ࠧࠨ࠴")
            for block in l111ll1:
                l11l11+=block+l1lll1 (u"ࠣ࠱ࠥ࠵")
                if len(l11l11) > l1l1111:
                    l11l11+=l1lll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l11
        return title
    def l1ll11(l11, password):
        l1lll1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll1 (u"ࠧࠦࠢ࠹").join(l11)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1llll = l1lll1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1llll.encode())
        l11111 = [l1lll1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11lll = l1lll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11lll)
            for e in l11111:
                if e in l11lll: return False
            raise l1ll11l(l11lll, l1111l1=l1l1l11.l111l1(), l1ll11l1=l1ll11l1)
        logger.info(l1lll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l11 = l1lll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll1 (u"ࠦࠧ࠿")
    os.system(l1lll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11ll1l = l11lll1(l111lll)
    l11l1 = l11lll1(hashlib.sha1(l111lll.encode()).hexdigest()[:10])
    l1lllll(l11l1)
    logger.info(l1lll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11l1))
    if ll:
        l11 = [l1lll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1 (u"ࠤ࠰ࡸࠧࡄ"), l1lll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1 (u"ࠫ࠲ࡵࠧࡆ"), l1lll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l11, ll),
                    urllib.parse.unquote(l1ll11l1), os.path.abspath(l11l1)]
        l1ll11(l11, password)
    else:
        while True:
            l1l11, password = l11l11l(l11l1, l1ll11l1, l11l1l1)
            if l1l11.lower() != l1lll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11 = [l1lll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll1 (u"ࠤ࠰ࡸࠧࡋ"), l1lll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll1 (u"ࠫ࠲ࡵࠧࡍ"), l1lll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l11,
                            urllib.parse.unquote(l1ll11l1), os.path.abspath(l11l1)]
            else:
                raise l111111()
            if l1ll11(l11, password): break
    os.system(l1lll1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11l1, l11ll1l))
    l1lll11l=os.path.abspath(l11ll1l)
    return l1lll11l
def l11l11l(l111lll, l1ll11l1, l11l1l1):
    l1ll1l1 = os.path.join(os.environ[l1lll1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1l1)):
       os.makedirs(os.path.dirname(l1ll1l1))
    l111l1l = l11l1l1.get_value(l1lll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll1111 = l1lll11(l111lll, l111l1l)
    l1l11, password = l1ll1111.l1ll1lll(l1lll1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll11l1 + l1lll1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll11l1 + l1lll1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l11 != l1lll1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l1l1(l111lll, l1l11):
        l11ll11 = l1lll1 (u"ࠤ࡙ࠣࠦ").join([l111lll, l1l11, l1lll1 (u"࡚ࠪࠦࠬ") + password + l1lll1 (u"࡛ࠫࠧ࠭"), l1lll1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1l1, l1lll1 (u"࠭ࡷࠬࠩ࡝")) as l1ll1l11:
            l1ll1l11.write(l11ll11)
        os.chmod(l1ll1l1, 0o600)
    return l1l11, password
def l1l1l1(l111lll, l1l11):
    l1ll1l1 = l11l111 = os.path.join(os.environ[l1lll1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1l1):
        with open(l1ll1l1, l1lll1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll1ll1 = data[0].split(l1lll1 (u"ࠦࠥࠨࡢ"))
            if l111lll == l1ll1ll1[0] and l1l11 == l1ll1ll1[1]:
                return True
    return False