#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1ll = 7
def l11ll11 (l1lll11l):
    global l1ll
    l1l1ll1 = ord (l1lll11l [-1])
    l11l1l1 = l1lll11l [:-1]
    l111ll1 = l1l1ll1 % len (l11l1l1)
    l11lll = l11l1l1 [:l111ll1] + l11l1l1 [l111ll1:]
    if l1l1l:
        l1lll = l111111 () .join ([unichr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    return eval (l1lll)
import logging
import os
import re
from l1l import l1llll1l1
logger = logging.getLogger(l11ll11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1l1111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11ll11 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll1ll():
    try:
        out = os.popen(l11ll11 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l11ll11 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l11ll11 (u"ࠢࠣॶ").join(result)
                logger.info(l11ll11 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l11ll11 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l11ll11 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l11ll11 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1l1(l11ll11 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l11ll11 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1l1111(l11ll11 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))