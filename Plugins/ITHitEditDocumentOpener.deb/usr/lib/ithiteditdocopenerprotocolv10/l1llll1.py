#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1ll = 7
def l1l111 (l11ll):
    global l1lll11l
    l1ll1l1l = ord (l11ll [-1])
    l111 = l11ll [:-1]
    l11 = l1ll1l1l % len (l111)
    l1ll1ll = l111 [:l11] + l111 [l11:]
    if l1llll:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    return eval (l1ll1l1)
import hashlib
import os
import l1l1lll
from l1lllll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1lll import l111lll
from l11111 import l11l111, l1ll1l11
import logging
logger = logging.getLogger(l1l111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111l1l():
    def __init__(self, l1ll1lll,l1ll111, l11l11= None, l1l1ll1=None):
        self.l1ll=False
        self.l11l = self._1l11l1()
        self.l1ll111 = l1ll111
        self.l11l11 = l11l11
        self.l111l11 = l1ll1lll
        if l11l11:
            self.l1lll1ll = True
        else:
            self.l1lll1ll = False
        self.l1l1ll1 = l1l1ll1
    def _1l11l1(self):
        try:
            return l1l1lll.l111l1() is not None
        except:
            return False
    def open(self):
        l1l111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l:
            raise NotImplementedError(l1l111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1llllll = self.l111l11
        if self.l1ll111.lower().startswith(self.l111l11.lower()):
            l1l11 = re.compile(re.escape(self.l111l11), re.IGNORECASE)
            l1ll111 = l1l11.sub(l1l111 (u"ࠨࠩࠄ"), self.l1ll111)
            l1ll111 = l1ll111.replace(l1l111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1llll11(self.l111l11, l1llllll, l1ll111, self.l11l11)
    def l1llll11(self,l111l11, l1llllll, l1ll111, l11l11):
        l1l111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1l1l = l1lll1(l111l11)
        l1lll111 = self.l1l111l(l1l1l1l)
        logger.info(l1l111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1l1l)
        if l1lll111:
            logger.info(l1l111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111lll(l1l1l1l)
            l1l1l1l = l1ll1111(l111l11, l1llllll, l11l11, self.l1l1ll1)
        logger.debug(l1l111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l1l=l1l1l1l + l1l111 (u"ࠤ࠲ࠦࠌ") + l1ll111
        l111l = l1l111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l1l+ l1l111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111l)
        l1l1l = os.system(l111l)
        if (l1l1l != 0):
            raise IOError(l1l111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l1l, l1l1l))
    def l1l111l(self, l1l1l1l):
        if os.path.exists(l1l1l1l):
            if os.path.islink(l1l1l1l):
                l1l1l1l = os.readlink(l1l1l1l)
            if os.path.ismount(l1l1l1l):
                return True
        return False
def l1lll1(l111l11):
    l1ll11 = l111l11.replace(l1l111 (u"࠭࡜࡝ࠩࠐ"), l1l111 (u"ࠧࡠࠩࠑ")).replace(l1l111 (u"ࠨ࠱ࠪࠒ"), l1l111 (u"ࠩࡢࠫࠓ"))
    l1l1111 = l1l111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11lll=os.environ[l1l111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1=os.path.join(l11lll,l1l1111, l1ll11)
    l1ll11ll=os.path.abspath(l1l1)
    return l1ll11ll
def l1lllll1(l11llll):
    if not os.path.exists(l11llll):
        os.makedirs(l11llll)
def l1llll1l(l111l11, l1llllll, l1ll1=None, password=None):
    l1l111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11llll = l1lll1(l111l11)
    l1lllll1(l11llll)
    if not l1ll1:
        l11lll1 = l111ll1()
        l1l1ll =l11lll1.l11111l(l1l111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1llllll + l1l111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1llllll + l1l111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l1ll, str):
            l1ll1, password = l1l1ll
        else:
            raise l1ll1l11()
        logger.info(l1l111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11llll))
    l1lll1l1 = pwd.getpwuid( os.getuid())[0]
    l1lll=os.environ[l1l111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1111l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l1l1={l1l111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lll1l1, l1l111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111l11, l1l111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11llll, l1l111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll, l1l111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll1, l1l111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l1l1, temp_file)
        if not os.path.exists(os.path.join(l1111l1, l1l111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l=l1l111 (u"ࠦࡵࡿࠢࠣ")
            key=l1l111 (u"ࠧࠨࠤ")
        else:
            l1l=l1l111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l11l=l1l111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l,temp_file.name)
        l1l1l11=[l1l111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1111l1, l1l11l)]
        p = subprocess.Popen(l1l1l11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11llll
    logger.debug(l1l111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11ll=os.path.abspath(l11llll)
    logger.debug(l1l111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11ll)
    return l1ll11ll
def l1ll1111(l111l11, l1llllll, l11l11, l1l1ll1):
    l1l111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11ll1(title):
        l1111ll=30
        if len(title)>l1111ll:
            l1111l=title.split(l1l111 (u"ࠨ࠯ࠣ࠳"))
            l11ll11=l1l111 (u"ࠧࠨ࠴")
            for block in l1111l:
                l11ll11+=block+l1l111 (u"ࠣ࠱ࠥ࠵")
                if len(l11ll11) > l1111ll:
                    l11ll11+=l1l111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11ll11
        return title
    def l111ll(ll, password):
        l1l111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l111 (u"ࠧࠦࠢ࠹").join(ll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11ll1l = l1l111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11ll1l.encode())
        l1ll11l1 = [l1l111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l111111 = l1l111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l111111)
            for e in l1ll11l1:
                if e in l111111: return False
            raise l11l111(l111111, l1ll1111=l1l1lll.l111l1(), l1llllll=l1llllll)
        logger.info(l1l111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1ll1 = l1l111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l111 (u"ࠦࠧ࠿")
    os.system(l1l111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll11 = l1lll1(l111l11)
    l11llll = l1lll1(hashlib.sha1(l111l11.encode()).hexdigest()[:10])
    l1lllll1(l11llll)
    logger.info(l1l111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11llll))
    if l11l11:
        ll = [l1l111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l111 (u"ࠤ࠰ࡸࠧࡄ"), l1l111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l111 (u"ࠫ࠲ࡵࠧࡆ"), l1l111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1ll1, l11l11),
                    urllib.parse.unquote(l1llllll), os.path.abspath(l11llll)]
        l111ll(ll, password)
    else:
        while True:
            l1ll1, password = l11l1(l11llll, l1llllll, l1l1ll1)
            if l1ll1.lower() != l1l111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                ll = [l1l111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l111 (u"ࠤ࠰ࡸࠧࡋ"), l1l111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l111 (u"ࠫ࠲ࡵࠧࡍ"), l1l111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1ll1,
                            urllib.parse.unquote(l1llllll), os.path.abspath(l11llll)]
            else:
                raise l1ll1l11()
            if l111ll(ll, password): break
    os.system(l1l111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11llll, l1lll11))
    l1ll11ll=os.path.abspath(l1lll11)
    return l1ll11ll
def l11l1(l111l11, l1llllll, l1l1ll1):
    l1 = os.path.join(os.environ[l1l111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1)):
       os.makedirs(os.path.dirname(l1))
    l1lll1l = l1l1ll1.get_value(l1l111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11lll1 = l111ll1(l111l11, l1lll1l)
    l1ll1, password = l11lll1.l11111l(l1l111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1llllll + l1l111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1llllll + l1l111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1ll1 != l1l111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll111l(l111l11, l1ll1):
        l1ll11l = l1l111 (u"ࠤ࡙ࠣࠦ").join([l111l11, l1ll1, l1l111 (u"࡚ࠪࠦࠬ") + password + l1l111 (u"࡛ࠫࠧ࠭"), l1l111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1, l1l111 (u"࠭ࡷࠬࠩ࡝")) as l1ll1ll1:
            l1ll1ll1.write(l1ll11l)
        os.chmod(l1, 0o600)
    return l1ll1, password
def l1ll111l(l111l11, l1ll1):
    l1 = l1l11ll = os.path.join(os.environ[l1l111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1):
        with open(l1, l1l111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l11l = data[0].split(l1l111 (u"ࠦࠥࠨࡢ"))
            if l111l11 == l11l11l[0] and l1ll1 == l11l11l[1]:
                return True
    return False