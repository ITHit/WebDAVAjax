#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import gi
gi.require_version(l11llll (u"࠭ࡇࡵ࡭ࠪ঻"), l11llll (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l11111
import logging
logger = logging.getLogger(l11llll (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l1l11(Gtk.Window):
    def __init__(self, l1ll11lll1, l1l1llllll):
        Gtk.Window.__init__(self)
        self.l1ll11l=30
        self.l1l1l1111l = False
        self.service = l1ll11lll1
        self.l111=l1l1llllll
        self.l1l1ll=l1l11111.l1l1l1ll
        self.l1ll1l11l1 = Gtk.ListStore(str)
        self.l1l1l111l1()
    def l1l1l111ll(self, service):
        l1l11l1l1l = self.l1l1ll.l11lll1l(l11llll (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1l11l1l1l
    def l1l1l111l1(self, l1ll11lll1=None):
        if l1ll11lll1:
            self.l1ll1l11l1.clear()
            l1ll11l1l1=self.l1l1l111ll(l1ll11lll1)
            self.l1ll1l11l1.append([l11llll (u"ࠥࠦি")])
            for l111 in l1ll11l1l1:
                self.l1ll1l11l1.append([l111])
        else:
            self.l1ll1l11l1.clear()
            self.l1ll1l11l1.append([l11llll (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1l1l11l11(self, widget, data=None):
        l1l1llll11= widget.get_active()
        if data == l11llll (u"ࠧ࠷ࠢু") and l1l1llll11:
            self.l1l1l111l1()
            self.l1l1lll11l.set_active(0)
            self.l1ll111lll.set_text(l11llll (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1ll111lll.set_sensitive(False)
            self.l1l1lll11l.set_sensitive(False)
        else:
            self.l1l1l111l1(l1ll11lll1=self.service)
            self.l1l1lll11l.set_active(0)
            self.l1ll111lll.set_text(l11llll (u"ࠢࠣৃ"))
            self.l1l1lll11l.set_sensitive(True)
            self.l1ll111lll.set_sensitive(True)
    def l1ll11ll1l(self, widget):
        if widget.get_active():
            l111 = widget.get_child().get_text()
        else:
            l111 = self.l1ll1l11l1[widget.get_active()][0]
        password = self.l1l1l1ll11(self.service, l111)
        if password:
            self.l1ll111lll.set_text(password)
        else:
            self.l1ll111lll.set_text(l11llll (u"ࠣࠤৄ"))
    def l1ll1l1lll(self, l111, pwd, service):
        keyring.set_password(service, l111, pwd)
        l1l11l1l1l=self.l1l1ll.l11lll1l(l11llll (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l111 in l1l11l1l1l:
            value = self.l1l1ll.get_value(l11llll (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l1l1ll.l11lllll(l11llll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l11llll (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l111))
    def l1l1l1ll11(self, service, l111):
        l1l1l11l1l = keyring.get_password(service, l111)
        return l1l1l11l1l
    def l1l1l1l11l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l11ll1l1(self, widget, data=None):
        self.l1l1l1111l=widget.get_active()
    def l11l1l(self, message, title=l11llll (u"࠭ࠧ৉"), l111l1l11=True):
        if l111l1l11:
            l1l11ll1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11ll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l11llll1 = Gtk.MessageDialog(self,
            l1l11ll1ll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l11llll1.set_title(title)
        l1l11llll1.set_default_response(Gtk.ResponseType.OK)
        l1l1l11ll1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll1l1ll1 = Gtk.VBox()
        l1l1lll1ll = Gtk.Box(spacing=1)
        l1l1lll1ll.set_homogeneous(False)
        l1ll1ll1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1ll1l1.set_homogeneous(False)
        l1ll11l111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11l111.set_homogeneous(False)
        l1l1lll1ll.pack_start(l1ll1ll1l1, True, True, 0)
        l1l1lll1ll.pack_start(l1ll11l111, True, True, 0)
        l1l1ll11l1 = l1l11llll1.get_content_area()
        l1l1l1ll1l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1ll11l1.pack_start(l1l1l1ll1l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll11111l = Gtk.Label()
        l1l1ll11ll = Gtk.Label()
        l1l1ll11ll.set_text(l11llll (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1l1ll11ll, True, True, 0)
        l1ll11111l.set_text(l11llll (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1ll11111l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll11111l, 0, 1, 0, 1)
        l1l1ll1l1l = Gtk.RadioButton.new_with_label_from_widget(None, l11llll (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1l1ll1l1l.connect(l11llll (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1l1l11l11, l11llll (u"ࠦ࠶ࠨৎ"))
        table.attach(l1l1ll1l1l, 1, 2, 0, 1)
        l1ll1l1l11 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1l1l, l11llll (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1ll1l1l11.connect(l11llll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1l1l11l11, l11llll (u"ࠢ࠳ࠤ৑"))
        table.attach(l1ll1l1l11, 1, 2, 1, 2)
        l1l1lllll1 = Gtk.Label()
        l1l1lllll1.set_text(l11llll (u"ࠣࠢࠥ৒"))
        table.attach(l1l1lllll1, 0, 1, 4, 6)
        l1ll1ll11l = Gtk.Label()
        l1ll1ll11l.set_text(l11llll (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1ll1ll11l.set_justify(Gtk.Justification.RIGHT)
        l1ll1ll11l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1lll11l = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1l11l1)
        self.l1l1lll11l.set_entry_text_column(0)
        table.attach(l1ll1ll11l, 0, 1, 6, 8)
        table.attach(self.l1l1lll11l, 1, 3, 6, 8)
        self.l1l1lll11l.connect(l11llll (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1ll11ll1l)
        l1ll1l11ll = Gtk.Label()
        l1ll1l11ll.set_text(l11llll (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1ll1l11ll.set_justify(Gtk.Justification.RIGHT)
        l1ll1l11ll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll111lll = Gtk.Entry()
        self.l1ll111lll.set_visibility(False)
        self.l1ll111lll.connect(l11llll (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1l1l1l11l, l1l11llll1)
        table.attach(l1ll1l11ll, 0, 1, 8, 10)
        table.attach(self.l1ll111lll, 1, 3, 8, 10)
        l1ll1lllll = Gtk.CheckButton(l11llll (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1ll1lllll.connect(l11llll (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1l11ll1l1, l1ll1lllll)
        l1ll1lllll.set_active(False)
        table.attach(l1ll1lllll, 1, 3, 12, 14)
        l1l1l11111 = Gtk.Label()
        l1l1l11111.set_text(l11llll (u"ࠣࠢࠥ৙") * 5)
        l1ll1l1ll1.pack_start(l1l1l11111, True, True, 0)
        if self.l111:
            l1ll1l1l11.set_active(True)
            self.l1l1lll11l.set_active(0)
            self.l1l1lll11l.set_sensitive(True)
            self.l1ll111lll.set_text(l11llll (u"ࠤࠥ৚"))
            self.l1ll111lll.set_sensitive(True)
        else:
            self.l1l1lll11l.set_active(0)
            self.l1l1lll11l.set_sensitive(False)
            self.l1ll111lll.set_text(l11llll (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1ll111lll.set_sensitive(False)
        l1l1l11ll1.pack_start(vbox, True, True, 0)
        l1l1l11ll1.pack_start(table, True, True, 0)
        l1l1l11ll1.pack_end(l1ll1l1ll1, True, True, 0)
        l1l1l1ll1l.pack_start(l1l1l11ll1, True, True, 0)
        l1l11llll1.show_all()
        response = l1l11llll1.run()
        if self.l1l1lll11l.get_active():
            l111 = self.l1l1lll11l.get_child().get_text()
        else:
            l111 = self.l1ll1l11l1[self.l1l1lll11l.get_active()][0]
        pwd = self.l1ll111lll.get_text()
        l1l11llll1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1l1111l:
                self.l1ll1l1lll(l111, pwd, self.service)
            return l111, pwd
        else:
            return l11llll (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l11llll (u"ࠬ࠭ঢ়")
class l1l11l11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1111l1(self, l1l1ll11):
        l1l1ll1111 = Gtk.ScrolledWindow()
        l1l1ll1111.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11l11l=None
        self.l1l11l1ll1 = Gtk.TextBuffer()
        self.l1l11l1ll1.set_text(l1l1ll11)
        self.set_style()
        regexp= l11llll (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll1lll11 = self._1ll1l1111(l1l1ll11, regexp)
        self.l1l1l1l1ll(l1ll1lll11, self.l1l11l1ll1.get_start_iter())
        self.l1ll111l11 = Gtk.TextView(buffer=self.l1l11l1ll1)
        self.l1ll111l11.set_property(l11llll (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1ll111l11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll111l11.connect(l11llll (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1ll1lll1l)
        self.l1ll111l11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1ll1111.set_size_request(300,100)
        self.l1ll111l11.show()
        l1l1ll1111.add(self.l1ll111l11)
        l1l1ll1111.show()
        return l1l1ll1111
    def _1ll1lll1l(self, *args, **kwargs):
        l1l1lll111, l1ll1111ll=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1lll111, l1ll1111ll).get_tags()
        if not self.l1ll11l11l:
            self.l1ll11l11l = args[1].window.get_cursor()
            self.l1ll11ll11 = Gdk.Cursor(Gdk.CursorType.l1l11ll11l)
        elif tag:
            args[1].window.set_cursor(self.l1ll11ll11)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11l11l:
                args[1].window.set_cursor(self.l1ll11l11l)
    def _1ll1l1111(self, l1l1ll11, l1l1ll1lll):
        res=[]
        l1lll11111=re.findall(l1l1ll1lll,l1l1ll11)
        for l1l1l1lll1 in l1lll11111:
            for el in l1l1l1lll1:
                if el:
                    res.append(el)
        return res
    def l1l1l1l1ll(self, l1ll1lll11, start):
        l1l1l11lll=0
        for text in l1ll1lll11:
            end = self.l1l11l1ll1.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l11lll+=1
                l1ll1llll1, l1l1lll1l1 = match
                tag = self.l1l11l1ll1.create_tag(str(l1l1l11lll), foreground=l11llll (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l11llll (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1l11l1lll, text)
                self.l1l11l1ll1.apply_tag(tag, l1ll1llll1, l1l1lll1l1)
                self.l1l1l1l1ll(l1ll1lll11, l1l1lll1l1)
    def _1l11l1lll(self, tag, widget, l1ll111l1l, _1l1l1l1l1, text):
        _1ll1l111l = l1ll111l1l.type
        _1l11lllll = l1ll111l1l.window
        if _1ll1l111l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll1l111l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll111l1l.button
            self.l1ll11l11l = Gdk.Cursor(Gdk.CursorType.l1l11ll11l)
            if _1ll1l111l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l11llll (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l111lllll(self, message, title=l11llll (u"ࠬ࠭৤"), l111l1l11=True, l1ll1ll111=None):
        if l111l1l11:
            l1l11ll1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11ll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l11ll1ll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll1ll111:
            l1l1ll11l1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1lll1ll = Gtk.HBox(spacing=0)
            l1ll111111 = Gtk.HBox(spacing=5)
            l1l11lll1l = Gtk.Label()
            l1l11lll1l.set_markup(l11llll (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1l11lll1l.set_line_wrap(True)
            l1l11lll1l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l11llll (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll111ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111ll1.show()
            l1ll1l1l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l1l.show()
            l1ll11llll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11llll.show()
            l1l1lll1ll.pack_start(separator, True, True, 0)
            l1l1lll1ll.pack_start(l1ll111ll1, True, True, 0)
            l1l1lll1ll.pack_start(l1ll1l1l1l, True, True, 0)
            l1l1lll1ll.pack_start(l1ll11llll, True, True, 0)
            l1l1lll1ll.pack_start(l1l11lll1l, False, True, 0)
            l1l1llll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1llll1l.show()
            l1l1lll1ll.pack_end(l1l1llll1l, True, True, 0)
            l1l1ll1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1ll1.show()
            vbox.pack_start(l1l1lll1ll, True, True, 0)
            l1l1ll1111=self.__1ll1111l1(l1l1ll11=l1ll1ll111)
            vbox.pack_start(l1l1ll1111, False, False, 0)
            vbox.pack_end(l1l1ll1ll1, False, False, 0)
            l1ll111111.pack_start(vbox, True, True,5)
            l1ll111111.show()
            l1l1ll11l1.pack_end(l1ll111111, False, False, 0)
            vbox.show()
            l1l1lll1ll.show()
        window.run()
class l1ll1ll1l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11ll111(self, widget, l1ll11l1ll):
        if l1ll11l1ll == Gtk.ResponseType.OK:
            self.result = l11llll (u"ࠣࡑࡎࠦ১")
        elif l1ll11l1ll == Gtk.ResponseType.CANCEL:
            self.result = l11llll (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1ll11l1ll == Gtk.ResponseType.DELETE_EVENT:
            self.result = l11llll (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1ll1lll1(self, title=l11llll (u"ࠦࠧ৪"), message=l11llll (u"ࠧࠨ৫") , l111l1l11=True):
        if l111l1l11:
            l1l11ll1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11ll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11ll1ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l11llll (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1l11ll111)
        window.run()
class l1l1ll1l11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1llll=None
        self.result = None
    def l1l11ll111(self, widget, l1ll11l1ll):
        print(widget, l1ll11l1ll)
        if l1ll11l1ll == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll11l1ll == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll11l1ll == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l11ll1l1(self, widget, l1l1ll111l):
        if l1l1ll111l.get_active():
            self.l1l1l1llll = 1
        else:
            self.l1l1l1llll = 0
    def l1l1l1l111(self, title=l11llll (u"ࠢࠣ৭"), message=l11llll (u"ࠣࠤ৮"), l1l11lll11 =l11llll (u"ࠤࠥ৯"),l111l1l11=True):
        if l111l1l11:
            l1l11ll1ll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11ll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11ll1ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l11llll (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1l11ll111)
        l1ll1lllll = Gtk.CheckButton(l1l11lll11)
        l1ll1lllll.connect(l11llll (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1l11ll1l1, l1ll1lllll)
        l1ll1lllll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll1lllll, expand=True, fill=True, padding=0)
        l1ll1lllll.show()
        window.run()
def l1l111l11(title, msg, l1l11lll11=l11llll (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l111l1l11=True):
    result=None
    try:
        l1lll1111l = l1l1ll1l11()
        l1lll1111l.l1l1l1l111(title, msg, l1l11lll11, l111l1l11)
        result = {l11llll (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1lll1111l.result,  l11llll (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1lll1111l.l1l1l1llll}
    except Exception as e:
        logger.exception(l11llll (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l11llll (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l111ll1ll = l1l11l11l()
    message= l11llll (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1ll1ll1ll = l11llll (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l111ll1ll.l111lllll(message, l11llll (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l111l1l11=True, l1ll1ll111=l1ll1ll1ll)