#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import logging
import os
import re
from l1l1111 import l1lll1l1l
logger = logging.getLogger(l1l11l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1111ll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l11l (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111():
    try:
        out = os.popen(l1l11l (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1l11l (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1l11l (u"ࠢࠣॶ").join(result)
                logger.info(l1l11l (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1l11l (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1l11l (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1l11l (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1lll1l1l(l1l11l (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1l11l (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1111ll(l1l11l (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))