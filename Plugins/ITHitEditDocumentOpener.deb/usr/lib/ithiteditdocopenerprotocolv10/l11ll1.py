#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import gi
gi.require_version(l1ll11l1 (u"࠭ࡇࡵ࡭ࠪ঻"), l1ll11l1 (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1l1l1
import logging
logger = logging.getLogger(l1ll11l1 (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l1llll11(Gtk.Window):
    def __init__(self, l1l1ll11ll, l1l1l1l1l1):
        Gtk.Window.__init__(self)
        self.l1llllll=30
        self.l1l1llllll = False
        self.service = l1l1ll11ll
        self.l11111=l1l1l1l1l1
        self.l1lll1ll=l1l1l1l1.l11ll11l
        self.l1l1l1ll1l = Gtk.ListStore(str)
        self.l1l1l1l11l()
    def l1l1lll111(self, service):
        l1ll1l111l = self.l1lll1ll.l11ll1l1(l1ll11l1 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1ll1l111l
    def l1l1l1l11l(self, l1l1ll11ll=None):
        if l1l1ll11ll:
            self.l1l1l1ll1l.clear()
            l1l1l11ll1=self.l1l1lll111(l1l1ll11ll)
            self.l1l1l1ll1l.append([l1ll11l1 (u"ࠥࠦি")])
            for l11111 in l1l1l11ll1:
                self.l1l1l1ll1l.append([l11111])
        else:
            self.l1l1l1ll1l.clear()
            self.l1l1l1ll1l.append([l1ll11l1 (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1l1ll1ll1(self, widget, data=None):
        l1l1l11l1l= widget.get_active()
        if data == l1ll11l1 (u"ࠧ࠷ࠢু") and l1l1l11l1l:
            self.l1l1l1l11l()
            self.l1ll1l1111.set_active(0)
            self.l1ll1ll1ll.set_text(l1ll11l1 (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1ll1ll1ll.set_sensitive(False)
            self.l1ll1l1111.set_sensitive(False)
        else:
            self.l1l1l1l11l(l1l1ll11ll=self.service)
            self.l1ll1l1111.set_active(0)
            self.l1ll1ll1ll.set_text(l1ll11l1 (u"ࠢࠣৃ"))
            self.l1ll1l1111.set_sensitive(True)
            self.l1ll1ll1ll.set_sensitive(True)
    def l1ll1l11l1(self, widget):
        if widget.get_active():
            l11111 = widget.get_child().get_text()
        else:
            l11111 = self.l1l1l1ll1l[widget.get_active()][0]
        password = self.l1ll1lll1l(self.service, l11111)
        if password:
            self.l1ll1ll1ll.set_text(password)
        else:
            self.l1ll1ll1ll.set_text(l1ll11l1 (u"ࠣࠤৄ"))
    def l1l1l111l1(self, l11111, pwd, service):
        keyring.set_password(service, l11111, pwd)
        l1ll1l111l=self.l1lll1ll.l11ll1l1(l1ll11l1 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l11111 in l1ll1l111l:
            value = self.l1lll1ll.get_value(l1ll11l1 (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l1lll1ll.l11ll1ll(l1ll11l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l1ll11l1 (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l11111))
    def l1ll1lll1l(self, service, l11111):
        l1l11l1l1l = keyring.get_password(service, l11111)
        return l1l11l1l1l
    def l1l1l1ll11(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l11l1ll1(self, widget, data=None):
        self.l1l1llllll=widget.get_active()
    def l11llll(self, message, title=l1ll11l1 (u"࠭ࠧ৉"), l1ll1111l=True):
        if l1ll1111l:
            l1l1lll11l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll111l11 = Gtk.MessageDialog(self,
            l1l1lll11l,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll111l11.set_title(title)
        l1ll111l11.set_default_response(Gtk.ResponseType.OK)
        l1l1lllll1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll1ll11l = Gtk.VBox()
        l1ll1ll1l1 = Gtk.Box(spacing=1)
        l1ll1ll1l1.set_homogeneous(False)
        l1l1l1111l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1111l.set_homogeneous(False)
        l1ll11111l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11111l.set_homogeneous(False)
        l1ll1ll1l1.pack_start(l1l1l1111l, True, True, 0)
        l1ll1ll1l1.pack_start(l1ll11111l, True, True, 0)
        l1l11lllll = l1ll111l11.get_content_area()
        l1l1lll1ll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l11lllll.pack_start(l1l1lll1ll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l11ll1l1 = Gtk.Label()
        l1ll11l11l = Gtk.Label()
        l1ll11l11l.set_text(l1ll11l1 (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1ll11l11l, True, True, 0)
        l1l11ll1l1.set_text(l1ll11l1 (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1l11ll1l1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l11ll1l1, 0, 1, 0, 1)
        l1ll11l1l1 = Gtk.RadioButton.new_with_label_from_widget(None, l1ll11l1 (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1ll11l1l1.connect(l1ll11l1 (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1l1ll1ll1, l1ll11l1 (u"ࠦ࠶ࠨৎ"))
        table.attach(l1ll11l1l1, 1, 2, 0, 1)
        l1l1l11111 = Gtk.RadioButton.new_with_label_from_widget(l1ll11l1l1, l1ll11l1 (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1l1l11111.connect(l1ll11l1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1l1ll1ll1, l1ll11l1 (u"ࠢ࠳ࠤ৑"))
        table.attach(l1l1l11111, 1, 2, 1, 2)
        l1l1ll1l1l = Gtk.Label()
        l1l1ll1l1l.set_text(l1ll11l1 (u"ࠣࠢࠥ৒"))
        table.attach(l1l1ll1l1l, 0, 1, 4, 6)
        l1ll1111l1 = Gtk.Label()
        l1ll1111l1.set_text(l1ll11l1 (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1ll1111l1.set_justify(Gtk.Justification.RIGHT)
        l1ll1111l1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1l1111 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1ll1l)
        self.l1ll1l1111.set_entry_text_column(0)
        table.attach(l1ll1111l1, 0, 1, 6, 8)
        table.attach(self.l1ll1l1111, 1, 3, 6, 8)
        self.l1ll1l1111.connect(l1ll11l1 (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1ll1l11l1)
        l1l1ll1111 = Gtk.Label()
        l1l1ll1111.set_text(l1ll11l1 (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1l1ll1111.set_justify(Gtk.Justification.RIGHT)
        l1l1ll1111.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1ll1ll = Gtk.Entry()
        self.l1ll1ll1ll.set_visibility(False)
        self.l1ll1ll1ll.connect(l1ll11l1 (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1l1l1ll11, l1ll111l11)
        table.attach(l1l1ll1111, 0, 1, 8, 10)
        table.attach(self.l1ll1ll1ll, 1, 3, 8, 10)
        l1ll1l1l11 = Gtk.CheckButton(l1ll11l1 (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1ll1l1l11.connect(l1ll11l1 (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1l11l1ll1, l1ll1l1l11)
        l1ll1l1l11.set_active(False)
        table.attach(l1ll1l1l11, 1, 3, 12, 14)
        l1ll1ll111 = Gtk.Label()
        l1ll1ll111.set_text(l1ll11l1 (u"ࠣࠢࠥ৙") * 5)
        l1ll1ll11l.pack_start(l1ll1ll111, True, True, 0)
        if self.l11111:
            l1l1l11111.set_active(True)
            self.l1ll1l1111.set_active(0)
            self.l1ll1l1111.set_sensitive(True)
            self.l1ll1ll1ll.set_text(l1ll11l1 (u"ࠤࠥ৚"))
            self.l1ll1ll1ll.set_sensitive(True)
        else:
            self.l1ll1l1111.set_active(0)
            self.l1ll1l1111.set_sensitive(False)
            self.l1ll1ll1ll.set_text(l1ll11l1 (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1ll1ll1ll.set_sensitive(False)
        l1l1lllll1.pack_start(vbox, True, True, 0)
        l1l1lllll1.pack_start(table, True, True, 0)
        l1l1lllll1.pack_end(l1ll1ll11l, True, True, 0)
        l1l1lll1ll.pack_start(l1l1lllll1, True, True, 0)
        l1ll111l11.show_all()
        response = l1ll111l11.run()
        if self.l1ll1l1111.get_active():
            l11111 = self.l1ll1l1111.get_child().get_text()
        else:
            l11111 = self.l1l1l1ll1l[self.l1ll1l1111.get_active()][0]
        pwd = self.l1ll1ll1ll.get_text()
        l1ll111l11.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1llllll:
                self.l1l1l111l1(l11111, pwd, self.service)
            return l11111, pwd
        else:
            return l1ll11l1 (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l1ll11l1 (u"ࠬ࠭ঢ়")
class l11l111ll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1ll1lll(self, l1l1l11l):
        l1ll11llll = Gtk.ScrolledWindow()
        l1ll11llll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll1l1ll1=None
        self.l1ll1l11ll = Gtk.TextBuffer()
        self.l1ll1l11ll.set_text(l1l1l11l)
        self.set_style()
        regexp= l1ll11l1 (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll1l1lll = self._1ll11l111(l1l1l11l, regexp)
        self.l1ll1llll1(l1ll1l1lll, self.l1ll1l11ll.get_start_iter())
        self.l1l1ll1l11 = Gtk.TextView(buffer=self.l1ll1l11ll)
        self.l1l1ll1l11.set_property(l1ll11l1 (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1l1ll1l11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1ll1l11.connect(l1ll11l1 (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1l1lll1l1)
        self.l1l1ll1l11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll11llll.set_size_request(300,100)
        self.l1l1ll1l11.show()
        l1ll11llll.add(self.l1l1ll1l11)
        l1ll11llll.show()
        return l1ll11llll
    def _1l1lll1l1(self, *args, **kwargs):
        l1l11llll1, l1ll1l1l1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l11llll1, l1ll1l1l1l).get_tags()
        if not self.l1ll1l1ll1:
            self.l1ll1l1ll1 = args[1].window.get_cursor()
            self.l1l1l11lll = Gdk.Cursor(Gdk.CursorType.l1ll1lll11)
        elif tag:
            args[1].window.set_cursor(self.l1l1l11lll)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll1l1ll1:
                args[1].window.set_cursor(self.l1ll1l1ll1)
    def _1ll11l111(self, l1l1l11l, l1l1ll11l1):
        res=[]
        l1l1l1lll1=re.findall(l1l1ll11l1,l1l1l11l)
        for l1l1l11l11 in l1l1l1lll1:
            for el in l1l1l11l11:
                if el:
                    res.append(el)
        return res
    def l1ll1llll1(self, l1ll1l1lll, start):
        l1ll1lllll=0
        for text in l1ll1l1lll:
            end = self.l1ll1l11ll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1lllll+=1
                l1lll11111, l1ll111l1l = match
                tag = self.l1ll1l11ll.create_tag(str(l1ll1lllll), foreground=l1ll11l1 (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1ll11l1 (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1l11ll1ll, text)
                self.l1ll1l11ll.apply_tag(tag, l1lll11111, l1ll111l1l)
                self.l1ll1llll1(l1ll1l1lll, l1ll111l1l)
    def _1l11ll1ll(self, tag, widget, l1ll11lll1, _1l11ll11l, text):
        _1l1l1l1ll = l1ll11lll1.type
        _1l1llll11 = l1ll11lll1.window
        if _1l1l1l1ll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l1l1ll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll11lll1.button
            self.l1ll1l1ll1 = Gdk.Cursor(Gdk.CursorType.l1ll1lll11)
            if _1l1l1l1ll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1ll11l1 (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1l11l11l(self, message, title=l1ll11l1 (u"ࠬ࠭৤"), l1ll1111l=True, l1l11lll1l=None):
        if l1ll1111l:
            l1l1lll11l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1lll11l,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l11lll1l:
            l1l11lllll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1ll1l1 = Gtk.HBox(spacing=0)
            l1ll11ll1l = Gtk.HBox(spacing=5)
            l1ll11l1ll = Gtk.Label()
            l1ll11l1ll.set_markup(l1ll11l1 (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1ll11l1ll.set_line_wrap(True)
            l1ll11l1ll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1ll11l1 (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll111111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111111.show()
            l1ll111lll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111lll.show()
            l1ll1111ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1111ll.show()
            l1ll1ll1l1.pack_start(separator, True, True, 0)
            l1ll1ll1l1.pack_start(l1ll111111, True, True, 0)
            l1ll1ll1l1.pack_start(l1ll111lll, True, True, 0)
            l1ll1ll1l1.pack_start(l1ll1111ll, True, True, 0)
            l1ll1ll1l1.pack_start(l1ll11l1ll, False, True, 0)
            l1l1l111ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l111ll.show()
            l1ll1ll1l1.pack_end(l1l1l111ll, True, True, 0)
            l1l1llll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1llll1l.show()
            vbox.pack_start(l1ll1ll1l1, True, True, 0)
            l1ll11llll=self.__1l1ll1lll(l1l1l11l=l1l11lll1l)
            vbox.pack_start(l1ll11llll, False, False, 0)
            vbox.pack_end(l1l1llll1l, False, False, 0)
            l1ll11ll1l.pack_start(vbox, True, True,5)
            l1ll11ll1l.show()
            l1l11lllll.pack_end(l1ll11ll1l, False, False, 0)
            vbox.show()
            l1ll1ll1l1.show()
        window.run()
class l111l11ll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111ll1(self, widget, l1l1l1l111):
        if l1l1l1l111 == Gtk.ResponseType.OK:
            self.result = l1ll11l1 (u"ࠣࡑࡎࠦ১")
        elif l1l1l1l111 == Gtk.ResponseType.CANCEL:
            self.result = l1ll11l1 (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1l1l1l111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1ll11l1 (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l111l111l(self, title=l1ll11l1 (u"ࠦࠧ৪"), message=l1ll11l1 (u"ࠧࠨ৫") , l1ll1111l=True):
        if l1ll1111l:
            l1l1lll11l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll11l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1ll11l1 (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1ll111ll1)
        window.run()
class l1ll11ll11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1lll1111l=None
        self.result = None
    def l1ll111ll1(self, widget, l1l1l1l111):
        print(widget, l1l1l1l111)
        if l1l1l1l111 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l1l111 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l1l111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l11l1ll1(self, widget, l1l1l1llll):
        if l1l1l1llll.get_active():
            self.l1lll1111l = 1
        else:
            self.l1lll1111l = 0
    def l1l1ll111l(self, title=l1ll11l1 (u"ࠢࠣ৭"), message=l1ll11l1 (u"ࠣࠤ৮"), l1l11ll111 =l1ll11l1 (u"ࠤࠥ৯"),l1ll1111l=True):
        if l1ll1111l:
            l1l1lll11l= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll11l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll11l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1ll11l1 (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1ll111ll1)
        l1ll1l1l11 = Gtk.CheckButton(l1l11ll111)
        l1ll1l1l11.connect(l1ll11l1 (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1l11l1ll1, l1ll1l1l11)
        l1ll1l1l11.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll1l1l11, expand=True, fill=True, padding=0)
        l1ll1l1l11.show()
        window.run()
def l1111llll(title, msg, l1l11ll111=l1ll11l1 (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l1ll1111l=True):
    result=None
    try:
        l1l11l1lll = l1ll11ll11()
        l1l11l1lll.l1l1ll111l(title, msg, l1l11ll111, l1ll1111l)
        result = {l1ll11l1 (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1l11l1lll.result,  l1ll11l1 (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1l11l1lll.l1lll1111l}
    except Exception as e:
        logger.exception(l1ll11l1 (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l1ll11l1 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l11ll1111 = l11l111ll()
    message= l1ll11l1 (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1l11lll11 = l1ll11l1 (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l11ll1111.l1l11l11l(message, l1ll11l1 (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l1ll1111l=True, l1l11lll1l=l1l11lll11)