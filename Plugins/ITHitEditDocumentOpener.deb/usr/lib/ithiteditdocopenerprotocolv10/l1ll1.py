#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l11l = 2048
l1l1l11 = 7
def l111l11 (l1ll):
    global l11lll
    l1ll1l1l = ord (l1ll [-1])
    l11ll1l = l1ll [:-1]
    l1l1 = l1ll1l1l % len (l11ll1l)
    l11l1ll = l11ll1l [:l1l1] + l11ll1l [l1l1:]
    if l1ll1ll:
        l1l11l1 = l1ll1ll1 () .join ([unichr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    return eval (l1l11l1)
import hashlib
import os
import l1lll1ll
from l1llllll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll1ll import l11lll1
from l1lll1l import l111ll1, l1lll11
import logging
logger = logging.getLogger(l111l11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111():
    def __init__(self, l1l1ll1,l1l1l1, l111l1l= None, l11ll1=None):
        self.l1l111=False
        self.l1ll11 = self._111111()
        self.l1l1l1 = l1l1l1
        self.l111l1l = l111l1l
        self.l1l1l = l1l1ll1
        if l111l1l:
            self.l1ll1l1 = True
        else:
            self.l1ll1l1 = False
        self.l11ll1 = l11ll1
    def _111111(self):
        try:
            return l1lll1ll.l111l1() is not None
        except:
            return False
    def open(self):
        l111l11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll11:
            raise NotImplementedError(l111l11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111l11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll11l = self.l1l1l
        if self.l1l1l1.lower().startswith(self.l1l1l.lower()):
            l111ll = re.compile(re.escape(self.l1l1l), re.IGNORECASE)
            l1l1l1 = l111ll.sub(l111l11 (u"ࠨࠩࠄ"), self.l1l1l1)
            l1l1l1 = l1l1l1.replace(l111l11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l111l11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll111(self.l1l1l, l1ll11l, l1l1l1, self.l111l1l)
    def l1lll111(self,l1l1l, l1ll11l, l1l1l1, l111l1l):
        l111l11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111l11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1111 = l111l(l1l1l)
        l11ll = self.l1llll1(l1l1111)
        logger.info(l111l11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1111)
        if l11ll:
            logger.info(l111l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11lll1(l1l1111)
            l1l1111 = l11ll11(l1l1l, l1ll11l, l111l1l, self.l11ll1)
        logger.debug(l111l11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1111l=l1l1111 + l111l11 (u"ࠤ࠲ࠦࠌ") + l1l1l1
        l1ll11l1 = l111l11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1111l+ l111l11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll11l1)
        l1ll1l11 = os.system(l1ll11l1)
        if (l1ll1l11 != 0):
            raise IOError(l111l11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1111l, l1ll1l11))
    def l1llll1(self, l1l1111):
        if os.path.exists(l1l1111):
            if os.path.islink(l1l1111):
                l1l1111 = os.readlink(l1l1111)
            if os.path.ismount(l1l1111):
                return True
        return False
def l111l(l1l1l):
    l1ll11ll = l1l1l.replace(l111l11 (u"࠭࡜࡝ࠩࠐ"), l111l11 (u"ࠧࡠࠩࠑ")).replace(l111l11 (u"ࠨ࠱ࠪࠒ"), l111l11 (u"ࠩࡢࠫࠓ"))
    l1l = l111l11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1111ll=os.environ[l111l11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l11l=os.path.join(l1111ll,l1l, l1ll11ll)
    l1l1l1l=os.path.abspath(l11l11l)
    return l1l1l1l
def l1l111l(l1):
    if not os.path.exists(l1):
        os.makedirs(l1)
def l1llll(l1l1l, l1ll11l, l1l11=None, password=None):
    l111l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1 = l111l(l1l1l)
    l1l111l(l1)
    if not l1l11:
        l11111l = l11111()
        ll =l11111l.l11(l111l11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll11l + l111l11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll11l + l111l11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(ll, str):
            l1l11, password = ll
        else:
            raise l1lll11()
        logger.info(l111l11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1))
    l1ll111 = pwd.getpwuid( os.getuid())[0]
    l1lll1=os.environ[l111l11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l111={l111l11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll111, l111l11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1l, l111l11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1, l111l11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll1, l111l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l11, l111l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l111, temp_file)
        if not os.path.exists(os.path.join(l1llll1l, l111l11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1l=l111l11 (u"ࠦࡵࡿࠢࠣ")
            key=l111l11 (u"ࠧࠨࠤ")
        else:
            l1ll1l=l111l11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111l11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1llll11=l111l11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1l,temp_file.name)
        l11l1l=[l111l11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111l11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll1l, l1llll11)]
        p = subprocess.Popen(l11l1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111l11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111l11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111l11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1
    logger.debug(l111l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1l1l=os.path.abspath(l1)
    logger.debug(l111l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1l1l)
    return l1l1l1l
def l11ll11(l1l1l, l1ll11l, l111l1l, l11ll1):
    l111l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lllll1(title):
        l1l11l=30
        if len(title)>l1l11l:
            l1lll11l=title.split(l111l11 (u"ࠨ࠯ࠣ࠳"))
            l1lllll=l111l11 (u"ࠧࠨ࠴")
            for block in l1lll11l:
                l1lllll+=block+l111l11 (u"ࠣ࠱ࠥ࠵")
                if len(l1lllll) > l1l11l:
                    l1lllll+=l111l11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lllll
        return title
    l1l11 = l111l11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l111l11 (u"ࠦࠧ࠸")
    os.system(l111l11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1l11ll = l111l(l1l1l)
    l1 = l111l(hashlib.sha1(l1l1l.encode()).hexdigest()[:10])
    l1l111l(l1)
    logger.info(l111l11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1))
    if l111l1l:
        l1111 = [l111l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l111l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l111l11 (u"ࠤ࠰ࡸࠧ࠽"), l111l11 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l111l11 (u"ࠫ࠲ࡵࠧ࠿"), l111l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1l11, l111l1l),
                    urllib.parse.unquote(l1ll11l), os.path.abspath(l1)]
    else:
        l1l11, password = l11l11(l1, l1ll11l, l11ll1)
        if l1l11.lower() != l111l11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1111 = [l111l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111l11 (u"ࠤ࠰ࡸࠧࡄ"), l111l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111l11 (u"ࠫ࠲ࡵࠧࡆ"), l111l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1l11,
                        urllib.parse.unquote(l1ll11l), os.path.abspath(l1)]
        else:
            raise l1lll11()
    logger.info(l111l11 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l111l11 (u"ࠢࠡࠤࡉ").join(l1111)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11llll = l111l11 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11llll.encode())
    if len(err) > 0:
        l111lll = l111l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l111lll)
        raise l111ll1(l111lll, l11ll11=l1lll1ll.l111l1(), l1ll11l=l1ll11l)
    logger.info(l111l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l111l11 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1, l1l11ll))
    l1l1l1l=os.path.abspath(l1l11ll)
    return l1l1l1l
def l11l11(l1l1l, l1ll11l, l11ll1):
    l1ll1lll = os.path.join(os.environ[l111l11 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l111l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l111l11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1ll1lll)):
       os.makedirs(os.path.dirname(l1ll1lll))
    l1lll1l1 = l11ll1.get_value(l111l11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l111l11 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l11111l = l11111(l1l1l, l1lll1l1)
    l1l11, password = l11111l.l11(l111l11 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1ll11l + l111l11 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1ll11l + l111l11 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1l11 != l111l11 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l11l1(l1l1l, l1l11):
        l1l1ll = l111l11 (u"ࠢࠡࠤࡗ").join([l1l1l, l1l11, l111l11 (u"ࠨࠤࠪࡘ") + password + l111l11 (u"࡙ࠩࠥࠫ"), l111l11 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1ll1lll, l111l11 (u"ࠫࡼ࠱࡛ࠧ")) as l11l1l1:
            l11l1l1.write(l1l1ll)
        os.chmod(l1ll1lll, 0o600)
    return l1l11, password
def l11l1(l1l1l, l1l11):
    l1ll1lll = l1111l1 = os.path.join(os.environ[l111l11 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l111l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l111l11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1ll1lll):
        with open(l1ll1lll, l111l11 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1lll = data[0].split(l111l11 (u"ࠤࠣࠦࡠ"))
            if l1l1l == l1lll[0] and l1l11 == l1lll[1]:
                return True
    return False