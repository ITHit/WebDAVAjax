#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l11111l = 7
def l1ll11l (l1lll1l1):
    global l111111
    l1ll1l1 = ord (l1lll1l1 [-1])
    l1ll111 = l1lll1l1 [:-1]
    l11l1 = l1ll1l1 % len (l1ll111)
    l1l1111 = l1ll111 [:l11l1] + l1ll111 [l11l1:]
    if l11ll1:
        l1ll11 = l1llll1l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    return eval (l1ll11)
import re
class l1l1l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1ll1 = kwargs.get(l1ll11l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1111l1 = kwargs.get(l1ll11l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll1l11 = self.l111111l(args)
        if l1lll1l11:
            args=args+ l1lll1l11
        self.args = [a for a in args]
    def l111111l(self, *args):
        l1lll1l11=None
        l1l11l11 = args[0][0]
        if re.search(l1ll11l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11l11):
            l1lll1l11 = (l1ll11l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1ll1
                            ,)
        return l1lll1l11
class l1111111(Exception):
    def __init__(self, *args, **kwargs):
        l1lll1l11 = self.l111111l(args)
        if l1lll1l11:
            args = args + l1lll1l11
        self.args = [a for a in args]
    def l111111l(self, *args):
        s = l1ll11l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll11l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll1ll(Exception):
    pass
class l1lllll(Exception):
    pass
class l1llll11l(Exception):
    def __init__(self, message, l1lll11ll, url):
        super(l1llll11l,self).__init__(message)
        self.l1lll11ll = l1lll11ll
        self.url = url
class l11111l1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l111l1ll(Exception):
    pass