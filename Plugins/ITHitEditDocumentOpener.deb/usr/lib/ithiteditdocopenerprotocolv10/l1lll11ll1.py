#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1l111l = 7
def l1ll1l1l (l11ll1l):
    global l1l11
    l1 = ord (l11ll1l [-1])
    l1lll = l11ll1l [:-1]
    l1lllll = l1 % len (l1lll)
    l1lll11 = l1lll [:l1lllll] + l1lll [l1lllll:]
    if l1l1ll1:
        l1l11l = l111l11 () .join ([unichr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    return eval (l1l11l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1111=logging.WARNING
logger = logging.getLogger(l1ll1l1l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llll1111)
l1l11l11 = SysLogHandler(address=l1ll1l1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll1l1l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l11l11)
ch = logging.StreamHandler()
ch.setLevel(l1llll1111)
logger.addHandler(ch)
class l1llll11l1(io.FileIO):
    l1ll1l1l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll1l1l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1ll1l, l1lllll1ll,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll1l = l1lll1ll1l
            self.l1lllll1ll = l1lllll1ll
            if not options:
                options = l1ll1l1l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll1l1l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1ll1l,
                                              self.l1lllll1ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l11l = os.path.join(os.path.sep, l1ll1l1l (u"ࠪࡩࡹࡩࠧই"), l1ll1l1l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llll1lll = path
        else:
            self._1llll1lll = self.l1lll1l11l
        super(l1llll11l1, self).__init__(self._1llll1lll, l1ll1l1l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11l11(self, line):
        return l1llll11l1.Entry(*[x for x in line.strip(l1ll1l1l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll1l1l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll1l1l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll1l1l (u"ࠤࠦࠦ঍")):
                    yield self._1lll11l11(line)
            except ValueError:
                pass
    def l1llll1l1l(self, attr, value):
        for entry in self.entries:
            l1lll11l1l = getattr(entry, attr)
            if l1lll11l1l == value:
                return entry
        return None
    def l1lllll1l1(self, entry):
        if self.l1llll1l1l(l1ll1l1l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll1l1l (u"ࠫࡡࡴࠧএ")).encode(l1ll1l1l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1lll1(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll1l1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll1l1l (u"ࠢࠤࠤ঒")):
                if self._1lll11l11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll1l1l (u"ࠨࠩও").join(lines).encode(l1ll1l1l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1llll111l(cls, l1lll1ll1l, path=None):
        l1lllll111 = cls(path=path)
        entry = l1lllll111.l1llll1l1l(l1ll1l1l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1ll1l)
        if entry:
            return l1lllll111.l1lll1lll1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll1l, l1lllll1ll, options=None, path=None):
        return cls(path=path).l1lllll1l1(l1llll11l1.Entry(device,
                                                    l1lll1ll1l, l1lllll1ll,
                                                    options=options))
class l1lllll11l(object):
    def __init__(self, l1llllll1l):
        self.l1lll1ll11=l1ll1l1l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1111l=l1ll1l1l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llllll1l=l1llllll1l
        self.l1llll1ll1()
        self.l1lll1l1l1()
        self.l1lll1l1ll()
        self.l1lll111l1()
        self.l1llll1l11()
    def l1llll1ll1(self):
        temp_file=open(l1llll11ll,l1ll1l1l (u"࠭ࡲࠨঘ"))
        l1llllll=temp_file.read()
        data=json.loads(l1llllll)
        self.user=data[l1ll1l1l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11llll=data[l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11111=data[l1ll1l1l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l11l1l=data[l1ll1l1l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11111=data[l1ll1l1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1llll=data[l1ll1l1l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l1ll(self):
        l1l1l1=os.path.join(l1ll1l1l (u"ࠨ࠯ࠣট"),l1ll1l1l (u"ࠢࡶࡵࡵࠦঠ"),l1ll1l1l (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll1l1l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll1l1l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l1l1)
    def l1llll1l11(self):
        logger.info(l1ll1l1l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11111=os.path.join(self.l11l1l,self.l1lll1ll11)
        l1lllllll1 = pwd.getpwnam(self.user).pw_uid
        l1lll111ll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11111):
            os.makedirs(l11111)
            os.system(l1ll1l1l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11111))
            logger.debug(l1ll1l1l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11111)
        else:
            logger.debug(l1ll1l1l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11111)
        l1l1l1=os.path.join(l11111, self.l1lll1111l)
        print(l1l1l1)
        logger.debug(l1ll1l1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l1l1)
        with open(l1l1l1, l1ll1l1l (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l111:
            logger.debug(self.l11llll + l1ll1l1l (u"ࠪࠤࠬপ")+self.l1lll11111+l1ll1l1l (u"ࠫࠥࠨࠧফ")+self.l1lll1llll+l1ll1l1l (u"ࠬࠨࠧব"))
            l1lll1l111.writelines(self.l11llll + l1ll1l1l (u"࠭ࠠࠨভ")+self.l1lll11111+l1ll1l1l (u"ࠧࠡࠤࠪম")+self.l1lll1llll+l1ll1l1l (u"ࠨࠤࠪয"))
        os.chmod(l1l1l1, 0o600)
        os.chown(l1l1l1, l1lllllll1, l1lll111ll)
    def l1lll1l1l1(self, l1lll11lll=l1ll1l1l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll1l1l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11lll in groups:
            logger.info(l1ll1l1l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11lll))
        else:
            logger.warning(l1ll1l1l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11lll))
            l11l111=l1ll1l1l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11lll,self.user)
            logger.debug(l1ll1l1l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l11l111)
            os.system(l11l111)
            logger.debug(l1ll1l1l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll111l1(self):
        logger.debug(l1ll1l1l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lllll111=l1llll11l1()
        l1lllll111.add(self.l11llll, self.l11111, l1lllll1ll=l1ll1l1l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll1l1l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll1l1l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll11ll = urllib.parse.unquote(sys.argv[1])
        if l1llll11ll:
            l1llllll11=l1lllll11l(l1llll11ll)
        else:
            raise (l1ll1l1l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll1l1l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise