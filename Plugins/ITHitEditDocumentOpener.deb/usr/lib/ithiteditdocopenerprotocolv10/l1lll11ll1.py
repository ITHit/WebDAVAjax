#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llllll11=logging.WARNING
logger = logging.getLogger(l11llll (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llllll11)
l1ll1111 = SysLogHandler(address=l11llll (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l11llll (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1ll1111.setFormatter(formatter)
logger.addHandler(l1ll1111)
ch = logging.StreamHandler()
ch.setLevel(l1llllll11)
logger.addHandler(ch)
class l1llllllll(io.FileIO):
    l11llll (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l11llll (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1llll, l1lllll111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1llll = l1lll1llll
            self.l1lllll111 = l1lllll111
            if not options:
                options = l11llll (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11llll (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1llll,
                                              self.l1lllll111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l1l1 = os.path.join(os.path.sep, l11llll (u"ࠨࡧࡷࡧࠬঅ"), l11llll (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lllll11l = path
        else:
            self._1lllll11l = self.l1lll1l1l1
        super(l1llllllll, self).__init__(self._1lllll11l, l11llll (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll1ll11(self, line):
        return l1llllllll.Entry(*[x for x in line.strip(l11llll (u"ࠦࡡࡴࠢঈ")).split() if x not in (l11llll (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11llll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l11llll (u"ࠢࠤࠤঋ")):
                    yield self._1lll1ll11(line)
            except ValueError:
                pass
    def l1lll1ll1l(self, attr, value):
        for entry in self.entries:
            l1lll1l11l = getattr(entry, attr)
            if l1lll1l11l == value:
                return entry
        return None
    def l1llll1lll(self, entry):
        if self.l1lll1ll1l(l11llll (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l11llll (u"ࠩ࡟ࡲࠬ঍")).encode(l11llll (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lllll1l1(self, entry):
        self.seek(0)
        lines = [l.decode(l11llll (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11llll (u"ࠧࠩࠢঐ")):
                if self._1lll1ll11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11llll (u"࠭ࠧ঑").join(lines).encode(l11llll (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll111l1(cls, l1lll1llll, path=None):
        l1lllllll1 = cls(path=path)
        entry = l1lllllll1.l1lll1ll1l(l11llll (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1llll)
        if entry:
            return l1lllllll1.l1lllll1l1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1llll, l1lllll111, options=None, path=None):
        return cls(path=path).l1llll1lll(l1llllllll.Entry(device,
                                                    l1lll1llll, l1lllll111,
                                                    options=options))
class l1llll1ll1(object):
    def __init__(self, l1llll1111):
        self.l1llll11ll=l11llll (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll1l1ll=l11llll (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll1111=l1llll1111
        self.l1llll111l()
        self.l1lllll1ll()
        self.l1llllll1l()
        self.l1lll1lll1()
        self.l1lll11l11()
    def l1llll111l(self):
        temp_file=open(l1lll111ll,l11llll (u"ࠫࡷ࠭খ"))
        l1l111l=temp_file.read()
        data=json.loads(l1l111l)
        self.user=data[l11llll (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l11l11=data[l11llll (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l111l1=data[l11llll (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1llll1l=data[l11llll (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1llll1l1l=data[l11llll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll11l1l=data[l11llll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1llllll1l(self):
        l1l1l1=os.path.join(l11llll (u"ࠦ࠴ࠨঝ"),l11llll (u"ࠧࡻࡳࡳࠤঞ"),l11llll (u"ࠨࡳࡣ࡫ࡱࠦট"),l11llll (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l11llll (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1l1l1)
    def l1lll11l11(self):
        logger.info(l11llll (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l111l1=os.path.join(self.l1llll1l,self.l1llll11ll)
        l11111111 = pwd.getpwnam(self.user).pw_uid
        l1llll1l11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l111l1):
            os.makedirs(l111l1)
            os.system(l11llll (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l111l1))
            logger.debug(l11llll (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l111l1)
        else:
            logger.debug(l11llll (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l111l1)
        l1l1l1=os.path.join(l111l1, self.l1lll1l1ll)
        print(l1l1l1)
        logger.debug(l11llll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1l1l1)
        with open(l1l1l1, l11llll (u"ࠢࡸ࠭ࠥধ")) as l1llll11l1:
            logger.debug(self.l11l11 + l11llll (u"ࠨࠢࠪন")+self.l1llll1l1l+l11llll (u"ࠩࠣࠦࠬ঩")+self.l1lll11l1l+l11llll (u"ࠪࠦࠬপ"))
            l1llll11l1.writelines(self.l11l11 + l11llll (u"ࠫࠥ࠭ফ")+self.l1llll1l1l+l11llll (u"ࠬࠦࠢࠨব")+self.l1lll11l1l+l11llll (u"࠭ࠢࠨভ"))
        os.chmod(l1l1l1, 0o600)
        os.chown(l1l1l1, l11111111, l1llll1l11)
    def l1lllll1ll(self, l1lll1l111=l11llll (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l11llll (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1l111 in groups:
            logger.info(l11llll (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1lll1l111))
        else:
            logger.warning(l11llll (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1lll1l111))
            l111l=l11llll (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1lll1l111,self.user)
            logger.debug(l11llll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l111l)
            os.system(l111l)
            logger.debug(l11llll (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll1lll1(self):
        logger.debug(l11llll (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lllllll1=l1llllllll()
        l1lllllll1.add(self.l11l11, self.l111l1, l1lllll111=l11llll (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l11llll (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l11llll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll111ll = urllib.parse.unquote(sys.argv[1])
        if l1lll111ll:
            l1lll11lll=l1llll1ll1(l1lll111ll)
        else:
            raise (l11llll (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l11llll (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise