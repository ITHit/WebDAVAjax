#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1l11=logging.WARNING
logger = logging.getLogger(l1llll1 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll1l11)
l1l11l1l = SysLogHandler(address=l1llll1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1llll1 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l11l1l.setFormatter(formatter)
logger.addHandler(l1l11l1l)
ch = logging.StreamHandler()
ch.setLevel(l1llll1l11)
logger.addHandler(ch)
class l1llll1lll(io.FileIO):
    l1llll1 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1llll1 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1llll11l1, l1lll1ll11,
                     options, d=0, p=0):
            self.device = device
            self.l1llll11l1 = l1llll11l1
            self.l1lll1ll11 = l1lll1ll11
            if not options:
                options = l1llll1 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1llll1 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1llll11l1,
                                              self.l1lll1ll11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lllllll1 = os.path.join(os.path.sep, l1llll1 (u"ࠨࡧࡷࡧࠬঅ"), l1llll1 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1llll1ll1 = path
        else:
            self._1llll1ll1 = self.l1lllllll1
        super(l1llll1lll, self).__init__(self._1llll1ll1, l1llll1 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll1llll(self, line):
        return l1llll1lll.Entry(*[x for x in line.strip(l1llll1 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1llll1 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1llll1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1llll1 (u"ࠢࠤࠤঋ")):
                    yield self._1lll1llll(line)
            except ValueError:
                pass
    def l1llllllll(self, attr, value):
        for entry in self.entries:
            l1llllll11 = getattr(entry, attr)
            if l1llllll11 == value:
                return entry
        return None
    def l1llll11ll(self, entry):
        if self.l1llllllll(l1llll1 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1llll1 (u"ࠩ࡟ࡲࠬ঍")).encode(l1llll1 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll11l1l(self, entry):
        self.seek(0)
        lines = [l.decode(l1llll1 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1llll1 (u"ࠧࠩࠢঐ")):
                if self._1lll1llll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1llll1 (u"࠭ࠧ঑").join(lines).encode(l1llll1 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll111ll(cls, l1llll11l1, path=None):
        l1llll111l = cls(path=path)
        entry = l1llll111l.l1llllllll(l1llll1 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1llll11l1)
        if entry:
            return l1llll111l.l1lll11l1l(entry)
        return False
    @classmethod
    def add(cls, device, l1llll11l1, l1lll1ll11, options=None, path=None):
        return cls(path=path).l1llll11ll(l1llll1lll.Entry(device,
                                                    l1llll11l1, l1lll1ll11,
                                                    options=options))
class l11111111(object):
    def __init__(self, l1lll1l1l1):
        self.l1lll1l111=l1llll1 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1llll1111=l1llll1 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1lll1l1l1=l1lll1l1l1
        self.l1lll1lll1()
        self.l1lll11lll()
        self.l1lllll111()
        self.l1lllll1l1()
        self.l1lll1l1ll()
    def l1lll1lll1(self):
        temp_file=open(l1lll1l11l,l1llll1 (u"ࠫࡷ࠭খ"))
        l1ll=temp_file.read()
        data=json.loads(l1ll)
        self.user=data[l1llll1 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1l1l1=data[l1llll1 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1l111=data[l1llll1 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1ll1=data[l1llll1 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lllll1ll=data[l1llll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll111l1=data[l1llll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lllll111(self):
        l11ll11=os.path.join(l1llll1 (u"ࠦ࠴ࠨঝ"),l1llll1 (u"ࠧࡻࡳࡳࠤঞ"),l1llll1 (u"ࠨࡳࡣ࡫ࡱࠦট"),l1llll1 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1llll1 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l11ll11)
    def l1lll1l1ll(self):
        logger.info(l1llll1 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1l111=os.path.join(self.l1ll1,self.l1lll1l111)
        l1lllll11l = pwd.getpwnam(self.user).pw_uid
        l1llll1l1l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l111):
            os.makedirs(l1l111)
            os.system(l1llll1 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1l111))
            logger.debug(l1llll1 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1l111)
        else:
            logger.debug(l1llll1 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1l111)
        l11ll11=os.path.join(l1l111, self.l1llll1111)
        print(l11ll11)
        logger.debug(l1llll1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l11ll11)
        with open(l11ll11, l1llll1 (u"ࠢࡸ࠭ࠥধ")) as l1lll11l11:
            logger.debug(self.l1l1l1 + l1llll1 (u"ࠨࠢࠪন")+self.l1lllll1ll+l1llll1 (u"ࠩࠣࠦࠬ঩")+self.l1lll111l1+l1llll1 (u"ࠪࠦࠬপ"))
            l1lll11l11.writelines(self.l1l1l1 + l1llll1 (u"ࠫࠥ࠭ফ")+self.l1lllll1ll+l1llll1 (u"ࠬࠦࠢࠨব")+self.l1lll111l1+l1llll1 (u"࠭ࠢࠨভ"))
        os.chmod(l11ll11, 0o600)
        os.chown(l11ll11, l1lllll11l, l1llll1l1l)
    def l1lll11lll(self, l1llllll1l=l1llll1 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1llll1 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll1l in groups:
            logger.info(l1llll1 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llllll1l))
        else:
            logger.warning(l1llll1 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llllll1l))
            l1llll11=l1llll1 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llllll1l,self.user)
            logger.debug(l1llll1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1llll11)
            os.system(l1llll11)
            logger.debug(l1llll1 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lllll1l1(self):
        logger.debug(l1llll1 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llll111l=l1llll1lll()
        l1llll111l.add(self.l1l1l1, self.l1l111, l1lll1ll11=l1llll1 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1llll1 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1llll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1l11l = urllib.parse.unquote(sys.argv[1])
        if l1lll1l11l:
            l1lll1ll1l=l11111111(l1lll1l11l)
        else:
            raise (l1llll1 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1llll1 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise