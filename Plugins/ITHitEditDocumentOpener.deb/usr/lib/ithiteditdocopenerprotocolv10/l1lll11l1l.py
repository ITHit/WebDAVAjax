#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l1ll1l1 = 2048
l1lll1l1 = 7
def l1l1ll (l1ll1l1l):
    global l111l1
    l1l11l1 = ord (l1ll1l1l [-1])
    l1lll1l = l1ll1l1l [:-1]
    l1llll1 = l1l11l1 % len (l1lll1l)
    ll = l1lll1l [:l1llll1] + l1lll1l [l1llll1:]
    if l1l1111:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    return eval (l1111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llllll11=logging.WARNING
logger = logging.getLogger(l1l1ll (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llllll11)
l11ll1ll = SysLogHandler(address=l1l1ll (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1l1ll (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l11ll1ll)
ch = logging.StreamHandler()
ch.setLevel(l1llllll11)
logger.addHandler(ch)
class l1llll11l1(io.FileIO):
    l1l1ll (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1l1ll (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1lll1, l11111111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1lll1 = l1lll1lll1
            self.l11111111 = l11111111
            if not options:
                options = l1l1ll (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1ll (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1lll1,
                                              self.l11111111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll11ll = os.path.join(os.path.sep, l1l1ll (u"ࠨࡧࡷࡧࠬঅ"), l1l1ll (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1llll1lll = path
        else:
            self._1llll1lll = self.l1llll11ll
        super(l1llll11l1, self).__init__(self._1llll1lll, l1l1ll (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lllll1l1(self, line):
        return l1llll11l1.Entry(*[x for x in line.strip(l1l1ll (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1l1ll (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1ll (u"ࠢࠤࠤঋ")):
                    yield self._1lllll1l1(line)
            except ValueError:
                pass
    def l1lll1llll(self, attr, value):
        for entry in self.entries:
            l1llll111l = getattr(entry, attr)
            if l1llll111l == value:
                return entry
        return None
    def l1llll1111(self, entry):
        if self.l1lll1llll(l1l1ll (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1l1ll (u"ࠩ࡟ࡲࠬ঍")).encode(l1l1ll (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll1l111(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1ll (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1ll (u"ࠧࠩࠢঐ")):
                if self._1lllll1l1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1ll (u"࠭ࠧ঑").join(lines).encode(l1l1ll (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l1ll(cls, l1lll1lll1, path=None):
        l1lll1ll1l = cls(path=path)
        entry = l1lll1ll1l.l1lll1llll(l1l1ll (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1lll1)
        if entry:
            return l1lll1ll1l.l1lll1l111(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1lll1, l11111111, options=None, path=None):
        return cls(path=path).l1llll1111(l1llll11l1.Entry(device,
                                                    l1lll1lll1, l11111111,
                                                    options=options))
class l1lllll11l(object):
    def __init__(self, l1lll1l11l):
        self.l1lll11lll=l1l1ll (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1llll1l1l=l1l1ll (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1lll1l11l=l1lll1l11l
        self.l1lll111l1()
        self.l1lll11ll1()
        self.l1lllll111()
        self.l1lllllll1()
        self.l1llll1l11()
    def l1lll111l1(self):
        temp_file=open(l1lll1l1l1,l1l1ll (u"ࠫࡷ࠭খ"))
        l111ll1=temp_file.read()
        data=json.loads(l111ll1)
        self.user=data[l1l1ll (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l111l=data[l1l1ll (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11lll=data[l1l1ll (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1llll=data[l1l1ll (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1llllllll=data[l1l1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll11l11=data[l1l1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lllll111(self):
        l1111ll=os.path.join(l1l1ll (u"ࠦ࠴ࠨঝ"),l1l1ll (u"ࠧࡻࡳࡳࠤঞ"),l1l1ll (u"ࠨࡳࡣ࡫ࡱࠦট"),l1l1ll (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1l1ll (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1111ll)
    def l1llll1l11(self):
        logger.info(l1l1ll (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11lll=os.path.join(self.l1llll,self.l1lll11lll)
        l1llll1ll1 = pwd.getpwnam(self.user).pw_uid
        l1lllll1ll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11lll):
            os.makedirs(l11lll)
            os.system(l1l1ll (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11lll))
            logger.debug(l1l1ll (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11lll)
        else:
            logger.debug(l1l1ll (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11lll)
        l1111ll=os.path.join(l11lll, self.l1llll1l1l)
        print(l1111ll)
        logger.debug(l1l1ll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1111ll)
        with open(l1111ll, l1l1ll (u"ࠢࡸ࠭ࠥধ")) as l1lll1ll11:
            logger.debug(self.l111l + l1l1ll (u"ࠨࠢࠪন")+self.l1llllllll+l1l1ll (u"ࠩࠣࠦࠬ঩")+self.l1lll11l11+l1l1ll (u"ࠪࠦࠬপ"))
            l1lll1ll11.writelines(self.l111l + l1l1ll (u"ࠫࠥ࠭ফ")+self.l1llllllll+l1l1ll (u"ࠬࠦࠢࠨব")+self.l1lll11l11+l1l1ll (u"࠭ࠢࠨভ"))
        os.chmod(l1111ll, 0o600)
        os.chown(l1111ll, l1llll1ll1, l1lllll1ll)
    def l1lll11ll1(self, l1llllll1l=l1l1ll (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1l1ll (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll1l in groups:
            logger.info(l1l1ll (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llllll1l))
        else:
            logger.warning(l1l1ll (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llllll1l))
            l1lllll1=l1l1ll (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llllll1l,self.user)
            logger.debug(l1l1ll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1lllll1)
            os.system(l1lllll1)
            logger.debug(l1l1ll (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lllllll1(self):
        logger.debug(l1l1ll (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lll1ll1l=l1llll11l1()
        l1lll1ll1l.add(self.l111l, self.l11lll, l11111111=l1l1ll (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1l1ll (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1l1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1l1l1 = urllib.parse.unquote(sys.argv[1])
        if l1lll1l1l1:
            l1lll111ll=l1lllll11l(l1lll1l1l1)
        else:
            raise (l1l1ll (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1l1ll (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise