#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l11l=logging.WARNING
logger = logging.getLogger(l1ll11l1 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1lll1l11l)
l1ll111l = SysLogHandler(address=l1ll11l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1ll11l1 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1ll111l.setFormatter(formatter)
logger.addHandler(l1ll111l)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l11l)
logger.addHandler(ch)
class l1lll11l11(io.FileIO):
    l1ll11l1 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1ll11l1 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1llll1ll1, l1lll11lll,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1ll1 = l1llll1ll1
            self.l1lll11lll = l1lll11lll
            if not options:
                options = l1ll11l1 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll11l1 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1llll1ll1,
                                              self.l1lll11lll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1111 = os.path.join(os.path.sep, l1ll11l1 (u"ࠨࡧࡷࡧࠬঅ"), l1ll11l1 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lllll11l = path
        else:
            self._1lllll11l = self.l1llll1111
        super(l1lll11l11, self).__init__(self._1lllll11l, l1ll11l1 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll1l1ll(self, line):
        return l1lll11l11.Entry(*[x for x in line.strip(l1ll11l1 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1ll11l1 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll11l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll11l1 (u"ࠢࠤࠤঋ")):
                    yield self._1lll1l1ll(line)
            except ValueError:
                pass
    def l1llll1l1l(self, attr, value):
        for entry in self.entries:
            l1lll11ll1 = getattr(entry, attr)
            if l1lll11ll1 == value:
                return entry
        return None
    def l1llllll1l(self, entry):
        if self.l1llll1l1l(l1ll11l1 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1ll11l1 (u"ࠩ࡟ࡲࠬ঍")).encode(l1ll11l1 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l11111111(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll11l1 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll11l1 (u"ࠧࠩࠢঐ")):
                if self._1lll1l1ll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll11l1 (u"࠭ࠧ঑").join(lines).encode(l1ll11l1 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll111l1(cls, l1llll1ll1, path=None):
        l1llllllll = cls(path=path)
        entry = l1llllllll.l1llll1l1l(l1ll11l1 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1llll1ll1)
        if entry:
            return l1llllllll.l11111111(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1ll1, l1lll11lll, options=None, path=None):
        return cls(path=path).l1llllll1l(l1lll11l11.Entry(device,
                                                    l1llll1ll1, l1lll11lll,
                                                    options=options))
class l1llll11l1(object):
    def __init__(self, l1lll1ll11):
        self.l1lll1l1l1=l1ll11l1 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lllll111=l1ll11l1 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1lll1ll11=l1lll1ll11
        self.l1llll11ll()
        self.l1llll1l11()
        self.l1lllll1l1()
        self.l1llllll11()
        self.l1lllllll1()
    def l1llll11ll(self):
        temp_file=open(l1lll1ll1l,l1ll11l1 (u"ࠫࡷ࠭খ"))
        l11111l=temp_file.read()
        data=json.loads(l11111l)
        self.user=data[l1ll11l1 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l11lll1=data[l1ll11l1 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1ll111=data[l1ll11l1 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1l11ll=data[l1ll11l1 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lllll1ll=data[l1ll11l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll111ll=data[l1ll11l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lllll1l1(self):
        l1l11=os.path.join(l1ll11l1 (u"ࠦ࠴ࠨঝ"),l1ll11l1 (u"ࠧࡻࡳࡳࠤঞ"),l1ll11l1 (u"ࠨࡳࡣ࡫ࡱࠦট"),l1ll11l1 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1ll11l1 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1l11)
    def l1lllllll1(self):
        logger.info(l1ll11l1 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1ll111=os.path.join(self.l1l11ll,self.l1lll1l1l1)
        l1lll1lll1 = pwd.getpwnam(self.user).pw_uid
        l1llll1lll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll111):
            os.makedirs(l1ll111)
            os.system(l1ll11l1 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1ll111))
            logger.debug(l1ll11l1 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1ll111)
        else:
            logger.debug(l1ll11l1 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1ll111)
        l1l11=os.path.join(l1ll111, self.l1lllll111)
        print(l1l11)
        logger.debug(l1ll11l1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1l11)
        with open(l1l11, l1ll11l1 (u"ࠢࡸ࠭ࠥধ")) as l1lll1l111:
            logger.debug(self.l11lll1 + l1ll11l1 (u"ࠨࠢࠪন")+self.l1lllll1ll+l1ll11l1 (u"ࠩࠣࠦࠬ঩")+self.l1lll111ll+l1ll11l1 (u"ࠪࠦࠬপ"))
            l1lll1l111.writelines(self.l11lll1 + l1ll11l1 (u"ࠫࠥ࠭ফ")+self.l1lllll1ll+l1ll11l1 (u"ࠬࠦࠢࠨব")+self.l1lll111ll+l1ll11l1 (u"࠭ࠢࠨভ"))
        os.chmod(l1l11, 0o600)
        os.chown(l1l11, l1lll1lll1, l1llll1lll)
    def l1llll1l11(self, l1llll111l=l1ll11l1 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1ll11l1 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll111l in groups:
            logger.info(l1ll11l1 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llll111l))
        else:
            logger.warning(l1ll11l1 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llll111l))
            l1lll11l=l1ll11l1 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llll111l,self.user)
            logger.debug(l1ll11l1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1lll11l)
            os.system(l1lll11l)
            logger.debug(l1ll11l1 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1llllll11(self):
        logger.debug(l1ll11l1 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llllllll=l1lll11l11()
        l1llllllll.add(self.l11lll1, self.l1ll111, l1lll11lll=l1ll11l1 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1ll11l1 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1ll11l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1ll1l = urllib.parse.unquote(sys.argv[1])
        if l1lll1ll1l:
            l1lll1llll=l1llll11l1(l1lll1ll1l)
        else:
            raise (l1ll11l1 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1ll11l1 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise