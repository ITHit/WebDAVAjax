#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l1 = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1l1l = 7
def l1ll1 (l11l1l1):
    global l1lll11
    l111l11 = ord (l11l1l1 [-1])
    l1111l1 = l11l1l1 [:-1]
    l1l1ll = l111l11 % len (l1111l1)
    l1l1l1 = l1111l1 [:l1l1ll] + l1111l1 [l1l1ll:]
    if l1lll1l1:
        l1111l = l11ll11 () .join ([unichr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    return eval (l1111l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllll1l1=logging.WARNING
logger = logging.getLogger(l1ll1 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1lllll1l1)
l11llll1 = SysLogHandler(address=l1ll1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1ll1 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l11llll1.setFormatter(formatter)
logger.addHandler(l11llll1)
ch = logging.StreamHandler()
ch.setLevel(l1lllll1l1)
logger.addHandler(ch)
class l1lll11lll(io.FileIO):
    l1ll1 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1ll1 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll111l1, l1lll1l1l1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll111l1 = l1lll111l1
            self.l1lll1l1l1 = l1lll1l1l1
            if not options:
                options = l1ll1 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll1 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll111l1,
                                              self.l1lll1l1l1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1ll1 = os.path.join(os.path.sep, l1ll1 (u"ࠨࡧࡷࡧࠬঅ"), l1ll1 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1llll1111 = path
        else:
            self._1llll1111 = self.l1llll1ll1
        super(l1lll11lll, self).__init__(self._1llll1111, l1ll1 (u"ࠪࡶࡧ࠱ࠧই"))
    def _11111111(self, line):
        return l1lll11lll.Entry(*[x for x in line.strip(l1ll1 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1ll1 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll1 (u"ࠢࠤࠤঋ")):
                    yield self._11111111(line)
            except ValueError:
                pass
    def l1lll11l11(self, attr, value):
        for entry in self.entries:
            l1llll11ll = getattr(entry, attr)
            if l1llll11ll == value:
                return entry
        return None
    def l1lllll11l(self, entry):
        if self.l1lll11l11(l1ll1 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1ll1 (u"ࠩ࡟ࡲࠬ঍")).encode(l1ll1 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1llllllll(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll1 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll1 (u"ࠧࠩࠢঐ")):
                if self._11111111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll1 (u"࠭ࠧ঑").join(lines).encode(l1ll1 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1llll1l11(cls, l1lll111l1, path=None):
        l1llllll1l = cls(path=path)
        entry = l1llllll1l.l1lll11l11(l1ll1 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll111l1)
        if entry:
            return l1llllll1l.l1llllllll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll111l1, l1lll1l1l1, options=None, path=None):
        return cls(path=path).l1lllll11l(l1lll11lll.Entry(device,
                                                    l1lll111l1, l1lll1l1l1,
                                                    options=options))
class l1lllll111(object):
    def __init__(self, l1llll111l):
        self.l1lll1ll11=l1ll1 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll11ll1=l1ll1 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll111l=l1llll111l
        self.l1llll11l1()
        self.l1llll1lll()
        self.l1llllll11()
        self.l1lll111ll()
        self.l1lll1llll()
    def l1llll11l1(self):
        temp_file=open(l1llll1l1l,l1ll1 (u"ࠫࡷ࠭খ"))
        l11llll=temp_file.read()
        data=json.loads(l11llll)
        self.user=data[l1ll1 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1l1l=data[l1ll1 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11l11l=data[l1ll1 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1ll111=data[l1ll1 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll1l11l=data[l1ll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll1lll1=data[l1ll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1llllll11(self):
        l111l1=os.path.join(l1ll1 (u"ࠦ࠴ࠨঝ"),l1ll1 (u"ࠧࡻࡳࡳࠤঞ"),l1ll1 (u"ࠨࡳࡣ࡫ࡱࠦট"),l1ll1 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1ll1 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l111l1)
    def l1lll1llll(self):
        logger.info(l1ll1 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11l11l=os.path.join(self.l1ll111,self.l1lll1ll11)
        l1lllllll1 = pwd.getpwnam(self.user).pw_uid
        l1lll1l1ll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l11l):
            os.makedirs(l11l11l)
            os.system(l1ll1 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11l11l))
            logger.debug(l1ll1 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11l11l)
        else:
            logger.debug(l1ll1 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11l11l)
        l111l1=os.path.join(l11l11l, self.l1lll11ll1)
        print(l111l1)
        logger.debug(l1ll1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l111l1)
        with open(l111l1, l1ll1 (u"ࠢࡸ࠭ࠥধ")) as l1lll1ll1l:
            logger.debug(self.l1l1l + l1ll1 (u"ࠨࠢࠪন")+self.l1lll1l11l+l1ll1 (u"ࠩࠣࠦࠬ঩")+self.l1lll1lll1+l1ll1 (u"ࠪࠦࠬপ"))
            l1lll1ll1l.writelines(self.l1l1l + l1ll1 (u"ࠫࠥ࠭ফ")+self.l1lll1l11l+l1ll1 (u"ࠬࠦࠢࠨব")+self.l1lll1lll1+l1ll1 (u"࠭ࠢࠨভ"))
        os.chmod(l111l1, 0o600)
        os.chown(l111l1, l1lllllll1, l1lll1l1ll)
    def l1llll1lll(self, l1lllll1ll=l1ll1 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1ll1 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lllll1ll in groups:
            logger.info(l1ll1 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1lllll1ll))
        else:
            logger.warning(l1ll1 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1lllll1ll))
            l1lll1ll=l1ll1 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1lllll1ll,self.user)
            logger.debug(l1ll1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1lll1ll)
            os.system(l1lll1ll)
            logger.debug(l1ll1 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll111ll(self):
        logger.debug(l1ll1 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llllll1l=l1lll11lll()
        l1llllll1l.add(self.l1l1l, self.l11l11l, l1lll1l1l1=l1ll1 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1ll1 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1ll1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llll1l1l = urllib.parse.unquote(sys.argv[1])
        if l1llll1l1l:
            l1lll1l111=l1lllll111(l1llll1l1l)
        else:
            raise (l1ll1 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1ll1 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise