#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l1 = sys.version_info [0] == 2
l1l1l11 = 2048
l1ll1l1l = 7
def l11ll1l (l1l11ll):
    global l1lll1l1
    l1l11 = ord (l1l11ll [-1])
    l1 = l1l11ll [:-1]
    l1ll111 = l1l11 % len (l1)
    ll = l1 [:l1ll111] + l1 [l1ll111:]
    if l11l1l1:
        l1l1l1 = l1lll11l () .join ([unichr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    return eval (l1l1l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11lll=logging.WARNING
logger = logging.getLogger(l11ll1l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11lll)
l11lllll = SysLogHandler(address=l11ll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11ll1l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11lllll.setFormatter(formatter)
logger.addHandler(l11lllll)
ch = logging.StreamHandler()
ch.setLevel(l1lll11lll)
logger.addHandler(ch)
class l1lllllll1(io.FileIO):
    l11ll1l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11ll1l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11l11, l1lll11ll1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11l11 = l1lll11l11
            self.l1lll11ll1 = l1lll11ll1
            if not options:
                options = l11ll1l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11ll1l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11l11,
                                              self.l1lll11ll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll111l1 = os.path.join(os.path.sep, l11ll1l (u"ࠪࡩࡹࡩࠧই"), l11ll1l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll111ll = path
        else:
            self._1lll111ll = self.l1lll111l1
        super(l1lllllll1, self).__init__(self._1lll111ll, l11ll1l (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l1l(self, line):
        return l1lllllll1.Entry(*[x for x in line.strip(l11ll1l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11ll1l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11ll1l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11ll1l (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l1l(line)
            except ValueError:
                pass
    def l1lll11111(self, attr, value):
        for entry in self.entries:
            l1lllll1ll = getattr(entry, attr)
            if l1lllll1ll == value:
                return entry
        return None
    def l1llllll11(self, entry):
        if self.l1lll11111(l11ll1l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11ll1l (u"ࠫࡡࡴࠧএ")).encode(l11ll1l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllll11l(self, entry):
        self.seek(0)
        lines = [l.decode(l11ll1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11ll1l (u"ࠢࠤࠤ঒")):
                if self._1llll1l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11ll1l (u"ࠨࠩও").join(lines).encode(l11ll1l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll1l(cls, l1lll11l11, path=None):
        l1lll1ll11 = cls(path=path)
        entry = l1lll1ll11.l1lll11111(l11ll1l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11l11)
        if entry:
            return l1lll1ll11.l1lllll11l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11l11, l1lll11ll1, options=None, path=None):
        return cls(path=path).l1llllll11(l1lllllll1.Entry(device,
                                                    l1lll11l11, l1lll11ll1,
                                                    options=options))
class l1lll1l11l(object):
    def __init__(self, l1lllll111):
        self.l1llll111l=l11ll1l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lllll1l1=l11ll1l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll111=l1lllll111
        self.l1llll11l1()
        self.l1lll1111l()
        self.l1llll1111()
        self.l1lll11l1l()
        self.l1llll1l11()
    def l1llll11l1(self):
        temp_file=open(l1llll1ll1,l11ll1l (u"࠭ࡲࠨঘ"))
        l111111=temp_file.read()
        data=json.loads(l111111)
        self.user=data[l11ll1l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll1l=data[l11ll1l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll=data[l11ll1l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll1ll=data[l11ll1l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1l111=data[l11ll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l1ll=data[l11ll1l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1111(self):
        l11ll1=os.path.join(l11ll1l (u"ࠨ࠯ࠣট"),l11ll1l (u"ࠢࡶࡵࡵࠦঠ"),l11ll1l (u"ࠣࡵࡥ࡭ࡳࠨড"),l11ll1l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11ll1l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11ll1)
    def l1llll1l11(self):
        logger.info(l11ll1l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll=os.path.join(self.l1ll1ll,self.l1llll111l)
        l1lll1lll1 = pwd.getpwnam(self.user).pw_uid
        l1lll1l1l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll):
            os.makedirs(l1ll)
            os.system(l11ll1l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll))
            logger.debug(l11ll1l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll)
        else:
            logger.debug(l11ll1l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll)
        l11ll1=os.path.join(l1ll, self.l1lllll1l1)
        print(l11ll1)
        logger.debug(l11ll1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11ll1)
        with open(l11ll1, l11ll1l (u"ࠤࡺ࠯ࠧ঩")) as l1lll1llll:
            logger.debug(self.l1ll1l + l11ll1l (u"ࠪࠤࠬপ")+self.l1lll1l111+l11ll1l (u"ࠫࠥࠨࠧফ")+self.l1lll1l1ll+l11ll1l (u"ࠬࠨࠧব"))
            l1lll1llll.writelines(self.l1ll1l + l11ll1l (u"࠭ࠠࠨভ")+self.l1lll1l111+l11ll1l (u"ࠧࠡࠤࠪম")+self.l1lll1l1ll+l11ll1l (u"ࠨࠤࠪয"))
        os.chmod(l11ll1, 0o600)
        os.chown(l11ll1, l1lll1lll1, l1lll1l1l1)
    def l1lll1111l(self, l1llll11ll=l11ll1l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11ll1l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11ll in groups:
            logger.info(l11ll1l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll11ll))
        else:
            logger.warning(l11ll1l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll11ll))
            l1llll=l11ll1l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll11ll,self.user)
            logger.debug(l11ll1l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1llll)
            os.system(l1llll)
            logger.debug(l11ll1l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll11l1l(self):
        logger.debug(l11ll1l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1ll11=l1lllllll1()
        l1lll1ll11.add(self.l1ll1l, self.l1ll, l1lll11ll1=l11ll1l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11ll1l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11ll1l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll1ll1 = urllib.parse.unquote(sys.argv[1])
        if l1llll1ll1:
            l1llllll1l=l1lll1l11l(l1llll1ll1)
        else:
            raise (l11ll1l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11ll1l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise