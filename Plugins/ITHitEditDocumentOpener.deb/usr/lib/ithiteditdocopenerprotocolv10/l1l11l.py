#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1llll11 = 2048
l11l11 = 7
def l1lllll (l1lll):
    global l1ll1ll1
    l1ll1lll = ord (l1lll [-1])
    l111l11 = l1lll [:-1]
    l1ll11l = l1ll1lll % len (l111l11)
    l1111 = l111l11 [:l1ll11l] + l111l11 [l1ll11l:]
    if l1ll1:
        l111lll = l1l1ll1 () .join ([unichr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    else:
        l111lll = str () .join ([chr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    return eval (l111lll)
import re
class l11l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l111111l = kwargs.get(l1lllll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11l1l = kwargs.get(l1lllll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll1lll = self.l1111l11(args)
        if l1lll1lll:
            args=args+ l1lll1lll
        self.args = [a for a in args]
    def l1111l11(self, *args):
        l1lll1lll=None
        l11ll1l1 = args[0][0]
        if re.search(l1lllll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11ll1l1):
            l1lll1lll = (l1lllll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l111111l
                            ,)
        return l1lll1lll
class l11111l1(Exception):
    def __init__(self, *args, **kwargs):
        l1lll1lll = self.l1111l11(args)
        if l1lll1lll:
            args = args + l1lll1lll
        self.args = [a for a in args]
    def l1111l11(self, *args):
        s = l1lllll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lllll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll11ll(Exception):
    pass
class l1lll1ll(Exception):
    pass
class l1lll1l11(Exception):
    def __init__(self, message, l1lllll11, url):
        super(l1lll1l11,self).__init__(message)
        self.l1lllll11 = l1lllll11
        self.url = url
class l1llll1l1(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llll111(Exception):
    pass
class l1llllll1(Exception):
    pass
class l11l1l1l(Exception):
    pass