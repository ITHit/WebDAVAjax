#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import logging
import os
import re
from l1llllll import l1llll1ll
logger = logging.getLogger(l1llll1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l111l11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1llll1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1():
    try:
        out = os.popen(l1llll1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1llll1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1llll1 (u"ࠢࠣॶ").join(result)
                logger.info(l1llll1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1llll1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1llll1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1llll1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1ll(l1llll1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1llll1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l111l11(l1llll1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))