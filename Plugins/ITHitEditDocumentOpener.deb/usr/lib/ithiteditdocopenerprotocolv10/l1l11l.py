#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import gi
gi.require_version(l111lll (u"ࠨࡉࡷ࡯ࠬঽ"), l111lll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1l11l
import logging
logger = logging.getLogger(l111lll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l11111(Gtk.Window):
    def __init__(self, l1ll1l1l1l, l1ll1llll1):
        Gtk.Window.__init__(self)
        self.l1l1ll1=30
        self.l1l11l1l11 = False
        self.service = l1ll1l1l1l
        self.l1l11=l1ll1llll1
        self.l1l=l1l1l11l.l11ll1ll
        self.l1l11ll1l1 = Gtk.ListStore(str)
        self.l1ll11111l()
    def l1l1llll1l(self, service):
        l1ll1lll1l = self.l1l.l1l1l111(l111lll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll1lll1l
    def l1ll11111l(self, l1ll1l1l1l=None):
        if l1ll1l1l1l:
            self.l1l11ll1l1.clear()
            l1l11ll1ll=self.l1l1llll1l(l1ll1l1l1l)
            self.l1l11ll1l1.append([l111lll (u"ࠧࠨু")])
            for l1l11 in l1l11ll1ll:
                self.l1l11ll1l1.append([l1l11])
        else:
            self.l1l11ll1l1.clear()
            self.l1l11ll1l1.append([l111lll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1lll111(self, widget, data=None):
        l1ll1ll1l1= widget.get_active()
        if data == l111lll (u"ࠢ࠲ࠤৃ") and l1ll1ll1l1:
            self.l1ll11111l()
            self.l1ll11l1l1.set_active(0)
            self.l1l1l1lll1.set_text(l111lll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l1lll1.set_sensitive(False)
            self.l1ll11l1l1.set_sensitive(False)
        else:
            self.l1ll11111l(l1ll1l1l1l=self.service)
            self.l1ll11l1l1.set_active(0)
            self.l1l1l1lll1.set_text(l111lll (u"ࠤࠥ৅"))
            self.l1ll11l1l1.set_sensitive(True)
            self.l1l1l1lll1.set_sensitive(True)
    def l1l1ll11l1(self, widget):
        if widget.get_active():
            l1l11 = widget.get_child().get_text()
        else:
            l1l11 = self.l1l11ll1l1[widget.get_active()][0]
        password = self.l1ll111lll(self.service, l1l11)
        if password:
            self.l1l1l1lll1.set_text(password)
        else:
            self.l1l1l1lll1.set_text(l111lll (u"ࠥࠦ৆"))
    def l1ll1l11ll(self, l1l11, pwd, service):
        keyring.set_password(service, l1l11, pwd)
        l1ll1lll1l=self.l1l.l1l1l111(l111lll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1l11 in l1ll1lll1l:
            value = self.l1l.get_value(l111lll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l.l11ll111(l111lll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l111lll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1l11))
    def l1ll111lll(self, service, l1l11):
        l1ll11l111 = keyring.get_password(service, l1l11)
        return l1ll11l111
    def l1l1ll11ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l11ll11l(self, widget, data=None):
        self.l1l11l1l11=widget.get_active()
    def l111ll(self, message, title=l111lll (u"ࠨࠩো"), l1l1111ll=True):
        if l1l1111ll:
            l1l1l1l1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1l1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l11ll111 = Gtk.MessageDialog(self,
            l1l1l1l1ll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l11ll111.set_title(title)
        l1l11ll111.set_default_response(Gtk.ResponseType.OK)
        l1ll1ll111 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll111l1l = Gtk.VBox()
        l1l11l1lll = Gtk.Box(spacing=1)
        l1l11l1lll.set_homogeneous(False)
        l1ll1ll1ll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1ll1ll.set_homogeneous(False)
        l1ll1111ll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1111ll.set_homogeneous(False)
        l1l11l1lll.pack_start(l1ll1ll1ll, True, True, 0)
        l1l11l1lll.pack_start(l1ll1111ll, True, True, 0)
        l1l1ll1111 = l1l11ll111.get_content_area()
        l1ll11llll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1ll1111.pack_start(l1ll11llll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll11l1ll = Gtk.Label()
        l1l1l11111 = Gtk.Label()
        l1l1l11111.set_text(l111lll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1l11111, True, True, 0)
        l1ll11l1ll.set_text(l111lll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll11l1ll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll11l1ll, 0, 1, 0, 1)
        l1l11l11ll = Gtk.RadioButton.new_with_label_from_widget(None, l111lll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l11l11ll.connect(l111lll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1lll111, l111lll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l11l11ll, 1, 2, 0, 1)
        l1l1l11lll = Gtk.RadioButton.new_with_label_from_widget(l1l11l11ll, l111lll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1l11lll.connect(l111lll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1lll111, l111lll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1l11lll, 1, 2, 1, 2)
        l1l1l1ll1l = Gtk.Label()
        l1l1l1ll1l.set_text(l111lll (u"ࠥࠤࠧ৔"))
        table.attach(l1l1l1ll1l, 0, 1, 4, 6)
        l1l1l1l1l1 = Gtk.Label()
        l1l1l1l1l1.set_text(l111lll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1l1l1l1.set_justify(Gtk.Justification.RIGHT)
        l1l1l1l1l1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll11l1l1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l11ll1l1)
        self.l1ll11l1l1.set_entry_text_column(0)
        table.attach(l1l1l1l1l1, 0, 1, 6, 8)
        table.attach(self.l1ll11l1l1, 1, 3, 6, 8)
        self.l1ll11l1l1.connect(l111lll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1ll11l1)
        l1l1lllll1 = Gtk.Label()
        l1l1lllll1.set_text(l111lll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l1lllll1.set_justify(Gtk.Justification.RIGHT)
        l1l1lllll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l1lll1 = Gtk.Entry()
        self.l1l1l1lll1.set_visibility(False)
        self.l1l1l1lll1.connect(l111lll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1ll11ll, l1l11ll111)
        table.attach(l1l1lllll1, 0, 1, 8, 10)
        table.attach(self.l1l1l1lll1, 1, 3, 8, 10)
        l1l1lll1l1 = Gtk.CheckButton(l111lll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1lll1l1.connect(l111lll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l11ll11l, l1l1lll1l1)
        l1l1lll1l1.set_active(False)
        table.attach(l1l1lll1l1, 1, 3, 12, 14)
        l1ll1111l1 = Gtk.Label()
        l1ll1111l1.set_text(l111lll (u"ࠥࠤࠧ৛") * 5)
        l1ll111l1l.pack_start(l1ll1111l1, True, True, 0)
        if self.l1l11:
            l1l1l11lll.set_active(True)
            self.l1ll11l1l1.set_active(0)
            self.l1ll11l1l1.set_sensitive(True)
            self.l1l1l1lll1.set_text(l111lll (u"ࠦࠧড়"))
            self.l1l1l1lll1.set_sensitive(True)
        else:
            self.l1ll11l1l1.set_active(0)
            self.l1ll11l1l1.set_sensitive(False)
            self.l1l1l1lll1.set_text(l111lll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l1lll1.set_sensitive(False)
        l1ll1ll111.pack_start(vbox, True, True, 0)
        l1ll1ll111.pack_start(table, True, True, 0)
        l1ll1ll111.pack_end(l1ll111l1l, True, True, 0)
        l1ll11llll.pack_start(l1ll1ll111, True, True, 0)
        l1l11ll111.show_all()
        response = l1l11ll111.run()
        if self.l1ll11l1l1.get_active():
            l1l11 = self.l1ll11l1l1.get_child().get_text()
        else:
            l1l11 = self.l1l11ll1l1[self.l1ll11l1l1.get_active()][0]
        pwd = self.l1l1l1lll1.get_text()
        l1l11ll111.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l11l1l11:
                self.l1ll1l11ll(l1l11, pwd, self.service)
            return l1l11, pwd
        else:
            return l111lll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l111lll (u"ࠧࠨয়")
class l1l111l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1l1ll1(self, l1l11ll1):
        l1ll1lllll = Gtk.ScrolledWindow()
        l1ll1lllll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l11l1l1l=None
        self.l1l1llllll = Gtk.TextBuffer()
        self.l1l1llllll.set_text(l1l11ll1)
        self.set_style()
        regexp= l111lll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll111l11 = self._1ll1l1111(l1l11ll1, regexp)
        self.l1ll1l1lll(l1ll111l11, self.l1l1llllll.get_start_iter())
        self.l1l11lll11 = Gtk.TextView(buffer=self.l1l1llllll)
        self.l1l11lll11.set_property(l111lll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l11lll11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11lll11.connect(l111lll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1ll1lll)
        self.l1l11lll11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1lllll.set_size_request(300,100)
        self.l1l11lll11.show()
        l1ll1lllll.add(self.l1l11lll11)
        l1ll1lllll.show()
        return l1ll1lllll
    def _1l1ll1lll(self, *args, **kwargs):
        l1ll1l1l11, l1ll11l11l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1l1l11, l1ll11l11l).get_tags()
        if not self.l1l11l1l1l:
            self.l1l11l1l1l = args[1].window.get_cursor()
            self.l1l1l11ll1 = Gdk.Cursor(Gdk.CursorType.l1l11lll1l)
        elif tag:
            args[1].window.set_cursor(self.l1l1l11ll1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l11l1l1l:
                args[1].window.set_cursor(self.l1l11l1l1l)
    def _1ll1l1111(self, l1l11ll1, l1l1l11l11):
        res=[]
        l1ll1ll11l=re.findall(l1l1l11l11,l1l11ll1)
        for l1l1l1llll in l1ll1ll11l:
            for el in l1l1l1llll:
                if el:
                    res.append(el)
        return res
    def l1ll1l1lll(self, l1ll111l11, start):
        l1ll1l11l1=0
        for text in l1ll111l11:
            end = self.l1l1llllll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1l11l1+=1
                l1l1l111l1, l1ll11ll1l = match
                tag = self.l1l1llllll.create_tag(str(l1ll1l11l1), foreground=l111lll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l111lll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1l1111l, text)
                self.l1l1llllll.apply_tag(tag, l1l1l111l1, l1ll11ll1l)
                self.l1ll1l1lll(l1ll111l11, l1ll11ll1l)
    def _1l1l1111l(self, tag, widget, l1l1ll1l11, _1l1llll11, text):
        _1l11l1ll1 = l1l1ll1l11.type
        _1l1l111ll = l1l1ll1l11.window
        if _1l11l1ll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11l1ll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1ll1l11.button
            self.l1l11l1l1l = Gdk.Cursor(Gdk.CursorType.l1l11lll1l)
            if _1l11l1ll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l111lll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l111l1ll1(self, message, title=l111lll (u"ࠧࠨ০"), l1l1111ll=True, l1ll1lll11=None):
        if l1l1111ll:
            l1l1l1l1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1l1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1l1l1ll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll1lll11:
            l1l1ll1111 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l11l1lll = Gtk.HBox(spacing=0)
            l1l11llll1 = Gtk.HBox(spacing=5)
            l1ll111111 = Gtk.Label()
            l1ll111111.set_markup(l111lll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll111111.set_line_wrap(True)
            l1ll111111.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l111lll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1ll111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll111l.show()
            l1ll1l111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l111l.show()
            l1l1ll1l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1l1l.show()
            l1l11l1lll.pack_start(separator, True, True, 0)
            l1l11l1lll.pack_start(l1l1ll111l, True, True, 0)
            l1l11l1lll.pack_start(l1ll1l111l, True, True, 0)
            l1l11l1lll.pack_start(l1l1ll1l1l, True, True, 0)
            l1l11l1lll.pack_start(l1ll111111, False, True, 0)
            l1l11lllll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lllll.show()
            l1l11l1lll.pack_end(l1l11lllll, True, True, 0)
            l1l1ll1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1ll1.show()
            vbox.pack_start(l1l11l1lll, True, True, 0)
            l1ll1lllll=self.__1ll1l1ll1(l1l11ll1=l1ll1lll11)
            vbox.pack_start(l1ll1lllll, False, False, 0)
            vbox.pack_end(l1l1ll1ll1, False, False, 0)
            l1l11llll1.pack_start(vbox, True, True,5)
            l1l11llll1.show()
            l1l1ll1111.pack_end(l1l11llll1, False, False, 0)
            vbox.show()
            l1l11l1lll.show()
        window.run()
class l1l1lll11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1lll1ll(self, widget, l1ll111ll1):
        if l1ll111ll1 == Gtk.ResponseType.OK:
            self.result = l111lll (u"ࠥࡓࡐࠨ৩")
        elif l1ll111ll1 == Gtk.ResponseType.CANCEL:
            self.result = l111lll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll111ll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l111lll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1l111lll(self, title=l111lll (u"ࠨࠢ৬"), message=l111lll (u"ࠢࠣ৭") , l1l1111ll=True):
        if l1l1111ll:
            l1l1l1l1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1l1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l1l1ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l111lll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1lll1ll)
        window.run()
class l1l1l1l11l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1lll11l=None
        self.result = None
    def l1l1lll1ll(self, widget, l1ll111ll1):
        print(widget, l1ll111ll1)
        if l1ll111ll1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll111ll1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll111ll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l11ll11l(self, widget, l1ll11lll1):
        if l1ll11lll1.get_active():
            self.l1l1lll11l = 1
        else:
            self.l1l1lll11l = 0
    def l1l1l1ll11(self, title=l111lll (u"ࠤࠥ৯"), message=l111lll (u"ࠥࠦৰ"), l1ll11ll11 =l111lll (u"ࠦࠧৱ"),l1l1111ll=True):
        if l1l1111ll:
            l1l1l1l1ll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1l1l1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1l1l1ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l111lll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1lll1ll)
        l1l1lll1l1 = Gtk.CheckButton(l1ll11ll11)
        l1l1lll1l1.connect(l111lll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l11ll11l, l1l1lll1l1)
        l1l1lll1l1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1lll1l1, expand=True, fill=True, padding=0)
        l1l1lll1l1.show()
        window.run()
def l11lll1l1(title, msg, l1ll11ll11=l111lll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1l1111ll=True):
    result=None
    try:
        l1l1l1l111 = l1l1l1l11l()
        l1l1l1l111.l1l1l1ll11(title, msg, l1ll11ll11, l1l1111ll)
        result = {l111lll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1l1l111.result,  l111lll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1l1l111.l1l1lll11l}
    except Exception as e:
        logger.exception(l111lll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l111lll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1111llll = l1l111l11()
    message= l111lll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1l11l1l = l111lll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1111llll.l111l1ll1(message, l111lll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1l1111ll=True, l1ll1lll11=l1l1l11l1l)