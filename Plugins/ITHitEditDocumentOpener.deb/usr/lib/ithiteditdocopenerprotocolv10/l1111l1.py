#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l = 2048
l1lll11l = 7
def l11lll1 (l1ll1l1):
    global l1lll1
    l1111l = ord (l1ll1l1 [-1])
    l11111l = l1ll1l1 [:-1]
    l1l11l1 = l1111l % len (l11111l)
    l11l1l1 = l11111l [:l1l11l1] + l11111l [l1l11l1:]
    if l1l11l:
        l11ll = l1l111l () .join ([unichr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    return eval (l11ll)
import logging
import os
import re
from l1lll111 import l111111l
logger = logging.getLogger(l11lll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l111l11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11lll1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l11ll():
    try:
        out = os.popen(l11lll1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11lll1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11lll1 (u"ࠤࠥॸ").join(result)
                logger.info(l11lll1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11lll1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11lll1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11lll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l111111l(l11lll1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11lll1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l111l11(l11lll1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))