#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l1 = sys.version_info [0] == 2
l111ll = 2048
l11111l = 7
def l1ll1ll (l11llll):
    global l1ll11l
    l111lll = ord (l11llll [-1])
    l1l1 = l11llll [:-1]
    l1llll1l = l111lll % len (l1l1)
    l1l1l1l = l1l1 [:l1llll1l] + l1l1 [l1llll1l:]
    if l1l11l1:
        l1ll1l1l = l1111ll () .join ([unichr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    else:
        l1ll1l1l = str () .join ([chr (ord (char) - l111ll - (l1ll11l1 + l111lll) % l11111l) for l1ll11l1, char in enumerate (l1l1l1l)])
    return eval (l1ll1l1l)
import logging
import os
import re
from l1ll11 import l1llll1ll
logger = logging.getLogger(l1ll1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1l1l11(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1ll (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll():
    try:
        out = os.popen(l1ll1ll (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1ll1ll (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1ll1ll (u"ࠢࠣॶ").join(result)
                logger.info(l1ll1ll (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1ll1ll (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1ll1ll (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1ll1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1ll(l1ll1ll (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1ll1ll (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1l1l11(l1ll1ll (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))