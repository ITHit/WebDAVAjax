#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import re
class l1ll1ll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111111 = kwargs.get(l1l11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11111l = kwargs.get(l1l11l (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1llll11l = self.l1lll1lll(args)
        if l1llll11l:
            args=args+ l1llll11l
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        l1llll11l=None
        l1l1ll11 = args[0][0]
        if re.search(l1l11l (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l1ll11):
            l1llll11l = (l1l11l (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1111111
                            ,)
        return l1llll11l
class l1lll1l1l(Exception):
    def __init__(self, *args, **kwargs):
        l1llll11l = self.l1lll1lll(args)
        if l1llll11l:
            args = args + l1llll11l
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        s = l1l11l (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1l11l (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1llll1ll(Exception):
    pass
class l11l11(Exception):
    pass
class l1lllllll(Exception):
    def __init__(self, message, l1111ll1, url):
        super(l1lllllll,self).__init__(message)
        self.l1111ll1 = l1111ll1
        self.url = url
class l11111l1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l111111l(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111ll(Exception):
    pass
class l1111l1l(Exception):
    pass
class l11l1lll(Exception):
    pass