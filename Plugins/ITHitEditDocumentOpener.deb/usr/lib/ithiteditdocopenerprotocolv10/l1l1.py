#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1l = 2048
l1llll1l = 7
def l11l (l11ll1):
    global l1lll11l
    l1ll1 = ord (l11ll1 [-1])
    l11ll11 = l11ll1 [:-1]
    l11l111 = l1ll1 % len (l11ll11)
    l1l1l = l11ll11 [:l11l111] + l11ll11 [l11l111:]
    if l111ll1:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    return eval (l11l11l)
import hashlib
import os
import l1lll11
from l1lll1l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll11 import l1lllll
from l1ll11ll import l11111, l111
import logging
logger = logging.getLogger(l11l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11ll1l():
    def __init__(self, l1l1lll,l11llll, l1ll1l1= None, l111l1l=None):
        self.l1111=False
        self.l1l1l11 = self._11111l()
        self.l11llll = l11llll
        self.l1ll1l1 = l1ll1l1
        self.l1lllll1 = l1l1lll
        if l1ll1l1:
            self.l1l1ll = True
        else:
            self.l1l1ll = False
        self.l111l1l = l111l1l
    def _11111l(self):
        try:
            return l1lll11.l11lll1() is not None
        except:
            return False
    def open(self):
        l11l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1l11:
            raise NotImplementedError(l11l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l111l = self.l1lllll1
        if self.l11llll.lower().startswith(self.l1lllll1.lower()):
            l11l1l1 = re.compile(re.escape(self.l1lllll1), re.IGNORECASE)
            l11llll = l11l1l1.sub(l11l (u"ࠨࠩࠄ"), self.l11llll)
            l11llll = l11llll.replace(l11l (u"ࠩࡧࡥࡻ࠭ࠅ"), l11l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll11(self.l1lllll1, l1l111l, l11llll, self.l1ll1l1)
    def l1ll11(self,l1lllll1, l1l111l, l11llll, l1ll1l1):
        l11l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1111 = l111l11(l1lllll1)
        l1ll1l1l = self.l1l11ll(l1l1111)
        logger.info(l11l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1111)
        if l1ll1l1l:
            logger.info(l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lllll(l1l1111)
            l1l1111 = l1l1ll1(l1lllll1, l1l111l, l1ll1l1, self.l111l1l)
        logger.debug(l11l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l11l1=l1l1111 + l11l (u"ࠤ࠲ࠦࠌ") + l11llll
        ll = l11l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l11l1+ l11l (u"ࠫࠧ࠭ࠎ")
        logger.debug(ll)
        l1lll1l = os.system(ll)
        if (l1lll1l != 0):
            raise IOError(l11l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l11l1, l1lll1l))
    def l1l11ll(self, l1l1111):
        if os.path.exists(l1l1111):
            if os.path.islink(l1l1111):
                l1l1111 = os.readlink(l1l1111)
            if os.path.ismount(l1l1111):
                return True
        return False
def l111l11(l1lllll1):
    l1ll11l = l1lllll1.replace(l11l (u"࠭࡜࡝ࠩࠐ"), l11l (u"ࠧࡠࠩࠑ")).replace(l11l (u"ࠨ࠱ࠪࠒ"), l11l (u"ࠩࡢࠫࠓ"))
    l1ll111 = l11l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l1ll=os.environ[l11l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll=os.path.join(l11l1ll,l1ll111, l1ll11l)
    l1llll11=os.path.abspath(l1ll)
    return l1llll11
def l1l11(l11ll):
    if not os.path.exists(l11ll):
        os.makedirs(l11ll)
def l1ll1l11(l1lllll1, l1l111l, l1ll11l1=None, password=None):
    l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11ll = l111l11(l1lllll1)
    l1l11(l11ll)
    if not l1ll11l1:
        l1lll111 = l1ll1ll()
        l1lll1 =l1lll111.l1llll(l11l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l111l + l11l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l111l + l11l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lll1, str):
            l1ll11l1, password = l1lll1
        else:
            raise l111()
        logger.info(l11l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11ll))
    l111ll = pwd.getpwuid( os.getuid())[0]
    l1l111=os.environ[l11l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll1ll={l11l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111ll, l11l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1lllll1, l11l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11ll, l11l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l111, l11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll11l1, l11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll1ll, temp_file)
        if not os.path.exists(os.path.join(l1lll, l11l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1llll1=l11l (u"ࠦࡵࡿࠢࠣ")
            key=l11l (u"ࠧࠨࠤ")
        else:
            l1llll1=l11l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l=l11l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1llll1,temp_file.name)
        l1l1l1l=[l11l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll, l1ll1l)]
        p = subprocess.Popen(l1l1l1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11ll
    logger.debug(l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llll11=os.path.abspath(l11ll)
    logger.debug(l11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llll11)
    return l1llll11
def l1l1ll1(l1lllll1, l1l111l, l1ll1l1, l111l1l):
    l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l1(title):
        l1111l=30
        if len(title)>l1111l:
            l1l1l1=title.split(l11l (u"ࠨ࠯ࠣ࠳"))
            l1=l11l (u"ࠧࠨ࠴")
            for block in l1l1l1:
                l1+=block+l11l (u"ࠣ࠱ࠥ࠵")
                if len(l1) > l1111l:
                    l1+=l11l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1
        return title
    l1ll11l1 = l11l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l11l (u"ࠦࠧ࠸")
    os.system(l11l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1111ll = l111l11(l1lllll1)
    l11ll = l111l11(hashlib.sha1(l1lllll1.encode()).hexdigest()[:10])
    l1l11(l11ll)
    logger.info(l11l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11ll))
    if l1ll1l1:
        l11l1l = [l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l11l (u"ࠤ࠰ࡸࠧ࠽"), l11l (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l11l (u"ࠫ࠲ࡵࠧ࠿"), l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1ll11l1, l1ll1l1),
                    urllib.parse.unquote(l1l111l), os.path.abspath(l11ll)]
    else:
        l1ll11l1, password = l1ll1lll(l11ll, l1l111l, l111l1l)
        if l1ll11l1.lower() != l11l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l11l1l = [l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11l (u"ࠤ࠰ࡸࠧࡄ"), l11l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11l (u"ࠫ࠲ࡵࠧࡆ"), l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1ll11l1,
                        urllib.parse.unquote(l1l111l), os.path.abspath(l11ll)]
        else:
            raise l111()
    logger.info(l11l (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l11l (u"ࠢࠡࠤࡉ").join(l11l1l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1ll1ll1 = l11l (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1ll1ll1.encode())
    if len(err) > 0:
        l111111 = l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l111111)
        raise l11111(l111111, l1l1ll1=l1lll11.l11lll1(), l1l111l=l1l111l)
    logger.info(l11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l11l (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11ll, l1111ll))
    l1llll11=os.path.abspath(l1111ll)
    return l1llll11
def l1ll1lll(l1lllll1, l1l111l, l111l1l):
    l1l11l = os.path.join(os.environ[l11l (u"ࠧࡎࡏࡎࡇࠥࡎ")], l11l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l11l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1l11l)):
       os.makedirs(os.path.dirname(l1l11l))
    l1llllll = l111l1l.get_value(l11l (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l11l (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1lll111 = l1ll1ll(l1lllll1, l1llllll)
    l1ll11l1, password = l1lll111.l1llll(l11l (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1l111l + l11l (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1l111l + l11l (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1ll11l1 != l11l (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l111lll(l1lllll1, l1ll11l1):
        l11 = l11l (u"ࠢࠡࠤࡗ").join([l1lllll1, l1ll11l1, l11l (u"ࠨࠤࠪࡘ") + password + l11l (u"࡙ࠩࠥࠫ"), l11l (u"ࠪࡠࡳ࡚࠭")])
        with open(l1l11l, l11l (u"ࠫࡼ࠱࡛ࠧ")) as l111l:
            l111l.write(l11)
        os.chmod(l1l11l, 0o600)
    return l1ll11l1, password
def l111lll(l1lllll1, l1ll11l1):
    l1l11l = l11lll = os.path.join(os.environ[l11l (u"ࠧࡎࡏࡎࡇࠥ࡜")], l11l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l11l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1l11l):
        with open(l1l11l, l11l (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l11l11 = data[0].split(l11l (u"ࠤࠣࠦࡠ"))
            if l1lllll1 == l11l11[0] and l1ll11l1 == l11l11[1]:
                return True
    return False