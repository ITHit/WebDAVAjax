#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import hashlib
import os
import l1lll111
from l11ll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll111 import l1lll1
from l1111l import l1l1ll1, l1
import logging
logger = logging.getLogger(l11llll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111ll():
    def __init__(self, l1ll1ll,l11111, l1llllll= None, l1l1ll=None):
        self.l111111=False
        self.l1l111 = self._1l1111()
        self.l11111 = l11111
        self.l1llllll = l1llllll
        self.l11l11 = l1ll1ll
        if l1llllll:
            self.l1ll1l1 = True
        else:
            self.l1ll1l1 = False
        self.l1l1ll = l1l1ll
    def _1l1111(self):
        try:
            return l1lll111.l1lll1ll() is not None
        except:
            return False
    def open(self):
        l11llll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l111:
            raise NotImplementedError(l11llll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11llll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1lllll = self.l11l11
        if self.l11111.lower().startswith(self.l11l11.lower()):
            l1lllll1 = re.compile(re.escape(self.l11l11), re.IGNORECASE)
            l11111 = l1lllll1.sub(l11llll (u"ࠨࠩࠄ"), self.l11111)
            l11111 = l11111.replace(l11llll (u"ࠩࡧࡥࡻ࠭ࠅ"), l11llll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11l1(self.l11l11, l1lllll, l11111, self.l1llllll)
    def l11l1(self,l11l11, l1lllll, l11111, l1llllll):
        l11llll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11llll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111ll1 = l1ll11(l11l11)
        l1l1l1l = self.l1ll1lll(l111ll1)
        logger.info(l11llll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111ll1)
        if l1l1l1l:
            logger.info(l11llll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll1(l111ll1)
            l111ll1 = l11111l(l11l11, l1lllll, l1llllll, self.l1l1ll)
        logger.debug(l11llll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l1ll=l111ll1 + l11llll (u"ࠤ࠲ࠦࠌ") + l11111
        l1llll = l11llll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l1ll+ l11llll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1llll)
        l11ll = os.system(l1llll)
        if (l11ll != 0):
            raise IOError(l11llll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l1ll, l11ll))
    def l1ll1lll(self, l111ll1):
        if os.path.exists(l111ll1):
            if os.path.islink(l111ll1):
                l111ll1 = os.readlink(l111ll1)
            if os.path.ismount(l111ll1):
                return True
        return False
def l1ll11(l11l11):
    l1111l1 = l11l11.replace(l11llll (u"࠭࡜࡝ࠩࠐ"), l11llll (u"ࠧࡠࠩࠑ")).replace(l11llll (u"ࠨ࠱ࠪࠒ"), l11llll (u"ࠩࡢࠫࠓ"))
    l11l = l11llll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll11l1=os.environ[l11llll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l111=os.path.join(l1ll11l1,l11l, l1111l1)
    l11=os.path.abspath(l11l111)
    return l11
def l1ll1l1l(l111l1):
    if not os.path.exists(l111l1):
        os.makedirs(l111l1)
def l1ll1l(l11l11, l1lllll, l111=None, password=None):
    l11llll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111l1 = l1ll11(l11l11)
    l1ll1l1l(l111l1)
    if not l111:
        l1l11l1 = l1l11()
        l1ll =l1l11l1.l11l1l(l11llll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1lllll + l11llll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1lllll + l11llll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll, str):
            l111, password = l1ll
        else:
            raise l1()
        logger.info(l11llll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111l1))
    l11l11l = pwd.getpwuid( os.getuid())[0]
    l1llll1l=os.environ[l11llll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11ll11=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l1l11={l11llll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11l, l11llll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l11, l11llll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111l1, l11llll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1llll1l, l11llll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111, l11llll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l1l11, temp_file)
        if not os.path.exists(os.path.join(l11ll11, l11llll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l=l11llll (u"ࠦࡵࡿࠢࠣ")
            key=l11llll (u"ࠧࠨࠤ")
        else:
            l1l=l11llll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11llll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1lll=l11llll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l,temp_file.name)
        l111l=[l11llll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11llll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11ll11, l1l1lll)]
        p = subprocess.Popen(l111l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11llll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11llll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11llll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111l1
    logger.debug(l11llll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11llll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11llll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11llll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11=os.path.abspath(l111l1)
    logger.debug(l11llll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11)
    return l11
def l11111l(l11l11, l1lllll, l1llllll, l1l1ll):
    l11llll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1l(title):
        l1ll11l=30
        if len(title)>l1ll11l:
            l11lll1=title.split(l11llll (u"ࠨ࠯ࠣ࠳"))
            l1ll11ll=l11llll (u"ࠧࠨ࠴")
            for block in l11lll1:
                l1ll11ll+=block+l11llll (u"ࠣ࠱ࠥ࠵")
                if len(l1ll11ll) > l1ll11l:
                    l1ll11ll+=l11llll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll11ll
        return title
    l111 = l11llll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l11llll (u"ࠦࠧ࠸")
    os.system(l11llll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1l11l = l1ll11(l11l11)
    l111l1 = l1ll11(hashlib.sha1(l11l11.encode()).hexdigest()[:10])
    l1ll1l1l(l111l1)
    logger.info(l11llll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l111l1))
    if l1llllll:
        l1ll1 = [l11llll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l11llll (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l11llll (u"ࠤ࠰ࡸࠧ࠽"), l11llll (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l11llll (u"ࠫ࠲ࡵࠧ࠿"), l11llll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l111, l1llllll),
                    urllib.parse.unquote(l1lllll), os.path.abspath(l111l1)]
    else:
        l111, password = l11ll1l(l111l1, l1lllll, l1l1ll)
        if l111.lower() != l11llll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1ll1 = [l11llll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11llll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11llll (u"ࠤ࠰ࡸࠧࡄ"), l11llll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11llll (u"ࠫ࠲ࡵࠧࡆ"), l11llll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l111,
                        urllib.parse.unquote(l1lllll), os.path.abspath(l111l1)]
        else:
            raise l1()
    logger.info(l11llll (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l11llll (u"ࠢࠡࠤࡉ").join(l1ll1)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11l1l1 = l11llll (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11l1l1.encode())
    if len(err) > 0:
        l1ll1ll1 = l11llll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1ll1ll1)
        raise l1l1ll1(l1ll1ll1, l11111l=l1lll111.l1lll1ll(), l1lllll=l1lllll)
    logger.info(l11llll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l11llll (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l111l1, l1l11l))
    l11=os.path.abspath(l1l11l)
    return l11
def l11ll1l(l11l11, l1lllll, l1l1ll):
    l111ll = os.path.join(os.environ[l11llll (u"ࠧࡎࡏࡎࡇࠥࡎ")], l11llll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l11llll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l111ll)):
       os.makedirs(os.path.dirname(l111ll))
    l1111 = l1l1ll.get_value(l11llll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l11llll (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l11l1 = l1l11(l11l11, l1111)
    l111, password = l1l11l1.l11l1l(l11llll (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1lllll + l11llll (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1lllll + l11llll (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l111 != l11llll (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l111l1l(l11l11, l111):
        l1ll1l11 = l11llll (u"ࠢࠡࠤࡗ").join([l11l11, l111, l11llll (u"ࠨࠤࠪࡘ") + password + l11llll (u"࡙ࠩࠥࠫ"), l11llll (u"ࠪࡠࡳ࡚࠭")])
        with open(l111ll, l11llll (u"ࠫࡼ࠱࡛ࠧ")) as l1l111l:
            l1l111l.write(l1ll1l11)
        os.chmod(l111ll, 0o600)
    return l111, password
def l111l1l(l11l11, l111):
    l111ll = l1l1l1 = os.path.join(os.environ[l11llll (u"ࠧࡎࡏࡎࡇࠥ࡜")], l11llll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l11llll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l111ll):
        with open(l111ll, l11llll (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1l11ll = data[0].split(l11llll (u"ࠤࠣࠦࡠ"))
            if l11l11 == l1l11ll[0] and l111 == l1l11ll[1]:
                return True
    return False