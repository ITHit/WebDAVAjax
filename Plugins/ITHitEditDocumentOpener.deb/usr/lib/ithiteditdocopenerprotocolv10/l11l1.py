#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l11111 = 7
def l11 (l1l111l):
    global l1lll11
    l11l11 = ord (l1l111l [-1])
    l1l1ll1 = l1l111l [:-1]
    l1llll = l11l11 % len (l1l1ll1)
    l1lll1ll = l1l1ll1 [:l1llll] + l1l1ll1 [l1llll:]
    if l11l1l:
        l1l1l1 = l1ll1l1 () .join ([unichr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    return eval (l1l1l1)
import gi
gi.require_version(l11 (u"࠭ࡇࡵ࡭ࠪ঻"), l11 (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l111l1
import logging
logger = logging.getLogger(l11 (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l1lllll1(Gtk.Window):
    def __init__(self, l1ll11111l, l1l1l1llll):
        Gtk.Window.__init__(self)
        self.l111l1l=30
        self.l1ll1lll11 = False
        self.service = l1ll11111l
        self.l11l=l1l1l1llll
        self.l1l1=l1l111l1.l11ll11l
        self.l1l11lllll = Gtk.ListStore(str)
        self.l1l1l11111()
    def l1l1ll11ll(self, service):
        l1ll1l1l11 = self.l1l1.l1l1l1ll(l11 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1ll1l1l11
    def l1l1l11111(self, l1ll11111l=None):
        if l1ll11111l:
            self.l1l11lllll.clear()
            l1ll11l111=self.l1l1ll11ll(l1ll11111l)
            self.l1l11lllll.append([l11 (u"ࠥࠦি")])
            for l11l in l1ll11l111:
                self.l1l11lllll.append([l11l])
        else:
            self.l1l11lllll.clear()
            self.l1l11lllll.append([l11 (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1l11lll1l(self, widget, data=None):
        l1ll1l11ll= widget.get_active()
        if data == l11 (u"ࠧ࠷ࠢু") and l1ll1l11ll:
            self.l1l1l11111()
            self.l1lll1111l.set_active(0)
            self.l1ll111l11.set_text(l11 (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1ll111l11.set_sensitive(False)
            self.l1lll1111l.set_sensitive(False)
        else:
            self.l1l1l11111(l1ll11111l=self.service)
            self.l1lll1111l.set_active(0)
            self.l1ll111l11.set_text(l11 (u"ࠢࠣৃ"))
            self.l1lll1111l.set_sensitive(True)
            self.l1ll111l11.set_sensitive(True)
    def l1l1l1111l(self, widget):
        if widget.get_active():
            l11l = widget.get_child().get_text()
        else:
            l11l = self.l1l11lllll[widget.get_active()][0]
        password = self.l1ll111111(self.service, l11l)
        if password:
            self.l1ll111l11.set_text(password)
        else:
            self.l1ll111l11.set_text(l11 (u"ࠣࠤৄ"))
    def l1ll1l11l1(self, l11l, pwd, service):
        keyring.set_password(service, l11l, pwd)
        l1ll1l1l11=self.l1l1.l1l1l1ll(l11 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l11l in l1ll1l1l11:
            value = self.l1l1.get_value(l11 (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l1l1.l1l1111l(l11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l11 (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l11l))
    def l1ll111111(self, service, l11l):
        l1l11ll11l = keyring.get_password(service, l11l)
        return l1l11ll11l
    def l1l11lll11(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1lllll(self, widget, data=None):
        self.l1ll1lll11=widget.get_active()
    def l1ll1ll(self, message, title=l11 (u"࠭ࠧ৉"), l111ll1ll=True):
        if l111ll1ll:
            l1l1lll111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll11ll1l = Gtk.MessageDialog(self,
            l1l1lll111,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll11ll1l.set_title(title)
        l1ll11ll1l.set_default_response(Gtk.ResponseType.OK)
        l1l1ll11l1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l1l1l1 = Gtk.VBox()
        l1l1l1lll1 = Gtk.Box(spacing=1)
        l1l1l1lll1.set_homogeneous(False)
        l1l11ll1ll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11ll1ll.set_homogeneous(False)
        l1l1l1ll1l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1ll1l.set_homogeneous(False)
        l1l1l1lll1.pack_start(l1l11ll1ll, True, True, 0)
        l1l1l1lll1.pack_start(l1l1l1ll1l, True, True, 0)
        l1ll111l1l = l1ll11ll1l.get_content_area()
        l1l1l1l1ll = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll111l1l.pack_start(l1l1l1l1ll, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l1l11l = Gtk.Label()
        l1ll11l1ll = Gtk.Label()
        l1ll11l1ll.set_text(l11 (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1ll11l1ll, True, True, 0)
        l1l1l1l11l.set_text(l11 (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1l1l1l11l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l1l11l, 0, 1, 0, 1)
        l1l1l111ll = Gtk.RadioButton.new_with_label_from_widget(None, l11 (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1l1l111ll.connect(l11 (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1l11lll1l, l11 (u"ࠦ࠶ࠨৎ"))
        table.attach(l1l1l111ll, 1, 2, 0, 1)
        l1ll1l1111 = Gtk.RadioButton.new_with_label_from_widget(l1l1l111ll, l11 (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1ll1l1111.connect(l11 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1l11lll1l, l11 (u"ࠢ࠳ࠤ৑"))
        table.attach(l1ll1l1111, 1, 2, 1, 2)
        l1ll1ll1l1 = Gtk.Label()
        l1ll1ll1l1.set_text(l11 (u"ࠣࠢࠥ৒"))
        table.attach(l1ll1ll1l1, 0, 1, 4, 6)
        l1ll111lll = Gtk.Label()
        l1ll111lll.set_text(l11 (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1ll111lll.set_justify(Gtk.Justification.RIGHT)
        l1ll111lll.set_alignment(xalign=1, yalign=0.5)
        self.l1lll1111l = Gtk.ComboBox.new_with_model_and_entry(self.l1l11lllll)
        self.l1lll1111l.set_entry_text_column(0)
        table.attach(l1ll111lll, 0, 1, 6, 8)
        table.attach(self.l1lll1111l, 1, 3, 6, 8)
        self.l1lll1111l.connect(l11 (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1l1l1111l)
        l1ll11lll1 = Gtk.Label()
        l1ll11lll1.set_text(l11 (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1ll11lll1.set_justify(Gtk.Justification.RIGHT)
        l1ll11lll1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll111l11 = Gtk.Entry()
        self.l1ll111l11.set_visibility(False)
        self.l1ll111l11.connect(l11 (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1l11lll11, l1ll11ll1l)
        table.attach(l1ll11lll1, 0, 1, 8, 10)
        table.attach(self.l1ll111l11, 1, 3, 8, 10)
        l1l1l1l111 = Gtk.CheckButton(l11 (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1l1l1l111.connect(l11 (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1ll1lllll, l1l1l1l111)
        l1l1l1l111.set_active(False)
        table.attach(l1l1l1l111, 1, 3, 12, 14)
        l1ll1ll111 = Gtk.Label()
        l1ll1ll111.set_text(l11 (u"ࠣࠢࠥ৙") * 5)
        l1l1l1l1l1.pack_start(l1ll1ll111, True, True, 0)
        if self.l11l:
            l1ll1l1111.set_active(True)
            self.l1lll1111l.set_active(0)
            self.l1lll1111l.set_sensitive(True)
            self.l1ll111l11.set_text(l11 (u"ࠤࠥ৚"))
            self.l1ll111l11.set_sensitive(True)
        else:
            self.l1lll1111l.set_active(0)
            self.l1lll1111l.set_sensitive(False)
            self.l1ll111l11.set_text(l11 (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1ll111l11.set_sensitive(False)
        l1l1ll11l1.pack_start(vbox, True, True, 0)
        l1l1ll11l1.pack_start(table, True, True, 0)
        l1l1ll11l1.pack_end(l1l1l1l1l1, True, True, 0)
        l1l1l1l1ll.pack_start(l1l1ll11l1, True, True, 0)
        l1ll11ll1l.show_all()
        response = l1ll11ll1l.run()
        if self.l1lll1111l.get_active():
            l11l = self.l1lll1111l.get_child().get_text()
        else:
            l11l = self.l1l11lllll[self.l1lll1111l.get_active()][0]
        pwd = self.l1ll111l11.get_text()
        l1ll11ll1l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll1lll11:
                self.l1ll1l11l1(l11l, pwd, self.service)
            return l11l, pwd
        else:
            return l11 (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l11 (u"ࠬ࠭ঢ়")
class l11llll1l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll111ll1(self, l11lll11):
        l1ll1l111l = Gtk.ScrolledWindow()
        l1ll1l111l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1lll11111=None
        self.l1l11llll1 = Gtk.TextBuffer()
        self.l1l11llll1.set_text(l11lll11)
        self.set_style()
        regexp= l11 (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1l1ll1l1l = self._1l1llllll(l11lll11, regexp)
        self.l1l1l11lll(l1l1ll1l1l, self.l1l11llll1.get_start_iter())
        self.l1l1ll1l11 = Gtk.TextView(buffer=self.l1l11llll1)
        self.l1l1ll1l11.set_property(l11 (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1l1ll1l11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1ll1l11.connect(l11 (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1l1llll1l)
        self.l1l1ll1l11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1l111l.set_size_request(300,100)
        self.l1l1ll1l11.show()
        l1ll1l111l.add(self.l1l1ll1l11)
        l1ll1l111l.show()
        return l1ll1l111l
    def _1l1llll1l(self, *args, **kwargs):
        l1l11ll111, l1l1ll1lll=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l11ll111, l1l1ll1lll).get_tags()
        if not self.l1lll11111:
            self.l1lll11111 = args[1].window.get_cursor()
            self.l1l1l111l1 = Gdk.Cursor(Gdk.CursorType.l1ll11l11l)
        elif tag:
            args[1].window.set_cursor(self.l1l1l111l1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1lll11111:
                args[1].window.set_cursor(self.l1lll11111)
    def _1l1llllll(self, l11lll11, l1ll1l1lll):
        res=[]
        l1ll1111ll=re.findall(l1ll1l1lll,l11lll11)
        for l1l11l1ll1 in l1ll1111ll:
            for el in l1l11l1ll1:
                if el:
                    res.append(el)
        return res
    def l1l1l11lll(self, l1l1ll1l1l, start):
        l1ll1ll11l=0
        for text in l1l1ll1l1l:
            end = self.l1l11llll1.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1ll11l+=1
                l1l1lllll1, l1l1llll11 = match
                tag = self.l1l11llll1.create_tag(str(l1ll1ll11l), foreground=l11 (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l11 (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1ll1llll1, text)
                self.l1l11llll1.apply_tag(tag, l1l1lllll1, l1l1llll11)
                self.l1l1l11lll(l1l1ll1l1l, l1l1llll11)
    def _1ll1llll1(self, tag, widget, l1l1ll1111, _1l1ll111l, text):
        _1l1l11ll1 = l1l1ll1111.type
        _1ll1lll1l = l1l1ll1111.window
        if _1l1l11ll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l11ll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1ll1111.button
            self.l1lll11111 = Gdk.Cursor(Gdk.CursorType.l1ll11l11l)
            if _1l1l11ll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l11 (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1lll11ll(self, message, title=l11 (u"ࠬ࠭৤"), l111ll1ll=True, l1l1ll1ll1=None):
        if l111ll1ll:
            l1l1lll111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1lll111,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1ll1ll1:
            l1ll111l1l = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1l1lll1 = Gtk.HBox(spacing=0)
            l1l1lll1l1 = Gtk.HBox(spacing=5)
            l1ll11l1l1 = Gtk.Label()
            l1ll11l1l1.set_markup(l11 (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1ll11l1l1.set_line_wrap(True)
            l1ll11l1l1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l11 (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1lll1ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll1ll.show()
            l1l1l1ll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1ll11.show()
            l1l1l11l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11l11.show()
            l1l1l1lll1.pack_start(separator, True, True, 0)
            l1l1l1lll1.pack_start(l1l1lll1ll, True, True, 0)
            l1l1l1lll1.pack_start(l1l1l1ll11, True, True, 0)
            l1l1l1lll1.pack_start(l1l1l11l11, True, True, 0)
            l1l1l1lll1.pack_start(l1ll11l1l1, False, True, 0)
            l1ll1111l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1111l1.show()
            l1l1l1lll1.pack_end(l1ll1111l1, True, True, 0)
            l1ll1ll1ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll1ll.show()
            vbox.pack_start(l1l1l1lll1, True, True, 0)
            l1ll1l111l=self.__1ll111ll1(l11lll11=l1l1ll1ll1)
            vbox.pack_start(l1ll1l111l, False, False, 0)
            vbox.pack_end(l1ll1ll1ll, False, False, 0)
            l1l1lll1l1.pack_start(vbox, True, True,5)
            l1l1lll1l1.show()
            l1ll111l1l.pack_end(l1l1lll1l1, False, False, 0)
            vbox.show()
            l1l1l1lll1.show()
        window.run()
class l1111l11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11ll1l1(self, widget, l1l11l1lll):
        if l1l11l1lll == Gtk.ResponseType.OK:
            self.result = l11 (u"ࠣࡑࡎࠦ১")
        elif l1l11l1lll == Gtk.ResponseType.CANCEL:
            self.result = l11 (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1l11l1lll == Gtk.ResponseType.DELETE_EVENT:
            self.result = l11 (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l111l1l11(self, title=l11 (u"ࠦࠧ৪"), message=l11 (u"ࠧࠨ৫") , l111ll1ll=True):
        if l111ll1ll:
            l1l1lll111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l11 (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1l11ll1l1)
        window.run()
class l1l1l11l1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll11llll=None
        self.result = None
    def l1l11ll1l1(self, widget, l1l11l1lll):
        print(widget, l1l11l1lll)
        if l1l11l1lll == Gtk.ResponseType.OK:
            self.result = True
        elif l1l11l1lll == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l11l1lll == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1lllll(self, widget, l1ll1l1l1l):
        if l1ll1l1l1l.get_active():
            self.l1ll11llll = 1
        else:
            self.l1ll11llll = 0
    def l1l1lll11l(self, title=l11 (u"ࠢࠣ৭"), message=l11 (u"ࠣࠤ৮"), l1ll11ll11 =l11 (u"ࠤࠥ৯"),l111ll1ll=True):
        if l111ll1ll:
            l1l1lll111= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l11 (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1l11ll1l1)
        l1l1l1l111 = Gtk.CheckButton(l1ll11ll11)
        l1l1l1l111.connect(l11 (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1ll1lllll, l1l1l1l111)
        l1l1l1l111.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1l1l111, expand=True, fill=True, padding=0)
        l1l1l1l111.show()
        window.run()
def l1ll1l1ll(title, msg, l1ll11ll11=l11 (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l111ll1ll=True):
    result=None
    try:
        l1l11l1l1l = l1l1l11l1l()
        l1l11l1l1l.l1l1lll11l(title, msg, l1ll11ll11, l111ll1ll)
        result = {l11 (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1l11l1l1l.result,  l11 (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1l11l1l1l.l1ll11llll}
    except Exception as e:
        logger.exception(l11 (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l11 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l111111l1 = l11llll1l()
    message= l11 (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1ll1l1ll1 = l11 (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l111111l1.l1lll11ll(message, l11 (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l111ll1ll=True, l1l1ll1ll1=l1ll1l1ll1)