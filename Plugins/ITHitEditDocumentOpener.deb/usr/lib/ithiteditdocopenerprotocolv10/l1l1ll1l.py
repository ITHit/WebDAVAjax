#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1ll = sys.version_info [0] == 2
l1lll1l = 2048
l11l11 = 7
def l1ll11l1 (l11l1ll):
    global l1l1ll
    l1l111l = ord (l11l1ll [-1])
    l11l11l = l11l1ll [:-1]
    l11ll = l1l111l % len (l11l11l)
    l1l111 = l11l11l [:l11ll] + l11l11l [l11ll:]
    if l1lll1ll:
        l11ll11 = l111ll1 () .join ([unichr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    return eval (l11ll11)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1llll11 import l1llll1
from configobj import ConfigObj
l1l11l1l = l1ll11l1 (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11llll1 = l1ll11l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠺࠺࠼࠳࠶ࠢࡤ")
l1l111l1 = l1ll11l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll11l1 (u"ࠣ࠷࠱࠶࠶࠴࠵࠹࠹࠻࠲࠵ࠨࡦ")
l1l1l11l=os.path.join(os.environ.get(l1ll11l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll11l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l111l1.replace(l1ll11l1 (u"ࠦࠥࠨࡩ"), l1ll11l1 (u"ࠧࡥࠢࡪ")).lower())
l11ll1ll=os.environ.get(l1ll11l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll11l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll1l=l11llll1.replace(l1ll11l1 (u"ࠣࠢࠥ࡭"), l1ll11l1 (u"ࠤࡢࠦ࡮"))+l1ll11l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll11l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11lllll=os.path.join(os.environ.get(l1ll11l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll1l)
elif platform.system() == l1ll11l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l1l1=l1llll1(l1l1l11l+l1ll11l1 (u"ࠢ࠰ࠤࡳ"))
    l11lllll = os.path.join(l1l1l1l1, l11lll1l)
else:
    l11lllll = os.path.join( l11lll1l)
l11ll1ll=l11ll1ll.upper()
if l11ll1ll == l1ll11l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l11lll=logging.DEBUG
elif l11ll1ll == l1ll11l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l11lll = logging.INFO
elif l11ll1ll == l1ll11l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l11lll = logging.WARNING
elif l11ll1ll == l1ll11l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l11lll = logging.ERROR
elif l11ll1ll == l1ll11l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l11lll = logging.CRITICAL
elif l11ll1ll == l1ll11l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l11lll = logging.NOTSET
logger = logging.getLogger(l1ll11l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l11lll)
l1l1111l = logging.FileHandler(l11lllll, mode=l1ll11l1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1111l.setLevel(l1l11lll)
formatter = logging.Formatter(l1ll11l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll11l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1111l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11lll)
l11ll11l = SysLogHandler(address=l1ll11l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll11l.setFormatter(formatter)
logger.addHandler(l1l1111l)
logger.addHandler(ch)
logger.addHandler(l11ll11l)
class Settings():
    l1l1l111 = l1ll11l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11ll111 = l1ll11l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1lll1 = l1ll11l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11llll1):
        self.l11l1lll = self._1l111ll(l11llll1)
        self._1l11ll1()
    def _1l111ll(self, l11llll1):
        l11lll11 = l11llll1.split(l1ll11l1 (u"ࠣࠢࠥࢂ"))
        l11lll11 = l1ll11l1 (u"ࠤࠣࠦࢃ").join(l11lll11)
        if platform.system() == l1ll11l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11l1lll = os.path.join(l1l1l11l, l1ll11l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11lll11 + l1ll11l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11l1lll
    def l1l1ll11(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll11l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll11l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11ll1(self):
        if not os.path.exists(os.path.dirname(self.l11l1lll)):
            os.makedirs(os.path.dirname(self.l11l1lll))
        if not os.path.exists(self.l11l1lll):
            self.config = ConfigObj(self.l11l1lll)
            self.config[l1ll11l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll11l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll11l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1lll1
            self.config[l1ll11l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll11l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11ll111
            self.config[l1ll11l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll11l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l111
            self.config[l1ll11l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11l1lll)
            self.l1l1lll1 = self.get_value(l1ll11l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll11l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11ll111 = self.get_value(l1ll11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll11l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l111 = self.get_value(l1ll11l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll11l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l1ll(self):
        l11ll1l1 = l1ll11l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l111
        l11ll1l1 += l1ll11l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11ll111
        l11ll1l1 += l1ll11l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1lll1
        return l11ll1l1
    def __unicode__(self):
        return self._1l1l1ll()
    def __str__(self):
        return self._1l1l1ll()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l11llll1)