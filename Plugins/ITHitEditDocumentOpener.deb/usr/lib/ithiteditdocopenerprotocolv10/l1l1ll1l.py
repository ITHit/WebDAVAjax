#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1llll11 = 2048
l11l11 = 7
def l1lllll (l1lll):
    global l1ll1ll1
    l1ll1lll = ord (l1lll [-1])
    l111l11 = l1lll [:-1]
    l1ll11l = l1ll1lll % len (l111l11)
    l1111 = l111l11 [:l1ll11l] + l111l11 [l1ll11l:]
    if l1ll1:
        l111lll = l1l1ll1 () .join ([unichr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    else:
        l111lll = str () .join ([chr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    return eval (l111lll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1llll1 import ll
from configobj import ConfigObj
l1l111ll = l1lllll (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11ll11l = l1lllll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠷࠺࠳࠶ࠢࡤ")
l1l1lll1 = l1lllll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lllll (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠶࠹࠲࠵ࠨࡦ")
l1l11111=os.path.join(os.environ.get(l1lllll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lllll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1lll1.replace(l1lllll (u"ࠦࠥࠨࡩ"), l1lllll (u"ࠧࡥࠢࡪ")).lower())
l11ll1ll=os.environ.get(l1lllll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lllll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1111l=l11ll11l.replace(l1lllll (u"ࠣࠢࠥ࡭"), l1lllll (u"ࠤࡢࠦ࡮"))+l1lllll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lllll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll111=os.path.join(os.environ.get(l1lllll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1111l)
elif platform.system() == l1lllll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1llll=ll(l1l11111+l1lllll (u"ࠢ࠰ࠤࡳ"))
    l11ll111 = os.path.join(l1l1llll, l1l1111l)
else:
    l11ll111 = os.path.join( l1l1111l)
l11ll1ll=l11ll1ll.upper()
if l11ll1ll == l1lllll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lll1l=logging.DEBUG
elif l11ll1ll == l1lllll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lll1l = logging.INFO
elif l11ll1ll == l1lllll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lll1l = logging.WARNING
elif l11ll1ll == l1lllll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lll1l = logging.ERROR
elif l11ll1ll == l1lllll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lll1l = logging.CRITICAL
elif l11ll1ll == l1lllll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lll1l = logging.NOTSET
logger = logging.getLogger(l1lllll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lll1l)
l11l1lll = logging.FileHandler(l11ll111, mode=l1lllll (u"ࠣࡹ࠮ࠦࡻ"))
l11l1lll.setLevel(l11lll1l)
formatter = logging.Formatter(l1lllll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lllll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11l1lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll1l)
l11llll1 = SysLogHandler(address=l1lllll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11llll1.setFormatter(formatter)
logger.addHandler(l11l1lll)
logger.addHandler(ch)
logger.addHandler(l11llll1)
class Settings():
    l1l11ll1 = l1lllll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1l1l1 = l1lllll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111l1 = l1lllll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11ll11l):
        self.l1l11l11 = self._1l1l111(l11ll11l)
        self._1l11l1l()
    def _1l1l111(self, l11ll11l):
        l11lll11 = l11ll11l.split(l1lllll (u"ࠣࠢࠥࢂ"))
        l11lll11 = l1lllll (u"ࠤࠣࠦࢃ").join(l11lll11)
        if platform.system() == l1lllll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11l11 = os.path.join(l1l11111, l1lllll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11lll11 + l1lllll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11l11
    def l1l1l1ll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1ll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lllll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lllll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11l1l(self):
        if not os.path.exists(os.path.dirname(self.l1l11l11)):
            os.makedirs(os.path.dirname(self.l1l11l11))
        if not os.path.exists(self.l1l11l11):
            self.config = ConfigObj(self.l1l11l11)
            self.config[l1lllll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lllll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lllll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111l1
            self.config[l1lllll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lllll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lllll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1l1l1
            self.config[l1lllll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lllll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l11ll1
            self.config[l1lllll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11l11)
            self.l1l111l1 = self.get_value(l1lllll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lllll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1l1l1 = self.get_value(l1lllll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lllll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l11ll1 = self.get_value(l1lllll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lllll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11lll(self):
        l11ll1l1 = l1lllll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l11ll1
        l11ll1l1 += l1lllll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1l1l1
        l11ll1l1 += l1lllll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111l1
        return l11ll1l1
    def __unicode__(self):
        return self._1l11lll()
    def __str__(self):
        return self._1l11lll()
    def __del__(self):
        self.config.write()
l11lllll = Settings(l11ll11l)