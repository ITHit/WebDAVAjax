#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import logging
import os
import re
from l11l1l1 import l11111ll
logger = logging.getLogger(l1ll11l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll11l1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1lll():
    try:
        out = os.popen(l1ll11l1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1ll11l1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1ll11l1 (u"ࠢࠣॶ").join(result)
                logger.info(l1ll11l1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1ll11l1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1ll11l1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1ll11l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l11111ll(l1ll11l1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1ll11l1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l111(l1ll11l1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))