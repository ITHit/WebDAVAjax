#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11ll = sys.version_info [0] == 2
l1l111 = 2048
l1l1l1 = 7
def l11111l (l1ll11l):
    global l1l1lll
    l11ll11 = ord (l1ll11l [-1])
    l1l1111 = l1ll11l [:-1]
    l111ll = l11ll11 % len (l1l1111)
    l1ll1lll = l1l1111 [:l111ll] + l1l1111 [l111ll:]
    if l1l11ll:
        l1ll111 = l1ll1l1l () .join ([unichr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1ll111 = str () .join ([chr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1ll111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11ll1=logging.WARNING
logger = logging.getLogger(l11111l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11ll1)
l1l1ll11 = SysLogHandler(address=l11111l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11111l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1ll11.setFormatter(formatter)
logger.addHandler(l1l1ll11)
ch = logging.StreamHandler()
ch.setLevel(l1lll11ll1)
logger.addHandler(ch)
class l1lll11111(io.FileIO):
    l11111l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11111l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll11l1l, l1llll11ll,
                     options, d=0, p=0):
            self.device = device
            self.l1lll11l1l = l1lll11l1l
            self.l1llll11ll = l1llll11ll
            if not options:
                options = l11111l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11111l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll11l1l,
                                              self.l1llll11ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll11 = os.path.join(os.path.sep, l11111l (u"ࠪࡩࡹࡩࠧই"), l11111l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1lll1 = path
        else:
            self._1lll1lll1 = self.l1lll1ll11
        super(l1lll11111, self).__init__(self._1lll1lll1, l11111l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1ll1l(self, line):
        return l1lll11111.Entry(*[x for x in line.strip(l11111l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11111l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11111l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11111l (u"ࠤࠦࠦ঍")):
                    yield self._1lll1ll1l(line)
            except ValueError:
                pass
    def l1llllll11(self, attr, value):
        for entry in self.entries:
            l1lll1l1l1 = getattr(entry, attr)
            if l1lll1l1l1 == value:
                return entry
        return None
    def l1llll1lll(self, entry):
        if self.l1llllll11(l11111l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11111l (u"ࠫࡡࡴࠧএ")).encode(l11111l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll11lll(self, entry):
        self.seek(0)
        lines = [l.decode(l11111l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11111l (u"ࠢࠤࠤ঒")):
                if self._1lll1ll1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11111l (u"ࠨࠩও").join(lines).encode(l11111l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll111ll(cls, l1lll11l1l, path=None):
        l1lllll1ll = cls(path=path)
        entry = l1lllll1ll.l1llllll11(l11111l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll11l1l)
        if entry:
            return l1lllll1ll.l1lll11lll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll11l1l, l1llll11ll, options=None, path=None):
        return cls(path=path).l1llll1lll(l1lll11111.Entry(device,
                                                    l1lll11l1l, l1llll11ll,
                                                    options=options))
class l1llllll1l(object):
    def __init__(self, l1llll1l11):
        self.l1llll111l=l11111l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1l1ll=l11111l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llll1l11=l1llll1l11
        self.l1lll1l11l()
        self.l1lll1111l()
        self.l1lllll1l1()
        self.l1lllllll1()
        self.l1llll11l1()
    def l1lll1l11l(self):
        temp_file=open(l1lll1llll,l11111l (u"࠭ࡲࠨঘ"))
        l1llll11=temp_file.read()
        data=json.loads(l1llll11)
        self.user=data[l11111l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l111ll1=data[l11111l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l11lll=data[l11111l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l=data[l11111l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll111=data[l11111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l111=data[l11111l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lllll1l1(self):
        l1ll=os.path.join(l11111l (u"ࠨ࠯ࠣট"),l11111l (u"ࠢࡶࡵࡵࠦঠ"),l11111l (u"ࠣࡵࡥ࡭ࡳࠨড"),l11111l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11111l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll)
    def l1llll11l1(self):
        logger.info(l11111l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l11lll=os.path.join(self.l1l,self.l1llll111l)
        l1llll1l1l = pwd.getpwnam(self.user).pw_uid
        l1lll111l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11lll):
            os.makedirs(l11lll)
            os.system(l11111l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l11lll))
            logger.debug(l11111l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l11lll)
        else:
            logger.debug(l11111l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l11lll)
        l1ll=os.path.join(l11lll, self.l1lll1l1ll)
        print(l1ll)
        logger.debug(l11111l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll)
        with open(l1ll, l11111l (u"ࠤࡺ࠯ࠧ঩")) as l1lll11l11:
            logger.debug(self.l111ll1 + l11111l (u"ࠪࠤࠬপ")+self.l1lllll111+l11111l (u"ࠫࠥࠨࠧফ")+self.l1lll1l111+l11111l (u"ࠬࠨࠧব"))
            l1lll11l11.writelines(self.l111ll1 + l11111l (u"࠭ࠠࠨভ")+self.l1lllll111+l11111l (u"ࠧࠡࠤࠪম")+self.l1lll1l111+l11111l (u"ࠨࠤࠪয"))
        os.chmod(l1ll, 0o600)
        os.chown(l1ll, l1llll1l1l, l1lll111l1)
    def l1lll1111l(self, l1llll1111=l11111l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11111l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll1111 in groups:
            logger.info(l11111l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll1111))
        else:
            logger.warning(l11111l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll1111))
            l1llll1=l11111l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll1111,self.user)
            logger.debug(l11111l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1llll1)
            os.system(l1llll1)
            logger.debug(l11111l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lllllll1(self):
        logger.debug(l11111l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lllll1ll=l1lll11111()
        l1lllll1ll.add(self.l111ll1, self.l11lll, l1llll11ll=l11111l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11111l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11111l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll1llll = urllib.parse.unquote(sys.argv[1])
        if l1lll1llll:
            l1lllll11l=l1llllll1l(l1lll1llll)
        else:
            raise (l11111l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11111l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise