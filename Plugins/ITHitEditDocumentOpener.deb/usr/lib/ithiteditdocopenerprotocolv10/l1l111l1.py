#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l11111 = 7
def l11 (l1l111l):
    global l1lll11
    l11l11 = ord (l1l111l [-1])
    l1l1ll1 = l1l111l [:-1]
    l1llll = l11l11 % len (l1l1ll1)
    l1lll1ll = l1l1ll1 [:l1llll] + l1l1ll1 [l1llll:]
    if l11l1l:
        l1l1l1 = l1ll1l1 () .join ([unichr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    return eval (l1l1l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll1l import l1llllll
from configobj import ConfigObj
l1l11111 = l11 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l1lll1 = l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠸࠱࠹࠱࠴ࠧࡢ")
l11lllll = l11 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l11 (u"ࠨ࠵࠯࠴࠳࠲࠺࠾࠰࠸࠰࠳ࠦࡤ")
l1l1l1l1=os.path.join(os.environ.get(l11 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l11 (u"ࠣ࠰ࠨࡷࠧࡦ") %l11lllll.replace(l11 (u"ࠤࠣࠦࡧ"), l11 (u"ࠥࡣࠧࡨ")).lower())
l11lll1l=os.environ.get(l11 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l11 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l11lll=l1l1lll1.replace(l11 (u"ࠨࠠࠣ࡫"), l11 (u"ࠢࡠࠤ࡬"))+l11 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1l11l=os.path.join(os.environ.get(l11 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l11lll)
elif platform.system() == l11 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11ll1l1=l1llllll(l1l1l1l1+l11 (u"ࠧ࠵ࠢࡱ"))
    l1l1l11l = os.path.join(l11ll1l1, l1l11lll)
else:
    l1l1l11l = os.path.join( l1l11lll)
l11lll1l=l11lll1l.upper()
if l11lll1l == l11 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1ll1111=logging.DEBUG
elif l11lll1l == l11 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1ll1111 = logging.INFO
elif l11lll1l == l11 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1ll1111 = logging.WARNING
elif l11lll1l == l11 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1ll1111 = logging.ERROR
elif l11lll1l == l11 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1ll1111 = logging.CRITICAL
elif l11lll1l == l11 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1ll1111 = logging.NOTSET
logger = logging.getLogger(l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1ll1111)
l1l1llll = logging.FileHandler(l1l1l11l, mode=l11 (u"ࠨࡷࠬࠤࡹ"))
l1l1llll.setLevel(l1ll1111)
formatter = logging.Formatter(l11 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l11 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l1llll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1ll1111)
l1l11ll1 = SysLogHandler(address=l11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l11ll1.setFormatter(formatter)
logger.addHandler(l1l1llll)
logger.addHandler(ch)
logger.addHandler(l1l11ll1)
class Settings():
    l1l111ll = l11 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11ll1ll = l11 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l1ll1l = l11 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l1lll1):
        self.l1l1l111 = self._1l11l1l(l1l1lll1)
        self._11llll1()
    def _1l11l1l(self, l1l1lll1):
        l1l1ll11 = l1l1lll1.split(l11 (u"ࠨࠠࠣࢀ"))
        l1l1ll11 = l11 (u"ࠢࠡࠤࢁ").join(l1l1ll11)
        if platform.system() == l11 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l1l111 = os.path.join(l1l1l1l1, l11 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1ll11 + l11 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l1l111
    def l1l1111l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1ll111l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11llll1(self):
        if not os.path.exists(os.path.dirname(self.l1l1l111)):
            os.makedirs(os.path.dirname(self.l1l1l111))
        if not os.path.exists(self.l1l1l111):
            self.config = ConfigObj(self.l1l1l111)
            self.config[l11 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l11 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l11 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l1ll1l
            self.config[l11 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11ll1ll
            self.config[l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l111ll
            self.config[l11 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l111)
            self.l1l1ll1l = self.get_value(l11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l11 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11ll1ll = self.get_value(l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l111ll = self.get_value(l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l11l11(self):
        l11lll11 = l11 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l111ll
        l11lll11 += l11 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11ll1ll
        l11lll11 += l11 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l1ll1l
        return l11lll11
    def __unicode__(self):
        return self._1l11l11()
    def __str__(self):
        return self._1l11l11()
    def __del__(self):
        self.config.write()
l11ll11l = Settings(l1l1lll1)