#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import hashlib
import os
import l1ll1l1
from l11ll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll1l1 import l111
from l11l1l1 import l1lll1l1, l1l1lll
import logging
logger = logging.getLogger(l1ll11l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1llll1():
    def __init__(self, l1ll11l,l1l1ll1, l1111ll= None, l1lll1ll=None):
        self.l1lll=False
        self.l1ll1l1l = self._111l()
        self.l1l1ll1 = l1l1ll1
        self.l1111ll = l1111ll
        self.l11lll1 = l1ll11l
        if l1111ll:
            self.l1 = True
        else:
            self.l1 = False
        self.l1lll1ll = l1lll1ll
    def _111l(self):
        try:
            return l1ll1l1.l1ll1lll() is not None
        except:
            return False
    def open(self):
        l1ll11l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1l1l:
            raise NotImplementedError(l1ll11l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll11l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1lll1 = self.l11lll1
        if self.l1l1ll1.lower().startswith(self.l11lll1.lower()):
            l1ll1l11 = re.compile(re.escape(self.l11lll1), re.IGNORECASE)
            l1l1ll1 = l1ll1l11.sub(l1ll11l1 (u"ࠨࠩࠄ"), self.l1l1ll1)
            l1l1ll1 = l1l1ll1.replace(l1ll11l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll11l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll11(self.l11lll1, l1lll1, l1l1ll1, self.l1111ll)
    def l1ll11(self,l11lll1, l1lll1, l1l1ll1, l1111ll):
        l1ll11l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll11l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11ll = l11l11(l11lll1)
        l1l1ll = self.l111ll1(l11ll)
        logger.info(l1ll11l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11ll)
        if l1l1ll:
            logger.info(l1ll11l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111(l11ll)
            l11ll = l1l1l(l11lll1, l1lll1, l1111ll, self.l1lll1ll)
        logger.debug(l1ll11l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11lll=l11ll + l1ll11l1 (u"ࠤ࠲ࠦࠌ") + l1l1ll1
        l1l1l1l = l1ll11l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11lll+ l1ll11l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1l1l)
        l1ll = os.system(l1l1l1l)
        if (l1ll != 0):
            raise IOError(l1ll11l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11lll, l1ll))
    def l111ll1(self, l11ll):
        if os.path.exists(l11ll):
            if os.path.islink(l11ll):
                l11ll = os.readlink(l11ll)
            if os.path.ismount(l11ll):
                return True
        return False
def l11l11(l11lll1):
    l111l1l = l11lll1.replace(l1ll11l1 (u"࠭࡜࡝ࠩࠐ"), l1ll11l1 (u"ࠧࡠࠩࠑ")).replace(l1ll11l1 (u"ࠨ࠱ࠪࠒ"), l1ll11l1 (u"ࠩࡢࠫࠓ"))
    l1ll1ll1 = l1ll11l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11=os.environ[l1ll11l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    ll=os.path.join(l11,l1ll1ll1, l111l1l)
    l1llll=os.path.abspath(ll)
    return l1llll
def l111lll(l1ll111):
    if not os.path.exists(l1ll111):
        os.makedirs(l1ll111)
def l1l(l11lll1, l1lll1, l11111=None, password=None):
    l1ll11l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll111 = l11l11(l11lll1)
    l111lll(l1ll111)
    if not l11111:
        l1l111 = l1llll11()
        l1ll1ll =l1l111.l11llll(l1ll11l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1lll1 + l1ll11l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1lll1 + l1ll11l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll1ll, str):
            l11111, password = l1ll1ll
        else:
            raise l1l1lll()
        logger.info(l1ll11l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll111))
    l11l1 = pwd.getpwuid( os.getuid())[0]
    l1l11ll=os.environ[l1ll11l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lllll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1111l1={l1ll11l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l1, l1ll11l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11lll1, l1ll11l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll111, l1ll11l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l11ll, l1ll11l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11111, l1ll11l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1111l1, temp_file)
        if not os.path.exists(os.path.join(l1lllll, l1ll11l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11ll1l=l1ll11l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1ll11l1 (u"ࠧࠨࠤ")
        else:
            l11ll1l=l1ll11l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll11l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1=l1ll11l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11ll1l,temp_file.name)
        l1lll11l=[l1ll11l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll11l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lllll, l1l1)]
        p = subprocess.Popen(l1lll11l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll11l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll11l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll11l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll111
    logger.debug(l1ll11l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll11l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll11l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll11l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llll=os.path.abspath(l1ll111)
    logger.debug(l1ll11l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llll)
    return l1llll
def l1l1l(l11lll1, l1lll1, l1111ll, l1lll1ll):
    l1ll11l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l1ll(title):
        l1llllll=30
        if len(title)>l1llllll:
            l1l11l=title.split(l1ll11l1 (u"ࠨ࠯ࠣ࠳"))
            l1111=l1ll11l1 (u"ࠧࠨ࠴")
            for block in l1l11l:
                l1111+=block+l1ll11l1 (u"ࠣ࠱ࠥ࠵")
                if len(l1111) > l1llllll:
                    l1111+=l1ll11l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1111
        return title
    l11111 = l1ll11l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1ll11l1 (u"ࠦࠧ࠸")
    os.system(l1ll11l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l11ll11 = l11l11(l11lll1)
    l1ll111 = l11l11(hashlib.sha1(l11lll1.encode()).hexdigest()[:10])
    l111lll(l1ll111)
    logger.info(l1ll11l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1ll111))
    if l1111ll:
        l1llll1l = [l1ll11l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1ll11l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1ll11l1 (u"ࠤ࠰ࡸࠧ࠽"), l1ll11l1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1ll11l1 (u"ࠫ࠲ࡵࠧ࠿"), l1ll11l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l11111, l1111ll),
                    urllib.parse.unquote(l1lll1), os.path.abspath(l1ll111)]
    else:
        l11111, password = l1l1l1(l1ll111, l1lll1, l1lll1ll)
        if l11111.lower() != l1ll11l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1llll1l = [l1ll11l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll11l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll11l1 (u"ࠤ࠰ࡸࠧࡄ"), l1ll11l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll11l1 (u"ࠫ࠲ࡵࠧࡆ"), l1ll11l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l11111,
                        urllib.parse.unquote(l1lll1), os.path.abspath(l1ll111)]
        else:
            raise l1l1lll()
    logger.info(l1ll11l1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1ll11l1 (u"ࠢࠡࠤࡉ").join(l1llll1l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l111l11 = l1ll11l1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l111l11.encode())
    if len(err) > 0:
        l1lllll1 = l1ll11l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1lllll1)
        raise l1lll1l1(l1lllll1, l1l1l=l1ll1l1.l1ll1lll(), l1lll1=l1lll1)
    logger.info(l1ll11l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1ll11l1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1ll111, l11ll11))
    l1llll=os.path.abspath(l11ll11)
    return l1llll
def l1l1l1(l11lll1, l1lll1, l1lll1ll):
    l11l1l = os.path.join(os.environ[l1ll11l1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1ll11l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1ll11l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l11l1l)):
       os.makedirs(os.path.dirname(l11l1l))
    l111111 = l1lll1ll.get_value(l1ll11l1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1ll11l1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l111 = l1llll11(l11lll1, l111111)
    l11111, password = l1l111.l11llll(l1ll11l1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1lll1 + l1ll11l1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1lll1 + l1ll11l1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l11111 != l1ll11l1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1lll1l(l11lll1, l11111):
        l1ll1 = l1ll11l1 (u"ࠢࠡࠤࡗ").join([l11lll1, l11111, l1ll11l1 (u"ࠨࠤࠪࡘ") + password + l1ll11l1 (u"࡙ࠩࠥࠫ"), l1ll11l1 (u"ࠪࡠࡳ࡚࠭")])
        with open(l11l1l, l1ll11l1 (u"ࠫࡼ࠱࡛ࠧ")) as l11111l:
            l11111l.write(l1ll1)
        os.chmod(l11l1l, 0o600)
    return l11111, password
def l1lll1l(l11lll1, l11111):
    l11l1l = l1l11 = os.path.join(os.environ[l1ll11l1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1ll11l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1ll11l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l11l1l):
        with open(l11l1l, l1ll11l1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1lll111 = data[0].split(l1ll11l1 (u"ࠤࠣࠦࡠ"))
            if l11lll1 == l1lll111[0] and l11111 == l1lll111[1]:
                return True
    return False