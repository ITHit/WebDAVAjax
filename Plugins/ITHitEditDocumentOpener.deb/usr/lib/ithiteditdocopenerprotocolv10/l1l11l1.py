#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l1lll = 2048
l11l1l1 = 7
def l11ll11 (l1ll1lll):
    global l1llllll
    l111111 = ord (l1ll1lll [-1])
    l1lll11l = l1ll1lll [:-1]
    l11111l = l111111 % len (l1lll11l)
    l11l111 = l1lll11l [:l11111l] + l1lll11l [l11111l:]
    if l1lll111:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    return eval (l11l11l)
import logging
import os
import re
from l1ll1ll1 import l1lll11ll
logger = logging.getLogger(l11ll11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1ll1l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11ll11 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l1l():
    try:
        out = os.popen(l11ll11 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11ll11 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11ll11 (u"ࠤࠥॸ").join(result)
                logger.info(l11ll11 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11ll11 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11ll11 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11ll11 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll11ll(l11ll11 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11ll11 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1ll1l1(l11ll11 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))