#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll11 = sys.version_info [0] == 2
l1llll1 = 2048
l11ll = 7
def l1l1ll1 (l11l1l):
    global l1111l1
    l1lllll1 = ord (l11l1l [-1])
    l11llll = l11l1l [:-1]
    l1ll1l11 = l1lllll1 % len (l11llll)
    l1ll1lll = l11llll [:l1ll1l11] + l11llll [l1ll1l11:]
    if l1llll11:
        l1l1l = l11 () .join ([unichr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    return eval (l1l1l)
import hashlib
import os
import l11111
from l1ll11l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11111 import l1l11ll
from l1111ll import l1l11l, l1l1l1l
import logging
logger = logging.getLogger(l1l1ll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll11ll():
    def __init__(self, l1111,l1, l1lll11= None, l1ll1ll=None):
        self.l1lll1l=False
        self.l11l11l = self._11l1ll()
        self.l1 = l1
        self.l1lll11 = l1lll11
        self.l1ll1ll1 = l1111
        if l1lll11:
            self.l1lll1ll = True
        else:
            self.l1lll1ll = False
        self.l1ll1ll = l1ll1ll
    def _11l1ll(self):
        try:
            return l11111.l111() is not None
        except:
            return False
    def open(self):
        l1l1ll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l11l:
            raise NotImplementedError(l1l1ll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1ll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11lll = self.l1ll1ll1
        if self.l1.lower().startswith(self.l1ll1ll1.lower()):
            l1l111 = re.compile(re.escape(self.l1ll1ll1), re.IGNORECASE)
            l1 = l1l111.sub(l1l1ll1 (u"ࠨࠩࠄ"), self.l1)
            l1 = l1.replace(l1l1ll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1ll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l(self.l1ll1ll1, l11lll, l1, self.l1lll11)
    def l1l(self,l1ll1ll1, l11lll, l1, l1lll11):
        l1l1ll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1ll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11lll1 = l111l(l1ll1ll1)
        l1l111l = self.l111ll(l11lll1)
        logger.info(l1l1ll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11lll1)
        if l1l111l:
            logger.info(l1l1ll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l11ll(l11lll1)
            l11lll1 = l1lll111(l1ll1ll1, l11lll, l1lll11, self.l1ll1ll)
        logger.debug(l1l1ll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll11l=l11lll1 + l1l1ll1 (u"ࠤ࠲ࠦࠌ") + l1
        l111l1 = l1l1ll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll11l+ l1l1ll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111l1)
        l1lll1 = os.system(l111l1)
        if (l1lll1 != 0):
            raise IOError(l1l1ll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll11l, l1lll1))
    def l111ll(self, l11lll1):
        if os.path.exists(l11lll1):
            if os.path.islink(l11lll1):
                l11lll1 = os.readlink(l11lll1)
            if os.path.ismount(l11lll1):
                return True
        return False
def l111l(l1ll1ll1):
    l111ll1 = l1ll1ll1.replace(l1l1ll1 (u"࠭࡜࡝ࠩࠐ"), l1l1ll1 (u"ࠧࡠࠩࠑ")).replace(l1l1ll1 (u"ࠨ࠱ࠪࠒ"), l1l1ll1 (u"ࠩࡢࠫࠓ"))
    l11ll11 = l1l1ll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll1l1=os.environ[l1l1ll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llll=os.path.join(l1ll1l1,l11ll11, l111ll1)
    l1lll1l1=os.path.abspath(l1llll)
    return l1lll1l1
def l1l1111(l1l11):
    if not os.path.exists(l1l11):
        os.makedirs(l1l11)
def l11l1l1(l1ll1ll1, l11lll, l1ll1=None, password=None):
    l1l1ll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l11 = l111l(l1ll1ll1)
    l1l1111(l1l11)
    if not l1ll1:
        l11l = l11ll1()
        l111l1l =l11l.l1llll1l(l1l1ll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11lll + l1l1ll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11lll + l1l1ll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l111l1l, str):
            l1ll1, password = l111l1l
        else:
            raise l1l1l1l()
        logger.info(l1l1ll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l11))
    l111l11 = pwd.getpwuid( os.getuid())[0]
    l1l1l1=os.environ[l1l1ll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11111l={l1l1ll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111l11, l1l1ll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1ll1, l1l1ll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l11, l1l1ll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1l1, l1l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll1, l1l1ll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11111l, temp_file)
        if not os.path.exists(os.path.join(l1l1ll, l1l1ll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111lll=l1l1ll1 (u"ࠦࡵࡿࠢࠣ")
            key=l1l1ll1 (u"ࠧࠨࠤ")
        else:
            l111lll=l1l1ll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1ll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l1l=l1l1ll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111lll,temp_file.name)
        l1lll=[l1l1ll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1ll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1ll, l1ll1l1l)]
        p = subprocess.Popen(l1lll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1ll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1ll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1ll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l11
    logger.debug(l1l1ll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1ll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1ll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1ll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll1l1=os.path.abspath(l1l11)
    logger.debug(l1l1ll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll1l1)
    return l1lll1l1
def l1lll111(l1ll1ll1, l11lll, l1lll11, l1ll1ll):
    l1l1ll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1(title):
        l111111=30
        if len(title)>l111111:
            l1l1lll=title.split(l1l1ll1 (u"ࠨ࠯ࠣ࠳"))
            l1l1l11=l1l1ll1 (u"ࠧࠨ࠴")
            for block in l1l1lll:
                l1l1l11+=block+l1l1ll1 (u"ࠣ࠱ࠥ࠵")
                if len(l1l1l11) > l111111:
                    l1l1l11+=l1l1ll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l1l11
        return title
    l1ll1 = l1l1ll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1l1ll1 (u"ࠦࠧ࠸")
    os.system(l1l1ll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l11l1 = l111l(l1ll1ll1)
    l1l11 = l111l(hashlib.sha1(l1ll1ll1.encode()).hexdigest()[:10])
    l1l1111(l1l11)
    logger.info(l1l1ll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1l11))
    if l1lll11:
        l1ll11 = [l1l1ll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1l1ll1 (u"ࠤ࠰ࡸࠧ࠽"), l1l1ll1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1l1ll1 (u"ࠫ࠲ࡵࠧ࠿"), l1l1ll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1ll1, l1lll11),
                    urllib.parse.unquote(l11lll), os.path.abspath(l1l11)]
    else:
        l1ll1, password = l1ll1l(l1l11, l11lll, l1ll1ll)
        if l1ll1.lower() != l1l1ll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1ll11 = [l1l1ll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1ll1 (u"ࠤ࠰ࡸࠧࡄ"), l1l1ll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1ll1 (u"ࠫ࠲ࡵࠧࡆ"), l1l1ll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1ll1,
                        urllib.parse.unquote(l11lll), os.path.abspath(l1l11)]
        else:
            raise l1l1l1l()
    logger.info(l1l1ll1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1l1ll1 (u"ࠢࠡࠤࡉ").join(l1ll11)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1ll = l1l1ll1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1ll.encode())
    if len(err) > 0:
        l1111l = l1l1ll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1111l)
        raise l1l11l(l1111l, l1lll111=l11111.l111(), l11lll=l11lll)
    logger.info(l1l1ll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1l1ll1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1l11, l11l1))
    l1lll1l1=os.path.abspath(l11l1)
    return l1lll1l1
def l1ll1l(l1ll1ll1, l11lll, l1ll1ll):
    l1llllll = os.path.join(os.environ[l1l1ll1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1l1ll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1l1ll1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1llllll)):
       os.makedirs(os.path.dirname(l1llllll))
    l1ll111 = l1ll1ll.get_value(l1l1ll1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1l1ll1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l11l = l11ll1(l1ll1ll1, l1ll111)
    l1ll1, password = l11l.l1llll1l(l1l1ll1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11lll + l1l1ll1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11lll + l1l1ll1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1ll1 != l1l1ll1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l11l11(l1ll1ll1, l1ll1):
        l11ll1l = l1l1ll1 (u"ࠢࠡࠤࡗ").join([l1ll1ll1, l1ll1, l1l1ll1 (u"ࠨࠤࠪࡘ") + password + l1l1ll1 (u"࡙ࠩࠥࠫ"), l1l1ll1 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1llllll, l1l1ll1 (u"ࠫࡼ࠱࡛ࠧ")) as ll:
            ll.write(l11ll1l)
        os.chmod(l1llllll, 0o600)
    return l1ll1, password
def l11l11(l1ll1ll1, l1ll1):
    l1llllll = l1lll11l = os.path.join(os.environ[l1l1ll1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1l1ll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1l1ll1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1llllll):
        with open(l1llllll, l1l1ll1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1lllll = data[0].split(l1l1ll1 (u"ࠤࠣࠦࡠ"))
            if l1ll1ll1 == l1lllll[0] and l1ll1 == l1lllll[1]:
                return True
    return False