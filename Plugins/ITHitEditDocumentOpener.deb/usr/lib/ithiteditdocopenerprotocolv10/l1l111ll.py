#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll11 = sys.version_info [0] == 2
l1llll1 = 2048
l11ll = 7
def l1l1ll1 (l11l1l):
    global l1111l1
    l1lllll1 = ord (l11l1l [-1])
    l11llll = l11l1l [:-1]
    l1ll1l11 = l1lllll1 % len (l11llll)
    l1ll1lll = l11llll [:l1ll1l11] + l11llll [l1ll1l11:]
    if l1llll11:
        l1l1l = l11 () .join ([unichr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    return eval (l1l1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11111 import l1l11ll
from configobj import ConfigObj
l1l1ll11 = l1l1ll1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1ll111l = l1l1ll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠶࠴࠱࠴ࠧࡢ")
l11ll1ll = l1l1ll1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1l1ll1 (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠵࠳࠰࠳ࠦࡤ")
l11llll1=os.path.join(os.environ.get(l1l1ll1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1l1ll1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l11ll1ll.replace(l1l1ll1 (u"ࠤࠣࠦࡧ"), l1l1ll1 (u"ࠥࡣࠧࡨ")).lower())
l1l1111l=os.environ.get(l1l1ll1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1l1ll1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l11l1l=l1ll111l.replace(l1l1ll1 (u"ࠨࠠࠣ࡫"), l1l1ll1 (u"ࠢࡠࠤ࡬"))+l1l1ll1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1l1ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l11lll1l=os.path.join(os.environ.get(l1l1ll1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l11l1l)
elif platform.system() == l1l1ll1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11ll11l=l1l11ll(l11llll1+l1l1ll1 (u"ࠧ࠵ࠢࡱ"))
    l11lll1l = os.path.join(l11ll11l, l1l11l1l)
else:
    l11lll1l = os.path.join( l1l11l1l)
l1l1111l=l1l1111l.upper()
if l1l1111l == l1l1ll1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1ll1111=logging.DEBUG
elif l1l1111l == l1l1ll1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1ll1111 = logging.INFO
elif l1l1111l == l1l1ll1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1ll1111 = logging.WARNING
elif l1l1111l == l1l1ll1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1ll1111 = logging.ERROR
elif l1l1111l == l1l1ll1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1ll1111 = logging.CRITICAL
elif l1l1111l == l1l1ll1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1ll1111 = logging.NOTSET
logger = logging.getLogger(l1l1ll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1ll1111)
l11lllll = logging.FileHandler(l11lll1l, mode=l1l1ll1 (u"ࠨࡷࠬࠤࡹ"))
l11lllll.setLevel(l1ll1111)
formatter = logging.Formatter(l1l1ll1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1l1ll1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l11lllll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1ll1111)
l1l1l1ll = SysLogHandler(address=l1l1ll1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l1l1ll.setFormatter(formatter)
logger.addHandler(l11lllll)
logger.addHandler(ch)
logger.addHandler(l1l1l1ll)
class Settings():
    l1l1ll1l = l1l1ll1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11ll1l1 = l1l1ll1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l11ll1 = l1l1ll1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1ll111l):
        self.l1l11lll = self._1l11l11(l1ll111l)
        self._1l1llll()
    def _1l11l11(self, l1ll111l):
        l1l11111 = l1ll111l.split(l1l1ll1 (u"ࠨࠠࠣࢀ"))
        l1l11111 = l1l1ll1 (u"ࠢࠡࠤࢁ").join(l1l11111)
        if platform.system() == l1l1ll1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l11lll = os.path.join(l11llll1, l1l1ll1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l11111 + l1l1ll1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l11lll
    def l1l1lll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l111l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1ll1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1ll1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1llll(self):
        if not os.path.exists(os.path.dirname(self.l1l11lll)):
            os.makedirs(os.path.dirname(self.l1l11lll))
        if not os.path.exists(self.l1l11lll):
            self.config = ConfigObj(self.l1l11lll)
            self.config[l1l1ll1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1l1ll1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1l1ll1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l11ll1
            self.config[l1l1ll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1l1ll1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11ll1l1
            self.config[l1l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1ll1l
            self.config[l1l1ll1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11lll)
            self.l1l11ll1 = self.get_value(l1l1ll1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1l1ll1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11ll1l1 = self.get_value(l1l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1l1ll1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1ll1l = self.get_value(l1l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11lll11(self):
        l1l1l111 = l1l1ll1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1ll1l
        l1l1l111 += l1l1ll1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11ll1l1
        l1l1l111 += l1l1ll1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l11ll1
        return l1l1l111
    def __unicode__(self):
        return self._11lll11()
    def __str__(self):
        return self._11lll11()
    def __del__(self):
        self.config.write()
l1l1l1l1 = Settings(l1ll111l)