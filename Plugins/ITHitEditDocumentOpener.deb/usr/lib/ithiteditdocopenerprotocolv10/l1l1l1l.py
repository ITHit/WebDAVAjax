#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l = sys.version_info [0] == 2
l1llll11 = 2048
l1l11l = 7
def l11l1l1 (l1l111):
    global l1llllll
    l1lll = ord (l1l111 [-1])
    l1lll1l = l1l111 [:-1]
    l1ll1l1 = l1lll % len (l1lll1l)
    l11l11 = l1lll1l [:l1ll1l1] + l1lll1l [l1ll1l1:]
    if l1ll11l:
        l1l = l1111l () .join ([unichr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    return eval (l1l)
import re
class l11l11l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llll11l = kwargs.get(l11l1l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l111 = kwargs.get(l11l1l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll1ll = self.l1lll1lll(args)
        if l1llll1ll:
            args=args+ l1llll1ll
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        l1llll1ll=None
        l11lll1l = args[0][0]
        if re.search(l11l1l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11lll1l):
            l1llll1ll = (l11l1l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1llll11l
                            ,)
        return l1llll1ll
class l11111l1(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1ll = self.l1lll1lll(args)
        if l1llll1ll:
            args = args + l1llll1ll
        self.args = [a for a in args]
    def l1lll1lll(self, *args):
        s = l11l1l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11l1l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll1l1(Exception):
    pass
class l1ll1111(Exception):
    pass
class l1111l11(Exception):
    def __init__(self, message, l111111l, url):
        super(l1111l11,self).__init__(message)
        self.l111111l = l111111l
        self.url = url
class l1lll1l1l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll111(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1lllll11(Exception):
    pass
class l111l111(Exception):
    pass