#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import hashlib
import os
import l1l11l
from l1lll111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l11l import l111l11
from l1llllll import l1l1l11, l1ll11
import logging
logger = logging.getLogger(l1llll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11():
    def __init__(self, l1ll1l,l1111, l1lll1= None, l1l1ll=None):
        self.l1l11l1=False
        self.l1lllll = self._111111()
        self.l1111 = l1111
        self.l1lll1 = l1lll1
        self.l1l1l1 = l1ll1l
        if l1lll1:
            self.l111 = True
        else:
            self.l111 = False
        self.l1l1ll = l1l1ll
    def _111111(self):
        try:
            return l1l11l.l1l1() is not None
        except:
            return False
    def open(self):
        l1llll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lllll:
            raise NotImplementedError(l1llll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1llll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll = self.l1l1l1
        if self.l1111.lower().startswith(self.l1l1l1.lower()):
            l1ll11l = re.compile(re.escape(self.l1l1l1), re.IGNORECASE)
            l1111 = l1ll11l.sub(l1llll1 (u"ࠨࠩࠄ"), self.l1111)
            l1111 = l1111.replace(l1llll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1llll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll11l(self.l1l1l1, l11ll, l1111, self.l1lll1)
    def l1lll11l(self,l1l1l1, l11ll, l1111, l1lll1):
        l1llll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1llll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11llll = l11lll1(l1l1l1)
        l1111ll = self.l11l1(l11llll)
        logger.info(l1llll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11llll)
        if l1111ll:
            logger.info(l1llll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111l11(l11llll)
            l11llll = l1ll11ll(l1l1l1, l11ll, l1lll1, self.l1l1ll)
        logger.debug(l1llll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll1l=l11llll + l1llll1 (u"ࠤ࠲ࠦࠌ") + l1111
        l1lll1ll = l1llll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll1l+ l1llll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1lll1ll)
        l11l1l = os.system(l1lll1ll)
        if (l11l1l != 0):
            raise IOError(l1llll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll1l, l11l1l))
    def l11l1(self, l11llll):
        if os.path.exists(l11llll):
            if os.path.islink(l11llll):
                l11llll = os.readlink(l11llll)
            if os.path.ismount(l11llll):
                return True
        return False
def l11lll1(l1l1l1):
    l1111l1 = l1l1l1.replace(l1llll1 (u"࠭࡜࡝ࠩࠐ"), l1llll1 (u"ࠧࡠࠩࠑ")).replace(l1llll1 (u"ࠨ࠱ࠪࠒ"), l1llll1 (u"ࠩࡢࠫࠓ"))
    l1l111l = l1llll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll1l1=os.environ[l1llll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l111ll1=os.path.join(l1ll1l1,l1l111l, l1111l1)
    l111ll=os.path.abspath(l111ll1)
    return l111ll
def l1111l(l1l111):
    if not os.path.exists(l1l111):
        os.makedirs(l1l111)
def l1lll(l1l1l1, l11ll, l1lll11=None, password=None):
    l1llll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l111 = l11lll1(l1l1l1)
    l1111l(l1l111)
    if not l1lll11:
        l11l111 = l1ll11l1()
        l1llll1l =l11l111.l111lll(l1llll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll + l1llll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll + l1llll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll1l, str):
            l1lll11, password = l1llll1l
        else:
            raise l1ll11()
        logger.info(l1llll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l111))
    l1ll1lll = pwd.getpwuid( os.getuid())[0]
    l1ll1=os.environ[l1llll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l111l={l1llll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1lll, l1llll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1l1, l1llll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l111, l1llll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll1, l1llll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll11, l1llll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l111l, temp_file)
        if not os.path.exists(os.path.join(l1ll1ll, l1llll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11l1l1=l1llll1 (u"ࠦࡵࡿࠢࠣ")
            key=l1llll1 (u"ࠧࠨࠤ")
        else:
            l11l1l1=l1llll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1llll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1l1=l1llll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11l1l1,temp_file.name)
        l1llll11=[l1llll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1llll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1ll, l1lll1l1)]
        p = subprocess.Popen(l1llll11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1llll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1llll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1llll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l111
    logger.debug(l1llll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1llll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1llll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1llll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111ll=os.path.abspath(l1l111)
    logger.debug(l1llll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111ll)
    return l111ll
def l1ll11ll(l1l1l1, l11ll, l1lll1, l1l1ll):
    l1llll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11ll1(title):
        l111l1l=30
        if len(title)>l111l1l:
            l1lllll1=title.split(l1llll1 (u"ࠨ࠯ࠣ࠳"))
            ll=l1llll1 (u"ࠧࠨ࠴")
            for block in l1lllll1:
                ll+=block+l1llll1 (u"ࠣ࠱ࠥ࠵")
                if len(ll) > l111l1l:
                    ll+=l1llll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=ll
        return title
    l1lll11 = l1llll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1llll1 (u"ࠦࠧ࠸")
    os.system(l1llll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1l = l11lll1(l1l1l1)
    l1l111 = l11lll1(hashlib.sha1(l1l1l1.encode()).hexdigest()[:10])
    l1111l(l1l111)
    logger.info(l1llll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1l111))
    if l1lll1:
        l11l11l = [l1llll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1llll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1llll1 (u"ࠤ࠰ࡸࠧ࠽"), l1llll1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1llll1 (u"ࠫ࠲ࡵࠧ࠿"), l1llll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1lll11, l1lll1),
                    urllib.parse.unquote(l11ll), os.path.abspath(l1l111)]
    else:
        l1lll11, password = l1(l1l111, l11ll, l1l1ll)
        if l1lll11.lower() != l1llll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l11l11l = [l1llll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1llll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1llll1 (u"ࠤ࠰ࡸࠧࡄ"), l1llll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1llll1 (u"ࠫ࠲ࡵࠧࡆ"), l1llll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1lll11,
                        urllib.parse.unquote(l11ll), os.path.abspath(l1l111)]
        else:
            raise l1ll11()
    logger.info(l1llll1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1llll1 (u"ࠢࠡࠤࡉ").join(l11l11l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1ll1l11 = l1llll1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1ll1l11.encode())
    if len(err) > 0:
        l11lll = l1llll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l11lll)
        raise l1l1l11(l11lll, l1ll11ll=l1l11l.l1l1(), l11ll=l11ll)
    logger.info(l1llll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1llll1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1l111, l1l))
    l111ll=os.path.abspath(l1l)
    return l111ll
def l1(l1l1l1, l11ll, l1l1ll):
    l11ll1l = os.path.join(os.environ[l1llll1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1llll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1llll1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l11ll1l)):
       os.makedirs(os.path.dirname(l11ll1l))
    l1l1l = l1l1ll.get_value(l1llll1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1llll1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l11l111 = l1ll11l1(l1l1l1, l1l1l)
    l1lll11, password = l11l111.l111lll(l1llll1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11ll + l1llll1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11ll + l1llll1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1lll11 != l1llll1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l11l1ll(l1l1l1, l1lll11):
        l1l1111 = l1llll1 (u"ࠢࠡࠤࡗ").join([l1l1l1, l1lll11, l1llll1 (u"ࠨࠤࠪࡘ") + password + l1llll1 (u"࡙ࠩࠥࠫ"), l1llll1 (u"ࠪࡠࡳ࡚࠭")])
        with open(l11ll1l, l1llll1 (u"ࠫࡼ࠱࡛ࠧ")) as l1ll:
            l1ll.write(l1l1111)
        os.chmod(l11ll1l, 0o600)
    return l1lll11, password
def l11l1ll(l1l1l1, l1lll11):
    l11ll1l = l11ll11 = os.path.join(os.environ[l1llll1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1llll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1llll1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l11ll1l):
        with open(l11ll1l, l1llll1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l11111 = data[0].split(l1llll1 (u"ࠤࠣࠦࡠ"))
            if l1l1l1 == l11111[0] and l1lll11 == l11111[1]:
                return True
    return False