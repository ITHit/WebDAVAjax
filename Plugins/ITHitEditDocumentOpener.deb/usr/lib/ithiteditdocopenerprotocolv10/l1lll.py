#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l11111 = 7
def l11 (l1l111l):
    global l1lll11
    l11l11 = ord (l1l111l [-1])
    l1l1ll1 = l1l111l [:-1]
    l1llll = l11l11 % len (l1l1ll1)
    l1lll1ll = l1l1ll1 [:l1llll] + l1l1ll1 [l1llll:]
    if l11l1l:
        l1l1l1 = l1ll1l1 () .join ([unichr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    return eval (l1l1l1)
import re
class l1l11l1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111l11 = kwargs.get(l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1l11l = kwargs.get(l11 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111111 = self.l1llll1l1(args)
        if l1111111:
            args=args+ l1111111
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        l1111111=None
        l11lll11 = args[0][0]
        if re.search(l11 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l11lll11):
            l1111111 = (l11 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1111l11
                            ,)
        return l1111111
class l1111ll1(Exception):
    def __init__(self, *args, **kwargs):
        l1111111 = self.l1llll1l1(args)
        if l1111111:
            args = args + l1111111
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        s = l11 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l11 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1lllllll(Exception):
    pass
class l1ll11l(Exception):
    pass
class l1llll111(Exception):
    def __init__(self, message, l11111ll, url):
        super(l1llll111,self).__init__(message)
        self.l11111ll = l11111ll
        self.url = url
class l11111l1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1111l1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l111111l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l111l11l(Exception):
    pass