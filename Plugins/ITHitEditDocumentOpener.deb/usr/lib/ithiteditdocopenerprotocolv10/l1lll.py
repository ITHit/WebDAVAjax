#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l1 = sys.version_info [0] == 2
l11 = 2048
l1ll11ll = 7
def l1lll1ll (l1lll111):
    global l1l1ll1
    l1l11 = ord (l1lll111 [-1])
    l1llll11 = l1lll111 [:-1]
    l1l1 = l1l11 % len (l1llll11)
    l1l1111 = l1llll11 [:l1l1] + l1llll11 [l1l1:]
    if l1ll11l1:
        l1111ll = l111l1 () .join ([unichr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    return eval (l1111ll)
import re
class l11ll1l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llll111 = kwargs.get(l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11ll11 = kwargs.get(l1lll1ll (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1lllllll = self.l1lllll11(args)
        if l1lllllll:
            args=args+ l1lllllll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        l1lllllll=None
        l1ll1111 = args[0][0]
        if re.search(l1lll1ll (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1ll1111):
            l1lllllll = (l1lll1ll (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1llll111
                            ,)
        return l1lllllll
class l11111ll(Exception):
    def __init__(self, *args, **kwargs):
        l1lllllll = self.l1lllll11(args)
        if l1lllllll:
            args = args + l1lllllll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        s = l1lll1ll (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1lll1ll (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1lll1l1l(Exception):
    pass
class l111lll(Exception):
    pass
class l1111ll1(Exception):
    def __init__(self, message, l1llllll1, url):
        super(l1111ll1,self).__init__(message)
        self.l1llllll1 = l1llllll1
        self.url = url
class l1lll1lll(Exception):
    pass
class l1111111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111111l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1111l1l(Exception):
    pass
class l111ll11(Exception):
    pass