#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1l1 = 2048
l1ll11 = 7
def l1lll11 (ll):
    global l11l1
    l11l111 = ord (ll [-1])
    l11ll1l = ll [:-1]
    l1l11 = l11l111 % len (l11ll1l)
    l111l1 = l11ll1l [:l1l11] + l11ll1l [l1l11:]
    if l11l1l:
        l1l111l = l1ll11l1 () .join ([unichr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    else:
        l1l111l = str () .join ([chr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    return eval (l1l111l)
import hashlib
import os
import l1llll
from l11l1ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1llll import l1ll1111
from l1lll1 import l11llll, l1ll11ll
import logging
logger = logging.getLogger(l1lll11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111lll():
    def __init__(self, l1ll1l11,l1ll, l1ll1l= None, l1ll1ll1=None):
        self.l1l1l1l=False
        self.l1l11l1 = self._1111ll()
        self.l1ll = l1ll
        self.l1ll1l = l1ll1l
        self.l11l11 = l1ll1l11
        if l1ll1l:
            self.l11ll1 = True
        else:
            self.l11ll1 = False
        self.l1ll1ll1 = l1ll1ll1
    def _1111ll(self):
        try:
            return l1llll.l11l11l() is not None
        except:
            return False
    def open(self):
        l1lll11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l11l1:
            raise NotImplementedError(l1lll11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l11ll = self.l11l11
        if self.l1ll.lower().startswith(self.l11l11.lower()):
            l1111l = re.compile(re.escape(self.l11l11), re.IGNORECASE)
            l1ll = l1111l.sub(l1lll11 (u"ࠨࠩࠄ"), self.l1ll)
            l1ll = l1ll.replace(l1lll11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll1l(self.l11l11, l1l11ll, l1ll, self.l1ll1l)
    def l1lll1l(self,l11l11, l1l11ll, l1ll, l1ll1l):
        l1lll11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111111 = l1llll11(l11l11)
        l1llllll = self.l1lllll(l111111)
        logger.info(l1lll11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111111)
        if l1llllll:
            logger.info(l1lll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1111(l111111)
            l111111 = l1111(l11l11, l1l11ll, l1ll1l, self.l1ll1ll1)
        logger.debug(l1lll11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1111l1=l111111 + l1lll11 (u"ࠤ࠲ࠦࠌ") + l1ll
        l11 = l1lll11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1111l1+ l1lll11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11)
        l1ll1l1l = os.system(l11)
        if (l1ll1l1l != 0):
            raise IOError(l1lll11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1111l1, l1ll1l1l))
    def l1lllll(self, l111111):
        if os.path.exists(l111111):
            if os.path.islink(l111111):
                l111111 = os.readlink(l111111)
            if os.path.ismount(l111111):
                return True
        return False
def l1llll11(l11l11):
    l1lll11l = l11l11.replace(l1lll11 (u"࠭࡜࡝ࠩࠐ"), l1lll11 (u"ࠧࡠࠩࠑ")).replace(l1lll11 (u"ࠨ࠱ࠪࠒ"), l1lll11 (u"ࠩࡢࠫࠓ"))
    l11lll = l1lll11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11ll11=os.environ[l1lll11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11111l=os.path.join(l11ll11,l11lll, l1lll11l)
    l1lll111=os.path.abspath(l11111l)
    return l1lll111
def l11111(l1ll1l1):
    if not os.path.exists(l1ll1l1):
        os.makedirs(l1ll1l1)
def l1llll1(l11l11, l1l11ll, l1l1ll=None, password=None):
    l1lll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll1l1 = l1llll11(l11l11)
    l11111(l1ll1l1)
    if not l1l1ll:
        l1lll1ll = l1l()
        l1llll1l =l1lll1ll.l1l11l(l1lll11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l11ll + l1lll11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l11ll + l1lll11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll1l, str):
            l1l1ll, password = l1llll1l
        else:
            raise l1ll11ll()
        logger.info(l1lll11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll1l1))
    l11ll = pwd.getpwuid( os.getuid())[0]
    l1l111=os.environ[l1lll11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l111l={l1lll11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11ll, l1lll11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11l11, l1lll11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll1l1, l1lll11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l111, l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1ll, l1lll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l111l, temp_file)
        if not os.path.exists(os.path.join(l1lll, l1lll11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1=l1lll11 (u"ࠦࡵࡿࠢࠣ")
            key=l1lll11 (u"ࠧࠨࠤ")
        else:
            l1=l1lll11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111ll1=l1lll11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1,temp_file.name)
        l1lllll1=[l1lll11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll, l111ll1)]
        p = subprocess.Popen(l1lllll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll1l1
    logger.debug(l1lll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll111=os.path.abspath(l1ll1l1)
    logger.debug(l1lll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll111)
    return l1lll111
def l1111(l11l11, l1l11ll, l1ll1l, l1ll1ll1):
    l1lll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll111(title):
        l111ll=30
        if len(title)>l111ll:
            l1l1l=title.split(l1lll11 (u"ࠨ࠯ࠣ࠳"))
            l111l1l=l1lll11 (u"ࠧࠨ࠴")
            for block in l1l1l:
                l111l1l+=block+l1lll11 (u"ࠣ࠱ࠥ࠵")
                if len(l111l1l) > l111ll:
                    l111l1l+=l1lll11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111l1l
        return title
    def l1l1lll(l1ll1lll, password):
        l1lll11 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lll11 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lll11 (u"ࠧࠦࠢ࠹").join(l1ll1lll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11lll1 = l1lll11 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11lll1.encode())
        l11l = [l1lll11 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11l1l1 = l1lll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11l1l1)
            for e in l11l:
                if e in l11l1l1: return False
            raise l11llll(l11l1l1, l1111=l1llll.l11l11l(), l1l11ll=l1l11ll)
        logger.info(l1lll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l1ll = l1lll11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lll11 (u"ࠦࠧ࠿")
    os.system(l1lll11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1ll = l1llll11(l11l11)
    l1ll1l1 = l1llll11(hashlib.sha1(l11l11.encode()).hexdigest()[:10])
    l11111(l1ll1l1)
    logger.info(l1lll11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll1l1))
    if l1ll1l:
        l1ll1lll = [l1lll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll11 (u"ࠤ࠰ࡸࠧࡄ"), l1lll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll11 (u"ࠫ࠲ࡵࠧࡆ"), l1lll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l1ll, l1ll1l),
                    urllib.parse.unquote(l1l11ll), os.path.abspath(l1ll1l1)]
        l1l1lll(l1ll1lll, password)
    else:
        while True:
            l1l1ll, password = l1ll1(l1ll1l1, l1l11ll, l1ll1ll1)
            if l1l1ll.lower() != l1lll11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll1lll = [l1lll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lll11 (u"ࠤ࠰ࡸࠧࡋ"), l1lll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lll11 (u"ࠫ࠲ࡵࠧࡍ"), l1lll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l1ll,
                            urllib.parse.unquote(l1l11ll), os.path.abspath(l1ll1l1)]
            else:
                raise l1ll11ll()
            if l1l1lll(l1ll1lll, password): break
    os.system(l1lll11 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll1l1, l1ll1ll))
    l1lll111=os.path.abspath(l1ll1ll)
    return l1lll111
def l1ll1(l11l11, l1l11ll, l1ll1ll1):
    l1l1ll1 = os.path.join(os.environ[l1lll11 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lll11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lll11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l1ll1)):
       os.makedirs(os.path.dirname(l1l1ll1))
    l111 = l1ll1ll1.get_value(l1lll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lll11 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1lll1ll = l1l(l11l11, l111)
    l1l1ll, password = l1lll1ll.l1l11l(l1lll11 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l11ll + l1lll11 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l11ll + l1lll11 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l1ll != l1lll11 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll11l(l11l11, l1l1ll):
        l1l1l1 = l1lll11 (u"ࠤ࡙ࠣࠦ").join([l11l11, l1l1ll, l1lll11 (u"࡚ࠪࠦࠬ") + password + l1lll11 (u"࡛ࠫࠧ࠭"), l1lll11 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l1ll1, l1lll11 (u"࠭ࡷࠬࠩ࡝")) as l111l11:
            l111l11.write(l1l1l1)
        os.chmod(l1l1ll1, 0o600)
    return l1l1ll, password
def l1ll11l(l11l11, l1l1ll):
    l1l1ll1 = l1l1l11 = os.path.join(os.environ[l1lll11 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lll11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lll11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l1ll1):
        with open(l1l1ll1, l1lll11 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1l1111 = data[0].split(l1lll11 (u"ࠦࠥࠨࡢ"))
            if l11l11 == l1l1111[0] and l1l1ll == l1l1111[1]:
                return True
    return False