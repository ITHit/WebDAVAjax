#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1ll1lll = 2048
l11ll1 = 7
def l1lll111 (l1111l1):
    global l1llll1l
    l1l1lll = ord (l1111l1 [-1])
    l1l1l11 = l1111l1 [:-1]
    l111ll1 = l1l1lll % len (l1l1l11)
    l1ll1 = l1l1l11 [:l111ll1] + l1l1l11 [l111ll1:]
    if l11l11:
        l11l1 = l1l11l1 () .join ([unichr (ord (char) - l1ll1lll - (l1l1111 + l1l1lll) % l11ll1) for l1l1111, char in enumerate (l1ll1)])
    else:
        l11l1 = str () .join ([chr (ord (char) - l1ll1lll - (l1l1111 + l1l1lll) % l11ll1) for l1l1111, char in enumerate (l1ll1)])
    return eval (l11l1)
import logging
import os
import re
from l1ll11l1 import l1llll11l
logger = logging.getLogger(l1lll111 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll111 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll1l1():
    try:
        out = os.popen(l1lll111 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll111 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll111 (u"ࠤࠥॸ").join(result)
                logger.info(l1lll111 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll111 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll111 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll111 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll11l(l1lll111 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll111 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1(l1lll111 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))