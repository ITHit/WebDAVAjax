#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l11l = 2048
l1l1l11 = 7
def l111l11 (l1ll):
    global l11lll
    l1ll1l1l = ord (l1ll [-1])
    l11ll1l = l1ll [:-1]
    l1l1 = l1ll1l1l % len (l11ll1l)
    l11l1ll = l11ll1l [:l1l1] + l11ll1l [l1l1:]
    if l1ll1ll:
        l1l11l1 = l1ll1ll1 () .join ([unichr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    return eval (l1l11l1)
import logging
import os
import re
from l1lll1l import l1lll1lll
logger = logging.getLogger(l111l11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l11lll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111l11 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l1():
    try:
        out = os.popen(l111l11 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l111l11 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l111l11 (u"ࠢࠣॶ").join(result)
                logger.info(l111l11 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l111l11 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l111l11 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l111l11 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1lll1lll(l111l11 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l111l11 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l11lll1(l111l11 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))