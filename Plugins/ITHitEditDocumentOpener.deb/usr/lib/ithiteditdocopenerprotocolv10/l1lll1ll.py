#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l1ll1l1 = 2048
l1lll1l1 = 7
def l1l1ll (l1ll1l1l):
    global l111l1
    l1l11l1 = ord (l1ll1l1l [-1])
    l1lll1l = l1ll1l1l [:-1]
    l1llll1 = l1l11l1 % len (l1lll1l)
    ll = l1lll1l [:l1llll1] + l1lll1l [l1llll1:]
    if l1l1111:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    return eval (l1111)
import hashlib
import os
import l11ll
from l1lll11l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11ll import l1lll1
from l11ll1 import l1111l, l1ll111
import logging
logger = logging.getLogger(l1l1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll11():
    def __init__(self, l111l1l,l1l1l1, l1llllll= None, l1ll=None):
        self.l1ll1=False
        self.l1lll = self._1ll1l()
        self.l1l1l1 = l1l1l1
        self.l1llllll = l1llllll
        self.l111l = l111l1l
        if l1llllll:
            self.l1ll11l = True
        else:
            self.l1ll11l = False
        self.l1ll = l1ll
    def _1ll1l(self):
        try:
            return l11ll.l11111() is not None
        except:
            return False
    def open(self):
        l1l1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lll:
            raise NotImplementedError(l1l1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l11 = self.l111l
        if self.l1l1l1.lower().startswith(self.l111l.lower()):
            l1ll1l11 = re.compile(re.escape(self.l111l), re.IGNORECASE)
            l1l1l1 = l1ll1l11.sub(l1l1ll (u"ࠨࠩࠄ"), self.l1l1l1)
            l1l1l1 = l1l1l1.replace(l1l1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1(self.l111l, l1l11, l1l1l1, self.l1llllll)
    def l1l1(self,l111l, l1l11, l1l1l1, l1llllll):
        l1l1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l11ll = l1l111l(l111l)
        l111lll = self.l1l111(l1l11ll)
        logger.info(l1l1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l11ll)
        if l111lll:
            logger.info(l1l1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll1(l1l11ll)
            l1l11ll = l1lll111(l111l, l1l11, l1llllll, self.l1ll)
        logger.debug(l1l1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111=l1l11ll + l1l1ll (u"ࠤ࠲ࠦࠌ") + l1l1l1
        l1lll11 = l1l1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111+ l1l1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1lll11)
        l1l1ll1 = os.system(l1lll11)
        if (l1l1ll1 != 0):
            raise IOError(l1l1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111, l1l1ll1))
    def l1l111(self, l1l11ll):
        if os.path.exists(l1l11ll):
            if os.path.islink(l1l11ll):
                l1l11ll = os.readlink(l1l11ll)
            if os.path.ismount(l1l11ll):
                return True
        return False
def l1l111l(l111l):
    l11 = l111l.replace(l1l1ll (u"࠭࡜࡝ࠩࠐ"), l1l1ll (u"ࠧࡠࠩࠑ")).replace(l1l1ll (u"ࠨ࠱ࠪࠒ"), l1l1ll (u"ࠩࡢࠫࠓ"))
    l1ll11l1 = l1l1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11l11l=os.environ[l1l1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l11=os.path.join(l11l11l,l1ll11l1, l11)
    l11ll1l=os.path.abspath(l11l11)
    return l11ll1l
def l1l(l11lll):
    if not os.path.exists(l11lll):
        os.makedirs(l11lll)
def l1lllll(l111l, l1l11, l1l1l11=None, password=None):
    l1l1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11lll = l1l111l(l111l)
    l1l(l11lll)
    if not l1l1l11:
        l1l1l1l = l1llll11()
        l11l1 =l1l1l1l.l1ll1ll1(l1l1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l11 + l1l1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l11 + l1l1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l1, str):
            l1l1l11, password = l11l1
        else:
            raise l1ll111()
        logger.info(l1l1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11lll))
    l111111 = pwd.getpwuid( os.getuid())[0]
    l1llll=os.environ[l1l1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l={l1l1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111111, l1l1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111l, l1l1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11lll, l1l1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1llll, l1l1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1l11, l1l1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l, temp_file)
        if not os.path.exists(os.path.join(l1ll1ll, l1l1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1lll=l1l1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1l1ll (u"ࠧࠨࠤ")
        else:
            l1ll1lll=l1l1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11l1l=l1l1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1lll,temp_file.name)
        l1lllll1=[l1l1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1ll, l11l1l)]
        p = subprocess.Popen(l1lllll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11lll
    logger.debug(l1l1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l11ll1l=os.path.abspath(l11lll)
    logger.debug(l1l1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l11ll1l)
    return l11ll1l
def l1lll111(l111l, l1l11, l1llllll, l1ll):
    l1l1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l11l(title):
        l1ll11ll=30
        if len(title)>l1ll11ll:
            l11l1ll=title.split(l1l1ll (u"ࠨ࠯ࠣ࠳"))
            l11l1l1=l1l1ll (u"ࠧࠨ࠴")
            for block in l11l1ll:
                l11l1l1+=block+l1l1ll (u"ࠣ࠱ࠥ࠵")
                if len(l11l1l1) > l1ll11ll:
                    l11l1l1+=l1l1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l1l1
        return title
    l1l1l11 = l1l1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1l1ll (u"ࠦࠧ࠸")
    os.system(l1l1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1111l1 = l1l111l(l111l)
    l11lll = l1l111l(hashlib.sha1(l111l.encode()).hexdigest()[:10])
    l1l(l11lll)
    logger.info(l1l1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11lll))
    if l1llllll:
        l111l11 = [l1l1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1l1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1l1ll (u"ࠤ࠰ࡸࠧ࠽"), l1l1ll (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1l1ll (u"ࠫ࠲ࡵࠧ࠿"), l1l1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1l1l11, l1llllll),
                    urllib.parse.unquote(l1l11), os.path.abspath(l11lll)]
    else:
        l1l1l11, password = l11lll1(l11lll, l1l11, l1ll)
        if l1l1l11.lower() != l1l1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l111l11 = [l1l1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1ll (u"ࠤ࠰ࡸࠧࡄ"), l1l1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1ll (u"ࠫ࠲ࡵࠧࡆ"), l1l1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1l1l11,
                        urllib.parse.unquote(l1l11), os.path.abspath(l11lll)]
        else:
            raise l1ll111()
    logger.info(l1l1ll (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1l1ll (u"ࠢࠡࠤࡉ").join(l111l11)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11llll = l1l1ll (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11llll.encode())
    if len(err) > 0:
        l11l111 = l1l1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l11l111)
        raise l1111l(l11l111, l1lll111=l11ll.l11111(), l1l11=l1l11)
    logger.info(l1l1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1l1ll (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11lll, l1111l1))
    l11ll1l=os.path.abspath(l1111l1)
    return l11ll1l
def l11lll1(l111l, l1l11, l1ll):
    l1l1l = os.path.join(os.environ[l1l1ll (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1l1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1l1ll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1l1l)):
       os.makedirs(os.path.dirname(l1l1l))
    l1llll1l = l1ll.get_value(l1l1ll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1l1ll (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l1l1l = l1llll11(l111l, l1llll1l)
    l1l1l11, password = l1l1l1l.l1ll1ll1(l1l1ll (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1l11 + l1l1ll (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1l11 + l1l1ll (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1l1l11 != l1l1ll (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1(l111l, l1l1l11):
        l11111l = l1l1ll (u"ࠢࠡࠤࡗ").join([l111l, l1l1l11, l1l1ll (u"ࠨࠤࠪࡘ") + password + l1l1ll (u"࡙ࠩࠥࠫ"), l1l1ll (u"ࠪࡠࡳ࡚࠭")])
        with open(l1l1l, l1l1ll (u"ࠫࡼ࠱࡛ࠧ")) as l111ll1:
            l111ll1.write(l11111l)
        os.chmod(l1l1l, 0o600)
    return l1l1l11, password
def l1(l111l, l1l1l11):
    l1l1l = l1111ll = os.path.join(os.environ[l1l1ll (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1l1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1l1ll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1l1l):
        with open(l1l1l, l1l1ll (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l11ll11 = data[0].split(l1l1ll (u"ࠤࠣࠦࡠ"))
            if l111l == l11ll11[0] and l1l1l11 == l11ll11[1]:
                return True
    return False