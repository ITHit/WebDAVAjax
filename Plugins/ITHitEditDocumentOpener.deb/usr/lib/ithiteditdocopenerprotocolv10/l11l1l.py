#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l11111l = 7
def l1ll11l (l1lll1l1):
    global l111111
    l1ll1l1 = ord (l1lll1l1 [-1])
    l1ll111 = l1lll1l1 [:-1]
    l11l1 = l1ll1l1 % len (l1ll111)
    l1l1111 = l1ll111 [:l11l1] + l1ll111 [l11l1:]
    if l11ll1:
        l1ll11 = l1llll1l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    return eval (l1ll11)
import hashlib
import os
import l1l1l11
from l1l11ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1l11 import l1llll1
from l1ll1 import l1l1l, l1lllll
import logging
logger = logging.getLogger(l1ll11l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111lll():
    def __init__(self, l1lll1l,l11llll, l1ll1lll= None, l1111l=None):
        self.l11ll11=False
        self.l1ll1111 = self._111l1l()
        self.l11llll = l11llll
        self.l1ll1lll = l1ll1lll
        self.l1l111l = l1lll1l
        if l1ll1lll:
            self.l1l1l1 = True
        else:
            self.l1l1l1 = False
        self.l1111l = l1111l
    def _111l1l(self):
        try:
            return l1l1l11.l1l1lll() is not None
        except:
            return False
    def open(self):
        l1ll11l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1111:
            raise NotImplementedError(l1ll11l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll11l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1111l1 = self.l1l111l
        if self.l11llll.lower().startswith(self.l1l111l.lower()):
            l1l1ll1 = re.compile(re.escape(self.l1l111l), re.IGNORECASE)
            l11llll = l1l1ll1.sub(l1ll11l (u"ࠨࠩࠄ"), self.l11llll)
            l11llll = l11llll.replace(l1ll11l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll11l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l111(self.l1l111l, l1111l1, l11llll, self.l1ll1lll)
    def l1l111(self,l1l111l, l1111l1, l11llll, l1ll1lll):
        l1ll11l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll11l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11ll1l = l11l11l(l1l111l)
        l11ll = self.l1ll(l11ll1l)
        logger.info(l1ll11l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11ll1l)
        if l11ll:
            logger.info(l1ll11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1llll1(l11ll1l)
            l11ll1l = l1lll11(l1l111l, l1111l1, l1ll1lll, self.l1111l)
        logger.debug(l1ll11l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll1ll=l11ll1l + l1ll11l (u"ࠤ࠲ࠦࠌ") + l11llll
        l1 = l1ll11l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll1ll+ l1ll11l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1)
        l1lll = os.system(l1)
        if (l1lll != 0):
            raise IOError(l1ll11l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll1ll, l1lll))
    def l1ll(self, l11ll1l):
        if os.path.exists(l11ll1l):
            if os.path.islink(l11ll1l):
                l11ll1l = os.readlink(l11ll1l)
            if os.path.ismount(l11ll1l):
                return True
        return False
def l11l11l(l1l111l):
    l1ll1ll1 = l1l111l.replace(l1ll11l (u"࠭࡜࡝ࠩࠐ"), l1ll11l (u"ࠧࡠࠩࠑ")).replace(l1ll11l (u"ࠨ࠱ࠪࠒ"), l1ll11l (u"ࠩࡢࠫࠓ"))
    l11lll1 = l1ll11l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l=os.environ[l1ll11l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1ll=os.path.join(l1l,l11lll1, l1ll1ll1)
    l111l=os.path.abspath(l1ll1ll)
    return l111l
def l1l11(ll):
    if not os.path.exists(ll):
        os.makedirs(ll)
def l11l(l1l111l, l1111l1, l11l111=None, password=None):
    l1ll11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    ll = l11l11l(l1l111l)
    l1l11(ll)
    if not l11l111:
        l11l11 = l1ll111l()
        l11111 =l11l11.l111ll(l1ll11l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1111l1 + l1ll11l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1111l1 + l1ll11l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11111, str):
            l11l111, password = l11111
        else:
            raise l1lllll()
        logger.info(l1ll11l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(ll))
    l1ll11ll = pwd.getpwuid( os.getuid())[0]
    l1l1l1l=os.environ[l1ll11l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l11l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1111={l1ll11l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll11ll, l1ll11l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l111l, l1ll11l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):ll, l1ll11l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1l1l, l1ll11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l111, l1ll11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1111, temp_file)
        if not os.path.exists(os.path.join(l1l11l, l1ll11l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111ll1=l1ll11l (u"ࠦࡵࡿࠢࠣ")
            key=l1ll11l (u"ࠧࠨࠤ")
        else:
            l111ll1=l1ll11l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll11l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111=l1ll11l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111ll1,temp_file.name)
        l1ll1l11=[l1ll11l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll11l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l11l, l111)]
        p = subprocess.Popen(l1ll1l11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll11l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll11l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll11l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %ll
    logger.debug(l1ll11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111l=os.path.abspath(ll)
    logger.debug(l1ll11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111l)
    return l111l
def l1lll11(l1l111l, l1111l1, l1ll1lll, l1111l):
    l1ll11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll111(title):
        l1ll1l1l=30
        if len(title)>l1ll1l1l:
            l1l11l1=title.split(l1ll11l (u"ࠨ࠯ࠣ࠳"))
            l1llll=l1ll11l (u"ࠧࠨ࠴")
            for block in l1l11l1:
                l1llll+=block+l1ll11l (u"ࠣ࠱ࠥ࠵")
                if len(l1llll) > l1ll1l1l:
                    l1llll+=l1ll11l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1llll
        return title
    def l1l1(l1l1ll, password):
        l1ll11l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll11l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll11l (u"ࠧࠦࠢ࠹").join(l1l1ll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l111l11 = l1ll11l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l111l11.encode())
        l11lll = [l1ll11l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11l1ll = l1ll11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11l1ll)
            for e in l11lll:
                if e in l11l1ll: return False
            raise l1l1l(l11l1ll, l1lll11=l1l1l11.l1l1lll(), l1111l1=l1111l1)
        logger.info(l1ll11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11l111 = l1ll11l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll11l (u"ࠦࠧ࠿")
    os.system(l1ll11l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1llllll = l11l11l(l1l111l)
    ll = l11l11l(hashlib.sha1(l1l111l.encode()).hexdigest()[:10])
    l1l11(ll)
    logger.info(l1ll11l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(ll))
    if l1ll1lll:
        l1l1ll = [l1ll11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll11l (u"ࠤ࠰ࡸࠧࡄ"), l1ll11l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll11l (u"ࠫ࠲ࡵࠧࡆ"), l1ll11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11l111, l1ll1lll),
                    urllib.parse.unquote(l1111l1), os.path.abspath(ll)]
        l1l1(l1l1ll, password)
    else:
        while True:
            l11l111, password = l11(ll, l1111l1, l1111l)
            if l11l111.lower() != l1ll11l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1l1ll = [l1ll11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll11l (u"ࠤ࠰ࡸࠧࡋ"), l1ll11l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll11l (u"ࠫ࠲ࡵࠧࡍ"), l1ll11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11l111,
                            urllib.parse.unquote(l1111l1), os.path.abspath(ll)]
            else:
                raise l1lllll()
            if l1l1(l1l1ll, password): break
    os.system(l1ll11l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (ll, l1llllll))
    l111l=os.path.abspath(l1llllll)
    return l111l
def l11(l1l111l, l1111l1, l1111l):
    l11l1l1 = os.path.join(os.environ[l1ll11l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll11l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll11l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l1l1)):
       os.makedirs(os.path.dirname(l11l1l1))
    l1ll1l = l1111l.get_value(l1ll11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll11l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11l11 = l1ll111l(l1l111l, l1ll1l)
    l11l111, password = l11l11.l111ll(l1ll11l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1111l1 + l1ll11l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1111l1 + l1ll11l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11l111 != l1ll11l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1lllll1(l1l111l, l11l111):
        l111l1 = l1ll11l (u"ࠤ࡙ࠣࠦ").join([l1l111l, l11l111, l1ll11l (u"࡚ࠪࠦࠬ") + password + l1ll11l (u"࡛ࠫࠧ࠭"), l1ll11l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l1l1, l1ll11l (u"࠭ࡷࠬࠩ࡝")) as l1lll11l:
            l1lll11l.write(l111l1)
        os.chmod(l11l1l1, 0o600)
    return l11l111, password
def l1lllll1(l1l111l, l11l111):
    l11l1l1 = l1llll11 = os.path.join(os.environ[l1ll11l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll11l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll11l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l1l1):
        with open(l11l1l1, l1ll11l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1111ll = data[0].split(l1ll11l (u"ࠦࠥࠨࡢ"))
            if l1l111l == l1111ll[0] and l11l111 == l1111ll[1]:
                return True
    return False