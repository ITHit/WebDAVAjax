#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l1 = sys.version_info [0] == 2
l1l1l11 = 2048
l1ll1l1l = 7
def l11ll1l (l1l11ll):
    global l1lll1l1
    l1l11 = ord (l1l11ll [-1])
    l1 = l1l11ll [:-1]
    l1ll111 = l1l11 % len (l1)
    ll = l1 [:l1ll111] + l1 [l1ll111:]
    if l11l1l1:
        l1l1l1 = l1lll11l () .join ([unichr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    return eval (l1l1l1)
import re
class l11l111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111l11 = kwargs.get(l11ll1l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l111 = kwargs.get(l11ll1l (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1llll1ll = self.l1llllll1(args)
        if l1llll1ll:
            args=args+ l1llll1ll
        self.args = [a for a in args]
    def l1llllll1(self, *args):
        l1llll1ll=None
        l1l11l1l = args[0][0]
        if re.search(l11ll1l (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11l1l):
            l1llll1ll = (l11ll1l (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1111l11
                            ,)
        return l1llll1ll
class l1lll1lll(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1ll = self.l1llllll1(args)
        if l1llll1ll:
            args = args + l1llll1ll
        self.args = [a for a in args]
    def l1llllll1(self, *args):
        s = l11ll1l (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11ll1l (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll111(Exception):
    pass
class l1ll1(Exception):
    pass
class l1lll11ll(Exception):
    def __init__(self, message, l1lllll1l, url):
        super(l1lll11ll,self).__init__(message)
        self.l1lllll1l = l1lllll1l
        self.url = url
class l1lll1l11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111111l(Exception):
    pass
class l1111111(Exception):
    pass
class l1111l1l(Exception):
    pass