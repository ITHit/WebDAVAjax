#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l11 = 7
def l1l111l (l11ll1):
    global l1l1l
    l11lll1 = ord (l11ll1 [-1])
    l111 = l11ll1 [:-1]
    l1l = l11lll1 % len (l111)
    l11lll = l111 [:l1l] + l111 [l1l:]
    if l1ll111:
        l1l11l1 = l11l11l () .join ([unichr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    return eval (l1l11l1)
import re
class l1lll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1lll = kwargs.get(l1l111l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1l1l11 = kwargs.get(l1l111l (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111l11 = self.l111111l(args)
        if l1111l11:
            args=args+ l1111l11
        self.args = [a for a in args]
    def l111111l(self, *args):
        l1111l11=None
        l1l111ll = args[0][0]
        if re.search(l1l111l (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l111ll):
            l1111l11 = (l1l111l (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1lll1lll
                            ,)
        return l1111l11
class l1111111(Exception):
    def __init__(self, *args, **kwargs):
        l1111l11 = self.l111111l(args)
        if l1111l11:
            args = args + l1111l11
        self.args = [a for a in args]
    def l111111l(self, *args):
        s = l1l111l (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1l111l (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1lll1ll1(Exception):
    pass
class l11l1l1(Exception):
    pass
class l1llllll1(Exception):
    def __init__(self, message, l1llll111, url):
        super(l1llllll1,self).__init__(message)
        self.l1llll111 = l1llll111
        self.url = url
class l1llll11l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1111l1l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1111ll1(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllllll(Exception):
    pass
class l11l11ll(Exception):
    pass