#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import sys, json
import os
import urllib
import l1l11l
from l1lll111 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l11111 import l1l11ll1, logger, l1l1llll
from cookies import l11l1l11 as l11l1llll
from l1ll111 import l11
l11l111l1 = None
from l1llllll import *
class l1l11l11l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1llll1 (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1111lll1):
        self.config = l1111lll1
        self.l1l111ll1 = l1l11l.l1l1()
    def l1111ll11(self):
        data = platform.uname()
        logger.info(l1llll1 (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1llll1 (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1llll1 (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1llll1 (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1l111lll():
    def __init__(self, encode = True):
        self._encode = encode
        self._111lllll = [l1llll1 (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l1lll11ll = None
        self.l111l1l1l = None
        self.l1l111111 = None
        self.l11l11ll1 = None
        self.l1llll11 = None
        self.l1l1l1l11 = None
        self.l1111111l = None
        self.l11l1l111 = None
        self.cookies = None
    def l1ll1llll(self, url):
        l1llll1 (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1llll1 (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._11l1lll1(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11111l11(url)
        self.dict = self._1l1l1l1l(params)
        logger.info(l1llll1 (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l1ll11111(self.dict):
            raise l1lllll11(l1llll1 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._111lllll)
        self._11llllll(self.dict)
        if self._encode:
            self.l1l1l11ll()
        self._11lll1ll()
        self._11111l1l()
        self._1ll11l1l()
        self._1l1ll111()
        self.l1ll1111l()
        logger.info(l1llll1 (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1llll1 (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l1lll11ll))
        logger.info(l1llll1 (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l111l1l1l))
        logger.info(l1llll1 (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l1l111111))
        logger.info(l1llll1 (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l11l11ll1))
        logger.info(l1llll1 (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l1llll11))
        logger.info(l1llll1 (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l1l1l1l11))
        logger.info(l1llll1 (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l1111111l))
        logger.info(l1llll1 (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l11l1l111))
    def _11llllll(self, l1ll1l111):
        self.l1lll11ll = l1ll1l111.get(l1llll1 (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l111l1l1l = l1ll1l111.get(l1llll1 (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1llll1 (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l1l111111 = l1ll1l111.get(l1llll1 (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l11l11ll1 = l1ll1l111.get(l1llll1 (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l1llll11 = l1ll1l111.get(l1llll1 (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l1l1l1l11 = l1ll1l111.get(l1llll1 (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l1111111l = l1ll1l111.get(l1llll1 (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1llll1 (u"ࠨࠢ࣍"))
        self.l11l1l111 = l1ll1l111.get(l1llll1 (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1llll1 (u"ࠣࠤ࣏"))
        self.cookies = l1ll1l111.get(l1llll1 (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l1ll1111l(self):
        l11l11l1l = False
        if self.l1llll11:
            if self.l1llll11.upper() == l1llll1 (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l1llll11 = l1llll1 (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l1llll11.upper() == l1llll1 (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l1llll11 = l1llll1 (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l1llll11.upper() == l1llll1 (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l1llll11 = l1llll1 (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l1llll11.upper() == l1llll1 (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l1llll11 = l1llll1 (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l1llll11 == l1llll1 (u"ࠦࠧࣙ"):
                l11l11l1l = True
            else:
                self.l1llll11 = self.l1llll11.lower()
        else:
            l11l11l1l = True
        if l11l11l1l:
            self.l1llll11 = l1llll1 (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l1l1l11ll(self):
        l1llll1 (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1llll1 (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l111lll11 = []
                    for el in self.__dict__.get(key):
                        l111lll11.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l111lll11
    def l11llll1l(self, l1ll1l11l):
        res = l1ll1l11l
        if self._encode:
            res = urllib.parse.quote(l1ll1l11l, safe=l1llll1 (u"ࠣࠤࣝ"))
        return res
    def _11l1lll1(self, url):
        l1llll1 (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1llll1 (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1llll1 (u"ࠦ࠿ࠨ࣠")), l1llll1 (u"ࠬ࠭࣡"), url)
        return url
    def _11111l11(self, url):
        l1llll1 (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l1l11lll1 = url.split(l1llll1 (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1llll1 (u"ࠣ࠽ࠥࣤ")))
        result = l1l11lll1
        if len(result) == 0:
            raise l1lllll1l(l1llll1 (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _1l1l1l1l(self, params):
        l1llll1 (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1llll1 (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1llll1 (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1111l1l1 = data.group(l1llll1 (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l1111l1l1 in (l1llll1 (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1llll1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1llll1 (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1llll1 (u"ࠥ࠰࣭ࠧ"))
                elif l1111l1l1 == l1llll1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1llll1 (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1llll1 (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l1111l1l1] = value
        return result
    def _1ll1lll1(self, url, scheme):
        l1llll1 (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l1111l1ll = {l1llll1 (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1llll1 (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l11ll1lll = url.split(l1llll1 (u"ࠥ࠾ࠧࣴ"))
        if len(l11ll1lll) == 1:
            for l1l1llll1 in list(l1111l1ll.keys()):
                if l1l1llll1 == scheme:
                    url += l1llll1 (u"ࠦ࠿ࠨࣵ") + str(l1111l1ll[l1l1llll1])
                    break
        return url
    def _11lll1ll(self):
        l1llll1 (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l11l11ll1:
            l1ll111ll = self.l11l11ll1[0]
            l1l1l1lll = urlparse(l1ll111ll)
        if self.l1lll11ll:
            l1ll11lll = urlparse(self.l1lll11ll)
            if l1ll11lll.scheme:
                l111111l1 = l1ll11lll.scheme
            else:
                if l1l1l1lll.scheme:
                    l111111l1 = l1l1l1lll.scheme
                else:
                    raise l11111l1(
                        l1llll1 (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l1ll11lll.netloc:
                l111l1111 = l1ll11lll.netloc
            else:
                if l1l1l1lll.netloc:
                    l111l1111 = l1l1l1lll.netloc
                else:
                    raise l11111l1(
                        l1llll1 (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l111l1111 = self._1ll1lll1(l111l1111, l111111l1)
            path = l1ll11lll.path
            if not path.endswith(l1llll1 (u"ࠨ࠱ࣹࠪ")):
                path += l1llll1 (u"ࠩ࠲ࣺࠫ")
            l1lll1l11 = ParseResult(scheme=l111111l1, netloc=l111l1111, path=path,
                                         params=l1ll11lll.params, query=l1ll11lll.query,
                                         fragment=l1ll11lll.fragment)
            self.l1lll11ll = l1lll1l11.geturl()
        else:
            if not l1l1l1lll.netloc:
                raise l11111l1(l1llll1 (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l11l11lll = l1l1l1lll.path
            l1l1ll11l = l1llll1 (u"ࠦ࠴ࠨࣼ").join(l11l11lll.split(l1llll1 (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1llll1 (u"ࠨ࠯ࠣࣾ")
            l1lll1l11 = ParseResult(scheme=l1l1l1lll.scheme,
                                         netloc=self._1ll1lll1(l1l1l1lll.netloc, l1l1l1lll.scheme),
                                         path=l1l1ll11l,
                                         params=l1llll1 (u"ࠢࠣࣿ"),
                                         query=l1llll1 (u"ࠣࠤऀ"),
                                         fragment=l1llll1 (u"ࠤࠥँ")
                                         )
            self.l1lll11ll = l1lll1l11.geturl()
    def _1ll11l1l(self):
        l1llll1 (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l11l11ll1:
            l1ll111ll = self.l11l11ll1[0]
            l1l1l1lll = urlparse(l1ll111ll)
        if self.l1l1l1l11:
            l1l1l1ll1 = urlparse(self.l1l1l1l11)
            if l1l1l1ll1.scheme:
                l111l1l11 = l1l1l1ll1.scheme
            else:
                l111l1l11 = l1l1l1lll.scheme
            if l1l1l1ll1.netloc:
                l11ll1111 = l1l1l1ll1.netloc
            else:
                l11ll1111 = l1l1l1lll.netloc
            l11111ll1 = ParseResult(scheme=l111l1l11, netloc=l11ll1111, path=l1l1l1ll1.path,
                                      params=l1l1l1ll1.params, query=l1l1l1ll1.query,
                                      fragment=l1l1l1ll1.fragment)
            self.l1l1l1l11 = l11111ll1.geturl()
    def _11111l1l(self):
        l1llll1 (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l11l11ll1
        self.l11l11ll1 = []
        for item in items:
            l111ll1ll = urlparse(item.strip(), scheme=l1llll1 (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l111ll1ll.path[-1] == l1llll1 (u"ࠨ࠯ࠣअ"):
                l1l111l11 = l111ll1ll.path
            else:
                path_list = l111ll1ll.path.split(l1llll1 (u"ࠢ࠰ࠤआ"))
                l1l111l11 = l1llll1 (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1llll1 (u"ࠤ࠲ࠦई")
            l11ll1l11 = urlparse(self.l1lll11ll, scheme=l1llll1 (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l111ll1ll.scheme:
                scheme = l111ll1ll.scheme
            elif l11ll1l11.scheme:
                scheme = l11ll1l11.scheme
            else:
                scheme = l1llll1 (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l111ll1ll.netloc and not l11ll1l11.netloc:
                l11ll11l1 = l111ll1ll.netloc
            elif not l111ll1ll.netloc and l11ll1l11.netloc:
                l11ll11l1 = l11ll1l11.netloc
            elif not l111ll1ll.netloc and not l11ll1l11.netloc and len(self.l11l11ll1) > 0:
                l1l11ll11 = urlparse(self.l11l11ll1[len(self.l11l11ll1) - 1])
                l11ll11l1 = l1l11ll11.netloc
            elif l11ll1l11.netloc:
                l11ll11l1 = l111ll1ll.netloc
            elif not l11ll1l11.netloc:
                l11ll11l1 = l111ll1ll.netloc
            if l111ll1ll.path:
                l1ll1ll11 = l111ll1ll.path
            if l11ll11l1:
                l11ll11l1 = self._1ll1lll1(l11ll11l1, scheme)
                l111lll1l = ParseResult(scheme=scheme, netloc=l11ll11l1, path=l1ll1ll11,
                                          params=l111ll1ll.params,
                                          query=l111ll1ll.query,
                                          fragment=l111ll1ll.fragment)
                self.l11l11ll1.append(l111lll1l.geturl())
    def _1l1ll111(self):
        l1llll1 (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l11l1l11l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l11l1(l1llll1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l11l1l11l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l11l1(l1llll1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l1l111111:
            l1111llll = []
            for l11ll1ll1 in self.l1l111111:
                if l11ll1ll1 not in [x[l1llll1 (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l1111llll.append(l11ll1ll1)
            if l1111llll:
                l11ll1ll = l1llll1 (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1llll1 (u"ࠥ࠰ࠥࠨऐ").join(l1111llll))
                raise l11l11l1(l1llll1 (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l11ll1ll)
    def l1ll11111(self, params):
        l1llll1 (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1ll11ll1 = True
        for param in self._111lllll:
            if not params.get(param.lower()):
                l1ll11ll1 = False
        return l1ll11ll1
class l1l1l1111():
    def __init__(self, l111l111l):
        self.l11l1ll1l = l1l11l.l1l1()
        self.l11lll11l = self.l111ll11l()
        self.l111ll111 = self.l11lllll1()
        self.l111l111l = l111l111l
        self._111llll1 = [l1llll1 (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1llll1 (u"ࠢࡏࡱࡱࡩࠧऔ"), l1llll1 (u"ࠣࡃ࡯ࡰࠧक"), l1llll1 (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1llll1 (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1llll1 (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1llll1 (u"ࠧࡏࡅࠣङ"), l1llll1 (u"ࠨࡅࡥࡩࡨࠦच")]
        self._1111ll1l = [l1llll1 (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1llll1 (u"ࠣࡇࡧ࡭ࡹࠨज"), l1llll1 (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1llll1 (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l11111lll = None
    def l111ll11l(self):
        l111l1ll1 = l1llll1 (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l111l1ll1
    def l11lllll1(self):
        l1ll11l11 = 0
        return l1ll11l11
    def l11lll1l1(self):
        l11ll1ll = l1llll1 (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l111ll111)
        l11ll1ll += l1llll1 (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l1ll1l1ll(l1l11ll1, l11ll1ll, t=1)
        return res
    def run(self):
        l11l1l1l1 = True
        self._1l11ll1l()
        result = []
        try:
            for cookie in l11l1llll(l111ll11=self.l111l111l.cookies).run():
                result.append(cookie)
        except l1111ll1 as e:
            logger.exception(l1llll1 (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l1l11l1ll = self._1111l111(result)
            if l1l11l1ll:
                logger.info(l1llll1 (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l1l11l1ll)
                self.l11111lll = l1l11l1ll
            else:
                logger.info(l1llll1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l1l11l1ll)
            l11l1l1l1 = True
        else:
            l11l1l1l1 = False
        return l11l1l1l1
    def _1111l111(self, l11lll111):
        res = False
        l1lll1 = os.path.join(os.environ[l1llll1 (u"ࠪࡌࡔࡓࡅࠨथ")], l1llll1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1llll1 (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1lll1111 = {}
        for cookies in l11lll111:
            l1lll1111[cookies.name] = cookies.value
        l1l11l111 = l1llll1 (u"ࠨࠢन")
        for key in list(l1lll1111.keys()):
            l1l11l111 += l1llll1 (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1lll1111[key].strip())
        if not os.path.exists(os.path.dirname(l1lll1)):
            os.makedirs(os.path.dirname(l1lll1))
        vers = int(l1llll1 (u"ࠣࠤप").join(self.l11l1ll1l.split(l1llll1 (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l11l11111 = [l1llll1 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1llll1 (u"ࠦࠨࠦࠢभ") + l1llll1 (u"ࠧ࠳ࠢम") * 60,
                              l1llll1 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1llll1 (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1llll1 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l1l11l111),
                              l1llll1 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l11l11111 = [l1llll1 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1llll1 (u"ࠦࠨࠦࠢऴ") + l1llll1 (u"ࠧ࠳ࠢव") * 60,
                              l1llll1 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1llll1 (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1llll1 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l1l11l111),
                              l1llll1 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1lll1, l1llll1 (u"ࠥࡻࠧऺ")) as l11ll1l1l:
            data = l1llll1 (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l11l11111)
            l11ll1l1l.write(data)
            l11ll1l1l.write(l1llll1 (u"ࠧࡢ࡮़ࠣ"))
        res = l1lll1
        return res
    def _1l11ll1l(self):
        self._11l11l11(l1llll1 (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._111111ll()
    def _11l11l11(self, l1l1lll1l):
        l11ll111l = self.l111l111l.dict[l1l1lll1l.lower()]
        if l11ll111l:
            if isinstance(l11ll111l, list):
                l1ll1ll1l = l11ll111l
            else:
                l1ll1ll1l = [l11ll111l]
            if l1llll1 (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l1l1lll1l.lower():
                    for l1l1111l1 in l1ll1ll1l:
                        l1l1lll11 = [l1ll1l1l1.upper() for l1ll1l1l1 in self._111llll1]
                        if not l1l1111l1.upper() in l1l1lll11:
                            l1l111l1l = l1llll1 (u"ࠣ࠮ࠣࠦि").join(self._111llll1)
                            l11l111ll = l1llll1 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l1l1lll1l, l11ll111l, l1l111l1l, )
                            raise l1lllllll(l11l111ll)
    def _111111ll(self):
        l1l11l1l1 = []
        l1l1111ll = self.l111l111l.l1l111111
        for l1l1l111l in self._111llll1:
            if not l1l1l111l in [l1llll1 (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1llll1 (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l1l11l1l1.append(l1l1l111l)
        for l1l1lllll in self.l111l111l.l111l1l1l:
            if l1l1lllll in l1l11l1l1 and not l1l1111ll:
                l11l111ll = l1llll1 (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1lllllll(l11l111ll)
def l1111l11l(title, message, l11ll11ll, l11llll11=None):
    l1l1ll1ll = l1l11111l()
    l1l1ll1ll.l11l1l1ll(message, title, l11ll11ll, l11llll11)
def l1l1l11l1(title, message, l11ll11ll):
    l111l1lll = l11l1111l()
    l111l1lll.l1l1ll1l1(title, message, l11ll11ll)
    res = l111l1lll.result
    return res
def main():
    try:
        logger.info(l1llll1 (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l1l1llll)
        system.l1111ll11()
        logger.info(l1llll1 (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1lllll11(
                l1llll1 (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l11l1ll11 = l1l111lll()
        l11l1ll11.l1ll1llll(l1llll1 (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l1lll111l = [item.upper() for item in l11l1ll11.l111l1l1l]
        l1l11llll = l1llll1 (u"ࠥࡒࡔࡔࡅࠣै") in l1lll111l
        if l1l11llll:
            logger.info(l1llll1 (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l1lll11l1 = l11l1ll11.l11l11ll1
            for l1111 in l1lll11l1:
                logger.debug(l1llll1 (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l1111))
                opener = l11(l11l1ll11.l1lll11ll, l1111, l1lll1=None, l1l1ll=l1l1llll)
                opener.open()
                logger.info(l1llll1 (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l1ll111l1 = l1l1l1111(l11l1ll11)
            l111ll1l1 = l1ll111l1.run()
            l1lll11l1 = l11l1ll11.l11l11ll1
            for l1111 in l1lll11l1:
                logger.info(l1llll1 (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l1111))
                opener = l11(l11l1ll11.l1lll11ll, l1111, l1lll1=l1ll111l1.l11111lll,
                                l1l1ll=l1l1llll)
                opener.open()
                logger.info(l1llll1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1l1l11 as e:
        title = l1llll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1l11ll1
        logger.exception(l1llll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l111l11ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111l11ll = el
        l111l11l1 = l1llll1 (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l11ll, message.strip())
        l1111l11l(title, l111l11l1, l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1llll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l11llll11=l111l11ll)
        sys.exit(2)
    except l1llll1ll as e:
        title = l1llll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1l11ll1
        logger.exception(l1llll1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l111l11ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111l11ll = el
        l111l11l1 = l1llll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l1111l11l(title, l111l11l1, l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1llll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l11llll11=l111l11ll)
        sys.exit(2)
    except l1lllll11 as e:
        title = l1llll1 (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1l11ll1
        logger.exception(l1llll1 (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l1111l11l(title, str(e), l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1llll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1llll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1l11ll1
        logger.exception(l1llll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l1111l11l(title, l1llll1 (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1llll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1lllllll as e:
        title = l1llll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1l11ll1
        logger.exception(l1llll1 (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l1111l11l(title, l1llll1 (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1llll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1llll111 as e:
        title = l1llll1 (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1l11ll1
        logger.exception(l1llll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l1111l11l(title, l1llll1 (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1llll1 (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1ll11:
        logger.info(l1llll1 (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1llll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1l11ll1
        logger.exception(l1llll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l1111l11l(title, l1llll1 (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l11ll11ll=l1l1llll.get_value(l1llll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1llll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1llll1 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()