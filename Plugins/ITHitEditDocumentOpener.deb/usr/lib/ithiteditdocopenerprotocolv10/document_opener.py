#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1l11 = 7
def l1ll1lll (l1):
    global l1l1lll
    l1lll1l1 = ord (l1 [-1])
    l1l11l1 = l1 [:-1]
    l111l = l1lll1l1 % len (l1l11l1)
    l1ll1l1 = l1l11l1 [:l111l] + l1l11l1 [l111l:]
    if l1l1:
        l11lll = l11llll () .join ([unichr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    return eval (l11lll)
import sys, json
import os
import urllib
import l11ll11
from l1llll import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1111l import l1l1ll11, logger, l11ll111
from cookies import l11l111l as l1l11111l
from l1ll11ll import l11111
l11ll1111 = None
from l11l11l import *
class l1ll1111l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1lll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1lll11l1):
        self.config = l1lll11l1
        self.l1l11ll1l = l11ll11.l111ll1()
    def l111l11ll(self):
        data = platform.uname()
        logger.info(l1ll1lll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1ll1lll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1ll1lll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1ll1lll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l11111111():
    def __init__(self, encode = True):
        self._encode = encode
        self._11l1lll1 = [l1ll1lll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l11l1ll1l = None
        self.l111ll1l1 = None
        self.l1l111lll = None
        self.l11lll11l = None
        self.l1lll111 = None
        self.l11l11lll = None
        self.l1ll1l1l1 = None
        self.l1l111ll1 = None
        self.cookies = None
    def l11111ll1(self, url):
        l1ll1lll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1ll1lll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l111l11(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l1ll11l(url)
        self.dict = self._1l111l1l(params)
        logger.info(l1ll1lll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l11ll1lll(self.dict):
            raise l1llllll1(l1ll1lll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._11l1lll1)
        self._1l1llll1(self.dict)
        if self._encode:
            self.l1111l1l1()
        self._11111l11()
        self._1111l11l()
        self._11l11ll1()
        self._111l111l()
        self.l1l1ll1l1()
        logger.info(l1ll1lll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1ll1lll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l11l1ll1l))
        logger.info(l1ll1lll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l111ll1l1))
        logger.info(l1ll1lll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1l111lll))
        logger.info(l1ll1lll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l11lll11l))
        logger.info(l1ll1lll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1lll111))
        logger.info(l1ll1lll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11l11lll))
        logger.info(l1ll1lll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1ll1l1l1))
        logger.info(l1ll1lll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1l111ll1))
    def _1l1llll1(self, l11111lll):
        self.l11l1ll1l = l11111lll.get(l1ll1lll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l111ll1l1 = l11111lll.get(l1ll1lll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1ll1lll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1l111lll = l11111lll.get(l1ll1lll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l11lll11l = l11111lll.get(l1ll1lll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1lll111 = l11111lll.get(l1ll1lll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11l11lll = l11111lll.get(l1ll1lll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1ll1l1l1 = l11111lll.get(l1ll1lll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1ll1lll (u"ࠣࠤ࣏"))
        self.l1l111ll1 = l11111lll.get(l1ll1lll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1ll1lll (u"࣑ࠥࠦ"))
        self.cookies = l11111lll.get(l1ll1lll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l1ll1l1(self):
        l111llll1 = False
        if self.l1lll111:
            if self.l1lll111.upper() == l1ll1lll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1lll111 = l1ll1lll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1lll111.upper() == l1ll1lll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1lll111 = l1ll1lll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1lll111.upper() == l1ll1lll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1lll111 = l1ll1lll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1lll111.upper() == l1ll1lll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1lll111 = l1ll1lll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1lll111 == l1ll1lll (u"ࠨࠢࣛ"):
                l111llll1 = True
            else:
                self.l1lll111 = self.l1lll111.lower()
        else:
            l111llll1 = True
        if l111llll1:
            self.l1lll111 = l1ll1lll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1111l1l1(self):
        l1ll1lll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1lll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1ll111ll = []
                    for el in self.__dict__.get(key):
                        l1ll111ll.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1ll111ll
    def l11l1l1l1(self, l11l11111):
        res = l11l11111
        if self._encode:
            res = urllib.parse.quote(l11l11111, safe=l1ll1lll (u"ࠥࠦࣟ"))
        return res
    def _1l111l11(self, url):
        l1ll1lll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1ll1lll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1ll1lll (u"ࠨ࠺ࠣ࣢")), l1ll1lll (u"ࠧࠨࣣ"), url)
        return url
    def _1l1ll11l(self, url):
        l1ll1lll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l111lll11 = url.split(l1ll1lll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1ll1lll (u"ࠥ࠿ࣦࠧ")))
        result = l111lll11
        if len(result) == 0:
            raise l1llll11l(l1ll1lll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1l111l1l(self, params):
        l1ll1lll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1ll1lll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1ll1lll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l11l111 = data.group(l1ll1lll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l11l111 in (l1ll1lll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1ll1lll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1ll1lll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1ll1lll (u"ࠧ࠲࣯ࠢ"))
                elif l1l11l111 == l1ll1lll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1ll1lll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1lll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l11l111] = value
        return result
    def _1l1lll1l(self, url, scheme):
        l1ll1lll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l11l1ll = {l1ll1lll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1ll1lll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11lll1ll = url.split(l1ll1lll (u"ࠧࡀࣶࠢ"))
        if len(l11lll1ll) == 1:
            for l1l1l1lll in list(l1l11l1ll.keys()):
                if l1l1l1lll == scheme:
                    url += l1ll1lll (u"ࠨ࠺ࠣࣷ") + str(l1l11l1ll[l1l1l1lll])
                    break
        return url
    def _11111l11(self):
        l1ll1lll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l11lll11l:
            l11l1l11l = self.l11lll11l[0]
            l11lll111 = urlparse(l11l1l11l)
        if self.l11l1ll1l:
            l1ll1ll1l = urlparse(self.l11l1ll1l)
            if l1ll1ll1l.scheme:
                l1lll1111 = l1ll1ll1l.scheme
            else:
                if l11lll111.scheme:
                    l1lll1111 = l11lll111.scheme
                else:
                    raise l1llll111(
                        l1ll1lll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1ll1ll1l.netloc:
                l11111l1l = l1ll1ll1l.netloc
            else:
                if l11lll111.netloc:
                    l11111l1l = l11lll111.netloc
                else:
                    raise l1llll111(
                        l1ll1lll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l11111l1l = self._1l1lll1l(l11111l1l, l1lll1111)
            path = l1ll1ll1l.path
            if not path.endswith(l1ll1lll (u"ࠪ࠳ࠬࣻ")):
                path += l1ll1lll (u"ࠫ࠴࠭ࣼ")
            l11l1llll = ParseResult(scheme=l1lll1111, netloc=l11111l1l, path=path,
                                         params=l1ll1ll1l.params, query=l1ll1ll1l.query,
                                         fragment=l1ll1ll1l.fragment)
            self.l11l1ll1l = l11l1llll.geturl()
        else:
            if not l11lll111.netloc:
                raise l1llll111(l1ll1lll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l1l1l1l = l11lll111.path
            l11lllll1 = l1ll1lll (u"ࠨ࠯ࠣࣾ").join(l1l1l1l1l.split(l1ll1lll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1ll1lll (u"ࠣ࠱ࠥऀ")
            l11l1llll = ParseResult(scheme=l11lll111.scheme,
                                         netloc=self._1l1lll1l(l11lll111.netloc, l11lll111.scheme),
                                         path=l11lllll1,
                                         params=l1ll1lll (u"ࠤࠥँ"),
                                         query=l1ll1lll (u"ࠥࠦं"),
                                         fragment=l1ll1lll (u"ࠦࠧः")
                                         )
            self.l11l1ll1l = l11l1llll.geturl()
    def _11l11ll1(self):
        l1ll1lll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l11lll11l:
            l11l1l11l = self.l11lll11l[0]
            l11lll111 = urlparse(l11l1l11l)
        if self.l11l11lll:
            l1111ll11 = urlparse(self.l11l11lll)
            if l1111ll11.scheme:
                l1111ll1l = l1111ll11.scheme
            else:
                l1111ll1l = l11lll111.scheme
            if l1111ll11.netloc:
                l1l11lll1 = l1111ll11.netloc
            else:
                l1l11lll1 = l11lll111.netloc
            l11l11l11 = ParseResult(scheme=l1111ll1l, netloc=l1l11lll1, path=l1111ll11.path,
                                      params=l1111ll11.params, query=l1111ll11.query,
                                      fragment=l1111ll11.fragment)
            self.l11l11lll = l11l11l11.geturl()
    def _1111l11l(self):
        l1ll1lll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l11lll11l
        self.l11lll11l = []
        for item in items:
            l1l111111 = urlparse(item.strip(), scheme=l1ll1lll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1l111111.path[-1] == l1ll1lll (u"ࠣ࠱ࠥइ"):
                l1ll1llll = l1l111111.path
            else:
                path_list = l1l111111.path.split(l1ll1lll (u"ࠤ࠲ࠦई"))
                l1ll1llll = l1ll1lll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1ll1lll (u"ࠦ࠴ࠨऊ")
            l1l1l11ll = urlparse(self.l11l1ll1l, scheme=l1ll1lll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1l111111.scheme:
                scheme = l1l111111.scheme
            elif l1l1l11ll.scheme:
                scheme = l1l1l11ll.scheme
            else:
                scheme = l1ll1lll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1l111111.netloc and not l1l1l11ll.netloc:
                l1lll111l = l1l111111.netloc
            elif not l1l111111.netloc and l1l1l11ll.netloc:
                l1lll111l = l1l1l11ll.netloc
            elif not l1l111111.netloc and not l1l1l11ll.netloc and len(self.l11lll11l) > 0:
                l11l111l1 = urlparse(self.l11lll11l[len(self.l11lll11l) - 1])
                l1lll111l = l11l111l1.netloc
            elif l1l1l11ll.netloc:
                l1lll111l = l1l111111.netloc
            elif not l1l1l11ll.netloc:
                l1lll111l = l1l111111.netloc
            if l1l111111.path:
                l11lll1l1 = l1l111111.path
            if l1lll111l:
                l1lll111l = self._1l1lll1l(l1lll111l, scheme)
                l11llllll = ParseResult(scheme=scheme, netloc=l1lll111l, path=l11lll1l1,
                                          params=l1l111111.params,
                                          query=l1l111111.query,
                                          fragment=l1l111111.fragment)
                self.l11lll11l.append(l11llllll.geturl())
    def _111l111l(self):
        l1ll1lll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l11ll1l1l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll1l(l1ll1lll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l11ll1l1l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll1l(l1ll1lll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1l111lll:
            l1l11l11l = []
            for l1l1lll11 in self.l1l111lll:
                if l1l1lll11 not in [x[l1ll1lll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l11l11l.append(l1l1lll11)
            if l1l11l11l:
                l11l1lll = l1ll1lll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1ll1lll (u"ࠧ࠲ࠠࠣऒ").join(l1l11l11l))
                raise l111ll1l(l1ll1lll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11l1lll)
    def l11ll1lll(self, params):
        l1ll1lll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l111l1111 = True
        for param in self._11l1lll1:
            if not params.get(param.lower()):
                l111l1111 = False
        return l111l1111
class l1l1ll111():
    def __init__(self, l11l11l1l):
        self.l1l1111ll = l11ll11.l111ll1()
        self.l1ll11l1l = self.l1ll1lll1()
        self.l1llllllll = self.l11l1l1ll()
        self.l11l11l1l = l11l11l1l
        self._1ll1l1ll = [l1ll1lll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1ll1lll (u"ࠤࡑࡳࡳ࡫ࠢख"), l1ll1lll (u"ࠥࡅࡱࡲࠢग"), l1ll1lll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1ll1lll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1ll1lll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1ll1lll (u"ࠢࡊࡇࠥछ"), l1ll1lll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._11ll111l = [l1ll1lll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1ll1lll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1ll1lll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1ll1lll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l1l1111 = None
    def l1ll1lll1(self):
        l1ll111l1 = l1ll1lll (u"ࠨࡎࡰࡰࡨࠦड")
        return l1ll111l1
    def l11l1l1ll(self):
        l11llll1l = 0
        return l11llll1l
    def l1111l1ll(self):
        l11l1lll = l1ll1lll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1llllllll)
        l11l1lll += l1ll1lll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l1111l1(l1l1ll11, l11l1lll, t=1)
        return res
    def run(self):
        l111ll11l = True
        self._1l11llll()
        result = []
        try:
            for cookie in l1l11111l(l11l1l11=self.l11l11l1l.cookies).run():
                result.append(cookie)
        except l11111ll as e:
            logger.exception(l1ll1lll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l111lll1l = self._1111llll(result)
            if l111lll1l:
                logger.info(l1ll1lll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l111lll1l)
                self.l1l1l1111 = l111lll1l
            else:
                logger.info(l1ll1lll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l111lll1l)
            l111ll11l = True
        else:
            l111ll11l = False
        return l111ll11l
    def _1111llll(self, l111l1l11):
        res = False
        l1l1111 = os.path.join(os.environ[l1ll1lll (u"ࠬࡎࡏࡎࡇࠪध")], l1ll1lll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1ll1lll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1l1ll1ll = {}
        for cookies in l111l1l11:
            l1l1ll1ll[cookies.name] = cookies.value
        l11l1l111 = l1ll1lll (u"ࠣࠤप")
        for key in list(l1l1ll1ll.keys()):
            l11l1l111 += l1ll1lll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1l1ll1ll[key].strip())
        if not os.path.exists(os.path.dirname(l1l1111)):
            os.makedirs(os.path.dirname(l1l1111))
        vers = int(l1ll1lll (u"ࠥࠦब").join(self.l1l1111ll.split(l1ll1lll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1ll1l111 = [l1ll1lll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1ll1lll (u"ࠨࠣࠡࠤय") + l1ll1lll (u"ࠢ࠮ࠤर") * 60,
                              l1ll1lll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1ll1lll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1ll1lll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11l1l111),
                              l1ll1lll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1ll1l111 = [l1ll1lll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1ll1lll (u"ࠨࠣࠡࠤश") + l1ll1lll (u"ࠢ࠮ࠤष") * 60,
                              l1ll1lll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1ll1lll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1ll1lll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11l1l111),
                              l1ll1lll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1l1111, l1ll1lll (u"ࠧࡽ़ࠢ")) as l1l1l1l11:
            data = l1ll1lll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1ll1l111)
            l1l1l1l11.write(data)
            l1l1l1l11.write(l1ll1lll (u"ࠢ࡝ࡰࠥा"))
        res = l1l1111
        return res
    def _1l11llll(self):
        self._1l11l1l1(l1ll1lll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._111ll111()
    def _1l11l1l1(self, l11ll1l11):
        l1ll11ll1 = self.l11l11l1l.dict[l11ll1l11.lower()]
        if l1ll11ll1:
            if isinstance(l1ll11ll1, list):
                l11ll11ll = l1ll11ll1
            else:
                l11ll11ll = [l1ll11ll1]
            if l1ll1lll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11ll1l11.lower():
                    for l1111l111 in l11ll11ll:
                        l1ll11111 = [l1l1lllll.upper() for l1l1lllll in self._1ll1l1ll]
                        if not l1111l111.upper() in l1ll11111:
                            l11llll11 = l1ll1lll (u"ࠥ࠰ࠥࠨु").join(self._1ll1l1ll)
                            l111l1lll = l1ll1lll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11ll1l11, l1ll11ll1, l11llll11, )
                            raise l1111l11(l111l1lll)
    def _111ll111(self):
        l1111lll1 = []
        l1ll1l11l = self.l11l11l1l.l1l111lll
        for l111l11l1 in self._1ll1l1ll:
            if not l111l11l1 in [l1ll1lll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1ll1lll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1111lll1.append(l111l11l1)
        for l11l1111l in self.l11l11l1l.l111ll1l1:
            if l11l1111l in l1111lll1 and not l1ll1l11l:
                l111l1lll = l1ll1lll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1111l11(l111l1lll)
def l111ll1ll(title, message, l1111111l, l1ll11lll=None):
    l11ll11l1 = l111l1l1l()
    l11ll11l1.l11l1ll11(message, title, l1111111l, l1ll11lll)
def l1ll11l11(title, message, l1111111l):
    l111l1ll1 = l11ll1ll1()
    l111l1ll1.l1l11ll11(title, message, l1111111l)
    res = l111l1ll1.result
    return res
def main():
    try:
        logger.info(l1ll1lll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11ll111)
        system.l111l11ll()
        logger.info(l1ll1lll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1llllll1(
                l1ll1lll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111111ll = l11111111()
        l111111ll.l11111ll1(l1ll1lll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l1l111l = [item.upper() for item in l111111ll.l111ll1l1]
        l1l1l1ll1 = l1ll1lll (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l1l111l
        if l1l1l1ll1:
            logger.info(l1ll1lll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1l1l11l1 = l111111ll.l11lll11l
            for ll in l1l1l11l1:
                logger.debug(l1ll1lll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(ll))
                opener = l11111(l111111ll.l11l1ll1l, ll, l1l1111=None, l1ll111l=l11ll111)
                opener.open()
                logger.info(l1ll1lll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111111l1 = l1l1ll111(l111111ll)
            l11l111ll = l111111l1.run()
            l1l1l11l1 = l111111ll.l11lll11l
            for ll in l1l1l11l1:
                logger.info(l1ll1lll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(ll))
                opener = l11111(l111111ll.l11l1ll1l, ll, l1l1111=l111111l1.l1l1l1111,
                                l1ll111l=l11ll111)
                opener.open()
                logger.info(l1ll1lll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11ll as e:
        title = l1ll1lll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l111lllll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111lllll = el
        l1ll1ll11 = l1ll1lll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1l1ll1, message.strip())
        l111ll1ll(title, l1ll1ll11, l1111111l=l11ll111.get_value(l1ll1lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1ll1lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1ll11lll=l111lllll)
        sys.exit(2)
    except l11111l1 as e:
        title = l1ll1lll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l111lllll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l111lllll = el
        l1ll1ll11 = l1ll1lll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l111ll1ll(title, l1ll1ll11, l1111111l=l11ll111.get_value(l1ll1lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1ll1lll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1ll11lll=l111lllll)
        sys.exit(2)
    except l1llllll1 as e:
        title = l1ll1lll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l111ll1ll(title, str(e), l1111111l=l11ll111.get_value(l1ll1lll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1ll1lll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1lll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l111ll1ll(title, l1ll1lll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1111111l=l11ll111.get_value(l1ll1lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1ll1lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1111l11 as e:
        title = l1ll1lll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l111ll1ll(title, l1ll1lll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1111111l=l11ll111.get_value(l1ll1lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1ll1lll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1lll as e:
        title = l1ll1lll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l111ll1ll(title, l1ll1lll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1111111l=l11ll111.get_value(l1ll1lll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1ll1lll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l111lll:
        logger.info(l1ll1lll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1lll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1ll11
        logger.exception(l1ll1lll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l111ll1ll(title, l1ll1lll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1111111l=l11ll111.get_value(l1ll1lll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1ll1lll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1lll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()