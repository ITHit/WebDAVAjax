#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1l111l = 7
def l1ll1l1l (l11ll1l):
    global l1l11
    l1 = ord (l11ll1l [-1])
    l1lll = l11ll1l [:-1]
    l1lllll = l1 % len (l1lll)
    l1lll11 = l1lll [:l1lllll] + l1lll [l1lllll:]
    if l1l1ll1:
        l1l11l = l111l11 () .join ([unichr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    return eval (l1l11l)
import sys, json
import os
import urllib
import l11l1l1
from l1ll1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1llll import l11l1lll, logger, l11ll1ll
from cookies import l111llll as l1l1l1lll
from l11ll import l111
l1l11ll1l = None
from l1ll1lll import *
class l1ll111l1():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1l1l (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1l1l11):
        self.config = l1l1l1l11
        self.l1lll111l = l11l1l1.l111l1l()
    def l1111ll11(self):
        data = platform.uname()
        logger.info(l1ll1l1l (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1ll1l1l (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1ll1l1l (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1ll1l1l (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll1111l():
    def __init__(self, encode = True):
        self._encode = encode
        self._111l1l1l = [l1ll1l1l (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l111l1l11 = None
        self.l11llll11 = None
        self.l111ll1ll = None
        self.l1l1ll1l1 = None
        self.l11l111 = None
        self.l11lllll1 = None
        self.l11l1111l = None
        self.l1l111ll1 = None
        self.cookies = None
    def l11llll1l(self, url):
        l1ll1l1l (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1ll1l1l (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11ll1lll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11111111(url)
        self.dict = self._11l11ll1(params)
        logger.info(l1ll1l1l (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1l1lll11(self.dict):
            raise l1lllll1l(l1ll1l1l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._111l1l1l)
        self._1l11111l(self.dict)
        if self._encode:
            self.l1ll11ll1()
        self._111lllll()
        self._1l1l11l1()
        self._1l111l11()
        self._1ll1l111()
        self.l11ll11ll()
        logger.info(l1ll1l1l (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1ll1l1l (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l111l1l11))
        logger.info(l1ll1l1l (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11llll11))
        logger.info(l1ll1l1l (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l111ll1ll))
        logger.info(l1ll1l1l (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1l1ll1l1))
        logger.info(l1ll1l1l (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l11l111))
        logger.info(l1ll1l1l (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11lllll1))
        logger.info(l1ll1l1l (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l11l1111l))
        logger.info(l1ll1l1l (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1l111ll1))
    def _1l11111l(self, l1ll11111):
        self.l111l1l11 = l1ll11111.get(l1ll1l1l (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11llll11 = l1ll11111.get(l1ll1l1l (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1ll1l1l (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l111ll1ll = l1ll11111.get(l1ll1l1l (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1l1ll1l1 = l1ll11111.get(l1ll1l1l (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l11l111 = l1ll11111.get(l1ll1l1l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11lllll1 = l1ll11111.get(l1ll1l1l (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l11l1111l = l1ll11111.get(l1ll1l1l (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1ll1l1l (u"ࠣࠤ࣏"))
        self.l1l111ll1 = l1ll11111.get(l1ll1l1l (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1ll1l1l (u"࣑ࠥࠦ"))
        self.cookies = l1ll11111.get(l1ll1l1l (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11ll11ll(self):
        l11lll111 = False
        if self.l11l111:
            if self.l11l111.upper() == l1ll1l1l (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l11l111 = l1ll1l1l (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l11l111.upper() == l1ll1l1l (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l11l111 = l1ll1l1l (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l11l111.upper() == l1ll1l1l (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l11l111 = l1ll1l1l (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l11l111.upper() == l1ll1l1l (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l11l111 = l1ll1l1l (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l11l111 == l1ll1l1l (u"ࠨࠢࣛ"):
                l11lll111 = True
            else:
                self.l11l111 = self.l11l111.lower()
        else:
            l11lll111 = True
        if l11lll111:
            self.l11l111 = l1ll1l1l (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1ll11ll1(self):
        l1ll1l1l (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1l1l (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11l111ll = []
                    for el in self.__dict__.get(key):
                        l11l111ll.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11l111ll
    def l1l11l111(self, l1l1111l1):
        res = l1l1111l1
        if self._encode:
            res = urllib.parse.quote(l1l1111l1, safe=l1ll1l1l (u"ࠥࠦࣟ"))
        return res
    def _11ll1lll(self, url):
        l1ll1l1l (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1ll1l1l (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1ll1l1l (u"ࠨ࠺ࠣ࣢")), l1ll1l1l (u"ࠧࠨࣣ"), url)
        return url
    def _11111111(self, url):
        l1ll1l1l (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1ll1l11l = url.split(l1ll1l1l (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1ll1l1l (u"ࠥ࠿ࣦࠧ")))
        result = l1ll1l11l
        if len(result) == 0:
            raise l1llll11l(l1ll1l1l (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _11l11ll1(self, params):
        l1ll1l1l (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1ll1l1l (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1ll1l1l (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11lll1ll = data.group(l1ll1l1l (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11lll1ll in (l1ll1l1l (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1ll1l1l (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1ll1l1l (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1ll1l1l (u"ࠧ࠲࣯ࠢ"))
                elif l11lll1ll == l1ll1l1l (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1ll1l1l (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1l1l (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11lll1ll] = value
        return result
    def _1l111l1l(self, url, scheme):
        l1ll1l1l (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1ll11l11 = {l1ll1l1l (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1ll1l1l (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11l1l1ll = url.split(l1ll1l1l (u"ࠧࡀࣶࠢ"))
        if len(l11l1l1ll) == 1:
            for l1l11l1ll in list(l1ll11l11.keys()):
                if l1l11l1ll == scheme:
                    url += l1ll1l1l (u"ࠨ࠺ࠣࣷ") + str(l1ll11l11[l1l11l1ll])
                    break
        return url
    def _111lllll(self):
        l1ll1l1l (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1l1ll1l1:
            l111ll111 = self.l1l1ll1l1[0]
            l11lll1l1 = urlparse(l111ll111)
        if self.l111l1l11:
            l1l11ll11 = urlparse(self.l111l1l11)
            if l1l11ll11.scheme:
                l11llllll = l1l11ll11.scheme
            else:
                if l11lll1l1.scheme:
                    l11llllll = l11lll1l1.scheme
                else:
                    raise l1llllll1(
                        l1ll1l1l (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l11ll11.netloc:
                l11l1l111 = l1l11ll11.netloc
            else:
                if l11lll1l1.netloc:
                    l11l1l111 = l11lll1l1.netloc
                else:
                    raise l1llllll1(
                        l1ll1l1l (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l11l1l111 = self._1l111l1l(l11l1l111, l11llllll)
            path = l1l11ll11.path
            if not path.endswith(l1ll1l1l (u"ࠪ࠳ࠬࣻ")):
                path += l1ll1l1l (u"ࠫ࠴࠭ࣼ")
            l11ll1111 = ParseResult(scheme=l11llllll, netloc=l11l1l111, path=path,
                                         params=l1l11ll11.params, query=l1l11ll11.query,
                                         fragment=l1l11ll11.fragment)
            self.l111l1l11 = l11ll1111.geturl()
        else:
            if not l11lll1l1.netloc:
                raise l1llllll1(l1ll1l1l (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11lll11l = l11lll1l1.path
            l1l111lll = l1ll1l1l (u"ࠨ࠯ࠣࣾ").join(l11lll11l.split(l1ll1l1l (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1ll1l1l (u"ࠣ࠱ࠥऀ")
            l11ll1111 = ParseResult(scheme=l11lll1l1.scheme,
                                         netloc=self._1l111l1l(l11lll1l1.netloc, l11lll1l1.scheme),
                                         path=l1l111lll,
                                         params=l1ll1l1l (u"ࠤࠥँ"),
                                         query=l1ll1l1l (u"ࠥࠦं"),
                                         fragment=l1ll1l1l (u"ࠦࠧः")
                                         )
            self.l111l1l11 = l11ll1111.geturl()
    def _1l111l11(self):
        l1ll1l1l (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1l1ll1l1:
            l111ll111 = self.l1l1ll1l1[0]
            l11lll1l1 = urlparse(l111ll111)
        if self.l11lllll1:
            l1l1l1l1l = urlparse(self.l11lllll1)
            if l1l1l1l1l.scheme:
                l1l11l1l1 = l1l1l1l1l.scheme
            else:
                l1l11l1l1 = l11lll1l1.scheme
            if l1l1l1l1l.netloc:
                l111l1ll1 = l1l1l1l1l.netloc
            else:
                l111l1ll1 = l11lll1l1.netloc
            l1l111111 = ParseResult(scheme=l1l11l1l1, netloc=l111l1ll1, path=l1l1l1l1l.path,
                                      params=l1l1l1l1l.params, query=l1l1l1l1l.query,
                                      fragment=l1l1l1l1l.fragment)
            self.l11lllll1 = l1l111111.geturl()
    def _1l1l11l1(self):
        l1ll1l1l (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1l1ll1l1
        self.l1l1ll1l1 = []
        for item in items:
            l1ll1l1l1 = urlparse(item.strip(), scheme=l1ll1l1l (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1ll1l1l1.path[-1] == l1ll1l1l (u"ࠣ࠱ࠥइ"):
                l1l1l1111 = l1ll1l1l1.path
            else:
                path_list = l1ll1l1l1.path.split(l1ll1l1l (u"ࠤ࠲ࠦई"))
                l1l1l1111 = l1ll1l1l (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1ll1l1l (u"ࠦ࠴ࠨऊ")
            l11111l11 = urlparse(self.l111l1l11, scheme=l1ll1l1l (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1ll1l1l1.scheme:
                scheme = l1ll1l1l1.scheme
            elif l11111l11.scheme:
                scheme = l11111l11.scheme
            else:
                scheme = l1ll1l1l (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1ll1l1l1.netloc and not l11111l11.netloc:
                l111lll11 = l1ll1l1l1.netloc
            elif not l1ll1l1l1.netloc and l11111l11.netloc:
                l111lll11 = l11111l11.netloc
            elif not l1ll1l1l1.netloc and not l11111l11.netloc and len(self.l1l1ll1l1) > 0:
                l11111lll = urlparse(self.l1l1ll1l1[len(self.l1l1ll1l1) - 1])
                l111lll11 = l11111lll.netloc
            elif l11111l11.netloc:
                l111lll11 = l1ll1l1l1.netloc
            elif not l11111l11.netloc:
                l111lll11 = l1ll1l1l1.netloc
            if l1ll1l1l1.path:
                l1ll11lll = l1ll1l1l1.path
            if l111lll11:
                l111lll11 = self._1l111l1l(l111lll11, scheme)
                l1l1l11ll = ParseResult(scheme=scheme, netloc=l111lll11, path=l1ll11lll,
                                          params=l1ll1l1l1.params,
                                          query=l1ll1l1l1.query,
                                          fragment=l1ll1l1l1.fragment)
                self.l1l1ll1l1.append(l1l1l11ll.geturl())
    def _1ll1l111(self):
        l1ll1l1l (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l111llll1 = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111l1l(l1ll1l1l (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l111llll1)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111l1l(l1ll1l1l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l111ll1ll:
            l1111l11l = []
            for l11l1ll11 in self.l111ll1ll:
                if l11l1ll11 not in [x[l1ll1l1l (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1111l11l.append(l11l1ll11)
            if l1111l11l:
                l1l1lll1 = l1ll1l1l (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1ll1l1l (u"ࠧ࠲ࠠࠣऒ").join(l1111l11l))
                raise l1111l1l(l1ll1l1l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l1lll1)
    def l1l1lll11(self, params):
        l1ll1l1l (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l111l11ll = True
        for param in self._111l1l1l:
            if not params.get(param.lower()):
                l111l11ll = False
        return l111l11ll
class l11ll111l():
    def __init__(self, l111ll11l):
        self.l1111lll1 = l11l1l1.l111l1l()
        self.l1l1ll1ll = self.l1l1ll111()
        self.l1lll11l1 = self.l1111ll1l()
        self.l111ll11l = l111ll11l
        self._111l1111 = [l1ll1l1l (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1ll1l1l (u"ࠤࡑࡳࡳ࡫ࠢख"), l1ll1l1l (u"ࠥࡅࡱࡲࠢग"), l1ll1l1l (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1ll1l1l (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1ll1l1l (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1ll1l1l (u"ࠢࡊࡇࠥछ"), l1ll1l1l (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._11111l1l = [l1ll1l1l (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1ll1l1l (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1ll1l1l (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1ll1l1l (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l11llll = None
    def l1l1ll111(self):
        l1111l111 = l1ll1l1l (u"ࠨࡎࡰࡰࡨࠦड")
        return l1111l111
    def l1111ll1l(self):
        l1ll1llll = 0
        return l1ll1llll
    def l1l1l1ll1(self):
        l1l1lll1 = l1ll1l1l (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1lll11l1)
        l1l1lll1 += l1ll1l1l (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1111l1l1(l11l1lll, l1l1lll1, t=1)
        return res
    def run(self):
        l1ll111ll = True
        self._11111ll1()
        result = []
        try:
            for cookie in l1l1l1lll(l111l1ll=self.l111ll11l.cookies).run():
                result.append(cookie)
        except l1111l11 as e:
            logger.exception(l1ll1l1l (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11l11lll = self._1ll1ll11(result)
            if l11l11lll:
                logger.info(l1ll1l1l (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11l11lll)
                self.l1l11llll = l11l11lll
            else:
                logger.info(l1ll1l1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11l11lll)
            l1ll111ll = True
        else:
            l1ll111ll = False
        return l1ll111ll
    def _1ll1ll11(self, l1111111l):
        res = False
        l111lll = os.path.join(os.environ[l1ll1l1l (u"ࠬࡎࡏࡎࡇࠪध")], l1ll1l1l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1ll1l1l (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11l111l1 = {}
        for cookies in l1111111l:
            l11l111l1[cookies.name] = cookies.value
        l1l1l111l = l1ll1l1l (u"ࠣࠤप")
        for key in list(l11l111l1.keys()):
            l1l1l111l += l1ll1l1l (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11l111l1[key].strip())
        if not os.path.exists(os.path.dirname(l111lll)):
            os.makedirs(os.path.dirname(l111lll))
        vers = int(l1ll1l1l (u"ࠥࠦब").join(self.l1111lll1.split(l1ll1l1l (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1111llll = [l1ll1l1l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1ll1l1l (u"ࠨࠣࠡࠤय") + l1ll1l1l (u"ࠢ࠮ࠤर") * 60,
                              l1ll1l1l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1ll1l1l (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1ll1l1l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l1l111l),
                              l1ll1l1l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1111llll = [l1ll1l1l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1ll1l1l (u"ࠨࠣࠡࠤश") + l1ll1l1l (u"ࠢ࠮ࠤष") * 60,
                              l1ll1l1l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1ll1l1l (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1ll1l1l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l1l111l),
                              l1ll1l1l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l111lll, l1ll1l1l (u"ࠧࡽ़ࠢ")) as l11l11l1l:
            data = l1ll1l1l (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1111llll)
            l11l11l1l.write(data)
            l11l11l1l.write(l1ll1l1l (u"ࠢ࡝ࡰࠥा"))
        res = l111lll
        return res
    def _11111ll1(self):
        self._1l1ll11l(l1ll1l1l (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11l11111()
    def _1l1ll11l(self, l1llllllll):
        l11l1l1l1 = self.l111ll11l.dict[l1llllllll.lower()]
        if l11l1l1l1:
            if isinstance(l11l1l1l1, list):
                l11l1l11l = l11l1l1l1
            else:
                l11l1l11l = [l11l1l1l1]
            if l1ll1l1l (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1llllllll.lower():
                    for l11ll1l1l in l11l1l11l:
                        l111lll1l = [l111l1lll.upper() for l111l1lll in self._111l1111]
                        if not l11ll1l1l.upper() in l111lll1l:
                            l1l1111ll = l1ll1l1l (u"ࠥ࠰ࠥࠨु").join(self._111l1111)
                            l1l1lll1l = l1ll1l1l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1llllllll, l11l1l1l1, l1l1111ll, )
                            raise l1lll1lll(l1l1lll1l)
    def _11l11111(self):
        l1ll1lll1 = []
        l1ll11l1l = self.l111ll11l.l111ll1ll
        for l1lll1111 in self._111l1111:
            if not l1lll1111 in [l1ll1l1l (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1ll1l1l (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1ll1lll1.append(l1lll1111)
        for l1111l1ll in self.l111ll11l.l11llll11:
            if l1111l1ll in l1ll1lll1 and not l1ll11l1l:
                l1l1lll1l = l1ll1l1l (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lll1lll(l1l1lll1l)
def l11l1lll1(title, message, l111ll1l1, l11ll1l11=None):
    l1l11l11l = l11l11l11()
    l1l11l11l.l111111ll(message, title, l111ll1l1, l11ll1l11)
def l1l11lll1(title, message, l111ll1l1):
    l111l11l1 = l11ll1ll1()
    l111l11l1.l1ll1l1ll(title, message, l111ll1l1)
    res = l111l11l1.result
    return res
def main():
    try:
        logger.info(l1ll1l1l (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11ll1ll)
        system.l1111ll11()
        logger.info(l1ll1l1l (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1lllll1l(
                l1ll1l1l (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111l111l = l1ll1111l()
        l111l111l.l11llll1l(l1ll1l1l (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l1llll1 = [item.upper() for item in l111l111l.l11llll11]
        l11l1llll = l1ll1l1l (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l1llll1
        if l11l1llll:
            logger.info(l1ll1l1l (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1ll1ll1l = l111l111l.l1l1ll1l1
            for l1l1lll in l1ll1ll1l:
                logger.debug(l1ll1l1l (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1l1lll))
                opener = l111(l111l111l.l111l1l11, l1l1lll, l111lll=None, l11l=l11ll1ll)
                opener.open()
                logger.info(l1ll1l1l (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111111l1 = l11ll111l(l111l111l)
            l1l1lllll = l111111l1.run()
            l1ll1ll1l = l111l111l.l1l1ll1l1
            for l1l1lll in l1ll1ll1l:
                logger.info(l1ll1l1l (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1l1lll))
                opener = l111(l111l111l.l111l1l11, l1l1lll, l111lll=l111111l1.l1l11llll,
                                l11l=l11ll1ll)
                opener.open()
                logger.info(l1ll1l1l (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11lll as e:
        title = l1ll1l1l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11ll11l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll11l1 = el
        l11l1ll1l = l1ll1l1l (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1l11ll, message.strip())
        l11l1lll1(title, l11l1ll1l, l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l11ll1l11=l11ll11l1)
        sys.exit(2)
    except l1lll11ll as e:
        title = l1ll1l1l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11ll11l1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll11l1 = el
        l11l1ll1l = l1ll1l1l (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l11l1lll1(title, l11l1ll1l, l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1ll1l1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l11ll1l11=l11ll11l1)
        sys.exit(2)
    except l1lllll1l as e:
        title = l1ll1l1l (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l11l1lll1(title, str(e), l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1ll1l1l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1l1l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l11l1lll1(title, l1ll1l1l (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lll1lll as e:
        title = l1ll1l1l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l11l1lll1(title, l1ll1l1l (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1ll1l1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1ll1 as e:
        title = l1ll1l1l (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l11l1lll1(title, l1ll1l1l (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1ll1l1l (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll1ll1:
        logger.info(l1ll1l1l (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1l1l (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11l1lll
        logger.exception(l1ll1l1l (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l11l1lll1(title, l1ll1l1l (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l111ll1l1=l11ll1ll.get_value(l1ll1l1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1ll1l1l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1l1l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()