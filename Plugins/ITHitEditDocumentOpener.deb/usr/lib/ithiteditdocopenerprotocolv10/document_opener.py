#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1l11l1 = 2048
l1l = 7
def l1l11l (l1lll1l1):
    global l1l111l
    l1ll11ll = ord (l1lll1l1 [-1])
    l111ll1 = l1lll1l1 [:-1]
    l111l1 = l1ll11ll % len (l111ll1)
    l111111 = l111ll1 [:l111l1] + l111ll1 [l111l1:]
    if l1l1lll:
        l1111ll = l11l11 () .join ([unichr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    return eval (l1111ll)
import sys, json
import os
import urllib
import l11llll
from l1l1l1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1ll11 import l1l1l1l1, logger, l11ll1l1
from cookies import l11l111l as l1111llll
from l11lll import l1l1
l1l1lllll = None
from l1ll1l1l import *
class l11l11l11():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l11l (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1l1111):
        self.config = l1l1l1111
        self.l11lll11l = l11llll.l1ll111l()
    def l11111lll(self):
        data = platform.uname()
        logger.info(l1l11l (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1l11l (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1l11l (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1l11l (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l11111111():
    def __init__(self, encode = True):
        self._encode = encode
        self._11l11ll1 = [l1l11l (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l111ll1ll = None
        self.l11ll111l = None
        self.l1l1l1ll1 = None
        self.l1l1l1l11 = None
        self.l1llllll = None
        self.l1l11l11l = None
        self.l111ll1l1 = None
        self.l1111l111 = None
        self.cookies = None
    def l11ll1l11(self, url):
        l1l11l (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1l11l (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11l111ll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11l111l1(url)
        self.dict = self._111llll1(params)
        logger.info(l1l11l (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l111111ll(self.dict):
            raise l111111l(l1l11l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._11l11ll1)
        self._11ll1ll1(self.dict)
        if self._encode:
            self.l1l1l11ll()
        self._1ll11l1l()
        self._1l1111l1()
        self._11l1ll11()
        self._1l1ll1ll()
        self.l11lll1ll()
        logger.info(l1l11l (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1l11l (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l111ll1ll))
        logger.info(l1l11l (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11ll111l))
        logger.info(l1l11l (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1l1l1ll1))
        logger.info(l1l11l (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1l1l1l11))
        logger.info(l1l11l (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1llllll))
        logger.info(l1l11l (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1l11l11l))
        logger.info(l1l11l (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l111ll1l1))
        logger.info(l1l11l (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1111l111))
    def _11ll1ll1(self, l11l1l1l1):
        self.l111ll1ll = l11l1l1l1.get(l1l11l (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11ll111l = l11l1l1l1.get(l1l11l (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1l11l (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1l1l1ll1 = l11l1l1l1.get(l1l11l (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1l1l1l11 = l11l1l1l1.get(l1l11l (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1llllll = l11l1l1l1.get(l1l11l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1l11l11l = l11l1l1l1.get(l1l11l (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l111ll1l1 = l11l1l1l1.get(l1l11l (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1l11l (u"ࠣࠤ࣏"))
        self.l1111l111 = l11l1l1l1.get(l1l11l (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1l11l (u"࣑ࠥࠦ"))
        self.cookies = l11l1l1l1.get(l1l11l (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11lll1ll(self):
        l1l1l1l1l = False
        if self.l1llllll:
            if self.l1llllll.upper() == l1l11l (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1llllll = l1l11l (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1llllll.upper() == l1l11l (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1llllll = l1l11l (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1llllll.upper() == l1l11l (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1llllll = l1l11l (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1llllll.upper() == l1l11l (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1llllll = l1l11l (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1llllll == l1l11l (u"ࠨࠢࣛ"):
                l1l1l1l1l = True
            else:
                self.l1llllll = self.l1llllll.lower()
        else:
            l1l1l1l1l = True
        if l1l1l1l1l:
            self.l1llllll = l1l11l (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1l1l11ll(self):
        l1l11l (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l11l (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l111l11l1 = []
                    for el in self.__dict__.get(key):
                        l111l11l1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l111l11l1
    def l1l1ll111(self, l1l111lll):
        res = l1l111lll
        if self._encode:
            res = urllib.parse.quote(l1l111lll, safe=l1l11l (u"ࠥࠦࣟ"))
        return res
    def _11l111ll(self, url):
        l1l11l (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1l11l (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1l11l (u"ࠨ࠺ࠣ࣢")), l1l11l (u"ࠧࠨࣣ"), url)
        return url
    def _11l111l1(self, url):
        l1l11l (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1111l11l = url.split(l1l11l (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1l11l (u"ࠥ࠿ࣦࠧ")))
        result = l1111l11l
        if len(result) == 0:
            raise l1lll11ll(l1l11l (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _111llll1(self, params):
        l1l11l (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1l11l (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1l11l (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l1ll1l1 = data.group(l1l11l (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l1ll1l1 in (l1l11l (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1l11l (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1l11l (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1l11l (u"ࠧ࠲࣯ࠢ"))
                elif l1l1ll1l1 == l1l11l (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1l11l (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l11l (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l1ll1l1] = value
        return result
    def _1l11ll1l(self, url, scheme):
        l1l11l (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l111l11ll = {l1l11l (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1l11l (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1l1l1lll = url.split(l1l11l (u"ࠧࡀࣶࠢ"))
        if len(l1l1l1lll) == 1:
            for l111l111l in list(l111l11ll.keys()):
                if l111l111l == scheme:
                    url += l1l11l (u"ࠨ࠺ࠣࣷ") + str(l111l11ll[l111l111l])
                    break
        return url
    def _1ll11l1l(self):
        l1l11l (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1l1l1l11:
            l111l1ll1 = self.l1l1l1l11[0]
            l1l11111l = urlparse(l111l1ll1)
        if self.l111ll1ll:
            l11lll111 = urlparse(self.l111ll1ll)
            if l11lll111.scheme:
                l11l1l11l = l11lll111.scheme
            else:
                if l1l11111l.scheme:
                    l11l1l11l = l1l11111l.scheme
                else:
                    raise l1llll11l(
                        l1l11l (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l11lll111.netloc:
                l1111lll1 = l11lll111.netloc
            else:
                if l1l11111l.netloc:
                    l1111lll1 = l1l11111l.netloc
                else:
                    raise l1llll11l(
                        l1l11l (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1111lll1 = self._1l11ll1l(l1111lll1, l11l1l11l)
            path = l11lll111.path
            if not path.endswith(l1l11l (u"ࠪ࠳ࠬࣻ")):
                path += l1l11l (u"ࠫ࠴࠭ࣼ")
            l1ll11ll1 = ParseResult(scheme=l11l1l11l, netloc=l1111lll1, path=path,
                                         params=l11lll111.params, query=l11lll111.query,
                                         fragment=l11lll111.fragment)
            self.l111ll1ll = l1ll11ll1.geturl()
        else:
            if not l1l11111l.netloc:
                raise l1llll11l(l1l11l (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l111111 = l1l11111l.path
            l111l1111 = l1l11l (u"ࠨ࠯ࠣࣾ").join(l1l111111.split(l1l11l (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1l11l (u"ࠣ࠱ࠥऀ")
            l1ll11ll1 = ParseResult(scheme=l1l11111l.scheme,
                                         netloc=self._1l11ll1l(l1l11111l.netloc, l1l11111l.scheme),
                                         path=l111l1111,
                                         params=l1l11l (u"ࠤࠥँ"),
                                         query=l1l11l (u"ࠥࠦं"),
                                         fragment=l1l11l (u"ࠦࠧः")
                                         )
            self.l111ll1ll = l1ll11ll1.geturl()
    def _11l1ll11(self):
        l1l11l (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1l1l1l11:
            l111l1ll1 = self.l1l1l1l11[0]
            l1l11111l = urlparse(l111l1ll1)
        if self.l1l11l11l:
            l1ll1lll1 = urlparse(self.l1l11l11l)
            if l1ll1lll1.scheme:
                l111ll11l = l1ll1lll1.scheme
            else:
                l111ll11l = l1l11111l.scheme
            if l1ll1lll1.netloc:
                l111l1l1l = l1ll1lll1.netloc
            else:
                l111l1l1l = l1l11111l.netloc
            l1ll1ll1l = ParseResult(scheme=l111ll11l, netloc=l111l1l1l, path=l1ll1lll1.path,
                                      params=l1ll1lll1.params, query=l1ll1lll1.query,
                                      fragment=l1ll1lll1.fragment)
            self.l1l11l11l = l1ll1ll1l.geturl()
    def _1l1111l1(self):
        l1l11l (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1l1l1l11
        self.l1l1l1l11 = []
        for item in items:
            l11l1lll1 = urlparse(item.strip(), scheme=l1l11l (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11l1lll1.path[-1] == l1l11l (u"ࠣ࠱ࠥइ"):
                l1ll111l1 = l11l1lll1.path
            else:
                path_list = l11l1lll1.path.split(l1l11l (u"ࠤ࠲ࠦई"))
                l1ll111l1 = l1l11l (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1l11l (u"ࠦ࠴ࠨऊ")
            l1l1111ll = urlparse(self.l111ll1ll, scheme=l1l11l (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11l1lll1.scheme:
                scheme = l11l1lll1.scheme
            elif l1l1111ll.scheme:
                scheme = l1l1111ll.scheme
            else:
                scheme = l1l11l (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11l1lll1.netloc and not l1l1111ll.netloc:
                l1l111ll1 = l11l1lll1.netloc
            elif not l11l1lll1.netloc and l1l1111ll.netloc:
                l1l111ll1 = l1l1111ll.netloc
            elif not l11l1lll1.netloc and not l1l1111ll.netloc and len(self.l1l1l1l11) > 0:
                l11ll1lll = urlparse(self.l1l1l1l11[len(self.l1l1l1l11) - 1])
                l1l111ll1 = l11ll1lll.netloc
            elif l1l1111ll.netloc:
                l1l111ll1 = l11l1lll1.netloc
            elif not l1l1111ll.netloc:
                l1l111ll1 = l11l1lll1.netloc
            if l11l1lll1.path:
                l1ll11l11 = l11l1lll1.path
            if l1l111ll1:
                l1l111ll1 = self._1l11ll1l(l1l111ll1, scheme)
                l111lll1l = ParseResult(scheme=scheme, netloc=l1l111ll1, path=l1ll11l11,
                                          params=l11l1lll1.params,
                                          query=l11l1lll1.query,
                                          fragment=l11l1lll1.fragment)
                self.l1l1l1l11.append(l111lll1l.geturl())
    def _1l1ll1ll(self):
        l1l11l (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1ll1l111 = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l1l11l (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1ll1l111)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l1l11l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1l1l1ll1:
            l11l11lll = []
            for l11l11l1l in self.l1l1l1ll1:
                if l11l11l1l not in [x[l1l11l (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l11l11lll.append(l11l11l1l)
            if l11l11lll:
                l1l1l111 = l1l11l (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1l11l (u"ࠧ࠲ࠠࠣऒ").join(l11l11lll))
                raise l111l111(l1l11l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l1l111)
    def l111111ll(self, params):
        l1l11l (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1l11l1ll = True
        for param in self._11l11ll1:
            if not params.get(param.lower()):
                l1l11l1ll = False
        return l1l11l1ll
class l1ll1l1ll():
    def __init__(self, l11llllll):
        self.l1111l1l1 = l11llll.l1ll111l()
        self.l11llll1l = self.l1ll1l1l1()
        self.l1111ll1l = self.l1l11l111()
        self.l11llllll = l11llllll
        self._11ll1l1l = [l1l11l (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1l11l (u"ࠤࡑࡳࡳ࡫ࠢख"), l1l11l (u"ࠥࡅࡱࡲࠢग"), l1l11l (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1l11l (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1l11l (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1l11l (u"ࠢࡊࡇࠥछ"), l1l11l (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l1llll1 = [l1l11l (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1l11l (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1l11l (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1l11l (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11ll11ll = None
    def l1ll1l1l1(self):
        l1l11llll = l1l11l (u"ࠨࡎࡰࡰࡨࠦड")
        return l1l11llll
    def l1l11l111(self):
        l1111ll11 = 0
        return l1111ll11
    def l1l111l11(self):
        l1l1l111 = l1l11l (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1111ll1l)
        l1l1l111 += l1l11l (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1lll1111(l1l1l1l1, l1l1l111, t=1)
        return res
    def run(self):
        l11l1l111 = True
        self._1l1l11l1()
        result = []
        try:
            for cookie in l1111llll(l111lll1=self.l11llllll.cookies).run():
                result.append(cookie)
        except l1lllll1l as e:
            logger.exception(l1l11l (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1l111l1l = self._1ll1l11l(result)
            if l1l111l1l:
                logger.info(l1l11l (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1l111l1l)
                self.l11ll11ll = l1l111l1l
            else:
                logger.info(l1l11l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1l111l1l)
            l11l1l111 = True
        else:
            l11l1l111 = False
        return l11l1l111
    def _1ll1l11l(self, l1111l1ll):
        res = False
        l11ll = os.path.join(os.environ[l1l11l (u"ࠬࡎࡏࡎࡇࠪध")], l1l11l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1l11l (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11111l1l = {}
        for cookies in l1111l1ll:
            l11111l1l[cookies.name] = cookies.value
        l1l1lll11 = l1l11l (u"ࠣࠤप")
        for key in list(l11111l1l.keys()):
            l1l1lll11 += l1l11l (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11111l1l[key].strip())
        if not os.path.exists(os.path.dirname(l11ll)):
            os.makedirs(os.path.dirname(l11ll))
        vers = int(l1l11l (u"ࠥࠦब").join(self.l1111l1l1.split(l1l11l (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l111lllll = [l1l11l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1l11l (u"ࠨࠣࠡࠤय") + l1l11l (u"ࠢ࠮ࠤर") * 60,
                              l1l11l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1l11l (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1l11l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l1lll11),
                              l1l11l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l111lllll = [l1l11l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1l11l (u"ࠨࠣࠡࠤश") + l1l11l (u"ࠢ࠮ࠤष") * 60,
                              l1l11l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1l11l (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1l11l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l1lll11),
                              l1l11l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l11ll, l1l11l (u"ࠧࡽ़ࠢ")) as l11l1l1ll:
            data = l1l11l (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l111lllll)
            l11l1l1ll.write(data)
            l11l1l1ll.write(l1l11l (u"ࠢ࡝ࡰࠥा"))
        res = l11ll
        return res
    def _1l1l11l1(self):
        self._111l1lll(l1l11l (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1l11ll11()
    def _111l1lll(self, l1ll1llll):
        l11l1llll = self.l11llllll.dict[l1ll1llll.lower()]
        if l11l1llll:
            if isinstance(l11l1llll, list):
                l1l1lll1l = l11l1llll
            else:
                l1l1lll1l = [l11l1llll]
            if l1l11l (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l1ll1llll.lower():
                    for l11lllll1 in l1l1lll1l:
                        l11111l11 = [l1111111l.upper() for l1111111l in self._11ll1l1l]
                        if not l11lllll1.upper() in l11111l11:
                            l11ll11l1 = l1l11l (u"ࠥ࠰ࠥࠨु").join(self._11ll1l1l)
                            l11llll11 = l1l11l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l1ll1llll, l11l1llll, l11ll11l1, )
                            raise l1llll1ll(l11llll11)
    def _1l11ll11(self):
        l11111ll1 = []
        l1lll11l1 = self.l11llllll.l1l1l1ll1
        for l1ll1ll11 in self._11ll1l1l:
            if not l1ll1ll11 in [l1l11l (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1l11l (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11111ll1.append(l1ll1ll11)
        for l11ll1111 in self.l11llllll.l11ll111l:
            if l11ll1111 in l11111ll1 and not l1lll11l1:
                l11llll11 = l1l11l (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1llll1ll(l11llll11)
def l1l1ll11l(title, message, l1ll1111l, l111111l1=None):
    l1ll111ll = l111l1l11()
    l1ll111ll.l1lll111l(message, title, l1ll1111l, l111111l1)
def l1l11lll1(title, message, l1ll1111l):
    l11lll1l1 = l1ll11111()
    l11lll1l1.l11l11111(title, message, l1ll1111l)
    res = l11lll1l1.result
    return res
def main():
    try:
        logger.info(l1l11l (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11ll1l1)
        system.l11111lll()
        logger.info(l1l11l (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l111111l(
                l1l11l (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111ll111 = l11111111()
        l111ll111.l11ll1l11(l1l11l (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1llllllll = [item.upper() for item in l111ll111.l11ll111l]
        l1l11l1l1 = l1l11l (u"ࠧࡔࡏࡏࡇࠥॊ") in l1llllllll
        if l1l11l1l1:
            logger.info(l1l11l (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1l1l111l = l111ll111.l1l1l1l11
            for l1ll1111 in l1l1l111l:
                logger.debug(l1l11l (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1ll1111))
                opener = l1l1(l111ll111.l111ll1ll, l1ll1111, l11ll=None, l1lll11=l11ll1l1)
                opener.open()
                logger.info(l1l11l (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111lll11 = l1ll1l1ll(l111ll111)
            l11l1ll1l = l111lll11.run()
            l1l1l111l = l111ll111.l1l1l1l11
            for l1ll1111 in l1l1l111l:
                logger.info(l1l11l (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1ll1111))
                opener = l1l1(l111ll111.l111ll1ll, l1ll1111, l11ll=l111lll11.l11ll11ll,
                                l1lll11=l11ll1l1)
                opener.open()
                logger.info(l1l11l (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11lll1 as e:
        title = l1l11l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1l1l1
        logger.exception(l1l11l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1ll11lll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll11lll = el
        l11l1111l = l1l11l (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1lll, message.strip())
        l1l1ll11l(title, l11l1111l, l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1l11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l111111l1=l1ll11lll)
        sys.exit(2)
    except l1llllll1 as e:
        title = l1l11l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1l1l1
        logger.exception(l1l11l (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1ll11lll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1ll11lll = el
        l11l1111l = l1l11l (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1l1ll11l(title, l11l1111l, l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l111111l1=l1ll11lll)
        sys.exit(2)
    except l111111l as e:
        title = l1l11l (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1l1l1
        logger.exception(l1l11l (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1l1ll11l(title, str(e), l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1l11l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1l11l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1l1l1
        logger.exception(l1l11l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1l1ll11l(title, l1l11l (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1l11l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1llll1ll as e:
        title = l1l11l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1l1l1
        logger.exception(l1l11l (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1l1ll11l(title, l1l11l (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1111111 as e:
        title = l1l11l (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1l1l1
        logger.exception(l1l11l (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1l1ll11l(title, l1l11l (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1l11l (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l11:
        logger.info(l1l11l (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1l11l (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1l1l1
        logger.exception(l1l11l (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1l1ll11l(title, l1l11l (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1ll1111l=l11ll1l1.get_value(l1l11l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1l11l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l11l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()