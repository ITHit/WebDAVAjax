#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1111ll = 2048
l1l1l11 = 7
def l1ll1l1l (l1l1ll1):
    global l1lll
    l1lll1l = ord (l1l1ll1 [-1])
    l1ll = l1l1ll1 [:-1]
    l11l1ll = l1lll1l % len (l1ll)
    l1lllll1 = l1ll [:l11l1ll] + l1ll [l11l1ll:]
    if l1l1l1l:
        l1111l1 = l1llll1l () .join ([unichr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    return eval (l1111l1)
import sys, json
import os
import urllib
import l1l1l
from l11llll import *
import platform
from urllib.parse import urlparse, ParseResult
from l11ll11l import l1l1l111, logger, l1l1llll
from cookies import l1111l1l as l11ll1l11
from l1lll111 import l111l
l111l1ll1 = None
from l1l111l import *
class l1l1lll1l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1l1l (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1lll1111):
        self.config = l1lll1111
        self.l111111ll = l1l1l.l1ll1ll1()
    def l11l111ll(self):
        data = platform.uname()
        logger.info(l1ll1l1l (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1ll1l1l (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1ll1l1l (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1ll1l1l (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll111ll():
    def __init__(self, encode = True):
        self._encode = encode
        self._11ll1l1l = [l1ll1l1l (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l111ll1 = None
        self.l1ll111l1 = None
        self.l11l11lll = None
        self.l111l1lll = None
        self.l11l11l = None
        self.l111l1111 = None
        self.l11llll1l = None
        self.l1l111lll = None
        self.cookies = None
    def l111111l1(self, url):
        l1ll1l1l (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1ll1l1l (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l1l11l1(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11l11ll1(url)
        self.dict = self._1l1111l1(params)
        logger.info(l1ll1l1l (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1111l1ll(self.dict):
            raise l1lll11ll(l1ll1l1l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._11ll1l1l)
        self._11ll11ll(self.dict)
        if self._encode:
            self.l1lll11l1()
        self._111l11ll()
        self._11ll1lll()
        self._111lllll()
        self._1lll111l()
        self.l11111l11()
        logger.info(l1ll1l1l (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1ll1l1l (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l111ll1))
        logger.info(l1ll1l1l (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1ll111l1))
        logger.info(l1ll1l1l (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11l11lll))
        logger.info(l1ll1l1l (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l111l1lll))
        logger.info(l1ll1l1l (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l11l11l))
        logger.info(l1ll1l1l (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l111l1111))
        logger.info(l1ll1l1l (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l11llll1l))
        logger.info(l1ll1l1l (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l1l111lll))
    def _11ll11ll(self, l1ll11111):
        self.l1l111ll1 = l1ll11111.get(l1ll1l1l (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1ll111l1 = l1ll11111.get(l1ll1l1l (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1ll1l1l (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11l11lll = l1ll11111.get(l1ll1l1l (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l111l1lll = l1ll11111.get(l1ll1l1l (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l11l11l = l1ll11111.get(l1ll1l1l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l111l1111 = l1ll11111.get(l1ll1l1l (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l11llll1l = l1ll11111.get(l1ll1l1l (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1ll1l1l (u"ࠣࠤ࣏"))
        self.l1l111lll = l1ll11111.get(l1ll1l1l (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1ll1l1l (u"࣑ࠥࠦ"))
        self.cookies = l1ll11111.get(l1ll1l1l (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l11111l11(self):
        l11l1llll = False
        if self.l11l11l:
            if self.l11l11l.upper() == l1ll1l1l (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l11l11l = l1ll1l1l (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l11l11l.upper() == l1ll1l1l (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l11l11l = l1ll1l1l (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l11l11l.upper() == l1ll1l1l (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l11l11l = l1ll1l1l (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l11l11l.upper() == l1ll1l1l (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l11l11l = l1ll1l1l (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l11l11l == l1ll1l1l (u"ࠨࠢࣛ"):
                l11l1llll = True
            else:
                self.l11l11l = self.l11l11l.lower()
        else:
            l11l1llll = True
        if l11l1llll:
            self.l11l11l = l1ll1l1l (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1lll11l1(self):
        l1ll1l1l (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1l1l (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l11111l = []
                    for el in self.__dict__.get(key):
                        l1l11111l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l11111l
    def l1ll1l1ll(self, l1l11l1ll):
        res = l1l11l1ll
        if self._encode:
            res = urllib.parse.quote(l1l11l1ll, safe=l1ll1l1l (u"ࠥࠦࣟ"))
        return res
    def _1l1l11l1(self, url):
        l1ll1l1l (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1ll1l1l (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1ll1l1l (u"ࠨ࠺ࠣ࣢")), l1ll1l1l (u"ࠧࠨࣣ"), url)
        return url
    def _11l11ll1(self, url):
        l1ll1l1l (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1ll1l111 = url.split(l1ll1l1l (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1ll1l1l (u"ࠥ࠿ࣦࠧ")))
        result = l1ll1l111
        if len(result) == 0:
            raise l11111l1(l1ll1l1l (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1l1111l1(self, params):
        l1ll1l1l (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1ll1l1l (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1ll1l1l (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l111ll1ll = data.group(l1ll1l1l (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l111ll1ll in (l1ll1l1l (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1ll1l1l (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1ll1l1l (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1ll1l1l (u"ࠧ࠲࣯ࠢ"))
                elif l111ll1ll == l1ll1l1l (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1ll1l1l (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1l1l (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l111ll1ll] = value
        return result
    def _11lll1ll(self, url, scheme):
        l1ll1l1l (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l11l1l111 = {l1ll1l1l (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1ll1l1l (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11l1111l = url.split(l1ll1l1l (u"ࠧࡀࣶࠢ"))
        if len(l11l1111l) == 1:
            for l1l1l111l in list(l11l1l111.keys()):
                if l1l1l111l == scheme:
                    url += l1ll1l1l (u"ࠨ࠺ࠣࣷ") + str(l11l1l111[l1l1l111l])
                    break
        return url
    def _111l11ll(self):
        l1ll1l1l (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l111l1lll:
            l11l1ll1l = self.l111l1lll[0]
            l1l1llll1 = urlparse(l11l1ll1l)
        if self.l1l111ll1:
            l111ll1l1 = urlparse(self.l1l111ll1)
            if l111ll1l1.scheme:
                l1l1l1111 = l111ll1l1.scheme
            else:
                if l1l1llll1.scheme:
                    l1l1l1111 = l1l1llll1.scheme
                else:
                    raise l1111111(
                        l1ll1l1l (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l111ll1l1.netloc:
                l1l11l11l = l111ll1l1.netloc
            else:
                if l1l1llll1.netloc:
                    l1l11l11l = l1l1llll1.netloc
                else:
                    raise l1111111(
                        l1ll1l1l (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l11l11l = self._11lll1ll(l1l11l11l, l1l1l1111)
            path = l111ll1l1.path
            if not path.endswith(l1ll1l1l (u"ࠪ࠳ࠬࣻ")):
                path += l1ll1l1l (u"ࠫ࠴࠭ࣼ")
            l11l1l1l1 = ParseResult(scheme=l1l1l1111, netloc=l1l11l11l, path=path,
                                         params=l111ll1l1.params, query=l111ll1l1.query,
                                         fragment=l111ll1l1.fragment)
            self.l1l111ll1 = l11l1l1l1.geturl()
        else:
            if not l1l1llll1.netloc:
                raise l1111111(l1ll1l1l (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l111l111l = l1l1llll1.path
            l1l11l111 = l1ll1l1l (u"ࠨ࠯ࠣࣾ").join(l111l111l.split(l1ll1l1l (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1ll1l1l (u"ࠣ࠱ࠥऀ")
            l11l1l1l1 = ParseResult(scheme=l1l1llll1.scheme,
                                         netloc=self._11lll1ll(l1l1llll1.netloc, l1l1llll1.scheme),
                                         path=l1l11l111,
                                         params=l1ll1l1l (u"ࠤࠥँ"),
                                         query=l1ll1l1l (u"ࠥࠦं"),
                                         fragment=l1ll1l1l (u"ࠦࠧः")
                                         )
            self.l1l111ll1 = l11l1l1l1.geturl()
    def _111lllll(self):
        l1ll1l1l (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l111l1lll:
            l11l1ll1l = self.l111l1lll[0]
            l1l1llll1 = urlparse(l11l1ll1l)
        if self.l111l1111:
            l11llll11 = urlparse(self.l111l1111)
            if l11llll11.scheme:
                l1l1ll111 = l11llll11.scheme
            else:
                l1l1ll111 = l1l1llll1.scheme
            if l11llll11.netloc:
                l1111l11l = l11llll11.netloc
            else:
                l1111l11l = l1l1llll1.netloc
            l111llll1 = ParseResult(scheme=l1l1ll111, netloc=l1111l11l, path=l11llll11.path,
                                      params=l11llll11.params, query=l11llll11.query,
                                      fragment=l11llll11.fragment)
            self.l111l1111 = l111llll1.geturl()
    def _11ll1lll(self):
        l1ll1l1l (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l111l1lll
        self.l111l1lll = []
        for item in items:
            l111l1l11 = urlparse(item.strip(), scheme=l1ll1l1l (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l111l1l11.path[-1] == l1ll1l1l (u"ࠣ࠱ࠥइ"):
                l11l1l11l = l111l1l11.path
            else:
                path_list = l111l1l11.path.split(l1ll1l1l (u"ࠤ࠲ࠦई"))
                l11l1l11l = l1ll1l1l (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1ll1l1l (u"ࠦ࠴ࠨऊ")
            l1l1lllll = urlparse(self.l1l111ll1, scheme=l1ll1l1l (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l111l1l11.scheme:
                scheme = l111l1l11.scheme
            elif l1l1lllll.scheme:
                scheme = l1l1lllll.scheme
            else:
                scheme = l1ll1l1l (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l111l1l11.netloc and not l1l1lllll.netloc:
                l1l111111 = l111l1l11.netloc
            elif not l111l1l11.netloc and l1l1lllll.netloc:
                l1l111111 = l1l1lllll.netloc
            elif not l111l1l11.netloc and not l1l1lllll.netloc and len(self.l111l1lll) > 0:
                l1ll11l11 = urlparse(self.l111l1lll[len(self.l111l1lll) - 1])
                l1l111111 = l1ll11l11.netloc
            elif l1l1lllll.netloc:
                l1l111111 = l111l1l11.netloc
            elif not l1l1lllll.netloc:
                l1l111111 = l111l1l11.netloc
            if l111l1l11.path:
                l11l1ll11 = l111l1l11.path
            if l1l111111:
                l1l111111 = self._11lll1ll(l1l111111, scheme)
                l11l1lll1 = ParseResult(scheme=scheme, netloc=l1l111111, path=l11l1ll11,
                                          params=l111l1l11.params,
                                          query=l111l1l11.query,
                                          fragment=l111l1l11.fragment)
                self.l111l1lll.append(l11l1lll1.geturl())
    def _1lll111l(self):
        l1ll1l1l (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1ll1l11l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111lll(l1ll1l1l (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1ll1l11l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l1111lll(l1ll1l1l (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11l11lll:
            l11111l1l = []
            for l1ll1l1l1 in self.l11l11lll:
                if l1ll1l1l1 not in [x[l1ll1l1l (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l11111l1l.append(l1ll1l1l1)
            if l11111l1l:
                l11lllll = l1ll1l1l (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1ll1l1l (u"ࠧ࠲ࠠࠣऒ").join(l11111l1l))
                raise l1111lll(l1ll1l1l (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11lllll)
    def l1111l1ll(self, params):
        l1ll1l1l (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l11111111 = True
        for param in self._11ll1l1l:
            if not params.get(param.lower()):
                l11111111 = False
        return l11111111
class l11111ll1():
    def __init__(self, l11ll11l1):
        self.l1l1l11ll = l1l1l.l1ll1ll1()
        self.l11l111l1 = self.l1l1ll1l1()
        self.l1111llll = self.l11l1l1ll()
        self.l11ll11l1 = l11ll11l1
        self._1l1ll11l = [l1ll1l1l (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1ll1l1l (u"ࠤࡑࡳࡳ࡫ࠢख"), l1ll1l1l (u"ࠥࡅࡱࡲࠢग"), l1ll1l1l (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1ll1l1l (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1ll1l1l (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1ll1l1l (u"ࠢࡊࡇࠥछ"), l1ll1l1l (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._11lllll1 = [l1ll1l1l (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1ll1l1l (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1ll1l1l (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1ll1l1l (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1l11llll = None
    def l1l1ll1l1(self):
        l111l1l1l = l1ll1l1l (u"ࠨࡎࡰࡰࡨࠦड")
        return l111l1l1l
    def l11l1l1ll(self):
        l111ll111 = 0
        return l111ll111
    def l11l11111(self):
        l11lllll = l1ll1l1l (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1111llll)
        l11lllll += l1ll1l1l (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1ll1111l(l1l1l111, l11lllll, t=1)
        return res
    def run(self):
        l1l1l1ll1 = True
        self._1l1l1l1l()
        result = []
        try:
            for cookie in l11ll1l11(l111ll1l=self.l11ll11l1.cookies).run():
                result.append(cookie)
        except l1llll11l as e:
            logger.exception(l1ll1l1l (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11lll1l1 = self._1111l111(result)
            if l11lll1l1:
                logger.info(l1ll1l1l (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11lll1l1)
                self.l1l11llll = l11lll1l1
            else:
                logger.info(l1ll1l1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11lll1l1)
            l1l1l1ll1 = True
        else:
            l1l1l1ll1 = False
        return l1l1l1ll1
    def _1111l111(self, l11l11l11):
        res = False
        l11ll1l = os.path.join(os.environ[l1ll1l1l (u"ࠬࡎࡏࡎࡇࠪध")], l1ll1l1l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1ll1l1l (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l1ll1llll = {}
        for cookies in l11l11l11:
            l1ll1llll[cookies.name] = cookies.value
        l11ll111l = l1ll1l1l (u"ࠣࠤप")
        for key in list(l1ll1llll.keys()):
            l11ll111l += l1ll1l1l (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l1ll1llll[key].strip())
        if not os.path.exists(os.path.dirname(l11ll1l)):
            os.makedirs(os.path.dirname(l11ll1l))
        vers = int(l1ll1l1l (u"ࠥࠦब").join(self.l1l1l11ll.split(l1ll1l1l (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11lll111 = [l1ll1l1l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1ll1l1l (u"ࠨࠣࠡࠤय") + l1ll1l1l (u"ࠢ࠮ࠤर") * 60,
                              l1ll1l1l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1ll1l1l (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1ll1l1l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11ll111l),
                              l1ll1l1l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11lll111 = [l1ll1l1l (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1ll1l1l (u"ࠨࠣࠡࠤश") + l1ll1l1l (u"ࠢ࠮ࠤष") * 60,
                              l1ll1l1l (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1ll1l1l (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1ll1l1l (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11ll111l),
                              l1ll1l1l (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l11ll1l, l1ll1l1l (u"ࠧࡽ़ࠢ")) as l1ll11ll1:
            data = l1ll1l1l (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11lll111)
            l1ll11ll1.write(data)
            l1ll11ll1.write(l1ll1l1l (u"ࠢ࡝ࡰࠥा"))
        res = l11ll1l
        return res
    def _1l1l1l1l(self):
        self._1l11l1l1(l1ll1l1l (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._11lll11l()
    def _1l11l1l1(self, l111lll1l):
        l11ll1ll1 = self.l11ll11l1.dict[l111lll1l.lower()]
        if l11ll1ll1:
            if isinstance(l11ll1ll1, list):
                l1l1lll11 = l11ll1ll1
            else:
                l1l1lll11 = [l11ll1ll1]
            if l1ll1l1l (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l111lll1l.lower():
                    for l11llllll in l1l1lll11:
                        l1l111l1l = [l1ll11lll.upper() for l1ll11lll in self._1l1ll11l]
                        if not l11llllll.upper() in l1l111l1l:
                            l1111lll1 = l1ll1l1l (u"ࠥ࠰ࠥࠨु").join(self._1l1ll11l)
                            l11111lll = l1ll1l1l (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l111lll1l, l11ll1ll1, l1111lll1, )
                            raise l11111ll(l11111lll)
    def _11lll11l(self):
        l1llllllll = []
        l1l1ll1ll = self.l11ll11l1.l11l11lll
        for l1l1l1lll in self._1l1ll11l:
            if not l1l1l1lll in [l1ll1l1l (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1ll1l1l (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1llllllll.append(l1l1l1lll)
        for l1ll1ll1l in self.l11ll11l1.l1ll111l1:
            if l1ll1ll1l in l1llllllll and not l1l1ll1ll:
                l11111lll = l1ll1l1l (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l11111ll(l11111lll)
def l1l11lll1(title, message, l111l11l1, l111lll11=None):
    l1111111l = l1l11ll11()
    l1111111l.l1l1l1l11(message, title, l111l11l1, l111lll11)
def l11ll1111(title, message, l111l11l1):
    l1111l1l1 = l1l111l11()
    l1111l1l1.l11l11l1l(title, message, l111l11l1)
    res = l1111l1l1.result
    return res
def main():
    try:
        logger.info(l1ll1l1l (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l1llll)
        system.l11l111ll()
        logger.info(l1ll1l1l (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1lll11ll(
                l1ll1l1l (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1ll1lll1 = l1ll111ll()
        l1ll1lll1.l111111l1(l1ll1l1l (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1ll1ll11 = [item.upper() for item in l1ll1lll1.l1ll111l1]
        l1l1111ll = l1ll1l1l (u"ࠧࡔࡏࡏࡇࠥॊ") in l1ll1ll11
        if l1l1111ll:
            logger.info(l1ll1l1l (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l111ll11l = l1ll1lll1.l111l1lll
            for l1ll11l1 in l111ll11l:
                logger.debug(l1ll1l1l (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1ll11l1))
                opener = l111l(l1ll1lll1.l1l111ll1, l1ll11l1, l11ll1l=None, l111ll1=l1l1llll)
                opener.open()
                logger.info(l1ll1l1l (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l1ll11l1l = l11111ll1(l1ll1lll1)
            l1l11ll1l = l1ll11l1l.run()
            l111ll11l = l1ll1lll1.l111l1lll
            for l1ll11l1 in l111ll11l:
                logger.info(l1ll1l1l (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1ll11l1))
                opener = l111l(l1ll1lll1.l1l111ll1, l1ll11l1, l11ll1l=l1ll11l1l.l1l11llll,
                                l111ll1=l1l1llll)
                opener.open()
                logger.info(l1ll1l1l (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11 as e:
        title = l1ll1l1l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l1111ll11 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1111ll11 = el
        l1111ll1l = l1ll1l1l (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l111ll, message.strip())
        l1l11lll1(title, l1111ll1l, l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l111lll11=l1111ll11)
        sys.exit(2)
    except l1111l11 as e:
        title = l1ll1l1l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l1111ll11 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1111ll11 = el
        l1111ll1l = l1ll1l1l (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1l11lll1(title, l1111ll1l, l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1ll1l1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l111lll11=l1111ll11)
        sys.exit(2)
    except l1lll11ll as e:
        title = l1ll1l1l (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1l11lll1(title, str(e), l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1ll1l1l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1l1l (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1l11lll1(title, l1ll1l1l (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1ll1l1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l11111ll as e:
        title = l1ll1l1l (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1l11lll1(title, l1ll1l1l (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1ll1l1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lllll1l as e:
        title = l1ll1l1l (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1l11lll1(title, l1ll1l1l (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1ll1l1l (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll1l:
        logger.info(l1ll1l1l (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1l1l (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1l111
        logger.exception(l1ll1l1l (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1l11lll1(title, l1ll1l1l (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l111l11l1=l1l1llll.get_value(l1ll1l1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1ll1l1l (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1l1l (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()