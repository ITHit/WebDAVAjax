#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l1 = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1l1l = 7
def l1ll1 (l11l1l1):
    global l1lll11
    l111l11 = ord (l11l1l1 [-1])
    l1111l1 = l11l1l1 [:-1]
    l1l1ll = l111l11 % len (l1111l1)
    l1l1l1 = l1111l1 [:l1l1ll] + l1111l1 [l1l1ll:]
    if l1lll1l1:
        l1111l = l11ll11 () .join ([unichr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    return eval (l1111l)
import sys, json
import os
import urllib
import l1ll11l
from l1lll1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1lll1 import l11lllll, logger, l1ll111l
from cookies import l111lll1 as l1l1ll1l1
from l111l1l import l111l
l1l1l1111 = None
from l1ll1lll import *
class l1ll1ll11():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll1 (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1111111l):
        self.config = l1111111l
        self.l11l1l1l1 = l1ll11l.l11()
    def l11llll1l(self):
        data = platform.uname()
        logger.info(l1ll1 (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1ll1 (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1ll1 (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1ll1 (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1ll11ll1():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l11llll = [l1ll1 (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l1l111111 = None
        self.l1ll1l1ll = None
        self.l11ll1lll = None
        self.l111111ll = None
        self.l1lll1ll = None
        self.l11111ll1 = None
        self.l1111l11l = None
        self.l1ll11111 = None
        self.cookies = None
    def l111lll11(self, url):
        l1ll1 (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1ll1 (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._1l111lll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l11l1ll(url)
        self.dict = self._1l1l1l1l(params)
        logger.info(l1ll1 (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l1l1111l1(self.dict):
            raise l1llll111(l1ll1 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._1l11llll)
        self._111ll1ll(self.dict)
        if self._encode:
            self.l11ll111l()
        self._1l1l1l11()
        self._1lll111l()
        self._1l11l1l1()
        self._1l111l11()
        self.l1ll11lll()
        logger.info(l1ll1 (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1ll1 (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l1l111111))
        logger.info(l1ll1 (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l1ll1l1ll))
        logger.info(l1ll1 (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l11ll1lll))
        logger.info(l1ll1 (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l111111ll))
        logger.info(l1ll1 (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l1lll1ll))
        logger.info(l1ll1 (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l11111ll1))
        logger.info(l1ll1 (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l1111l11l))
        logger.info(l1ll1 (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l1ll11111))
    def _111ll1ll(self, l1111l1l1):
        self.l1l111111 = l1111l1l1.get(l1ll1 (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l1ll1l1ll = l1111l1l1.get(l1ll1 (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1ll1 (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l11ll1lll = l1111l1l1.get(l1ll1 (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l111111ll = l1111l1l1.get(l1ll1 (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l1lll1ll = l1111l1l1.get(l1ll1 (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l11111ll1 = l1111l1l1.get(l1ll1 (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l1111l11l = l1111l1l1.get(l1ll1 (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1ll1 (u"ࠨࠢ࣍"))
        self.l1ll11111 = l1111l1l1.get(l1ll1 (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1ll1 (u"ࠣࠤ࣏"))
        self.cookies = l1111l1l1.get(l1ll1 (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l1ll11lll(self):
        l11l1l1ll = False
        if self.l1lll1ll:
            if self.l1lll1ll.upper() == l1ll1 (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l1lll1ll = l1ll1 (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l1lll1ll.upper() == l1ll1 (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l1lll1ll = l1ll1 (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l1lll1ll.upper() == l1ll1 (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l1lll1ll = l1ll1 (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l1lll1ll.upper() == l1ll1 (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l1lll1ll = l1ll1 (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l1lll1ll == l1ll1 (u"ࠦࠧࣙ"):
                l11l1l1ll = True
            else:
                self.l1lll1ll = self.l1lll1ll.lower()
        else:
            l11l1l1ll = True
        if l11l1l1ll:
            self.l1lll1ll = l1ll1 (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l11ll111l(self):
        l1ll1 (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll1 (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l111l1l11 = []
                    for el in self.__dict__.get(key):
                        l111l1l11.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l111l1l11
    def l1ll111l1(self, l111l1lll):
        res = l111l1lll
        if self._encode:
            res = urllib.parse.quote(l111l1lll, safe=l1ll1 (u"ࠣࠤࣝ"))
        return res
    def _1l111lll(self, url):
        l1ll1 (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1ll1 (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1ll1 (u"ࠦ࠿ࠨ࣠")), l1ll1 (u"ࠬ࠭࣡"), url)
        return url
    def _1l11l1ll(self, url):
        l1ll1 (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l1l11lll1 = url.split(l1ll1 (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1ll1 (u"ࠣ࠽ࠥࣤ")))
        result = l1l11lll1
        if len(result) == 0:
            raise l11111l1(l1ll1 (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _1l1l1l1l(self, params):
        l1ll1 (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1ll1 (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1ll1 (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11lllll1 = data.group(l1ll1 (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l11lllll1 in (l1ll1 (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1ll1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1ll1 (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1ll1 (u"ࠥ࠰࣭ࠧ"))
                elif l11lllll1 == l1ll1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1ll1 (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll1 (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l11lllll1] = value
        return result
    def _11111lll(self, url, scheme):
        l1ll1 (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l11lll111 = {l1ll1 (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1ll1 (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l111ll11l = url.split(l1ll1 (u"ࠥ࠾ࠧࣴ"))
        if len(l111ll11l) == 1:
            for l1l1l1lll in list(l11lll111.keys()):
                if l1l1l1lll == scheme:
                    url += l1ll1 (u"ࠦ࠿ࠨࣵ") + str(l11lll111[l1l1l1lll])
                    break
        return url
    def _1l1l1l11(self):
        l1ll1 (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l111111ll:
            l1111l1ll = self.l111111ll[0]
            l1l1l11l1 = urlparse(l1111l1ll)
        if self.l1l111111:
            l11l1lll1 = urlparse(self.l1l111111)
            if l11l1lll1.scheme:
                l111ll1l1 = l11l1lll1.scheme
            else:
                if l1l1l11l1.scheme:
                    l111ll1l1 = l1l1l11l1.scheme
                else:
                    raise l1111111(
                        l1ll1 (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l11l1lll1.netloc:
                l1l1ll1ll = l11l1lll1.netloc
            else:
                if l1l1l11l1.netloc:
                    l1l1ll1ll = l1l1l11l1.netloc
                else:
                    raise l1111111(
                        l1ll1 (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l1l1ll1ll = self._11111lll(l1l1ll1ll, l111ll1l1)
            path = l11l1lll1.path
            if not path.endswith(l1ll1 (u"ࠨ࠱ࣹࠪ")):
                path += l1ll1 (u"ࠩ࠲ࣺࠫ")
            l1ll1111l = ParseResult(scheme=l111ll1l1, netloc=l1l1ll1ll, path=path,
                                         params=l11l1lll1.params, query=l11l1lll1.query,
                                         fragment=l11l1lll1.fragment)
            self.l1l111111 = l1ll1111l.geturl()
        else:
            if not l1l1l11l1.netloc:
                raise l1111111(l1ll1 (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l1111l111 = l1l1l11l1.path
            l11111l11 = l1ll1 (u"ࠦ࠴ࠨࣼ").join(l1111l111.split(l1ll1 (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1ll1 (u"ࠨ࠯ࠣࣾ")
            l1ll1111l = ParseResult(scheme=l1l1l11l1.scheme,
                                         netloc=self._11111lll(l1l1l11l1.netloc, l1l1l11l1.scheme),
                                         path=l11111l11,
                                         params=l1ll1 (u"ࠢࠣࣿ"),
                                         query=l1ll1 (u"ࠣࠤऀ"),
                                         fragment=l1ll1 (u"ࠤࠥँ")
                                         )
            self.l1l111111 = l1ll1111l.geturl()
    def _1l11l1l1(self):
        l1ll1 (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l111111ll:
            l1111l1ll = self.l111111ll[0]
            l1l1l11l1 = urlparse(l1111l1ll)
        if self.l11111ll1:
            l111111l1 = urlparse(self.l11111ll1)
            if l111111l1.scheme:
                l1111lll1 = l111111l1.scheme
            else:
                l1111lll1 = l1l1l11l1.scheme
            if l111111l1.netloc:
                l1l1111ll = l111111l1.netloc
            else:
                l1l1111ll = l1l1l11l1.netloc
            l111ll111 = ParseResult(scheme=l1111lll1, netloc=l1l1111ll, path=l111111l1.path,
                                      params=l111111l1.params, query=l111111l1.query,
                                      fragment=l111111l1.fragment)
            self.l11111ll1 = l111ll111.geturl()
    def _1lll111l(self):
        l1ll1 (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l111111ll
        self.l111111ll = []
        for item in items:
            l1ll1ll1l = urlparse(item.strip(), scheme=l1ll1 (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l1ll1ll1l.path[-1] == l1ll1 (u"ࠨ࠯ࠣअ"):
                l1ll1l1l1 = l1ll1ll1l.path
            else:
                path_list = l1ll1ll1l.path.split(l1ll1 (u"ࠢ࠰ࠤआ"))
                l1ll1l1l1 = l1ll1 (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1ll1 (u"ࠤ࠲ࠦई")
            l1l11111l = urlparse(self.l1l111111, scheme=l1ll1 (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l1ll1ll1l.scheme:
                scheme = l1ll1ll1l.scheme
            elif l1l11111l.scheme:
                scheme = l1l11111l.scheme
            else:
                scheme = l1ll1 (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l1ll1ll1l.netloc and not l1l11111l.netloc:
                l111lllll = l1ll1ll1l.netloc
            elif not l1ll1ll1l.netloc and l1l11111l.netloc:
                l111lllll = l1l11111l.netloc
            elif not l1ll1ll1l.netloc and not l1l11111l.netloc and len(self.l111111ll) > 0:
                l1lll1l11 = urlparse(self.l111111ll[len(self.l111111ll) - 1])
                l111lllll = l1lll1l11.netloc
            elif l1l11111l.netloc:
                l111lllll = l1ll1ll1l.netloc
            elif not l1l11111l.netloc:
                l111lllll = l1ll1ll1l.netloc
            if l1ll1ll1l.path:
                l1ll11l11 = l1ll1ll1l.path
            if l111lllll:
                l111lllll = self._11111lll(l111lllll, scheme)
                l11l1ll11 = ParseResult(scheme=scheme, netloc=l111lllll, path=l1ll11l11,
                                          params=l1ll1ll1l.params,
                                          query=l1ll1ll1l.query,
                                          fragment=l1ll1ll1l.fragment)
                self.l111111ll.append(l11l1ll11.geturl())
    def _1l111l11(self):
        l1ll1 (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l111llll1 = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1ll1(l1ll1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l111llll1)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1ll1(l1ll1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l11ll1lll:
            l1l11l11l = []
            for l1l11ll11 in self.l11ll1lll:
                if l1l11ll11 not in [x[l1ll1 (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l1l11l11l.append(l1l11ll11)
            if l1l11l11l:
                l1l11l1l = l1ll1 (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1ll1 (u"ࠥ࠰ࠥࠨऐ").join(l1l11l11l))
                raise l11l1ll1(l1ll1 (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1l11l1l)
    def l1l1111l1(self, params):
        l1ll1 (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1l1lll11 = True
        for param in self._1l11llll:
            if not params.get(param.lower()):
                l1l1lll11 = False
        return l1l1lll11
class l1l1l11ll():
    def __init__(self, l11l11l11):
        self.l11ll1l1l = l1ll11l.l11()
        self.l1lll11ll = self.l1l1ll111()
        self.l11l111ll = self.l11ll11ll()
        self.l11l11l11 = l11l11l11
        self._111l1111 = [l1ll1 (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1ll1 (u"ࠢࡏࡱࡱࡩࠧऔ"), l1ll1 (u"ࠣࡃ࡯ࡰࠧक"), l1ll1 (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1ll1 (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1ll1 (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1ll1 (u"ࠧࡏࡅࠣङ"), l1ll1 (u"ࠨࡅࡥࡩࡨࠦच")]
        self._11l11111 = [l1ll1 (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1ll1 (u"ࠣࡇࡧ࡭ࡹࠨज"), l1ll1 (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1ll1 (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l11l1l11l = None
    def l1l1ll111(self):
        l1l1l111l = l1ll1 (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l1l1l111l
    def l11ll11ll(self):
        l111l111l = 0
        return l111l111l
    def l1l111l1l(self):
        l1l11l1l = l1ll1 (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l11l111ll)
        l1l11l1l += l1ll1 (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l11ll1ll1(l11lllll, l1l11l1l, t=1)
        return res
    def run(self):
        l111l1l1l = True
        self._11ll11l1()
        result = []
        try:
            for cookie in l1l1ll1l1(l11l11ll=self.l11l11l11.cookies).run():
                result.append(cookie)
        except l1lll1lll as e:
            logger.exception(l1ll1 (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l11l111l1 = self._11ll1l11(result)
            if l11l111l1:
                logger.info(l1ll1 (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l11l111l1)
                self.l11l1l11l = l11l111l1
            else:
                logger.info(l1ll1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l11l111l1)
            l111l1l1l = True
        else:
            l111l1l1l = False
        return l111l1l1l
    def _11ll1l11(self, l1l1lll1l):
        res = False
        l1lllll = os.path.join(os.environ[l1ll1 (u"ࠪࡌࡔࡓࡅࠨथ")], l1ll1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1ll1 (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1l1llll1 = {}
        for cookies in l1l1lll1l:
            l1l1llll1[cookies.name] = cookies.value
        l11ll1111 = l1ll1 (u"ࠨࠢन")
        for key in list(l1l1llll1.keys()):
            l11ll1111 += l1ll1 (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1l1llll1[key].strip())
        if not os.path.exists(os.path.dirname(l1lllll)):
            os.makedirs(os.path.dirname(l1lllll))
        vers = int(l1ll1 (u"ࠣࠤप").join(self.l11ll1l1l.split(l1ll1 (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l1ll1lll1 = [l1ll1 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1ll1 (u"ࠦࠨࠦࠢभ") + l1ll1 (u"ࠧ࠳ࠢम") * 60,
                              l1ll1 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1ll1 (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1ll1 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l11ll1111),
                              l1ll1 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l1ll1lll1 = [l1ll1 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1ll1 (u"ࠦࠨࠦࠢऴ") + l1ll1 (u"ࠧ࠳ࠢव") * 60,
                              l1ll1 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1ll1 (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1ll1 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l11ll1111),
                              l1ll1 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1lllll, l1ll1 (u"ࠥࡻࠧऺ")) as l1111ll11:
            data = l1ll1 (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l1ll1lll1)
            l1111ll11.write(data)
            l1111ll11.write(l1ll1 (u"ࠧࡢ࡮़ࠣ"))
        res = l1lllll
        return res
    def _11ll11l1(self):
        self._11l11l1l(l1ll1 (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._11lll11l()
    def _11l11l1l(self, l1111llll):
        l11l1111l = self.l11l11l11.dict[l1111llll.lower()]
        if l11l1111l:
            if isinstance(l11l1111l, list):
                l1ll1llll = l11l1111l
            else:
                l1ll1llll = [l11l1111l]
            if l1ll1 (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l1111llll.lower():
                    for l1111ll1l in l1ll1llll:
                        l11111l1l = [l1ll11l1l.upper() for l1ll11l1l in self._111l1111]
                        if not l1111ll1l.upper() in l11111l1l:
                            l1l1l1ll1 = l1ll1 (u"ࠣ࠮ࠣࠦि").join(self._111l1111)
                            l11l11lll = l1ll1 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l1111llll, l11l1111l, l1l1l1ll1, )
                            raise l1111l1l(l11l11lll)
    def _11lll11l(self):
        l1lll1111 = []
        l111l1ll1 = self.l11l11l11.l11ll1lll
        for l11l11ll1 in self._111l1111:
            if not l11l11ll1 in [l1ll1 (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1ll1 (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l1lll1111.append(l11l11ll1)
        for l11lll1l1 in self.l11l11l11.l1ll1l1ll:
            if l11lll1l1 in l1lll1111 and not l111l1ll1:
                l11l11lll = l1ll1 (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1111l1l(l11l11lll)
def l11lll1ll(title, message, l1lll11l1, l1l11ll1l=None):
    l1ll1l11l = l11l1l111()
    l1ll1l11l.l111lll1l(message, title, l1lll11l1, l1l11ll1l)
def l1l1ll11l(title, message, l1lll11l1):
    l1l1lllll = l111l11ll()
    l1l1lllll.l11l1ll1l(title, message, l1lll11l1)
    res = l1l1lllll.result
    return res
def main():
    try:
        logger.info(l1ll1 (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l1ll111l)
        system.l11llll1l()
        logger.info(l1ll1 (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1llll111(
                l1ll1 (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l1l11l111 = l1ll11ll1()
        l1l11l111.l111lll11(l1ll1 (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l111l11l1 = [item.upper() for item in l1l11l111.l1ll1l1ll]
        l1ll111ll = l1ll1 (u"ࠥࡒࡔࡔࡅࠣै") in l111l11l1
        if l1ll111ll:
            logger.info(l1ll1 (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l11llllll = l1l11l111.l111111ll
            for l1ll1ll in l11llllll:
                logger.debug(l1ll1 (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l1ll1ll))
                opener = l111l(l1l11l111.l1l111111, l1ll1ll, l1lllll=None, l1l=l1ll111l)
                opener.open()
                logger.info(l1ll1 (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l11llll11 = l1l1l11ll(l1l11l111)
            l1l111ll1 = l11llll11.run()
            l11llllll = l1l11l111.l111111ll
            for l1ll1ll in l11llllll:
                logger.info(l1ll1 (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l1ll1ll))
                opener = l111l(l1l11l111.l1l111111, l1ll1ll, l1lllll=l11llll11.l11l1l11l,
                                l1l=l1ll111l)
                opener.open()
                logger.info(l1ll1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1111 as e:
        title = l1ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l11lllll
        logger.exception(l1ll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l11l1llll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1llll = el
        l1ll1l111 = l1ll1 (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l1111ll, message.strip())
        l11lll1ll(title, l1ll1l111, l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l1l11ll1l=l11l1llll)
        sys.exit(2)
    except l11111ll as e:
        title = l1ll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l11lllll
        logger.exception(l1ll1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l11l1llll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1llll = el
        l1ll1l111 = l1ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l11lll1ll(title, l1ll1l111, l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1ll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l1l11ll1l=l11l1llll)
        sys.exit(2)
    except l1llll111 as e:
        title = l1ll1 (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l11lllll
        logger.exception(l1ll1 (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l11lll1ll(title, str(e), l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1ll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l11lllll
        logger.exception(l1ll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l11lll1ll(title, l1ll1 (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1111l1l as e:
        title = l1ll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l11lllll
        logger.exception(l1ll1 (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l11lll1ll(title, l1ll1 (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1ll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1lllll1l as e:
        title = l1ll1 (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l11lllll
        logger.exception(l1ll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l11lll1ll(title, l1ll1 (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1ll1 (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1l111:
        logger.info(l1ll1 (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1ll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l11lllll
        logger.exception(l1ll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l11lll1ll(title, l1ll1 (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l1lll11l1=l1ll111l.get_value(l1ll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1ll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll1 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()