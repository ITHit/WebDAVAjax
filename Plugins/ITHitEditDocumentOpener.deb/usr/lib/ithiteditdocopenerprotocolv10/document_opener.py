#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import sys, json
import os
import urllib
import l1lll111
from l11ll1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l11111 import l1l1ll1l, logger, l1l1l1ll
from cookies import l111l1ll as l1ll11111
from l1l1 import l1111ll
l11l11l1l = None
from l1111l import *
class l1ll111ll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l11llll (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1ll1ll11):
        self.config = l1ll1ll11
        self.l1lll11ll = l1lll111.l1lll1ll()
    def l11ll1lll(self):
        data = platform.uname()
        logger.info(l11llll (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l11llll (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l11llll (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l11llll (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1ll1l1ll():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l111lll = [l11llll (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l1l11111l = None
        self.l1l111ll1 = None
        self.l1l1l111l = None
        self.l1ll1l111 = None
        self.l111l = None
        self.l1111l111 = None
        self.l1111l11l = None
        self.l111ll11l = None
        self.cookies = None
    def l111l11ll(self, url):
        l11llll (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l11llll (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._1l1l11l1(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1ll11lll(url)
        self.dict = self._111111l1(params)
        logger.info(l11llll (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l111l1lll(self.dict):
            raise l1111l1l(l11llll (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._1l111lll)
        self._1ll1111l(self.dict)
        if self._encode:
            self.l11lll1ll()
        self._1ll1l1l1()
        self._111ll111()
        self._11ll1111()
        self._1l11llll()
        self.l1l1ll1l1()
        logger.info(l11llll (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l11llll (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l1l11111l))
        logger.info(l11llll (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l1l111ll1))
        logger.info(l11llll (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l1l1l111l))
        logger.info(l11llll (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l1ll1l111))
        logger.info(l11llll (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l111l))
        logger.info(l11llll (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l1111l111))
        logger.info(l11llll (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l1111l11l))
        logger.info(l11llll (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l111ll11l))
    def _1ll1111l(self, l11l1ll1l):
        self.l1l11111l = l11l1ll1l.get(l11llll (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l1l111ll1 = l11l1ll1l.get(l11llll (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l11llll (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l1l1l111l = l11l1ll1l.get(l11llll (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l1ll1l111 = l11l1ll1l.get(l11llll (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l111l = l11l1ll1l.get(l11llll (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l1111l111 = l11l1ll1l.get(l11llll (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l1111l11l = l11l1ll1l.get(l11llll (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l11llll (u"ࠨࠢ࣍"))
        self.l111ll11l = l11l1ll1l.get(l11llll (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l11llll (u"ࠣࠤ࣏"))
        self.cookies = l11l1ll1l.get(l11llll (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l1l1ll1l1(self):
        l1l11l1ll = False
        if self.l111l:
            if self.l111l.upper() == l11llll (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l111l = l11llll (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l111l.upper() == l11llll (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l111l = l11llll (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l111l.upper() == l11llll (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l111l = l11llll (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l111l.upper() == l11llll (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l111l = l11llll (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l111l == l11llll (u"ࠦࠧࣙ"):
                l1l11l1ll = True
            else:
                self.l111l = self.l111l.lower()
        else:
            l1l11l1ll = True
        if l1l11l1ll:
            self.l111l = l11llll (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l11lll1ll(self):
        l11llll (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l11llll (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l111111 = []
                    for el in self.__dict__.get(key):
                        l1l111111.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l111111
    def l111ll1l1(self, l111llll1):
        res = l111llll1
        if self._encode:
            res = urllib.parse.quote(l111llll1, safe=l11llll (u"ࠣࠤࣝ"))
        return res
    def _1l1l11l1(self, url):
        l11llll (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l11llll (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l11llll (u"ࠦ࠿ࠨ࣠")), l11llll (u"ࠬ࠭࣡"), url)
        return url
    def _1ll11lll(self, url):
        l11llll (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l111l1ll1 = url.split(l11llll (u"ࠢࡼ࠲ࢀࣣࠦ").format(l11llll (u"ࠣ࠽ࠥࣤ")))
        result = l111l1ll1
        if len(result) == 0:
            raise l11111ll(l11llll (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _111111l1(self, params):
        l11llll (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l11llll (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l11llll (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l1l1l1l = data.group(l11llll (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l1l1l1l1l in (l11llll (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l11llll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l11llll (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l11llll (u"ࠥ࠰࣭ࠧ"))
                elif l1l1l1l1l == l11llll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l11llll (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l11llll (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l1l1l1l1l] = value
        return result
    def _11lllll1(self, url, scheme):
        l11llll (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l1l1llll1 = {l11llll (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l11llll (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l1l1l11ll = url.split(l11llll (u"ࠥ࠾ࠧࣴ"))
        if len(l1l1l11ll) == 1:
            for l11llllll in list(l1l1llll1.keys()):
                if l11llllll == scheme:
                    url += l11llll (u"ࠦ࠿ࠨࣵ") + str(l1l1llll1[l11llllll])
                    break
        return url
    def _1ll1l1l1(self):
        l11llll (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l1ll1l111:
            l11l1lll1 = self.l1ll1l111[0]
            l1ll11l1l = urlparse(l11l1lll1)
        if self.l1l11111l:
            l11111l1l = urlparse(self.l1l11111l)
            if l11111l1l.scheme:
                l11l111l1 = l11111l1l.scheme
            else:
                if l1ll11l1l.scheme:
                    l11l111l1 = l1ll11l1l.scheme
                else:
                    raise l111111l(
                        l11llll (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l11111l1l.netloc:
                l11l1111l = l11111l1l.netloc
            else:
                if l1ll11l1l.netloc:
                    l11l1111l = l1ll11l1l.netloc
                else:
                    raise l111111l(
                        l11llll (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l11l1111l = self._11lllll1(l11l1111l, l11l111l1)
            path = l11111l1l.path
            if not path.endswith(l11llll (u"ࠨ࠱ࣹࠪ")):
                path += l11llll (u"ࠩ࠲ࣺࠫ")
            l1111l1l1 = ParseResult(scheme=l11l111l1, netloc=l11l1111l, path=path,
                                         params=l11111l1l.params, query=l11111l1l.query,
                                         fragment=l11111l1l.fragment)
            self.l1l11111l = l1111l1l1.geturl()
        else:
            if not l1ll11l1l.netloc:
                raise l111111l(l11llll (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l1111lll1 = l1ll11l1l.path
            l1111l1ll = l11llll (u"ࠦ࠴ࠨࣼ").join(l1111lll1.split(l11llll (u"ࠧ࠵ࠢࣽ"))[:-1]) + l11llll (u"ࠨ࠯ࠣࣾ")
            l1111l1l1 = ParseResult(scheme=l1ll11l1l.scheme,
                                         netloc=self._11lllll1(l1ll11l1l.netloc, l1ll11l1l.scheme),
                                         path=l1111l1ll,
                                         params=l11llll (u"ࠢࠣࣿ"),
                                         query=l11llll (u"ࠣࠤऀ"),
                                         fragment=l11llll (u"ࠤࠥँ")
                                         )
            self.l1l11111l = l1111l1l1.geturl()
    def _11ll1111(self):
        l11llll (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l1ll1l111:
            l11l1lll1 = self.l1ll1l111[0]
            l1ll11l1l = urlparse(l11l1lll1)
        if self.l1111l111:
            l11lll1l1 = urlparse(self.l1111l111)
            if l11lll1l1.scheme:
                l1ll1l11l = l11lll1l1.scheme
            else:
                l1ll1l11l = l1ll11l1l.scheme
            if l11lll1l1.netloc:
                l11l1l111 = l11lll1l1.netloc
            else:
                l11l1l111 = l1ll11l1l.netloc
            l11ll11l1 = ParseResult(scheme=l1ll1l11l, netloc=l11l1l111, path=l11lll1l1.path,
                                      params=l11lll1l1.params, query=l11lll1l1.query,
                                      fragment=l11lll1l1.fragment)
            self.l1111l111 = l11ll11l1.geturl()
    def _111ll111(self):
        l11llll (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l1ll1l111
        self.l1ll1l111 = []
        for item in items:
            l11l11l11 = urlparse(item.strip(), scheme=l11llll (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l11l11l11.path[-1] == l11llll (u"ࠨ࠯ࠣअ"):
                l111l1l1l = l11l11l11.path
            else:
                path_list = l11l11l11.path.split(l11llll (u"ࠢ࠰ࠤआ"))
                l111l1l1l = l11llll (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l11llll (u"ࠤ࠲ࠦई")
            l1l1ll11l = urlparse(self.l1l11111l, scheme=l11llll (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l11l11l11.scheme:
                scheme = l11l11l11.scheme
            elif l1l1ll11l.scheme:
                scheme = l1l1ll11l.scheme
            else:
                scheme = l11llll (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l11l11l11.netloc and not l1l1ll11l.netloc:
                l11l11lll = l11l11l11.netloc
            elif not l11l11l11.netloc and l1l1ll11l.netloc:
                l11l11lll = l1l1ll11l.netloc
            elif not l11l11l11.netloc and not l1l1ll11l.netloc and len(self.l1ll1l111) > 0:
                l1l1lllll = urlparse(self.l1ll1l111[len(self.l1ll1l111) - 1])
                l11l11lll = l1l1lllll.netloc
            elif l1l1ll11l.netloc:
                l11l11lll = l11l11l11.netloc
            elif not l1l1ll11l.netloc:
                l11l11lll = l11l11l11.netloc
            if l11l11l11.path:
                l111lll1l = l11l11l11.path
            if l11l11lll:
                l11l11lll = self._11lllll1(l11l11lll, scheme)
                l1l1l1lll = ParseResult(scheme=scheme, netloc=l11l11lll, path=l111lll1l,
                                          params=l11l11l11.params,
                                          query=l11l11l11.query,
                                          fragment=l11l11l11.fragment)
                self.l1ll1l111.append(l1l1l1lll.geturl())
    def _1l11llll(self):
        l11llll (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l1lll111l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l11llll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l1lll111l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l11llll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l1l1l111l:
            l1ll111l1 = []
            for l1l11lll1 in self.l1l1l111l:
                if l1l11lll1 not in [x[l11llll (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l1ll111l1.append(l1l11lll1)
            if l1ll111l1:
                l1l1ll11 = l11llll (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l11llll (u"ࠥ࠰ࠥࠨऐ").join(l1ll111l1))
                raise l111l111(l11llll (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1l1ll11)
    def l111l1lll(self, params):
        l11llll (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1l1111l1 = True
        for param in self._1l111lll:
            if not params.get(param.lower()):
                l1l1111l1 = False
        return l1l1111l1
class l1111llll():
    def __init__(self, l1l1l1l11):
        self.l111l11l1 = l1lll111.l1lll1ll()
        self.l11l1ll11 = self.l1l1ll111()
        self.l11111lll = self.l11ll1ll1()
        self.l1l1l1l11 = l1l1l1l11
        self._1lll11l1 = [l11llll (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l11llll (u"ࠢࡏࡱࡱࡩࠧऔ"), l11llll (u"ࠣࡃ࡯ࡰࠧक"), l11llll (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l11llll (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l11llll (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l11llll (u"ࠧࡏࡅࠣङ"), l11llll (u"ࠨࡅࡥࡩࡨࠦच")]
        self._11llll1l = [l11llll (u"ࠢࡗ࡫ࡨࡻࠧछ"), l11llll (u"ࠣࡇࡧ࡭ࡹࠨज"), l11llll (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l11llll (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l1l11ll11 = None
    def l1l1ll111(self):
        l1l1l1ll1 = l11llll (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l1l1l1ll1
    def l11ll1ll1(self):
        l1ll11ll1 = 0
        return l1ll11ll1
    def l1l11l111(self):
        l1l1ll11 = l11llll (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l11111lll)
        l1l1ll11 += l11llll (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l1l111l11(l1l1ll1l, l1l1ll11, t=1)
        return res
    def run(self):
        l1111ll11 = True
        self._111111ll()
        result = []
        try:
            for cookie in l1ll11111(l11l1lll=self.l1l1l1l11.cookies).run():
                result.append(cookie)
        except l1lll1l1l as e:
            logger.exception(l11llll (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l11ll1l11 = self._11lll11l(result)
            if l11ll1l11:
                logger.info(l11llll (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l11ll1l11)
                self.l1l11ll11 = l11ll1l11
            else:
                logger.info(l11llll (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l11ll1l11)
            l1111ll11 = True
        else:
            l1111ll11 = False
        return l1111ll11
    def _11lll11l(self, l11lll111):
        res = False
        l1llllll = os.path.join(os.environ[l11llll (u"ࠪࡌࡔࡓࡅࠨथ")], l11llll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l11llll (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1l11ll1l = {}
        for cookies in l11lll111:
            l1l11ll1l[cookies.name] = cookies.value
        l11l11111 = l11llll (u"ࠨࠢन")
        for key in list(l1l11ll1l.keys()):
            l11l11111 += l11llll (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1l11ll1l[key].strip())
        if not os.path.exists(os.path.dirname(l1llllll)):
            os.makedirs(os.path.dirname(l1llllll))
        vers = int(l11llll (u"ࠣࠤप").join(self.l111l11l1.split(l11llll (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l1l111l1l = [l11llll (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l11llll (u"ࠦࠨࠦࠢभ") + l11llll (u"ࠧ࠳ࠢम") * 60,
                              l11llll (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l11llll (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l11llll (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l11l11111),
                              l11llll (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l1l111l1l = [l11llll (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l11llll (u"ࠦࠨࠦࠢऴ") + l11llll (u"ࠧ࠳ࠢव") * 60,
                              l11llll (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l11llll (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l11llll (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l11l11111),
                              l11llll (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1llllll, l11llll (u"ࠥࡻࠧऺ")) as l1ll1llll:
            data = l11llll (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l1l111l1l)
            l1ll1llll.write(data)
            l1ll1llll.write(l11llll (u"ࠧࡢ࡮़ࠣ"))
        res = l1llllll
        return res
    def _111111ll(self):
        self._111l111l(l11llll (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._1lll1111()
    def _111l111l(self, l1l1l1111):
        l11l11ll1 = self.l1l1l1l11.dict[l1l1l1111.lower()]
        if l11l11ll1:
            if isinstance(l11l11ll1, list):
                l1l1ll1ll = l11l11ll1
            else:
                l1l1ll1ll = [l11l11ll1]
            if l11llll (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l1l1l1111.lower():
                    for l11l1llll in l1l1ll1ll:
                        l11l1l11l = [l11111l11.upper() for l11111l11 in self._1lll11l1]
                        if not l11l1llll.upper() in l11l1l11l:
                            l1l11l1l1 = l11llll (u"ࠣ࠮ࠣࠦि").join(self._1lll11l1)
                            l1111ll1l = l11llll (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l1l1l1111, l11l11ll1, l1l11l1l1, )
                            raise l1111l11(l1111ll1l)
    def _1lll1111(self):
        l11llll11 = []
        l1l1lll1l = self.l1l1l1l11.l1l1l111l
        for l111lll11 in self._1lll11l1:
            if not l111lll11 in [l11llll (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l11llll (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l11llll11.append(l111lll11)
        for l11111ll1 in self.l1l1l1l11.l1l111ll1:
            if l11111ll1 in l11llll11 and not l1l1lll1l:
                l1111ll1l = l11llll (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1111l11(l1111ll1l)
def l1l1111ll(title, message, l111l1l11, l1111111l=None):
    l111ll1ll = l1l11l11l()
    l111ll1ll.l111lllll(message, title, l111l1l11, l1111111l)
def l11l1l1l1(title, message, l111l1l11):
    l11l111ll = l1ll1ll1l()
    l11l111ll.l1ll1lll1(title, message, l111l1l11)
    res = l11l111ll.result
    return res
def main():
    try:
        logger.info(l11llll (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l1l1l1ll)
        system.l11ll1lll()
        logger.info(l11llll (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1111l1l(
                l11llll (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l11ll1l1l = l1ll1l1ll()
        l11ll1l1l.l111l11ll(l11llll (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l1lll1l11 = [item.upper() for item in l11ll1l1l.l1l111ll1]
        l111l1111 = l11llll (u"ࠥࡒࡔࡔࡅࠣै") in l1lll1l11
        if l111l1111:
            logger.info(l11llll (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l1l1lll11 = l11ll1l1l.l1ll1l111
            for l11111 in l1l1lll11:
                logger.debug(l11llll (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l11111))
                opener = l1111ll(l11ll1l1l.l1l11111l, l11111, l1llllll=None, l1l1ll=l1l1l1ll)
                opener.open()
                logger.info(l11llll (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l11ll111l = l1111llll(l11ll1l1l)
            l11ll11ll = l11ll111l.run()
            l1l1lll11 = l11ll1l1l.l1ll1l111
            for l11111 in l1l1lll11:
                logger.info(l11llll (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l11111))
                opener = l1111ll(l11ll1l1l.l1l11111l, l11111, l1llllll=l11ll111l.l1l11ll11,
                                l1l1ll=l1l1l1ll)
                opener.open()
                logger.info(l11llll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1l1ll1 as e:
        title = l11llll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1l1ll1l
        logger.exception(l11llll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l11l1l1ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1l1ll = el
        l1ll11l11 = l11llll (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l1lllll, message.strip())
        l1l1111ll(title, l1ll11l11, l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l11llll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l1111111l=l11l1l1ll)
        sys.exit(2)
    except l1llll1ll as e:
        title = l11llll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1l1ll1l
        logger.exception(l11llll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l11l1l1ll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1l1ll = el
        l1ll11l11 = l11llll (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l1l1111ll(title, l1ll11l11, l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l11llll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l1111111l=l11l1l1ll)
        sys.exit(2)
    except l1111l1l as e:
        title = l11llll (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1l1ll1l
        logger.exception(l11llll (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l1l1111ll(title, str(e), l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l11llll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l11llll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1l1ll1l
        logger.exception(l11llll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l1l1111ll(title, l11llll (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l11llll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1111l11 as e:
        title = l11llll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1l1ll1l
        logger.exception(l11llll (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l1l1111ll(title, l11llll (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l11llll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1lllll11 as e:
        title = l11llll (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1l1ll1l
        logger.exception(l11llll (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l1l1111ll(title, l11llll (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l11llll (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1:
        logger.info(l11llll (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l11llll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1l1ll1l
        logger.exception(l11llll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l1l1111ll(title, l11llll (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l111l1l11=l1l1l1ll.get_value(l11llll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l11llll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l11llll (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()