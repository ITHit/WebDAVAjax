#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l1l1ll = 7
def l1ll11 (l1l1ll1):
    global l1llll1
    l111 = ord (l1l1ll1 [-1])
    l1ll11l = l1l1ll1 [:-1]
    l11l11l = l111 % len (l1ll11l)
    l1llll = l1ll11l [:l11l11l] + l1ll11l [l11l11l:]
    if l111l1:
        l1111l1 = l11111l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    return eval (l1111l1)
import sys, json
import os
import urllib
import l1l11
from l1111l import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l111l1 import l1l1ll11, logger, l1l1l1l1
from cookies import l11l1l11 as l11l1l1ll
from l1ll1ll1 import l1lll1l
l1ll1l1l1 = None
from l1ll1ll import *
class l1l11lll1():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll11 (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l111l1l1l):
        self.config = l111l1l1l
        self.l1l11ll1l = l1l11.l1llll1l()
    def l1lll11l1(self):
        data = platform.uname()
        logger.info(l1ll11 (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1ll11 (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1ll11 (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1ll11 (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1l111111():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l1lll11 = [l1ll11 (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l11l1111l = None
        self.l11llll1l = None
        self.l1l1lllll = None
        self.l1ll1l11l = None
        self.l1l111 = None
        self.l111l1ll1 = None
        self.l111ll1l1 = None
        self.l1l1l111l = None
        self.cookies = None
    def l1l1l11ll(self, url):
        l1ll11 (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1ll11 (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._1l11l111(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111lll11(url)
        self.dict = self._111lllll(params)
        logger.info(l1ll11 (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l1l1l1111(self.dict):
            raise l1lllll1l(l1ll11 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._1l1lll11)
        self._1ll1l111(self.dict)
        if self._encode:
            self.l111l1l11()
        self._11l1l11l()
        self._11ll11ll()
        self._1l1l1ll1()
        self._1ll1111l()
        self.l1l1lll1l()
        logger.info(l1ll11 (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1ll11 (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l11l1111l))
        logger.info(l1ll11 (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l11llll1l))
        logger.info(l1ll11 (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l1l1lllll))
        logger.info(l1ll11 (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l1ll1l11l))
        logger.info(l1ll11 (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l1l111))
        logger.info(l1ll11 (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l111l1ll1))
        logger.info(l1ll11 (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l111ll1l1))
        logger.info(l1ll11 (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l1l1l111l))
    def _1ll1l111(self, l1111ll11):
        self.l11l1111l = l1111ll11.get(l1ll11 (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l11llll1l = l1111ll11.get(l1ll11 (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1ll11 (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l1l1lllll = l1111ll11.get(l1ll11 (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l1ll1l11l = l1111ll11.get(l1ll11 (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l1l111 = l1111ll11.get(l1ll11 (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l111l1ll1 = l1111ll11.get(l1ll11 (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l111ll1l1 = l1111ll11.get(l1ll11 (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1ll11 (u"ࠨࠢ࣍"))
        self.l1l1l111l = l1111ll11.get(l1ll11 (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1ll11 (u"ࠣࠤ࣏"))
        self.cookies = l1111ll11.get(l1ll11 (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l1l1lll1l(self):
        l1ll1ll11 = False
        if self.l1l111:
            if self.l1l111.upper() == l1ll11 (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l1l111 = l1ll11 (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l1l111.upper() == l1ll11 (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l1l111 = l1ll11 (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l1l111.upper() == l1ll11 (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l1l111 = l1ll11 (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l1l111.upper() == l1ll11 (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l1l111 = l1ll11 (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l1l111 == l1ll11 (u"ࠦࠧࣙ"):
                l1ll1ll11 = True
            else:
                self.l1l111 = self.l1l111.lower()
        else:
            l1ll1ll11 = True
        if l1ll1ll11:
            self.l1l111 = l1ll11 (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l111l1l11(self):
        l1ll11 (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll11 (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1lll111l = []
                    for el in self.__dict__.get(key):
                        l1lll111l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1lll111l
    def l11ll111l(self, l11llllll):
        res = l11llllll
        if self._encode:
            res = urllib.parse.quote(l11llllll, safe=l1ll11 (u"ࠣࠤࣝ"))
        return res
    def _1l11l111(self, url):
        l1ll11 (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1ll11 (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1ll11 (u"ࠦ࠿ࠨ࣠")), l1ll11 (u"ࠬ࠭࣡"), url)
        return url
    def _111lll11(self, url):
        l1ll11 (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l11l1l111 = url.split(l1ll11 (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1ll11 (u"ࠣ࠽ࠥࣤ")))
        result = l11l1l111
        if len(result) == 0:
            raise l1llll1l1(l1ll11 (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _111lllll(self, params):
        l1ll11 (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1ll11 (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1ll11 (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1ll11l1l = data.group(l1ll11 (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l1ll11l1l in (l1ll11 (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1ll11 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1ll11 (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1ll11 (u"ࠥ࠰࣭ࠧ"))
                elif l1ll11l1l == l1ll11 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1ll11 (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll11 (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l1ll11l1l] = value
        return result
    def _1l11l11l(self, url, scheme):
        l1ll11 (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l1ll1lll1 = {l1ll11 (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1ll11 (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l11ll11l1 = url.split(l1ll11 (u"ࠥ࠾ࠧࣴ"))
        if len(l11ll11l1) == 1:
            for l1l1l1l11 in list(l1ll1lll1.keys()):
                if l1l1l1l11 == scheme:
                    url += l1ll11 (u"ࠦ࠿ࠨࣵ") + str(l1ll1lll1[l1l1l1l11])
                    break
        return url
    def _11l1l11l(self):
        l1ll11 (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l1ll1l11l:
            l1ll11111 = self.l1ll1l11l[0]
            l1l1llll1 = urlparse(l1ll11111)
        if self.l11l1111l:
            l11ll1l1l = urlparse(self.l11l1111l)
            if l11ll1l1l.scheme:
                l11111lll = l11ll1l1l.scheme
            else:
                if l1l1llll1.scheme:
                    l11111lll = l1l1llll1.scheme
                else:
                    raise l1lll1lll(
                        l1ll11 (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l11ll1l1l.netloc:
                l111l111l = l11ll1l1l.netloc
            else:
                if l1l1llll1.netloc:
                    l111l111l = l1l1llll1.netloc
                else:
                    raise l1lll1lll(
                        l1ll11 (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l111l111l = self._1l11l11l(l111l111l, l11111lll)
            path = l11ll1l1l.path
            if not path.endswith(l1ll11 (u"ࠨ࠱ࣹࠪ")):
                path += l1ll11 (u"ࠩ࠲ࣺࠫ")
            l11111l1l = ParseResult(scheme=l11111lll, netloc=l111l111l, path=path,
                                         params=l11ll1l1l.params, query=l11ll1l1l.query,
                                         fragment=l11ll1l1l.fragment)
            self.l11l1111l = l11111l1l.geturl()
        else:
            if not l1l1llll1.netloc:
                raise l1lll1lll(l1ll11 (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l11lll11l = l1l1llll1.path
            l11l1l1l1 = l1ll11 (u"ࠦ࠴ࠨࣼ").join(l11lll11l.split(l1ll11 (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1ll11 (u"ࠨ࠯ࠣࣾ")
            l11111l1l = ParseResult(scheme=l1l1llll1.scheme,
                                         netloc=self._1l11l11l(l1l1llll1.netloc, l1l1llll1.scheme),
                                         path=l11l1l1l1,
                                         params=l1ll11 (u"ࠢࠣࣿ"),
                                         query=l1ll11 (u"ࠣࠤऀ"),
                                         fragment=l1ll11 (u"ࠤࠥँ")
                                         )
            self.l11l1111l = l11111l1l.geturl()
    def _1l1l1ll1(self):
        l1ll11 (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l1ll1l11l:
            l1ll11111 = self.l1ll1l11l[0]
            l1l1llll1 = urlparse(l1ll11111)
        if self.l111l1ll1:
            l1l11ll11 = urlparse(self.l111l1ll1)
            if l1l11ll11.scheme:
                l11l111ll = l1l11ll11.scheme
            else:
                l11l111ll = l1l1llll1.scheme
            if l1l11ll11.netloc:
                l1l11l1l1 = l1l11ll11.netloc
            else:
                l1l11l1l1 = l1l1llll1.netloc
            l11111ll1 = ParseResult(scheme=l11l111ll, netloc=l1l11l1l1, path=l1l11ll11.path,
                                      params=l1l11ll11.params, query=l1l11ll11.query,
                                      fragment=l1l11ll11.fragment)
            self.l111l1ll1 = l11111ll1.geturl()
    def _11ll11ll(self):
        l1ll11 (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l1ll1l11l
        self.l1ll1l11l = []
        for item in items:
            l11l1llll = urlparse(item.strip(), scheme=l1ll11 (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l11l1llll.path[-1] == l1ll11 (u"ࠨ࠯ࠣअ"):
                l11l11111 = l11l1llll.path
            else:
                path_list = l11l1llll.path.split(l1ll11 (u"ࠢ࠰ࠤआ"))
                l11l11111 = l1ll11 (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1ll11 (u"ࠤ࠲ࠦई")
            l1l111l1l = urlparse(self.l11l1111l, scheme=l1ll11 (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l11l1llll.scheme:
                scheme = l11l1llll.scheme
            elif l1l111l1l.scheme:
                scheme = l1l111l1l.scheme
            else:
                scheme = l1ll11 (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l11l1llll.netloc and not l1l111l1l.netloc:
                l1lll1111 = l11l1llll.netloc
            elif not l11l1llll.netloc and l1l111l1l.netloc:
                l1lll1111 = l1l111l1l.netloc
            elif not l11l1llll.netloc and not l1l111l1l.netloc and len(self.l1ll1l11l) > 0:
                l111111l1 = urlparse(self.l1ll1l11l[len(self.l1ll1l11l) - 1])
                l1lll1111 = l111111l1.netloc
            elif l1l111l1l.netloc:
                l1lll1111 = l11l1llll.netloc
            elif not l1l111l1l.netloc:
                l1lll1111 = l11l1llll.netloc
            if l11l1llll.path:
                l11l1ll1l = l11l1llll.path
            if l1lll1111:
                l1lll1111 = self._1l11l11l(l1lll1111, scheme)
                l1ll111l1 = ParseResult(scheme=scheme, netloc=l1lll1111, path=l11l1ll1l,
                                          params=l11l1llll.params,
                                          query=l11l1llll.query,
                                          fragment=l11l1llll.fragment)
                self.l1ll1l11l.append(l1ll111l1.geturl())
    def _1ll1111l(self):
        l1ll11 (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l1l1ll1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1l1l(l1ll11 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l1l1ll1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1l1l(l1ll11 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l1l1lllll:
            l11l1ll11 = []
            for l11lll111 in self.l1l1lllll:
                if l11lll111 not in [x[l1ll11 (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l11l1ll11.append(l11lll111)
            if l11l1ll11:
                l1l1ll1l = l1ll11 (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1ll11 (u"ࠥ࠰ࠥࠨऐ").join(l11l1ll11))
                raise l11l1l1l(l1ll11 (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1l1ll1l)
    def l1l1l1111(self, params):
        l1ll11 (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l111l11l1 = True
        for param in self._1l1lll11:
            if not params.get(param.lower()):
                l111l11l1 = False
        return l111l11l1
class l11111l11():
    def __init__(self, l11ll1lll):
        self.l11lll1l1 = l1l11.l1llll1l()
        self.l1111111l = self.l1l1ll111()
        self.l11ll1111 = self.l1l1111ll()
        self.l11ll1lll = l11ll1lll
        self._1111llll = [l1ll11 (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1ll11 (u"ࠢࡏࡱࡱࡩࠧऔ"), l1ll11 (u"ࠣࡃ࡯ࡰࠧक"), l1ll11 (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1ll11 (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1ll11 (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1ll11 (u"ࠧࡏࡅࠣङ"), l1ll11 (u"ࠨࡅࡥࡩࡨࠦच")]
        self._1ll11ll1 = [l1ll11 (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1ll11 (u"ࠣࡇࡧ࡭ࡹࠨज"), l1ll11 (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1ll11 (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l11l11lll = None
    def l1l1ll111(self):
        l1111l1l1 = l1ll11 (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l1111l1l1
    def l1l1111ll(self):
        l1l1ll11l = 0
        return l1l1ll11l
    def l1ll11lll(self):
        l1l1ll1l = l1ll11 (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l11ll1111)
        l1l1ll1l += l1ll11 (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l111llll1(l1l1ll11, l1l1ll1l, t=1)
        return res
    def run(self):
        l1111ll1l = True
        self._11l11ll1()
        result = []
        try:
            for cookie in l11l1l1ll(l111l1ll=self.l11ll1lll.cookies).run():
                result.append(cookie)
        except l1111l1l as e:
            logger.exception(l1ll11 (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l1111l1ll = self._111l1lll(result)
            if l1111l1ll:
                logger.info(l1ll11 (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l1111l1ll)
                self.l11l11lll = l1111l1ll
            else:
                logger.info(l1ll11 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l1111l1ll)
            l1111ll1l = True
        else:
            l1111ll1l = False
        return l1111ll1l
    def _111l1lll(self, l1l1ll1l1):
        res = False
        l1l11l1 = os.path.join(os.environ[l1ll11 (u"ࠪࡌࡔࡓࡅࠨथ")], l1ll11 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1ll11 (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1l111lll = {}
        for cookies in l1l1ll1l1:
            l1l111lll[cookies.name] = cookies.value
        l1ll111ll = l1ll11 (u"ࠨࠢन")
        for key in list(l1l111lll.keys()):
            l1ll111ll += l1ll11 (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1l111lll[key].strip())
        if not os.path.exists(os.path.dirname(l1l11l1)):
            os.makedirs(os.path.dirname(l1l11l1))
        vers = int(l1ll11 (u"ࠣࠤप").join(self.l11lll1l1.split(l1ll11 (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l1l1l11l1 = [l1ll11 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1ll11 (u"ࠦࠨࠦࠢभ") + l1ll11 (u"ࠧ࠳ࠢम") * 60,
                              l1ll11 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1ll11 (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1ll11 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l1ll111ll),
                              l1ll11 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l1l1l11l1 = [l1ll11 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1ll11 (u"ࠦࠨࠦࠢऴ") + l1ll11 (u"ࠧ࠳ࠢव") * 60,
                              l1ll11 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1ll11 (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1ll11 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l1ll111ll),
                              l1ll11 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1l11l1, l1ll11 (u"ࠥࡻࠧऺ")) as l1ll1ll1l:
            data = l1ll11 (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l1l1l11l1)
            l1ll1ll1l.write(data)
            l1ll1ll1l.write(l1ll11 (u"ࠧࡢ࡮़ࠣ"))
        res = l1l11l1
        return res
    def _11l11ll1(self):
        self._111l1111(l1ll11 (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._11lll1ll()
    def _111l1111(self, l1l1l1l1l):
        l1lll11ll = self.l11ll1lll.dict[l1l1l1l1l.lower()]
        if l1lll11ll:
            if isinstance(l1lll11ll, list):
                l1l11llll = l1lll11ll
            else:
                l1l11llll = [l1lll11ll]
            if l1ll11 (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l1l1l1l1l.lower():
                    for l111ll11l in l1l11llll:
                        l11l111l1 = [l111ll1ll.upper() for l111ll1ll in self._1111llll]
                        if not l111ll11l.upper() in l11l111l1:
                            l111111ll = l1ll11 (u"ࠣ࠮ࠣࠦि").join(self._1111llll)
                            l11l11l1l = l1ll11 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l1l1l1l1l, l1lll11ll, l111111ll, )
                            raise l11111ll(l11l11l1l)
    def _11lll1ll(self):
        l11ll1ll1 = []
        l1111l11l = self.l11ll1lll.l1l1lllll
        for l11ll1l11 in self._1111llll:
            if not l11ll1l11 in [l1ll11 (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1ll11 (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l11ll1ll1.append(l11ll1l11)
        for l1ll1l1ll in self.l11ll1lll.l11llll1l:
            if l1ll1l1ll in l11ll1ll1 and not l1111l11l:
                l11l11l1l = l1ll11 (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l11111ll(l11l11l1l)
def l111ll111(title, message, l11llll11, l11l1lll1=None):
    l1l11111l = l1l111ll1()
    l1l11111l.l1l1111l1(message, title, l11llll11, l11l1lll1)
def l111lll1l(title, message, l11llll11):
    l11l11l11 = l1lll1l11()
    l11l11l11.l1ll1llll(title, message, l11llll11)
    res = l11l11l11.result
    return res
def main():
    try:
        logger.info(l1ll11 (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l1l1l1l1)
        system.l1lll11l1()
        logger.info(l1ll11 (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1lllll1l(
                l1ll11 (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l1l11l1ll = l1l111111()
        l1l11l1ll.l1l1l11ll(l1ll11 (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l1l1l1lll = [item.upper() for item in l1l11l1ll.l11llll1l]
        l1l111l11 = l1ll11 (u"ࠥࡒࡔࡔࡅࠣै") in l1l1l1lll
        if l1l111l11:
            logger.info(l1ll11 (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l11lllll1 = l1l11l1ll.l1ll1l11l
            for l1111 in l11lllll1:
                logger.debug(l1ll11 (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l1111))
                opener = l1lll1l(l1l11l1ll.l11l1111l, l1111, l1l11l1=None, l1lllll=l1l1l1l1)
                opener.open()
                logger.info(l1ll11 (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l111l11ll = l11111l11(l1l11l1ll)
            l1ll11l11 = l111l11ll.run()
            l11lllll1 = l1l11l1ll.l1ll1l11l
            for l1111 in l11lllll1:
                logger.info(l1ll11 (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l1111))
                opener = l1lll1l(l1l11l1ll.l11l1111l, l1111, l1l11l1=l111l11ll.l11l11lll,
                                l1lllll=l1l1l1l1)
                opener.open()
                logger.info(l1ll11 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1ll1 as e:
        title = l1ll11 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1l1ll11
        logger.exception(l1ll11 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l1111l111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1111l111 = el
        l1111lll1 = l1ll11 (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l1ll111, message.strip())
        l111ll111(title, l1111lll1, l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1ll11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l11l1lll1=l1111l111)
        sys.exit(2)
    except l1llll1ll as e:
        title = l1ll11 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1l1ll11
        logger.exception(l1ll11 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l1111l111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1111l111 = el
        l1111lll1 = l1ll11 (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l111ll111(title, l1111lll1, l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1ll11 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l11l1lll1=l1111l111)
        sys.exit(2)
    except l1lllll1l as e:
        title = l1ll11 (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1l1ll11
        logger.exception(l1ll11 (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l111ll111(title, str(e), l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1ll11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll11 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1l1ll11
        logger.exception(l1ll11 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l111ll111(title, l1ll11 (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1ll11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l11111ll as e:
        title = l1ll11 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1l1ll11
        logger.exception(l1ll11 (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l111ll111(title, l1ll11 (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1ll11 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1111l11 as e:
        title = l1ll11 (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1l1ll11
        logger.exception(l1ll11 (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l111ll111(title, l1ll11 (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1ll11 (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1ll1l1l:
        logger.info(l1ll11 (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1ll11 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1l1ll11
        logger.exception(l1ll11 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l111ll111(title, l1ll11 (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l11llll11=l1l1l1l1.get_value(l1ll11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1ll11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll11 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()