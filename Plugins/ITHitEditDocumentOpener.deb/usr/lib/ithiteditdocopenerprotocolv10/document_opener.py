#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l1l1ll1 (l11ll1):
    global l1llll1
    l1ll111 = ord (l11ll1 [-1])
    l1lll1 = l11ll1 [:-1]
    l1l1111 = l1ll111 % len (l1lll1)
    l1lll1l = l1lll1 [:l1l1111] + l1lll1 [l1l1111:]
    if l1:
        l111ll = l1ll1111 () .join ([unichr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    return eval (l111ll)
import sys, json
import os
import urllib
import l11l11
from l1llll import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1lll1 import l11ll1l1, logger, l1l11l11
from cookies import l111lll1 as l1ll1l1ll
from l1llll1l import l1ll1lll
l1ll1llll = None
from l1111ll import *
class l11l1l1l1():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l1ll1 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1l11l1):
        self.config = l1l1l11l1
        self.l1l1l1l11 = l11l11.l1ll11l1()
    def l1l1l1lll(self):
        data = platform.uname()
        logger.info(l1l1ll1 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1l1ll1 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1l1ll1 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1l1ll1 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1111l1ll():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l111l11 = [l1l1ll1 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l1lll11 = None
        self.l1l1l1111 = None
        self.l1lll1111 = None
        self.l1l1llll1 = None
        self.l1l1 = None
        self.l11ll1l11 = None
        self.l1l11llll = None
        self.l111lllll = None
        self.cookies = None
    def l11111111(self, url):
        l1l1ll1 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1l1ll1 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._111l111l(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1l1ll11l(url)
        self.dict = self._111l11l1(params)
        logger.info(l1l1ll1 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l11l1ll11(self.dict):
            raise l1llll11l(l1l1ll1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1l111l11)
        self._111ll111(self.dict)
        if self._encode:
            self.l1ll1l11l()
        self._11llllll()
        self._11llll1l()
        self._1l1l11ll()
        self._1l1ll1l1()
        self.l111l1l1l()
        logger.info(l1l1ll1 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1l1ll1 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l1lll11))
        logger.info(l1l1ll1 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l1l1l1111))
        logger.info(l1l1ll1 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l1lll1111))
        logger.info(l1l1ll1 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l1l1llll1))
        logger.info(l1l1ll1 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l1l1))
        logger.info(l1l1ll1 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11ll1l11))
        logger.info(l1l1ll1 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l11llll))
        logger.info(l1l1ll1 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l111lllll))
    def _111ll111(self, l11l1ll1l):
        self.l1l1lll11 = l11l1ll1l.get(l1l1ll1 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l1l1l1111 = l11l1ll1l.get(l1l1ll1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1l1ll1 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l1lll1111 = l11l1ll1l.get(l1l1ll1 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l1l1llll1 = l11l1ll1l.get(l1l1ll1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l1l1 = l11l1ll1l.get(l1l1ll1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11ll1l11 = l11l1ll1l.get(l1l1ll1 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l11llll = l11l1ll1l.get(l1l1ll1 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1l1ll1 (u"ࠣࠤ࣏"))
        self.l111lllll = l11l1ll1l.get(l1l1ll1 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1l1ll1 (u"࣑ࠥࠦ"))
        self.cookies = l11l1ll1l.get(l1l1ll1 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l111l1l1l(self):
        l1lll111l = False
        if self.l1l1:
            if self.l1l1.upper() == l1l1ll1 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l1l1 = l1l1ll1 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l1l1.upper() == l1l1ll1 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l1l1 = l1l1ll1 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l1l1.upper() == l1l1ll1 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l1l1 = l1l1ll1 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l1l1.upper() == l1l1ll1 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l1l1 = l1l1ll1 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l1l1 == l1l1ll1 (u"ࠨࠢࣛ"):
                l1lll111l = True
            else:
                self.l1l1 = self.l1l1.lower()
        else:
            l1lll111l = True
        if l1lll111l:
            self.l1l1 = l1l1ll1 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1ll1l11l(self):
        l1l1ll1 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l1ll1 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l111ll1l1 = []
                    for el in self.__dict__.get(key):
                        l111ll1l1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l111ll1l1
    def l1l11l11l(self, l1l111lll):
        res = l1l111lll
        if self._encode:
            res = urllib.parse.quote(l1l111lll, safe=l1l1ll1 (u"ࠥࠦࣟ"))
        return res
    def _111l111l(self, url):
        l1l1ll1 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1l1ll1 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1l1ll1 (u"ࠨ࠺ࠣ࣢")), l1l1ll1 (u"ࠧࠨࣣ"), url)
        return url
    def _1l1ll11l(self, url):
        l1l1ll1 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1lll11l1 = url.split(l1l1ll1 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1l1ll1 (u"ࠥ࠿ࣦࠧ")))
        result = l1lll11l1
        if len(result) == 0:
            raise l1lll1ll1(l1l1ll1 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _111l11l1(self, params):
        l1l1ll1 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1l1ll1 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1l1ll1 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11111ll1 = data.group(l1l1ll1 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l11111ll1 in (l1l1ll1 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1l1ll1 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1l1ll1 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1l1ll1 (u"ࠧ࠲࣯ࠢ"))
                elif l11111ll1 == l1l1ll1 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1l1ll1 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l1ll1 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l11111ll1] = value
        return result
    def _1ll11lll(self, url, scheme):
        l1l1ll1 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l11l111 = {l1l1ll1 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1l1ll1 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1l11l1ll = url.split(l1l1ll1 (u"ࠧࡀࣶࠢ"))
        if len(l1l11l1ll) == 1:
            for l11lll1ll in list(l1l11l111.keys()):
                if l11lll1ll == scheme:
                    url += l1l1ll1 (u"ࠨ࠺ࠣࣷ") + str(l1l11l111[l11lll1ll])
                    break
        return url
    def _11llllll(self):
        l1l1ll1 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l1l1llll1:
            l1111llll = self.l1l1llll1[0]
            l1l1l111l = urlparse(l1111llll)
        if self.l1l1lll11:
            l1l1l1ll1 = urlparse(self.l1l1lll11)
            if l1l1l1ll1.scheme:
                l11111l11 = l1l1l1ll1.scheme
            else:
                if l1l1l111l.scheme:
                    l11111l11 = l1l1l111l.scheme
                else:
                    raise l1llll1ll(
                        l1l1ll1 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l1l1ll1.netloc:
                l1ll1lll1 = l1l1l1ll1.netloc
            else:
                if l1l1l111l.netloc:
                    l1ll1lll1 = l1l1l111l.netloc
                else:
                    raise l1llll1ll(
                        l1l1ll1 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1ll1lll1 = self._1ll11lll(l1ll1lll1, l11111l11)
            path = l1l1l1ll1.path
            if not path.endswith(l1l1ll1 (u"ࠪ࠳ࠬࣻ")):
                path += l1l1ll1 (u"ࠫ࠴࠭ࣼ")
            l1ll1111l = ParseResult(scheme=l11111l11, netloc=l1ll1lll1, path=path,
                                         params=l1l1l1ll1.params, query=l1l1l1ll1.query,
                                         fragment=l1l1l1ll1.fragment)
            self.l1l1lll11 = l1ll1111l.geturl()
        else:
            if not l1l1l111l.netloc:
                raise l1llll1ll(l1l1ll1 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l1l111111 = l1l1l111l.path
            l1l111l1l = l1l1ll1 (u"ࠨ࠯ࠣࣾ").join(l1l111111.split(l1l1ll1 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1l1ll1 (u"ࠣ࠱ࠥऀ")
            l1ll1111l = ParseResult(scheme=l1l1l111l.scheme,
                                         netloc=self._1ll11lll(l1l1l111l.netloc, l1l1l111l.scheme),
                                         path=l1l111l1l,
                                         params=l1l1ll1 (u"ࠤࠥँ"),
                                         query=l1l1ll1 (u"ࠥࠦं"),
                                         fragment=l1l1ll1 (u"ࠦࠧः")
                                         )
            self.l1l1lll11 = l1ll1111l.geturl()
    def _1l1l11ll(self):
        l1l1ll1 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l1l1llll1:
            l1111llll = self.l1l1llll1[0]
            l1l1l111l = urlparse(l1111llll)
        if self.l11ll1l11:
            l1llllllll = urlparse(self.l11ll1l11)
            if l1llllllll.scheme:
                l111ll11l = l1llllllll.scheme
            else:
                l111ll11l = l1l1l111l.scheme
            if l1llllllll.netloc:
                l1l11111l = l1llllllll.netloc
            else:
                l1l11111l = l1l1l111l.netloc
            l11ll1ll1 = ParseResult(scheme=l111ll11l, netloc=l1l11111l, path=l1llllllll.path,
                                      params=l1llllllll.params, query=l1llllllll.query,
                                      fragment=l1llllllll.fragment)
            self.l11ll1l11 = l11ll1ll1.geturl()
    def _11llll1l(self):
        l1l1ll1 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l1l1llll1
        self.l1l1llll1 = []
        for item in items:
            l11l11l11 = urlparse(item.strip(), scheme=l1l1ll1 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11l11l11.path[-1] == l1l1ll1 (u"ࠣ࠱ࠥइ"):
                l111l11ll = l11l11l11.path
            else:
                path_list = l11l11l11.path.split(l1l1ll1 (u"ࠤ࠲ࠦई"))
                l111l11ll = l1l1ll1 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1l1ll1 (u"ࠦ࠴ࠨऊ")
            l1l1ll111 = urlparse(self.l1l1lll11, scheme=l1l1ll1 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11l11l11.scheme:
                scheme = l11l11l11.scheme
            elif l1l1ll111.scheme:
                scheme = l1l1ll111.scheme
            else:
                scheme = l1l1ll1 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11l11l11.netloc and not l1l1ll111.netloc:
                l11l11111 = l11l11l11.netloc
            elif not l11l11l11.netloc and l1l1ll111.netloc:
                l11l11111 = l1l1ll111.netloc
            elif not l11l11l11.netloc and not l1l1ll111.netloc and len(self.l1l1llll1) > 0:
                l1111l11l = urlparse(self.l1l1llll1[len(self.l1l1llll1) - 1])
                l11l11111 = l1111l11l.netloc
            elif l1l1ll111.netloc:
                l11l11111 = l11l11l11.netloc
            elif not l1l1ll111.netloc:
                l11l11111 = l11l11l11.netloc
            if l11l11l11.path:
                l11ll111l = l11l11l11.path
            if l11l11111:
                l11l11111 = self._1ll11lll(l11l11111, scheme)
                l1111lll1 = ParseResult(scheme=scheme, netloc=l11l11111, path=l11ll111l,
                                          params=l11l11l11.params,
                                          query=l11l11l11.query,
                                          fragment=l11l11l11.fragment)
                self.l1l1llll1.append(l1111lll1.geturl())
    def _1l1ll1l1(self):
        l1l1ll1 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l11lll111 = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l1l1ll1 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l11lll111)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l1l1ll1 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l1lll1111:
            l1l11lll1 = []
            for l1ll1l111 in self.l1lll1111:
                if l1ll1l111 not in [x[l1l1ll1 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1l11lll1.append(l1ll1l111)
            if l1l11lll1:
                l11ll1ll = l1l1ll1 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1l1ll1 (u"ࠧ࠲ࠠࠣऒ").join(l1l11lll1))
                raise l111ll11(l1l1ll1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l11ll1ll)
    def l11l1ll11(self, params):
        l1l1ll1 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l11l1l11l = True
        for param in self._1l111l11:
            if not params.get(param.lower()):
                l11l1l11l = False
        return l11l1l11l
class l1ll111ll():
    def __init__(self, l1l11ll11):
        self.l11l11ll1 = l11l11.l1ll11l1()
        self.l1ll11l11 = self.l11l111ll()
        self.l1ll11ll1 = self.l111l1111()
        self.l1l11ll11 = l1l11ll11
        self._11ll11ll = [l1l1ll1 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1l1ll1 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1l1ll1 (u"ࠥࡅࡱࡲࠢग"), l1l1ll1 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1l1ll1 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1l1ll1 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1l1ll1 (u"ࠢࡊࡇࠥछ"), l1l1ll1 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._111l1lll = [l1l1ll1 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1l1ll1 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1l1ll1 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1l1ll1 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l1111l1l1 = None
    def l11l111ll(self):
        l111llll1 = l1l1ll1 (u"ࠨࡎࡰࡰࡨࠦड")
        return l111llll1
    def l111l1111(self):
        l1111l111 = 0
        return l1111l111
    def l1l1111ll(self):
        l11ll1ll = l1l1ll1 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l1ll11ll1)
        l11ll1ll += l1l1ll1 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l1l1111l1(l11ll1l1, l11ll1ll, t=1)
        return res
    def run(self):
        l1l1lll1l = True
        self._11l11l1l()
        result = []
        try:
            for cookie in l1ll1l1ll(l11l111l=self.l1l11ll11.cookies).run():
                result.append(cookie)
        except l111111l as e:
            logger.exception(l1l1ll1 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l111lll11 = self._1l1lllll(result)
            if l111lll11:
                logger.info(l1l1ll1 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l111lll11)
                self.l1111l1l1 = l111lll11
            else:
                logger.info(l1l1ll1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l111lll11)
            l1l1lll1l = True
        else:
            l1l1lll1l = False
        return l1l1lll1l
    def _1l1lllll(self, l1l1l1l1l):
        res = False
        l1lllll1 = os.path.join(os.environ[l1l1ll1 (u"ࠬࡎࡏࡎࡇࠪध")], l1l1ll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1l1ll1 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l111111ll = {}
        for cookies in l1l1l1l1l:
            l111111ll[cookies.name] = cookies.value
        l1l11l1l1 = l1l1ll1 (u"ࠣࠤप")
        for key in list(l111111ll.keys()):
            l1l11l1l1 += l1l1ll1 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l111111ll[key].strip())
        if not os.path.exists(os.path.dirname(l1lllll1)):
            os.makedirs(os.path.dirname(l1lllll1))
        vers = int(l1l1ll1 (u"ࠥࠦब").join(self.l11l11ll1.split(l1l1ll1 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l11l1llll = [l1l1ll1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1l1ll1 (u"ࠨࠣࠡࠤय") + l1l1ll1 (u"ࠢ࠮ࠤर") * 60,
                              l1l1ll1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1l1ll1 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1l1ll1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l1l11l1l1),
                              l1l1ll1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l11l1llll = [l1l1ll1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1l1ll1 (u"ࠨࠣࠡࠤश") + l1l1ll1 (u"ࠢ࠮ࠤष") * 60,
                              l1l1ll1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1l1ll1 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1l1ll1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l1l11l1l1),
                              l1l1ll1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1lllll1, l1l1ll1 (u"ࠧࡽ़ࠢ")) as l11ll11l1:
            data = l1l1ll1 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l11l1llll)
            l11ll11l1.write(data)
            l11ll11l1.write(l1l1ll1 (u"ࠢ࡝ࡰࠥा"))
        res = l1lllll1
        return res
    def _11l11l1l(self):
        self._11lll1l1(l1l1ll1 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._111111l1()
    def _11lll1l1(self, l11111l1l):
        l1ll111l1 = self.l1l11ll11.dict[l11111l1l.lower()]
        if l1ll111l1:
            if isinstance(l1ll111l1, list):
                l1l11ll1l = l1ll111l1
            else:
                l1l11ll1l = [l1ll111l1]
            if l1l1ll1 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11111l1l.lower():
                    for l11lllll1 in l1l11ll1l:
                        l11l1lll1 = [l1l1ll1ll.upper() for l1l1ll1ll in self._11ll11ll]
                        if not l11lllll1.upper() in l11l1lll1:
                            l11ll1111 = l1l1ll1 (u"ࠥ࠰ࠥࠨु").join(self._11ll11ll)
                            l11l1l1ll = l1l1ll1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11111l1l, l1ll111l1, l11ll1111, )
                            raise l1lllllll(l11l1l1ll)
    def _111111l1(self):
        l11111lll = []
        l111l1l11 = self.l1l11ll11.l1lll1111
        for l11l111l1 in self._11ll11ll:
            if not l11l111l1 in [l1l1ll1 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1l1ll1 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l11111lll.append(l11l111l1)
        for l1l111ll1 in self.l1l11ll11.l1l1l1111:
            if l1l111ll1 in l11111lll and not l111l1l11:
                l11l1l1ll = l1l1ll1 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lllllll(l11l1l1ll)
def l1ll11111(title, message, l11ll1l1l, l1111111l=None):
    l11ll1lll = l1111ll11()
    l11ll1lll.l111l1ll1(message, title, l11ll1l1l, l1111111l)
def l1ll1l1l1(title, message, l11ll1l1l):
    l11l11lll = l11l1111l()
    l11l11lll.l1111ll1l(title, message, l11ll1l1l)
    res = l11l11lll.result
    return res
def main():
    try:
        logger.info(l1l1ll1 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l1l11l11)
        system.l1l1l1lll()
        logger.info(l1l1ll1 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1llll11l(
                l1l1ll1 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l1ll11l1l = l1111l1ll()
        l1ll11l1l.l11111111(l1l1ll1 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l11lll11l = [item.upper() for item in l1ll11l1l.l1l1l1111]
        l1ll1ll1l = l1l1ll1 (u"ࠧࡔࡏࡏࡇࠥॊ") in l11lll11l
        if l1ll1ll1l:
            logger.info(l1l1ll1 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l1ll1ll11 = l1ll11l1l.l1l1llll1
            for l11l111 in l1ll1ll11:
                logger.debug(l1l1ll1 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l11l111))
                opener = l1ll1lll(l1ll11l1l.l1l1lll11, l11l111, l1lllll1=None, l1ll111l=l1l11l11)
                opener.open()
                logger.info(l1l1ll1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l111lll1l = l1ll111ll(l1ll11l1l)
            l111ll1ll = l111lll1l.run()
            l1ll1ll11 = l1ll11l1l.l1l1llll1
            for l11l111 in l1ll1ll11:
                logger.info(l1l1ll1 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l11l111))
                opener = l1ll1lll(l1ll11l1l.l1l1lll11, l11l111, l1lllll1=l111lll1l.l1111l1l1,
                                l1ll111l=l1l11l11)
                opener.open()
                logger.info(l1l1ll1 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1ll11 as e:
        title = l1l1ll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11llll11 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11llll11 = el
        l11l1l111 = l1l1ll1 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1lllll, message.strip())
        l1ll11111(title, l11l1l111, l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1l1ll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1111111l=l11llll11)
        sys.exit(2)
    except l1111111 as e:
        title = l1l1ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11llll11 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11llll11 = el
        l11l1l111 = l1l1ll1 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1ll11111(title, l11l1l111, l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1111111l=l11llll11)
        sys.exit(2)
    except l1llll11l as e:
        title = l1l1ll1 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1ll11111(title, str(e), l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1l1ll1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1l1ll1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1ll11111(title, l1l1ll1 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1l1ll1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lllllll as e:
        title = l1l1ll1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1ll11111(title, l1l1ll1 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l11111ll as e:
        title = l1l1ll1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1ll11111(title, l1l1ll1 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1l1ll1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l11ll1l:
        logger.info(l1l1ll1 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1l1ll1 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l11ll1l1
        logger.exception(l1l1ll1 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1ll11111(title, l1l1ll1 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11ll1l1l=l1l11l11.get_value(l1l1ll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1l1ll1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l1ll1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()