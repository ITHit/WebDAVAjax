#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import sys, json
import os
import urllib
import l1ll1l1
from l11ll1 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1l1l1 import l1ll1111, logger, l11ll11l
from cookies import l111ll11 as l1l11llll
from l1l11l1 import l1llll1
l1l1ll11l = None
from l11l1l1 import *
class l1l1ll111():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1ll11l1 (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1lll1l):
        self.config = l1l1lll1l
        self.l1l11lll1 = l1ll1l1.l1ll1lll()
    def l1l1111ll(self):
        data = platform.uname()
        logger.info(l1ll11l1 (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1ll11l1 (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1ll11l1 (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1ll11l1 (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1lll11l1():
    def __init__(self, encode = True):
        self._encode = encode
        self._11l11111 = [l1ll11l1 (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l1111lll1 = None
        self.l11lll11l = None
        self.l1ll111ll = None
        self.l1ll1l1l1 = None
        self.l1lll11l = None
        self.l1ll11l1l = None
        self.l1l11l111 = None
        self.l1l11ll11 = None
        self.cookies = None
    def l1l1lll11(self, url):
        l1ll11l1 (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1ll11l1 (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._11lll111(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11llll11(url)
        self.dict = self._11l1l1l1(params)
        logger.info(l1ll11l1 (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l111l1lll(self.dict):
            raise l1llll1l1(l1ll11l1 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._11l11111)
        self._1ll11lll(self.dict)
        if self._encode:
            self.l1l1l1lll()
        self._11lll1ll()
        self._11111l11()
        self._1ll111l1()
        self._1ll1ll11()
        self.l11llllll()
        logger.info(l1ll11l1 (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1ll11l1 (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l1111lll1))
        logger.info(l1ll11l1 (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l11lll11l))
        logger.info(l1ll11l1 (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l1ll111ll))
        logger.info(l1ll11l1 (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l1ll1l1l1))
        logger.info(l1ll11l1 (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l1lll11l))
        logger.info(l1ll11l1 (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l1ll11l1l))
        logger.info(l1ll11l1 (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l1l11l111))
        logger.info(l1ll11l1 (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l1l11ll11))
    def _1ll11lll(self, l11ll111l):
        self.l1111lll1 = l11ll111l.get(l1ll11l1 (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l11lll11l = l11ll111l.get(l1ll11l1 (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1ll11l1 (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l1ll111ll = l11ll111l.get(l1ll11l1 (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l1ll1l1l1 = l11ll111l.get(l1ll11l1 (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l1lll11l = l11ll111l.get(l1ll11l1 (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l1ll11l1l = l11ll111l.get(l1ll11l1 (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l1l11l111 = l11ll111l.get(l1ll11l1 (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1ll11l1 (u"ࠨࠢ࣍"))
        self.l1l11ll11 = l11ll111l.get(l1ll11l1 (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1ll11l1 (u"ࠣࠤ࣏"))
        self.cookies = l11ll111l.get(l1ll11l1 (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l11llllll(self):
        l1l1l11ll = False
        if self.l1lll11l:
            if self.l1lll11l.upper() == l1ll11l1 (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l1lll11l = l1ll11l1 (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l1lll11l.upper() == l1ll11l1 (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l1lll11l = l1ll11l1 (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l1lll11l.upper() == l1ll11l1 (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l1lll11l = l1ll11l1 (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l1lll11l.upper() == l1ll11l1 (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l1lll11l = l1ll11l1 (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l1lll11l == l1ll11l1 (u"ࠦࠧࣙ"):
                l1l1l11ll = True
            else:
                self.l1lll11l = self.l1lll11l.lower()
        else:
            l1l1l11ll = True
        if l1l1l11ll:
            self.l1lll11l = l1ll11l1 (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l1l1l1lll(self):
        l1ll11l1 (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1ll11l1 (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1111l11l = []
                    for el in self.__dict__.get(key):
                        l1111l11l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1111l11l
    def l11l11l1l(self, l1ll1ll1l):
        res = l1ll1ll1l
        if self._encode:
            res = urllib.parse.quote(l1ll1ll1l, safe=l1ll11l1 (u"ࠣࠤࣝ"))
        return res
    def _11lll111(self, url):
        l1ll11l1 (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1ll11l1 (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1ll11l1 (u"ࠦ࠿ࠨ࣠")), l1ll11l1 (u"ࠬ࠭࣡"), url)
        return url
    def _11llll11(self, url):
        l1ll11l1 (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l111ll1ll = url.split(l1ll11l1 (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1ll11l1 (u"ࠣ࠽ࠥࣤ")))
        result = l111ll1ll
        if len(result) == 0:
            raise l1111l1l(l1ll11l1 (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _11l1l1l1(self, params):
        l1ll11l1 (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1ll11l1 (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1ll11l1 (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11l11ll1 = data.group(l1ll11l1 (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l11l11ll1 in (l1ll11l1 (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1ll11l1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1ll11l1 (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1ll11l1 (u"ࠥ࠰࣭ࠧ"))
                elif l11l11ll1 == l1ll11l1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1ll11l1 (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1ll11l1 (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l11l11ll1] = value
        return result
    def _1ll11l11(self, url, scheme):
        l1ll11l1 (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l11111lll = {l1ll11l1 (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1ll11l1 (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l1l11l1ll = url.split(l1ll11l1 (u"ࠥ࠾ࠧࣴ"))
        if len(l1l11l1ll) == 1:
            for l1111ll1l in list(l11111lll.keys()):
                if l1111ll1l == scheme:
                    url += l1ll11l1 (u"ࠦ࠿ࠨࣵ") + str(l11111lll[l1111ll1l])
                    break
        return url
    def _11lll1ll(self):
        l1ll11l1 (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l1ll1l1l1:
            l111l1l11 = self.l1ll1l1l1[0]
            l1ll11111 = urlparse(l111l1l11)
        if self.l1111lll1:
            l111lll11 = urlparse(self.l1111lll1)
            if l111lll11.scheme:
                l111lllll = l111lll11.scheme
            else:
                if l1ll11111.scheme:
                    l111lllll = l1ll11111.scheme
                else:
                    raise l1llllll1(
                        l1ll11l1 (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l111lll11.netloc:
                l11ll1l1l = l111lll11.netloc
            else:
                if l1ll11111.netloc:
                    l11ll1l1l = l1ll11111.netloc
                else:
                    raise l1llllll1(
                        l1ll11l1 (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l11ll1l1l = self._1ll11l11(l11ll1l1l, l111lllll)
            path = l111lll11.path
            if not path.endswith(l1ll11l1 (u"ࠨ࠱ࣹࠪ")):
                path += l1ll11l1 (u"ࠩ࠲ࣺࠫ")
            l111l1111 = ParseResult(scheme=l111lllll, netloc=l11ll1l1l, path=path,
                                         params=l111lll11.params, query=l111lll11.query,
                                         fragment=l111lll11.fragment)
            self.l1111lll1 = l111l1111.geturl()
        else:
            if not l1ll11111.netloc:
                raise l1llllll1(l1ll11l1 (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l1l1l1ll1 = l1ll11111.path
            l11l1lll1 = l1ll11l1 (u"ࠦ࠴ࠨࣼ").join(l1l1l1ll1.split(l1ll11l1 (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1ll11l1 (u"ࠨ࠯ࠣࣾ")
            l111l1111 = ParseResult(scheme=l1ll11111.scheme,
                                         netloc=self._1ll11l11(l1ll11111.netloc, l1ll11111.scheme),
                                         path=l11l1lll1,
                                         params=l1ll11l1 (u"ࠢࠣࣿ"),
                                         query=l1ll11l1 (u"ࠣࠤऀ"),
                                         fragment=l1ll11l1 (u"ࠤࠥँ")
                                         )
            self.l1111lll1 = l111l1111.geturl()
    def _1ll111l1(self):
        l1ll11l1 (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l1ll1l1l1:
            l111l1l11 = self.l1ll1l1l1[0]
            l1ll11111 = urlparse(l111l1l11)
        if self.l1ll11l1l:
            l11l1l11l = urlparse(self.l1ll11l1l)
            if l11l1l11l.scheme:
                l11111ll1 = l11l1l11l.scheme
            else:
                l11111ll1 = l1ll11111.scheme
            if l11l1l11l.netloc:
                l1l1l111l = l11l1l11l.netloc
            else:
                l1l1l111l = l1ll11111.netloc
            l1ll1l111 = ParseResult(scheme=l11111ll1, netloc=l1l1l111l, path=l11l1l11l.path,
                                      params=l11l1l11l.params, query=l11l1l11l.query,
                                      fragment=l11l1l11l.fragment)
            self.l1ll11l1l = l1ll1l111.geturl()
    def _11111l11(self):
        l1ll11l1 (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l1ll1l1l1
        self.l1ll1l1l1 = []
        for item in items:
            l1l111ll1 = urlparse(item.strip(), scheme=l1ll11l1 (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l1l111ll1.path[-1] == l1ll11l1 (u"ࠨ࠯ࠣअ"):
                l111llll1 = l1l111ll1.path
            else:
                path_list = l1l111ll1.path.split(l1ll11l1 (u"ࠢ࠰ࠤआ"))
                l111llll1 = l1ll11l1 (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1ll11l1 (u"ࠤ࠲ࠦई")
            l111ll1l1 = urlparse(self.l1111lll1, scheme=l1ll11l1 (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l1l111ll1.scheme:
                scheme = l1l111ll1.scheme
            elif l111ll1l1.scheme:
                scheme = l111ll1l1.scheme
            else:
                scheme = l1ll11l1 (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l1l111ll1.netloc and not l111ll1l1.netloc:
                l1l1l1l11 = l1l111ll1.netloc
            elif not l1l111ll1.netloc and l111ll1l1.netloc:
                l1l1l1l11 = l111ll1l1.netloc
            elif not l1l111ll1.netloc and not l111ll1l1.netloc and len(self.l1ll1l1l1) > 0:
                l1ll1l1ll = urlparse(self.l1ll1l1l1[len(self.l1ll1l1l1) - 1])
                l1l1l1l11 = l1ll1l1ll.netloc
            elif l111ll1l1.netloc:
                l1l1l1l11 = l1l111ll1.netloc
            elif not l111ll1l1.netloc:
                l1l1l1l11 = l1l111ll1.netloc
            if l1l111ll1.path:
                l1l1llll1 = l1l111ll1.path
            if l1l1l1l11:
                l1l1l1l11 = self._1ll11l11(l1l1l1l11, scheme)
                l1l111l11 = ParseResult(scheme=scheme, netloc=l1l1l1l11, path=l1l1llll1,
                                          params=l1l111ll1.params,
                                          query=l1l111ll1.query,
                                          fragment=l1l111ll1.fragment)
                self.l1ll1l1l1.append(l1l111l11.geturl())
    def _1ll1ll11(self):
        l1ll11l1 (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l11l1ll1l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111lll1(l1ll11l1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l11l1ll1l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111lll1(l1ll11l1 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l1ll111ll:
            l1lll1l11 = []
            for l1l1111l1 in self.l1ll111ll:
                if l1l1111l1 not in [x[l1ll11l1 (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l1lll1l11.append(l1l1111l1)
            if l1lll1l11:
                l1l1l11l = l1ll11l1 (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1ll11l1 (u"ࠥ࠰ࠥࠨऐ").join(l1lll1l11))
                raise l111lll1(l1ll11l1 (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1l1l11l)
    def l111l1lll(self, params):
        l1ll11l1 (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1lll1111 = True
        for param in self._11l11111:
            if not params.get(param.lower()):
                l1lll1111 = False
        return l1lll1111
class l1lll11ll():
    def __init__(self, l11l1111l):
        self.l1111ll11 = l1ll1l1.l1ll1lll()
        self.l1l11111l = self.l11llll1l()
        self.l111111l1 = self.l111l11l1()
        self.l11l1111l = l11l1111l
        self._1l11ll1l = [l1ll11l1 (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1ll11l1 (u"ࠢࡏࡱࡱࡩࠧऔ"), l1ll11l1 (u"ࠣࡃ࡯ࡰࠧक"), l1ll11l1 (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1ll11l1 (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1ll11l1 (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1ll11l1 (u"ࠧࡏࡅࠣङ"), l1ll11l1 (u"ࠨࡅࡥࡩࡨࠦच")]
        self._1lll111l = [l1ll11l1 (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1ll11l1 (u"ࠣࡇࡧ࡭ࡹࠨज"), l1ll11l1 (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1ll11l1 (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l11l11lll = None
    def l11llll1l(self):
        l11lll1l1 = l1ll11l1 (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l11lll1l1
    def l111l11l1(self):
        l1ll1l11l = 0
        return l1ll1l11l
    def l11ll1lll(self):
        l1l1l11l = l1ll11l1 (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l111111l1)
        l1l1l11l += l1ll11l1 (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l1111llll(l1ll1111, l1l1l11l, t=1)
        return res
    def run(self):
        l11l1l1ll = True
        self._111ll111()
        result = []
        try:
            for cookie in l1l11llll(l111ll1l=self.l11l1111l.cookies).run():
                result.append(cookie)
        except l1llll1ll as e:
            logger.exception(l1ll11l1 (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l11ll1ll1 = self._11ll11ll(result)
            if l11ll1ll1:
                logger.info(l1ll11l1 (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l11ll1ll1)
                self.l11l11lll = l11ll1ll1
            else:
                logger.info(l1ll11l1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l11ll1ll1)
            l11l1l1ll = True
        else:
            l11l1l1ll = False
        return l11l1l1ll
    def _11ll11ll(self, l111lll1l):
        res = False
        l1111ll = os.path.join(os.environ[l1ll11l1 (u"ࠪࡌࡔࡓࡅࠨथ")], l1ll11l1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1ll11l1 (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1l1ll1ll = {}
        for cookies in l111lll1l:
            l1l1ll1ll[cookies.name] = cookies.value
        l1111111l = l1ll11l1 (u"ࠨࠢन")
        for key in list(l1l1ll1ll.keys()):
            l1111111l += l1ll11l1 (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1l1ll1ll[key].strip())
        if not os.path.exists(os.path.dirname(l1111ll)):
            os.makedirs(os.path.dirname(l1111ll))
        vers = int(l1ll11l1 (u"ࠣࠤप").join(self.l1111ll11.split(l1ll11l1 (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l11ll11l1 = [l1ll11l1 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1ll11l1 (u"ࠦࠨࠦࠢभ") + l1ll11l1 (u"ࠧ࠳ࠢम") * 60,
                              l1ll11l1 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1ll11l1 (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1ll11l1 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l1111111l),
                              l1ll11l1 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l11ll11l1 = [l1ll11l1 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1ll11l1 (u"ࠦࠨࠦࠢऴ") + l1ll11l1 (u"ࠧ࠳ࠢव") * 60,
                              l1ll11l1 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1ll11l1 (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1ll11l1 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l1111111l),
                              l1ll11l1 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1111ll, l1ll11l1 (u"ࠥࡻࠧऺ")) as l1ll11ll1:
            data = l1ll11l1 (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l11ll11l1)
            l1ll11ll1.write(data)
            l1ll11ll1.write(l1ll11l1 (u"ࠧࡢ࡮़ࠣ"))
        res = l1111ll
        return res
    def _111ll111(self):
        self._1111l1ll(l1ll11l1 (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._11l1l111()
    def _1111l1ll(self, l11l111l1):
        l11lllll1 = self.l11l1111l.dict[l11l111l1.lower()]
        if l11lllll1:
            if isinstance(l11lllll1, list):
                l11l1llll = l11lllll1
            else:
                l11l1llll = [l11lllll1]
            if l1ll11l1 (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l11l111l1.lower():
                    for l11l11l11 in l11l1llll:
                        l1111l1l1 = [l11111l1l.upper() for l11111l1l in self._1l11ll1l]
                        if not l11l11l11.upper() in l1111l1l1:
                            l1l1l11l1 = l1ll11l1 (u"ࠣ࠮ࠣࠦि").join(self._1l11ll1l)
                            l1l1ll1l1 = l1ll11l1 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l11l111l1, l11lllll1, l1l1l11l1, )
                            raise l1lllllll(l1l1ll1l1)
    def _11l1l111(self):
        l111l1ll1 = []
        l1111l111 = self.l11l1111l.l1ll111ll
        for l1l1l1l1l in self._1l11ll1l:
            if not l1l1l1l1l in [l1ll11l1 (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1ll11l1 (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l111l1ll1.append(l1l1l1l1l)
        for l11l1ll11 in self.l11l1111l.l11lll11l:
            if l11l1ll11 in l111l1ll1 and not l1111l111:
                l1l1ll1l1 = l1ll11l1 (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1lllllll(l1l1ll1l1)
def l111l1l1l(title, message, l1ll1111l, l1l111111=None):
    l11ll1111 = l11l111ll()
    l11ll1111.l1l11l11l(message, title, l1ll1111l, l1l111111)
def l1l111l1l(title, message, l1ll1111l):
    l1l111lll = l111l11ll()
    l1l111lll.l111l111l(title, message, l1ll1111l)
    res = l1l111lll.result
    return res
def main():
    try:
        logger.info(l1ll11l1 (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l11ll11l)
        system.l1l1111ll()
        logger.info(l1ll11l1 (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1llll1l1(
                l1ll11l1 (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l1l11l1l1 = l1lll11l1()
        l1l11l1l1.l1l1lll11(l1ll11l1 (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l111ll11l = [item.upper() for item in l1l11l1l1.l11lll11l]
        l1l1l1111 = l1ll11l1 (u"ࠥࡒࡔࡔࡅࠣै") in l111ll11l
        if l1l1l1111:
            logger.info(l1ll11l1 (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l1ll1llll = l1l11l1l1.l1ll1l1l1
            for l1l1ll1 in l1ll1llll:
                logger.debug(l1ll11l1 (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l1l1ll1))
                opener = l1llll1(l1l11l1l1.l1111lll1, l1l1ll1, l1111ll=None, l1lll1ll=l11ll11l)
                opener.open()
                logger.info(l1ll11l1 (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l1ll1lll1 = l1lll11ll(l1l11l1l1)
            l111111ll = l1ll1lll1.run()
            l1ll1llll = l1l11l1l1.l1ll1l1l1
            for l1l1ll1 in l1ll1llll:
                logger.info(l1ll11l1 (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l1l1ll1))
                opener = l1llll1(l1l11l1l1.l1111lll1, l1l1ll1, l1111ll=l1ll1lll1.l11l11lll,
                                l1lll1ll=l11ll11l)
                opener.open()
                logger.info(l1ll11l1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1lll1l1 as e:
        title = l1ll11l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l1l1lllll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1lllll = el
        l11ll1l11 = l1ll11l1 (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l1lll1, message.strip())
        l111l1l1l(title, l11ll1l11, l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1ll11l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l1l111111=l1l1lllll)
        sys.exit(2)
    except l11111ll as e:
        title = l1ll11l1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l1l1lllll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1lllll = el
        l11ll1l11 = l1ll11l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l111l1l1l(title, l11ll1l11, l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1ll11l1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l1l111111=l1l1lllll)
        sys.exit(2)
    except l1llll1l1 as e:
        title = l1ll11l1 (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l111l1l1l(title, str(e), l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1ll11l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1ll11l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l111l1l1l(title, l1ll11l1 (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1ll11l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1lllllll as e:
        title = l1ll11l1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l111l1l1l(title, l1ll11l1 (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1ll11l1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1111l11 as e:
        title = l1ll11l1 (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l111l1l1l(title, l1ll11l1 (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1ll11l1 (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1l1lll:
        logger.info(l1ll11l1 (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1ll11l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1ll1111
        logger.exception(l1ll11l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l111l1l1l(title, l1ll11l1 (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l1ll1111l=l11ll11l.get_value(l1ll11l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1ll11l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1ll11l1 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()