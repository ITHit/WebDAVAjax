#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import sys, json
import os
import urllib
import l1lll111
from l1l11l import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1l11l import l1l11l1l, logger, l11ll1ll
from cookies import l111ll11 as l11l1111l
from l1ll111l import l1l1
l11lllll1 = None
from l1l1l11 import *
class l1l1ll1ll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l111lll (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1ll1l111):
        self.config = l1ll1l111
        self.l1111111l = l1lll111.l1ll()
    def l11llllll(self):
        data = platform.uname()
        logger.info(l111lll (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l111lll (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l111lll (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l111lll (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1l1l1l1l():
    def __init__(self, encode = True):
        self._encode = encode
        self._111llll1 = [l111lll (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l111lll11 = None
        self.l111l1l1l = None
        self.l111l111l = None
        self.l11llll1l = None
        self.l111 = None
        self.l11l11lll = None
        self.l11l111l1 = None
        self.l11l1llll = None
        self.cookies = None
    def l11l1ll1l(self, url):
        l111lll (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l111lll (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._11l1l1ll(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111lllll(url)
        self.dict = self._1ll111l1(params)
        logger.info(l111lll (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1ll1111l(self.dict):
            raise l1llll1ll(l111lll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._111llll1)
        self._1ll1llll(self.dict)
        if self._encode:
            self.l1lll111l()
        self._1ll1l1l1()
        self._1111lll1()
        self._1111l111()
        self._1l1ll11l()
        self.l1l1l1111()
        logger.info(l111lll (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l111lll (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l111lll11))
        logger.info(l111lll (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l111l1l1l))
        logger.info(l111lll (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l111l111l))
        logger.info(l111lll (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l11llll1l))
        logger.info(l111lll (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l111))
        logger.info(l111lll (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l11l11lll))
        logger.info(l111lll (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l11l111l1))
        logger.info(l111lll (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l11l1llll))
    def _1ll1llll(self, l1l1lll1l):
        self.l111lll11 = l1l1lll1l.get(l111lll (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l111l1l1l = l1l1lll1l.get(l111lll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l111lll (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l111l111l = l1l1lll1l.get(l111lll (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l11llll1l = l1l1lll1l.get(l111lll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l111 = l1l1lll1l.get(l111lll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l11l11lll = l1l1lll1l.get(l111lll (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l11l111l1 = l1l1lll1l.get(l111lll (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l111lll (u"ࠣࠤ࣏"))
        self.l11l1llll = l1l1lll1l.get(l111lll (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l111lll (u"࣑ࠥࠦ"))
        self.cookies = l1l1lll1l.get(l111lll (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1l1l1111(self):
        l111lll1l = False
        if self.l111:
            if self.l111.upper() == l111lll (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l111 = l111lll (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l111.upper() == l111lll (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l111 = l111lll (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l111.upper() == l111lll (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l111 = l111lll (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l111.upper() == l111lll (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l111 = l111lll (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l111 == l111lll (u"ࠨࠢࣛ"):
                l111lll1l = True
            else:
                self.l111 = self.l111.lower()
        else:
            l111lll1l = True
        if l111lll1l:
            self.l111 = l111lll (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l1lll111l(self):
        l111lll (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l111lll (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11l11l1l = []
                    for el in self.__dict__.get(key):
                        l11l11l1l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11l11l1l
    def l111ll1l1(self, l1ll1ll11):
        res = l1ll1ll11
        if self._encode:
            res = urllib.parse.quote(l1ll1ll11, safe=l111lll (u"ࠥࠦࣟ"))
        return res
    def _11l1l1ll(self, url):
        l111lll (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l111lll (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l111lll (u"ࠨ࠺ࠣ࣢")), l111lll (u"ࠧࠨࣣ"), url)
        return url
    def _111lllll(self, url):
        l111lll (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l1lll1111 = url.split(l111lll (u"ࠤࡾ࠴ࢂࠨࣥ").format(l111lll (u"ࠥ࠿ࣦࠧ")))
        result = l1lll1111
        if len(result) == 0:
            raise l1111111(l111lll (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1ll111l1(self, params):
        l111lll (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l111lll (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l111lll (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l11l111 = data.group(l111lll (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l11l111 in (l111lll (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l111lll (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l111lll (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l111lll (u"ࠧ࠲࣯ࠢ"))
                elif l1l11l111 == l111lll (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l111lll (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l111lll (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l11l111] = value
        return result
    def _1l111ll1(self, url, scheme):
        l111lll (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1ll11111 = {l111lll (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l111lll (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l1ll1lll1 = url.split(l111lll (u"ࠧࡀࣶࠢ"))
        if len(l1ll1lll1) == 1:
            for l1l1llll1 in list(l1ll11111.keys()):
                if l1l1llll1 == scheme:
                    url += l111lll (u"ࠨ࠺ࠣࣷ") + str(l1ll11111[l1l1llll1])
                    break
        return url
    def _1ll1l1l1(self):
        l111lll (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l11llll1l:
            l1l11ll11 = self.l11llll1l[0]
            l1l111111 = urlparse(l1l11ll11)
        if self.l111lll11:
            l1l11llll = urlparse(self.l111lll11)
            if l1l11llll.scheme:
                l1l11111l = l1l11llll.scheme
            else:
                if l1l111111.scheme:
                    l1l11111l = l1l111111.scheme
                else:
                    raise l1llllll1(
                        l111lll (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l11llll.netloc:
                l1l1l1l11 = l1l11llll.netloc
            else:
                if l1l111111.netloc:
                    l1l1l1l11 = l1l111111.netloc
                else:
                    raise l1llllll1(
                        l111lll (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1l1l1l11 = self._1l111ll1(l1l1l1l11, l1l11111l)
            path = l1l11llll.path
            if not path.endswith(l111lll (u"ࠪ࠳ࠬࣻ")):
                path += l111lll (u"ࠫ࠴࠭ࣼ")
            l111l1111 = ParseResult(scheme=l1l11111l, netloc=l1l1l1l11, path=path,
                                         params=l1l11llll.params, query=l1l11llll.query,
                                         fragment=l1l11llll.fragment)
            self.l111lll11 = l111l1111.geturl()
        else:
            if not l1l111111.netloc:
                raise l1llllll1(l111lll (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11l11111 = l1l111111.path
            l111ll1ll = l111lll (u"ࠨ࠯ࠣࣾ").join(l11l11111.split(l111lll (u"ࠢ࠰ࠤࣿ"))[:-1]) + l111lll (u"ࠣ࠱ࠥऀ")
            l111l1111 = ParseResult(scheme=l1l111111.scheme,
                                         netloc=self._1l111ll1(l1l111111.netloc, l1l111111.scheme),
                                         path=l111ll1ll,
                                         params=l111lll (u"ࠤࠥँ"),
                                         query=l111lll (u"ࠥࠦं"),
                                         fragment=l111lll (u"ࠦࠧः")
                                         )
            self.l111lll11 = l111l1111.geturl()
    def _1111l111(self):
        l111lll (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l11llll1l:
            l1l11ll11 = self.l11llll1l[0]
            l1l111111 = urlparse(l1l11ll11)
        if self.l11l11lll:
            l1ll111ll = urlparse(self.l11l11lll)
            if l1ll111ll.scheme:
                l11ll11l1 = l1ll111ll.scheme
            else:
                l11ll11l1 = l1l111111.scheme
            if l1ll111ll.netloc:
                l1l1l1lll = l1ll111ll.netloc
            else:
                l1l1l1lll = l1l111111.netloc
            l11llll11 = ParseResult(scheme=l11ll11l1, netloc=l1l1l1lll, path=l1ll111ll.path,
                                      params=l1ll111ll.params, query=l1ll111ll.query,
                                      fragment=l1ll111ll.fragment)
            self.l11l11lll = l11llll11.geturl()
    def _1111lll1(self):
        l111lll (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l11llll1l
        self.l11llll1l = []
        for item in items:
            l1l11ll1l = urlparse(item.strip(), scheme=l111lll (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l1l11ll1l.path[-1] == l111lll (u"ࠣ࠱ࠥइ"):
                l11lll1ll = l1l11ll1l.path
            else:
                path_list = l1l11ll1l.path.split(l111lll (u"ࠤ࠲ࠦई"))
                l11lll1ll = l111lll (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l111lll (u"ࠦ࠴ࠨऊ")
            l11l1lll1 = urlparse(self.l111lll11, scheme=l111lll (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l1l11ll1l.scheme:
                scheme = l1l11ll1l.scheme
            elif l11l1lll1.scheme:
                scheme = l11l1lll1.scheme
            else:
                scheme = l111lll (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l1l11ll1l.netloc and not l11l1lll1.netloc:
                l1ll11l1l = l1l11ll1l.netloc
            elif not l1l11ll1l.netloc and l11l1lll1.netloc:
                l1ll11l1l = l11l1lll1.netloc
            elif not l1l11ll1l.netloc and not l11l1lll1.netloc and len(self.l11llll1l) > 0:
                l111ll111 = urlparse(self.l11llll1l[len(self.l11llll1l) - 1])
                l1ll11l1l = l111ll111.netloc
            elif l11l1lll1.netloc:
                l1ll11l1l = l1l11ll1l.netloc
            elif not l11l1lll1.netloc:
                l1ll11l1l = l1l11ll1l.netloc
            if l1l11ll1l.path:
                l1lll11l1 = l1l11ll1l.path
            if l1ll11l1l:
                l1ll11l1l = self._1l111ll1(l1ll11l1l, scheme)
                l11111l1l = ParseResult(scheme=scheme, netloc=l1ll11l1l, path=l1lll11l1,
                                          params=l1l11ll1l.params,
                                          query=l1l11ll1l.query,
                                          fragment=l1l11ll1l.fragment)
                self.l11llll1l.append(l11111l1l.geturl())
    def _1l1ll11l(self):
        l111lll (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l111ll11l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l1l1(l111lll (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l111ll11l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l1l1(l111lll (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l111l111l:
            l1ll11l11 = []
            for l1l1l11ll in self.l111l111l:
                if l1l1l11ll not in [x[l111lll (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l1ll11l11.append(l1l1l11ll)
            if l1ll11l11:
                l1l11ll1 = l111lll (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l111lll (u"ࠧ࠲ࠠࠣऒ").join(l1ll11l11))
                raise l111l1l1(l111lll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l11ll1)
    def l1ll1111l(self, params):
        l111lll (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1l1ll1l1 = True
        for param in self._111llll1:
            if not params.get(param.lower()):
                l1l1ll1l1 = False
        return l1l1ll1l1
class l1ll11lll():
    def __init__(self, l1111ll11):
        self.l111l1lll = l1lll111.l1ll()
        self.l1l1l111l = self.l11l1l11l()
        self.l11111111 = self.l1111l1l1()
        self.l1111ll11 = l1111ll11
        self._11ll1111 = [l111lll (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l111lll (u"ࠤࡑࡳࡳ࡫ࠢख"), l111lll (u"ࠥࡅࡱࡲࠢग"), l111lll (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l111lll (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l111lll (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l111lll (u"ࠢࡊࡇࠥछ"), l111lll (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1l1111l1 = [l111lll (u"ࠤ࡙࡭ࡪࡽࠢझ"), l111lll (u"ࠥࡉࡩ࡯ࡴࠣञ"), l111lll (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l111lll (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l111l1l11 = None
    def l11l1l11l(self):
        l1l11lll1 = l111lll (u"ࠨࡎࡰࡰࡨࠦड")
        return l1l11lll1
    def l1111l1l1(self):
        l1l11l1l1 = 0
        return l1l11l1l1
    def l1l1l1ll1(self):
        l1l11ll1 = l111lll (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l11111111)
        l1l11ll1 += l111lll (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11lll1l1(l1l11l1l, l1l11ll1, t=1)
        return res
    def run(self):
        l11l111ll = True
        self._11111l11()
        result = []
        try:
            for cookie in l11l1111l(l111l11l=self.l1111ll11.cookies).run():
                result.append(cookie)
        except l1lll11ll as e:
            logger.exception(l111lll (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l11ll11ll = self._1111l11l(result)
            if l11ll11ll:
                logger.info(l111lll (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l11ll11ll)
                self.l111l1l11 = l11ll11ll
            else:
                logger.info(l111lll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l11ll11ll)
            l11l111ll = True
        else:
            l11l111ll = False
        return l11l111ll
    def _1111l11l(self, l1l1l11l1):
        res = False
        l111l1l = os.path.join(os.environ[l111lll (u"ࠬࡎࡏࡎࡇࠪध")], l111lll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l111lll (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11l11ll1 = {}
        for cookies in l1l1l11l1:
            l11l11ll1[cookies.name] = cookies.value
        l11ll1ll1 = l111lll (u"ࠣࠤप")
        for key in list(l11l11ll1.keys()):
            l11ll1ll1 += l111lll (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11l11ll1[key].strip())
        if not os.path.exists(os.path.dirname(l111l1l)):
            os.makedirs(os.path.dirname(l111l1l))
        vers = int(l111lll (u"ࠥࠦब").join(self.l111l1lll.split(l111lll (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l111l11ll = [l111lll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l111lll (u"ࠨࠣࠡࠤय") + l111lll (u"ࠢ࠮ࠤर") * 60,
                              l111lll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l111lll (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l111lll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11ll1ll1),
                              l111lll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l111l11ll = [l111lll (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l111lll (u"ࠨࠣࠡࠤश") + l111lll (u"ࠢ࠮ࠤष") * 60,
                              l111lll (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l111lll (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l111lll (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11ll1ll1),
                              l111lll (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l111l1l, l111lll (u"ࠧࡽ़ࠢ")) as l11lll111:
            data = l111lll (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l111l11ll)
            l11lll111.write(data)
            l11lll111.write(l111lll (u"ࠢ࡝ࡰࠥा"))
        res = l111l1l
        return res
    def _11111l11(self):
        self._111111l1(l111lll (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1l11l1ll()
    def _111111l1(self, l11ll111l):
        l1l111l1l = self.l1111ll11.dict[l11ll111l.lower()]
        if l1l111l1l:
            if isinstance(l1l111l1l, list):
                l111111ll = l1l111l1l
            else:
                l111111ll = [l1l111l1l]
            if l111lll (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11ll111l.lower():
                    for l11l11l11 in l111111ll:
                        l1llllllll = [l1ll1l1ll.upper() for l1ll1l1ll in self._11ll1111]
                        if not l11l11l11.upper() in l1llllllll:
                            l1ll11ll1 = l111lll (u"ࠥ࠰ࠥࠨु").join(self._11ll1111)
                            l1ll1l11l = l111lll (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11ll111l, l1l111l1l, l1ll11ll1, )
                            raise l11111l1(l1ll1l11l)
    def _1l11l1ll(self):
        l111l11l1 = []
        l11ll1l11 = self.l1111ll11.l111l111l
        for l11lll11l in self._11ll1111:
            if not l11lll11l in [l111lll (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l111lll (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l111l11l1.append(l11lll11l)
        for l11111lll in self.l1111ll11.l111l1l1l:
            if l11111lll in l111l11l1 and not l11ll1l11:
                l1ll1l11l = l111lll (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l11111l1(l1ll1l11l)
def l1l1ll111(title, message, l1l1111ll, l1l11l11l=None):
    l1111llll = l1l111l11()
    l1111llll.l111l1ll1(message, title, l1l1111ll, l1l11l11l)
def l11l1ll11(title, message, l1l1111ll):
    l1l1lllll = l1l1lll11()
    l1l1lllll.l1l111lll(title, message, l1l1111ll)
    res = l1l1lllll.result
    return res
def main():
    try:
        logger.info(l111lll (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11ll1ll)
        system.l11llllll()
        logger.info(l111lll (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1llll1ll(
                l111lll (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l11ll1lll = l1l1l1l1l()
        l11ll1lll.l11l1ll1l(l111lll (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1111ll1l = [item.upper() for item in l11ll1lll.l111l1l1l]
        l1111l1ll = l111lll (u"ࠧࡔࡏࡏࡇࠥॊ") in l1111ll1l
        if l1111l1ll:
            logger.info(l111lll (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l11ll1l1l = l11ll1lll.l11llll1l
            for l1l11ll in l11ll1l1l:
                logger.debug(l111lll (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1l11ll))
                opener = l1l1(l11ll1lll.l111lll11, l1l11ll, l111l1l=None, l1l=l11ll1ll)
                opener.open()
                logger.info(l111lll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11l1l1l1 = l1ll11lll(l11ll1lll)
            l11l1l111 = l11l1l1l1.run()
            l11ll1l1l = l11ll1lll.l11llll1l
            for l1l11ll in l11ll1l1l:
                logger.info(l111lll (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1l11ll))
                opener = l1l1(l11ll1lll.l111lll11, l1l11ll, l111l1l=l11l1l1l1.l111l1l11,
                                l1l=l11ll1ll)
                opener.open()
                logger.info(l111lll (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l1lllll as e:
        title = l111lll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l11l1l
        logger.exception(l111lll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11111ll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11111ll1 = el
        l1ll1ll1l = l111lll (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l1l111l, message.strip())
        l1l1ll111(title, l1ll1ll1l, l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l111lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1l11l11l=l11111ll1)
        sys.exit(2)
    except l1llll11l as e:
        title = l111lll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l11l1l
        logger.exception(l111lll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11111ll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11111ll1 = el
        l1ll1ll1l = l111lll (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1l1ll111(title, l1ll1ll1l, l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l111lll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1l11l11l=l11111ll1)
        sys.exit(2)
    except l1llll1ll as e:
        title = l111lll (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l11l1l
        logger.exception(l111lll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1l1ll111(title, str(e), l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l111lll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l111lll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l11l1l
        logger.exception(l111lll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1l1ll111(title, l111lll (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l111lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l11111l1 as e:
        title = l111lll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l11l1l
        logger.exception(l111lll (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1l1ll111(title, l111lll (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l111lll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1ll1 as e:
        title = l111lll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l11l1l
        logger.exception(l111lll (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1l1ll111(title, l111lll (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l111lll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1ll11ll:
        logger.info(l111lll (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l111lll (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l11l1l
        logger.exception(l111lll (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1l1ll111(title, l111lll (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l1l1111ll=l11ll1ll.get_value(l111lll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l111lll (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l111lll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()