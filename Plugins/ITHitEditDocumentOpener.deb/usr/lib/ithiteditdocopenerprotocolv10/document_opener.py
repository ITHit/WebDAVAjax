#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111lll = 2048
l1lll11 = 7
def l1l1l11 (l1l11):
    global l111l
    l1ll1l11 = ord (l1l11 [-1])
    l11l = l1l11 [:-1]
    l1lll = l1ll1l11 % len (l11l)
    l1lll11l = l11l [:l1lll] + l11l [l1lll:]
    if l1ll1l:
        l11ll1l = l1llll1l () .join ([unichr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    return eval (l11ll1l)
import sys, json
import os
import urllib
import l1l1ll
from l11ll11 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1111l import l1l111ll, logger, l1l1ll11
from cookies import l11ll111 as l1111ll11
from l111 import l1111l1
l1l11l1l1 = None
from l1111ll import *
class l11llllll():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l1l11 (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1l1l1l11):
        self.config = l1l1l1l11
        self.l1l11ll11 = l1l1ll.l1l11ll()
    def l11ll1l1l(self):
        data = platform.uname()
        logger.info(l1l1l11 (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1l1l11 (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1l1l11 (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1l1l11 (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l11l1l111():
    def __init__(self, encode = True):
        self._encode = encode
        self._111l1lll = [l1l1l11 (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l11llll1l = None
        self.l1ll11ll1 = None
        self.l111l1ll1 = None
        self.l1lll111l = None
        self.l1ll11ll = None
        self.l11ll1111 = None
        self.l11ll1ll1 = None
        self.l1l1l1l1l = None
        self.cookies = None
    def l1111llll(self, url):
        l1l1l11 (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1l1l11 (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._11llll11(url)
        url = urllib.parse.unquote_plus(url)
        params = self._11l111l1(url)
        self.dict = self._11111ll1(params)
        logger.info(l1l1l11 (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l111l111l(self.dict):
            raise l1llll1l1(l1l1l11 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._111l1lll)
        self._11l1ll1l(self.dict)
        if self._encode:
            self.l1111l111()
        self._1l1l111l()
        self._11lll111()
        self._11ll111l()
        self._1l1lll11()
        self.l111l11l1()
        logger.info(l1l1l11 (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1l1l11 (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l11llll1l))
        logger.info(l1l1l11 (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l1ll11ll1))
        logger.info(l1l1l11 (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l111l1ll1))
        logger.info(l1l1l11 (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l1lll111l))
        logger.info(l1l1l11 (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l1ll11ll))
        logger.info(l1l1l11 (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l11ll1111))
        logger.info(l1l1l11 (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l11ll1ll1))
        logger.info(l1l1l11 (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l1l1l1l1l))
    def _11l1ll1l(self, l1l1ll11l):
        self.l11llll1l = l1l1ll11l.get(l1l1l11 (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l1ll11ll1 = l1l1ll11l.get(l1l1l11 (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1l1l11 (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l111l1ll1 = l1l1ll11l.get(l1l1l11 (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l1lll111l = l1l1ll11l.get(l1l1l11 (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l1ll11ll = l1l1ll11l.get(l1l1l11 (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l11ll1111 = l1l1ll11l.get(l1l1l11 (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l11ll1ll1 = l1l1ll11l.get(l1l1l11 (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1l1l11 (u"ࠨࠢ࣍"))
        self.l1l1l1l1l = l1l1ll11l.get(l1l1l11 (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1l1l11 (u"ࠣࠤ࣏"))
        self.cookies = l1l1ll11l.get(l1l1l11 (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l111l11l1(self):
        l1ll11111 = False
        if self.l1ll11ll:
            if self.l1ll11ll.upper() == l1l1l11 (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l1ll11ll = l1l1l11 (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l1ll11ll.upper() == l1l1l11 (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l1ll11ll = l1l1l11 (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l1ll11ll.upper() == l1l1l11 (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l1ll11ll = l1l1l11 (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l1ll11ll.upper() == l1l1l11 (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l1ll11ll = l1l1l11 (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l1ll11ll == l1l1l11 (u"ࠦࠧࣙ"):
                l1ll11111 = True
            else:
                self.l1ll11ll = self.l1ll11ll.lower()
        else:
            l1ll11111 = True
        if l1ll11111:
            self.l1ll11ll = l1l1l11 (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l1111l111(self):
        l1l1l11 (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l1l11 (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l111111l1 = []
                    for el in self.__dict__.get(key):
                        l111111l1.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l111111l1
    def l11l1l1ll(self, l1l1l1lll):
        res = l1l1l1lll
        if self._encode:
            res = urllib.parse.quote(l1l1l1lll, safe=l1l1l11 (u"ࠣࠤࣝ"))
        return res
    def _11llll11(self, url):
        l1l1l11 (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1l1l11 (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1l1l11 (u"ࠦ࠿ࠨ࣠")), l1l1l11 (u"ࠬ࠭࣡"), url)
        return url
    def _11l111l1(self, url):
        l1l1l11 (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l1lll1l11 = url.split(l1l1l11 (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1l1l11 (u"ࠣ࠽ࠥࣤ")))
        result = l1lll1l11
        if len(result) == 0:
            raise l1llllll1(l1l1l11 (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _11111ll1(self, params):
        l1l1l11 (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1l1l11 (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1l1l11 (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1lll11ll = data.group(l1l1l11 (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l1lll11ll in (l1l1l11 (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1l1l11 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1l1l11 (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1l1l11 (u"ࠥ࠰࣭ࠧ"))
                elif l1lll11ll == l1l1l11 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1l1l11 (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l1l11 (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l1lll11ll] = value
        return result
    def _1l11ll1l(self, url, scheme):
        l1l1l11 (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l1ll1l1l1 = {l1l1l11 (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1l1l11 (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l1l11l111 = url.split(l1l1l11 (u"ࠥ࠾ࠧࣴ"))
        if len(l1l11l111) == 1:
            for l11111l1l in list(l1ll1l1l1.keys()):
                if l11111l1l == scheme:
                    url += l1l1l11 (u"ࠦ࠿ࠨࣵ") + str(l1ll1l1l1[l11111l1l])
                    break
        return url
    def _1l1l111l(self):
        l1l1l11 (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l1lll111l:
            l111lllll = self.l1lll111l[0]
            l11l11l1l = urlparse(l111lllll)
        if self.l11llll1l:
            l1l1lll1l = urlparse(self.l11llll1l)
            if l1l1lll1l.scheme:
                l1ll1lll1 = l1l1lll1l.scheme
            else:
                if l11l11l1l.scheme:
                    l1ll1lll1 = l11l11l1l.scheme
                else:
                    raise l11111ll(
                        l1l1l11 (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l1l1lll1l.netloc:
                l11l1lll1 = l1l1lll1l.netloc
            else:
                if l11l11l1l.netloc:
                    l11l1lll1 = l11l11l1l.netloc
                else:
                    raise l11111ll(
                        l1l1l11 (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l11l1lll1 = self._1l11ll1l(l11l1lll1, l1ll1lll1)
            path = l1l1lll1l.path
            if not path.endswith(l1l1l11 (u"ࠨ࠱ࣹࠪ")):
                path += l1l1l11 (u"ࠩ࠲ࣺࠫ")
            l1ll1111l = ParseResult(scheme=l1ll1lll1, netloc=l11l1lll1, path=path,
                                         params=l1l1lll1l.params, query=l1l1lll1l.query,
                                         fragment=l1l1lll1l.fragment)
            self.l11llll1l = l1ll1111l.geturl()
        else:
            if not l11l11l1l.netloc:
                raise l11111ll(l1l1l11 (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l11ll1l11 = l11l11l1l.path
            l11l1l11l = l1l1l11 (u"ࠦ࠴ࠨࣼ").join(l11ll1l11.split(l1l1l11 (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1l1l11 (u"ࠨ࠯ࠣࣾ")
            l1ll1111l = ParseResult(scheme=l11l11l1l.scheme,
                                         netloc=self._1l11ll1l(l11l11l1l.netloc, l11l11l1l.scheme),
                                         path=l11l1l11l,
                                         params=l1l1l11 (u"ࠢࠣࣿ"),
                                         query=l1l1l11 (u"ࠣࠤऀ"),
                                         fragment=l1l1l11 (u"ࠤࠥँ")
                                         )
            self.l11llll1l = l1ll1111l.geturl()
    def _11ll111l(self):
        l1l1l11 (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l1lll111l:
            l111lllll = self.l1lll111l[0]
            l11l11l1l = urlparse(l111lllll)
        if self.l11ll1111:
            l1111ll1l = urlparse(self.l11ll1111)
            if l1111ll1l.scheme:
                l1l11111l = l1111ll1l.scheme
            else:
                l1l11111l = l11l11l1l.scheme
            if l1111ll1l.netloc:
                l11l1111l = l1111ll1l.netloc
            else:
                l11l1111l = l11l11l1l.netloc
            l1ll11l1l = ParseResult(scheme=l1l11111l, netloc=l11l1111l, path=l1111ll1l.path,
                                      params=l1111ll1l.params, query=l1111ll1l.query,
                                      fragment=l1111ll1l.fragment)
            self.l11ll1111 = l1ll11l1l.geturl()
    def _11lll111(self):
        l1l1l11 (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l1lll111l
        self.l1lll111l = []
        for item in items:
            l1ll1l111 = urlparse(item.strip(), scheme=l1l1l11 (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l1ll1l111.path[-1] == l1l1l11 (u"ࠨ࠯ࠣअ"):
                l1l11lll1 = l1ll1l111.path
            else:
                path_list = l1ll1l111.path.split(l1l1l11 (u"ࠢ࠰ࠤआ"))
                l1l11lll1 = l1l1l11 (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1l1l11 (u"ࠤ࠲ࠦई")
            l1lll1111 = urlparse(self.l11llll1l, scheme=l1l1l11 (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l1ll1l111.scheme:
                scheme = l1ll1l111.scheme
            elif l1lll1111.scheme:
                scheme = l1lll1111.scheme
            else:
                scheme = l1l1l11 (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l1ll1l111.netloc and not l1lll1111.netloc:
                l11ll1lll = l1ll1l111.netloc
            elif not l1ll1l111.netloc and l1lll1111.netloc:
                l11ll1lll = l1lll1111.netloc
            elif not l1ll1l111.netloc and not l1lll1111.netloc and len(self.l1lll111l) > 0:
                l111ll1l1 = urlparse(self.l1lll111l[len(self.l1lll111l) - 1])
                l11ll1lll = l111ll1l1.netloc
            elif l1lll1111.netloc:
                l11ll1lll = l1ll1l111.netloc
            elif not l1lll1111.netloc:
                l11ll1lll = l1ll1l111.netloc
            if l1ll1l111.path:
                l1l1111l1 = l1ll1l111.path
            if l11ll1lll:
                l11ll1lll = self._1l11ll1l(l11ll1lll, scheme)
                l11l111ll = ParseResult(scheme=scheme, netloc=l11ll1lll, path=l1l1111l1,
                                          params=l1ll1l111.params,
                                          query=l1ll1l111.query,
                                          fragment=l1ll1l111.fragment)
                self.l1lll111l.append(l11l111ll.geturl())
    def _1l1lll11(self):
        l1l1l11 (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l1111l1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1l1l(l1l1l11 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l1111l1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l11l1l1l(l1l1l11 (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l111l1ll1:
            l1l1ll111 = []
            for l1ll1llll in self.l111l1ll1:
                if l1ll1llll not in [x[l1l1l11 (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l1l1ll111.append(l1ll1llll)
            if l1l1ll111:
                l1l11l11 = l1l1l11 (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1l1l11 (u"ࠥ࠰ࠥࠨऐ").join(l1l1ll111))
                raise l11l1l1l(l1l1l11 (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1l11l11)
    def l111l111l(self, params):
        l1l1l11 (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1l11l11l = True
        for param in self._111l1lll:
            if not params.get(param.lower()):
                l1l11l11l = False
        return l1l11l11l
class l11l11l11():
    def __init__(self, l1ll1ll1l):
        self.l1l11l1ll = l1l1ll.l1l11ll()
        self.l1ll111ll = self.l1111l1l1()
        self.l1ll11l11 = self.l111111ll()
        self.l1ll1ll1l = l1ll1ll1l
        self._111ll11l = [l1l1l11 (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1l1l11 (u"ࠢࡏࡱࡱࡩࠧऔ"), l1l1l11 (u"ࠣࡃ࡯ࡰࠧक"), l1l1l11 (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1l1l11 (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1l1l11 (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1l1l11 (u"ࠧࡏࡅࠣङ"), l1l1l11 (u"ࠨࡅࡥࡩࡨࠦच")]
        self._111l11ll = [l1l1l11 (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1l1l11 (u"ࠣࡇࡧ࡭ࡹࠨज"), l1l1l11 (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1l1l11 (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l1l1l1111 = None
    def l1111l1l1(self):
        l111lll11 = l1l1l11 (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l111lll11
    def l111111ll(self):
        l1lll11l1 = 0
        return l1lll11l1
    def l11l11lll(self):
        l1l11l11 = l1l1l11 (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l1ll11l11)
        l1l11l11 += l1l1l11 (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l1ll1l11l(l1l111ll, l1l11l11, t=1)
        return res
    def run(self):
        l11l1llll = True
        self._1ll1l1ll()
        result = []
        try:
            for cookie in l1111ll11(l111ll1l=self.l1ll1ll1l.cookies).run():
                result.append(cookie)
        except l1llll11l as e:
            logger.exception(l1l1l11 (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l1l1l1ll1 = self._111llll1(result)
            if l1l1l1ll1:
                logger.info(l1l1l11 (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l1l1l1ll1)
                self.l1l1l1111 = l1l1l1ll1
            else:
                logger.info(l1l1l11 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l1l1l1ll1)
            l11l1llll = True
        else:
            l11l1llll = False
        return l11l1llll
    def _111llll1(self, l1l1l11ll):
        res = False
        l11l1l1 = os.path.join(os.environ[l1l1l11 (u"ࠪࡌࡔࡓࡅࠨथ")], l1l1l11 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1l1l11 (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1111l11l = {}
        for cookies in l1l1l11ll:
            l1111l11l[cookies.name] = cookies.value
        l1l1ll1ll = l1l1l11 (u"ࠨࠢन")
        for key in list(l1111l11l.keys()):
            l1l1ll1ll += l1l1l11 (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1111l11l[key].strip())
        if not os.path.exists(os.path.dirname(l11l1l1)):
            os.makedirs(os.path.dirname(l11l1l1))
        vers = int(l1l1l11 (u"ࠣࠤप").join(self.l1l11l1ll.split(l1l1l11 (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l111lll1l = [l1l1l11 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1l1l11 (u"ࠦࠨࠦࠢभ") + l1l1l11 (u"ࠧ࠳ࠢम") * 60,
                              l1l1l11 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1l1l11 (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1l1l11 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l1l1ll1ll),
                              l1l1l11 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l111lll1l = [l1l1l11 (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1l1l11 (u"ࠦࠨࠦࠢऴ") + l1l1l11 (u"ࠧ࠳ࠢव") * 60,
                              l1l1l11 (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1l1l11 (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1l1l11 (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l1l1ll1ll),
                              l1l1l11 (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l11l1l1, l1l1l11 (u"ࠥࡻࠧऺ")) as l1l111l11:
            data = l1l1l11 (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l111lll1l)
            l1l111l11.write(data)
            l1l111l11.write(l1l1l11 (u"ࠧࡢ࡮़ࠣ"))
        res = l11l1l1
        return res
    def _1ll1l1ll(self):
        self._1l1llll1(l1l1l11 (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._1l1ll1l1()
    def _1l1llll1(self, l11l11ll1):
        l1l111lll = self.l1ll1ll1l.dict[l11l11ll1.lower()]
        if l1l111lll:
            if isinstance(l1l111lll, list):
                l111l1l11 = l1l111lll
            else:
                l111l1l11 = [l1l111lll]
            if l1l1l11 (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l11l11ll1.lower():
                    for l11lll1l1 in l111l1l11:
                        l1l11llll = [l1l1111ll.upper() for l1l1111ll in self._111ll11l]
                        if not l11lll1l1.upper() in l1l11llll:
                            l11ll11l1 = l1l1l11 (u"ࠣ࠮ࠣࠦि").join(self._111ll11l)
                            l1111lll1 = l1l1l11 (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l11l11ll1, l1l111lll, l11ll11l1, )
                            raise l1llll111(l1111lll1)
    def _1l1ll1l1(self):
        l11ll11ll = []
        l111l1111 = self.l1ll1ll1l.l111l1ll1
        for l11l1ll11 in self._111ll11l:
            if not l11l1ll11 in [l1l1l11 (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1l1l11 (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l11ll11ll.append(l11l1ll11)
        for l111l1l1l in self.l1ll1ll1l.l1ll11ll1:
            if l111l1l1l in l11ll11ll and not l111l1111:
                l1111lll1 = l1l1l11 (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1llll111(l1111lll1)
def l11l1l1l1(title, message, l11111l11, l1ll1ll11=None):
    l1ll111l1 = l1l1l11l1()
    l1ll111l1.l1ll11lll(message, title, l11111l11, l1ll1ll11)
def l1l111111(title, message, l11111l11):
    l11lll1ll = l1l1lllll()
    l11lll1ll.l1111111l(title, message, l11111l11)
    res = l11lll1ll.result
    return res
def main():
    try:
        logger.info(l1l1l11 (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l1l1ll11)
        system.l11ll1l1l()
        logger.info(l1l1l11 (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1llll1l1(
                l1l1l11 (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l111ll111 = l11l1l111()
        l111ll111.l1111llll(l1l1l11 (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l1l111ll1 = [item.upper() for item in l111ll111.l1ll11ll1]
        l1l111l1l = l1l1l11 (u"ࠥࡒࡔࡔࡅࠣै") in l1l111ll1
        if l1l111l1l:
            logger.info(l1l1l11 (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l11lll11l = l111ll111.l1lll111l
            for l1ll1ll1 in l11lll11l:
                logger.debug(l1l1l11 (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l1ll1ll1))
                opener = l1111l1(l111ll111.l11llll1l, l1ll1ll1, l11l1l1=None, l11lll1=l1l1ll11)
                opener.open()
                logger.info(l1l1l11 (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l11lllll1 = l11l11l11(l111ll111)
            l11l11111 = l11lllll1.run()
            l11lll11l = l111ll111.l1lll111l
            for l1ll1ll1 in l11lll11l:
                logger.info(l1l1l11 (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l1ll1ll1))
                opener = l1111l1(l111ll111.l11llll1l, l1ll1ll1, l11l1l1=l11lllll1.l1l1l1111,
                                l11lll1=l1l1ll11)
                opener.open()
                logger.info(l1l1l11 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1lllll1 as e:
        title = l1l1l11 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1l111ll
        logger.exception(l1l1l11 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l11111lll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11111lll = el
        l111ll1ll = l1l1l11 (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l11l11l, message.strip())
        l11l1l1l1(title, l111ll1ll, l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1l1l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l1ll1ll11=l11111lll)
        sys.exit(2)
    except l11111l1 as e:
        title = l1l1l11 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1l111ll
        logger.exception(l1l1l11 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l11111lll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11111lll = el
        l111ll1ll = l1l1l11 (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l11l1l1l1(title, l111ll1ll, l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1l1l11 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l1ll1ll11=l11111lll)
        sys.exit(2)
    except l1llll1l1 as e:
        title = l1l1l11 (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1l111ll
        logger.exception(l1l1l11 (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l11l1l1l1(title, str(e), l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1l1l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1l1l11 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1l111ll
        logger.exception(l1l1l11 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l11l1l1l1(title, l1l1l11 (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1l1l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1llll111 as e:
        title = l1l1l11 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1l111ll
        logger.exception(l1l1l11 (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l11l1l1l1(title, l1l1l11 (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1l1l11 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1lllll1l as e:
        title = l1l1l11 (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1l111ll
        logger.exception(l1l1l11 (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l11l1l1l1(title, l1l1l11 (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1l1l11 (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1lll1l:
        logger.info(l1l1l11 (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1l1l11 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1l111ll
        logger.exception(l1l1l11 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l11l1l1l1(title, l1l1l11 (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l11111l11=l1l1ll11.get_value(l1l1l11 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1l1l11 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l1l11 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()