#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l1ll1l1 = 2048
l1lll1l1 = 7
def l1l1ll (l1ll1l1l):
    global l111l1
    l1l11l1 = ord (l1ll1l1l [-1])
    l1lll1l = l1ll1l1l [:-1]
    l1llll1 = l1l11l1 % len (l1lll1l)
    ll = l1lll1l [:l1llll1] + l1lll1l [l1llll1:]
    if l1l1111:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    return eval (l1111)
import sys, json
import os
import urllib
import l11ll
from l1lll11l import *
import platform
from urllib.parse import urlparse, ParseResult
from l11ll11l import l1ll1111, logger, l1l1l1l1
from cookies import l111l11l as l1111l1l1
from l1lll1ll import l1ll11
l11l111ll = None
from l11ll1 import *
class l1l1lll1l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1l1ll (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l1111l111):
        self.config = l1111l111
        self.l1l111lll = l11ll.l11111()
    def l111l1ll1(self):
        data = platform.uname()
        logger.info(l1l1ll (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1l1ll (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1l1ll (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1l1ll (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1l1l11l1():
    def __init__(self, encode = True):
        self._encode = encode
        self._1ll11l11 = [l1l1ll (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l1l1l1111 = None
        self.l11l1l1l1 = None
        self.l1l11l11l = None
        self.l11l1l1ll = None
        self.l1lllll1 = None
        self.l1ll1l1ll = None
        self.l1ll111l1 = None
        self.l1111l1ll = None
        self.cookies = None
    def l1111ll11(self, url):
        l1l1ll (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1l1ll (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._11l1ll11(url)
        url = urllib.parse.unquote_plus(url)
        params = self._111l1l11(url)
        self.dict = self._11l11111(params)
        logger.info(l1l1ll (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l11ll11l1(self.dict):
            raise l11111ll(l1l1ll (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._1ll11l11)
        self._11l1l11l(self.dict)
        if self._encode:
            self.l1ll11l1l()
        self._1l1ll1l1()
        self._1ll11111()
        self._1ll111ll()
        self._11l11lll()
        self.l111l111l()
        logger.info(l1l1ll (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1l1ll (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l1l1l1111))
        logger.info(l1l1ll (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l11l1l1l1))
        logger.info(l1l1ll (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l1l11l11l))
        logger.info(l1l1ll (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l11l1l1ll))
        logger.info(l1l1ll (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l1lllll1))
        logger.info(l1l1ll (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l1ll1l1ll))
        logger.info(l1l1ll (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l1ll111l1))
        logger.info(l1l1ll (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l1111l1ll))
    def _11l1l11l(self, l1111l11l):
        self.l1l1l1111 = l1111l11l.get(l1l1ll (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l11l1l1l1 = l1111l11l.get(l1l1ll (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1l1ll (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l1l11l11l = l1111l11l.get(l1l1ll (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l11l1l1ll = l1111l11l.get(l1l1ll (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l1lllll1 = l1111l11l.get(l1l1ll (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l1ll1l1ll = l1111l11l.get(l1l1ll (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l1ll111l1 = l1111l11l.get(l1l1ll (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1l1ll (u"ࠨࠢ࣍"))
        self.l1111l1ll = l1111l11l.get(l1l1ll (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1l1ll (u"ࠣࠤ࣏"))
        self.cookies = l1111l11l.get(l1l1ll (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l111l111l(self):
        l11lllll1 = False
        if self.l1lllll1:
            if self.l1lllll1.upper() == l1l1ll (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l1lllll1 = l1l1ll (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l1lllll1.upper() == l1l1ll (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l1lllll1 = l1l1ll (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l1lllll1.upper() == l1l1ll (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l1lllll1 = l1l1ll (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l1lllll1.upper() == l1l1ll (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l1lllll1 = l1l1ll (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l1lllll1 == l1l1ll (u"ࠦࠧࣙ"):
                l11lllll1 = True
            else:
                self.l1lllll1 = self.l1lllll1.lower()
        else:
            l11lllll1 = True
        if l11lllll1:
            self.l1lllll1 = l1l1ll (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l1ll11l1l(self):
        l1l1ll (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1l1ll (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l11ll1l11 = []
                    for el in self.__dict__.get(key):
                        l11ll1l11.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l11ll1l11
    def l11l1lll1(self, l1ll1111l):
        res = l1ll1111l
        if self._encode:
            res = urllib.parse.quote(l1ll1111l, safe=l1l1ll (u"ࠣࠤࣝ"))
        return res
    def _11l1ll11(self, url):
        l1l1ll (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1l1ll (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1l1ll (u"ࠦ࠿ࠨ࣠")), l1l1ll (u"ࠬ࠭࣡"), url)
        return url
    def _111l1l11(self, url):
        l1l1ll (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l1l1l1l11 = url.split(l1l1ll (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1l1ll (u"ࠣ࠽ࠥࣤ")))
        result = l1l1l1l11
        if len(result) == 0:
            raise l1lllll1l(l1l1ll (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _11l11111(self, params):
        l1l1ll (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1l1ll (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1l1ll (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l111ll1ll = data.group(l1l1ll (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l111ll1ll in (l1l1ll (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1l1ll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1l1ll (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1l1ll (u"ࠥ࠰࣭ࠧ"))
                elif l111ll1ll == l1l1ll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1l1ll (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1l1ll (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l111ll1ll] = value
        return result
    def _111ll1l1(self, url, scheme):
        l1l1ll (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l1l1l1ll1 = {l1l1ll (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1l1ll (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l111lll1l = url.split(l1l1ll (u"ࠥ࠾ࠧࣴ"))
        if len(l111lll1l) == 1:
            for l1111llll in list(l1l1l1ll1.keys()):
                if l1111llll == scheme:
                    url += l1l1ll (u"ࠦ࠿ࠨࣵ") + str(l1l1l1ll1[l1111llll])
                    break
        return url
    def _1l1ll1l1(self):
        l1l1ll (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l11l1l1ll:
            l1l1ll1ll = self.l11l1l1ll[0]
            l1l1111l1 = urlparse(l1l1ll1ll)
        if self.l1l1l1111:
            l11ll1111 = urlparse(self.l1l1l1111)
            if l11ll1111.scheme:
                l1ll1llll = l11ll1111.scheme
            else:
                if l1l1111l1.scheme:
                    l1ll1llll = l1l1111l1.scheme
                else:
                    raise l1111l1l(
                        l1l1ll (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l11ll1111.netloc:
                l1l1111ll = l11ll1111.netloc
            else:
                if l1l1111l1.netloc:
                    l1l1111ll = l1l1111l1.netloc
                else:
                    raise l1111l1l(
                        l1l1ll (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l1l1111ll = self._111ll1l1(l1l1111ll, l1ll1llll)
            path = l11ll1111.path
            if not path.endswith(l1l1ll (u"ࠨ࠱ࣹࠪ")):
                path += l1l1ll (u"ࠩ࠲ࣺࠫ")
            l1l1ll111 = ParseResult(scheme=l1ll1llll, netloc=l1l1111ll, path=path,
                                         params=l11ll1111.params, query=l11ll1111.query,
                                         fragment=l11ll1111.fragment)
            self.l1l1l1111 = l1l1ll111.geturl()
        else:
            if not l1l1111l1.netloc:
                raise l1111l1l(l1l1ll (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l1l11lll1 = l1l1111l1.path
            l111l11ll = l1l1ll (u"ࠦ࠴ࠨࣼ").join(l1l11lll1.split(l1l1ll (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1l1ll (u"ࠨ࠯ࠣࣾ")
            l1l1ll111 = ParseResult(scheme=l1l1111l1.scheme,
                                         netloc=self._111ll1l1(l1l1111l1.netloc, l1l1111l1.scheme),
                                         path=l111l11ll,
                                         params=l1l1ll (u"ࠢࠣࣿ"),
                                         query=l1l1ll (u"ࠣࠤऀ"),
                                         fragment=l1l1ll (u"ࠤࠥँ")
                                         )
            self.l1l1l1111 = l1l1ll111.geturl()
    def _1ll111ll(self):
        l1l1ll (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l11l1l1ll:
            l1l1ll1ll = self.l11l1l1ll[0]
            l1l1111l1 = urlparse(l1l1ll1ll)
        if self.l1ll1l1ll:
            l11111lll = urlparse(self.l1ll1l1ll)
            if l11111lll.scheme:
                l1lll111l = l11111lll.scheme
            else:
                l1lll111l = l1l1111l1.scheme
            if l11111lll.netloc:
                l11l1l111 = l11111lll.netloc
            else:
                l11l1l111 = l1l1111l1.netloc
            l11llll1l = ParseResult(scheme=l1lll111l, netloc=l11l1l111, path=l11111lll.path,
                                      params=l11111lll.params, query=l11111lll.query,
                                      fragment=l11111lll.fragment)
            self.l1ll1l1ll = l11llll1l.geturl()
    def _1ll11111(self):
        l1l1ll (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l11l1l1ll
        self.l11l1l1ll = []
        for item in items:
            l111lll11 = urlparse(item.strip(), scheme=l1l1ll (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l111lll11.path[-1] == l1l1ll (u"ࠨ࠯ࠣअ"):
                l1l111111 = l111lll11.path
            else:
                path_list = l111lll11.path.split(l1l1ll (u"ࠢ࠰ࠤआ"))
                l1l111111 = l1l1ll (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1l1ll (u"ࠤ࠲ࠦई")
            l1l1l1l1l = urlparse(self.l1l1l1111, scheme=l1l1ll (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l111lll11.scheme:
                scheme = l111lll11.scheme
            elif l1l1l1l1l.scheme:
                scheme = l1l1l1l1l.scheme
            else:
                scheme = l1l1ll (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l111lll11.netloc and not l1l1l1l1l.netloc:
                l111lllll = l111lll11.netloc
            elif not l111lll11.netloc and l1l1l1l1l.netloc:
                l111lllll = l1l1l1l1l.netloc
            elif not l111lll11.netloc and not l1l1l1l1l.netloc and len(self.l11l1l1ll) > 0:
                l11lll1ll = urlparse(self.l11l1l1ll[len(self.l11l1l1ll) - 1])
                l111lllll = l11lll1ll.netloc
            elif l1l1l1l1l.netloc:
                l111lllll = l111lll11.netloc
            elif not l1l1l1l1l.netloc:
                l111lllll = l111lll11.netloc
            if l111lll11.path:
                l11l11l11 = l111lll11.path
            if l111lllll:
                l111lllll = self._111ll1l1(l111lllll, scheme)
                l1l1lllll = ParseResult(scheme=scheme, netloc=l111lllll, path=l11l11l11,
                                          params=l111lll11.params,
                                          query=l111lll11.query,
                                          fragment=l111lll11.fragment)
                self.l11l1l1ll.append(l1l1lllll.geturl())
    def _11l11lll(self):
        l1l1ll (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l11l1ll1l = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111llll(l1l1ll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l11l1ll1l)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111llll(l1l1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l1l11l11l:
            l1lll1111 = []
            for l1l1llll1 in self.l1l11l11l:
                if l1l1llll1 not in [x[l1l1ll (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l1lll1111.append(l1l1llll1)
            if l1lll1111:
                l1l1lll1 = l1l1ll (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1l1ll (u"ࠥ࠰ࠥࠨऐ").join(l1lll1111))
                raise l111llll(l1l1ll (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1l1lll1)
    def l11ll11l1(self, params):
        l1l1ll (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1ll1lll1 = True
        for param in self._1ll11l11:
            if not params.get(param.lower()):
                l1ll1lll1 = False
        return l1ll1lll1
class l11ll11ll():
    def __init__(self, l11111l1l):
        self.l1ll1l111 = l11ll.l11111()
        self.l1ll1l1l1 = self.l1l11llll()
        self.l1l11ll11 = self.l111111l1()
        self.l11111l1l = l11111l1l
        self._11ll111l = [l1l1ll (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1l1ll (u"ࠢࡏࡱࡱࡩࠧऔ"), l1l1ll (u"ࠣࡃ࡯ࡰࠧक"), l1l1ll (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1l1ll (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1l1ll (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1l1ll (u"ࠧࡏࡅࠣङ"), l1l1ll (u"ࠨࡅࡥࡩࡨࠦच")]
        self._11lll11l = [l1l1ll (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1l1ll (u"ࠣࡇࡧ࡭ࡹࠨज"), l1l1ll (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1l1ll (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l111l1lll = None
    def l1l11llll(self):
        l11111l11 = l1l1ll (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l11111l11
    def l111111l1(self):
        l1l111l1l = 0
        return l1l111l1l
    def l1lll11ll(self):
        l1l1lll1 = l1l1ll (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l1l11ll11)
        l1l1lll1 += l1l1ll (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l1l1l111l(l1ll1111, l1l1lll1, t=1)
        return res
    def run(self):
        l11llllll = True
        self._1l11l1ll()
        result = []
        try:
            for cookie in l1111l1l1(l11l1lll=self.l11111l1l.cookies).run():
                result.append(cookie)
        except l1llll11l as e:
            logger.exception(l1l1ll (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l111111ll = self._11111ll1(result)
            if l111111ll:
                logger.info(l1l1ll (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l111111ll)
                self.l111l1lll = l111111ll
            else:
                logger.info(l1l1ll (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l111111ll)
            l11llllll = True
        else:
            l11llllll = False
        return l11llllll
    def _11111ll1(self, l1l11ll1l):
        res = False
        l1llllll = os.path.join(os.environ[l1l1ll (u"ࠪࡌࡔࡓࡅࠨथ")], l1l1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1l1ll (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l11l11ll1 = {}
        for cookies in l1l11ll1l:
            l11l11ll1[cookies.name] = cookies.value
        l1ll11ll1 = l1l1ll (u"ࠨࠢन")
        for key in list(l11l11ll1.keys()):
            l1ll11ll1 += l1l1ll (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l11l11ll1[key].strip())
        if not os.path.exists(os.path.dirname(l1llllll)):
            os.makedirs(os.path.dirname(l1llllll))
        vers = int(l1l1ll (u"ࠣࠤप").join(self.l1ll1l111.split(l1l1ll (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l11l11l1l = [l1l1ll (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1l1ll (u"ࠦࠨࠦࠢभ") + l1l1ll (u"ࠧ࠳ࠢम") * 60,
                              l1l1ll (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1l1ll (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1l1ll (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l1ll11ll1),
                              l1l1ll (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l11l11l1l = [l1l1ll (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1l1ll (u"ࠦࠨࠦࠢऴ") + l1l1ll (u"ࠧ࠳ࠢव") * 60,
                              l1l1ll (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1l1ll (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1l1ll (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l1ll11ll1),
                              l1l1ll (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1llllll, l1l1ll (u"ࠥࡻࠧऺ")) as l1l11l1l1:
            data = l1l1ll (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l11l11l1l)
            l1l11l1l1.write(data)
            l1l11l1l1.write(l1l1ll (u"ࠧࡢ࡮़ࠣ"))
        res = l1llllll
        return res
    def _1l11l1ll(self):
        self._1111ll1l(l1l1ll (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._1ll11lll()
    def _1111ll1l(self, l1lll1l11):
        l1l1lll11 = self.l11111l1l.dict[l1lll1l11.lower()]
        if l1l1lll11:
            if isinstance(l1l1lll11, list):
                l111ll111 = l1l1lll11
            else:
                l111ll111 = [l1l1lll11]
            if l1l1ll (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l1lll1l11.lower():
                    for l1111111l in l111ll111:
                        l1l1l1lll = [l11lll1l1.upper() for l11lll1l1 in self._11ll111l]
                        if not l1111111l.upper() in l1l1l1lll:
                            l11llll11 = l1l1ll (u"ࠣ࠮ࠣࠦि").join(self._11ll111l)
                            l1l111l11 = l1l1ll (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l1lll1l11, l1l1lll11, l11llll11, )
                            raise l1llll1ll(l1l111l11)
    def _1ll11lll(self):
        l111llll1 = []
        l11ll1lll = self.l11111l1l.l1l11l11l
        for l11ll1l1l in self._11ll111l:
            if not l11ll1l1l in [l1l1ll (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1l1ll (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l111llll1.append(l11ll1l1l)
        for l11l1llll in self.l11111l1l.l11l1l1l1:
            if l11l1llll in l111llll1 and not l11ll1lll:
                l1l111l11 = l1l1ll (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1llll1ll(l1l111l11)
def l11l1111l(title, message, l1l111ll1, l111l1111=None):
    l111l11l1 = l1ll1ll1l()
    l111l11l1.l1l1ll11l(message, title, l1l111ll1, l111l1111)
def l111l1l1l(title, message, l1l111ll1):
    l11lll111 = l1l11l111()
    l11lll111.l1lll11l1(title, message, l1l111ll1)
    res = l11lll111.result
    return res
def main():
    try:
        logger.info(l1l1ll (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l1l1l1l1)
        system.l111l1ll1()
        logger.info(l1l1ll (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l11111ll(
                l1l1ll (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l1ll1l11l = l1l1l11l1()
        l1ll1l11l.l1111ll11(l1l1ll (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l1111lll1 = [item.upper() for item in l1ll1l11l.l11l1l1l1]
        l111ll11l = l1l1ll (u"ࠥࡒࡔࡔࡅࠣै") in l1111lll1
        if l111ll11l:
            logger.info(l1l1ll (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l1l11111l = l1ll1l11l.l11l1l1ll
            for l1l1l1 in l1l11111l:
                logger.debug(l1l1ll (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l1l1l1))
                opener = l1ll11(l1ll1l11l.l1l1l1111, l1l1l1, l1llllll=None, l1ll=l1l1l1l1)
                opener.open()
                logger.info(l1l1ll (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l1ll1ll11 = l11ll11ll(l1ll1l11l)
            l11l111l1 = l1ll1ll11.run()
            l1l11111l = l1ll1l11l.l11l1l1ll
            for l1l1l1 in l1l11111l:
                logger.info(l1l1ll (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l1l1l1))
                opener = l1ll11(l1ll1l11l.l1l1l1111, l1l1l1, l1llllll=l1ll1ll11.l111l1lll,
                                l1ll=l1l1l1l1)
                opener.open()
                logger.info(l1l1ll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l1111l as e:
        title = l1l1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1ll1111
        logger.exception(l1l1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l11ll1ll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll1ll1 = el
        l1l1l11ll = l1l1ll (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l1l11, message.strip())
        l11l1111l(title, l1l1l11ll, l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1l1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l111l1111=l11ll1ll1)
        sys.exit(2)
    except l111111l as e:
        title = l1l1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1ll1111
        logger.exception(l1l1ll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l11ll1ll1 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11ll1ll1 = el
        l1l1l11ll = l1l1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l11l1111l(title, l1l1l11ll, l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1l1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l111l1111=l11ll1ll1)
        sys.exit(2)
    except l11111ll as e:
        title = l1l1ll (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1ll1111
        logger.exception(l1l1ll (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l11l1111l(title, str(e), l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1l1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1l1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1ll1111
        logger.exception(l1l1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l11l1111l(title, l1l1ll (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1l1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1llll1ll as e:
        title = l1l1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1ll1111
        logger.exception(l1l1ll (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l11l1111l(title, l1l1ll (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1l1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1lll1ll1 as e:
        title = l1l1ll (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1ll1111
        logger.exception(l1l1ll (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l11l1111l(title, l1l1ll (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1l1ll (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l1ll111:
        logger.info(l1l1ll (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1l1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1ll1111
        logger.exception(l1l1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l11l1111l(title, l1l1ll (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l1l111ll1=l1l1l1l1.get_value(l1l1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1l1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1l1ll (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()