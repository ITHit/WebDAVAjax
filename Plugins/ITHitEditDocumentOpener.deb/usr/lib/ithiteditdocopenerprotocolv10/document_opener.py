#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l1 = sys.version_info [0] == 2
l11 = 2048
l1ll11ll = 7
def l1lll1ll (l1lll111):
    global l1l1ll1
    l1l11 = ord (l1lll111 [-1])
    l1llll11 = l1lll111 [:-1]
    l1l1 = l1l11 % len (l1llll11)
    l1l1111 = l1llll11 [:l1l1] + l1llll11 [l1l1:]
    if l1ll11l1:
        l1111ll = l111l1 () .join ([unichr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    return eval (l1111ll)
import sys, json
import os
import urllib
import l1l1lll
from l111111 import *
import platform
from urllib.parse import urlparse, ParseResult
from l1l1111l import l1l11ll1, logger, l11lll11
from cookies import l111l1l1 as l1ll11l11
from l1l111 import l1ll1
l11lll1l1 = None
from l1lll import *
class l1ll1l11l():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1lll1ll (u"ࠢࡼ࠲ࢀࠤࡻ࠴ࡻ࠲ࡿࠣࡳࡳࠦࡻ࠳ࡿࠥࢲ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l11l1l1l1):
        self.config = l11l1l1l1
        self.l111111l1 = l1l1lll.l111l()
    def l1l11l1ll(self):
        data = platform.uname()
        logger.info(l1lll1ll (u"ࠣࡕࡼࡷࡹ࡫࡭ࠡࡋࡱࡪࡴࡀࠢࢳ"))
        logger.info(l1lll1ll (u"ࠤࠣࠤࠥࠦࡓࡺࡵࡷࡩࡲࡀࠠࠦࡵࠥࢴ") % data[0])
        logger.info(l1lll1ll (u"ࠥࠤࠥࠦࠠࡓࡧ࡯ࡩࡦࡹࡥ࠻ࠢࠨࡷࠧࢵ") % data[2])
        logger.info(l1lll1ll (u"ࠦࠥࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࢶ") % data[3])
class l1l111l11():
    def __init__(self, encode = True):
        self._encode = encode
        self._111lllll = [l1lll1ll (u"ࠧ࡯ࡴࡦ࡯ࡸࡶࡱࠨࢷ"), ]
        self.l11ll1ll1 = None
        self.l11l1l1ll = None
        self.l1l11lll1 = None
        self.l11ll111l = None
        self.l11l11l = None
        self.l1l1llll1 = None
        self.l1ll111l1 = None
        self.l111l11l1 = None
        self.cookies = None
    def l11ll11l1(self, url):
        l1lll1ll (u"࠭ࠧࠨࠢࠣࠤࠥࠦࠠ࡮ࡣ࡬ࡲࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡰࠣࡴࡦࡸࡳࡦࠢࡸࡶࡱࠦࠠࠡࠢࠣࠤࠥࠦࠧࠨࠩࢸ")
        logger.info(l1lll1ll (u"ࠢࡪࡰࡦࡳࡲ࡫ࠠࡖࡔࡏ࠾ࠥࢁ࠰ࡾࠤࢹ").format(url))
        url = self._1l11111l(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1lll11l1(url)
        self.dict = self._1l1lll11(params)
        logger.info(l1lll1ll (u"ࠣࡵࡳࡰ࡮ࡺࡥࡥࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢺ").format(self.dict))
        if not self.l1ll1l111(self.dict):
            raise l1lll1lll(l1lll1ll (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠾ࡡࡴࠥࡴࠤࢻ") % self._111lllll)
        self._1111l11l(self.dict)
        if self._encode:
            self.l1ll1111l()
        self._11l1ll11()
        self._1lll1111()
        self._11l1ll1l()
        self._111l111l()
        self.l11l11ll1()
        logger.info(l1lll1ll (u"ࠥࡔࡦࡸࡳࡦࡦࠣࡔࡦࡸࡡ࡮ࡧࡷࡩࡷࡹࠠ࠻ࠤࢼ"))
        logger.info(l1lll1ll (u"ࠦࠥࠦࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࡲࡤࡸ࡭ࡀࠠࠦࡵࠥࢽ") % (self.l11ll1ll1))
        logger.info(l1lll1ll (u"ࠧࠦࠠࠡࡵࡨࡥࡷࡩࡨࡪࡰ࠽ࠤࠪࡹࠢࢾ") % (self.l11l1l1ll))
        logger.info(l1lll1ll (u"ࠨࠠࠡࠢࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹ࠺ࠡࠧࡶࠦࢿ") % (self.l1l11lll1))
        logger.info(l1lll1ll (u"ࠢࠡࠢࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬࠿ࠦࠥࡴࠤࣀ") % (self.l11ll111l))
        logger.info(l1lll1ll (u"ࠣࠢࠣࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠦࠥࡴࠤࣁ") % (self.l11l11l))
        logger.info(l1lll1ll (u"ࠤࠣࠤࠥࡲ࡯ࡨ࡫ࡱࡹࡷࡲ࠺ࠡࠧࡶࠦࣂ") % (self.l1l1llll1))
        logger.info(l1lll1ll (u"ࠥࠤࠥࠦ࡬ࡰࡩ࡬ࡲࡳࡧ࡭ࡦ࠼ࠣࠩࡸࠨࣃ") % (self.l1ll111l1))
        logger.info(l1lll1ll (u"ࠦࠥࠦࠠࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲ࠿ࠦࠥࡴࠤࣄ") % (self.l111l11l1))
    def _1111l11l(self, l111111ll):
        self.l11ll1ll1 = l111111ll.get(l1lll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡹࡷࡲࠢࣅ"), None)
        self.l11l1l1ll = l111111ll.get(l1lll1ll (u"ࠨࡳࡦࡣࡵࡧ࡭࡯࡮ࠣࣆ"), [l1lll1ll (u"ࠧࡏࡱࡱࡩࠬࣇ"), ])
        self.l1l11lll1 = l111111ll.get(l1lll1ll (u"ࠣࡥࡲࡳࡰ࡯ࡥ࡯ࡣࡰࡩࡸࠨࣈ"), None)
        self.l11ll111l = l111111ll.get(l1lll1ll (u"ࠤ࡬ࡸࡪࡳࡵࡳ࡮ࠥࣉ"), None)
        self.l11l11l = l111111ll.get(l1lll1ll (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࠦ࣊"), None)
        self.l1l1llll1 = l111111ll.get(l1lll1ll (u"ࠦࡱࡵࡧࡪࡰࡸࡶࡱࠨ࣋"), None)
        self.l1ll111l1 = l111111ll.get(l1lll1ll (u"ࠧࡲ࡯ࡨ࡫ࡱࡲࡦࡳࡥࠣ࣌"), l1lll1ll (u"ࠨࠢ࣍"))
        self.l111l11l1 = l111111ll.get(l1lll1ll (u"ࠢࡴࡪࡲࡻࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࡬ࡰࡩ࡬ࡲࠧ࣎"), l1lll1ll (u"ࠣࠤ࣏"))
        self.cookies = l111111ll.get(l1lll1ll (u"ࠤࡦࡳࡴࡱࡩࡦࡵ࣐ࠥ"), None)
    def l11l11ll1(self):
        l11l11l11 = False
        if self.l11l11l:
            if self.l11l11l.upper() == l1lll1ll (u"ࠥࡉࡉࡏࡔ࣑ࠣ"):
                self.l11l11l = l1lll1ll (u"ࠦࡪࡪࡩࡵࠤ࣒")
            elif self.l11l11l.upper() == l1lll1ll (u"ࠧ࡜ࡉࡆ࡙࣓ࠥ"):
                self.l11l11l = l1lll1ll (u"ࠨ࡯ࡱࡧࡱࠦࣔ")
            elif self.l11l11l.upper() == l1lll1ll (u"ࠢࡑࡔࡌࡒ࡙ࠨࣕ"):
                self.l11l11l = l1lll1ll (u"ࠣࡲࡵ࡭ࡳࡺࠢࣖ")
            elif self.l11l11l.upper() == l1lll1ll (u"ࠤࡒࡔࡊࡔࡗࡊࡖࡋࠦࣗ"):
                self.l11l11l = l1lll1ll (u"ࠥࡳࡵ࡫࡮ࡢࡵࠥࣘ")
            elif self.l11l11l == l1lll1ll (u"ࠦࠧࣙ"):
                l11l11l11 = True
            else:
                self.l11l11l = self.l11l11l.lower()
        else:
            l11l11l11 = True
        if l11l11l11:
            self.l11l11l = l1lll1ll (u"ࠧࡵࡰࡦࡰࠥࣚ")
    def l1ll1111l(self):
        l1lll1ll (u"࠭ࠧࠨࠢࡕࡩࡵࡲࡡࡤࡧࠣࠩࡽࡾࠠࡦࡵࡦࡥࡵ࡫ࡳࠡࡤࡼࠤࡹ࡮ࡥࡪࡴࠣࡷ࡮ࡴࡧ࡭ࡧ࠰ࡧ࡭ࡧࡲࡢࡥࡷࡩࡷࠦࡥࡲࡷ࡬ࡺࡦࡲࡥ࡯ࡶࠣࠫࠬ࠭ࣛ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1lll1ll (u"ࠢࡠࠤࣜ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1l1l1111 = []
                    for el in self.__dict__.get(key):
                        l1l1l1111.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1l1l1111
    def l111l11ll(self, l1l1ll1ll):
        res = l1l1ll1ll
        if self._encode:
            res = urllib.parse.quote(l1l1ll1ll, safe=l1lll1ll (u"ࠣࠤࣝ"))
        return res
    def _1l11111l(self, url):
        l1lll1ll (u"ࠩࠪࠫࠥࡸࡥ࡮ࡱࡹࡩࠥࡊࡁࡗࠬ࠽ࠤ࡫ࡸ࡯࡮ࠢࡸࡶࡱࠦࡩࡧࠢࡨࡼ࡮ࡹࡴࠨࠩࠪࣞ")
        url = re.sub(l1lll1ll (u"ࡵࠫࡣࡢࡷࠬࡽ࠳ࢁࠬࣟ").format(l1lll1ll (u"ࠦ࠿ࠨ࣠")), l1lll1ll (u"ࠬ࠭࣡"), url)
        return url
    def _1lll11l1(self, url):
        l1lll1ll (u"࠭ࠧࠨࠢࡶࡴࡱ࡯ࡴࠡࡷࡵࡰࠥࡨࡹࠡࡦࡨࡰ࡮ࡳࡥࡵࡧࡵࠤࡀࠦࠧࠨࠩ࣢")
        l111ll1ll = url.split(l1lll1ll (u"ࠢࡼ࠲ࢀࣣࠦ").format(l1lll1ll (u"ࠣ࠽ࠥࣤ")))
        result = l111ll1ll
        if len(result) == 0:
            raise l1111111(l1lll1ll (u"ࠤࡆࡥࡳࠦ࡮ࡰࡶࠣࡴࡦࡸࡳࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠨࣥ"))
        return result
    def _1l1lll11(self, params):
        l1lll1ll (u"ࠪࠫࠬࠦ࡮ࡰࡴࡰࡥࡱ࡯ࡳࡦࠢࡷࡳࠥࡱࡥࡵࠢࡹࡥࡱࡻࡥࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡦࡶࡪࡧࡴࡦࠢ࡮ࡩࡾࠦ࡬ࡰࡹࡨࡶࠥ࠭ࠧࠨࣦ")
        result = {}
        regexp = re.compile(l1lll1ll (u"ࡶࠧࡤࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡞ࡺ࠯࠮ࢁ࠰ࡾࠪࡂࡔࡁࡶࡡࡳࡣࡰࡷࡃ࠴ࠫࡀࠫࠧࠦࣧ").format(l1lll1ll (u"ࠧࡃࠢࣨ")))
        for el in params:
            data = regexp.match(el)
            if data:
                l11llll11 = data.group(l1lll1ll (u"ࠨ࡮ࡢ࡯ࡨࣩࠦ")).lower()
                if l11llll11 in (l1lll1ll (u"ࠢࡤࡱࡲ࡯࡮࡫࡮ࡢ࡯ࡨࡷࠧ࣪"), l1lll1ll (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥ࣫")):
                    value = data.group(l1lll1ll (u"ࠤࡳࡥࡷࡧ࡭ࡴࠤ࣬")).split(l1lll1ll (u"ࠥ࠰࣭ࠧ"))
                elif l11llll11 == l1lll1ll (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰ࣮ࠧ"):
                    value = data.group(l1lll1ll (u"ࠧࡶࡡࡳࡣࡰࡷ࣯ࠧ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1lll1ll (u"ࠨࡰࡢࡴࡤࡱࡸࠨࣰ"))
                result[l11llll11] = value
        return result
    def _1ll11l1l(self, url, scheme):
        l1lll1ll (u"ࠢࠣࠤࠣࡆࡦࡹࡥࡥࠢࡲࡲࠥ࡮ࡴࡵࡲࠣࡳࡷࠦࡨࡵࡶࡳࡷࠥࡹࡣࡩࡧࡰࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡰࡴࡷࠦࠧࠨࣱ")
        l1l1111ll = {l1lll1ll (u"ࠣࡪࡷࡸࡵࠨࣲ"): 80, l1lll1ll (u"ࠤ࡫ࡸࡹࡶࡳࠣࣳ"): 443}
        l1l1ll11l = url.split(l1lll1ll (u"ࠥ࠾ࠧࣴ"))
        if len(l1l1ll11l) == 1:
            for l1l1l11ll in list(l1l1111ll.keys()):
                if l1l1l11ll == scheme:
                    url += l1lll1ll (u"ࠦ࠿ࠨࣵ") + str(l1l1111ll[l1l1l11ll])
                    break
        return url
    def _11l1ll11(self):
        l1lll1ll (u"ࠧࠨࠢࠡࡈࡸࡲࡨࡺࡩࡰࡰࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࡸࠦ࡭ࡰࡷࡱࡸ࡮ࡴࡧࡱࡣࡷ࡬ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡦࡹࡥࡥࠢࡲࡲࠥ࡯࡮ࡤࡱࡰࡩࠥࡶࡡࡳࡣࡰࡷࠥࡵࡲࠡࡨ࡬ࡶࡸࡺࠠࡧ࡫࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡶࡡࡵࡪࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡩ࡯ࡥࡲࡱࡪࠦࡰࡢࡴࡤࡱࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥ࡯ࡴࠡࡱࡱࠤࡱࡧࡳࡵࠢࡩࡳࡱࡪࡥࡳࠢࡷࡳࠥ࡬ࡩ࡭ࡧࠣࡳࡷࠦࡩࡧࠢ࡬ࡸࠥ࡯ࡳࠡࡨࡲࡰࡩ࡫ࡲࠡࡱࡱࠤࡸࡧ࡭ࡦࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࣶࠢ")
        if self.l11ll111l:
            l1l1l1ll1 = self.l11ll111l[0]
            l111l1l11 = urlparse(l1l1l1ll1)
        if self.l11ll1ll1:
            l1l1111l1 = urlparse(self.l11ll1ll1)
            if l1l1111l1.scheme:
                l11111ll1 = l1l1111l1.scheme
            else:
                if l111l1l11.scheme:
                    l11111ll1 = l111l1l11.scheme
                else:
                    raise l1111l1l(
                        l1lll1ll (u"ࠨࡉࡵࡧࡰ࡙ࡗࡒࠠࡰࡴࠣࡑࡴࡻ࡮ࡵࡗࡕࡐࠥࡳࡵࡴࡶࠣࡦࡪࠦࡡࠡࡥࡲࡱࡵࡲࡥࡵࡧ࡙ࠣࡗࡒࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠣࡨࡴࡳࡡࡪࡰࠣࡲࡦࡳࡥࠣࣷ"))
            if l1l1111l1.netloc:
                l11l111l1 = l1l1111l1.netloc
            else:
                if l111l1l11.netloc:
                    l11l111l1 = l111l1l11.netloc
                else:
                    raise l1111l1l(
                        l1lll1ll (u"ࠢࡊࡶࡨࡱ࡚ࡘࡌࠡࡱࡵࠤࡒࡵࡵ࡯ࡶࡘࡖࡑࠦ࡭ࡶࡵࡷࠤࡧ࡫ࠠࡢࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࠤ࡚ࡘࡌࠡ࡫ࡱࡧࡱࡻࡤࡪࡰࡪࠤࡩࡵ࡭ࡢ࡫ࡱࠤࡳࡧ࡭ࡦࠤࣸ"))
            l11l111l1 = self._1ll11l1l(l11l111l1, l11111ll1)
            path = l1l1111l1.path
            if not path.endswith(l1lll1ll (u"ࠨ࠱ࣹࠪ")):
                path += l1lll1ll (u"ࠩ࠲ࣺࠫ")
            l11ll1l1l = ParseResult(scheme=l11111ll1, netloc=l11l111l1, path=path,
                                         params=l1l1111l1.params, query=l1l1111l1.query,
                                         fragment=l1l1111l1.fragment)
            self.l11ll1ll1 = l11ll1l1l.geturl()
        else:
            if not l111l1l11.netloc:
                raise l1111l1l(l1lll1ll (u"ࠥࡍࡹ࡫࡭ࡖࡔࡏࠤࡴࡸࠠࡎࡱࡸࡲࡹ࡛ࡒࡍࠢࡰࡹࡸࡺࠠࡣࡧࠣࡥࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࠠࡖࡔࡏࠤ࡮ࡴࡣ࡭ࡷࡧ࡭ࡳ࡭ࠠࡥࡱࡰࡥ࡮ࡴࠠ࡯ࡣࡰࡩࠧࣻ"))
            l1ll1l1l1 = l111l1l11.path
            l11llll1l = l1lll1ll (u"ࠦ࠴ࠨࣼ").join(l1ll1l1l1.split(l1lll1ll (u"ࠧ࠵ࠢࣽ"))[:-1]) + l1lll1ll (u"ࠨ࠯ࠣࣾ")
            l11ll1l1l = ParseResult(scheme=l111l1l11.scheme,
                                         netloc=self._1ll11l1l(l111l1l11.netloc, l111l1l11.scheme),
                                         path=l11llll1l,
                                         params=l1lll1ll (u"ࠢࠣࣿ"),
                                         query=l1lll1ll (u"ࠣࠤऀ"),
                                         fragment=l1lll1ll (u"ࠤࠥँ")
                                         )
            self.l11ll1ll1 = l11ll1l1l.geturl()
    def _11l1ll1l(self):
        l1lll1ll (u"ࠥࠦࠧࠦࡖࡢ࡮࡬ࡨࡦࡺࡥࠡ࡮ࡲ࡫࡮ࡴࠠࡶࡴ࡯ࠦࠧࠨं")
        if self.l11ll111l:
            l1l1l1ll1 = self.l11ll111l[0]
            l111l1l11 = urlparse(l1l1l1ll1)
        if self.l1l1llll1:
            l11lll11l = urlparse(self.l1l1llll1)
            if l11lll11l.scheme:
                l1ll11lll = l11lll11l.scheme
            else:
                l1ll11lll = l111l1l11.scheme
            if l11lll11l.netloc:
                l1l11ll1l = l11lll11l.netloc
            else:
                l1l11ll1l = l111l1l11.netloc
            l1111111l = ParseResult(scheme=l1ll11lll, netloc=l1l11ll1l, path=l11lll11l.path,
                                      params=l11lll11l.params, query=l11lll11l.query,
                                      fragment=l11lll11l.fragment)
            self.l1l1llll1 = l1111111l.geturl()
    def _1lll1111(self):
        l1lll1ll (u"ࠦࠧࠨࠠࡗࡣ࡯࡭ࡩࡧࡴࡦࠢ࡬ࡸࡪࡳࡰࡢࡶ࡫ࠦࠧࠨः")
        items = self.l11ll111l
        self.l11ll111l = []
        for item in items:
            l11lll111 = urlparse(item.strip(), scheme=l1lll1ll (u"ࠧ࡮ࡴࡵࡲࠥऄ"))
            if l11lll111.path[-1] == l1lll1ll (u"ࠨ࠯ࠣअ"):
                l1l11llll = l11lll111.path
            else:
                path_list = l11lll111.path.split(l1lll1ll (u"ࠢ࠰ࠤआ"))
                l1l11llll = l1lll1ll (u"ࠣ࠱ࠥइ").join(path_list[:len(path_list) - 1]) + l1lll1ll (u"ࠤ࠲ࠦई")
            l111l1ll1 = urlparse(self.l11ll1ll1, scheme=l1lll1ll (u"ࠥ࡬ࡹࡺࡰࠣउ"))
            if l11lll111.scheme:
                scheme = l11lll111.scheme
            elif l111l1ll1.scheme:
                scheme = l111l1ll1.scheme
            else:
                scheme = l1lll1ll (u"ࠦ࡭ࡺࡴࡱࠤऊ")
            if l11lll111.netloc and not l111l1ll1.netloc:
                l1l1l1l11 = l11lll111.netloc
            elif not l11lll111.netloc and l111l1ll1.netloc:
                l1l1l1l11 = l111l1ll1.netloc
            elif not l11lll111.netloc and not l111l1ll1.netloc and len(self.l11ll111l) > 0:
                l11l11l1l = urlparse(self.l11ll111l[len(self.l11ll111l) - 1])
                l1l1l1l11 = l11l11l1l.netloc
            elif l111l1ll1.netloc:
                l1l1l1l11 = l11lll111.netloc
            elif not l111l1ll1.netloc:
                l1l1l1l11 = l11lll111.netloc
            if l11lll111.path:
                l11l1lll1 = l11lll111.path
            if l1l1l1l11:
                l1l1l1l11 = self._1ll11l1l(l1l1l1l11, scheme)
                l1l111l1l = ParseResult(scheme=scheme, netloc=l1l1l1l11, path=l11l1lll1,
                                          params=l11lll111.params,
                                          query=l11lll111.query,
                                          fragment=l11lll111.fragment)
                self.l11ll111l.append(l1l111l1l.geturl())
    def _111l111l(self):
        l1lll1ll (u"ࠧࠨࠢࠡࡒࡤࡶࡸ࡫ࠠࡤࡱࡲ࡯࡮࡫ࡳࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠦࠧࠨऋ")
        if self.cookies:
            try:
                import base64
                l11ll11ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l1lll1ll (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡨࡵࡤࡦࠢࡦࡳࡴࡱࡩࡦࡵ࠱ࠫऌ"))
            try:
                import json
                self.cookies = json.loads(l11ll11ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111ll11(l1lll1ll (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡰࡴࡧࡤࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰ࠪऍ"))
        else:
            self.cookies = []
        if self.l1l11lll1:
            l111ll11l = []
            for l1l1l111l in self.l1l11lll1:
                if l1l1l111l not in [x[l1lll1ll (u"ࠨࡍࡈ࡝ࠬऎ")] for x in self.cookies]:
                    l111ll11l.append(l1l1l111l)
            if l111ll11l:
                l1ll1111 = l1lll1ll (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡧࡴࡵ࡫ࡪࡧࠫࡷ࠮ࠦࠧࡼ࠲ࢀࠫࠥࡽࡡࡴࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨ࠳ࠨए").format(l1lll1ll (u"ࠥ࠰ࠥࠨऐ").join(l111ll11l))
                raise l111ll11(l1lll1ll (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡭ࡱࡤࡨࠥࡩ࡯ࡰ࡭࡬ࡩࡸ࠴࡜࡯ࠩऑ") + l1ll1111)
    def l1ll1l111(self, params):
        l1lll1ll (u"ࠬ࠭ࠧࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡳࡳࠦࡨࡢࡸࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡧ࡬࡭ࠢࡲ࡯ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩࠥࡸࡥࡵࡷࡵࡲࠥࡌࡡ࡭ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠭ࠧࠨऒ")
        l1ll11ll1 = True
        for param in self._111lllll:
            if not params.get(param.lower()):
                l1ll11ll1 = False
        return l1ll11ll1
class l11111l1l():
    def __init__(self, l11111lll):
        self.l11l11111 = l1l1lll.l111l()
        self.l1l111111 = self.l1111l111()
        self.l1111l1ll = self.l1111ll11()
        self.l11111lll = l11111lll
        self._111lll11 = [l1lll1ll (u"ࠨࡃࡶࡴࡵࡩࡳࡺࠢओ"), l1lll1ll (u"ࠢࡏࡱࡱࡩࠧऔ"), l1lll1ll (u"ࠣࡃ࡯ࡰࠧक"), l1lll1ll (u"ࠤࡆ࡬ࡷࡵ࡭ࡦࠤख"), l1lll1ll (u"ࠥࡊ࡮ࡸࡥࡧࡱࡻࠦग"), l1lll1ll (u"ࠦࡘࡧࡦࡢࡴ࡬ࠦघ"), l1lll1ll (u"ࠧࡏࡅࠣङ"), l1lll1ll (u"ࠨࡅࡥࡩࡨࠦच")]
        self._1ll1ll11 = [l1lll1ll (u"ࠢࡗ࡫ࡨࡻࠧछ"), l1lll1ll (u"ࠣࡇࡧ࡭ࡹࠨज"), l1lll1ll (u"ࠤࡓࡶ࡮ࡴࡴࠣझ"), l1lll1ll (u"ࠥࡓࡵ࡫࡮ࡘ࡫ࡷ࡬ࠧञ")]
        self.l1l11l111 = None
    def l1111l111(self):
        l11l1l11l = l1lll1ll (u"ࠦࡓࡵ࡮ࡦࠤट")
        return l11l1l11l
    def l1111ll11(self):
        l111lll1l = 0
        return l111lll1l
    def l1l1lll1l(self):
        l1ll1111 = l1lll1ll (u"࡚ࠧ࡯ࠡࡧࡻࡩࡨࡻࡴࡦࠢࡷ࡬࡮ࡹࠠࡤࡱࡰࡱࡦࡴࡤࠡࡶ࡫ࡩࠥࡧࡵࡵࡪࡨࡲࡹ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡣࡰࡱ࡮࡭ࡪࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡴࡣࡹࡩࡩࠦࡡࡴࠢࡳࡩࡷࡳࡡ࡯ࡧࡱࡸࠥ࡬࡯ࡳࠢࡾ࠴ࢂࠦࡨࡰࡷࡵࡷ࠳ࠨठ").format(self.l1111l1ll)
        l1ll1111 += l1lll1ll (u"ࠨ࡜࡯࡞ࡱࡘࡴࠦࡡࡷࡱ࡬ࡨࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡱࡵࡧ࠮࡫ࡱࠤࡼ࡯ࡴࡩࠢ࡟ࠦࡐ࡫ࡥࡱࠢࡰࡩࠥࡲ࡯ࡨࡩࡨࡨ࠲࡯࡮࡝ࠤࠣࡳࡵࡺࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࡧࡧࠤࡦࡴࡤࠡࡥ࡯ࡳࡸ࡫ࠠࡢ࡮࡯ࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳࠢࡺ࡭ࡳࡪ࡯ࡸࡵ࠱ࠦड")
        res = l1lll111l(l1l11ll1, l1ll1111, t=1)
        return res
    def run(self):
        l1ll1ll1l = True
        self._11ll1l11()
        result = []
        try:
            for cookie in l1ll11l11(l111lll1=self.l11111lll.cookies).run():
                result.append(cookie)
        except l1llll11l as e:
            logger.exception(l1lll1ll (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡄࡱࡲ࡯࡮࡫ࡅࡳࡴࡲࡶࠧढ"))
        if result:
            l1l11ll11 = self._11ll1111(result)
            if l1l11ll11:
                logger.info(l1lll1ll (u"ࠣࡅࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡑࡴࡻ࡮ࡵࡨࡶࠤࡼࡧࡳࠡࡥࡵࡥࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦण") % l1l11ll11)
                self.l1l11l111 = l1l11ll11
            else:
                logger.info(l1lll1ll (u"ࠤࡆࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡧࡱࡵࠤࡒࡵࡵ࡯ࡶࡩࡷࠥࡽࡡࡴࠢࡦࡶࡦࡺࡥࠡࡹ࡬ࡸ࡭ࠦࡅࡳࡴࡲࡶ࠳ࠦࡐࡢࡶ࡫࠾ࠥࠫࡳࠡࠤत") % l1l11ll11)
            l1ll1ll1l = True
        else:
            l1ll1ll1l = False
        return l1ll1ll1l
    def _11ll1111(self, l111llll1):
        res = False
        l1ll1l = os.path.join(os.environ[l1lll1ll (u"ࠪࡌࡔࡓࡅࠨथ")], l1lll1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧद"), l1lll1ll (u"ࠧࡪࡡࡷࡨࡶ࠶࠳ࡩ࡯࡯ࡨࠥध"))
        l1l111lll = {}
        for cookies in l111llll1:
            l1l111lll[cookies.name] = cookies.value
        l1ll1lll1 = l1lll1ll (u"ࠨࠢन")
        for key in list(l1l111lll.keys()):
            l1ll1lll1 += l1lll1ll (u"ࠢࠦࡵࡀࠩࡸࡁࠢऩ") % (key, l1l111lll[key].strip())
        if not os.path.exists(os.path.dirname(l1ll1l)):
            os.makedirs(os.path.dirname(l1ll1l))
        vers = int(l1lll1ll (u"ࠣࠤप").join(self.l11l11111.split(l1lll1ll (u"ࠤ࠱ࠦफ"))[:2]))
        if vers > 14:
            l111l1l1l = [l1lll1ll (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡂࠥ࠷࠮࠶࠰࠭ࠫब"),
                              l1lll1ll (u"ࠦࠨࠦࠢभ") + l1lll1ll (u"ࠧ࠳ࠢम") * 60,
                              l1lll1ll (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬय"),
                              l1lll1ll (u"ࠧ࡯ࡡࡦࡳࡴࡱࡩࡦࡵ࡟ࡸ࠶࠭र"),
                              l1lll1ll (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨऱ") % (l1ll1lll1),
                              l1lll1ll (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨल"),
                              ]
        else:
            l111l1l1l = [l1lll1ll (u"ࠪࠧࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࡫ࡵࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣ࠵࠳࠺࠮ࠫࠩळ"),
                              l1lll1ll (u"ࠦࠨࠦࠢऴ") + l1lll1ll (u"ࠧ࠳ࠢव") * 60,
                              l1lll1ll (u"࠭ࡵࡴࡧࡢࡰࡴࡩ࡫ࡴ࡞ࡷ࠴ࠬश"),
                              l1lll1ll (u"ࠧࡢ࡮࡯ࡳࡼࡥࡣࡰࡱ࡮࡭ࡪࡢࡴ࠲ࠩष"),
                              l1lll1ll (u"ࠨࡣࡧࡨࡤ࡮ࡥࡢࡦࡨࡶࠥࡉ࡯ࡰ࡭࡬ࡩࠥࠫࡳࠨस") % (l1ll1lll1),
                              l1lll1ll (u"ࠩࡧࡩࡧࡻࡧࠡ࡞ࡷࡱࡴࡹࡴࠨह"),
                              ]
        with open(l1ll1l, l1lll1ll (u"ࠥࡻࠧऺ")) as l111ll1l1:
            data = l1lll1ll (u"ࠦࡡࡴ࡜࡯ࠤऻ").join(l111l1l1l)
            l111ll1l1.write(data)
            l111ll1l1.write(l1lll1ll (u"ࠧࡢ࡮़ࠣ"))
        res = l1ll1l
        return res
    def _11ll1l11(self):
        self._1111ll1l(l1lll1ll (u"ࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣऽ"))
        self._11111l11()
    def _1111ll1l(self, l1l1l1l1l):
        l11lllll1 = self.l11111lll.dict[l1l1l1l1l.lower()]
        if l11lllll1:
            if isinstance(l11lllll1, list):
                l11l111ll = l11lllll1
            else:
                l11l111ll = [l11lllll1]
            if l1lll1ll (u"ࠧࡴࡧࡤࡶࡨ࡮ࡩ࡯ࠩा") == l1l1l1l1l.lower():
                    for l1ll1llll in l11l111ll:
                        l111ll111 = [l1ll11111.upper() for l1ll11111 in self._111lll11]
                        if not l1ll1llll.upper() in l111ll111:
                            l1111llll = l1lll1ll (u"ࠣ࠮ࠣࠦि").join(self._111lll11)
                            l1l111ll1 = l1lll1ll (u"ࠤࡓࡥࡷࡧ࡭ࡦࡶࡨࡶࠥࡢࠢࡼ࠲ࢀࡠࠧࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡣࡱࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡹࡥࡱࡻࡥ࠻ࠢࡾ࠵ࢂ࠴࡜࡯ࡕࡸࡴࡵࡵࡲࡵࡧࡧࠤࡴࡴ࡬ࡺࠢࡱࡩࡽࡺࠠࡷࡣ࡯ࡹࡪࡹ࠺ࠡࡽ࠵ࢁࠧी").format(
                                l1l1l1l1l, l11lllll1, l1111llll, )
                            raise l1llll1ll(l1l111ll1)
    def _11111l11(self):
        l1111l1l1 = []
        l11l1l111 = self.l11111lll.l1l11lll1
        for l1l1l11l1 in self._111lll11:
            if not l1l1l11l1 in [l1lll1ll (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠦु"), l1lll1ll (u"ࠦࡓࡵ࡮ࡦࠤू")]:
                l1111l1l1.append(l1l1l11l1)
        for l111l1111 in self.l11111lll.l11l1l1ll:
            if l111l1111 in l1111l1l1 and not l11l1l111:
                l1l111ll1 = l1lll1ll (u"ࠬࠨࡃࡰࡱ࡮࡭ࡪࡔࡡ࡮ࡧࡶࠦࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡶࡴࡪࡩࡩࡧ࡫ࡨࡨࠥ࡯ࡦࠡࠤࡄࡰࡱࠨࠠࡰࡴࠣࡱࡴࡸࡥࠡࡶ࡫ࡥࡳࠦ࡯࡯ࡧࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲࠡ࡫ࡶࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡰࠣࠦࡘ࡫ࡡࡳࡥ࡫ࡍࡳࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠱ࠫृ")
                raise l1llll1ll(l1l111ll1)
def l11l1llll(title, message, l1111lll1, l11l11lll=None):
    l1lll1l11 = l11lll1ll()
    l1lll1l11.l1l1ll1l1(message, title, l1111lll1, l11l11lll)
def l1l11l1l1(title, message, l1111lll1):
    l11llllll = l11ll1lll()
    l11llllll.l1ll111ll(title, message, l1111lll1)
    res = l11llllll.result
    return res
def main():
    try:
        logger.info(l1lll1ll (u"ࠨ࠽ࠣॄ") * 80)
        system = System(l11lll11)
        system.l1l11l1ll()
        logger.info(l1lll1ll (u"ࠢ࠾ࠤॅ") * 80)
        if len(sys.argv) < 2:
            raise l1lll1lll(
                l1lll1ll (u"ࠣࡖ࡫࡭ࡸࠦࡩࡴࠢࡤࠤࡵࡸ࡯ࡵࡱࡦࡳࡱࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡏࡴࠡ࡫ࡶࠤࡪࡾࡥࡤࡷࡷࡩࡩࠦࡷࡩࡧࡱࠤࡦࠦࡦࡪ࡮ࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡼ࡫ࡢࠡࡲࡤ࡫ࡪࠦࡩࡴࠢࡥࡩ࡮ࡴࡧࠡࡱࡳࡩࡳࠦࡵࡴ࡫ࡱ࡫ࠥࡪࡡࡷ࡚࠽ࠤࡵࡸ࡯ࡵࡱࡦࡳࡱ࠴ࠠࡅࡱࠣࡲࡴࡺࠠࡳࡷࡱࠤࡹ࡮ࡩࡴࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺ࠰ࠥॆ"))
        l1l1lllll = l1l111l11()
        l1l1lllll.l11ll11l1(l1lll1ll (u"ࠤࠣࠦे").join(sys.argv[1:]))
        l1lll11ll = [item.upper() for item in l1l1lllll.l11l1l1ll]
        l11l1111l = l1lll1ll (u"ࠥࡒࡔࡔࡅࠣै") in l1lll11ll
        if l11l1111l:
            logger.info(l1lll1ll (u"ࠦ࡜ࡵࡲ࡬ࠢࡺ࡭ࡹ࡮ࠠࡘࡇࡅࡈࡆ࡜ࠠࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࠥॉ"))
            l1l1l1lll = l1l1lllll.l11ll111l
            for l11lll1 in l1l1l1lll:
                logger.debug(l1lll1ll (u"ࠧࡺ࡯ࠡ࡞ࠥࡳࡵ࡫࡮ࡠࡦࡲࡧࡺࡳࡥ࡯ࡶ࡟ࠦࠥࡶࡡࡴࡶࡨࠤࡩࡧࡴࡢࠢࡾ࠴ࢂࠨॊ").format(l11lll1))
                opener = l1ll1(l1l1lllll.l11ll1ll1, l11lll1, l1ll1l=None, l11ll=l11lll11)
                opener.open()
                logger.info(l1lll1ll (u"ࠨࡏࡱࡧࡱࠤࡩࡵࡣࡶ࡯ࡨࡲࡹࠦࡳࡶࡥࡦࡩࡸࡹࠢो"))
        else:
            l1ll1l1ll = l11111l1l(l1l1lllll)
            l1l11l11l = l1ll1l1ll.run()
            l1l1l1lll = l1l1lllll.l11ll111l
            for l11lll1 in l1l1l1lll:
                logger.info(l1lll1ll (u"ࠢࡑࡴࡨࡴࡦࡸࡥࠡࡶࡲࠤࡴࡶࡥ࡯࡫ࡱ࡫ࠥࡪ࡯ࡤࡷࡰࡩࡳࡺࠠࡼ࠲ࢀࠦौ").format(l11lll1))
                opener = l1ll1(l1l1lllll.l11ll1ll1, l11lll1, l1ll1l=l1ll1l1ll.l1l11l111,
                                l11ll=l11lll11)
                opener.open()
                logger.info(l1lll1ll (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
    except l11ll1l as e:
        title = l1lll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॎ") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॏ"))
        message = l1l1ll111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1ll111 = el
        l111l1lll = l1lll1ll (u"ࠦࡋ࡯࡬ࡦࠢࡖࡽࡸࡺࡥ࡮ࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࡡࡴ࡜࡯ࡗࡕࡐ࠿ࠦࠥࡴ࡞ࡱࡠࡳࡋࡲࡳࡱࡵࠤࡲ࡫ࡳࡴࡣࡪࡩ࠿ࠦ࡜ࠣࠧࡶࡠࠧࠨॐ") % (
        e.l11ll11, message.strip())
        l11l1llll(title, l111l1lll, l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ॑"), l1lll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲ॒ࠧ")),
                           l11l11lll=l1l1ll111)
        sys.exit(2)
    except l11111ll as e:
        title = l1lll1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ॓") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨ॔"))
        message = l1l1ll111 = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l1l1ll111 = el
        l111l1lll = l1lll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡠࠧࠫࡳ࡝ࠤࠥॕ") % (message.strip())
        l11l1llll(title, l111l1lll, l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨॖ"), l1lll1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬॗ")),
                           l11l11lll=l1l1ll111)
        sys.exit(2)
    except l1lll1lll as e:
        title = l1lll1ll (u"ࠧࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠣࡐࡦࡻ࡮ࡤࡪࠣࡉࡷࡸ࡯ࡳࠢ࠰ࠤࠪࡹࠢक़") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠨࡈࡢࡸࡨࠤࡊࡸࡲࡰࡴ࠽ࠦख़"))
        l11l1llll(title, str(e), l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬग़"), l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩज़")))
        sys.exit(2)
    except IOError as e:
        title = l1lll1ll (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨड़") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣढ़"))
        l11l1llll(title, l1lll1ll (u"ࠦࢀ࠶ࡽࠣफ़").format(e),
                           l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪय़"), l1lll1ll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧॠ")))
        sys.exit(1)
    except l1llll1ll as e:
        title = l1lll1ll (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦॡ") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠣࡇࡵࡶࡴࡸࠠࡸ࡫ࡷ࡬ࠥࡳࡩࡴ࡯ࡤࡸࡨ࡮ࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴ࠽ࠦॢ"))
        l11l1llll(title, l1lll1ll (u"ࠤࡾ࠴ࢂࠨॣ").format(e),
                           l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ।"), l1lll1ll (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ॥")))
        sys.exit(2)
    except l1111l11 as e:
        title = l1lll1ll (u"ࠧࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤ०") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠨࡅࡳࡴࡲࡶࠥࡵ࡮ࠡࡱࡳࡩࡳ࡫ࡤࠡࡴࡨࡷࡴࡻࡲࡴࡧ࠽ࠦ१"))
        l11l1llll(title, l1lll1ll (u"ࠢࡆࡴࡵࡳࡷࡀࠠࡼ࠲ࢀࠦ२").format(e),
                           l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭३"), l1lll1ll (u"ࠩࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮ࠪ४")))
        sys.exit(2)
    except l111lll:
        logger.info(l1lll1ll (u"࡙ࠥࡸ࡫ࡲࠡࡥ࡯࡭ࡨࡱࠠ࡝ࠤࡆࡥࡳࡩࡥ࡭࡞ࠥࠤࡴࡴࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡪࡣ࡯ࡳ࡬ࠨ५"))
        sys.exit(0)
    except Exception as e:
        title = l1lll1ll (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣ६") % l1l11ll1
        logger.exception(l1lll1ll (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ७"))
        l11l1llll(title, l1lll1ll (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻ࠱ࡿࠥ८").format(e),
                           l1111lll1=l11lll11.get_value(l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ९"), l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॰")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1lll1ll (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦॱ"):
    main()