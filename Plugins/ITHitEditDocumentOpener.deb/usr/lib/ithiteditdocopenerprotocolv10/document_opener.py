#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l = sys.version_info [0] == 2
ll = 2048
l1 = 7
def l1111l1 (l1ll1lll):
    global l1ll1l1
    l1111 = ord (l1ll1lll [-1])
    l1l1lll = l1ll1lll [:-1]
    l11l1 = l1111 % len (l1l1lll)
    l1l1111 = l1l1lll [:l11l1] + l1l1lll [l11l1:]
    if l1lll1l:
        l1ll1ll1 = l1l1l () .join ([unichr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    else:
        l1ll1ll1 = str () .join ([chr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    return eval (l1ll1ll1)
import sys, json
import os
import urllib
import l1ll111l
from l1lll111 import *
import platform
from urllib.parse import urlparse, ParseResult
from l11lll11 import l1l1l1ll, logger, l11ll1l1
from cookies import l111lll1 as l11111ll1
from l11ll import l1lll11l
l1l1ll111 = None
from l1lll11 import *
class l111111l1():
    def __init__(self):
        self.name = None
        self.path = None
        self.version = None
    def __str__(self):
        res = l1111l1 (u"ࠤࡾ࠴ࢂࠦࡶ࠯ࡽ࠴ࢁࠥࡵ࡮ࠡࡽ࠵ࢁࠧࢴ").format(self.name, self.version, self.path)
        return res
class System():
    def __init__(self, l11lllll1):
        self.config = l11lllll1
        self.l1l11llll = l1ll111l.l111111()
    def l1ll1l1l1(self):
        data = platform.uname()
        logger.info(l1111l1 (u"ࠥࡗࡾࡹࡴࡦ࡯ࠣࡍࡳ࡬࡯࠻ࠤࢵ"))
        logger.info(l1111l1 (u"ࠦࠥࠦࠠࠡࡕࡼࡷࡹ࡫࡭࠻ࠢࠨࡷࠧࢶ") % data[0])
        logger.info(l1111l1 (u"ࠧࠦࠠࠡࠢࡕࡩࡱ࡫ࡡࡴࡧ࠽ࠤࠪࡹࠢࢷ") % data[2])
        logger.info(l1111l1 (u"ࠨ࡚ࠠࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࢸ") % data[3])
class l1ll111ll():
    def __init__(self, encode = True):
        self._encode = encode
        self._1l11l11l = [l1111l1 (u"ࠢࡪࡶࡨࡱࡺࡸ࡬ࠣࢹ"), ]
        self.l1l11ll11 = None
        self.l11l1l1ll = None
        self.l11l1111l = None
        self.l111l11ll = None
        self.l11l111 = None
        self.l1111ll1l = None
        self.l1l1l11ll = None
        self.l11ll1ll1 = None
        self.cookies = None
    def l1l1ll11l(self, url):
        l1111l1 (u"ࠨࠩࠪࠤࠥࠦࠠࠡࠢࡰࡥ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡲࡲࠥࡶࡡࡳࡵࡨࠤࡺࡸ࡬ࠡࠢࠣࠤࠥࠦࠠࠡࠩࠪࠫࢺ")
        logger.info(l1111l1 (u"ࠤ࡬ࡲࡨࡵ࡭ࡦࠢࡘࡖࡑࡀࠠࡼ࠲ࢀࠦࢻ").format(url))
        url = self._1l1l1ll1(url)
        url = urllib.parse.unquote_plus(url)
        params = self._1111l1ll(url)
        self.dict = self._1ll1111l(params)
        logger.info(l1111l1 (u"ࠥࡷࡵࡲࡩࡵࡧࡧࠤ࡚ࡘࡌ࠻ࠢࡾ࠴ࢂࠨࢼ").format(self.dict))
        if not self.l1l111l1l(self.dict):
            raise l1lllll1l(l1111l1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࡀ࡜࡯ࠧࡶࠦࢽ") % self._1l11l11l)
        self._111111ll(self.dict)
        if self._encode:
            self.l111l1l1l()
        self._1l1lll11()
        self._1l11l111()
        self._1l1lll1l()
        self._111lll11()
        self.l1111l11l()
        logger.info(l1111l1 (u"ࠧࡖࡡࡳࡵࡨࡨࠥࡖࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࠽ࠦࢾ"))
        logger.info(l1111l1 (u"ࠨࠠࠡࠢࡰࡳࡺࡴࡴࡪࡰࡪࡴࡦࡺࡨ࠻ࠢࠨࡷࠧࢿ") % (self.l1l11ll11))
        logger.info(l1111l1 (u"ࠢࠡࠢࠣࡷࡪࡧࡲࡤࡪ࡬ࡲ࠿ࠦࠥࡴࠤࣀ") % (self.l11l1l1ll))
        logger.info(l1111l1 (u"ࠣࠢࠣࠤࡨࡵ࡯࡬࡫ࡨࡲࡦࡳࡥࡴ࠼ࠣࠩࡸࠨࣁ") % (self.l11l1111l))
        logger.info(l1111l1 (u"ࠤࠣࠤࠥ࡯ࡴࡦ࡯ࡳࡥࡹ࡮࠺ࠡࠧࡶࠦࣂ") % (self.l111l11ll))
        logger.info(l1111l1 (u"ࠥࠤࠥࠦࡣࡰ࡯ࡰࡥࡳࡪ࠺ࠡࠧࡶࠦࣃ") % (self.l11l111))
        logger.info(l1111l1 (u"ࠦࠥࠦࠠ࡭ࡱࡪ࡭ࡳࡻࡲ࡭࠼ࠣࠩࡸࠨࣄ") % (self.l1111ll1l))
        logger.info(l1111l1 (u"ࠧࠦࠠࠡ࡮ࡲ࡫࡮ࡴ࡮ࡢ࡯ࡨ࠾ࠥࠫࡳࠣࣅ") % (self.l1l1l11ll))
        logger.info(l1111l1 (u"ࠨࠠࠡࠢࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࠺ࠡࠧࡶࠦࣆ") % (self.l11ll1ll1))
    def _111111ll(self, l1l11lll1):
        self.l1l11ll11 = l1l11lll1.get(l1111l1 (u"ࠢ࡮ࡱࡸࡲࡹࡻࡲ࡭ࠤࣇ"), None)
        self.l11l1l1ll = l1l11lll1.get(l1111l1 (u"ࠣࡵࡨࡥࡷࡩࡨࡪࡰࠥࣈ"), [l1111l1 (u"ࠩࡑࡳࡳ࡫ࠧࣉ"), ])
        self.l11l1111l = l1l11lll1.get(l1111l1 (u"ࠥࡧࡴࡵ࡫ࡪࡧࡱࡥࡲ࡫ࡳࠣ࣊"), None)
        self.l111l11ll = l1l11lll1.get(l1111l1 (u"ࠦ࡮ࡺࡥ࡮ࡷࡵࡰࠧ࣋"), None)
        self.l11l111 = l1l11lll1.get(l1111l1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠨ࣌"), None)
        self.l1111ll1l = l1l11lll1.get(l1111l1 (u"ࠨ࡬ࡰࡩ࡬ࡲࡺࡸ࡬ࠣ࣍"), None)
        self.l1l1l11ll = l1l11lll1.get(l1111l1 (u"ࠢ࡭ࡱࡪ࡭ࡳࡴࡡ࡮ࡧࠥ࣎"), l1111l1 (u"ࠣࠤ࣏"))
        self.l11ll1ll1 = l1l11lll1.get(l1111l1 (u"ࠤࡶ࡬ࡴࡽࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࡮ࡲ࡫࡮ࡴ࣐ࠢ"), l1111l1 (u"࣑ࠥࠦ"))
        self.cookies = l1l11lll1.get(l1111l1 (u"ࠦࡨࡵ࡯࡬࡫ࡨࡷ࣒ࠧ"), None)
    def l1111l11l(self):
        l1ll1ll11 = False
        if self.l11l111:
            if self.l11l111.upper() == l1111l1 (u"ࠧࡋࡄࡊࡖ࣓ࠥ"):
                self.l11l111 = l1111l1 (u"ࠨࡥࡥ࡫ࡷࠦࣔ")
            elif self.l11l111.upper() == l1111l1 (u"ࠢࡗࡋࡈ࡛ࠧࣕ"):
                self.l11l111 = l1111l1 (u"ࠣࡱࡳࡩࡳࠨࣖ")
            elif self.l11l111.upper() == l1111l1 (u"ࠤࡓࡖࡎࡔࡔࠣࣗ"):
                self.l11l111 = l1111l1 (u"ࠥࡴࡷ࡯࡮ࡵࠤࣘ")
            elif self.l11l111.upper() == l1111l1 (u"ࠦࡔࡖࡅࡏ࡙ࡌࡘࡍࠨࣙ"):
                self.l11l111 = l1111l1 (u"ࠧࡵࡰࡦࡰࡤࡷࠧࣚ")
            elif self.l11l111 == l1111l1 (u"ࠨࠢࣛ"):
                l1ll1ll11 = True
            else:
                self.l11l111 = self.l11l111.lower()
        else:
            l1ll1ll11 = True
        if l1ll1ll11:
            self.l11l111 = l1111l1 (u"ࠢࡰࡲࡨࡲࠧࣜ")
    def l111l1l1l(self):
        l1111l1 (u"ࠨࠩࠪࠤࡗ࡫ࡰ࡭ࡣࡦࡩࠥࠫࡸࡹࠢࡨࡷࡨࡧࡰࡦࡵࠣࡦࡾࠦࡴࡩࡧ࡬ࡶࠥࡹࡩ࡯ࡩ࡯ࡩ࠲ࡩࡨࡢࡴࡤࡧࡹ࡫ࡲࠡࡧࡴࡹ࡮ࡼࡡ࡭ࡧࡱࡸࠥ࠭ࠧࠨࣝ")
        for key in list(self.__dict__.keys()):
            if key[1] != l1111l1 (u"ࠤࡢࠦࣞ"):
                if isinstance(self.__dict__.get(key), str):
                    self.__dict__[key] = str(urllib.parse.unquote(self.__dict__.get(key)))
                if isinstance(self.__dict__.get(key), list):
                    l1ll1ll1l = []
                    for el in self.__dict__.get(key):
                        l1ll1ll1l.append(str(urllib.parse.unquote(el)))
                    self.__dict__[key] = l1ll1ll1l
    def l11l11l11(self, l1ll1l111):
        res = l1ll1l111
        if self._encode:
            res = urllib.parse.quote(l1ll1l111, safe=l1111l1 (u"ࠥࠦࣟ"))
        return res
    def _1l1l1ll1(self, url):
        l1111l1 (u"ࠫࠬ࠭ࠠࡳࡧࡰࡳࡻ࡫ࠠࡅࡃ࡙࠮࠿ࠦࡦࡳࡱࡰࠤࡺࡸ࡬ࠡ࡫ࡩࠤࡪࡾࡩࡴࡶࠪࠫࠬ࣠")
        url = re.sub(l1111l1 (u"ࡷ࠭࡞࡝ࡹ࠮ࡿ࠵ࢃࠧ࣡").format(l1111l1 (u"ࠨ࠺ࠣ࣢")), l1111l1 (u"ࠧࠨࣣ"), url)
        return url
    def _1111l1ll(self, url):
        l1111l1 (u"ࠨࠩࠪࠤࡸࡶ࡬ࡪࡶࠣࡹࡷࡲࠠࡣࡻࠣࡨࡪࡲࡩ࡮ࡧࡷࡩࡷࠦ࠻ࠡࠩࠪࠫࣤ")
        l11lll1ll = url.split(l1111l1 (u"ࠤࡾ࠴ࢂࠨࣥ").format(l1111l1 (u"ࠥ࠿ࣦࠧ")))
        result = l11lll1ll
        if len(result) == 0:
            raise l1llll11l(l1111l1 (u"ࠦࡈࡧ࡮ࠡࡰࡲࡸࠥࡶࡡࡳࡵࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠣࣧ"))
        return result
    def _1ll1111l(self, params):
        l1111l1 (u"ࠬ࠭ࠧࠡࡰࡲࡶࡲࡧ࡬ࡪࡵࡨࠤࡹࡵࠠ࡬ࡧࡷࠤࡻࡧ࡬ࡶࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡢࡰࡧࠤࡨࡸࡥࡢࡶࡨࠤࡰ࡫ࡹࠡ࡮ࡲࡻࡪࡸࠠࠨࠩࠪࣨ")
        result = {}
        regexp = re.compile(l1111l1 (u"ࡸࠢ࡟ࠪࡂࡔࡁࡴࡡ࡮ࡧࡁࡠࡼ࠱ࠩࡼ࠲ࢀࠬࡄࡖ࠼ࡱࡣࡵࡥࡲࡹ࠾࠯࠭ࡂ࠭ࠩࠨࣩ").format(l1111l1 (u"ࠢ࠾ࠤ࣪")))
        for el in params:
            data = regexp.match(el)
            if data:
                l1l1ll1ll = data.group(l1111l1 (u"ࠣࡰࡤࡱࡪࠨ࣫")).lower()
                if l1l1ll1ll in (l1111l1 (u"ࠤࡦࡳࡴࡱࡩࡦࡰࡤࡱࡪࡹࠢ࣬"), l1111l1 (u"ࠥࡷࡪࡧࡲࡤࡪ࡬ࡲ࣭ࠧ")):
                    value = data.group(l1111l1 (u"ࠦࡵࡧࡲࡢ࡯ࡶ࣮ࠦ")).split(l1111l1 (u"ࠧ࠲࣯ࠢ"))
                elif l1l1ll1ll == l1111l1 (u"ࠨࡩࡵࡧࡰࡹࡷࡲࣰࠢ"):
                    value = data.group(l1111l1 (u"ࠢࡱࡣࡵࡥࡲࡹࣱࠢ"))
                    try:
                        value = json.loads(value)
                    except ValueError:
                        value = [value]
                else:
                    value = data.group(l1111l1 (u"ࠣࡲࡤࡶࡦࡳࡳࣲࠣ"))
                result[l1l1ll1ll] = value
        return result
    def _111l11l1(self, url, scheme):
        l1111l1 (u"ࠤࠥࠦࠥࡈࡡࡴࡧࡧࠤࡴࡴࠠࡩࡶࡷࡴࠥࡵࡲࠡࡪࡷࡸࡵࡹࠠࡴࡥ࡫ࡩࡲ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡲࡶࡹࠨࠢࠣࣳ")
        l1l1111ll = {l1111l1 (u"ࠥ࡬ࡹࡺࡰࠣࣴ"): 80, l1111l1 (u"ࠦ࡭ࡺࡴࡱࡵࠥࣵ"): 443}
        l11l11ll1 = url.split(l1111l1 (u"ࠧࡀࣶࠢ"))
        if len(l11l11ll1) == 1:
            for l111ll11l in list(l1l1111ll.keys()):
                if l111ll11l == scheme:
                    url += l1111l1 (u"ࠨ࠺ࠣࣷ") + str(l1l1111ll[l111ll11l])
                    break
        return url
    def _1l1lll11(self):
        l1111l1 (u"ࠢࠣࠤࠣࡊࡺࡴࡣࡵ࡫ࡲࡲࠥ࡭ࡥ࡯ࡧࡵࡥࡹ࡫ࡳࠡ࡯ࡲࡹࡳࡺࡩ࡯ࡩࡳࡥࡹ࡮ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡨࡡࡴࡧࡧࠤࡴࡴࠠࡪࡰࡦࡳࡲ࡫ࠠࡱࡣࡵࡥࡲࡹࠠࡰࡴࠣࡪ࡮ࡸࡳࡵࠢࡩ࡭ࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡱࡣࡷ࡬ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡮ࡱࡸࡲࡹ࡯࡮ࡨࠢࡳࡥࡹ࡮ࠠ࡯ࡱࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯࡮ࠡ࡫ࡱࡧࡴࡳࡥࠡࡲࡤࡶࡦࡳࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡲ࡯ࡥࡨ࡫ࠠࡪࡶࠣࡳࡳࠦ࡬ࡢࡵࡷࠤ࡫ࡵ࡬ࡥࡧࡵࠤࡹࡵࠠࡧ࡫࡯ࡩࠥࡵࡲࠡ࡫ࡩࠤ࡮ࡺࠠࡪࡵࠣࡪࡴࡲࡤࡦࡴࠣࡳࡳࠦࡳࡢ࡯ࡨࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࣸ")
        if self.l111l11ll:
            l11l11l1l = self.l111l11ll[0]
            l11ll1l1l = urlparse(l11l11l1l)
        if self.l1l11ll11:
            l1l111111 = urlparse(self.l1l11ll11)
            if l1l111111.scheme:
                l111ll111 = l1l111111.scheme
            else:
                if l11ll1l1l.scheme:
                    l111ll111 = l11ll1l1l.scheme
                else:
                    raise l1llll1l1(
                        l1111l1 (u"ࠣࡋࡷࡩࡲ࡛ࡒࡍࠢࡲࡶࠥࡓ࡯ࡶࡰࡷ࡙ࡗࡒࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡣࠣࡧࡴࡳࡰ࡭ࡧࡷࡩ࡛ࠥࡒࡍࠢ࡬ࡲࡨࡲࡵࡥ࡫ࡱ࡫ࠥࡪ࡯࡮ࡣ࡬ࡲࠥࡴࡡ࡮ࡧࣹࠥ"))
            if l1l111111.netloc:
                l1111l1l1 = l1l111111.netloc
            else:
                if l11ll1l1l.netloc:
                    l1111l1l1 = l11ll1l1l.netloc
                else:
                    raise l1llll1l1(
                        l1111l1 (u"ࠤࡌࡸࡪࡳࡕࡓࡎࠣࡳࡷࠦࡍࡰࡷࡱࡸ࡚ࡘࡌࠡ࡯ࡸࡷࡹࠦࡢࡦࠢࡤࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࠦࡕࡓࡎࠣ࡭ࡳࡩ࡬ࡶࡦ࡬ࡲ࡬ࠦࡤࡰ࡯ࡤ࡭ࡳࠦ࡮ࡢ࡯ࡨࣺࠦ"))
            l1111l1l1 = self._111l11l1(l1111l1l1, l111ll111)
            path = l1l111111.path
            if not path.endswith(l1111l1 (u"ࠪ࠳ࠬࣻ")):
                path += l1111l1 (u"ࠫ࠴࠭ࣼ")
            l1l111ll1 = ParseResult(scheme=l111ll111, netloc=l1111l1l1, path=path,
                                         params=l1l111111.params, query=l1l111111.query,
                                         fragment=l1l111111.fragment)
            self.l1l11ll11 = l1l111ll1.geturl()
        else:
            if not l11ll1l1l.netloc:
                raise l1llll1l1(l1111l1 (u"ࠧࡏࡴࡦ࡯ࡘࡖࡑࠦ࡯ࡳࠢࡐࡳࡺࡴࡴࡖࡔࡏࠤࡲࡻࡳࡵࠢࡥࡩࠥࡧࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠢࡘࡖࡑࠦࡩ࡯ࡥ࡯ࡹࡩ࡯࡮ࡨࠢࡧࡳࡲࡧࡩ࡯ࠢࡱࡥࡲ࡫ࠢࣽ"))
            l11ll11l1 = l11ll1l1l.path
            l1l11ll1l = l1111l1 (u"ࠨ࠯ࠣࣾ").join(l11ll11l1.split(l1111l1 (u"ࠢ࠰ࠤࣿ"))[:-1]) + l1111l1 (u"ࠣ࠱ࠥऀ")
            l1l111ll1 = ParseResult(scheme=l11ll1l1l.scheme,
                                         netloc=self._111l11l1(l11ll1l1l.netloc, l11ll1l1l.scheme),
                                         path=l1l11ll1l,
                                         params=l1111l1 (u"ࠤࠥँ"),
                                         query=l1111l1 (u"ࠥࠦं"),
                                         fragment=l1111l1 (u"ࠦࠧः")
                                         )
            self.l1l11ll11 = l1l111ll1.geturl()
    def _1l1lll1l(self):
        l1111l1 (u"ࠧࠨࠢࠡࡘࡤࡰ࡮ࡪࡡࡵࡧࠣࡰࡴ࡭ࡩ࡯ࠢࡸࡶࡱࠨࠢࠣऄ")
        if self.l111l11ll:
            l11l11l1l = self.l111l11ll[0]
            l11ll1l1l = urlparse(l11l11l1l)
        if self.l1111ll1l:
            l1l1l1l11 = urlparse(self.l1111ll1l)
            if l1l1l1l11.scheme:
                l111lll1l = l1l1l1l11.scheme
            else:
                l111lll1l = l11ll1l1l.scheme
            if l1l1l1l11.netloc:
                l1111llll = l1l1l1l11.netloc
            else:
                l1111llll = l11ll1l1l.netloc
            l111ll1l1 = ParseResult(scheme=l111lll1l, netloc=l1111llll, path=l1l1l1l11.path,
                                      params=l1l1l1l11.params, query=l1l1l1l11.query,
                                      fragment=l1l1l1l11.fragment)
            self.l1111ll1l = l111ll1l1.geturl()
    def _1l11l111(self):
        l1111l1 (u"ࠨ࡙ࠢࠣࠢࡥࡱ࡯ࡤࡢࡶࡨࠤ࡮ࡺࡥ࡮ࡲࡤࡸ࡭ࠨࠢࠣअ")
        items = self.l111l11ll
        self.l111l11ll = []
        for item in items:
            l11ll111l = urlparse(item.strip(), scheme=l1111l1 (u"ࠢࡩࡶࡷࡴࠧआ"))
            if l11ll111l.path[-1] == l1111l1 (u"ࠣ࠱ࠥइ"):
                l1l1l1111 = l11ll111l.path
            else:
                path_list = l11ll111l.path.split(l1111l1 (u"ࠤ࠲ࠦई"))
                l1l1l1111 = l1111l1 (u"ࠥ࠳ࠧउ").join(path_list[:len(path_list) - 1]) + l1111l1 (u"ࠦ࠴ࠨऊ")
            l11l1ll11 = urlparse(self.l1l11ll11, scheme=l1111l1 (u"ࠧ࡮ࡴࡵࡲࠥऋ"))
            if l11ll111l.scheme:
                scheme = l11ll111l.scheme
            elif l11l1ll11.scheme:
                scheme = l11l1ll11.scheme
            else:
                scheme = l1111l1 (u"ࠨࡨࡵࡶࡳࠦऌ")
            if l11ll111l.netloc and not l11l1ll11.netloc:
                l1llllllll = l11ll111l.netloc
            elif not l11ll111l.netloc and l11l1ll11.netloc:
                l1llllllll = l11l1ll11.netloc
            elif not l11ll111l.netloc and not l11l1ll11.netloc and len(self.l111l11ll) > 0:
                l1l11l1l1 = urlparse(self.l111l11ll[len(self.l111l11ll) - 1])
                l1llllllll = l1l11l1l1.netloc
            elif l11l1ll11.netloc:
                l1llllllll = l11ll111l.netloc
            elif not l11l1ll11.netloc:
                l1llllllll = l11ll111l.netloc
            if l11ll111l.path:
                l11111lll = l11ll111l.path
            if l1llllllll:
                l1llllllll = self._111l11l1(l1llllllll, scheme)
                l1ll111l1 = ParseResult(scheme=scheme, netloc=l1llllllll, path=l11111lll,
                                          params=l11ll111l.params,
                                          query=l11ll111l.query,
                                          fragment=l11ll111l.fragment)
                self.l111l11ll.append(l1ll111l1.geturl())
    def _111lll11(self):
        l1111l1 (u"ࠢࠣࠤࠣࡔࡦࡸࡳࡦࠢࡦࡳࡴࡱࡩࡦࡵࠣࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࠨࠢࠣऍ")
        if self.cookies:
            try:
                import base64
                l1ll1l1ll = base64.b64decode(self.cookies).decode()
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l1111l1 (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡣࡰࡦࡨࠤࡨࡵ࡯࡬࡫ࡨࡷ࠳࠭ऎ"))
            try:
                import json
                self.cookies = json.loads(l1ll1l1ll)
            except:
                e = sys.exc_info()[0]
                logger.exception(e)
                raise l111l111(l1111l1 (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡲ࡯ࡢࡦࠣࡧࡴࡵ࡫ࡪࡧࡶ࠲ࠬए"))
        else:
            self.cookies = []
        if self.l11l1111l:
            l111l1111 = []
            for l11ll1lll in self.l11l1111l:
                if l11ll1lll not in [x[l1111l1 (u"ࠪࡏࡊ࡟ࠧऐ")] for x in self.cookies]:
                    l111l1111.append(l11ll1lll)
            if l111l1111:
                l1l111ll = l1111l1 (u"ࠦࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡯ࡰ࡭࡬ࡩ࠭ࡹࠩࠡࠩࡾ࠴ࢂ࠭ࠠࡸࡣࡶࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪ࠮ࠣऑ").format(l1111l1 (u"ࠧ࠲ࠠࠣऒ").join(l111l1111))
                raise l111l111(l1111l1 (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢ࡯ࡳࡦࡪࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡞ࡱࠫओ") + l1l111ll)
    def l1l111l1l(self, params):
        l1111l1 (u"ࠧࠨ࡚ࠩࠣࡦࡲࡩࡥࡣࡷࡩࠥࡵ࡮ࠡࡪࡤࡺࡪࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡲࡤࡶࡦࡳࡥࡵࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࡔࡳࡷࡨࠤ࡮࡬ࠠࡢ࡮࡯ࠤࡴࡱࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰࡸ࡫ࠠࡳࡧࡷࡹࡷࡴࠠࡇࡣ࡯ࡷࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪऔ")
        l1ll11ll1 = True
        for param in self._1l11l11l:
            if not params.get(param.lower()):
                l1ll11ll1 = False
        return l1ll11ll1
class l11llll11():
    def __init__(self, l11lll11l):
        self.l1ll11lll = l1ll111l.l111111()
        self.l11l1l11l = self.l111l111l()
        self.l111l1l11 = self.l1ll11111()
        self.l11lll11l = l11lll11l
        self._1lll1111 = [l1111l1 (u"ࠣࡅࡸࡶࡷ࡫࡮ࡵࠤक"), l1111l1 (u"ࠤࡑࡳࡳ࡫ࠢख"), l1111l1 (u"ࠥࡅࡱࡲࠢग"), l1111l1 (u"ࠦࡈ࡮ࡲࡰ࡯ࡨࠦघ"), l1111l1 (u"ࠧࡌࡩࡳࡧࡩࡳࡽࠨङ"), l1111l1 (u"ࠨࡓࡢࡨࡤࡶ࡮ࠨच"), l1111l1 (u"ࠢࡊࡇࠥछ"), l1111l1 (u"ࠣࡇࡧ࡫ࡪࠨज")]
        self._1111lll1 = [l1111l1 (u"ࠤ࡙࡭ࡪࡽࠢझ"), l1111l1 (u"ࠥࡉࡩ࡯ࡴࠣञ"), l1111l1 (u"ࠦࡕࡸࡩ࡯ࡶࠥट"), l1111l1 (u"ࠧࡕࡰࡦࡰ࡚࡭ࡹ࡮ࠢठ")]
        self.l11llll1l = None
    def l111l111l(self):
        l1ll1l11l = l1111l1 (u"ࠨࡎࡰࡰࡨࠦड")
        return l1ll1l11l
    def l1ll11111(self):
        l111llll1 = 0
        return l111llll1
    def l1l1l111l(self):
        l1l111ll = l1111l1 (u"ࠢࡕࡱࠣࡩࡽ࡫ࡣࡶࡶࡨࠤࡹ࡮ࡩࡴࠢࡦࡳࡲࡳࡡ࡯ࡦࠣࡸ࡭࡫ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡥࡲࡳࡰ࡯ࡥࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡶࡥࡻ࡫ࡤࠡࡣࡶࠤࡵ࡫ࡲ࡮ࡣࡱࡩࡳࡺࠠࡧࡱࡵࠤࢀ࠶ࡽࠡࡪࡲࡹࡷࡹ࠮ࠣढ").format(self.l111l1l11)
        l1l111ll += l1111l1 (u"ࠣ࡞ࡱࡠࡳ࡚࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷࠥࡳࡥࡴࡵࡤ࡫ࡪࠦ࡬ࡰࡩ࠰࡭ࡳࠦࡷࡪࡶ࡫ࠤࡡࠨࡋࡦࡧࡳࠤࡲ࡫ࠠ࡭ࡱࡪ࡫ࡪࡪ࠭ࡪࡰ࡟ࠦࠥࡵࡰࡵ࡫ࡲࡲࠥࡩࡨࡦࡥ࡮ࡩࡩࠦࡡ࡯ࡦࠣࡧࡱࡵࡳࡦࠢࡤࡰࡱࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵࠤࡼ࡯࡮ࡥࡱࡺࡷ࠳ࠨण")
        res = l11l1l1l1(l1l1l1ll, l1l111ll, t=1)
        return res
    def run(self):
        l11l111ll = True
        self._11111111()
        result = []
        try:
            for cookie in l11111ll1(l111l1l1=self.l11lll11l.cookies).run():
                result.append(cookie)
        except l1lll1l1l as e:
            logger.exception(l1111l1 (u"ࠤࡅࡶࡴࡽࡳࡦࡴࡆࡳࡴࡱࡩࡦࡇࡵࡶࡴࡸࠢत"))
        if result:
            l1ll1llll = self._1l111lll(result)
            if l1ll1llll:
                logger.info(l1111l1 (u"ࠥࡇࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡨࡲࡶࠥࡓ࡯ࡶࡰࡷࡪࡸࠦࡷࡢࡵࠣࡧࡷࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺ࠰ࠣࡔࡦࡺࡨ࠻ࠢࠨࡷࠥࠨथ") % l1ll1llll)
                self.l11llll1l = l1ll1llll
            else:
                logger.info(l1111l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡩࡳࡷࠦࡍࡰࡷࡱࡸ࡫ࡹࠠࡸࡣࡶࠤࡨࡸࡡࡵࡧࠣࡻ࡮ࡺࡨࠡࡇࡵࡶࡴࡸ࠮ࠡࡒࡤࡸ࡭ࡀࠠࠦࡵࠣࠦद") % l1ll1llll)
            l11l111ll = True
        else:
            l11l111ll = False
        return l11l111ll
    def _1l111lll(self, l1l1111l1):
        res = False
        l1lll = os.path.join(os.environ[l1111l1 (u"ࠬࡎࡏࡎࡇࠪध")], l1111l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢन"), l1111l1 (u"ࠢࡥࡣࡹࡪࡸ࠸࠮ࡤࡱࡱࡪࠧऩ"))
        l11l111l1 = {}
        for cookies in l1l1111l1:
            l11l111l1[cookies.name] = cookies.value
        l11lll1l1 = l1111l1 (u"ࠣࠤप")
        for key in list(l11l111l1.keys()):
            l11lll1l1 += l1111l1 (u"ࠤࠨࡷࡂࠫࡳ࠼ࠤफ") % (key, l11l111l1[key].strip())
        if not os.path.exists(os.path.dirname(l1lll)):
            os.makedirs(os.path.dirname(l1lll))
        vers = int(l1111l1 (u"ࠥࠦब").join(self.l1ll11lll.split(l1111l1 (u"ࠦ࠳ࠨभ"))[:2]))
        if vers > 14:
            l1l1l11l1 = [l1111l1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡄࠠ࠲࠰࠸࠲࠯࠭म"),
                              l1111l1 (u"ࠨࠣࠡࠤय") + l1111l1 (u"ࠢ࠮ࠤर") * 60,
                              l1111l1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧऱ"),
                              l1111l1 (u"ࠩࡱࡣࡨࡵ࡯࡬࡫ࡨࡷࡡࡺ࠱ࠨल"),
                              l1111l1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪळ") % (l11lll1l1),
                              l1111l1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऴ"),
                              ]
        else:
            l1l1l11l1 = [l1111l1 (u"ࠬࠩࠠࡎࡱࡸࡲࡹ࡬ࡳࠡࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࠦࡦࡰࡴࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥ࠷࠮࠵࠰࠭ࠫव"),
                              l1111l1 (u"ࠨࠣࠡࠤश") + l1111l1 (u"ࠢ࠮ࠤष") * 60,
                              l1111l1 (u"ࠨࡷࡶࡩࡤࡲ࡯ࡤ࡭ࡶࡠࡹ࠶ࠧस"),
                              l1111l1 (u"ࠩࡤࡰࡱࡵࡷࡠࡥࡲࡳࡰ࡯ࡥ࡝ࡶ࠴ࠫह"),
                              l1111l1 (u"ࠪࡥࡩࡪ࡟ࡩࡧࡤࡨࡪࡸࠠࡄࡱࡲ࡯࡮࡫ࠠࠦࡵࠪऺ") % (l11lll1l1),
                              l1111l1 (u"ࠫࡩ࡫ࡢࡶࡩࠣࡠࡹࡳ࡯ࡴࡶࠪऻ"),
                              ]
        with open(l1lll, l1111l1 (u"ࠧࡽ़ࠢ")) as l11llllll:
            data = l1111l1 (u"ࠨ࡜࡯࡞ࡱࠦऽ").join(l1l1l11l1)
            l11llllll.write(data)
            l11llllll.write(l1111l1 (u"ࠢ࡝ࡰࠥा"))
        res = l1lll
        return res
    def _11111111(self):
        self._1ll11l1l(l1111l1 (u"ࠣࡕࡨࡥࡷࡩࡨࡊࡰࠥि"))
        self._1lll111l()
    def _1ll11l1l(self, l11111l11):
        l1111111l = self.l11lll11l.dict[l11111l11.lower()]
        if l1111111l:
            if isinstance(l1111111l, list):
                l1l11l1ll = l1111111l
            else:
                l1l11l1ll = [l1111111l]
            if l1111l1 (u"ࠩࡶࡩࡦࡸࡣࡩ࡫ࡱࠫी") == l11111l11.lower():
                    for l11111l1l in l1l11l1ll:
                        l1l1l1lll = [l1ll11l11.upper() for l1ll11l11 in self._1lll1111]
                        if not l11111l1l.upper() in l1l1l1lll:
                            l1111ll11 = l1111l1 (u"ࠥ࠰ࠥࠨु").join(self._1lll1111)
                            l11ll1111 = l1111l1 (u"ࠦࡕࡧࡲࡢ࡯ࡨࡸࡪࡸࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡥࡲࡲࡹࡧࡩ࡯ࡵࠣࡥࡳࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࡻࡧ࡬ࡶࡧ࠽ࠤࢀ࠷ࡽ࠯࡞ࡱࡗࡺࡶࡰࡰࡴࡷࡩࡩࠦ࡯࡯࡮ࡼࠤࡳ࡫ࡸࡵࠢࡹࡥࡱࡻࡥࡴ࠼ࠣࡿ࠷ࢃࠢू").format(
                                l11111l11, l1111111l, l1111ll11, )
                            raise l1lll11ll(l11ll1111)
    def _1lll111l(self):
        l1l1llll1 = []
        l11l11111 = self.l11lll11l.l11l1111l
        for l1l1ll1l1 in self._1lll1111:
            if not l1l1ll1l1 in [l1111l1 (u"ࠧࡉࡵࡳࡴࡨࡲࡹࠨृ"), l1111l1 (u"ࠨࡎࡰࡰࡨࠦॄ")]:
                l1l1llll1.append(l1l1ll1l1)
        for l11l1ll1l in self.l11lll11l.l11l1l1ll:
            if l11l1ll1l in l1l1llll1 and not l11l11111:
                l11ll1111 = l1111l1 (u"ࠧࠣࡅࡲࡳࡰ࡯ࡥࡏࡣࡰࡩࡸࠨࠠࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࠣࡱࡺࡹࡴࠡࡤࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡪࡪࠠࡪࡨࠣࠦࡆࡲ࡬ࠣࠢࡲࡶࠥࡳ࡯ࡳࡧࠣࡸ࡭ࡧ࡮ࠡࡱࡱࡩࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴࠣ࡭ࡸࠦࡳࡱࡧࡦ࡭࡫࡯ࡥࡥࠢ࡬ࡲࠥࠨࡓࡦࡣࡵࡧ࡭ࡏ࡮ࠣࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠳࠭ॅ")
                raise l1lll11ll(l11ll1111)
def l1ll1lll1(title, message, l11l11lll, l1l111l11=None):
    l11l1l111 = l11lll111()
    l11l1l111.l11ll11ll(message, title, l11l11lll, l1l111l11)
def l111ll1ll(title, message, l11l11lll):
    l1l1lllll = l1lll11l1()
    l1l1lllll.l11ll1l11(title, message, l11l11lll)
    res = l1l1lllll.result
    return res
def main():
    try:
        logger.info(l1111l1 (u"ࠣ࠿ࠥॆ") * 80)
        system = System(l11ll1l1)
        system.l1ll1l1l1()
        logger.info(l1111l1 (u"ࠤࡀࠦे") * 80)
        if len(sys.argv) < 2:
            raise l1lllll1l(
                l1111l1 (u"ࠥࡘ࡭࡯ࡳࠡ࡫ࡶࠤࡦࠦࡰࡳࡱࡷࡳࡨࡵ࡬ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠴ࠠࡊࡶࠣ࡭ࡸࠦࡥࡹࡧࡦࡹࡹ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡡࠡࡨ࡬ࡰࡪࠦࡦࡳࡱࡰࠤࡦࠦࡷࡦࡤࠣࡴࡦ࡭ࡥࠡ࡫ࡶࠤࡧ࡫ࡩ࡯ࡩࠣࡳࡵ࡫࡮ࠡࡷࡶ࡭ࡳ࡭ࠠࡥࡣࡹ࡜࠿ࠦࡰࡳࡱࡷࡳࡨࡵ࡬࠯ࠢࡇࡳࠥࡴ࡯ࡵࠢࡵࡹࡳࠦࡴࡩ࡫ࡶࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼ࠲ࠧै"))
        l111l1lll = l1ll111ll()
        l111l1lll.l1l1ll11l(l1111l1 (u"ࠦࠥࠨॉ").join(sys.argv[1:]))
        l1l11111l = [item.upper() for item in l111l1lll.l11l1l1ll]
        l1l1l1l1l = l1111l1 (u"ࠧࡔࡏࡏࡇࠥॊ") in l1l11111l
        if l1l1l1l1l:
            logger.info(l1111l1 (u"ࠨࡗࡰࡴ࡮ࠤࡼ࡯ࡴࡩ࡚ࠢࡉࡇࡊࡁࡗࠢࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࠧो"))
            l111l1ll1 = l111l1lll.l111l11ll
            for l1ll11l1 in l111l1ll1:
                logger.debug(l1111l1 (u"ࠢࡵࡱࠣࡠࠧࡵࡰࡦࡰࡢࡨࡴࡩࡵ࡮ࡧࡱࡸࡡࠨࠠࡱࡣࡶࡸࡪࠦࡤࡢࡶࡤࠤࢀ࠶ࡽࠣौ").format(l1ll11l1))
                opener = l1lll11l(l111l1lll.l1l11ll11, l1ll11l1, l1lll=None, l1l11l1=l11ll1l1)
                opener.open()
                logger.info(l1111l1 (u"ࠣࡑࡳࡩࡳࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࡵࡸࡧࡨ࡫ࡳࡴࠤ्"))
        else:
            l11l1lll1 = l11llll11(l111l1lll)
            l111lllll = l11l1lll1.run()
            l111l1ll1 = l111l1lll.l111l11ll
            for l1ll11l1 in l111l1ll1:
                logger.info(l1111l1 (u"ࠤࡓࡶࡪࡶࡡࡳࡧࠣࡸࡴࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡥࡱࡦࡹࡲ࡫࡮ࡵࠢࡾ࠴ࢂࠨॎ").format(l1ll11l1))
                opener = l1lll11l(l111l1lll.l1l11ll11, l1ll11l1, l1lll=l11l1lll1.l11llll1l,
                                l1l11l1=l11ll1l1)
                opener.open()
                logger.info(l1111l1 (u"ࠥࡓࡵ࡫࡮ࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࠣࡷࡺࡩࡣࡦࡵࡶࠦॏ"))
    except l11111 as e:
        title = l1111l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣॐ") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥ॑"))
        message = l11l1llll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1llll = el
        l1111l111 = l1111l1 (u"ࠨࡆࡪ࡮ࡨࠤࡘࡿࡳࡵࡧࡰࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩ࠴࡜࡯࡞ࡱ࡙ࡗࡒ࠺ࠡࠧࡶࡠࡳࡢ࡮ࡆࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫࠺ࠡ࡞ࠥࠩࡸࡢ॒ࠢࠣ") % (
        e.l11l, message.strip())
        l1ll1lll1(title, l1111l111, l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ॓"), l1111l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ॔")),
                           l1l111l11=l11l1llll)
        sys.exit(2)
    except l1lll1l11 as e:
        title = l1111l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॕ") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠥࡌࡦࡼࡥࠡࡇࡵࡶࡴࡸ࠺ࠣॖ"))
        message = l11l1llll = None
        for index, el in enumerate(e.args):
            if index == 0:
                message = el
            elif index == 1:
                l11l1llll = el
        l1111l111 = l1111l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡱࡪࡹࡳࡢࡩࡨ࠾ࠥࡢࠢࠦࡵ࡟ࠦࠧॗ") % (message.strip())
        l1ll1lll1(title, l1111l111, l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪक़"), l1111l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧख़")),
                           l1l111l11=l11l1llll)
        sys.exit(2)
    except l1lllll1l as e:
        title = l1111l1 (u"ࠢࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡒࡡࡶࡰࡦ࡬ࠥࡋࡲࡳࡱࡵࠤ࠲ࠦࠥࡴࠤग़") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠣࡊࡤࡺࡪࠦࡅࡳࡴࡲࡶ࠿ࠨज़"))
        l1ll1lll1(title, str(e), l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧड़"), l1111l1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫढ़")))
        sys.exit(2)
    except IOError as e:
        title = l1111l1 (u"ࠦࡊࡸࡲࡰࡴࠣ࠱ࠥࠫࡳࠣफ़") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠧࡎࡡࡷࡧࠣࡉࡷࡸ࡯ࡳ࠼ࠥय़"))
        l1ll1lll1(title, l1111l1 (u"ࠨࡻ࠱ࡿࠥॠ").format(e),
                           l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬॡ"), l1111l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩॢ")))
        sys.exit(1)
    except l1lll11ll as e:
        title = l1111l1 (u"ࠤࡈࡶࡷࡵࡲࠡ࠯ࠣࠩࡸࠨॣ") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡭ࡹ࡮ࠠ࡮࡫ࡶࡱࡦࡺࡣࡩࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶ࠿ࠨ।"))
        l1ll1lll1(title, l1111l1 (u"ࠦࢀ࠶ࡽࠣ॥").format(e),
                           l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ०"), l1111l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ१")))
        sys.exit(2)
    except l1lll1lll as e:
        title = l1111l1 (u"ࠢࡆࡴࡵࡳࡷࠦ࠭ࠡࠧࡶࠦ२") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠣࡇࡵࡶࡴࡸࠠࡰࡰࠣࡳࡵ࡫࡮ࡦࡦࠣࡶࡪࡹ࡯ࡶࡴࡶࡩ࠿ࠨ३"))
        l1ll1lll1(title, l1111l1 (u"ࠤࡈࡶࡷࡵࡲ࠻ࠢࡾ࠴ࢂࠨ४").format(e),
                           l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ५"), l1111l1 (u"ࠫࡸ࡮࡯ࡸࡡࡰࡩࡸࡹࡡࡨࡧࡢࡥࡸࡥ࡭ࡰࡦࡤࡰࠬ६")))
        sys.exit(2)
    except l1111l:
        logger.info(l1111l1 (u"࡛ࠧࡳࡦࡴࠣࡧࡱ࡯ࡣ࡬ࠢ࡟ࠦࡈࡧ࡮ࡤࡧ࡯ࡠࠧࠦ࡯࡯ࠢ࡯ࡳ࡬࡯࡮ࠡࡦ࡬ࡥࡱࡵࡧࠣ७"))
        sys.exit(0)
    except Exception as e:
        title = l1111l1 (u"ࠨࡅࡳࡴࡲࡶࠥ࠳ࠠࠦࡵࠥ८") % l1l1l1ll
        logger.exception(l1111l1 (u"ࠢࡉࡣࡹࡩࠥࡋࡲࡳࡱࡵ࠾ࠧ९"))
        l1ll1lll1(title, l1111l1 (u"ࠣࡇࡵࡶࡴࡸ࠺ࠡࡽ࠳ࢁࠧ॰").format(e),
                           l11l11lll=l11ll1l1.get_value(l1111l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧॱ"), l1111l1 (u"ࠪࡷ࡭ࡵࡷࡠ࡯ࡨࡷࡸࡧࡧࡦࡡࡤࡷࡤࡳ࡯ࡥࡣ࡯ࠫॲ")))
        sys.exit(1)
    finally:
        pass
if __name__ == l1111l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨॳ"):
    main()