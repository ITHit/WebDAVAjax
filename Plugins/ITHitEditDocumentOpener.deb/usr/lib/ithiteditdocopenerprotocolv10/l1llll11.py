#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llllll = sys.version_info [0] == 2
l11ll1 = 2048
l1111ll = 7
def l1ll1l1 (l11ll11):
    global l1lll11
    l1lll111 = ord (l11ll11 [-1])
    l1ll11l1 = l11ll11 [:-1]
    l11l111 = l1lll111 % len (l1ll11l1)
    l1llll1 = l1ll11l1 [:l11l111] + l1ll11l1 [l11l111:]
    if l1llllll:
        l1lll1l = l1l1l1 () .join ([unichr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    else:
        l1lll1l = str () .join ([chr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    return eval (l1lll1l)
import logging
import os
import re
from l1l import l1lllllll
logger = logging.getLogger(l1ll1l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1l1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1ll():
    try:
        out = os.popen(l1ll1l1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1ll1l1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1ll1l1 (u"ࠢࠣॶ").join(result)
                logger.info(l1ll1l1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1ll1l1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1ll1l1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1ll1l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1lllllll(l1ll1l1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1ll1l1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1111(l1ll1l1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))