#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1ll = sys.version_info [0] == 2
l1lll1l = 2048
l11l11 = 7
def l1ll11l1 (l11l1ll):
    global l1l1ll
    l1l111l = ord (l11l1ll [-1])
    l11l11l = l11l1ll [:-1]
    l11ll = l1l111l % len (l11l11l)
    l1l111 = l11l11l [:l11ll] + l11l11l [l11ll:]
    if l1lll1ll:
        l11ll11 = l111ll1 () .join ([unichr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    return eval (l11ll11)
import logging
import os
import re
from l11llll import l1lll1ll1
logger = logging.getLogger(l1ll11l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1llll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll11l1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l1():
    try:
        out = os.popen(l1ll11l1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll11l1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll11l1 (u"ࠤࠥॸ").join(result)
                logger.info(l1ll11l1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll11l1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll11l1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll11l1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll1ll1(l1ll11l1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll11l1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1llll1(l1ll11l1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))