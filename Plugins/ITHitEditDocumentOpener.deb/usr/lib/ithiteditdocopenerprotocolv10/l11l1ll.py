#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1l = 7
def l11 (l1ll11l1):
    global l1l1111
    l1lll = ord (l1ll11l1 [-1])
    l1llllll = l1ll11l1 [:-1]
    l1l11l = l1lll % len (l1llllll)
    l1111ll = l1llllll [:l1l11l] + l1llllll [l1l11l:]
    if l111l1l:
        l11l = l11l1l1 () .join ([unichr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    return eval (l11l)
import logging
import os
import re
from l1l1ll1 import l11111l1
logger = logging.getLogger(l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11111l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1lll():
    try:
        out = os.popen(l11 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11 (u"ࠤࠥॸ").join(result)
                logger.info(l11 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111l1(l11 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11111l(l11 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))