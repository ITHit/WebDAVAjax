#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import gi
gi.require_version(l1l11l (u"࠭ࡇࡵ࡭ࠪ঻"), l1l11l (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11ll1l1
import logging
logger = logging.getLogger(l1l11l (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l11l1(Gtk.Window):
    def __init__(self, l1l1llll11, l1l1lll11l):
        Gtk.Window.__init__(self)
        self.l1l1=30
        self.l1l11lll1l = False
        self.service = l1l1llll11
        self.l11llll=l1l1lll11l
        self.l1llll=l11ll1l1.l1l111l1
        self.l1ll111111 = Gtk.ListStore(str)
        self.l1ll111l11()
    def l1lll1111l(self, service):
        l1ll1l1ll1 = self.l1llll.l1l1l11l(l1l11l (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1ll1l1ll1
    def l1ll111l11(self, l1l1llll11=None):
        if l1l1llll11:
            self.l1ll111111.clear()
            l1ll11l11l=self.l1lll1111l(l1l1llll11)
            self.l1ll111111.append([l1l11l (u"ࠥࠦি")])
            for l11llll in l1ll11l11l:
                self.l1ll111111.append([l11llll])
        else:
            self.l1ll111111.clear()
            self.l1ll111111.append([l1l11l (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1l1l11111(self, widget, data=None):
        l1l1ll11ll= widget.get_active()
        if data == l1l11l (u"ࠧ࠷ࠢু") and l1l1ll11ll:
            self.l1ll111l11()
            self.l1ll11111l.set_active(0)
            self.l1l1ll1l1l.set_text(l1l11l (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1l1ll1l1l.set_sensitive(False)
            self.l1ll11111l.set_sensitive(False)
        else:
            self.l1ll111l11(l1l1llll11=self.service)
            self.l1ll11111l.set_active(0)
            self.l1l1ll1l1l.set_text(l1l11l (u"ࠢࠣৃ"))
            self.l1ll11111l.set_sensitive(True)
            self.l1l1ll1l1l.set_sensitive(True)
    def l1l1l1l111(self, widget):
        if widget.get_active():
            l11llll = widget.get_child().get_text()
        else:
            l11llll = self.l1ll111111[widget.get_active()][0]
        password = self.l1ll1ll1ll(self.service, l11llll)
        if password:
            self.l1l1ll1l1l.set_text(password)
        else:
            self.l1l1ll1l1l.set_text(l1l11l (u"ࠣࠤৄ"))
    def l1l1ll1lll(self, l11llll, pwd, service):
        keyring.set_password(service, l11llll, pwd)
        l1ll1l1ll1=self.l1llll.l1l1l11l(l1l11l (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l11llll in l1ll1l1ll1:
            value = self.l1llll.get_value(l1l11l (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l1llll.l1l11lll(l1l11l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l1l11l (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l11llll))
    def l1ll1ll1ll(self, service, l11llll):
        l1l1ll111l = keyring.get_password(service, l11llll)
        return l1l1ll111l
    def l1ll1ll11l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll11ll11(self, widget, data=None):
        self.l1l11lll1l=widget.get_active()
    def l11(self, message, title=l1l11l (u"࠭ࠧ৉"), l11l11l11=True):
        if l11l11l11:
            l1lll11111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1lll11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1llll1l = Gtk.MessageDialog(self,
            l1lll11111,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1llll1l.set_title(title)
        l1l1llll1l.set_default_response(Gtk.ResponseType.OK)
        l1ll11l111 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll11ll1l = Gtk.VBox()
        l1ll1llll1 = Gtk.Box(spacing=1)
        l1ll1llll1.set_homogeneous(False)
        l1l1lll1ll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll1ll.set_homogeneous(False)
        l1ll1ll1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1ll1l1.set_homogeneous(False)
        l1ll1llll1.pack_start(l1l1lll1ll, True, True, 0)
        l1ll1llll1.pack_start(l1ll1ll1l1, True, True, 0)
        l1l1l1ll1l = l1l1llll1l.get_content_area()
        l1l1l1l11l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l1ll1l.pack_start(l1l1l1l11l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l1lll1 = Gtk.Label()
        l1ll1lll1l = Gtk.Label()
        l1ll1lll1l.set_text(l1l11l (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1ll1lll1l, True, True, 0)
        l1l1l1lll1.set_text(l1l11l (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1l1l1lll1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l1lll1, 0, 1, 0, 1)
        l1ll1l1l11 = Gtk.RadioButton.new_with_label_from_widget(None, l1l11l (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1ll1l1l11.connect(l1l11l (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1l1l11111, l1l11l (u"ࠦ࠶ࠨৎ"))
        table.attach(l1ll1l1l11, 1, 2, 0, 1)
        l1ll1lllll = Gtk.RadioButton.new_with_label_from_widget(l1ll1l1l11, l1l11l (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1ll1lllll.connect(l1l11l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1l1l11111, l1l11l (u"ࠢ࠳ࠤ৑"))
        table.attach(l1ll1lllll, 1, 2, 1, 2)
        l1l1l1ll11 = Gtk.Label()
        l1l1l1ll11.set_text(l1l11l (u"ࠣࠢࠥ৒"))
        table.attach(l1l1l1ll11, 0, 1, 4, 6)
        l1l1ll1111 = Gtk.Label()
        l1l1ll1111.set_text(l1l11l (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1l1ll1111.set_justify(Gtk.Justification.RIGHT)
        l1l1ll1111.set_alignment(xalign=1, yalign=0.5)
        self.l1ll11111l = Gtk.ComboBox.new_with_model_and_entry(self.l1ll111111)
        self.l1ll11111l.set_entry_text_column(0)
        table.attach(l1l1ll1111, 0, 1, 6, 8)
        table.attach(self.l1ll11111l, 1, 3, 6, 8)
        self.l1ll11111l.connect(l1l11l (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1l1l1l111)
        l1l1l1l1l1 = Gtk.Label()
        l1l1l1l1l1.set_text(l1l11l (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1l1l1l1l1.set_justify(Gtk.Justification.RIGHT)
        l1l1l1l1l1.set_alignment(xalign=1, yalign=0.5)
        self.l1l1ll1l1l = Gtk.Entry()
        self.l1l1ll1l1l.set_visibility(False)
        self.l1l1ll1l1l.connect(l1l11l (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1ll1ll11l, l1l1llll1l)
        table.attach(l1l1l1l1l1, 0, 1, 8, 10)
        table.attach(self.l1l1ll1l1l, 1, 3, 8, 10)
        l1ll1l111l = Gtk.CheckButton(l1l11l (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1ll1l111l.connect(l1l11l (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1ll11ll11, l1ll1l111l)
        l1ll1l111l.set_active(False)
        table.attach(l1ll1l111l, 1, 3, 12, 14)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l1l11l (u"ࠣࠢࠥ৙") * 5)
        l1ll11ll1l.pack_start(l1ll1111ll, True, True, 0)
        if self.l11llll:
            l1ll1lllll.set_active(True)
            self.l1ll11111l.set_active(0)
            self.l1ll11111l.set_sensitive(True)
            self.l1l1ll1l1l.set_text(l1l11l (u"ࠤࠥ৚"))
            self.l1l1ll1l1l.set_sensitive(True)
        else:
            self.l1ll11111l.set_active(0)
            self.l1ll11111l.set_sensitive(False)
            self.l1l1ll1l1l.set_text(l1l11l (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1l1ll1l1l.set_sensitive(False)
        l1ll11l111.pack_start(vbox, True, True, 0)
        l1ll11l111.pack_start(table, True, True, 0)
        l1ll11l111.pack_end(l1ll11ll1l, True, True, 0)
        l1l1l1l11l.pack_start(l1ll11l111, True, True, 0)
        l1l1llll1l.show_all()
        response = l1l1llll1l.run()
        if self.l1ll11111l.get_active():
            l11llll = self.l1ll11111l.get_child().get_text()
        else:
            l11llll = self.l1ll111111[self.l1ll11111l.get_active()][0]
        pwd = self.l1l1ll1l1l.get_text()
        l1l1llll1l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l11lll1l:
                self.l1l1ll1lll(l11llll, pwd, self.service)
            return l11llll, pwd
        else:
            return l1l11l (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l1l11l (u"ࠬ࠭ঢ়")
class l1ll11lll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1l1111l(self, l1l1ll11):
        l1l1llllll = Gtk.ScrolledWindow()
        l1l1llllll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll11lll1=None
        self.l1l1l11lll = Gtk.TextBuffer()
        self.l1l1l11lll.set_text(l1l1ll11)
        self.set_style()
        regexp= l1l11l (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll11llll = self._1l11lll11(l1l1ll11, regexp)
        self.l1l1l11l1l(l1ll11llll, self.l1l1l11lll.get_start_iter())
        self.l1l11l1l1l = Gtk.TextView(buffer=self.l1l1l11lll)
        self.l1l11l1l1l.set_property(l1l11l (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1l11l1l1l.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11l1l1l.connect(l1l11l (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1l1ll1ll1)
        self.l1l11l1l1l.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1llllll.set_size_request(300,100)
        self.l1l11l1l1l.show()
        l1l1llllll.add(self.l1l11l1l1l)
        l1l1llllll.show()
        return l1l1llllll
    def _1l1ll1ll1(self, *args, **kwargs):
        l1l1lll111, l1l1ll11l1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1lll111, l1l1ll11l1).get_tags()
        if not self.l1ll11lll1:
            self.l1ll11lll1 = args[1].window.get_cursor()
            self.l1ll111lll = Gdk.Cursor(Gdk.CursorType.l1l1lll1l1)
        elif tag:
            args[1].window.set_cursor(self.l1ll111lll)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll11lll1:
                args[1].window.set_cursor(self.l1ll11lll1)
    def _1l11lll11(self, l1l1ll11, l1ll1l11l1):
        res=[]
        l1l11llll1=re.findall(l1ll1l11l1,l1l1ll11)
        for l1l11ll11l in l1l11llll1:
            for el in l1l11ll11l:
                if el:
                    res.append(el)
        return res
    def l1l1l11l1l(self, l1ll11llll, start):
        l1l1l111l1=0
        for text in l1ll11llll:
            end = self.l1l1l11lll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l111l1+=1
                l1l1lllll1, l1ll1l1lll = match
                tag = self.l1l1l11lll.create_tag(str(l1l1l111l1), foreground=l1l11l (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1l11l (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1ll11l1l1, text)
                self.l1l1l11lll.apply_tag(tag, l1l1lllll1, l1ll1l1lll)
                self.l1l1l11l1l(l1ll11llll, l1ll1l1lll)
    def _1ll11l1l1(self, tag, widget, l1ll1ll111, _1ll1111l1, text):
        _1ll11l1ll = l1ll1ll111.type
        _1ll1l11ll = l1ll1ll111.window
        if _1ll11l1ll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1ll11l1ll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll1ll111.button
            self.l1ll11lll1 = Gdk.Cursor(Gdk.CursorType.l1l1lll1l1)
            if _1ll11l1ll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1l11l (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1l11llll(self, message, title=l1l11l (u"ࠬ࠭৤"), l11l11l11=True, l1l1l111ll=None):
        if l11l11l11:
            l1lll11111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1lll11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1lll11111,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1l111ll:
            l1l1l1ll1l = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1llll1 = Gtk.HBox(spacing=0)
            l1l11l1lll = Gtk.HBox(spacing=5)
            l1ll1l1l1l = Gtk.Label()
            l1ll1l1l1l.set_markup(l1l11l (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1ll1l1l1l.set_line_wrap(True)
            l1ll1l1l1l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1l11l (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1l11l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11l11.show()
            l1l1l1llll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1llll.show()
            l1l1l11ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11ll1.show()
            l1ll1llll1.pack_start(separator, True, True, 0)
            l1ll1llll1.pack_start(l1l1l11l11, True, True, 0)
            l1ll1llll1.pack_start(l1l1l1llll, True, True, 0)
            l1ll1llll1.pack_start(l1l1l11ll1, True, True, 0)
            l1ll1llll1.pack_start(l1ll1l1l1l, False, True, 0)
            l1l1l1l1ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l1ll.show()
            l1ll1llll1.pack_end(l1l1l1l1ll, True, True, 0)
            l1ll111ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111ll1.show()
            vbox.pack_start(l1ll1llll1, True, True, 0)
            l1l1llllll=self.__1l1l1111l(l1l1ll11=l1l1l111ll)
            vbox.pack_start(l1l1llllll, False, False, 0)
            vbox.pack_end(l1ll111ll1, False, False, 0)
            l1l11l1lll.pack_start(vbox, True, True,5)
            l1l11l1lll.show()
            l1l1l1ll1l.pack_end(l1l11l1lll, False, False, 0)
            vbox.show()
            l1ll1llll1.show()
        window.run()
class l111l111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11ll111(self, widget, l1l11ll1l1):
        if l1l11ll1l1 == Gtk.ResponseType.OK:
            self.result = l1l11l (u"ࠣࡑࡎࠦ১")
        elif l1l11ll1l1 == Gtk.ResponseType.CANCEL:
            self.result = l1l11l (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1l11ll1l1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1l11l (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1l1ll1l1(self, title=l1l11l (u"ࠦࠧ৪"), message=l1l11l (u"ࠧࠨ৫") , l11l11l11=True):
        if l11l11l11:
            l1lll11111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1lll11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1lll11111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1l11l (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1l11ll111)
        window.run()
class l1ll111l1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l11l1ll1=None
        self.result = None
    def l1l11ll111(self, widget, l1l11ll1l1):
        print(widget, l1l11ll1l1)
        if l1l11ll1l1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l11ll1l1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l11ll1l1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll11ll11(self, widget, l1l11ll1ll):
        if l1l11ll1ll.get_active():
            self.l1l11l1ll1 = 1
        else:
            self.l1l11l1ll1 = 0
    def l1ll1lll11(self, title=l1l11l (u"ࠢࠣ৭"), message=l1l11l (u"ࠣࠤ৮"), l1ll1l1111 =l1l11l (u"ࠤࠥ৯"),l11l11l11=True):
        if l11l11l11:
            l1lll11111= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1lll11111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1lll11111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1l11l (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1l11ll111)
        l1ll1l111l = Gtk.CheckButton(l1ll1l1111)
        l1ll1l111l.connect(l1l11l (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1ll11ll11, l1ll1l111l)
        l1ll1l111l.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll1l111l, expand=True, fill=True, padding=0)
        l1ll1l111l.show()
        window.run()
def l1l1111l1(title, msg, l1ll1l1111=l1l11l (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l11l11l11=True):
    result=None
    try:
        l1l11lllll = l1ll111l1l()
        l1l11lllll.l1ll1lll11(title, msg, l1ll1l1111, l11l11l11)
        result = {l1l11l (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1l11lllll.result,  l1l11l (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1l11lllll.l1l11l1ll1}
    except Exception as e:
        logger.exception(l1l11l (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l1l11l (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l1111l11l = l1ll11lll()
    message= l1l11l (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1l1ll1l11 = l1l11l (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l1111l11l.l1l11llll(message, l1l11l (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l11l11l11=True, l1l1l111ll=l1l1ll1l11)