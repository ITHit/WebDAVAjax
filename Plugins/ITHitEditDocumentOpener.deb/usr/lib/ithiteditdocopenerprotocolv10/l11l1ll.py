#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1lll1l = 2048
l1llll = 7
def l111 (l1l1111):
    global l1l11l
    l1llllll = ord (l1l1111 [-1])
    l111111 = l1l1111 [:-1]
    l1ll1ll = l1llllll % len (l111111)
    l11l = l111111 [:l1ll1ll] + l111111 [l1ll1ll:]
    if l1ll1:
        l11l111 = l1ll11 () .join ([unichr (ord (char) - l1lll1l - (l1ll1lll + l1llllll) % l1llll) for l1ll1lll, char in enumerate (l11l)])
    else:
        l11l111 = str () .join ([chr (ord (char) - l1lll1l - (l1ll1lll + l1llllll) % l1llll) for l1ll1lll, char in enumerate (l11l)])
    return eval (l11l111)
import gi
gi.require_version(l111 (u"ࠨࡉࡷ࡯ࠬঽ"), l111 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11ll11l
import logging
logger = logging.getLogger(l111 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1111l1(Gtk.Window):
    def __init__(self, l1ll1l1lll, l1ll11ll1l):
        Gtk.Window.__init__(self)
        self.l1ll11l=30
        self.l1l1ll1111 = False
        self.service = l1ll1l1lll
        self.l11ll1l=l1ll11ll1l
        self.ll=l11ll11l.l1l11l1l
        self.l1ll11llll = Gtk.ListStore(str)
        self.l1l11ll11l()
    def l1l1lll11l(self, service):
        l1l1l111l1 = self.ll.l1l1ll1l(l111 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1l111l1
    def l1l11ll11l(self, l1ll1l1lll=None):
        if l1ll1l1lll:
            self.l1ll11llll.clear()
            l1l11l11ll=self.l1l1lll11l(l1ll1l1lll)
            self.l1ll11llll.append([l111 (u"ࠧࠨু")])
            for l11ll1l in l1l11l11ll:
                self.l1ll11llll.append([l11ll1l])
        else:
            self.l1ll11llll.clear()
            self.l1ll11llll.append([l111 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1l1l111(self, widget, data=None):
        l1l1l1ll1l= widget.get_active()
        if data == l111 (u"ࠢ࠲ࠤৃ") and l1l1l1ll1l:
            self.l1l11ll11l()
            self.l1l1llllll.set_active(0)
            self.l1ll1l11ll.set_text(l111 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1l11ll.set_sensitive(False)
            self.l1l1llllll.set_sensitive(False)
        else:
            self.l1l11ll11l(l1ll1l1lll=self.service)
            self.l1l1llllll.set_active(0)
            self.l1ll1l11ll.set_text(l111 (u"ࠤࠥ৅"))
            self.l1l1llllll.set_sensitive(True)
            self.l1ll1l11ll.set_sensitive(True)
    def l1ll1l111l(self, widget):
        if widget.get_active():
            l11ll1l = widget.get_child().get_text()
        else:
            l11ll1l = self.l1ll11llll[widget.get_active()][0]
        password = self.l1l11lll1l(self.service, l11ll1l)
        if password:
            self.l1ll1l11ll.set_text(password)
        else:
            self.l1ll1l11ll.set_text(l111 (u"ࠥࠦ৆"))
    def l1l1l1111l(self, l11ll1l, pwd, service):
        keyring.set_password(service, l11ll1l, pwd)
        l1l1l111l1=self.ll.l1l1ll1l(l111 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l11ll1l in l1l1l111l1:
            value = self.ll.get_value(l111 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.ll.l1l11111(l111 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l111 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l11ll1l))
    def l1l11lll1l(self, service, l11ll1l):
        l1ll11ll11 = keyring.get_password(service, l11ll1l)
        return l1ll11ll11
    def l1l1ll11l1(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1l1ll1(self, widget, data=None):
        self.l1l1ll1111=widget.get_active()
    def l1l1l(self, message, title=l111 (u"ࠨࠩো"), l1l11l1ll=True):
        if l1l11l1ll:
            l1ll1ll111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1ll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll1l1l1l = Gtk.MessageDialog(self,
            l1ll1ll111,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll1l1l1l.set_title(title)
        l1ll1l1l1l.set_default_response(Gtk.ResponseType.OK)
        l1l1l1l11l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l11l1l1l = Gtk.VBox()
        l1l1ll1l1l = Gtk.Box(spacing=1)
        l1l1ll1l1l.set_homogeneous(False)
        l1l1l1ll11 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1l1ll11.set_homogeneous(False)
        l1l11l1lll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l1lll.set_homogeneous(False)
        l1l1ll1l1l.pack_start(l1l1l1ll11, True, True, 0)
        l1l1ll1l1l.pack_start(l1l11l1lll, True, True, 0)
        l1l1ll111l = l1ll1l1l1l.get_content_area()
        l1ll11111l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1ll111l.pack_start(l1ll11111l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l11111 = Gtk.Label()
        l1ll11lll1 = Gtk.Label()
        l1ll11lll1.set_text(l111 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1ll11lll1, True, True, 0)
        l1l1l11111.set_text(l111 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1l11111.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l11111, 0, 1, 0, 1)
        l1l11ll1l1 = Gtk.RadioButton.new_with_label_from_widget(None, l111 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l11ll1l1.connect(l111 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1l1l111, l111 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l11ll1l1, 1, 2, 0, 1)
        l1ll111ll1 = Gtk.RadioButton.new_with_label_from_widget(l1l11ll1l1, l111 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll111ll1.connect(l111 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1l1l111, l111 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll111ll1, 1, 2, 1, 2)
        l1ll1l1l11 = Gtk.Label()
        l1ll1l1l11.set_text(l111 (u"ࠥࠤࠧ৔"))
        table.attach(l1ll1l1l11, 0, 1, 4, 6)
        l1l1lll1ll = Gtk.Label()
        l1l1lll1ll.set_text(l111 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1lll1ll.set_justify(Gtk.Justification.RIGHT)
        l1l1lll1ll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1llllll = Gtk.ComboBox.new_with_model_and_entry(self.l1ll11llll)
        self.l1l1llllll.set_entry_text_column(0)
        table.attach(l1l1lll1ll, 0, 1, 6, 8)
        table.attach(self.l1l1llllll, 1, 3, 6, 8)
        self.l1l1llllll.connect(l111 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1ll1l111l)
        l1l1l111ll = Gtk.Label()
        l1l1l111ll.set_text(l111 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l1l111ll.set_justify(Gtk.Justification.RIGHT)
        l1l1l111ll.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1l11ll = Gtk.Entry()
        self.l1ll1l11ll.set_visibility(False)
        self.l1ll1l11ll.connect(l111 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1ll11l1, l1ll1l1l1l)
        table.attach(l1l1l111ll, 0, 1, 8, 10)
        table.attach(self.l1ll1l11ll, 1, 3, 8, 10)
        l1ll111lll = Gtk.CheckButton(l111 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll111lll.connect(l111 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1ll1l1ll1, l1ll111lll)
        l1ll111lll.set_active(False)
        table.attach(l1ll111lll, 1, 3, 12, 14)
        l1ll1111ll = Gtk.Label()
        l1ll1111ll.set_text(l111 (u"ࠥࠤࠧ৛") * 5)
        l1l11l1l1l.pack_start(l1ll1111ll, True, True, 0)
        if self.l11ll1l:
            l1ll111ll1.set_active(True)
            self.l1l1llllll.set_active(0)
            self.l1l1llllll.set_sensitive(True)
            self.l1ll1l11ll.set_text(l111 (u"ࠦࠧড়"))
            self.l1ll1l11ll.set_sensitive(True)
        else:
            self.l1l1llllll.set_active(0)
            self.l1l1llllll.set_sensitive(False)
            self.l1ll1l11ll.set_text(l111 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1l11ll.set_sensitive(False)
        l1l1l1l11l.pack_start(vbox, True, True, 0)
        l1l1l1l11l.pack_start(table, True, True, 0)
        l1l1l1l11l.pack_end(l1l11l1l1l, True, True, 0)
        l1ll11111l.pack_start(l1l1l1l11l, True, True, 0)
        l1ll1l1l1l.show_all()
        response = l1ll1l1l1l.run()
        if self.l1l1llllll.get_active():
            l11ll1l = self.l1l1llllll.get_child().get_text()
        else:
            l11ll1l = self.l1ll11llll[self.l1l1llllll.get_active()][0]
        pwd = self.l1ll1l11ll.get_text()
        l1ll1l1l1l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1ll1111:
                self.l1l1l1111l(l11ll1l, pwd, self.service)
            return l11ll1l, pwd
        else:
            return l111 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l111 (u"ࠧࠨয়")
class l1111l111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1l1llll(self, l11llll1):
        l1l1ll11ll = Gtk.ScrolledWindow()
        l1l1ll11ll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1l11lll=None
        self.l1ll1l1111 = Gtk.TextBuffer()
        self.l1ll1l1111.set_text(l11llll1)
        self.set_style()
        regexp= l111 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll11l1ll = self._1l1llll11(l11llll1, regexp)
        self.l1ll1ll1ll(l1ll11l1ll, self.l1ll1l1111.get_start_iter())
        self.l1l1l11l11 = Gtk.TextView(buffer=self.l1ll1l1111)
        self.l1l1l11l11.set_property(l111 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1l11l11.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l11l11.connect(l111 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1ll1ll1)
        self.l1l1l11l11.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1ll11ll.set_size_request(300,100)
        self.l1l1l11l11.show()
        l1l1ll11ll.add(self.l1l1l11l11)
        l1l1ll11ll.show()
        return l1l1ll11ll
    def _1l1ll1ll1(self, *args, **kwargs):
        l1l11lllll, l1ll1111l1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l11lllll, l1ll1111l1).get_tags()
        if not self.l1l1l11lll:
            self.l1l1l11lll = args[1].window.get_cursor()
            self.l1l11ll1ll = Gdk.Cursor(Gdk.CursorType.l1l11ll111)
        elif tag:
            args[1].window.set_cursor(self.l1l11ll1ll)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1l11lll:
                args[1].window.set_cursor(self.l1l1l11lll)
    def _1l1llll11(self, l11llll1, l1ll111111):
        res=[]
        l1l11l1ll1=re.findall(l1ll111111,l11llll1)
        for l1ll11l11l in l1l11l1ll1:
            for el in l1ll11l11l:
                if el:
                    res.append(el)
        return res
    def l1ll1ll1ll(self, l1ll11l1ll, start):
        l1ll1ll11l=0
        for text in l1ll11l1ll:
            end = self.l1ll1l1111.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1ll11l+=1
                l1ll1ll1l1, l1l1l1l1ll = match
                tag = self.l1ll1l1111.create_tag(str(l1ll1ll11l), foreground=l111 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l111 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1lllll1, text)
                self.l1ll1l1111.apply_tag(tag, l1ll1ll1l1, l1l1l1l1ll)
                self.l1ll1ll1ll(l1ll11l1ll, l1l1l1l1ll)
    def _1l1lllll1(self, tag, widget, l1ll1lllll, _1ll1lll11, text):
        _1l11l1l11 = l1ll1lllll.type
        _1l1ll1lll = l1ll1lllll.window
        if _1l11l1l11 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11l1l11 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll1lllll.button
            self.l1l1l11lll = Gdk.Cursor(Gdk.CursorType.l1l11ll111)
            if _1l11l1l11 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l111 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1ll1ll1l(self, message, title=l111 (u"ࠧࠨ০"), l1l11l1ll=True, l1l11llll1=None):
        if l1l11l1ll:
            l1ll1ll111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1ll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll1ll111,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l11llll1:
            l1l1ll111l = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1ll1l1l = Gtk.HBox(spacing=0)
            l1ll1l11l1 = Gtk.HBox(spacing=5)
            l1l1lll111 = Gtk.Label()
            l1l1lll111.set_markup(l111 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1lll111.set_line_wrap(True)
            l1l1lll111.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l111 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1ll1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll1l11.show()
            l1l1l11ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11ll1.show()
            l1l1llll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1llll1l.show()
            l1l1ll1l1l.pack_start(separator, True, True, 0)
            l1l1ll1l1l.pack_start(l1l1ll1l11, True, True, 0)
            l1l1ll1l1l.pack_start(l1l1l11ll1, True, True, 0)
            l1l1ll1l1l.pack_start(l1l1llll1l, True, True, 0)
            l1l1ll1l1l.pack_start(l1l1lll111, False, True, 0)
            l1ll111l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111l11.show()
            l1l1ll1l1l.pack_end(l1ll111l11, True, True, 0)
            l1ll111l1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111l1l.show()
            vbox.pack_start(l1l1ll1l1l, True, True, 0)
            l1l1ll11ll=self.__1l1l1llll(l11llll1=l1l11llll1)
            vbox.pack_start(l1l1ll11ll, False, False, 0)
            vbox.pack_end(l1ll111l1l, False, False, 0)
            l1ll1l11l1.pack_start(vbox, True, True,5)
            l1ll1l11l1.show()
            l1l1ll111l.pack_end(l1ll1l11l1, False, False, 0)
            vbox.show()
            l1l1ll1l1l.show()
        window.run()
class l1l1llll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l1l1l1(self, widget, l1ll11l1l1):
        if l1ll11l1l1 == Gtk.ResponseType.OK:
            self.result = l111 (u"ࠥࡓࡐࠨ৩")
        elif l1ll11l1l1 == Gtk.ResponseType.CANCEL:
            self.result = l111 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll11l1l1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l111 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1ll11l1l(self, title=l111 (u"ࠨࠢ৬"), message=l111 (u"ࠢࠣ৭") , l1l11l1ll=True):
        if l1l11l1ll:
            l1ll1ll111 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1ll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1ll111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l111 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1l1l1l1)
        window.run()
class l1l1l11l1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1lll1=None
        self.result = None
    def l1l1l1l1l1(self, widget, l1ll11l1l1):
        print(widget, l1ll11l1l1)
        if l1ll11l1l1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll11l1l1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll11l1l1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1l1ll1(self, widget, l1ll11l111):
        if l1ll11l111.get_active():
            self.l1l1l1lll1 = 1
        else:
            self.l1l1l1lll1 = 0
    def l1ll1lll1l(self, title=l111 (u"ࠤࠥ৯"), message=l111 (u"ࠥࠦৰ"), l1ll1llll1 =l111 (u"ࠦࠧৱ"),l1l11l1ll=True):
        if l1l11l1ll:
            l1ll1ll111= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1ll111 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1ll111,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l111 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1l1l1l1)
        l1ll111lll = Gtk.CheckButton(l1ll1llll1)
        l1ll111lll.connect(l111 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1ll1l1ll1, l1ll111lll)
        l1ll111lll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll111lll, expand=True, fill=True, padding=0)
        l1ll111lll.show()
        window.run()
def l1lll11l1(title, msg, l1ll1llll1=l111 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1l11l1ll=True):
    result=None
    try:
        l1l1lll1l1 = l1l1l11l1l()
        l1l1lll1l1.l1ll1lll1l(title, msg, l1ll1llll1, l1l11l1ll)
        result = {l111 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1lll1l1.result,  l111 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1lll1l1.l1l1l1lll1}
    except Exception as e:
        logger.exception(l111 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l111 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11l1lll1 = l1111l111()
    message= l111 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l11lll11 = l111 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11l1lll1.l1ll1ll1l(message, l111 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1l11l1ll=True, l1l11llll1=l1l11lll11)