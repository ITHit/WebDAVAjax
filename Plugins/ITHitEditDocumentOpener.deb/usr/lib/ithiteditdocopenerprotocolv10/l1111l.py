#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l1l1ll = 7
def l1ll11 (l1l1ll1):
    global l1llll1
    l111 = ord (l1l1ll1 [-1])
    l1ll11l = l1l1ll1 [:-1]
    l11l11l = l111 % len (l1ll11l)
    l1llll = l1ll11l [:l11l11l] + l1ll11l [l11l11l:]
    if l111l1:
        l1111l1 = l11111l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    return eval (l1111l1)
import gi
gi.require_version(l1ll11 (u"࠭ࡇࡵ࡭ࠪ঻"), l1ll11 (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l111l1
import logging
logger = logging.getLogger(l1ll11 (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l11l1l(Gtk.Window):
    def __init__(self, l1l11lll11, l1ll1ll11l):
        Gtk.Window.__init__(self)
        self.l1lllll1=30
        self.l1l1l1111l = False
        self.service = l1l11lll11
        self.l11llll=l1ll1ll11l
        self.l1lllll=l1l111l1.l1l1l1l1
        self.l1l1l11ll1 = Gtk.ListStore(str)
        self.l1l1l11111()
    def l1ll111111(self, service):
        l1l1l11l1l = self.l1lllll.l1l11lll(l1ll11 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1l1l11l1l
    def l1l1l11111(self, l1l11lll11=None):
        if l1l11lll11:
            self.l1l1l11ll1.clear()
            l1l1l11l11=self.l1ll111111(l1l11lll11)
            self.l1l1l11ll1.append([l1ll11 (u"ࠥࠦি")])
            for l11llll in l1l1l11l11:
                self.l1l1l11ll1.append([l11llll])
        else:
            self.l1l1l11ll1.clear()
            self.l1l1l11ll1.append([l1ll11 (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1ll11l1l1(self, widget, data=None):
        l1ll1l1lll= widget.get_active()
        if data == l1ll11 (u"ࠧ࠷ࠢু") and l1ll1l1lll:
            self.l1l1l11111()
            self.l1ll1lllll.set_active(0)
            self.l1ll1l1l1l.set_text(l1ll11 (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1ll1l1l1l.set_sensitive(False)
            self.l1ll1lllll.set_sensitive(False)
        else:
            self.l1l1l11111(l1l11lll11=self.service)
            self.l1ll1lllll.set_active(0)
            self.l1ll1l1l1l.set_text(l1ll11 (u"ࠢࠣৃ"))
            self.l1ll1lllll.set_sensitive(True)
            self.l1ll1l1l1l.set_sensitive(True)
    def l1l1l1l111(self, widget):
        if widget.get_active():
            l11llll = widget.get_child().get_text()
        else:
            l11llll = self.l1l1l11ll1[widget.get_active()][0]
        password = self.l1ll11l111(self.service, l11llll)
        if password:
            self.l1ll1l1l1l.set_text(password)
        else:
            self.l1ll1l1l1l.set_text(l1ll11 (u"ࠣࠤৄ"))
    def l1ll1ll1l1(self, l11llll, pwd, service):
        keyring.set_password(service, l11llll, pwd)
        l1l1l11l1l=self.l1lllll.l1l11lll(l1ll11 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l11llll in l1l1l11l1l:
            value = self.l1lllll.get_value(l1ll11 (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l1lllll.l1l1111l(l1ll11 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l1ll11 (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l11llll))
    def l1ll11l111(self, service, l11llll):
        l1ll11ll1l = keyring.get_password(service, l11llll)
        return l1ll11ll1l
    def l1l1ll11l1(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1l111ll(self, widget, data=None):
        self.l1l1l1111l=widget.get_active()
    def l1l1111(self, message, title=l1ll11 (u"࠭ࠧ৉"), l11llll11=True):
        if l11llll11:
            l1l11l1lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1lllll1 = Gtk.MessageDialog(self,
            l1l11l1lll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1lllll1.set_title(title)
        l1l1lllll1.set_default_response(Gtk.ResponseType.OK)
        l1l1ll11ll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1ll11l11l = Gtk.VBox()
        l1l1l11lll = Gtk.Box(spacing=1)
        l1l1l11lll.set_homogeneous(False)
        l1l1lll111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll111.set_homogeneous(False)
        l1l1lll11l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll11l.set_homogeneous(False)
        l1l1l11lll.pack_start(l1l1lll111, True, True, 0)
        l1l1l11lll.pack_start(l1l1lll11l, True, True, 0)
        l1l11llll1 = l1l1lllll1.get_content_area()
        l1l11lll1l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l11llll1.pack_start(l1l11lll1l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l11l1ll1 = Gtk.Label()
        l1l11ll111 = Gtk.Label()
        l1l11ll111.set_text(l1ll11 (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1l11ll111, True, True, 0)
        l1l11l1ll1.set_text(l1ll11 (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1l11l1ll1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l11l1ll1, 0, 1, 0, 1)
        l1l1ll1111 = Gtk.RadioButton.new_with_label_from_widget(None, l1ll11 (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1l1ll1111.connect(l1ll11 (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1ll11l1l1, l1ll11 (u"ࠦ࠶ࠨৎ"))
        table.attach(l1l1ll1111, 1, 2, 0, 1)
        l1l1l1ll11 = Gtk.RadioButton.new_with_label_from_widget(l1l1ll1111, l1ll11 (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1l1l1ll11.connect(l1ll11 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1ll11l1l1, l1ll11 (u"ࠢ࠳ࠤ৑"))
        table.attach(l1l1l1ll11, 1, 2, 1, 2)
        l1l11ll11l = Gtk.Label()
        l1l11ll11l.set_text(l1ll11 (u"ࠣࠢࠥ৒"))
        table.attach(l1l11ll11l, 0, 1, 4, 6)
        l1ll1l11l1 = Gtk.Label()
        l1ll1l11l1.set_text(l1ll11 (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1ll1l11l1.set_justify(Gtk.Justification.RIGHT)
        l1ll1l11l1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1lllll = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l11ll1)
        self.l1ll1lllll.set_entry_text_column(0)
        table.attach(l1ll1l11l1, 0, 1, 6, 8)
        table.attach(self.l1ll1lllll, 1, 3, 6, 8)
        self.l1ll1lllll.connect(l1ll11 (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1l1l1l111)
        l1l1lll1l1 = Gtk.Label()
        l1l1lll1l1.set_text(l1ll11 (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1l1lll1l1.set_justify(Gtk.Justification.RIGHT)
        l1l1lll1l1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1l1l1l = Gtk.Entry()
        self.l1ll1l1l1l.set_visibility(False)
        self.l1ll1l1l1l.connect(l1ll11 (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1l1ll11l1, l1l1lllll1)
        table.attach(l1l1lll1l1, 0, 1, 8, 10)
        table.attach(self.l1ll1l1l1l, 1, 3, 8, 10)
        l1lll11111 = Gtk.CheckButton(l1ll11 (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1lll11111.connect(l1ll11 (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1l1l111ll, l1lll11111)
        l1lll11111.set_active(False)
        table.attach(l1lll11111, 1, 3, 12, 14)
        l1ll1l11ll = Gtk.Label()
        l1ll1l11ll.set_text(l1ll11 (u"ࠣࠢࠥ৙") * 5)
        l1ll11l11l.pack_start(l1ll1l11ll, True, True, 0)
        if self.l11llll:
            l1l1l1ll11.set_active(True)
            self.l1ll1lllll.set_active(0)
            self.l1ll1lllll.set_sensitive(True)
            self.l1ll1l1l1l.set_text(l1ll11 (u"ࠤࠥ৚"))
            self.l1ll1l1l1l.set_sensitive(True)
        else:
            self.l1ll1lllll.set_active(0)
            self.l1ll1lllll.set_sensitive(False)
            self.l1ll1l1l1l.set_text(l1ll11 (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1ll1l1l1l.set_sensitive(False)
        l1l1ll11ll.pack_start(vbox, True, True, 0)
        l1l1ll11ll.pack_start(table, True, True, 0)
        l1l1ll11ll.pack_end(l1ll11l11l, True, True, 0)
        l1l11lll1l.pack_start(l1l1ll11ll, True, True, 0)
        l1l1lllll1.show_all()
        response = l1l1lllll1.run()
        if self.l1ll1lllll.get_active():
            l11llll = self.l1ll1lllll.get_child().get_text()
        else:
            l11llll = self.l1l1l11ll1[self.l1ll1lllll.get_active()][0]
        pwd = self.l1ll1l1l1l.get_text()
        l1l1lllll1.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1l1111l:
                self.l1ll1ll1l1(l11llll, pwd, self.service)
            return l11llll, pwd
        else:
            return l1ll11 (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l1ll11 (u"ࠬ࠭ঢ়")
class l1l111ll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1l1l1ll(self, l1l1ll1l):
        l1lll1111l = Gtk.ScrolledWindow()
        l1lll1111l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l11ll1ll=None
        self.l1l1ll1ll1 = Gtk.TextBuffer()
        self.l1l1ll1ll1.set_text(l1l1ll1l)
        self.set_style()
        regexp= l1ll11 (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll1lll11 = self._1ll111l1l(l1l1ll1l, regexp)
        self.l1l1lll1ll(l1ll1lll11, self.l1l1ll1ll1.get_start_iter())
        self.l1ll1ll111 = Gtk.TextView(buffer=self.l1l1ll1ll1)
        self.l1ll1ll111.set_property(l1ll11 (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1ll1ll111.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll1ll111.connect(l1ll11 (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1l1l1llll)
        self.l1ll1ll111.set_wrap_mode(Gtk.WrapMode.WORD)
        l1lll1111l.set_size_request(300,100)
        self.l1ll1ll111.show()
        l1lll1111l.add(self.l1ll1ll111)
        l1lll1111l.show()
        return l1lll1111l
    def _1l1l1llll(self, *args, **kwargs):
        l1ll1l111l, l1ll11ll11=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1l111l, l1ll11ll11).get_tags()
        if not self.l1l11ll1ll:
            self.l1l11ll1ll = args[1].window.get_cursor()
            self.l1l1l1l1l1 = Gdk.Cursor(Gdk.CursorType.l1l1ll111l)
        elif tag:
            args[1].window.set_cursor(self.l1l1l1l1l1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l11ll1ll:
                args[1].window.set_cursor(self.l1l11ll1ll)
    def _1ll111l1l(self, l1l1ll1l, l1l1ll1l1l):
        res=[]
        l1l1ll1l11=re.findall(l1l1ll1l1l,l1l1ll1l)
        for l1ll1111ll in l1l1ll1l11:
            for el in l1ll1111ll:
                if el:
                    res.append(el)
        return res
    def l1l1lll1ll(self, l1ll1lll11, start):
        l1ll1ll1ll=0
        for text in l1ll1lll11:
            end = self.l1l1ll1ll1.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1ll1ll+=1
                l1l1l111l1, l1ll1111l1 = match
                tag = self.l1l1ll1ll1.create_tag(str(l1ll1ll1ll), foreground=l1ll11 (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1ll11 (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1l11ll1l1, text)
                self.l1l1ll1ll1.apply_tag(tag, l1l1l111l1, l1ll1111l1)
                self.l1l1lll1ll(l1ll1lll11, l1ll1111l1)
    def _1l11ll1l1(self, tag, widget, l1ll11111l, _1l1llll1l, text):
        _1l11l1l1l = l1ll11111l.type
        _1l11lllll = l1ll11111l.window
        if _1l11l1l1l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11l1l1l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll11111l.button
            self.l1l11ll1ll = Gdk.Cursor(Gdk.CursorType.l1l1ll111l)
            if _1l11l1l1l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1ll11 (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1l1111l1(self, message, title=l1ll11 (u"ࠬ࠭৤"), l11llll11=True, l1l1llll11=None):
        if l11llll11:
            l1l11l1lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l11l1lll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1llll11:
            l1l11llll1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1l11lll = Gtk.HBox(spacing=0)
            l1ll1l1111 = Gtk.HBox(spacing=5)
            l1l1ll1lll = Gtk.Label()
            l1l1ll1lll.set_markup(l1ll11 (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1l1ll1lll.set_line_wrap(True)
            l1l1ll1lll.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1ll11 (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll111ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll111ll1.show()
            l1ll1llll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1llll1.show()
            l1ll11llll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11llll.show()
            l1l1l11lll.pack_start(separator, True, True, 0)
            l1l1l11lll.pack_start(l1ll111ll1, True, True, 0)
            l1l1l11lll.pack_start(l1ll1llll1, True, True, 0)
            l1l1l11lll.pack_start(l1ll11llll, True, True, 0)
            l1l1l11lll.pack_start(l1l1ll1lll, False, True, 0)
            l1l1l1l11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l11l.show()
            l1l1l11lll.pack_end(l1l1l1l11l, True, True, 0)
            l1l1l1lll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1lll1.show()
            vbox.pack_start(l1l1l11lll, True, True, 0)
            l1lll1111l=self.__1l1l1l1ll(l1l1ll1l=l1l1llll11)
            vbox.pack_start(l1lll1111l, False, False, 0)
            vbox.pack_end(l1l1l1lll1, False, False, 0)
            l1ll1l1111.pack_start(vbox, True, True,5)
            l1ll1l1111.show()
            l1l11llll1.pack_end(l1ll1l1111, False, False, 0)
            vbox.show()
            l1l1l11lll.show()
        window.run()
class l1lll1l11(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll111l11(self, widget, l1ll111lll):
        if l1ll111lll == Gtk.ResponseType.OK:
            self.result = l1ll11 (u"ࠣࡑࡎࠦ১")
        elif l1ll111lll == Gtk.ResponseType.CANCEL:
            self.result = l1ll11 (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1ll111lll == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1ll11 (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1ll1llll(self, title=l1ll11 (u"ࠦࠧ৪"), message=l1ll11 (u"ࠧࠨ৫") , l11llll11=True):
        if l11llll11:
            l1l11l1lll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1lll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1ll11 (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1ll111l11)
        window.run()
class l1l1l1ll1l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1lll1l=None
        self.result = None
    def l1ll111l11(self, widget, l1ll111lll):
        print(widget, l1ll111lll)
        if l1ll111lll == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll111lll == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll111lll == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1l111ll(self, widget, l1ll1l1ll1):
        if l1ll1l1ll1.get_active():
            self.l1ll1lll1l = 1
        else:
            self.l1ll1lll1l = 0
    def l1ll11l1ll(self, title=l1ll11 (u"ࠢࠣ৭"), message=l1ll11 (u"ࠣࠤ৮"), l1l1llllll =l1ll11 (u"ࠤࠥ৯"),l11llll11=True):
        if l11llll11:
            l1l11l1lll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l11l1lll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l11l1lll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1ll11 (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1ll111l11)
        l1lll11111 = Gtk.CheckButton(l1l1llllll)
        l1lll11111.connect(l1ll11 (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1l1l111ll, l1lll11111)
        l1lll11111.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1lll11111, expand=True, fill=True, padding=0)
        l1lll11111.show()
        window.run()
def l111llll1(title, msg, l1l1llllll=l1ll11 (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l11llll11=True):
    result=None
    try:
        l1ll1l1l11 = l1l1l1ll1l()
        l1ll1l1l11.l1ll11l1ll(title, msg, l1l1llllll, l11llll11)
        result = {l1ll11 (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1ll1l1l11.result,  l1ll11 (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1ll1l1l11.l1ll1lll1l}
    except Exception as e:
        logger.exception(l1ll11 (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l1ll11 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l1l11111l = l1l111ll1()
    message= l1ll11 (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1ll11lll1 = l1ll11 (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l1l11111l.l1l1111l1(message, l1ll11 (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l11llll11=True, l1l1llll11=l1ll11lll1)