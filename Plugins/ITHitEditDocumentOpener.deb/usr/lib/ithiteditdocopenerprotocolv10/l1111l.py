#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import re
class l1l1ll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1111111 = kwargs.get(l11llll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1lllll = kwargs.get(l11llll (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111ll1 = self.l1lllll1l(args)
        if l1111ll1:
            args=args+ l1111ll1
        self.args = [a for a in args]
    def l1lllll1l(self, *args):
        l1111ll1=None
        l1l1ll11 = args[0][0]
        if re.search(l11llll (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l1ll11):
            l1111ll1 = (l11llll (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1111111
                            ,)
        return l1111ll1
class l1llll1ll(Exception):
    def __init__(self, *args, **kwargs):
        l1111ll1 = self.l1lllll1l(args)
        if l1111ll1:
            args = args + l1111ll1
        self.args = [a for a in args]
    def l1lllll1l(self, *args):
        s = l11llll (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l11llll (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1llll11l(Exception):
    pass
class l1(Exception):
    pass
class l1lll1lll(Exception):
    def __init__(self, message, l1lll1ll1, url):
        super(l1lll1lll,self).__init__(message)
        self.l1lll1ll1 = l1lll1ll1
        self.url = url
class l1111l1l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1111l11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1llll111(Exception):
    pass
class l111111l(Exception):
    pass
class l111l111(Exception):
    pass