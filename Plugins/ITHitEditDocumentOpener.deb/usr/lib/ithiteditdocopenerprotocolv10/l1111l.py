#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1llllll = 2048
l11ll1 = 7
def l1lll1 (l1l1lll):
    global l1lllll1
    l11l1l = ord (l1l1lll [-1])
    l1ll111 = l1l1lll [:-1]
    l11l = l11l1l % len (l1ll111)
    l11111l = l1ll111 [:l11l] + l1ll111 [l11l:]
    if l1l11l:
        l1lll = l1 () .join ([unichr (ord (char) - l1llllll - (l11llll + l11l1l) % l11ll1) for l11llll, char in enumerate (l11111l)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1llllll - (l11llll + l11l1l) % l11ll1) for l11llll, char in enumerate (l11111l)])
    return eval (l1lll)
import re
class l1ll11l(Exception):
    def __init__(self, *args,**kwargs):
        self.l111111l = kwargs.get(l1lll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1ll11l1 = kwargs.get(l1lll1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l11111ll = self.l1lllll11(args)
        if l11111ll:
            args=args+ l11111ll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        l11111ll=None
        l1l1llll = args[0][0]
        if re.search(l1lll1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1llll):
            l11111ll = (l1lll1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l111111l
                            ,)
        return l11111ll
class l1lllll1l(Exception):
    def __init__(self, *args, **kwargs):
        l11111ll = self.l1lllll11(args)
        if l11111ll:
            args = args + l11111ll
        self.args = [a for a in args]
    def l1lllll11(self, *args):
        s = l1lll1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1lll1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll11l(Exception):
    pass
class l111111(Exception):
    pass
class l1lll1lll(Exception):
    def __init__(self, message, l1llll1l1, url):
        super(l1lll1lll,self).__init__(message)
        self.l1llll1l1 = l1llll1l1
        self.url = url
class l1lll11ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111ll11(Exception):
    pass