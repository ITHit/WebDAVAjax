#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def l111l (l111l1l):
    global l1l1ll1
    l1l11l1 = ord (l111l1l [-1])
    l1lllll1 = l111l1l [:-1]
    l1l1l1 = l1l11l1 % len (l1lllll1)
    l1ll1lll = l1lllll1 [:l1l1l1] + l1lllll1 [l1l1l1:]
    if l11l11:
        l1llll1l = l111l1 () .join ([unichr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1llll1l = str () .join ([chr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1llll1l)
import gi
gi.require_version(l111l (u"࠭ࡇࡵ࡭ࠪ঻"), l111l (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l1llll
import logging
logger = logging.getLogger(l111l (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l1(Gtk.Window):
    def __init__(self, l1l11ll1ll, l1ll1111ll):
        Gtk.Window.__init__(self)
        self.l1111l=30
        self.l1ll111l1l = False
        self.service = l1l11ll1ll
        self.ll=l1ll1111ll
        self.l11111l=l1l1llll.l1l11lll
        self.l1l1l1l11l = Gtk.ListStore(str)
        self.l1l11lll11()
    def l1ll1l1l11(self, service):
        l1l1ll1111 = self.l11111l.l11ll1ll(l111l (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1l1ll1111
    def l1l11lll11(self, l1l11ll1ll=None):
        if l1l11ll1ll:
            self.l1l1l1l11l.clear()
            l1l1l1ll11=self.l1ll1l1l11(l1l11ll1ll)
            self.l1l1l1l11l.append([l111l (u"ࠥࠦি")])
            for ll in l1l1l1ll11:
                self.l1l1l1l11l.append([ll])
        else:
            self.l1l1l1l11l.clear()
            self.l1l1l1l11l.append([l111l (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1l1l1llll(self, widget, data=None):
        l1ll11111l= widget.get_active()
        if data == l111l (u"ࠧ࠷ࠢু") and l1ll11111l:
            self.l1l11lll11()
            self.l1l11l1lll.set_active(0)
            self.l1l1ll111l.set_text(l111l (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1l1ll111l.set_sensitive(False)
            self.l1l11l1lll.set_sensitive(False)
        else:
            self.l1l11lll11(l1l11ll1ll=self.service)
            self.l1l11l1lll.set_active(0)
            self.l1l1ll111l.set_text(l111l (u"ࠢࠣৃ"))
            self.l1l11l1lll.set_sensitive(True)
            self.l1l1ll111l.set_sensitive(True)
    def l1l11ll11l(self, widget):
        if widget.get_active():
            ll = widget.get_child().get_text()
        else:
            ll = self.l1l1l1l11l[widget.get_active()][0]
        password = self.l1ll111111(self.service, ll)
        if password:
            self.l1l1ll111l.set_text(password)
        else:
            self.l1l1ll111l.set_text(l111l (u"ࠣࠤৄ"))
    def l1ll1l111l(self, ll, pwd, service):
        keyring.set_password(service, ll, pwd)
        l1l1ll1111=self.l11111l.l11ll1ll(l111l (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not ll in l1l1ll1111:
            value = self.l11111l.get_value(l111l (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l11111l.l1l1lll1(l111l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l111l (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, ll))
    def l1ll111111(self, service, ll):
        l1l1l1l1l1 = keyring.get_password(service, ll)
        return l1l1l1l1l1
    def l1ll1l1l1l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1ll1l1l(self, widget, data=None):
        self.l1ll111l1l=widget.get_active()
    def l11l(self, message, title=l111l (u"࠭ࠧ৉"), l111111ll=True):
        if l111111ll:
            l1ll1llll1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1llll1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll11l1ll = Gtk.MessageDialog(self,
            l1ll1llll1,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll11l1ll.set_title(title)
        l1ll11l1ll.set_default_response(Gtk.ResponseType.OK)
        l1ll111l11 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l11ll1 = Gtk.VBox()
        l1ll1l11ll = Gtk.Box(spacing=1)
        l1ll1l11ll.set_homogeneous(False)
        l1ll1lll1l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1lll1l.set_homogeneous(False)
        l1l11ll111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11ll111.set_homogeneous(False)
        l1ll1l11ll.pack_start(l1ll1lll1l, True, True, 0)
        l1ll1l11ll.pack_start(l1l11ll111, True, True, 0)
        l1ll111lll = l1ll11l1ll.get_content_area()
        l1l1l1lll1 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll111lll.pack_start(l1l1l1lll1, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1lll1ll = Gtk.Label()
        l1ll1lll11 = Gtk.Label()
        l1ll1lll11.set_text(l111l (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1ll1lll11, True, True, 0)
        l1l1lll1ll.set_text(l111l (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1l1lll1ll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1lll1ll, 0, 1, 0, 1)
        l1ll11llll = Gtk.RadioButton.new_with_label_from_widget(None, l111l (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1ll11llll.connect(l111l (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1l1l1llll, l111l (u"ࠦ࠶ࠨৎ"))
        table.attach(l1ll11llll, 1, 2, 0, 1)
        l1l1ll1lll = Gtk.RadioButton.new_with_label_from_widget(l1ll11llll, l111l (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1l1ll1lll.connect(l111l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1l1l1llll, l111l (u"ࠢ࠳ࠤ৑"))
        table.attach(l1l1ll1lll, 1, 2, 1, 2)
        l1ll1lllll = Gtk.Label()
        l1ll1lllll.set_text(l111l (u"ࠣࠢࠥ৒"))
        table.attach(l1ll1lllll, 0, 1, 4, 6)
        l1ll111ll1 = Gtk.Label()
        l1ll111ll1.set_text(l111l (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1ll111ll1.set_justify(Gtk.Justification.RIGHT)
        l1ll111ll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l11l1lll = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1l11l)
        self.l1l11l1lll.set_entry_text_column(0)
        table.attach(l1ll111ll1, 0, 1, 6, 8)
        table.attach(self.l1l11l1lll, 1, 3, 6, 8)
        self.l1l11l1lll.connect(l111l (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1l11ll11l)
        l1ll1ll1ll = Gtk.Label()
        l1ll1ll1ll.set_text(l111l (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1ll1ll1ll.set_justify(Gtk.Justification.RIGHT)
        l1ll1ll1ll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1ll111l = Gtk.Entry()
        self.l1l1ll111l.set_visibility(False)
        self.l1l1ll111l.connect(l111l (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1ll1l1l1l, l1ll11l1ll)
        table.attach(l1ll1ll1ll, 0, 1, 8, 10)
        table.attach(self.l1l1ll111l, 1, 3, 8, 10)
        l1l1l1l111 = Gtk.CheckButton(l111l (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1l1l1l111.connect(l111l (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1l1ll1l1l, l1l1l1l111)
        l1l1l1l111.set_active(False)
        table.attach(l1l1l1l111, 1, 3, 12, 14)
        l1lll1111l = Gtk.Label()
        l1lll1111l.set_text(l111l (u"ࠣࠢࠥ৙") * 5)
        l1l1l11ll1.pack_start(l1lll1111l, True, True, 0)
        if self.ll:
            l1l1ll1lll.set_active(True)
            self.l1l11l1lll.set_active(0)
            self.l1l11l1lll.set_sensitive(True)
            self.l1l1ll111l.set_text(l111l (u"ࠤࠥ৚"))
            self.l1l1ll111l.set_sensitive(True)
        else:
            self.l1l11l1lll.set_active(0)
            self.l1l11l1lll.set_sensitive(False)
            self.l1l1ll111l.set_text(l111l (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1l1ll111l.set_sensitive(False)
        l1ll111l11.pack_start(vbox, True, True, 0)
        l1ll111l11.pack_start(table, True, True, 0)
        l1ll111l11.pack_end(l1l1l11ll1, True, True, 0)
        l1l1l1lll1.pack_start(l1ll111l11, True, True, 0)
        l1ll11l1ll.show_all()
        response = l1ll11l1ll.run()
        if self.l1l11l1lll.get_active():
            ll = self.l1l11l1lll.get_child().get_text()
        else:
            ll = self.l1l1l1l11l[self.l1l11l1lll.get_active()][0]
        pwd = self.l1l1ll111l.get_text()
        l1ll11l1ll.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll111l1l:
                self.l1ll1l111l(ll, pwd, self.service)
            return ll, pwd
        else:
            return l111l (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l111l (u"ࠬ࠭ঢ়")
class l1l11llll(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1l1l1ll(self, l1l11111):
        l1ll11ll11 = Gtk.ScrolledWindow()
        l1ll11ll11.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1l11lll=None
        self.l1ll1l1lll = Gtk.TextBuffer()
        self.l1ll1l1lll.set_text(l1l11111)
        self.set_style()
        regexp= l111l (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll1l11l1 = self._1l1l1ll1l(l1l11111, regexp)
        self.l1ll11lll1(l1ll1l11l1, self.l1ll1l1lll.get_start_iter())
        self.l1l11lllll = Gtk.TextView(buffer=self.l1ll1l1lll)
        self.l1l11lllll.set_property(l111l (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1l11lllll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11lllll.connect(l111l (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1l11ll1l1)
        self.l1l11lllll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll11ll11.set_size_request(300,100)
        self.l1l11lllll.show()
        l1ll11ll11.add(self.l1l11lllll)
        l1ll11ll11.show()
        return l1ll11ll11
    def _1l11ll1l1(self, *args, **kwargs):
        l1l1l111ll, l1l1ll1ll1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l111ll, l1l1ll1ll1).get_tags()
        if not self.l1l1l11lll:
            self.l1l1l11lll = args[1].window.get_cursor()
            self.l1lll11111 = Gdk.Cursor(Gdk.CursorType.l1l1ll11l1)
        elif tag:
            args[1].window.set_cursor(self.l1lll11111)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1l11lll:
                args[1].window.set_cursor(self.l1l1l11lll)
    def _1l1l1ll1l(self, l1l11111, l1ll11l111):
        res=[]
        l1ll11ll1l=re.findall(l1ll11l111,l1l11111)
        for l1ll1ll1l1 in l1ll11ll1l:
            for el in l1ll1ll1l1:
                if el:
                    res.append(el)
        return res
    def l1ll11lll1(self, l1ll1l11l1, start):
        l1ll1111l1=0
        for text in l1ll1l11l1:
            end = self.l1ll1l1lll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1111l1+=1
                l1l1lllll1, l1l1llllll = match
                tag = self.l1ll1l1lll.create_tag(str(l1ll1111l1), foreground=l111l (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l111l (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1ll1ll111, text)
                self.l1ll1l1lll.apply_tag(tag, l1l1lllll1, l1l1llllll)
                self.l1ll11lll1(l1ll1l11l1, l1l1llllll)
    def _1ll1ll111(self, tag, widget, l1l1llll11, _1ll1ll11l, text):
        _1l11lll1l = l1l1llll11.type
        _1l1l111l1 = l1l1llll11.window
        if _1l11lll1l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l11lll1l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1llll11.button
            self.l1l1l11lll = Gdk.Cursor(Gdk.CursorType.l1l1ll11l1)
            if _1l11lll1l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l111l (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1ll1l1l1(self, message, title=l111l (u"ࠬ࠭৤"), l111111ll=True, l1l1ll1l11=None):
        if l111111ll:
            l1ll1llll1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1llll1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll1llll1,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l1ll1l11:
            l1ll111lll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1l11ll = Gtk.HBox(spacing=0)
            l1l1l11l1l = Gtk.HBox(spacing=5)
            l1ll11l1l1 = Gtk.Label()
            l1ll11l1l1.set_markup(l111l (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1ll11l1l1.set_line_wrap(True)
            l1ll11l1l1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l111l (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1l11111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l11111.show()
            l1l11llll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11llll1.show()
            l1ll1l1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1ll1.show()
            l1ll1l11ll.pack_start(separator, True, True, 0)
            l1ll1l11ll.pack_start(l1l1l11111, True, True, 0)
            l1ll1l11ll.pack_start(l1l11llll1, True, True, 0)
            l1ll1l11ll.pack_start(l1ll1l1ll1, True, True, 0)
            l1ll1l11ll.pack_start(l1ll11l1l1, False, True, 0)
            l1l1l1111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1111l.show()
            l1ll1l11ll.pack_end(l1l1l1111l, True, True, 0)
            l1l1lll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll11l.show()
            vbox.pack_start(l1ll1l11ll, True, True, 0)
            l1ll11ll11=self.__1l1l1l1ll(l1l11111=l1l1ll1l11)
            vbox.pack_start(l1ll11ll11, False, False, 0)
            vbox.pack_end(l1l1lll11l, False, False, 0)
            l1l1l11l1l.pack_start(vbox, True, True,5)
            l1l1l11l1l.show()
            l1ll111lll.pack_end(l1l1l11l1l, False, False, 0)
            vbox.show()
            l1ll1l11ll.show()
        window.run()
class l1l1ll11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1llll1l(self, widget, l1l1l11l11):
        if l1l1l11l11 == Gtk.ResponseType.OK:
            self.result = l111l (u"ࠣࡑࡎࠦ১")
        elif l1l1l11l11 == Gtk.ResponseType.CANCEL:
            self.result = l111l (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1l1l11l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l111l (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1l1llll1(self, title=l111l (u"ࠦࠧ৪"), message=l111l (u"ࠧࠨ৫") , l111111ll=True):
        if l111111ll:
            l1ll1llll1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1llll1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1llll1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l111l (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1l1llll1l)
        window.run()
class l1l1lll111(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l11l1ll1=None
        self.result = None
    def l1l1llll1l(self, widget, l1l1l11l11):
        print(widget, l1l1l11l11)
        if l1l1l11l11 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1l11l11 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1l11l11 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1ll1l1l(self, widget, l1l1ll11ll):
        if l1l1ll11ll.get_active():
            self.l1l11l1ll1 = 1
        else:
            self.l1l11l1ll1 = 0
    def l1ll11l11l(self, title=l111l (u"ࠢࠣ৭"), message=l111l (u"ࠣࠤ৮"), l1l11l1l1l =l111l (u"ࠤࠥ৯"),l111111ll=True):
        if l111111ll:
            l1ll1llll1= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1llll1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1llll1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l111l (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1l1llll1l)
        l1l1l1l111 = Gtk.CheckButton(l1l11l1l1l)
        l1l1l1l111.connect(l111l (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1l1ll1l1l, l1l1l1l111)
        l1l1l1l111.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1l1l111, expand=True, fill=True, padding=0)
        l1l1l1l111.show()
        window.run()
def l111ll111(title, msg, l1l11l1l1l=l111l (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l111111ll=True):
    result=None
    try:
        l1ll1l1111 = l1l1lll111()
        l1ll1l1111.l1ll11l11l(title, msg, l1l11l1l1l, l111111ll)
        result = {l111l (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1ll1l1111.result,  l111l (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1ll1l1111.l1l11l1ll1}
    except Exception as e:
        logger.exception(l111l (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l111l (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l11l1lll1 = l1l11llll()
    message= l111l (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1l1lll1l1 = l111l (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l11l1lll1.l1ll1l1l1(message, l111l (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l111111ll=True, l1l1ll1l11=l1l1lll1l1)