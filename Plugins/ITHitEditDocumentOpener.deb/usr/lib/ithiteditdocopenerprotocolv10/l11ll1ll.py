#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l1 = sys.version_info [0] == 2
l1l1l11 = 2048
l1ll1l1l = 7
def l11ll1l (l1l11ll):
    global l1lll1l1
    l1l11 = ord (l1l11ll [-1])
    l1 = l1l11ll [:-1]
    l1ll111 = l1l11 % len (l1)
    ll = l1 [:l1ll111] + l1 [l1ll111:]
    if l11l1l1:
        l1l1l1 = l1lll11l () .join ([unichr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1l1l11 - (l111l1 + l1l11) % l1ll1l1l) for l111l1, char in enumerate (ll)])
    return eval (l1l1l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll1lll import l1ll111l
from configobj import ConfigObj
l11ll11l = l11ll1l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1111l = l11ll1l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠺࠻࠺࠳࠶ࠢࡤ")
l1l11111 = l11ll1l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11ll1l (u"ࠣ࠷࠱࠶࠶࠴࠵࠹࠺࠹࠲࠵ࠨࡦ")
l11l1lll=os.path.join(os.environ.get(l11ll1l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11ll1l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11111.replace(l11ll1l (u"ࠦࠥࠨࡩ"), l11ll1l (u"ࠧࡥࠢࡪ")).lower())
l1l1l1l1=os.environ.get(l11ll1l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11ll1l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11lll1l=l1l1111l.replace(l11ll1l (u"ࠣࠢࠥ࡭"), l11ll1l (u"ࠤࡢࠦ࡮"))+l11ll1l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11ll1l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11ll1=os.path.join(os.environ.get(l11ll1l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11lll1l)
elif platform.system() == l11ll1l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1l111=l1ll111l(l11l1lll+l11ll1l (u"ࠢ࠰ࠤࡳ"))
    l1l11ll1 = os.path.join(l1l1l111, l11lll1l)
else:
    l1l11ll1 = os.path.join( l11lll1l)
l1l1l1l1=l1l1l1l1.upper()
if l1l1l1l1 == l11ll1l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1ll1l=logging.DEBUG
elif l1l1l1l1 == l11ll1l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1ll1l = logging.INFO
elif l1l1l1l1 == l11ll1l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1ll1l = logging.WARNING
elif l1l1l1l1 == l11ll1l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1ll1l = logging.ERROR
elif l1l1l1l1 == l11ll1l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1ll1l = logging.CRITICAL
elif l1l1l1l1 == l11ll1l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1ll1l = logging.NOTSET
logger = logging.getLogger(l11ll1l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1ll1l)
l1l11lll = logging.FileHandler(l1l11ll1, mode=l11ll1l (u"ࠣࡹ࠮ࠦࡻ"))
l1l11lll.setLevel(l1l1ll1l)
formatter = logging.Formatter(l11ll1l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11ll1l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l11lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1ll1l)
l11lllll = SysLogHandler(address=l11ll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11lllll.setFormatter(formatter)
logger.addHandler(l1l11lll)
logger.addHandler(ch)
logger.addHandler(l11lllll)
class Settings():
    l1l11l11 = l11ll1l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1ll11 = l11ll1l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11ll1l1 = l11ll1l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1111l):
        self.l1l1l11l = self._1l1llll(l1l1111l)
        self._1l1lll1()
    def _1l1llll(self, l1l1111l):
        l1l111ll = l1l1111l.split(l11ll1l (u"ࠣࠢࠥࢂ"))
        l1l111ll = l11ll1l (u"ࠤࠣࠦࢃ").join(l1l111ll)
        if platform.system() == l11ll1l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l11l = os.path.join(l11l1lll, l11ll1l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l111ll + l11ll1l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l11l
    def l11lll11(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll111(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11ll1l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11ll1l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l111l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1lll1(self):
        if not os.path.exists(os.path.dirname(self.l1l1l11l)):
            os.makedirs(os.path.dirname(self.l1l1l11l))
        if not os.path.exists(self.l1l1l11l):
            self.config = ConfigObj(self.l1l1l11l)
            self.config[l11ll1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11ll1l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11ll1l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11ll1l1
            self.config[l11ll1l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11ll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11ll1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1ll11
            self.config[l11ll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11ll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l11l11
            self.config[l11ll1l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l11l)
            self.l11ll1l1 = self.get_value(l11ll1l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11ll1l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1ll11 = self.get_value(l11ll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11ll1l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l11l11 = self.get_value(l11ll1l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11ll1l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1l1ll(self):
        l1l11l1l = l11ll1l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l11l11
        l1l11l1l += l11ll1l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1ll11
        l1l11l1l += l11ll1l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11ll1l1
        return l1l11l1l
    def __unicode__(self):
        return self._1l1l1ll()
    def __str__(self):
        return self._1l1l1ll()
    def __del__(self):
        self.config.write()
l11llll1 = Settings(l1l1111l)