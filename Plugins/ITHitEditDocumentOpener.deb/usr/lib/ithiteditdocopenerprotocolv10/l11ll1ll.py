#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11ll = sys.version_info [0] == 2
l1l111 = 2048
l1l1l1 = 7
def l11111l (l1ll11l):
    global l1l1lll
    l11ll11 = ord (l1ll11l [-1])
    l1l1111 = l1ll11l [:-1]
    l111ll = l11ll11 % len (l1l1111)
    l1ll1lll = l1l1111 [:l111ll] + l1l1111 [l111ll:]
    if l1l11ll:
        l1ll111 = l1ll1l1l () .join ([unichr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1ll111 = str () .join ([chr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1ll111)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11llll import l1l1
from configobj import ConfigObj
l1l1llll = l11111l (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1l111 = l11111l (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠼࠽࠳࠶ࠢࡤ")
l1l11lll = l11111l (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11111l (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠻࠼࠲࠵ࠨࡦ")
l11lll11=os.path.join(os.environ.get(l11111l (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11111l (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11lll.replace(l11111l (u"ࠦࠥࠨࡩ"), l11111l (u"ࠧࡥࠢࡪ")).lower())
l1l1lll1=os.environ.get(l11111l (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11111l (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l111ll=l1l1l111.replace(l11111l (u"ࠣࠢࠥ࡭"), l11111l (u"ࠤࡢࠦ࡮"))+l11111l (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11111l (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l11111=os.path.join(os.environ.get(l11111l (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l111ll)
elif platform.system() == l11111l (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l11l11=l1l1(l11lll11+l11111l (u"ࠢ࠰ࠤࡳ"))
    l1l11111 = os.path.join(l1l11l11, l1l111ll)
else:
    l1l11111 = os.path.join( l1l111ll)
l1l1lll1=l1l1lll1.upper()
if l1l1lll1 == l11111l (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l111l1=logging.DEBUG
elif l1l1lll1 == l11111l (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l111l1 = logging.INFO
elif l1l1lll1 == l11111l (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l111l1 = logging.WARNING
elif l1l1lll1 == l11111l (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l111l1 = logging.ERROR
elif l1l1lll1 == l11111l (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l111l1 = logging.CRITICAL
elif l1l1lll1 == l11111l (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l111l1 = logging.NOTSET
logger = logging.getLogger(l11111l (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l111l1)
l11llll1 = logging.FileHandler(l1l11111, mode=l11111l (u"ࠣࡹ࠮ࠦࡻ"))
l11llll1.setLevel(l1l111l1)
formatter = logging.Formatter(l11111l (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11111l (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11llll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l111l1)
l1l1ll11 = SysLogHandler(address=l11111l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l1ll11.setFormatter(formatter)
logger.addHandler(l11llll1)
logger.addHandler(ch)
logger.addHandler(l1l1ll11)
class Settings():
    l11l1lll = l11111l (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l11ll1 = l11111l (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l1l11l = l11111l (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1l111):
        self.l1l1l1ll = self._11ll11l(l1l1l111)
        self._1l1111l()
    def _11ll11l(self, l1l1l111):
        l11ll1l1 = l1l1l111.split(l11111l (u"ࠣࠢࠥࢂ"))
        l11ll1l1 = l11111l (u"ࠤࠣࠦࢃ").join(l11ll1l1)
        if platform.system() == l11111l (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l1ll = os.path.join(l11lll11, l11111l (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11ll1l1 + l11111l (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l1ll
    def l11lll1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lllll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11111l (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11111l (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l1l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1111l(self):
        if not os.path.exists(os.path.dirname(self.l1l1l1ll)):
            os.makedirs(os.path.dirname(self.l1l1l1ll))
        if not os.path.exists(self.l1l1l1ll):
            self.config = ConfigObj(self.l1l1l1ll)
            self.config[l11111l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11111l (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11111l (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l1l11l
            self.config[l11111l (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11111l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l11ll1
            self.config[l11111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11l1lll
            self.config[l11111l (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l1ll)
            self.l1l1l11l = self.get_value(l11111l (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11111l (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l11ll1 = self.get_value(l11111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11111l (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11l1lll = self.get_value(l11111l (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11111l (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11l1l(self):
        l11ll111 = l11111l (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11l1lll
        l11ll111 += l11111l (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l11ll1
        l11ll111 += l11111l (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l1l11l
        return l11ll111
    def __unicode__(self):
        return self._1l11l1l()
    def __str__(self):
        return self._1l11l1l()
    def __del__(self):
        self.config.write()
l1l1ll1l = Settings(l1l1l111)