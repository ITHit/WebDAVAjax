#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll1lll import l11lll1
from configobj import ConfigObj
l1ll111l = l1lll1l (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l11llll1 = l1lll1l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠶࠸࠱࠴ࠧࡢ")
l1l11111 = l1lll1l (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1lll1l (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠵࠷࠰࠳ࠦࡤ")
l1l1llll=os.path.join(os.environ.get(l1lll1l (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1lll1l (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l11111.replace(l1lll1l (u"ࠤࠣࠦࡧ"), l1lll1l (u"ࠥࡣࠧࡨ")).lower())
l1l1ll1l=os.environ.get(l1lll1l (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1lll1l (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l11ll1l1=l11llll1.replace(l1lll1l (u"ࠨࠠࠣ࡫"), l1lll1l (u"ࠢࡠࠤ࡬"))+l1lll1l (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1lll1l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l11ll1=os.path.join(os.environ.get(l1lll1l (u"ࠪࡘࡊࡓࡐࠨ࡯")),l11ll1l1)
elif platform.system() == l1lll1l (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11lll11=l11lll1(l1l1llll+l1lll1l (u"ࠧ࠵ࠢࡱ"))
    l1l11ll1 = os.path.join(l11lll11, l11ll1l1)
else:
    l1l11ll1 = os.path.join( l11ll1l1)
l1l1ll1l=l1l1ll1l.upper()
if l1l1ll1l == l1lll1l (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11ll11l=logging.DEBUG
elif l1l1ll1l == l1lll1l (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11ll11l = logging.INFO
elif l1l1ll1l == l1lll1l (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11ll11l = logging.WARNING
elif l1l1ll1l == l1lll1l (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11ll11l = logging.ERROR
elif l1l1ll1l == l1lll1l (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11ll11l = logging.CRITICAL
elif l1l1ll1l == l1lll1l (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11ll11l = logging.NOTSET
logger = logging.getLogger(l1lll1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11ll11l)
l1l11lll = logging.FileHandler(l1l11ll1, mode=l1lll1l (u"ࠨࡷࠬࠤࡹ"))
l1l11lll.setLevel(l11ll11l)
formatter = logging.Formatter(l1lll1l (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1lll1l (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l11lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll11l)
l1l1ll11 = SysLogHandler(address=l1lll1l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l1ll11.setFormatter(formatter)
logger.addHandler(l1l11lll)
logger.addHandler(ch)
logger.addHandler(l1l1ll11)
class Settings():
    l1l1lll1 = l1lll1l (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l11l1l = l1lll1l (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l1l111 = l1lll1l (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l11llll1):
        self.l1l1l11l = self._1l1l1l1(l11llll1)
        self._1ll1111()
    def _1l1l1l1(self, l11llll1):
        l1l111ll = l11llll1.split(l1lll1l (u"ࠨࠠࠣࢀ"))
        l1l111ll = l1lll1l (u"ࠢࠡࠤࢁ").join(l1l111ll)
        if platform.system() == l1lll1l (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l1l11l = os.path.join(l1l1llll, l1lll1l (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l111ll + l1lll1l (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l1l11l
    def l1l1111l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11l11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll1l (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll1l (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l1ll(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1ll1111(self):
        if not os.path.exists(os.path.dirname(self.l1l1l11l)):
            os.makedirs(os.path.dirname(self.l1l1l11l))
        if not os.path.exists(self.l1l1l11l):
            self.config = ConfigObj(self.l1l1l11l)
            self.config[l1lll1l (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1lll1l (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1lll1l (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l1l111
            self.config[l1lll1l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1lll1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1lll1l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l11l1l
            self.config[l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1lll1
            self.config[l1lll1l (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l11l)
            self.l1l1l111 = self.get_value(l1lll1l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1lll1l (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l11l1l = self.get_value(l1lll1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1lll1l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1lll1 = self.get_value(l1lll1l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll1l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11lllll(self):
        l11lll1l = l1lll1l (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1lll1
        l11lll1l += l1lll1l (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l11l1l
        l11lll1l += l1lll1l (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l1l111
        return l11lll1l
    def __unicode__(self):
        return self._11lllll()
    def __str__(self):
        return self._11lllll()
    def __del__(self):
        self.config.write()
l1l111l1 = Settings(l11llll1)