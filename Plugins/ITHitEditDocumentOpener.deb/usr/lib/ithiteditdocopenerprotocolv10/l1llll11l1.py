#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1lll111 = 2048
l1111 = 7
def l1ll (l11lll):
    global l1l1l1
    l1ll1l1 = ord (l11lll [-1])
    l1l1lll = l11lll [:-1]
    l1ll11l1 = l1ll1l1 % len (l1l1lll)
    l111 = l1l1lll [:l1ll11l1] + l1l1lll [l1ll11l1:]
    if l111ll1:
        l11llll = l1ll1l11 () .join ([unichr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    else:
        l11llll = str () .join ([chr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    return eval (l11llll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllllll1=logging.WARNING
logger = logging.getLogger(l1ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lllllll1)
l11lllll = SysLogHandler(address=l1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11lllll.setFormatter(formatter)
logger.addHandler(l11lllll)
ch = logging.StreamHandler()
ch.setLevel(l1lllllll1)
logger.addHandler(ch)
class l1lll11ll1(io.FileIO):
    l1ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1l1l, l1llll11ll,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1l1l = l1llll1l1l
            self.l1llll11ll = l1llll11ll
            if not options:
                options = l1ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1l1l,
                                              self.l1llll11ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11lll = os.path.join(os.path.sep, l1ll (u"ࠪࡩࡹࡩࠧই"), l1ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lllll111 = path
        else:
            self._1lllll111 = self.l1lll11lll
        super(l1lll11ll1, self).__init__(self._1lllll111, l1ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11l1l(self, line):
        return l1lll11ll1.Entry(*[x for x in line.strip(l1ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll (u"ࠤࠦࠦ঍")):
                    yield self._1lll11l1l(line)
            except ValueError:
                pass
    def l1lll1l11l(self, attr, value):
        for entry in self.entries:
            l1lll1l111 = getattr(entry, attr)
            if l1lll1l111 == value:
                return entry
        return None
    def l1lll11l11(self, entry):
        if self.l1lll1l11l(l1ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll (u"ࠫࡡࡴࠧএ")).encode(l1ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llllll11(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll (u"ࠢࠤࠤ঒")):
                if self._1lll11l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll (u"ࠨࠩও").join(lines).encode(l1ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllll1l1(cls, l1llll1l1l, path=None):
        l1lll1111l = cls(path=path)
        entry = l1lll1111l.l1lll1l11l(l1ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1l1l)
        if entry:
            return l1lll1111l.l1llllll11(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1l1l, l1llll11ll, options=None, path=None):
        return cls(path=path).l1lll11l11(l1lll11ll1.Entry(device,
                                                    l1llll1l1l, l1llll11ll,
                                                    options=options))
class l1lllll11l(object):
    def __init__(self, l1lllll1ll):
        self.l1lll111ll=l1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll111l1=l1ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll1ll=l1lllll1ll
        self.l1lll1ll1l()
        self.l1llll1111()
        self.l1lll1l1l1()
        self.l1llllll1l()
        self.l1lll1ll11()
    def l1lll1ll1l(self):
        temp_file=open(l1lll11111,l1ll (u"࠭ࡲࠨঘ"))
        l111lll=temp_file.read()
        data=json.loads(l111lll)
        self.user=data[l1ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l111l11=data[l1ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1=data[l1ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l111l=data[l1ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll111l=data[l1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l1ll=data[l1ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l1l1(self):
        l111l1=os.path.join(l1ll (u"ࠨ࠯ࠣট"),l1ll (u"ࠢࡶࡵࡵࠦঠ"),l1ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111l1)
    def l1lll1ll11(self):
        logger.info(l1ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1=os.path.join(self.l1l111l,self.l1lll111ll)
        l1llll1ll1 = pwd.getpwnam(self.user).pw_uid
        l1lll1lll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1):
            os.makedirs(l1)
            os.system(l1ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1))
            logger.debug(l1ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1)
        else:
            logger.debug(l1ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1)
        l111l1=os.path.join(l1, self.l1lll111l1)
        print(l111l1)
        logger.debug(l1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111l1)
        with open(l111l1, l1ll (u"ࠤࡺ࠯ࠧ঩")) as l1llll1lll:
            logger.debug(self.l111l11 + l1ll (u"ࠪࠤࠬপ")+self.l1llll111l+l1ll (u"ࠫࠥࠨࠧফ")+self.l1lll1l1ll+l1ll (u"ࠬࠨࠧব"))
            l1llll1lll.writelines(self.l111l11 + l1ll (u"࠭ࠠࠨভ")+self.l1llll111l+l1ll (u"ࠧࠡࠤࠪম")+self.l1lll1l1ll+l1ll (u"ࠨࠤࠪয"))
        os.chmod(l111l1, 0o600)
        os.chown(l111l1, l1llll1ll1, l1lll1lll1)
    def l1llll1111(self, l1lll1llll=l1ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1llll in groups:
            logger.info(l1ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1llll))
        else:
            logger.warning(l1ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1llll))
            l1ll1ll=l1ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1llll,self.user)
            logger.debug(l1ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll1ll)
            os.system(l1ll1ll)
            logger.debug(l1ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llllll1l(self):
        logger.debug(l1ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1111l=l1lll11ll1()
        l1lll1111l.add(self.l111l11, self.l1, l1llll11ll=l1ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll11111 = urllib.parse.unquote(sys.argv[1])
        if l1lll11111:
            l1llll1l11=l1lllll11l(l1lll11111)
        else:
            raise (l1ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise