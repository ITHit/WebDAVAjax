#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l1ll = 2048
l1l1 = 7
def l1lll1l (l1l111):
    global l1l111l
    l1lll1ll = ord (l1l111 [-1])
    l1lllll = l1l111 [:-1]
    l11111 = l1lll1ll % len (l1lllll)
    l1ll1l11 = l1lllll [:l11111] + l1lllll [l11111:]
    if l1ll1ll:
        l1ll11 = l1l1l () .join ([unichr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll - (l11l111 + l1lll1ll) % l1l1) for l11l111, char in enumerate (l1ll1l11)])
    return eval (l1ll11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1l1l1=logging.WARNING
logger = logging.getLogger(l1lll1l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1l1l1)
l1l11111 = SysLogHandler(address=l1lll1l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll1l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11111.setFormatter(formatter)
logger.addHandler(l1l11111)
ch = logging.StreamHandler()
ch.setLevel(l1lll1l1l1)
logger.addHandler(ch)
class l1lll11lll(io.FileIO):
    l1lll1l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll1l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1l1ll, l1lll11l11,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1l1ll = l1lll1l1ll
            self.l1lll11l11 = l1lll11l11
            if not options:
                options = l1lll1l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1l1ll,
                                              self.l1lll11l11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l11l = os.path.join(os.path.sep, l1lll1l (u"ࠪࡩࡹࡩࠧই"), l1lll1l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llllll1l = path
        else:
            self._1llllll1l = self.l1lll1l11l
        super(l1lll11lll, self).__init__(self._1llllll1l, l1lll1l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11ll1(self, line):
        return l1lll11lll.Entry(*[x for x in line.strip(l1lll1l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll1l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1l (u"ࠤࠦࠦ঍")):
                    yield self._1lll11ll1(line)
            except ValueError:
                pass
    def l1lll1llll(self, attr, value):
        for entry in self.entries:
            l1lllll1l1 = getattr(entry, attr)
            if l1lllll1l1 == value:
                return entry
        return None
    def l1lll1ll1l(self, entry):
        if self.l1lll1llll(l1lll1l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll1l (u"ࠫࡡࡴࠧএ")).encode(l1lll1l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llllll11(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1l (u"ࠢࠤࠤ঒")):
                if self._1lll11ll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1l (u"ࠨࠩও").join(lines).encode(l1lll1l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll111l1(cls, l1lll1l1ll, path=None):
        l1lllll11l = cls(path=path)
        entry = l1lllll11l.l1lll1llll(l1lll1l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1l1ll)
        if entry:
            return l1lllll11l.l1llllll11(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1l1ll, l1lll11l11, options=None, path=None):
        return cls(path=path).l1lll1ll1l(l1lll11lll.Entry(device,
                                                    l1lll1l1ll, l1lll11l11,
                                                    options=options))
class l1lllll1ll(object):
    def __init__(self, l1lllllll1):
        self.l1llll1l11=l1lll1l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1l111=l1lll1l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllllll1=l1lllllll1
        self.l1lll11111()
        self.l1lll11l1l()
        self.l1llll1ll1()
        self.l1llll1l1l()
        self.l1llll1111()
    def l1lll11111(self):
        temp_file=open(l1lll111ll,l1lll1l (u"࠭ࡲࠨঘ"))
        l11l11l=temp_file.read()
        data=json.loads(l11l11l)
        self.user=data[l1lll1l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l11=data[l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1111l=data[l1lll1l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l111ll1=data[l1lll1l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1lll1=data[l1lll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll11ll=data[l1lll1l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1llll1ll1(self):
        l1111l1=os.path.join(l1lll1l (u"ࠨ࠯ࠣট"),l1lll1l (u"ࠢࡶࡵࡵࠦঠ"),l1lll1l (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll1l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll1l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1111l1)
    def l1llll1111(self):
        logger.info(l1lll1l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1111l=os.path.join(self.l111ll1,self.l1llll1l11)
        l1llll1lll = pwd.getpwnam(self.user).pw_uid
        l1llll111l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1111l):
            os.makedirs(l1111l)
            os.system(l1lll1l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1111l))
            logger.debug(l1lll1l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1111l)
        else:
            logger.debug(l1lll1l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1111l)
        l1111l1=os.path.join(l1111l, self.l1lll1l111)
        print(l1111l1)
        logger.debug(l1lll1l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1111l1)
        with open(l1111l1, l1lll1l (u"ࠤࡺ࠯ࠧ঩")) as l1lll1ll11:
            logger.debug(self.l11l11 + l1lll1l (u"ࠪࠤࠬপ")+self.l1lll1lll1+l1lll1l (u"ࠫࠥࠨࠧফ")+self.l1llll11ll+l1lll1l (u"ࠬࠨࠧব"))
            l1lll1ll11.writelines(self.l11l11 + l1lll1l (u"࠭ࠠࠨভ")+self.l1lll1lll1+l1lll1l (u"ࠧࠡࠤࠪম")+self.l1llll11ll+l1lll1l (u"ࠨࠤࠪয"))
        os.chmod(l1111l1, 0o600)
        os.chown(l1111l1, l1llll1lll, l1llll111l)
    def l1lll11l1l(self, l1lll1111l=l1lll1l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll1l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1111l in groups:
            logger.info(l1lll1l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1111l))
        else:
            logger.warning(l1lll1l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1111l))
            l1l=l1lll1l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1111l,self.user)
            logger.debug(l1lll1l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l)
            os.system(l1l)
            logger.debug(l1lll1l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll1l1l(self):
        logger.debug(l1lll1l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lllll11l=l1lll11lll()
        l1lllll11l.add(self.l11l11, self.l1111l, l1lll11l11=l1lll1l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll1l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll1l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll111ll = urllib.parse.unquote(sys.argv[1])
        if l1lll111ll:
            l1lllll111=l1lllll1ll(l1lll111ll)
        else:
            raise (l1lll1l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll1l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise