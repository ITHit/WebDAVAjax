#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llllll = sys.version_info [0] == 2
l11ll1 = 2048
l1111ll = 7
def l1ll1l1 (l11ll11):
    global l1lll11
    l1lll111 = ord (l11ll11 [-1])
    l1ll11l1 = l11ll11 [:-1]
    l11l111 = l1lll111 % len (l1ll11l1)
    l1llll1 = l1ll11l1 [:l11l111] + l1ll11l1 [l11l111:]
    if l1llllll:
        l1lll1l = l1l1l1 () .join ([unichr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    else:
        l1lll1l = str () .join ([chr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    return eval (l1lll1l)
import hashlib
import os
import l1llll11
from l1lll1ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1llll11 import l1111
from l1l import l11l1ll, l1lll1l1
import logging
logger = logging.getLogger(l1ll1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l():
    def __init__(self, l11l1,l1ll1l1l, ll= None, l11lll=None):
        self.l111ll1=False
        self.l1lll11l = self._111lll()
        self.l1ll1l1l = l1ll1l1l
        self.ll = ll
        self.l11111 = l11l1
        if ll:
            self.l1l11 = True
        else:
            self.l1l11 = False
        self.l11lll = l11lll
    def _111lll(self):
        try:
            return l1llll11.l1l1ll() is not None
        except:
            return False
    def open(self):
        l1ll1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lll11l:
            raise NotImplementedError(l1ll1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11l1l = self.l11111
        if self.l1ll1l1l.lower().startswith(self.l11111.lower()):
            l1llll1l = re.compile(re.escape(self.l11111), re.IGNORECASE)
            l1ll1l1l = l1llll1l.sub(l1ll1l1 (u"ࠨࠩࠄ"), self.l1ll1l1l)
            l1ll1l1l = l1ll1l1l.replace(l1ll1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll1l(self.l11111, l11l1l, l1ll1l1l, self.ll)
    def l11ll1l(self,l11111, l11l1l, l1ll1l1l, ll):
        l1ll1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1l = l1111l1(l11111)
        l1lll1 = self.l1lll(l1ll1l)
        logger.info(l1ll1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1l)
        if l1lll1:
            logger.info(l1ll1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111(l1ll1l)
            l1ll1l = l111l11(l11111, l11l1l, ll, self.l11lll)
        logger.debug(l1ll1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll11l=l1ll1l + l1ll1l1 (u"ࠤ࠲ࠦࠌ") + l1ll1l1l
        l111111 = l1ll1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll11l+ l1ll1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111111)
        l11ll = os.system(l111111)
        if (l11ll != 0):
            raise IOError(l1ll1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll11l, l11ll))
    def l1lll(self, l1ll1l):
        if os.path.exists(l1ll1l):
            if os.path.islink(l1ll1l):
                l1ll1l = os.readlink(l1ll1l)
            if os.path.ismount(l1ll1l):
                return True
        return False
def l1111l1(l11111):
    l1 = l11111.replace(l1ll1l1 (u"࠭࡜࡝ࠩࠐ"), l1ll1l1 (u"ࠧࡠࠩࠑ")).replace(l1ll1l1 (u"ࠨ࠱ࠪࠒ"), l1ll1l1 (u"ࠩࡢࠫࠓ"))
    l1lllll = l1ll1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11=os.environ[l1ll1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1=os.path.join(l11,l1lllll, l1)
    l111l=os.path.abspath(l1ll1)
    return l111l
def l1l1l11(l1llll):
    if not os.path.exists(l1llll):
        os.makedirs(l1llll)
def l111l1l(l11111, l11l1l, l1ll1l11=None, password=None):
    l1ll1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1llll = l1111l1(l11111)
    l1l1l11(l1llll)
    if not l1ll1l11:
        l1ll1lll = l11l11()
        l1l1l =l1ll1lll.l11l11l(l1ll1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11l1l + l1ll1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11l1l + l1ll1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l1l, str):
            l1ll1l11, password = l1l1l
        else:
            raise l1lll1l1()
        logger.info(l1ll1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1llll))
    l1ll = pwd.getpwuid( os.getuid())[0]
    l111=os.environ[l1ll1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l111l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11lll1={l1ll1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll, l1ll1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11111, l1ll1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1llll, l1ll1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l111, l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll1l11, l1ll1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11lll1, temp_file)
        if not os.path.exists(os.path.join(l1l111l, l1ll1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l11ll=l1ll1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1l1 (u"ࠧࠨࠤ")
        else:
            l1l11ll=l1ll1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll11ll=l1ll1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l11ll,temp_file.name)
        l1l1111=[l1ll1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l111l, l1ll11ll)]
        p = subprocess.Popen(l1l1111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1llll
    logger.debug(l1ll1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111l=os.path.abspath(l1llll)
    logger.debug(l1ll1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111l)
    return l111l
def l111l11(l11111, l11l1l, ll, l11lll):
    l1ll1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1ll(title):
        l1ll1ll1=30
        if len(title)>l1ll1ll1:
            l1l1l1l=title.split(l1ll1l1 (u"ࠨ࠯ࠣ࠳"))
            l1lllll1=l1ll1l1 (u"ࠧࠨ࠴")
            for block in l1l1l1l:
                l1lllll1+=block+l1ll1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l1lllll1) > l1ll1ll1:
                    l1lllll1+=l1ll1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lllll1
        return title
    l1ll1l11 = l1ll1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1ll1l1 (u"ࠦࠧ࠸")
    os.system(l1ll1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l111l1 = l1111l1(l11111)
    l1llll = l1111l1(hashlib.sha1(l11111.encode()).hexdigest()[:10])
    l1l1l11(l1llll)
    logger.info(l1ll1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1llll))
    if ll:
        l1l11l1 = [l1ll1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1ll1l1 (u"ࠤ࠰ࡸࠧ࠽"), l1ll1l1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1ll1l1 (u"ࠫ࠲ࡵࠧ࠿"), l1ll1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1ll1l11, ll),
                    urllib.parse.unquote(l11l1l), os.path.abspath(l1llll)]
    else:
        l1ll1l11, password = l11llll(l1llll, l11l1l, l11lll)
        if l1ll1l11.lower() != l1ll1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1l11l1 = [l1ll1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1ll1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1ll1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1ll1l11,
                        urllib.parse.unquote(l11l1l), os.path.abspath(l1llll)]
        else:
            raise l1lll1l1()
    logger.info(l1ll1l1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1ll1l1 (u"ࠢࠡࠤࡉ").join(l1l11l1)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11111l = l1ll1l1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11111l.encode())
    if len(err) > 0:
        l1ll11 = l1ll1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1ll11)
        raise l11l1ll(l1ll11, l111l11=l1llll11.l1l1ll(), l11l1l=l11l1l)
    logger.info(l1ll1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1ll1l1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1llll, l111l1))
    l111l=os.path.abspath(l111l1)
    return l111l
def l11llll(l11111, l11l1l, l11lll):
    l1ll111 = os.path.join(os.environ[l1ll1l1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1ll1l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1ll1l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1ll111)):
       os.makedirs(os.path.dirname(l1ll111))
    l111ll = l11lll.get_value(l1ll1l1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1ll1l1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1ll1lll = l11l11(l11111, l111ll)
    l1ll1l11, password = l1ll1lll.l11l11l(l1ll1l1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11l1l + l1ll1l1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11l1l + l1ll1l1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1ll1l11 != l1ll1l1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l11l1l1(l11111, l1ll1l11):
        l1l1lll = l1ll1l1 (u"ࠢࠡࠤࡗ").join([l11111, l1ll1l11, l1ll1l1 (u"ࠨࠤࠪࡘ") + password + l1ll1l1 (u"࡙ࠩࠥࠫ"), l1ll1l1 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1ll111, l1ll1l1 (u"ࠫࡼ࠱࡛ࠧ")) as l1l11l:
            l1l11l.write(l1l1lll)
        os.chmod(l1ll111, 0o600)
    return l1ll1l11, password
def l11l1l1(l11111, l1ll1l11):
    l1ll111 = l1111l = os.path.join(os.environ[l1ll1l1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1ll1l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1ll1l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1ll111):
        with open(l1ll111, l1ll1l1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1l1ll1 = data[0].split(l1ll1l1 (u"ࠤࠣࠦࡠ"))
            if l11111 == l1l1ll1[0] and l1ll1l11 == l1l1ll1[1]:
                return True
    return False