#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l1 = sys.version_info [0] == 2
l11 = 2048
l1ll11ll = 7
def l1lll1ll (l1lll111):
    global l1l1ll1
    l1l11 = ord (l1lll111 [-1])
    l1llll11 = l1lll111 [:-1]
    l1l1 = l1l11 % len (l1llll11)
    l1l1111 = l1llll11 [:l1l1] + l1llll11 [l1l1:]
    if l1ll11l1:
        l1111ll = l111l1 () .join ([unichr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    return eval (l1111ll)
import hashlib
import os
import l1l1lll
from l111111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1lll import l1ll1l1
from l1lll import l11ll1l, l111lll
import logging
logger = logging.getLogger(l1lll1ll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll1():
    def __init__(self, l111l11,l11lll1, l1ll1l= None, l11ll=None):
        self.l1111l1=False
        self.l1ll111 = self._1ll11()
        self.l11lll1 = l11lll1
        self.l1ll1l = l1ll1l
        self.l1lll1l1 = l111l11
        if l1ll1l:
            self.l1l11ll = True
        else:
            self.l1l11ll = False
        self.l11ll = l11ll
    def _1ll11(self):
        try:
            return l1l1lll.l111l() is not None
        except:
            return False
    def open(self):
        l1lll1ll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll111:
            raise NotImplementedError(l1lll1ll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1ll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll11 = self.l1lll1l1
        if self.l11lll1.lower().startswith(self.l1lll1l1.lower()):
            l1ll11l = re.compile(re.escape(self.l1lll1l1), re.IGNORECASE)
            l11lll1 = l1ll11l.sub(l1lll1ll (u"ࠨࠩࠄ"), self.l11lll1)
            l11lll1 = l11lll1.replace(l1lll1ll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1ll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1l11(self.l1lll1l1, l11ll11, l11lll1, self.l1ll1l)
    def l1ll1l11(self,l1lll1l1, l11ll11, l11lll1, l1ll1l):
        l1lll1ll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1ll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1llll1l = l1ll1ll1(l1lll1l1)
        l1 = self.l11llll(l1llll1l)
        logger.info(l1lll1ll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1llll1l)
        if l1:
            logger.info(l1lll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1l1(l1llll1l)
            l1llll1l = l1l1l1l(l1lll1l1, l11ll11, l1ll1l, self.l11ll)
        logger.debug(l1lll1ll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111=l1llll1l + l1lll1ll (u"ࠤ࠲ࠦࠌ") + l11lll1
        l1l1l1 = l1lll1ll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111+ l1lll1ll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1l1)
        l1l = os.system(l1l1l1)
        if (l1l != 0):
            raise IOError(l1lll1ll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111, l1l))
    def l11llll(self, l1llll1l):
        if os.path.exists(l1llll1l):
            if os.path.islink(l1llll1l):
                l1llll1l = os.readlink(l1llll1l)
            if os.path.ismount(l1llll1l):
                return True
        return False
def l1ll1ll1(l1lll1l1):
    l11111 = l1lll1l1.replace(l1lll1ll (u"࠭࡜࡝ࠩࠐ"), l1lll1ll (u"ࠧࡠࠩࠑ")).replace(l1lll1ll (u"ࠨ࠱ࠪࠒ"), l1lll1ll (u"ࠩࡢࠫࠓ"))
    l1ll1l1l = l1lll1ll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1llll=os.environ[l1lll1ll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llllll=os.path.join(l1llll,l1ll1l1l, l11111)
    l1lll11l=os.path.abspath(l1llllll)
    return l1lll11l
def l111l1l(l1ll1lll):
    if not os.path.exists(l1ll1lll):
        os.makedirs(l1ll1lll)
def l11l1l1(l1lll1l1, l11ll11, l11l1ll=None, password=None):
    l1lll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll1lll = l1ll1ll1(l1lll1l1)
    l111l1l(l1ll1lll)
    if not l11l1ll:
        l1l1l = l1ll()
        l11l111 =l1l1l.l11ll1(l1lll1ll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll11 + l1lll1ll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll11 + l1lll1ll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l111, str):
            l11l1ll, password = l11l111
        else:
            raise l111lll()
        logger.info(l1lll1ll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll1lll))
    l1111 = pwd.getpwuid( os.getuid())[0]
    l1lll1=os.environ[l1lll1ll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l11=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l={l1lll1ll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1111, l1lll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1lll1l1, l1lll1ll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll1lll, l1lll1ll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll1, l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11l1ll, l1lll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l, temp_file)
        if not os.path.exists(os.path.join(l11l11, l1lll1ll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11lll=l1lll1ll (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1ll (u"ࠧࠨࠤ")
        else:
            l11lll=l1lll1ll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1ll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1ll=l1lll1ll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11lll,temp_file.name)
        l11l11l=[l1lll1ll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1ll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l11, l1ll1ll)]
        p = subprocess.Popen(l11l11l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1ll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1ll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1ll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll1lll
    logger.debug(l1lll1ll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1ll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll11l=os.path.abspath(l1ll1lll)
    logger.debug(l1lll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll11l)
    return l1lll11l
def l1l1l1l(l1lll1l1, l11ll11, l1ll1l, l11ll):
    l1lll1ll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l111ll(title):
        l1llll1=30
        if len(title)>l1llll1:
            l1l1l11=title.split(l1lll1ll (u"ࠨ࠯ࠣ࠳"))
            l1111l=l1lll1ll (u"ࠧࠨ࠴")
            for block in l1l1l11:
                l1111l+=block+l1lll1ll (u"ࠣ࠱ࠥ࠵")
                if len(l1111l) > l1llll1:
                    l1111l+=l1lll1ll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1111l
        return title
    l11l1ll = l1lll1ll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1lll1ll (u"ࠦࠧ࠸")
    os.system(l1lll1ll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l11l1l = l1ll1ll1(l1lll1l1)
    l1ll1lll = l1ll1ll1(hashlib.sha1(l1lll1l1.encode()).hexdigest()[:10])
    l111l1l(l1ll1lll)
    logger.info(l1lll1ll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1ll1lll))
    if l1ll1l:
        l1l11l = [l1lll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1lll1ll (u"ࠤ࠰ࡸࠧ࠽"), l1lll1ll (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1lll1ll (u"ࠫ࠲ࡵࠧ࠿"), l1lll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l11l1ll, l1ll1l),
                    urllib.parse.unquote(l11ll11), os.path.abspath(l1ll1lll)]
    else:
        l11l1ll, password = ll(l1ll1lll, l11ll11, l11ll)
        if l11l1ll.lower() != l1lll1ll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1l11l = [l1lll1ll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1ll (u"ࠤ࠰ࡸࠧࡄ"), l1lll1ll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1ll (u"ࠫ࠲ࡵࠧࡆ"), l1lll1ll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l11l1ll,
                        urllib.parse.unquote(l11ll11), os.path.abspath(l1ll1lll)]
        else:
            raise l111lll()
    logger.info(l1lll1ll (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1lll1ll (u"ࠢࠡࠤࡉ").join(l1l11l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11l1 = l1lll1ll (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11l1.encode())
    if len(err) > 0:
        l1l111l = l1lll1ll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1l111l)
        raise l11ll1l(l1l111l, l1l1l1l=l1l1lll.l111l(), l11ll11=l11ll11)
    logger.info(l1lll1ll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1lll1ll (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1ll1lll, l11l1l))
    l1lll11l=os.path.abspath(l11l1l)
    return l1lll11l
def ll(l1lll1l1, l11ll11, l11ll):
    l1lllll = os.path.join(os.environ[l1lll1ll (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1lll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1lll1ll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1lllll)):
       os.makedirs(os.path.dirname(l1lllll))
    l1lllll1 = l11ll.get_value(l1lll1ll (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1lll1ll (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l1l = l1ll(l1lll1l1, l1lllll1)
    l11l1ll, password = l1l1l.l11ll1(l1lll1ll (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11ll11 + l1lll1ll (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11ll11 + l1lll1ll (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l11l1ll != l1lll1ll (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1l1ll(l1lll1l1, l11l1ll):
        l1lll11 = l1lll1ll (u"ࠢࠡࠤࡗ").join([l1lll1l1, l11l1ll, l1lll1ll (u"ࠨࠤࠪࡘ") + password + l1lll1ll (u"࡙ࠩࠥࠫ"), l1lll1ll (u"ࠪࡠࡳ࡚࠭")])
        with open(l1lllll, l1lll1ll (u"ࠫࡼ࠱࡛ࠧ")) as l111ll1:
            l111ll1.write(l1lll11)
        os.chmod(l1lllll, 0o600)
    return l11l1ll, password
def l1l1ll(l1lll1l1, l11l1ll):
    l1lllll = l11111l = os.path.join(os.environ[l1lll1ll (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1lll1ll (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1lll1ll (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1lllll):
        with open(l1lllll, l1lll1ll (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1lll1l = data[0].split(l1lll1ll (u"ࠤࠣࠦࡠ"))
            if l1lll1l1 == l1lll1l[0] and l11l1ll == l1lll1l[1]:
                return True
    return False