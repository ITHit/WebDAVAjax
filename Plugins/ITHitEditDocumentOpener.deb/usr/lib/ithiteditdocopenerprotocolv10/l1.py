#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11ll = sys.version_info [0] == 2
l1l111 = 2048
l1l1l1 = 7
def l11111l (l1ll11l):
    global l1l1lll
    l11ll11 = ord (l1ll11l [-1])
    l1l1111 = l1ll11l [:-1]
    l111ll = l11ll11 % len (l1l1111)
    l1ll1lll = l1l1111 [:l111ll] + l1l1111 [l111ll:]
    if l1l11ll:
        l1ll111 = l1ll1l1l () .join ([unichr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1ll111 = str () .join ([chr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1ll111)
import hashlib
import os
import l11llll
from l1llll1l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11llll import l1l1
from l1llllll import l1lll1, l11l11
import logging
logger = logging.getLogger(l11111l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1ll11():
    def __init__(self, l1ll1111,l111l11, l11l1l1= None, l111lll=None):
        self.l1111l1=False
        self.l11l11l = self._1lll1ll()
        self.l111l11 = l111l11
        self.l11l1l1 = l11l1l1
        self.l111ll1 = l1ll1111
        if l11l1l1:
            self.l1lll11 = True
        else:
            self.l1lll11 = False
        self.l111lll = l111lll
    def _1lll1ll(self):
        try:
            return l11llll.l11l1l() is not None
        except:
            return False
    def open(self):
        l11111l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l11l:
            raise NotImplementedError(l11111l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11111l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1lllll1 = self.l111ll1
        if self.l111l11.lower().startswith(self.l111ll1.lower()):
            l11 = re.compile(re.escape(self.l111ll1), re.IGNORECASE)
            l111l11 = l11.sub(l11111l (u"ࠨࠩࠄ"), self.l111l11)
            l111l11 = l111l11.replace(l11111l (u"ࠩࡧࡥࡻ࠭ࠅ"), l11111l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1llll(self.l111ll1, l1lllll1, l111l11, self.l11l1l1)
    def l1llll(self,l111ll1, l1lllll1, l111l11, l11l1l1):
        l11111l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11111l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1ll = l111l(l111ll1)
        l11l1ll = self.l111l1(l1ll1ll)
        logger.info(l11111l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1ll)
        if l11l1ll:
            logger.info(l11111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l1(l1ll1ll)
            l1ll1ll = l1l111l(l111ll1, l1lllll1, l11l1l1, self.l111lll)
        logger.debug(l11111l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l=l1ll1ll + l11111l (u"ࠤ࠲ࠦࠌ") + l111l11
        l1l11l = l11111l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l+ l11111l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l11l)
        l1ll111l = os.system(l1l11l)
        if (l1ll111l != 0):
            raise IOError(l11111l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l, l1ll111l))
    def l111l1(self, l1ll1ll):
        if os.path.exists(l1ll1ll):
            if os.path.islink(l1ll1ll):
                l1ll1ll = os.readlink(l1ll1ll)
            if os.path.ismount(l1ll1ll):
                return True
        return False
def l111l(l111ll1):
    l1l11l1 = l111ll1.replace(l11111l (u"࠭࡜࡝ࠩࠐ"), l11111l (u"ࠧࡠࠩࠑ")).replace(l11111l (u"ࠨ࠱ࠪࠒ"), l11111l (u"ࠩࡢࠫࠓ"))
    l1ll11l1 = l11111l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111=os.environ[l11111l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll=os.path.join(l111,l1ll11l1, l1l11l1)
    l1ll1l=os.path.abspath(l11ll)
    return l1ll1l
def l111111(l11lll):
    if not os.path.exists(l11lll):
        os.makedirs(l11lll)
def l1ll1l11(l111ll1, l1lllll1, l1lllll=None, password=None):
    l11111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11lll = l111l(l111ll1)
    l111111(l11lll)
    if not l1lllll:
        l1111l = l1lll11l()
        l11l1 =l1111l.l111l1l(l11111l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1lllll1 + l11111l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1lllll1 + l11111l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l1, str):
            l1lllll, password = l11l1
        else:
            raise l11l11()
        logger.info(l11111l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11lll))
    l1lll = pwd.getpwuid( os.getuid())[0]
    l1l=os.environ[l11111l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11lll1={l11111l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lll, l11111l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111ll1, l11111l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11lll, l11111l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l, l11111l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lllll, l11111l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11lll1, temp_file)
        if not os.path.exists(os.path.join(l1ll1, l11111l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11ll1l=l11111l (u"ࠦࡵࡿࠢࠣ")
            key=l11111l (u"ࠧࠨࠤ")
        else:
            l11ll1l=l11111l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11111l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll1l=l11111l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11ll1l,temp_file.name)
        l1llll1=[l11111l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11111l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1, l1lll1l)]
        p = subprocess.Popen(l1llll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11111l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11111l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11111l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11lll
    logger.debug(l11111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11111l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll1l=os.path.abspath(l11lll)
    logger.debug(l11111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll1l)
    return l1ll1l
def l1l111l(l111ll1, l1lllll1, l11l1l1, l111lll):
    l11111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def ll(title):
        l1lll1l1=30
        if len(title)>l1lll1l1:
            l1l1ll=title.split(l11111l (u"ࠨ࠯ࠣ࠳"))
            l11111=l11111l (u"ࠧࠨ࠴")
            for block in l1l1ll:
                l11111+=block+l11111l (u"ࠣ࠱ࠥ࠵")
                if len(l11111) > l1lll1l1:
                    l11111+=l11111l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11111
        return title
    def l11l111(l1lll111, password):
        l11111l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11111l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11111l (u"ࠧࠦࠢ࠹").join(l1lll111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l1ll1 = l11111l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l1ll1.encode())
        l1l11 = [l11111l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll11ll = l11111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll11ll)
            for e in l1l11:
                if e in l1ll11ll: return False
            raise l1lll1(l1ll11ll, l1l111l=l11llll.l11l1l(), l1lllll1=l1lllll1)
        logger.info(l11111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lllll = l11111l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11111l (u"ࠦࠧ࠿")
    os.system(l11111l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l1l1l = l111l(l111ll1)
    l11lll = l111l(hashlib.sha1(l111ll1.encode()).hexdigest()[:10])
    l111111(l11lll)
    logger.info(l11111l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11lll))
    if l11l1l1:
        l1lll111 = [l11111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11111l (u"ࠤ࠰ࡸࠧࡄ"), l11111l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11111l (u"ࠫ࠲ࡵࠧࡆ"), l11111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lllll, l11l1l1),
                    urllib.parse.unquote(l1lllll1), os.path.abspath(l11lll)]
        l11l111(l1lll111, password)
    else:
        while True:
            l1lllll, password = l11ll1(l11lll, l1lllll1, l111lll)
            if l1lllll.lower() != l11111l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1lll111 = [l11111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11111l (u"ࠤ࠰ࡸࠧࡋ"), l11111l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11111l (u"ࠫ࠲ࡵࠧࡍ"), l11111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lllll,
                            urllib.parse.unquote(l1lllll1), os.path.abspath(l11lll)]
            else:
                raise l11l11()
            if l11l111(l1lll111, password): break
    os.system(l11111l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11lll, l1l1l1l))
    l1ll1l=os.path.abspath(l1l1l1l)
    return l1ll1l
def l11ll1(l111ll1, l1lllll1, l111lll):
    l1l1l11 = os.path.join(os.environ[l11111l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11111l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11111l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l1l11)):
       os.makedirs(os.path.dirname(l1l1l11))
    l1l1l = l111lll.get_value(l11111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11111l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1111l = l1lll11l(l111ll1, l1l1l)
    l1lllll, password = l1111l.l111l1l(l11111l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1lllll1 + l11111l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1lllll1 + l11111l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lllll != l11111l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1111(l111ll1, l1lllll):
        l1111ll = l11111l (u"ࠤ࡙ࠣࠦ").join([l111ll1, l1lllll, l11111l (u"࡚ࠪࠦࠬ") + password + l11111l (u"࡛ࠫࠧ࠭"), l11111l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l1l11, l11111l (u"࠭ࡷࠬࠩ࡝")) as l1llll11:
            l1llll11.write(l1111ll)
        os.chmod(l1l1l11, 0o600)
    return l1lllll, password
def l1111(l111ll1, l1lllll):
    l1l1l11 = l1ll = os.path.join(os.environ[l11111l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11111l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11111l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l1l11):
        with open(l1l1l11, l11111l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll1ll1 = data[0].split(l11111l (u"ࠦࠥࠨࡢ"))
            if l111ll1 == l1ll1ll1[0] and l1lllll == l1ll1ll1[1]:
                return True
    return False