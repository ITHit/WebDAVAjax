#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l = 2048
l1lll11l = 7
def l11lll1 (l1ll1l1):
    global l1lll1
    l1111l = ord (l1ll1l1 [-1])
    l11111l = l1ll1l1 [:-1]
    l1l11l1 = l1111l % len (l11111l)
    l11l1l1 = l11111l [:l1l11l1] + l11111l [l1l11l1:]
    if l1l11l:
        l11ll = l1l111l () .join ([unichr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    return eval (l11ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11ll1=logging.WARNING
logger = logging.getLogger(l11lll1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11ll1)
l1l11ll1 = SysLogHandler(address=l11lll1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l11lll1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11ll1.setFormatter(formatter)
logger.addHandler(l1l11ll1)
ch = logging.StreamHandler()
ch.setLevel(l1lll11ll1)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l11lll1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l11lll1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1lll, l1lll1111l,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1lll = l1llll1lll
            self.l1lll1111l = l1lll1111l
            if not options:
                options = l11lll1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11lll1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1lll,
                                              self.l1lll1111l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1l1l1 = os.path.join(os.path.sep, l11lll1 (u"ࠪࡩࡹࡩࠧই"), l11lll1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll11lll = path
        else:
            self._1lll11lll = self.l1lll1l1l1
        super(l1llll1l1l, self).__init__(self._1lll11lll, l11lll1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1lll1(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l11lll1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l11lll1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11lll1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l11lll1 (u"ࠤࠦࠦ঍")):
                    yield self._1lll1lll1(line)
            except ValueError:
                pass
    def l1lllll11l(self, attr, value):
        for entry in self.entries:
            l1llll11ll = getattr(entry, attr)
            if l1llll11ll == value:
                return entry
        return None
    def l1lll111l1(self, entry):
        if self.l1lllll11l(l11lll1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l11lll1 (u"ࠫࡡࡴࠧএ")).encode(l11lll1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llllll11(self, entry):
        self.seek(0)
        lines = [l.decode(l11lll1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11lll1 (u"ࠢࠤࠤ঒")):
                if self._1lll1lll1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11lll1 (u"ࠨࠩও").join(lines).encode(l11lll1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll111ll(cls, l1llll1lll, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1lllll11l(l11lll1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1lll)
        if entry:
            return l1llll1ll1.l1llllll11(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1lll, l1lll1111l, options=None, path=None):
        return cls(path=path).l1lll111l1(l1llll1l1l.Entry(device,
                                                    l1llll1lll, l1lll1111l,
                                                    options=options))
class l1lll1ll1l(object):
    def __init__(self, l1llllll1l):
        self.l1lllll1ll=l11lll1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11111=l11lll1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llllll1l=l1llllll1l
        self.l1lll1l111()
        self.l1llll111l()
        self.l1lllllll1()
        self.l1lll1l1ll()
        self.l1lllll111()
    def l1lll1l111(self):
        temp_file=open(l1llll1111,l11lll1 (u"࠭ࡲࠨঘ"))
        l1lllll=temp_file.read()
        data=json.loads(l1lllll)
        self.user=data[l11lll1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1llllll=data[l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l111l1l=data[l11lll1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll11l=data[l11lll1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1llll11l1=data[l11lll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll11l1l=data[l11lll1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lllllll1(self):
        l1lll1l1=os.path.join(l11lll1 (u"ࠨ࠯ࠣট"),l11lll1 (u"ࠢࡶࡵࡵࠦঠ"),l11lll1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l11lll1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l11lll1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1lll1l1)
    def l1lllll111(self):
        logger.info(l11lll1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l111l1l=os.path.join(self.l1ll11l,self.l1lllll1ll)
        l1lll11l11 = pwd.getpwnam(self.user).pw_uid
        l1lllll1l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l111l1l):
            os.makedirs(l111l1l)
            os.system(l11lll1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l111l1l))
            logger.debug(l11lll1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l111l1l)
        else:
            logger.debug(l11lll1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l111l1l)
        l1lll1l1=os.path.join(l111l1l, self.l1lll11111)
        print(l1lll1l1)
        logger.debug(l11lll1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1lll1l1)
        with open(l1lll1l1, l11lll1 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l11l:
            logger.debug(self.l1llllll + l11lll1 (u"ࠪࠤࠬপ")+self.l1llll11l1+l11lll1 (u"ࠫࠥࠨࠧফ")+self.l1lll11l1l+l11lll1 (u"ࠬࠨࠧব"))
            l1lll1l11l.writelines(self.l1llllll + l11lll1 (u"࠭ࠠࠨভ")+self.l1llll11l1+l11lll1 (u"ࠧࠡࠤࠪম")+self.l1lll11l1l+l11lll1 (u"ࠨࠤࠪয"))
        os.chmod(l1lll1l1, 0o600)
        os.chown(l1lll1l1, l1lll11l11, l1lllll1l1)
    def l1llll111l(self, l1lll1llll=l11lll1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l11lll1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1llll in groups:
            logger.info(l11lll1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1llll))
        else:
            logger.warning(l11lll1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1llll))
            l1ll11=l11lll1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1llll,self.user)
            logger.debug(l11lll1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll11)
            os.system(l1ll11)
            logger.debug(l11lll1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1l1ll(self):
        logger.debug(l11lll1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1ll1=l1llll1l1l()
        l1llll1ll1.add(self.l1llllll, self.l111l1l, l1lll1111l=l11lll1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l11lll1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l11lll1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll1111 = urllib.parse.unquote(sys.argv[1])
        if l1llll1111:
            l1llll1l11=l1lll1ll1l(l1llll1111)
        else:
            raise (l11lll1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l11lll1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise