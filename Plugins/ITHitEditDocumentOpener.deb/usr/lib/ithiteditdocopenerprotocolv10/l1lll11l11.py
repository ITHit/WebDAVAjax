#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l1l1ll1 = 7
def l111lll (l11):
    global l111l1
    l1ll1l1 = ord (l11 [-1])
    l1lllll1 = l11 [:-1]
    l1l1111 = l1ll1l1 % len (l1lllll1)
    l1l11ll = l1lllll1 [:l1l1111] + l1lllll1 [l1l1111:]
    if l1ll111:
        l1ll11l1 = l1l11l1 () .join ([unichr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    else:
        l1ll11l1 = str () .join ([chr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    return eval (l1ll11l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1111l=logging.WARNING
logger = logging.getLogger(l111lll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1111l)
l11ll111 = SysLogHandler(address=l111lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l111lll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll111.setFormatter(formatter)
logger.addHandler(l11ll111)
ch = logging.StreamHandler()
ch.setLevel(l1lll1111l)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l111lll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l111lll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll1l1l1, l1lll1l111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1l1l1 = l1lll1l1l1
            self.l1lll1l111 = l1lll1l111
            if not options:
                options = l111lll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l111lll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll1l1l1,
                                              self.l1lll1l111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll11ll = os.path.join(os.path.sep, l111lll (u"ࠪࡩࡹࡩࠧই"), l111lll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lllll1ll = path
        else:
            self._1lllll1ll = self.l1llll11ll
        super(l1llll1l1l, self).__init__(self._1lllll1ll, l111lll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llllll1l(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l111lll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l111lll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l111lll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l111lll (u"ࠤࠦࠦ঍")):
                    yield self._1llllll1l(line)
            except ValueError:
                pass
    def l1lll1llll(self, attr, value):
        for entry in self.entries:
            l1llll11l1 = getattr(entry, attr)
            if l1llll11l1 == value:
                return entry
        return None
    def l1lllll11l(self, entry):
        if self.l1lll1llll(l111lll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l111lll (u"ࠫࡡࡴࠧএ")).encode(l111lll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1l1ll(self, entry):
        self.seek(0)
        lines = [l.decode(l111lll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l111lll (u"ࠢࠤࠤ঒")):
                if self._1llllll1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l111lll (u"ࠨࠩও").join(lines).encode(l111lll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1lll1(cls, l1lll1l1l1, path=None):
        l1lll1l11l = cls(path=path)
        entry = l1lll1l11l.l1lll1llll(l111lll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll1l1l1)
        if entry:
            return l1lll1l11l.l1lll1l1ll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1l1l1, l1lll1l111, options=None, path=None):
        return cls(path=path).l1lllll11l(l1llll1l1l.Entry(device,
                                                    l1lll1l1l1, l1lll1l111,
                                                    options=options))
class l1llllll11(object):
    def __init__(self, l1lllllll1):
        self.l1lll1ll1l=l111lll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11lll=l111lll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllllll1=l1lllllll1
        self.l1lll1ll11()
        self.l1lll111ll()
        self.l1lll11l1l()
        self.l1lll111l1()
        self.l1lllll1l1()
    def l1lll1ll11(self):
        temp_file=open(l1llll111l,l111lll (u"࠭ࡲࠨঘ"))
        l11l1l=temp_file.read()
        data=json.loads(l11l1l)
        self.user=data[l111lll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11ll11=data[l111lll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1111ll=data[l111lll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l111l1l=data[l111lll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll111=data[l111lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll11ll1=data[l111lll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll11l1l(self):
        l1l11l=os.path.join(l111lll (u"ࠨ࠯ࠣট"),l111lll (u"ࠢࡶࡵࡵࠦঠ"),l111lll (u"ࠣࡵࡥ࡭ࡳࠨড"),l111lll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l111lll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l11l)
    def l1lllll1l1(self):
        logger.info(l111lll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1111ll=os.path.join(self.l111l1l,self.l1lll1ll1l)
        l1llll1ll1 = pwd.getpwnam(self.user).pw_uid
        l1lll11111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1111ll):
            os.makedirs(l1111ll)
            os.system(l111lll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1111ll))
            logger.debug(l111lll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1111ll)
        else:
            logger.debug(l111lll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1111ll)
        l1l11l=os.path.join(l1111ll, self.l1lll11lll)
        print(l1l11l)
        logger.debug(l111lll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l11l)
        with open(l1l11l, l111lll (u"ࠤࡺ࠯ࠧ঩")) as l1llll1l11:
            logger.debug(self.l11ll11 + l111lll (u"ࠪࠤࠬপ")+self.l1lllll111+l111lll (u"ࠫࠥࠨࠧফ")+self.l1lll11ll1+l111lll (u"ࠬࠨࠧব"))
            l1llll1l11.writelines(self.l11ll11 + l111lll (u"࠭ࠠࠨভ")+self.l1lllll111+l111lll (u"ࠧࠡࠤࠪম")+self.l1lll11ll1+l111lll (u"ࠨࠤࠪয"))
        os.chmod(l1l11l, 0o600)
        os.chown(l1l11l, l1llll1ll1, l1lll11111)
    def l1lll111ll(self, l1llll1111=l111lll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l111lll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll1111 in groups:
            logger.info(l111lll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll1111))
        else:
            logger.warning(l111lll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll1111))
            l111ll=l111lll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll1111,self.user)
            logger.debug(l111lll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l111ll)
            os.system(l111ll)
            logger.debug(l111lll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll111l1(self):
        logger.debug(l111lll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l11l=l1llll1l1l()
        l1lll1l11l.add(self.l11ll11, self.l1111ll, l1lll1l111=l111lll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l111lll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l111lll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll111l = urllib.parse.unquote(sys.argv[1])
        if l1llll111l:
            l1llll1lll=l1llllll11(l1llll111l)
        else:
            raise (l111lll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l111lll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise