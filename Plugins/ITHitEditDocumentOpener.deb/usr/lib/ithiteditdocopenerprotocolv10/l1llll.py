#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1l1 = 2048
l1ll11 = 7
def l1lll11 (ll):
    global l11l1
    l11l111 = ord (ll [-1])
    l11ll1l = ll [:-1]
    l1l11 = l11l111 % len (l11ll1l)
    l111l1 = l11ll1l [:l1l11] + l11ll1l [l1l11:]
    if l11l1l:
        l1l111l = l1ll11l1 () .join ([unichr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    else:
        l1l111l = str () .join ([chr (ord (char) - l1l1 - (l1ll111l + l11l111) % l1ll11) for l1ll111l, char in enumerate (l111l1)])
    return eval (l1l111l)
import logging
import os
import re
from l1lll1 import l111111l
logger = logging.getLogger(l1lll11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1ll1111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll11 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l11l():
    try:
        out = os.popen(l1lll11 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll11 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll11 (u"ࠤࠥॸ").join(result)
                logger.info(l1lll11 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll11 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll11 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll11 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l111111l(l1lll11 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll11 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1ll1111(l1lll11 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))