#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1l11 = 7
def l1ll1lll (l1):
    global l1l1lll
    l1lll1l1 = ord (l1 [-1])
    l1l11l1 = l1 [:-1]
    l111l = l1lll1l1 % len (l1l11l1)
    l1ll1l1 = l1l11l1 [:l111l] + l1l11l1 [l111l:]
    if l1l1:
        l11lll = l11llll () .join ([unichr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    return eval (l11lll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll111ll=logging.WARNING
logger = logging.getLogger(l1ll1lll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll111ll)
l11ll1ll = SysLogHandler(address=l1ll1lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll1lll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l11ll1ll)
ch = logging.StreamHandler()
ch.setLevel(l1lll111ll)
logger.addHandler(ch)
class l1llll1lll(io.FileIO):
    l1ll1lll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll1lll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llllll11, l1lllll1ll,
                     options, d=0, p=0):
            self.device = device
            self.l1llllll11 = l1llllll11
            self.l1lllll1ll = l1lllll1ll
            if not options:
                options = l1ll1lll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll1lll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llllll11,
                                              self.l1lllll1ll,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11l11 = os.path.join(os.path.sep, l1ll1lll (u"ࠪࡩࡹࡩࠧই"), l1ll1lll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1111l = path
        else:
            self._1lll1111l = self.l1lll11l11
        super(l1llll1lll, self).__init__(self._1lll1111l, l1ll1lll (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll1l1l(self, line):
        return l1llll1lll.Entry(*[x for x in line.strip(l1ll1lll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll1lll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll1lll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll1lll (u"ࠤࠦࠦ঍")):
                    yield self._1llll1l1l(line)
            except ValueError:
                pass
    def l1lll11ll1(self, attr, value):
        for entry in self.entries:
            l1lllll11l = getattr(entry, attr)
            if l1lllll11l == value:
                return entry
        return None
    def l1lll1ll1l(self, entry):
        if self.l1lll11ll1(l1ll1lll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll1lll (u"ࠫࡡࡴࠧএ")).encode(l1ll1lll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1llll(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll1lll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll1lll (u"ࠢࠤࠤ঒")):
                if self._1llll1l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll1lll (u"ࠨࠩও").join(lines).encode(l1ll1lll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll11(cls, l1llllll11, path=None):
        l1lll11111 = cls(path=path)
        entry = l1lll11111.l1lll11ll1(l1ll1lll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llllll11)
        if entry:
            return l1lll11111.l1lll1llll(entry)
        return False
    @classmethod
    def add(cls, device, l1llllll11, l1lllll1ll, options=None, path=None):
        return cls(path=path).l1lll1ll1l(l1llll1lll.Entry(device,
                                                    l1llllll11, l1lllll1ll,
                                                    options=options))
class l1lll1l1ll(object):
    def __init__(self, l1lll111l1):
        self.l1lll1l1l1=l1ll1lll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llllll1l=l1ll1lll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll111l1=l1lll111l1
        self.l1llll1ll1()
        self.l1lll1l111()
        self.l1lll1l11l()
        self.l1lllll1l1()
        self.l1llll111l()
    def l1llll1ll1(self):
        temp_file=open(l1lllll111,l1ll1lll (u"࠭ࡲࠨঘ"))
        l1ll1l1l=temp_file.read()
        data=json.loads(l1ll1l1l)
        self.user=data[l1ll1lll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l1l=data[l1ll1lll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1l1ll=data[l1ll1lll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll1111=data[l1ll1lll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll11l1l=data[l1ll1lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1llll1111=data[l1ll1lll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l11l(self):
        l1l1l=os.path.join(l1ll1lll (u"ࠨ࠯ࠣট"),l1ll1lll (u"ࠢࡶࡵࡵࠦঠ"),l1ll1lll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll1lll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll1lll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1l1l)
    def l1llll111l(self):
        logger.info(l1ll1lll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1l1ll=os.path.join(self.l1ll1111,self.l1lll1l1l1)
        l1lll1lll1 = pwd.getpwnam(self.user).pw_uid
        l1llll1l11 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l1ll):
            os.makedirs(l1l1ll)
            os.system(l1ll1lll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1l1ll))
            logger.debug(l1ll1lll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1l1ll)
        else:
            logger.debug(l1ll1lll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1l1ll)
        l1l1l=os.path.join(l1l1ll, self.l1llllll1l)
        print(l1l1l)
        logger.debug(l1ll1lll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1l1l)
        with open(l1l1l, l1ll1lll (u"ࠤࡺ࠯ࠧ঩")) as l1llll11l1:
            logger.debug(self.l11l1l + l1ll1lll (u"ࠪࠤࠬপ")+self.l1lll11l1l+l1ll1lll (u"ࠫࠥࠨࠧফ")+self.l1llll1111+l1ll1lll (u"ࠬࠨࠧব"))
            l1llll11l1.writelines(self.l11l1l + l1ll1lll (u"࠭ࠠࠨভ")+self.l1lll11l1l+l1ll1lll (u"ࠧࠡࠤࠪম")+self.l1llll1111+l1ll1lll (u"ࠨࠤࠪয"))
        os.chmod(l1l1l, 0o600)
        os.chown(l1l1l, l1lll1lll1, l1llll1l11)
    def l1lll1l111(self, l1lll11lll=l1ll1lll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll1lll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11lll in groups:
            logger.info(l1ll1lll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11lll))
        else:
            logger.warning(l1ll1lll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11lll))
            l1lll111=l1ll1lll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11lll,self.user)
            logger.debug(l1ll1lll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1lll111)
            os.system(l1lll111)
            logger.debug(l1ll1lll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lllll1l1(self):
        logger.debug(l1ll1lll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll11111=l1llll1lll()
        l1lll11111.add(self.l11l1l, self.l1l1ll, l1lllll1ll=l1ll1lll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll1lll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll1lll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll111 = urllib.parse.unquote(sys.argv[1])
        if l1lllll111:
            l1llll11ll=l1lll1l1ll(l1lllll111)
        else:
            raise (l1ll1lll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll1lll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise