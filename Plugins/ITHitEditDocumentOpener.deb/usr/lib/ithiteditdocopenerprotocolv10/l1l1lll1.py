#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l = sys.version_info [0] == 2
l1llll11 = 2048
l1l11l = 7
def l11l1l1 (l1l111):
    global l1llllll
    l1lll = ord (l1l111 [-1])
    l1lll1l = l1l111 [:-1]
    l1ll1l1 = l1lll % len (l1lll1l)
    l11l11 = l1lll1l [:l1ll1l1] + l1lll1l [l1ll1l1:]
    if l1ll11l:
        l1l = l1111l () .join ([unichr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    return eval (l1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lllll1 import l1ll11
from configobj import ConfigObj
l1l1l111 = l11l1l1 (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1llll = l11l1l1 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠹࠹࠳࠶ࠢࡤ")
l11ll1ll = l11l1l1 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l11l1l1 (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠸࠸࠲࠵ࠨࡦ")
l1l11l11=os.path.join(os.environ.get(l11l1l1 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l11l1l1 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll1ll.replace(l11l1l1 (u"ࠦࠥࠨࡩ"), l11l1l1 (u"ࠧࡥࠢࡪ")).lower())
l1l1l1l1=os.environ.get(l11l1l1 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l11l1l1 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l11ll1l1=l1l1llll.replace(l11l1l1 (u"ࠣࠢࠥ࡭"), l11l1l1 (u"ࠤࡢࠦ࡮"))+l11l1l1 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l11l1l1 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l111ll=os.path.join(os.environ.get(l11l1l1 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l11ll1l1)
elif platform.system() == l11l1l1 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11ll11l=l1ll11(l1l11l11+l11l1l1 (u"ࠢ࠰ࠤࡳ"))
    l1l111ll = os.path.join(l11ll11l, l11ll1l1)
else:
    l1l111ll = os.path.join( l11ll1l1)
l1l1l1l1=l1l1l1l1.upper()
if l1l1l1l1 == l11l1l1 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11ll111=logging.DEBUG
elif l1l1l1l1 == l11l1l1 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11ll111 = logging.INFO
elif l1l1l1l1 == l11l1l1 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11ll111 = logging.WARNING
elif l1l1l1l1 == l11l1l1 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11ll111 = logging.ERROR
elif l1l1l1l1 == l11l1l1 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11ll111 = logging.CRITICAL
elif l1l1l1l1 == l11l1l1 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11ll111 = logging.NOTSET
logger = logging.getLogger(l11l1l1 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11ll111)
l1l1ll1l = logging.FileHandler(l1l111ll, mode=l11l1l1 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1ll1l.setLevel(l11ll111)
formatter = logging.Formatter(l11l1l1 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l11l1l1 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1ll1l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll111)
l11lll11 = SysLogHandler(address=l11l1l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11lll11.setFormatter(formatter)
logger.addHandler(l1l1ll1l)
logger.addHandler(ch)
logger.addHandler(l11lll11)
class Settings():
    l1l11111 = l11l1l1 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11l1lll = l11l1l1 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l11lll = l11l1l1 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1llll):
        self.l1l1l11l = self._1l1l1ll(l1l1llll)
        self._1l111l1()
    def _1l1l1ll(self, l1l1llll):
        l11lllll = l1l1llll.split(l11l1l1 (u"ࠣࠢࠥࢂ"))
        l11lllll = l11l1l1 (u"ࠤࠣࠦࢃ").join(l11lllll)
        if platform.system() == l11l1l1 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l1l11l = os.path.join(l1l11l11, l11l1l1 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l11lllll + l11l1l1 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l1l11l
    def l1l1111l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11llll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11l1l1 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11l1l1 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11ll1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l111l1(self):
        if not os.path.exists(os.path.dirname(self.l1l1l11l)):
            os.makedirs(os.path.dirname(self.l1l1l11l))
        if not os.path.exists(self.l1l1l11l):
            self.config = ConfigObj(self.l1l1l11l)
            self.config[l11l1l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l11l1l1 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l11l1l1 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l11lll
            self.config[l11l1l1 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l11l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11l1lll
            self.config[l11l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l11l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l11111
            self.config[l11l1l1 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l11l)
            self.l1l11lll = self.get_value(l11l1l1 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l11l1l1 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11l1lll = self.get_value(l11l1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11l1l1 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l11111 = self.get_value(l11l1l1 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l11l1l1 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l11l1l(self):
        l11lll1l = l11l1l1 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l11111
        l11lll1l += l11l1l1 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11l1lll
        l11lll1l += l11l1l1 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l11lll
        return l11lll1l
    def __unicode__(self):
        return self._1l11l1l()
    def __str__(self):
        return self._1l11l1l()
    def __del__(self):
        self.config.write()
l1l1ll11 = Settings(l1l1llll)