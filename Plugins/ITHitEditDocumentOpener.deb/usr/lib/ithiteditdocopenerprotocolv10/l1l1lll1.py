#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l1 = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1l1l = 7
def l1ll1 (l11l1l1):
    global l1lll11
    l111l11 = ord (l11l1l1 [-1])
    l1111l1 = l11l1l1 [:-1]
    l1l1ll = l111l11 % len (l1111l1)
    l1l1l1 = l1111l1 [:l1l1ll] + l1111l1 [l1l1ll:]
    if l1lll1l1:
        l1111l = l11ll11 () .join ([unichr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    return eval (l1111l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll11l import l11l111
from configobj import ConfigObj
l1l111ll = l1ll1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l11lllll = l1ll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠷࠴࠱࠴ࠧࡢ")
l1l1l1l1 = l1ll1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1ll1 (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠶࠳࠰࠳ࠦࡤ")
l1l1l11l=os.path.join(os.environ.get(l1ll1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1ll1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l1l1l1.replace(l1ll1 (u"ࠤࠣࠦࡧ"), l1ll1 (u"ࠥࡣࠧࡨ")).lower())
l1l1l1ll=os.environ.get(l1ll1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1ll1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1ll1111=l11lllll.replace(l1ll1 (u"ࠨࠠࠣ࡫"), l1ll1 (u"ࠢࡠࠤ࡬"))+l1ll1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1ll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l11lll11=os.path.join(os.environ.get(l1ll1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1ll1111)
elif platform.system() == l1ll1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l11ll1=l11l111(l1l1l11l+l1ll1 (u"ࠧ࠵ࠢࡱ"))
    l11lll11 = os.path.join(l1l11ll1, l1ll1111)
else:
    l11lll11 = os.path.join( l1ll1111)
l1l1l1ll=l1l1l1ll.upper()
if l1l1l1ll == l1ll1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11lll1l=logging.DEBUG
elif l1l1l1ll == l1ll1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11lll1l = logging.INFO
elif l1l1l1ll == l1ll1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11lll1l = logging.WARNING
elif l1l1l1ll == l1ll1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11lll1l = logging.ERROR
elif l1l1l1ll == l1ll1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11lll1l = logging.CRITICAL
elif l1l1l1ll == l1ll1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11lll1l = logging.NOTSET
logger = logging.getLogger(l1ll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11lll1l)
l1l111l1 = logging.FileHandler(l11lll11, mode=l1ll1 (u"ࠨࡷࠬࠤࡹ"))
l1l111l1.setLevel(l11lll1l)
formatter = logging.Formatter(l1ll1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1ll1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l111l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll1l)
l11llll1 = SysLogHandler(address=l1ll1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l11llll1.setFormatter(formatter)
logger.addHandler(l1l111l1)
logger.addHandler(ch)
logger.addHandler(l11llll1)
class Settings():
    l1l1l111 = l1ll1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l11l11 = l1ll1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l11ll1l1 = l1ll1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l11lllll):
        self.l11ll1ll = self._11ll11l(l11lllll)
        self._1l11111()
    def _11ll11l(self, l11lllll):
        l1l11lll = l11lllll.split(l1ll1 (u"ࠨࠠࠣࢀ"))
        l1l11lll = l1ll1 (u"ࠢࠡࠤࢁ").join(l1l11lll)
        if platform.system() == l1ll1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11ll1ll = os.path.join(l1l1l11l, l1ll1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l11lll + l1ll1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11ll1ll
    def l1l1111l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1llll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1ll11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11111(self):
        if not os.path.exists(os.path.dirname(self.l11ll1ll)):
            os.makedirs(os.path.dirname(self.l11ll1ll))
        if not os.path.exists(self.l11ll1ll):
            self.config = ConfigObj(self.l11ll1ll)
            self.config[l1ll1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1ll1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1ll1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l11ll1l1
            self.config[l1ll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1ll1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l11l11
            self.config[l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1l111
            self.config[l1ll1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll1ll)
            self.l11ll1l1 = self.get_value(l1ll1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1ll1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l11l11 = self.get_value(l1ll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1ll1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1l111 = self.get_value(l1ll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1ll1l(self):
        l1l11l1l = l1ll1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1l111
        l1l11l1l += l1ll1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l11l11
        l1l11l1l += l1ll1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l11ll1l1
        return l1l11l1l
    def __unicode__(self):
        return self._1l1ll1l()
    def __str__(self):
        return self._1l1ll1l()
    def __del__(self):
        self.config.write()
l1ll111l = Settings(l11lllll)