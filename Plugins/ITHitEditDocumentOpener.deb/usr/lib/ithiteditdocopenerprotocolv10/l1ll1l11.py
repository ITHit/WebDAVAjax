#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l = sys.version_info [0] == 2
l1llll11 = 2048
l1l11l = 7
def l11l1l1 (l1l111):
    global l1llllll
    l1lll = ord (l1l111 [-1])
    l1lll1l = l1l111 [:-1]
    l1ll1l1 = l1lll % len (l1lll1l)
    l11l11 = l1lll1l [:l1ll1l1] + l1lll1l [l1ll1l1:]
    if l1ll11l:
        l1l = l1111l () .join ([unichr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    else:
        l1l = str () .join ([chr (ord (char) - l1llll11 - (l1l1111 + l1lll) % l1l11l) for l1l1111, char in enumerate (l11l11)])
    return eval (l1l)
import hashlib
import os
import l1lllll1
from ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lllll1 import l1ll11
from l1l1l1l import l11l11l, l1ll1111
import logging
logger = logging.getLogger(l11l1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11111l():
    def __init__(self, l1ll1lll,l111l, l1lll11l= None, l1lll11=None):
        self.l1lll1ll=False
        self.l1lllll = self._1llll1()
        self.l111l = l111l
        self.l1lll11l = l1lll11l
        self.l1ll1l = l1ll1lll
        if l1lll11l:
            self.l1ll11ll = True
        else:
            self.l1ll11ll = False
        self.l1lll11 = l1lll11
    def _1llll1(self):
        try:
            return l1lllll1.l111111() is not None
        except:
            return False
    def open(self):
        l11l1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1lllll:
            raise NotImplementedError(l11l1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11l1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l111 = self.l1ll1l
        if self.l111l.lower().startswith(self.l1ll1l.lower()):
            l1ll111 = re.compile(re.escape(self.l1ll1l), re.IGNORECASE)
            l111l = l1ll111.sub(l11l1l1 (u"ࠨࠩࠄ"), self.l111l)
            l111l = l111l.replace(l11l1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11l1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll1l(self.l1ll1l, l111, l111l, self.l1lll11l)
    def l11ll1l(self,l1ll1l, l111, l111l, l1lll11l):
        l11l1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11l1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111lll = l1l11ll(l1ll1l)
        l1l1l11 = self.l1l11l1(l111lll)
        logger.info(l11l1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111lll)
        if l1l1l11:
            logger.info(l11l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll11(l111lll)
            l111lll = l1l111l(l1ll1l, l111, l1lll11l, self.l1lll11)
        logger.debug(l11l1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1=l111lll + l11l1l1 (u"ࠤ࠲ࠦࠌ") + l111l
        l1ll11l1 = l11l1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1+ l11l1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll11l1)
        l1111l1 = os.system(l1ll11l1)
        if (l1111l1 != 0):
            raise IOError(l11l1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1, l1111l1))
    def l1l11l1(self, l111lll):
        if os.path.exists(l111lll):
            if os.path.islink(l111lll):
                l111lll = os.readlink(l111lll)
            if os.path.ismount(l111lll):
                return True
        return False
def l1l11ll(l1ll1l):
    l1lll1l1 = l1ll1l.replace(l11l1l1 (u"࠭࡜࡝ࠩࠐ"), l11l1l1 (u"ࠧࡠࠩࠑ")).replace(l11l1l1 (u"ࠨ࠱ࠪࠒ"), l11l1l1 (u"ࠩࡢࠫࠓ"))
    l11ll11 = l11l1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111ll1=os.environ[l11l1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l111l1l=os.path.join(l111ll1,l11ll11, l1lll1l1)
    l1l1l1=os.path.abspath(l111l1l)
    return l1l1l1
def l1l1ll(l11ll):
    if not os.path.exists(l11ll):
        os.makedirs(l11ll)
def l111l1(l1ll1l, l111, l1l11=None, password=None):
    l11l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11ll = l1l11ll(l1ll1l)
    l1l1ll(l11ll)
    if not l1l11:
        l1l1l = l1ll1()
        l1111 =l1l1l.l11llll(l11l1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l111 + l11l1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l111 + l11l1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1111, str):
            l1l11, password = l1111
        else:
            raise l1ll1111()
        logger.info(l11l1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11ll))
    l1ll111l = pwd.getpwuid( os.getuid())[0]
    l1llll=os.environ[l11l1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11ll1={l11l1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll111l, l11l1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1l, l11l1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11ll, l11l1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1llll, l11l1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l11, l11l1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11ll1, temp_file)
        if not os.path.exists(os.path.join(l1ll, l11l1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll111=l11l1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l11l1l1 (u"ࠧࠨࠤ")
        else:
            l1lll111=l11l1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11l1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1l1lll=l11l1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll111,temp_file.name)
        l11l1l=[l11l1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11l1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll, l1l1lll)]
        p = subprocess.Popen(l11l1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11l1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11l1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11l1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11ll
    logger.debug(l11l1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11l1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1l1=os.path.abspath(l11ll)
    logger.debug(l11l1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1l1)
    return l1l1l1
def l1l111l(l1ll1l, l111, l1lll11l, l1lll11):
    l11l1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll1l1l(title):
        l1llll1l=30
        if len(title)>l1llll1l:
            l11l=title.split(l11l1l1 (u"ࠨ࠯ࠣ࠳"))
            l11l111=l11l1l1 (u"ࠧࠨ࠴")
            for block in l11l:
                l11l111+=block+l11l1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l11l111) > l1llll1l:
                    l11l111+=l11l1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l111
        return title
    def l11111(l1lll1, password):
        l11l1l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11l1l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11l1l1 (u"ࠧࠦࠢ࠹").join(l1lll1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll1ll = l11l1l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll1ll.encode())
        l11 = [l11l1l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l1ll1 = l11l1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l1ll1)
            for e in l11:
                if e in l1l1ll1: return False
            raise l11l11l(l1l1ll1, l1l111l=l1lllll1.l111111(), l111=l111)
        logger.info(l11l1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l11 = l11l1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11l1l1 (u"ࠦࠧ࠿")
    os.system(l11l1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1 = l1l11ll(l1ll1l)
    l11ll = l1l11ll(hashlib.sha1(l1ll1l.encode()).hexdigest()[:10])
    l1l1ll(l11ll)
    logger.info(l11l1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11ll))
    if l1lll11l:
        l1lll1 = [l11l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11l1l1 (u"ࠤ࠰ࡸࠧࡄ"), l11l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11l1l1 (u"ࠫ࠲ࡵࠧࡆ"), l11l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l11, l1lll11l),
                    urllib.parse.unquote(l111), os.path.abspath(l11ll)]
        l11111(l1lll1, password)
    else:
        while True:
            l1l11, password = l1111ll(l11ll, l111, l1lll11)
            if l1l11.lower() != l11l1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1lll1 = [l11l1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11l1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11l1l1 (u"ࠤ࠰ࡸࠧࡋ"), l11l1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11l1l1 (u"ࠫ࠲ࡵࠧࡍ"), l11l1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l11,
                            urllib.parse.unquote(l111), os.path.abspath(l11ll)]
            else:
                raise l1ll1111()
            if l11111(l1lll1, password): break
    os.system(l11l1l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11ll, l1))
    l1l1l1=os.path.abspath(l1)
    return l1l1l1
def l1111ll(l1ll1l, l111, l1lll11):
    l11l1 = os.path.join(os.environ[l11l1l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11l1)):
       os.makedirs(os.path.dirname(l11l1))
    l111ll = l1lll11.get_value(l11l1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11l1l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l1l = l1ll1(l1ll1l, l111ll)
    l1l11, password = l1l1l.l11llll(l11l1l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l111 + l11l1l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l111 + l11l1l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l11 != l11l1l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll1ll1(l1ll1l, l1l11):
        l111l11 = l11l1l1 (u"ࠤ࡙ࠣࠦ").join([l1ll1l, l1l11, l11l1l1 (u"࡚ࠪࠦࠬ") + password + l11l1l1 (u"࡛ࠫࠧ࠭"), l11l1l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11l1, l11l1l1 (u"࠭ࡷࠬࠩ࡝")) as l11lll1:
            l11lll1.write(l111l11)
        os.chmod(l11l1, 0o600)
    return l1l11, password
def l1ll1ll1(l1ll1l, l1l11):
    l11l1 = l11l1ll = os.path.join(os.environ[l11l1l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11l1l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11l1l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11l1):
        with open(l11l1, l11l1l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11lll = data[0].split(l11l1l1 (u"ࠦࠥࠨࡢ"))
            if l1ll1l == l11lll[0] and l1l11 == l11lll[1]:
                return True
    return False