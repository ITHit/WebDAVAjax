#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1111 = sys.version_info [0] == 2
l1ll1l1 = 2048
l1lll1l1 = 7
def l1l1ll (l1ll1l1l):
    global l111l1
    l1l11l1 = ord (l1ll1l1l [-1])
    l1lll1l = l1ll1l1l [:-1]
    l1llll1 = l1l11l1 % len (l1lll1l)
    ll = l1lll1l [:l1llll1] + l1lll1l [l1llll1:]
    if l1l1111:
        l1111 = l1l1lll () .join ([unichr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    else:
        l1111 = str () .join ([chr (ord (char) - l1ll1l1 - (l111ll + l1l11l1) % l1lll1l1) for l111ll, char in enumerate (ll)])
    return eval (l1111)
import logging
import os
import re
from l11ll1 import l111111l
logger = logging.getLogger(l1l1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1lll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1ll (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11111():
    try:
        out = os.popen(l1l1ll (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1l1ll (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1l1ll (u"ࠢࠣॶ").join(result)
                logger.info(l1l1ll (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1l1ll (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1l1ll (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1l1ll (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l111111l(l1l1ll (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1l1ll (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1lll1(l1l1ll (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))