#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1l111l = 7
def l1ll1l1l (l11ll1l):
    global l1l11
    l1 = ord (l11ll1l [-1])
    l1lll = l11ll1l [:-1]
    l1lllll = l1 % len (l1lll)
    l1lll11 = l1lll [:l1lllll] + l1lll [l1lllll:]
    if l1l1ll1:
        l1l11l = l111l11 () .join ([unichr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    return eval (l1l11l)
import hashlib
import os
import l11l1l1
from l1ll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11l1l1 import l1111l
from l1ll1lll import l11lll, l1ll1ll1
import logging
logger = logging.getLogger(l1ll1l1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111():
    def __init__(self, l1ll,l1l1lll, l111lll= None, l11l=None):
        self.l1l=False
        self.l111l1 = self._11111l()
        self.l1l1lll = l1l1lll
        self.l111lll = l111lll
        self.l11llll = l1ll
        if l111lll:
            self.l1ll1ll = True
        else:
            self.l1ll1ll = False
        self.l11l = l11l
    def _11111l(self):
        try:
            return l11l1l1.l111l1l() is not None
        except:
            return False
    def open(self):
        l1ll1l1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111l1:
            raise NotImplementedError(l1ll1l1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1l1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l11ll = self.l11llll
        if self.l1l1lll.lower().startswith(self.l11llll.lower()):
            l1ll111l = re.compile(re.escape(self.l11llll), re.IGNORECASE)
            l1l1lll = l1ll111l.sub(l1ll1l1l (u"ࠨࠩࠄ"), self.l1l1lll)
            l1l1lll = l1l1lll.replace(l1ll1l1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1l1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l111ll(self.l11llll, l1l11ll, l1l1lll, self.l111lll)
    def l111ll(self,l11llll, l1l11ll, l1l1lll, l111lll):
        l1ll1l1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1l1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1l11 = l11l11(l11llll)
        l1111 = self.l1lll1(l1ll1l11)
        logger.info(l1ll1l1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1l11)
        if l1111:
            logger.info(l1ll1l1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1111l(l1ll1l11)
            l1ll1l11 = l1l1(l11llll, l1l11ll, l111lll, self.l11l)
        logger.debug(l1ll1l1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll1l1=l1ll1l11 + l1ll1l1l (u"ࠤ࠲ࠦࠌ") + l1l1lll
        l1111l1 = l1ll1l1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll1l1+ l1ll1l1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1111l1)
        l1llll1 = os.system(l1111l1)
        if (l1llll1 != 0):
            raise IOError(l1ll1l1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll1l1, l1llll1))
    def l1lll1(self, l1ll1l11):
        if os.path.exists(l1ll1l11):
            if os.path.islink(l1ll1l11):
                l1ll1l11 = os.readlink(l1ll1l11)
            if os.path.ismount(l1ll1l11):
                return True
        return False
def l11l11(l11llll):
    l111l = l11llll.replace(l1ll1l1l (u"࠭࡜࡝ࠩࠐ"), l1ll1l1l (u"ࠧࡠࠩࠑ")).replace(l1ll1l1l (u"ࠨ࠱ࠪࠒ"), l1ll1l1l (u"ࠩࡢࠫࠓ"))
    ll = l1ll1l1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l11l1=os.environ[l1ll1l1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1ll=os.path.join(l1l11l1,ll, l111l)
    l1ll1l1=os.path.abspath(l1l1ll)
    return l1ll1l1
def l1llll(l11111):
    if not os.path.exists(l11111):
        os.makedirs(l11111)
def l1ll11ll(l11llll, l1l11ll, l1lll1ll=None, password=None):
    l1ll1l1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11111 = l11l11(l11llll)
    l1llll(l11111)
    if not l1lll1ll:
        l11l11l = l1lll111()
        l111111 =l11l11l.l111ll1(l1ll1l1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l11ll + l1ll1l1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l11ll + l1ll1l1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l111111, str):
            l1lll1ll, password = l111111
        else:
            raise l1ll1ll1()
        logger.info(l1ll1l1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11111))
    l1lllll1 = pwd.getpwuid( os.getuid())[0]
    l11l1l=os.environ[l1ll1l1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11ll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11l1={l1ll1l1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lllll1, l1ll1l1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11llll, l1ll1l1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11111, l1ll1l1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11l1l, l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll1ll, l1ll1l1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11l1, temp_file)
        if not os.path.exists(os.path.join(l11ll1, l1ll1l1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll11=l1ll1l1l (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1l1l (u"ࠧࠨࠤ")
        else:
            l1ll11=l1ll1l1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1l1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11=l1ll1l1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll11,temp_file.name)
        l11l111=[l1ll1l1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1l1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11ll1, l11)]
        p = subprocess.Popen(l11l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1l1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1l1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1l1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11111
    logger.debug(l1ll1l1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1l1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1l1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1l1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll1l1=os.path.abspath(l11111)
    logger.debug(l1ll1l1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll1l1)
    return l1ll1l1
def l1l1(l11llll, l1l11ll, l111lll, l11l):
    l1ll1l1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l111(title):
        l1l1111=30
        if len(title)>l1l1111:
            l1ll1l=title.split(l1ll1l1l (u"ࠨ࠯ࠣ࠳"))
            l1ll11l=l1ll1l1l (u"ࠧࠨ࠴")
            for block in l1ll1l:
                l1ll11l+=block+l1ll1l1l (u"ࠣ࠱ࠥ࠵")
                if len(l1ll11l) > l1l1111:
                    l1ll11l+=l1ll1l1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll11l
        return title
    def l11l1ll(l1l1l, password):
        l1ll1l1l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1l1l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1l1l (u"ࠧࠦࠢ࠹").join(l1l1l)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1llll11 = l1ll1l1l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1llll11.encode())
        l11lll1 = [l1ll1l1l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll11l = l1ll1l1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll11l)
            for e in l11lll1:
                if e in l1lll11l: return False
            raise l11lll(l1lll11l, l1l1=l11l1l1.l111l1l(), l1l11ll=l1l11ll)
        logger.info(l1ll1l1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll1ll = l1ll1l1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1l1l (u"ࠦࠧ࠿")
    os.system(l1ll1l1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll1111 = l11l11(l11llll)
    l11111 = l11l11(hashlib.sha1(l11llll.encode()).hexdigest()[:10])
    l1llll(l11111)
    logger.info(l1ll1l1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11111))
    if l111lll:
        l1l1l = [l1ll1l1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1l1l (u"ࠤ࠰ࡸࠧࡄ"), l1ll1l1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1l1l (u"ࠫ࠲ࡵࠧࡆ"), l1ll1l1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll1ll, l111lll),
                    urllib.parse.unquote(l1l11ll), os.path.abspath(l11111)]
        l11l1ll(l1l1l, password)
    else:
        while True:
            l1lll1ll, password = l1llll1l(l11111, l1l11ll, l11l)
            if l1lll1ll.lower() != l1ll1l1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1l1l = [l1ll1l1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1l1l (u"ࠤ࠰ࡸࠧࡋ"), l1ll1l1l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1l1l (u"ࠫ࠲ࡵࠧࡍ"), l1ll1l1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll1ll,
                            urllib.parse.unquote(l1l11ll), os.path.abspath(l11111)]
            else:
                raise l1ll1ll1()
            if l11l1ll(l1l1l, password): break
    os.system(l1ll1l1l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11111, l1ll1111))
    l1ll1l1=os.path.abspath(l1ll1111)
    return l1ll1l1
def l1llll1l(l11llll, l1l11ll, l11l):
    l1ll111 = os.path.join(os.environ[l1ll1l1l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1l1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1l1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll111)):
       os.makedirs(os.path.dirname(l1ll111))
    l1l1l11 = l11l.get_value(l1ll1l1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1l1l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11l11l = l1lll111(l11llll, l1l1l11)
    l1lll1ll, password = l11l11l.l111ll1(l1ll1l1l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l11ll + l1ll1l1l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l11ll + l1ll1l1l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll1ll != l1ll1l1l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l11ll11(l11llll, l1lll1ll):
        l1111ll = l1ll1l1l (u"ࠤ࡙ࠣࠦ").join([l11llll, l1lll1ll, l1ll1l1l (u"࡚ࠪࠦࠬ") + password + l1ll1l1l (u"࡛ࠫࠧ࠭"), l1ll1l1l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll111, l1ll1l1l (u"࠭ࡷࠬࠩ࡝")) as l1llllll:
            l1llllll.write(l1111ll)
        os.chmod(l1ll111, 0o600)
    return l1lll1ll, password
def l11ll11(l11llll, l1lll1ll):
    l1ll111 = l1l1l1 = os.path.join(os.environ[l1ll1l1l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1l1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1l1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll111):
        with open(l1ll111, l1ll1l1l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lll1l = data[0].split(l1ll1l1l (u"ࠦࠥࠨࡢ"))
            if l11llll == l1lll1l[0] and l1lll1ll == l1lll1l[1]:
                return True
    return False