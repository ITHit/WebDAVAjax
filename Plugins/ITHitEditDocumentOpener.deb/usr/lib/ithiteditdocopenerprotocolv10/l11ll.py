#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l = sys.version_info [0] == 2
ll = 2048
l1 = 7
def l1111l1 (l1ll1lll):
    global l1ll1l1
    l1111 = ord (l1ll1lll [-1])
    l1l1lll = l1ll1lll [:-1]
    l11l1 = l1111 % len (l1l1lll)
    l1l1111 = l1l1lll [:l11l1] + l1l1lll [l11l1:]
    if l1lll1l:
        l1ll1ll1 = l1l1l () .join ([unichr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    else:
        l1ll1ll1 = str () .join ([chr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    return eval (l1ll1ll1)
import hashlib
import os
import l1ll111l
from l1lll111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll111l import l11lll1
from l1lll11 import l11111, l1111l
import logging
logger = logging.getLogger(l1111l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1lll11l():
    def __init__(self, l111l1l,l1ll11l1, l1lll= None, l1l11l1=None):
        self.l1l111=False
        self.l1l111l = self._1ll1l11()
        self.l1ll11l1 = l1ll11l1
        self.l1lll = l1lll
        self.l1ll1 = l111l1l
        if l1lll:
            self.l1l11ll = True
        else:
            self.l1l11ll = False
        self.l1l11l1 = l1l11l1
    def _1ll1l11(self):
        try:
            return l1ll111l.l111111() is not None
        except:
            return False
    def open(self):
        l1111l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l111l:
            raise NotImplementedError(l1111l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1111l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11l = self.l1ll1
        if self.l1ll11l1.lower().startswith(self.l1ll1.lower()):
            l111l = re.compile(re.escape(self.l1ll1), re.IGNORECASE)
            l1ll11l1 = l111l.sub(l1111l1 (u"ࠨࠩࠄ"), self.l1ll11l1)
            l1ll11l1 = l1ll11l1.replace(l1111l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1111l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11l11l(self.l1ll1, l11l, l1ll11l1, self.l1lll)
    def l11l11l(self,l1ll1, l11l, l1ll11l1, l1lll):
        l1111l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1111l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1l1 = l1l(l1ll1)
        l1ll11l = self.l1ll1111(l1l1l1)
        logger.info(l1111l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1l1)
        if l1ll11l:
            logger.info(l1111l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11lll1(l1l1l1)
            l1l1l1 = l1lll1l1(l1ll1, l11l, l1lll, self.l1l11l1)
        logger.debug(l1111l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11ll1l=l1l1l1 + l1111l1 (u"ࠤ࠲ࠦࠌ") + l1ll11l1
        l1ll1ll = l1111l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11ll1l+ l1111l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1ll)
        l1lll1 = os.system(l1ll1ll)
        if (l1lll1 != 0):
            raise IOError(l1111l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11ll1l, l1lll1))
    def l1ll1111(self, l1l1l1):
        if os.path.exists(l1l1l1):
            if os.path.islink(l1l1l1):
                l1l1l1 = os.readlink(l1l1l1)
            if os.path.ismount(l1l1l1):
                return True
        return False
def l1l(l1ll1):
    l111l11 = l1ll1.replace(l1111l1 (u"࠭࡜࡝ࠩࠐ"), l1111l1 (u"ࠧࡠࠩࠑ")).replace(l1111l1 (u"ࠨ࠱ࠪࠒ"), l1111l1 (u"ࠩࡢࠫࠓ"))
    l11 = l1111l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1llll=os.environ[l1111l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1llll1=os.path.join(l1llll,l11, l111l11)
    l1llll11=os.path.abspath(l1llll1)
    return l1llll11
def l1l11l(l111lll):
    if not os.path.exists(l111lll):
        os.makedirs(l111lll)
def l1l1l1l(l1ll1, l11l, l111l1=None, password=None):
    l1111l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111lll = l1l(l1ll1)
    l1l11l(l111lll)
    if not l111l1:
        l1lllll1 = l11lll()
        l1llllll =l1lllll1.l1llll1l(l1111l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11l + l1111l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11l + l1111l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llllll, str):
            l111l1, password = l1llllll
        else:
            raise l1111l()
        logger.info(l1111l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111lll))
    l111ll = pwd.getpwuid( os.getuid())[0]
    l1l1ll=os.environ[l1111l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l111ll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11={l1111l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111ll, l1111l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1, l1111l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111lll, l1111l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1ll, l1111l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111l1, l1111l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11, temp_file)
        if not os.path.exists(os.path.join(l111ll1, l1111l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l1l11=l1111l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1111l1 (u"ࠧࠨࠤ")
        else:
            l1l1l11=l1111l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1111l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll11ll=l1111l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l1l11,temp_file.name)
        l11l111=[l1111l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1111l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l111ll1, l1ll11ll)]
        p = subprocess.Popen(l11l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1111l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1111l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1111l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111lll
    logger.debug(l1111l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1111l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1111l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1111l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llll11=os.path.abspath(l111lll)
    logger.debug(l1111l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llll11)
    return l1llll11
def l1lll1l1(l1ll1, l11l, l1lll, l1l11l1):
    l1111l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1(title):
        l11llll=30
        if len(title)>l11llll:
            l1l11=title.split(l1111l1 (u"ࠨ࠯ࠣ࠳"))
            l11l11=l1111l1 (u"ࠧࠨ࠴")
            for block in l1l11:
                l11l11+=block+l1111l1 (u"ࠣ࠱ࠥ࠵")
                if len(l11l11) > l11llll:
                    l11l11+=l1111l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l11
        return title
    def l11l1l1(l11l1ll, password):
        l1111l1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1111l1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1111l1 (u"ࠧࠦࠢ࠹").join(l11l1ll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll = l1111l1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll.encode())
        l1ll1l = [l1111l1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l111 = l1111l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l111)
            for e in l1ll1l:
                if e in l111: return False
            raise l11111(l111, l1lll1l1=l1ll111l.l111111(), l11l=l11l)
        logger.info(l1111l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l111l1 = l1111l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1111l1 (u"ࠦࠧ࠿")
    os.system(l1111l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11111l = l1l(l1ll1)
    l111lll = l1l(hashlib.sha1(l1ll1.encode()).hexdigest()[:10])
    l1l11l(l111lll)
    logger.info(l1111l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111lll))
    if l1lll:
        l11l1ll = [l1111l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1111l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1111l1 (u"ࠤ࠰ࡸࠧࡄ"), l1111l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1111l1 (u"ࠫ࠲ࡵࠧࡆ"), l1111l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l111l1, l1lll),
                    urllib.parse.unquote(l11l), os.path.abspath(l111lll)]
        l11l1l1(l11l1ll, password)
    else:
        while True:
            l111l1, password = l1lllll(l111lll, l11l, l1l11l1)
            if l111l1.lower() != l1111l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l1ll = [l1111l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1111l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1111l1 (u"ࠤ࠰ࡸࠧࡋ"), l1111l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1111l1 (u"ࠫ࠲ࡵࠧࡍ"), l1111l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l111l1,
                            urllib.parse.unquote(l11l), os.path.abspath(l111lll)]
            else:
                raise l1111l()
            if l11l1l1(l11l1ll, password): break
    os.system(l1111l1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111lll, l11111l))
    l1llll11=os.path.abspath(l11111l)
    return l1llll11
def l1lllll(l1ll1, l11l, l1l11l1):
    l1ll1l1l = os.path.join(os.environ[l1111l1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1111l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1111l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll1l1l)):
       os.makedirs(os.path.dirname(l1ll1l1l))
    l11ll1 = l1l11l1.get_value(l1111l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1111l1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1lllll1 = l11lll(l1ll1, l11ll1)
    l111l1, password = l1lllll1.l1llll1l(l1111l1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11l + l1111l1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11l + l1111l1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l111l1 != l1111l1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l1ll1(l1ll1, l111l1):
        l1lll1ll = l1111l1 (u"ࠤ࡙ࠣࠦ").join([l1ll1, l111l1, l1111l1 (u"࡚ࠪࠦࠬ") + password + l1111l1 (u"࡛ࠫࠧ࠭"), l1111l1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll1l1l, l1111l1 (u"࠭ࡷࠬࠩ࡝")) as l1ll111:
            l1ll111.write(l1lll1ll)
        os.chmod(l1ll1l1l, 0o600)
    return l111l1, password
def l1l1ll1(l1ll1, l111l1):
    l1ll1l1l = l11l1l = os.path.join(os.environ[l1111l1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1111l1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1111l1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll1l1l):
        with open(l1ll1l1l, l1111l1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11ll11 = data[0].split(l1111l1 (u"ࠦࠥࠨࡢ"))
            if l1ll1 == l11ll11[0] and l111l1 == l11ll11[1]:
                return True
    return False