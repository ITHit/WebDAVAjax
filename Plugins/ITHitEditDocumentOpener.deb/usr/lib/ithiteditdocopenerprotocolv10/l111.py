#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l = 2048
l1lll11l = 7
def l11lll1 (l1ll1l1):
    global l1lll1
    l1111l = ord (l1ll1l1 [-1])
    l11111l = l1ll1l1 [:-1]
    l1l11l1 = l1111l % len (l11111l)
    l11l1l1 = l11111l [:l1l11l1] + l11111l [l1l11l1:]
    if l1l11l:
        l11ll = l1l111l () .join ([unichr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    return eval (l11ll)
import gi
gi.require_version(l11lll1 (u"ࠨࡉࡷ࡯ࠬঽ"), l11lll1 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11lll11
import logging
logger = logging.getLogger(l11lll1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l11(Gtk.Window):
    def __init__(self, l1l1ll1lll, l1l1lll11l):
        Gtk.Window.__init__(self)
        self.l1111ll=30
        self.l1ll11l111 = False
        self.service = l1l1ll1lll
        self.l111ll=l1l1lll11l
        self.l1lll1l=l11lll11.l1l1llll
        self.l1l1l1l1ll = Gtk.ListStore(str)
        self.l1ll1l11ll()
    def l1l1l1l1l1(self, service):
        l1ll1l1l11 = self.l1lll1l.l11ll1ll(l11lll1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll1l1l11
    def l1ll1l11ll(self, l1l1ll1lll=None):
        if l1l1ll1lll:
            self.l1l1l1l1ll.clear()
            l1ll111l1l=self.l1l1l1l1l1(l1l1ll1lll)
            self.l1l1l1l1ll.append([l11lll1 (u"ࠧࠨু")])
            for l111ll in l1ll111l1l:
                self.l1l1l1l1ll.append([l111ll])
        else:
            self.l1l1l1l1ll.clear()
            self.l1l1l1l1ll.append([l11lll1 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll11lll1(self, widget, data=None):
        l1l1l1lll1= widget.get_active()
        if data == l11lll1 (u"ࠢ࠲ࠤৃ") and l1l1l1lll1:
            self.l1ll1l11ll()
            self.l1l11ll1l1.set_active(0)
            self.l1ll1111ll.set_text(l11lll1 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1ll1111ll.set_sensitive(False)
            self.l1l11ll1l1.set_sensitive(False)
        else:
            self.l1ll1l11ll(l1l1ll1lll=self.service)
            self.l1l11ll1l1.set_active(0)
            self.l1ll1111ll.set_text(l11lll1 (u"ࠤࠥ৅"))
            self.l1l11ll1l1.set_sensitive(True)
            self.l1ll1111ll.set_sensitive(True)
    def l1ll11ll11(self, widget):
        if widget.get_active():
            l111ll = widget.get_child().get_text()
        else:
            l111ll = self.l1l1l1l1ll[widget.get_active()][0]
        password = self.l1l1ll111l(self.service, l111ll)
        if password:
            self.l1ll1111ll.set_text(password)
        else:
            self.l1ll1111ll.set_text(l11lll1 (u"ࠥࠦ৆"))
    def l1l1ll11l1(self, l111ll, pwd, service):
        keyring.set_password(service, l111ll, pwd)
        l1ll1l1l11=self.l1lll1l.l11ll1ll(l11lll1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l111ll in l1ll1l1l11:
            value = self.l1lll1l.get_value(l11lll1 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1lll1l.l1l11111(l11lll1 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l11lll1 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l111ll))
    def l1l1ll111l(self, service, l111ll):
        l1l11l1ll1 = keyring.get_password(service, l111ll)
        return l1l11l1ll1
    def l1l1ll1l1l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1l1ll11(self, widget, data=None):
        self.l1ll11l111=widget.get_active()
    def l1l1l(self, message, title=l11lll1 (u"ࠨࠩো"), l1ll1lll1=True):
        if l1ll1lll1:
            l1l1llll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l11lll1l = Gtk.MessageDialog(self,
            l1l1llll11,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l11lll1l.set_title(title)
        l1l11lll1l.set_default_response(Gtk.ResponseType.OK)
        l1ll11ll1l = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l11l11 = Gtk.VBox()
        l1ll1ll11l = Gtk.Box(spacing=1)
        l1ll1ll11l.set_homogeneous(False)
        l1l11ll111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11ll111.set_homogeneous(False)
        l1l11l1l1l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l1l1l.set_homogeneous(False)
        l1ll1ll11l.pack_start(l1l11ll111, True, True, 0)
        l1ll1ll11l.pack_start(l1l11l1l1l, True, True, 0)
        l1ll111ll1 = l1l11lll1l.get_content_area()
        l1l1ll1ll1 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll111ll1.pack_start(l1l1ll1ll1, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l1ll1l = Gtk.Label()
        l1l11l1lll = Gtk.Label()
        l1l11l1lll.set_text(l11lll1 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l11l1lll, True, True, 0)
        l1l1l1ll1l.set_text(l11lll1 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1l1ll1l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l1ll1l, 0, 1, 0, 1)
        l1l11ll1ll = Gtk.RadioButton.new_with_label_from_widget(None, l11lll1 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l11ll1ll.connect(l11lll1 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll11lll1, l11lll1 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l11ll1ll, 1, 2, 0, 1)
        l1l1l1111l = Gtk.RadioButton.new_with_label_from_widget(l1l11ll1ll, l11lll1 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1l1111l.connect(l11lll1 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll11lll1, l11lll1 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1l1111l, 1, 2, 1, 2)
        l1ll11l1ll = Gtk.Label()
        l1ll11l1ll.set_text(l11lll1 (u"ࠥࠤࠧ৔"))
        table.attach(l1ll11l1ll, 0, 1, 4, 6)
        l1l1l11lll = Gtk.Label()
        l1l1l11lll.set_text(l11lll1 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l1l11lll.set_justify(Gtk.Justification.RIGHT)
        l1l1l11lll.set_alignment(xalign=1, yalign=0.5)
        self.l1l11ll1l1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1l1l1ll)
        self.l1l11ll1l1.set_entry_text_column(0)
        table.attach(l1l1l11lll, 0, 1, 6, 8)
        table.attach(self.l1l11ll1l1, 1, 3, 6, 8)
        self.l1l11ll1l1.connect(l11lll1 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1ll11ll11)
        l1ll11l1l1 = Gtk.Label()
        l1ll11l1l1.set_text(l11lll1 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll11l1l1.set_justify(Gtk.Justification.RIGHT)
        l1ll11l1l1.set_alignment(xalign=1, yalign=0.5)
        self.l1ll1111ll = Gtk.Entry()
        self.l1ll1111ll.set_visibility(False)
        self.l1ll1111ll.connect(l11lll1 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1ll1l1l, l1l11lll1l)
        table.attach(l1ll11l1l1, 0, 1, 8, 10)
        table.attach(self.l1ll1111ll, 1, 3, 8, 10)
        l1ll111111 = Gtk.CheckButton(l11lll1 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1ll111111.connect(l11lll1 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1l1ll11, l1ll111111)
        l1ll111111.set_active(False)
        table.attach(l1ll111111, 1, 3, 12, 14)
        l1l1llllll = Gtk.Label()
        l1l1llllll.set_text(l11lll1 (u"ࠥࠤࠧ৛") * 5)
        l1l1l11l11.pack_start(l1l1llllll, True, True, 0)
        if self.l111ll:
            l1l1l1111l.set_active(True)
            self.l1l11ll1l1.set_active(0)
            self.l1l11ll1l1.set_sensitive(True)
            self.l1ll1111ll.set_text(l11lll1 (u"ࠦࠧড়"))
            self.l1ll1111ll.set_sensitive(True)
        else:
            self.l1l11ll1l1.set_active(0)
            self.l1l11ll1l1.set_sensitive(False)
            self.l1ll1111ll.set_text(l11lll1 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1ll1111ll.set_sensitive(False)
        l1ll11ll1l.pack_start(vbox, True, True, 0)
        l1ll11ll1l.pack_start(table, True, True, 0)
        l1ll11ll1l.pack_end(l1l1l11l11, True, True, 0)
        l1l1ll1ll1.pack_start(l1ll11ll1l, True, True, 0)
        l1l11lll1l.show_all()
        response = l1l11lll1l.run()
        if self.l1l11ll1l1.get_active():
            l111ll = self.l1l11ll1l1.get_child().get_text()
        else:
            l111ll = self.l1l1l1l1ll[self.l1l11ll1l1.get_active()][0]
        pwd = self.l1ll1111ll.get_text()
        l1l11lll1l.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll11l111:
                self.l1l1ll11l1(l111ll, pwd, self.service)
            return l111ll, pwd
        else:
            return l11lll1 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l11lll1 (u"ࠧࠨয়")
class l1l111l1l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1ll1l11(self, l1l111l1):
        l1l1l11111 = Gtk.ScrolledWindow()
        l1l1l11111.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll1ll1ll=None
        self.l1l1ll11ll = Gtk.TextBuffer()
        self.l1l1ll11ll.set_text(l1l111l1)
        self.set_style()
        regexp= l11lll1 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll1lll1l = self._1ll111lll(l1l111l1, regexp)
        self.l1l11lllll(l1ll1lll1l, self.l1l1ll11ll.get_start_iter())
        self.l1ll11llll = Gtk.TextView(buffer=self.l1l1ll11ll)
        self.l1ll11llll.set_property(l11lll1 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1ll11llll.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1ll11llll.connect(l11lll1 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1ll1l11l1)
        self.l1ll11llll.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1l11111.set_size_request(300,100)
        self.l1ll11llll.show()
        l1l1l11111.add(self.l1ll11llll)
        l1l1l11111.show()
        return l1l1l11111
    def _1ll1l11l1(self, *args, **kwargs):
        l1ll1ll111, l1l11lll11=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll1ll111, l1l11lll11).get_tags()
        if not self.l1ll1ll1ll:
            self.l1ll1ll1ll = args[1].window.get_cursor()
            self.l1ll11l11l = Gdk.Cursor(Gdk.CursorType.l1l1l111ll)
        elif tag:
            args[1].window.set_cursor(self.l1ll11l11l)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll1ll1ll:
                args[1].window.set_cursor(self.l1ll1ll1ll)
    def _1ll111lll(self, l1l111l1, l1l1lll1ll):
        res=[]
        l1l1l11ll1=re.findall(l1l1lll1ll,l1l111l1)
        for l1ll11111l in l1l1l11ll1:
            for el in l1ll11111l:
                if el:
                    res.append(el)
        return res
    def l1l11lllll(self, l1ll1lll1l, start):
        l1l1l1llll=0
        for text in l1ll1lll1l:
            end = self.l1l1ll11ll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l1llll+=1
                l1ll1lllll, l1ll1lll11 = match
                tag = self.l1l1ll11ll.create_tag(str(l1l1l1llll), foreground=l11lll1 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l11lll1 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1lll111, text)
                self.l1l1ll11ll.apply_tag(tag, l1ll1lllll, l1ll1lll11)
                self.l1l11lllll(l1ll1lll1l, l1ll1lll11)
    def _1l1lll111(self, tag, widget, l1ll1l1l1l, _1l11l1l11, text):
        _1l1l11l1l = l1ll1l1l1l.type
        _1ll1l1lll = l1ll1l1l1l.window
        if _1l1l11l1l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l11l1l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll1l1l1l.button
            self.l1ll1ll1ll = Gdk.Cursor(Gdk.CursorType.l1l1l111ll)
            if _1l1l11l1l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l11lll1 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1l11l111(self, message, title=l11lll1 (u"ࠧࠨ০"), l1ll1lll1=True, l1l11ll11l=None):
        if l1ll1lll1:
            l1l1llll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1llll11,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1l11ll11l:
            l1ll111ll1 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1ll11l = Gtk.HBox(spacing=0)
            l1l1llll1l = Gtk.HBox(spacing=5)
            l1ll1l1111 = Gtk.Label()
            l1ll1l1111.set_markup(l11lll1 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll1l1111.set_line_wrap(True)
            l1ll1l1111.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l11lll1 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1ll1l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1ll1l1.show()
            l1ll1llll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1llll1.show()
            l1ll1111l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1111l1.show()
            l1ll1ll11l.pack_start(separator, True, True, 0)
            l1ll1ll11l.pack_start(l1ll1ll1l1, True, True, 0)
            l1ll1ll11l.pack_start(l1ll1llll1, True, True, 0)
            l1ll1ll11l.pack_start(l1ll1111l1, True, True, 0)
            l1ll1ll11l.pack_start(l1ll1l1111, False, True, 0)
            l1l11llll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11llll1.show()
            l1ll1ll11l.pack_end(l1l11llll1, True, True, 0)
            l1l1l1l111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1l111.show()
            vbox.pack_start(l1ll1ll11l, True, True, 0)
            l1l1l11111=self.__1l1ll1l11(l1l111l1=l1l11ll11l)
            vbox.pack_start(l1l1l11111, False, False, 0)
            vbox.pack_end(l1l1l1l111, False, False, 0)
            l1l1llll1l.pack_start(vbox, True, True,5)
            l1l1llll1l.show()
            l1ll111ll1.pack_end(l1l1llll1l, False, False, 0)
            vbox.show()
            l1ll1ll11l.show()
        window.run()
class l11lllll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l1l111l1(self, widget, l1l1ll1111):
        if l1l1ll1111 == Gtk.ResponseType.OK:
            self.result = l11lll1 (u"ࠥࡓࡐࠨ৩")
        elif l1l1ll1111 == Gtk.ResponseType.CANCEL:
            self.result = l11lll1 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1ll1111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l11lll1 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l1l111l11(self, title=l11lll1 (u"ࠨࠢ৬"), message=l11lll1 (u"ࠢࠣ৭") , l1ll1lll1=True):
        if l1ll1lll1:
            l1l1llll11 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1llll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l11lll1 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l1l111l1)
        window.run()
class l1ll111l11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1l1ll1=None
        self.result = None
    def l1l1l111l1(self, widget, l1l1ll1111):
        print(widget, l1l1ll1111)
        if l1l1ll1111 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1ll1111 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1ll1111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1l1ll11(self, widget, l1l1lll1l1):
        if l1l1lll1l1.get_active():
            self.l1ll1l1ll1 = 1
        else:
            self.l1ll1l1ll1 = 0
    def l1l1lllll1(self, title=l11lll1 (u"ࠤࠥ৯"), message=l11lll1 (u"ࠥࠦৰ"), l1ll1l111l =l11lll1 (u"ࠦࠧৱ"),l1ll1lll1=True):
        if l1ll1lll1:
            l1l1llll11= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1llll11 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1llll11,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l11lll1 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l1l111l1)
        l1ll111111 = Gtk.CheckButton(l1ll1l111l)
        l1ll111111.connect(l11lll1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1l1ll11, l1ll111111)
        l1ll111111.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1ll111111, expand=True, fill=True, padding=0)
        l1ll111111.show()
        window.run()
def l1ll111l1(title, msg, l1ll1l111l=l11lll1 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1ll1lll1=True):
    result=None
    try:
        l1l1l1l11l = l1ll111l11()
        l1l1l1l11l.l1l1lllll1(title, msg, l1ll1l111l, l1ll1lll1)
        result = {l11lll1 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1l1l11l.result,  l11lll1 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1l1l11l.l1ll1l1ll1}
    except Exception as e:
        logger.exception(l11lll1 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l11lll1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l1111l111 = l1l111l1l()
    message= l11lll1 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l11l11ll = l11lll1 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l1111l111.l1l11l111(message, l11lll1 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1ll1lll1=True, l1l11ll11l=l1l11l11ll)