#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111lll = 2048
l1lll11 = 7
def l1l1l11 (l1l11):
    global l111l
    l1ll1l11 = ord (l1l11 [-1])
    l11l = l1l11 [:-1]
    l1lll = l1ll1l11 % len (l11l)
    l1lll11l = l11l [:l1lll] + l11l [l1lll:]
    if l1ll1l:
        l11ll1l = l1llll1l () .join ([unichr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    return eval (l11ll1l)
import hashlib
import os
import l1l1ll
from l11ll11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1ll import l1lll1ll
from l1111ll import l1lllll1, l1lll1l
import logging
logger = logging.getLogger(l1l1l11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1111l1():
    def __init__(self, l1l1111,l1ll1ll1, l11l1l1= None, l11lll1=None):
        self.l1lll1l1=False
        self.l1l1lll = self._11llll()
        self.l1ll1ll1 = l1ll1ll1
        self.l11l1l1 = l11l1l1
        self.l1ll1l1l = l1l1111
        if l11l1l1:
            self.l1l1 = True
        else:
            self.l1l1 = False
        self.l11lll1 = l11lll1
    def _11llll(self):
        try:
            return l1l1ll.l1l11ll() is not None
        except:
            return False
    def open(self):
        l1l1l11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1lll:
            raise NotImplementedError(l1l1l11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l1l11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11l11l = self.l1ll1l1l
        if self.l1ll1ll1.lower().startswith(self.l1ll1l1l.lower()):
            l11111 = re.compile(re.escape(self.l1ll1l1l), re.IGNORECASE)
            l1ll1ll1 = l11111.sub(l1l1l11 (u"ࠨࠩࠄ"), self.l1ll1ll1)
            l1ll1ll1 = l1ll1ll1.replace(l1l1l11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l1l11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll(self.l1ll1l1l, l11l11l, l1ll1ll1, self.l11l1l1)
    def l11ll(self,l1ll1l1l, l11l11l, l1ll1ll1, l11l1l1):
        l1l1l11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l1l11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1ll1 = l1111(l1ll1l1l)
        ll = self.l111l1l(l1l1ll1)
        logger.info(l1l1l11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1ll1)
        if ll:
            logger.info(l1l1l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll1ll(l1l1ll1)
            l1l1ll1 = l1ll1(l1ll1l1l, l11l11l, l11l1l1, self.l11lll1)
        logger.debug(l1l1l11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1l=l1l1ll1 + l1l1l11 (u"ࠤ࠲ࠦࠌ") + l1ll1ll1
        l1llllll = l1l1l11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1l+ l1l1l11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1llllll)
        l1ll11 = os.system(l1llllll)
        if (l1ll11 != 0):
            raise IOError(l1l1l11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1l, l1ll11))
    def l111l1l(self, l1l1ll1):
        if os.path.exists(l1l1ll1):
            if os.path.islink(l1l1ll1):
                l1l1ll1 = os.readlink(l1l1ll1)
            if os.path.ismount(l1l1ll1):
                return True
        return False
def l1111(l1ll1l1l):
    l1l111l = l1ll1l1l.replace(l1l1l11 (u"࠭࡜࡝ࠩࠐ"), l1l1l11 (u"ࠧࡠࠩࠑ")).replace(l1l1l11 (u"ࠨ࠱ࠪࠒ"), l1l1l11 (u"ࠩࡢࠫࠓ"))
    l11111l = l1l1l11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll=os.environ[l1l1l11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll1=os.path.join(l1ll,l11111l, l1l111l)
    l1ll11l=os.path.abspath(l11ll1)
    return l1ll11l
def l11lll(l1llll):
    if not os.path.exists(l1llll):
        os.makedirs(l1llll)
def l1lll1(l1ll1l1l, l11l11l, l1l1l1l=None, password=None):
    l1l1l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1llll = l1111(l1ll1l1l)
    l11lll(l1llll)
    if not l1l1l1l:
        l11l11 = l11l1l()
        l1l11l1 =l11l11.l111111(l1l1l11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11l11l + l1l1l11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11l11l + l1l1l11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l11l1, str):
            l1l1l1l, password = l1l11l1
        else:
            raise l1lll1l()
        logger.info(l1l1l11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1llll))
    l1lll111 = pwd.getpwuid( os.getuid())[0]
    l111l11=os.environ[l1l1l11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l111=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l1={l1l1l11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lll111, l1l1l11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1l1l, l1l1l11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1llll, l1l1l11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l111l11, l1l1l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l1l1l, l1l1l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l1, temp_file)
        if not os.path.exists(os.path.join(l11l111, l1l1l11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l=l1l1l11 (u"ࠦࡵࡿࠢࠣ")
            key=l1l1l11 (u"ࠧࠨࠤ")
        else:
            l1l=l1l1l11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l1l11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111l1=l1l1l11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l,temp_file.name)
        l1ll11ll=[l1l1l11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l1l11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l111, l111l1)]
        p = subprocess.Popen(l1ll11ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l1l11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l1l11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l1l11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1llll
    logger.debug(l1l1l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l1l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l1l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l1l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11l=os.path.abspath(l1llll)
    logger.debug(l1l1l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11l)
    return l1ll11l
def l1ll1(l1ll1l1l, l11l11l, l11l1l1, l11lll1):
    l1l1l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l11l(title):
        l1lllll=30
        if len(title)>l1lllll:
            l1111l=title.split(l1l1l11 (u"ࠨ࠯ࠣ࠳"))
            l111ll=l1l1l11 (u"ࠧࠨ࠴")
            for block in l1111l:
                l111ll+=block+l1l1l11 (u"ࠣ࠱ࠥ࠵")
                if len(l111ll) > l1lllll:
                    l111ll+=l1l1l11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111ll
        return title
    l1l1l1l = l1l1l11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1l1l11 (u"ࠦࠧ࠸")
    os.system(l1l1l11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l11l1ll = l1111(l1ll1l1l)
    l1llll = l1111(hashlib.sha1(l1ll1l1l.encode()).hexdigest()[:10])
    l11lll(l1llll)
    logger.info(l1l1l11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1llll))
    if l11l1l1:
        l111ll1 = [l1l1l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1l1l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1l1l11 (u"ࠤ࠰ࡸࠧ࠽"), l1l1l11 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1l1l11 (u"ࠫ࠲ࡵࠧ࠿"), l1l1l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1l1l1l, l11l1l1),
                    urllib.parse.unquote(l11l11l), os.path.abspath(l1llll)]
    else:
        l1l1l1l, password = l1(l1llll, l11l11l, l11lll1)
        if l1l1l1l.lower() != l1l1l11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l111ll1 = [l1l1l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l1l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l1l11 (u"ࠤ࠰ࡸࠧࡄ"), l1l1l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l1l11 (u"ࠫ࠲ࡵࠧࡆ"), l1l1l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1l1l1l,
                        urllib.parse.unquote(l11l11l), os.path.abspath(l1llll)]
        else:
            raise l1lll1l()
    logger.info(l1l1l11 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1l1l11 (u"ࠢࠡࠤࡉ").join(l111ll1)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11 = l1l1l11 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11.encode())
    if len(err) > 0:
        l1ll1ll = l1l1l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1ll1ll)
        raise l1lllll1(l1ll1ll, l1ll1=l1l1ll.l1l11ll(), l11l11l=l11l11l)
    logger.info(l1l1l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1l1l11 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1llll, l11l1ll))
    l1ll11l=os.path.abspath(l11l1ll)
    return l1ll11l
def l1(l1ll1l1l, l11l11l, l11lll1):
    l1ll1lll = os.path.join(os.environ[l1l1l11 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1l1l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1l1l11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l1ll1lll)):
       os.makedirs(os.path.dirname(l1ll1lll))
    l1ll1l1 = l11lll1.get_value(l1l1l11 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1l1l11 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l11l11 = l11l1l(l1ll1l1l, l1ll1l1)
    l1l1l1l, password = l11l11.l111111(l1l1l11 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11l11l + l1l1l11 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11l11l + l1l1l11 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1l1l1l != l1l1l11 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1l1l1(l1ll1l1l, l1l1l1l):
        l1ll11l1 = l1l1l11 (u"ࠢࠡࠤࡗ").join([l1ll1l1l, l1l1l1l, l1l1l11 (u"ࠨࠤࠪࡘ") + password + l1l1l11 (u"࡙ࠩࠥࠫ"), l1l1l11 (u"ࠪࡠࡳ࡚࠭")])
        with open(l1ll1lll, l1l1l11 (u"ࠫࡼ࠱࡛ࠧ")) as l1l111:
            l1l111.write(l1ll11l1)
        os.chmod(l1ll1lll, 0o600)
    return l1l1l1l, password
def l1l1l1(l1ll1l1l, l1l1l1l):
    l1ll1lll = l1llll1 = os.path.join(os.environ[l1l1l11 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1l1l11 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1l1l11 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l1ll1lll):
        with open(l1ll1lll, l1l1l11 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1llll11 = data[0].split(l1l1l11 (u"ࠤࠣࠦࡠ"))
            if l1ll1l1l == l1llll11[0] and l1l1l1l == l1llll11[1]:
                return True
    return False