#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l = 2048
l1lll11l = 7
def l11lll1 (l1ll1l1):
    global l1lll1
    l1111l = ord (l1ll1l1 [-1])
    l11111l = l1ll1l1 [:-1]
    l1l11l1 = l1111l % len (l11111l)
    l11l1l1 = l11111l [:l1l11l1] + l11111l [l1l11l1:]
    if l1l11l:
        l11ll = l1l111l () .join ([unichr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    return eval (l11ll)
import hashlib
import os
import l1111l1
from l111 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1111l1 import l111l11
from l1lll111 import l11l111, l111ll1
import logging
logger = logging.getLogger(l11lll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l1l():
    def __init__(self, l1l1,l1ll111, l1l1l1l= None, l1lll1l=None):
        self.l1l1l1=False
        self.l111111 = self._11l1()
        self.l1ll111 = l1ll111
        self.l1l1l1l = l1l1l1l
        self.l1llllll = l1l1
        if l1l1l1l:
            self.l1l1l11 = True
        else:
            self.l1l1l11 = False
        self.l1lll1l = l1lll1l
    def _11l1(self):
        try:
            return l1111l1.l1l11ll() is not None
        except:
            return False
    def open(self):
        l11lll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l111111:
            raise NotImplementedError(l11lll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11lll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11llll = self.l1llllll
        if self.l1ll111.lower().startswith(self.l1llllll.lower()):
            l1lll11 = re.compile(re.escape(self.l1llllll), re.IGNORECASE)
            l1ll111 = l1lll11.sub(l11lll1 (u"ࠨࠩࠄ"), self.l1ll111)
            l1ll111 = l1ll111.replace(l11lll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11lll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1ll(self.l1llllll, l11llll, l1ll111, self.l1l1l1l)
    def l1l1ll(self,l1llllll, l11llll, l1ll111, l1l1l1l):
        l11lll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11lll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1ll1 = l11l(l1llllll)
        l111l = self.l1llll11(l1l1ll1)
        logger.info(l11lll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1ll1)
        if l111l:
            logger.info(l11lll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111l11(l1l1ll1)
            l1l1ll1 = l1l1lll(l1llllll, l11llll, l1l1l1l, self.l1lll1l)
        logger.debug(l11lll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11111=l1l1ll1 + l11lll1 (u"ࠤ࠲ࠦࠌ") + l1ll111
        l1ll1l = l11lll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11111+ l11lll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1l)
        l11l1ll = os.system(l1ll1l)
        if (l11l1ll != 0):
            raise IOError(l11lll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11111, l11l1ll))
    def l1llll11(self, l1l1ll1):
        if os.path.exists(l1l1ll1):
            if os.path.islink(l1l1ll1):
                l1l1ll1 = os.readlink(l1l1ll1)
            if os.path.ismount(l1l1ll1):
                return True
        return False
def l11l(l1llllll):
    l1ll = l1llllll.replace(l11lll1 (u"࠭࡜࡝ࠩࠐ"), l11lll1 (u"ࠧࡠࠩࠑ")).replace(l11lll1 (u"ࠨ࠱ࠪࠒ"), l11lll1 (u"ࠩࡢࠫࠓ"))
    l1ll1l1l = l11lll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111l1=os.environ[l11lll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    ll=os.path.join(l111l1,l1ll1l1l, l1ll)
    l1ll11ll=os.path.abspath(ll)
    return l1ll11ll
def l1l11(l111l1l):
    if not os.path.exists(l111l1l):
        os.makedirs(l111l1l)
def l1ll1ll1(l1llllll, l11llll, l111ll=None, password=None):
    l11lll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111l1l = l11l(l1llllll)
    l1l11(l111l1l)
    if not l111ll:
        l1llll1 = l11()
        l111lll =l1llll1.l1l1l(l11lll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11llll + l11lll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11llll + l11lll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l111lll, str):
            l111ll, password = l111lll
        else:
            raise l111ll1()
        logger.info(l11lll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111l1l))
    l1ll1111 = pwd.getpwuid( os.getuid())[0]
    l1ll11l=os.environ[l11lll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll1={l11lll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1111, l11lll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1llllll, l11lll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111l1l, l11lll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11l, l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111ll, l11lll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll1, temp_file)
        if not os.path.exists(os.path.join(l1lll, l11lll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll1ll=l11lll1 (u"ࠦࡵࡿࠢࠣ")
            key=l11lll1 (u"ࠧࠨࠤ")
        else:
            l1lll1ll=l11lll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11lll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1111=l11lll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll1ll,temp_file.name)
        l1ll11=[l11lll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11lll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll, l1111)]
        p = subprocess.Popen(l1ll11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11lll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11lll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11lll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111l1l
    logger.debug(l11lll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11lll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11lll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11lll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11ll=os.path.abspath(l111l1l)
    logger.debug(l11lll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11ll)
    return l1ll11ll
def l1l1lll(l1llllll, l11llll, l1l1l1l, l1lll1l):
    l11lll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11ll1l(title):
        l1111ll=30
        if len(title)>l1111ll:
            l1=title.split(l11lll1 (u"ࠨ࠯ࠣ࠳"))
            l11lll=l11lll1 (u"ࠧࠨ࠴")
            for block in l1:
                l11lll+=block+l11lll1 (u"ࠣ࠱ࠥ࠵")
                if len(l11lll) > l1111ll:
                    l11lll+=l11lll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11lll
        return title
    def l11ll1(l11l11, password):
        l11lll1 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11lll1 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11lll1 (u"ࠧࠦࠢ࠹").join(l11l11)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11ll11 = l11lll1 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11ll11.encode())
        l11l11l = [l11lll1 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll1l11 = l11lll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll1l11)
            for e in l11l11l:
                if e in l1ll1l11: return False
            raise l11l111(l1ll1l11, l1l1lll=l1111l1.l1l11ll(), l11llll=l11llll)
        logger.info(l11lll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l111ll = l11lll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11lll1 (u"ࠦࠧ࠿")
    os.system(l11lll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1llll1l = l11l(l1llllll)
    l111l1l = l11l(hashlib.sha1(l1llllll.encode()).hexdigest()[:10])
    l1l11(l111l1l)
    logger.info(l11lll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111l1l))
    if l1l1l1l:
        l11l11 = [l11lll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11lll1 (u"ࠤ࠰ࡸࠧࡄ"), l11lll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11lll1 (u"ࠫ࠲ࡵࠧࡆ"), l11lll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l111ll, l1l1l1l),
                    urllib.parse.unquote(l11llll), os.path.abspath(l111l1l)]
        l11ll1(l11l11, password)
    else:
        while True:
            l111ll, password = l1lllll1(l111l1l, l11llll, l1lll1l)
            if l111ll.lower() != l11lll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l11 = [l11lll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11lll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11lll1 (u"ࠤ࠰ࡸࠧࡋ"), l11lll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11lll1 (u"ࠫ࠲ࡵࠧࡍ"), l11lll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l111ll,
                            urllib.parse.unquote(l11llll), os.path.abspath(l111l1l)]
            else:
                raise l111ll1()
            if l11ll1(l11l11, password): break
    os.system(l11lll1 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111l1l, l1llll1l))
    l1ll11ll=os.path.abspath(l1llll1l)
    return l1ll11ll
def l1lllll1(l1llllll, l11llll, l1lll1l):
    l1ll111l = os.path.join(os.environ[l11lll1 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11lll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11lll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1ll111l)):
       os.makedirs(os.path.dirname(l1ll111l))
    l1l1111 = l1lll1l.get_value(l11lll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11lll1 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1llll1 = l11(l1llllll, l1l1111)
    l111ll, password = l1llll1.l1l1l(l11lll1 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11llll + l11lll1 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11llll + l11lll1 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l111ll != l11lll1 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll1lll(l1llllll, l111ll):
        l1l111 = l11lll1 (u"ࠤ࡙ࠣࠦ").join([l1llllll, l111ll, l11lll1 (u"࡚ࠪࠦࠬ") + password + l11lll1 (u"࡛ࠫࠧ࠭"), l11lll1 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1ll111l, l11lll1 (u"࠭ࡷࠬࠩ࡝")) as l1lllll:
            l1lllll.write(l1l111)
        os.chmod(l1ll111l, 0o600)
    return l111ll, password
def l1ll1lll(l1llllll, l111ll):
    l1ll111l = l1lll1l1 = os.path.join(os.environ[l11lll1 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11lll1 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11lll1 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1ll111l):
        with open(l1ll111l, l11lll1 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll11l1 = data[0].split(l11lll1 (u"ࠦࠥࠨࡢ"))
            if l1llllll == l1ll11l1[0] and l111ll == l1ll11l1[1]:
                return True
    return False