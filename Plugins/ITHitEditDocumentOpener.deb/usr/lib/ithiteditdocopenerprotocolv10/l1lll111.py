#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l = sys.version_info [0] == 2
ll = 2048
l1 = 7
def l1111l1 (l1ll1lll):
    global l1ll1l1
    l1111 = ord (l1ll1lll [-1])
    l1l1lll = l1ll1lll [:-1]
    l11l1 = l1111 % len (l1l1lll)
    l1l1111 = l1l1lll [:l11l1] + l1l1lll [l11l1:]
    if l1lll1l:
        l1ll1ll1 = l1l1l () .join ([unichr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    else:
        l1ll1ll1 = str () .join ([chr (ord (char) - ll - (l1111ll + l1111) % l1) for l1111ll, char in enumerate (l1l1111)])
    return eval (l1ll1ll1)
import gi
gi.require_version(l1111l1 (u"ࠨࡉࡷ࡯ࠬঽ"), l1111l1 (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11lll11
import logging
logger = logging.getLogger(l1111l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l11lll(Gtk.Window):
    def __init__(self, l1l1l1ll11, l1ll111ll1):
        Gtk.Window.__init__(self)
        self.l11llll=30
        self.l1l1llll11 = False
        self.service = l1l1l1ll11
        self.l111l1=l1ll111ll1
        self.l1l11l1=l11lll11.l11ll1l1
        self.l1l11ll1ll = Gtk.ListStore(str)
        self.l1ll11l11l()
    def l1l1lll1l1(self, service):
        l1ll1lll1l = self.l1l11l1.l1l1llll(l1111l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1ll1lll1l
    def l1ll11l11l(self, l1l1l1ll11=None):
        if l1l1l1ll11:
            self.l1l11ll1ll.clear()
            l1ll1l1l1l=self.l1l1lll1l1(l1l1l1ll11)
            self.l1l11ll1ll.append([l1111l1 (u"ࠧࠨু")])
            for l111l1 in l1ll1l1l1l:
                self.l1l11ll1ll.append([l111l1])
        else:
            self.l1l11ll1ll.clear()
            self.l1l11ll1ll.append([l1111l1 (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1ll111111(self, widget, data=None):
        l1ll1lllll= widget.get_active()
        if data == l1111l1 (u"ࠢ࠲ࠤৃ") and l1ll1lllll:
            self.l1ll11l11l()
            self.l1l1l11ll1.set_active(0)
            self.l1l1l11lll.set_text(l1111l1 (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l11lll.set_sensitive(False)
            self.l1l1l11ll1.set_sensitive(False)
        else:
            self.l1ll11l11l(l1l1l1ll11=self.service)
            self.l1l1l11ll1.set_active(0)
            self.l1l1l11lll.set_text(l1111l1 (u"ࠤࠥ৅"))
            self.l1l1l11ll1.set_sensitive(True)
            self.l1l1l11lll.set_sensitive(True)
    def l1ll11l1ll(self, widget):
        if widget.get_active():
            l111l1 = widget.get_child().get_text()
        else:
            l111l1 = self.l1l11ll1ll[widget.get_active()][0]
        password = self.l1ll111lll(self.service, l111l1)
        if password:
            self.l1l1l11lll.set_text(password)
        else:
            self.l1l1l11lll.set_text(l1111l1 (u"ࠥࠦ৆"))
    def l1ll1l1l11(self, l111l1, pwd, service):
        keyring.set_password(service, l111l1, pwd)
        l1ll1lll1l=self.l1l11l1.l1l1llll(l1111l1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l111l1 in l1ll1lll1l:
            value = self.l1l11l1.get_value(l1111l1 (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l1l11l1.l1l1l11l(l1111l1 (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1111l1 (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l111l1))
    def l1ll111lll(self, service, l111l1):
        l1l1l1lll1 = keyring.get_password(service, l111l1)
        return l1l1l1lll1
    def l1ll1l11l1(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1l1llll(self, widget, data=None):
        self.l1l1llll11=widget.get_active()
    def l1llll1l(self, message, title=l1111l1 (u"ࠨࠩো"), l11l11lll=True):
        if l11l11lll:
            l1ll111l1l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111l1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l11l1lll = Gtk.MessageDialog(self,
            l1ll111l1l,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l11l1lll.set_title(title)
        l1l11l1lll.set_default_response(Gtk.ResponseType.OK)
        l1ll1ll1l1 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l1l1l1 = Gtk.VBox()
        l1ll1111ll = Gtk.Box(spacing=1)
        l1ll1111ll.set_homogeneous(False)
        l1l11l1l1l = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l1l1l.set_homogeneous(False)
        l1ll11lll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll11lll1.set_homogeneous(False)
        l1ll1111ll.pack_start(l1l11l1l1l, True, True, 0)
        l1ll1111ll.pack_start(l1ll11lll1, True, True, 0)
        l1ll11ll11 = l1l11l1lll.get_content_area()
        l1l1lll11l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1ll11ll11.pack_start(l1l1lll11l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1l1l11l = Gtk.Label()
        l1l1l1111l = Gtk.Label()
        l1l1l1111l.set_text(l1111l1 (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1l1111l, True, True, 0)
        l1l1l1l11l.set_text(l1111l1 (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1l1l1l11l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1l1l11l, 0, 1, 0, 1)
        l1l11l1l11 = Gtk.RadioButton.new_with_label_from_widget(None, l1111l1 (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l11l1l11.connect(l1111l1 (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1ll111111, l1111l1 (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l11l1l11, 1, 2, 0, 1)
        l1l1l111l1 = Gtk.RadioButton.new_with_label_from_widget(l1l11l1l11, l1111l1 (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1l1l111l1.connect(l1111l1 (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1ll111111, l1111l1 (u"ࠤ࠵ࠦ৓"))
        table.attach(l1l1l111l1, 1, 2, 1, 2)
        l1l1l111ll = Gtk.Label()
        l1l1l111ll.set_text(l1111l1 (u"ࠥࠤࠧ৔"))
        table.attach(l1l1l111ll, 0, 1, 4, 6)
        l1l11lllll = Gtk.Label()
        l1l11lllll.set_text(l1111l1 (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1l11lllll.set_justify(Gtk.Justification.RIGHT)
        l1l11lllll.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l11ll1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l11ll1ll)
        self.l1l1l11ll1.set_entry_text_column(0)
        table.attach(l1l11lllll, 0, 1, 6, 8)
        table.attach(self.l1l1l11ll1, 1, 3, 6, 8)
        self.l1l1l11ll1.connect(l1111l1 (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1ll11l1ll)
        l1ll1ll111 = Gtk.Label()
        l1ll1ll111.set_text(l1111l1 (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1ll1ll111.set_justify(Gtk.Justification.RIGHT)
        l1ll1ll111.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l11lll = Gtk.Entry()
        self.l1l1l11lll.set_visibility(False)
        self.l1l1l11lll.connect(l1111l1 (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1ll1l11l1, l1l11l1lll)
        table.attach(l1ll1ll111, 0, 1, 8, 10)
        table.attach(self.l1l1l11lll, 1, 3, 8, 10)
        l1l11l11ll = Gtk.CheckButton(l1111l1 (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l11l11ll.connect(l1111l1 (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1l1llll, l1l11l11ll)
        l1l11l11ll.set_active(False)
        table.attach(l1l11l11ll, 1, 3, 12, 14)
        l1l1lll111 = Gtk.Label()
        l1l1lll111.set_text(l1111l1 (u"ࠥࠤࠧ৛") * 5)
        l1l1l1l1l1.pack_start(l1l1lll111, True, True, 0)
        if self.l111l1:
            l1l1l111l1.set_active(True)
            self.l1l1l11ll1.set_active(0)
            self.l1l1l11ll1.set_sensitive(True)
            self.l1l1l11lll.set_text(l1111l1 (u"ࠦࠧড়"))
            self.l1l1l11lll.set_sensitive(True)
        else:
            self.l1l1l11ll1.set_active(0)
            self.l1l1l11ll1.set_sensitive(False)
            self.l1l1l11lll.set_text(l1111l1 (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l11lll.set_sensitive(False)
        l1ll1ll1l1.pack_start(vbox, True, True, 0)
        l1ll1ll1l1.pack_start(table, True, True, 0)
        l1ll1ll1l1.pack_end(l1l1l1l1l1, True, True, 0)
        l1l1lll11l.pack_start(l1ll1ll1l1, True, True, 0)
        l1l11l1lll.show_all()
        response = l1l11l1lll.run()
        if self.l1l1l11ll1.get_active():
            l111l1 = self.l1l1l11ll1.get_child().get_text()
        else:
            l111l1 = self.l1l11ll1ll[self.l1l1l11ll1.get_active()][0]
        pwd = self.l1l1l11lll.get_text()
        l1l11l1lll.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1l1llll11:
                self.l1ll1l1l11(l111l1, pwd, self.service)
            return l111l1, pwd
        else:
            return l1111l1 (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1111l1 (u"ࠧࠨয়")
class l11lll111(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1l1ll1(self, l1l111ll):
        l1l1ll1l1l = Gtk.ScrolledWindow()
        l1l1ll1l1l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1llllll=None
        self.l1l11ll1l1 = Gtk.TextBuffer()
        self.l1l11ll1l1.set_text(l1l111ll)
        self.set_style()
        regexp= l1111l1 (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1l11llll1 = self._1ll1l111l(l1l111ll, regexp)
        self.l1l11lll1l(l1l11llll1, self.l1l11ll1l1.get_start_iter())
        self.l1l1l11111 = Gtk.TextView(buffer=self.l1l11ll1l1)
        self.l1l1l11111.set_property(l1111l1 (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1l11111.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l11111.connect(l1111l1 (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l11ll111)
        self.l1l1l11111.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1ll1l1l.set_size_request(300,100)
        self.l1l1l11111.show()
        l1l1ll1l1l.add(self.l1l1l11111)
        l1l1ll1l1l.show()
        return l1l1ll1l1l
    def _1l11ll111(self, *args, **kwargs):
        l1ll111l11, l1l1l11l1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1ll111l11, l1l1l11l1l).get_tags()
        if not self.l1l1llllll:
            self.l1l1llllll = args[1].window.get_cursor()
            self.l1l1lllll1 = Gdk.Cursor(Gdk.CursorType.l1l1llll1l)
        elif tag:
            args[1].window.set_cursor(self.l1l1lllll1)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1llllll:
                args[1].window.set_cursor(self.l1l1llllll)
    def _1ll1l111l(self, l1l111ll, l1ll1ll1ll):
        res=[]
        l1ll11l1l1=re.findall(l1ll1ll1ll,l1l111ll)
        for l1l1ll11l1 in l1ll11l1l1:
            for el in l1l1ll11l1:
                if el:
                    res.append(el)
        return res
    def l1l11lll1l(self, l1l11llll1, start):
        l1ll1ll11l=0
        for text in l1l11llll1:
            end = self.l1l11ll1l1.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1ll1ll11l+=1
                l1l1ll1l11, l1l1l1ll1l = match
                tag = self.l1l11ll1l1.create_tag(str(l1ll1ll11l), foreground=l1111l1 (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1111l1 (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1l1ll111l, text)
                self.l1l11ll1l1.apply_tag(tag, l1l1ll1l11, l1l1l1ll1l)
                self.l1l11lll1l(l1l11llll1, l1l1l1ll1l)
    def _1l1ll111l(self, tag, widget, l1l1lll1ll, _1l1l11l11, text):
        _1l1l1l111 = l1l1lll1ll.type
        _1ll11llll = l1l1lll1ll.window
        if _1l1l1l111 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l1l111 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1lll1ll.button
            self.l1l1llllll = Gdk.Cursor(Gdk.CursorType.l1l1llll1l)
            if _1l1l1l111 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1111l1 (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l11ll11ll(self, message, title=l1111l1 (u"ࠧࠨ০"), l11l11lll=True, l1ll1l1lll=None):
        if l11l11lll:
            l1ll111l1l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111l1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll111l1l,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll1l1lll:
            l1ll11ll11 = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1111ll = Gtk.HBox(spacing=0)
            l1l1l1l1ll = Gtk.HBox(spacing=5)
            l1ll1l1111 = Gtk.Label()
            l1ll1l1111.set_markup(l1111l1 (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1ll1l1111.set_line_wrap(True)
            l1ll1l1111.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1111l1 (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll11111l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11111l.show()
            l1l1ll11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1ll11ll.show()
            l1ll1l11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l11ll.show()
            l1ll1111ll.pack_start(separator, True, True, 0)
            l1ll1111ll.pack_start(l1ll11111l, True, True, 0)
            l1ll1111ll.pack_start(l1l1ll11ll, True, True, 0)
            l1ll1111ll.pack_start(l1ll1l11ll, True, True, 0)
            l1ll1111ll.pack_start(l1ll1l1111, False, True, 0)
            l1ll1111l1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1111l1.show()
            l1ll1111ll.pack_end(l1ll1111l1, True, True, 0)
            l1l11ll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll11l.show()
            vbox.pack_start(l1ll1111ll, True, True, 0)
            l1l1ll1l1l=self.__1ll1l1ll1(l1l111ll=l1ll1l1lll)
            vbox.pack_start(l1l1ll1l1l, False, False, 0)
            vbox.pack_end(l1l11ll11l, False, False, 0)
            l1l1l1l1ll.pack_start(vbox, True, True,5)
            l1l1l1l1ll.show()
            l1ll11ll11.pack_end(l1l1l1l1ll, False, False, 0)
            vbox.show()
            l1ll1111ll.show()
        window.run()
class l1lll11l1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11l1ll1(self, widget, l1ll11ll1l):
        if l1ll11ll1l == Gtk.ResponseType.OK:
            self.result = l1111l1 (u"ࠥࡓࡐࠨ৩")
        elif l1ll11ll1l == Gtk.ResponseType.CANCEL:
            self.result = l1111l1 (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1ll11ll1l == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1111l1 (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11ll1l11(self, title=l1111l1 (u"ࠨࠢ৬"), message=l1111l1 (u"ࠢࠣ৭") , l11l11lll=True):
        if l11l11lll:
            l1ll111l1l = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111l1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll111l1l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1111l1 (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l11l1ll1)
        window.run()
class l1l11lll11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1lll11=None
        self.result = None
    def l1l11l1ll1(self, widget, l1ll11ll1l):
        print(widget, l1ll11ll1l)
        if l1ll11ll1l == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll11ll1l == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll11ll1l == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1l1llll(self, widget, l1ll11l111):
        if l1ll11l111.get_active():
            self.l1ll1lll11 = 1
        else:
            self.l1ll1lll11 = 0
    def l1l1ll1ll1(self, title=l1111l1 (u"ࠤࠥ৯"), message=l1111l1 (u"ࠥࠦৰ"), l1ll1llll1 =l1111l1 (u"ࠦࠧৱ"),l11l11lll=True):
        if l11l11lll:
            l1ll111l1l= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll111l1l = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll111l1l,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1111l1 (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l11l1ll1)
        l1l11l11ll = Gtk.CheckButton(l1ll1llll1)
        l1l11l11ll.connect(l1111l1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1l1llll, l1l11l11ll)
        l1l11l11ll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l11l11ll, expand=True, fill=True, padding=0)
        l1l11l11ll.show()
        window.run()
def l11l1l1l1(title, msg, l1ll1llll1=l1111l1 (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l11l11lll=True):
    result=None
    try:
        l1l1ll1lll = l1l11lll11()
        l1l1ll1lll.l1l1ll1ll1(title, msg, l1ll1llll1, l11l11lll)
        result = {l1111l1 (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l1ll1lll.result,  l1111l1 (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l1ll1lll.l1ll1lll11}
    except Exception as e:
        logger.exception(l1111l1 (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1111l1 (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11l1l111 = l11lll111()
    message= l1111l1 (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1l1ll1111 = l1111l1 (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11l1l111.l11ll11ll(message, l1111l1 (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l11l11lll=True, l1ll1l1lll=l1l1ll1111)