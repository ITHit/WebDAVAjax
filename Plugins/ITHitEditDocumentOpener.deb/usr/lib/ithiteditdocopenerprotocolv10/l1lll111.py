#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1111ll = 2048
l1l1l11 = 7
def l1ll1l1l (l1l1ll1):
    global l1lll
    l1lll1l = ord (l1l1ll1 [-1])
    l1ll = l1l1ll1 [:-1]
    l11l1ll = l1lll1l % len (l1ll)
    l1lllll1 = l1ll [:l11l1ll] + l1ll [l11l1ll:]
    if l1l1l1l:
        l1111l1 = l1llll1l () .join ([unichr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1111ll - (l1111l + l1lll1l) % l1l1l11) for l1111l, char in enumerate (l1lllll1)])
    return eval (l1111l1)
import hashlib
import os
import l1l1l
from l11llll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l1l import l111
from l1l111l import l11, l1ll1l
import logging
logger = logging.getLogger(l1ll1l1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111l():
    def __init__(self, l1l1lll,l1ll11l1, l11ll1l= None, l111ll1=None):
        self.l11l111=False
        self.l1l111 = self._11l1l()
        self.l1ll11l1 = l1ll11l1
        self.l11ll1l = l11ll1l
        self.l1ll11ll = l1l1lll
        if l11ll1l:
            self.l11111 = True
        else:
            self.l11111 = False
        self.l111ll1 = l111ll1
    def _11l1l(self):
        try:
            return l1l1l.l1ll1ll1() is not None
        except:
            return False
    def open(self):
        l1ll1l1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l111:
            raise NotImplementedError(l1ll1l1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1l1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l111ll = self.l1ll11ll
        if self.l1ll11l1.lower().startswith(self.l1ll11ll.lower()):
            l1ll1lll = re.compile(re.escape(self.l1ll11ll), re.IGNORECASE)
            l1ll11l1 = l1ll1lll.sub(l1ll1l1l (u"ࠨࠩࠄ"), self.l1ll11l1)
            l1ll11l1 = l1ll11l1.replace(l1ll1l1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1l1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11ll11(self.l1ll11ll, l111ll, l1ll11l1, self.l11ll1l)
    def l11ll11(self,l1ll11ll, l111ll, l1ll11l1, l11ll1l):
        l1ll1l1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1l1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111lll = l1l11l1(l1ll11ll)
        l1lll11 = self.l1ll111l(l111lll)
        logger.info(l1ll1l1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111lll)
        if l1lll11:
            logger.info(l1ll1l1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111(l111lll)
            l111lll = l1llll1(l1ll11ll, l111ll, l11ll1l, self.l111ll1)
        logger.debug(l1ll1l1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11l1l1=l111lll + l1ll1l1l (u"ࠤ࠲ࠦࠌ") + l1ll11l1
        l1ll1111 = l1ll1l1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11l1l1+ l1ll1l1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1111)
        l1l = os.system(l1ll1111)
        if (l1l != 0):
            raise IOError(l1ll1l1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11l1l1, l1l))
    def l1ll111l(self, l111lll):
        if os.path.exists(l111lll):
            if os.path.islink(l111lll):
                l111lll = os.readlink(l111lll)
            if os.path.ismount(l111lll):
                return True
        return False
def l1l11l1(l1ll11ll):
    l1llll = l1ll11ll.replace(l1ll1l1l (u"࠭࡜࡝ࠩࠐ"), l1ll1l1l (u"ࠧࡠࠩࠑ")).replace(l1ll1l1l (u"ࠨ࠱ࠪࠒ"), l1ll1l1l (u"ࠩࡢࠫࠓ"))
    l1l11ll = l1ll1l1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11111l=os.environ[l1ll1l1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll=os.path.join(l11111l,l1l11ll, l1llll)
    l1lll1l1=os.path.abspath(l11ll)
    return l1lll1l1
def l1lll1(l111l1l):
    if not os.path.exists(l111l1l):
        os.makedirs(l111l1l)
def l11l1(l1ll11ll, l111ll, l1llll11=None, password=None):
    l1ll1l1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111l1l = l1l11l1(l1ll11ll)
    l1lll1(l111l1l)
    if not l1llll11:
        l1 = l11l()
        l1l11l =l1.l1ll1ll(l1ll1l1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l111ll + l1ll1l1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l111ll + l1ll1l1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l11l, str):
            l1llll11, password = l1l11l
        else:
            raise l1ll1l()
        logger.info(l1ll1l1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111l1l))
    ll = pwd.getpwuid( os.getuid())[0]
    l1l11=os.environ[l1ll1l1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1111={l1ll1l1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : ll, l1ll1l1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll11ll, l1ll1l1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111l1l, l1ll1l1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l11, l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1llll11, l1ll1l1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1111, temp_file)
        if not os.path.exists(os.path.join(l1l1l1, l1ll1l1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1l11=l1ll1l1l (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1l1l (u"ࠧࠨࠤ")
        else:
            l1ll1l11=l1ll1l1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1l1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll11l=l1ll1l1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1l11,temp_file.name)
        l11l11l=[l1ll1l1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1l1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1l1, l1ll11l)]
        p = subprocess.Popen(l11l11l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1l1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1l1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1l1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111l1l
    logger.debug(l1ll1l1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1l1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1l1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1l1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lll1l1=os.path.abspath(l111l1l)
    logger.debug(l1ll1l1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lll1l1)
    return l1lll1l1
def l1llll1(l1ll11ll, l111ll, l11ll1l, l111ll1):
    l1ll1l1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1lll11l(title):
        l1ll11=30
        if len(title)>l1ll11:
            l1l1=title.split(l1ll1l1l (u"ࠨ࠯ࠣ࠳"))
            l11lll=l1ll1l1l (u"ࠧࠨ࠴")
            for block in l1l1:
                l11lll+=block+l1ll1l1l (u"ࠣ࠱ࠥ࠵")
                if len(l11lll) > l1ll11:
                    l11lll+=l1ll1l1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11lll
        return title
    def l11lll1(l11l11, password):
        l1ll1l1l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1ll1l1l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1ll1l1l (u"ࠧࠦࠢ࠹").join(l11l11)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11ll1 = l1ll1l1l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11ll1.encode())
        l1llllll = [l1ll1l1l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l111l1 = l1ll1l1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l111l1)
            for e in l1llllll:
                if e in l111l1: return False
            raise l11(l111l1, l1llll1=l1l1l.l1ll1ll1(), l111ll=l111ll)
        logger.info(l1ll1l1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1llll11 = l1ll1l1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1ll1l1l (u"ࠦࠧ࠿")
    os.system(l1ll1l1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l1111 = l1l11l1(l1ll11ll)
    l111l1l = l1l11l1(hashlib.sha1(l1ll11ll.encode()).hexdigest()[:10])
    l1lll1(l111l1l)
    logger.info(l1ll1l1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111l1l))
    if l11ll1l:
        l11l11 = [l1ll1l1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1l1l (u"ࠤ࠰ࡸࠧࡄ"), l1ll1l1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1l1l (u"ࠫ࠲ࡵࠧࡆ"), l1ll1l1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1llll11, l11ll1l),
                    urllib.parse.unquote(l111ll), os.path.abspath(l111l1l)]
        l11lll1(l11l11, password)
    else:
        while True:
            l1llll11, password = l1lll1ll(l111l1l, l111ll, l111ll1)
            if l1llll11.lower() != l1ll1l1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11l11 = [l1ll1l1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1ll1l1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1ll1l1l (u"ࠤ࠰ࡸࠧࡋ"), l1ll1l1l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1ll1l1l (u"ࠫ࠲ࡵࠧࡍ"), l1ll1l1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1llll11,
                            urllib.parse.unquote(l111ll), os.path.abspath(l111l1l)]
            else:
                raise l1ll1l()
            if l11lll1(l11l11, password): break
    os.system(l1ll1l1l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111l1l, l1l1111))
    l1lll1l1=os.path.abspath(l1l1111)
    return l1lll1l1
def l1lll1ll(l1ll11ll, l111ll, l111ll1):
    l111111 = os.path.join(os.environ[l1ll1l1l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1ll1l1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1ll1l1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l111111)):
       os.makedirs(os.path.dirname(l111111))
    l1lllll = l111ll1.get_value(l1ll1l1l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1ll1l1l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1 = l11l(l1ll11ll, l1lllll)
    l1llll11, password = l1.l1ll1ll(l1ll1l1l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l111ll + l1ll1l1l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l111ll + l1ll1l1l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1llll11 != l1ll1l1l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l1ll(l1ll11ll, l1llll11):
        l1ll1 = l1ll1l1l (u"ࠤ࡙ࠣࠦ").join([l1ll11ll, l1llll11, l1ll1l1l (u"࡚ࠪࠦࠬ") + password + l1ll1l1l (u"࡛ࠫࠧ࠭"), l1ll1l1l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l111111, l1ll1l1l (u"࠭ࡷࠬࠩ࡝")) as l1ll111:
            l1ll111.write(l1ll1)
        os.chmod(l111111, 0o600)
    return l1llll11, password
def l1l1ll(l1ll11ll, l1llll11):
    l111111 = l1ll1l1 = os.path.join(os.environ[l1ll1l1l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1ll1l1l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1ll1l1l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l111111):
        with open(l111111, l1ll1l1l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l111l11 = data[0].split(l1ll1l1l (u"ࠦࠥࠨࡢ"))
            if l1ll11ll == l111l11[0] and l1llll11 == l111l11[1]:
                return True
    return False