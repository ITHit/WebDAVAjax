#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import logging
import os
import re
from l1l1l11 import l1llll11l
logger = logging.getLogger(l111lll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11llll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111lll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll():
    try:
        out = os.popen(l111lll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l111lll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l111lll (u"ࠤࠥॸ").join(result)
                logger.info(l111lll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l111lll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l111lll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l111lll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll11l(l111lll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l111lll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11llll(l111lll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))