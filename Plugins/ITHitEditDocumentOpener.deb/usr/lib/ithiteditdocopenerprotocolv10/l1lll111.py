#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import logging
import os
import re
from l1111l import l1llll1ll
logger = logging.getLogger(l11llll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1lll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11llll (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1lll1ll():
    try:
        out = os.popen(l11llll (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l11llll (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l11llll (u"ࠢࠣॶ").join(result)
                logger.info(l11llll (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l11llll (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l11llll (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l11llll (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1ll(l11llll (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l11llll (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1lll1(l11llll (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))