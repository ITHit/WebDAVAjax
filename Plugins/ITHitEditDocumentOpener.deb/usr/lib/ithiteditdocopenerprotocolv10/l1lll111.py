#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1llll11 = 2048
l11l11 = 7
def l1lllll (l1lll):
    global l1ll1ll1
    l1ll1lll = ord (l1lll [-1])
    l111l11 = l1lll [:-1]
    l1ll11l = l1ll1lll % len (l111l11)
    l1111 = l111l11 [:l1ll11l] + l111l11 [l1ll11l:]
    if l1ll1:
        l111lll = l1l1ll1 () .join ([unichr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    else:
        l111lll = str () .join ([chr (ord (char) - l1llll11 - (l11 + l1ll1lll) % l11l11) for l11, char in enumerate (l1111)])
    return eval (l111lll)
import hashlib
import os
import l1llll1
from l1llllll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1llll1 import ll
from l1l11l import l11l1, l1lll1ll
import logging
logger = logging.getLogger(l1lllll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l11l1():
    def __init__(self, l1l1ll,l11l111, l1l11ll= None, l1l11=None):
        self.l1l=False
        self.l1111l = self._1ll1l1()
        self.l11l111 = l11l111
        self.l1l11ll = l1l11ll
        self.l111l1 = l1l1ll
        if l1l11ll:
            self.l11l1l1 = True
        else:
            self.l11l1l1 = False
        self.l1l11 = l1l11
    def _1ll1l1(self):
        try:
            return l1llll1.l1l1l11() is not None
        except:
            return False
    def open(self):
        l1lllll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1111l:
            raise NotImplementedError(l1lllll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lllll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11l1l = self.l111l1
        if self.l11l111.lower().startswith(self.l111l1.lower()):
            l1l1 = re.compile(re.escape(self.l111l1), re.IGNORECASE)
            l11l111 = l1l1.sub(l1lllll (u"ࠨࠩࠄ"), self.l11l111)
            l11l111 = l11l111.replace(l1lllll (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lllll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll1l1(self.l111l1, l11l1l, l11l111, self.l1l11ll)
    def l1lll1l1(self,l111l1, l11l1l, l11l111, l1l11ll):
        l1lllll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lllll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11ll11 = l11111(l111l1)
        l1lll1l = self.l11l11l(l11ll11)
        logger.info(l1lllll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11ll11)
        if l1lll1l:
            logger.info(l1lllll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            ll(l11ll11)
            l11ll11 = l1l1111(l111l1, l11l1l, l1l11ll, self.l1l11)
        logger.debug(l1lllll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lllll1=l11ll11 + l1lllll (u"ࠤ࠲ࠦࠌ") + l11l111
        l1111ll = l1lllll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lllll1+ l1lllll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1111ll)
        l1ll1l11 = os.system(l1111ll)
        if (l1ll1l11 != 0):
            raise IOError(l1lllll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lllll1, l1ll1l11))
    def l11l11l(self, l11ll11):
        if os.path.exists(l11ll11):
            if os.path.islink(l11ll11):
                l11ll11 = os.readlink(l11ll11)
            if os.path.ismount(l11ll11):
                return True
        return False
def l11111(l111l1):
    l1ll1111 = l111l1.replace(l1lllll (u"࠭࡜࡝ࠩࠐ"), l1lllll (u"ࠧࡠࠩࠑ")).replace(l1lllll (u"ࠨ࠱ࠪࠒ"), l1lllll (u"ࠩࡢࠫࠓ"))
    l1ll = l1lllll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l111l=os.environ[l1lllll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll11=os.path.join(l1l111l,l1ll, l1ll1111)
    l111ll1=os.path.abspath(l1ll11)
    return l111ll1
def l1ll1l(l11ll):
    if not os.path.exists(l11ll):
        os.makedirs(l11ll)
def l11ll1l(l111l1, l11l1l, l1lll1=None, password=None):
    l1lllll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11ll = l11111(l111l1)
    l1ll1l(l11ll)
    if not l1lll1:
        l1111l1 = l111l1l()
        l11l1ll =l1111l1.l1l1l1(l1lllll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11l1l + l1lllll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11l1l + l1lllll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11l1ll, str):
            l1lll1, password = l11l1ll
        else:
            raise l1lll1ll()
        logger.info(l1lllll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11ll))
    l111ll = pwd.getpwuid( os.getuid())[0]
    l1ll11l1=os.environ[l1lllll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1lll11l={l1lllll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111ll, l1lllll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l111l1, l1lllll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11ll, l1lllll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11l1, l1lllll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1lll1, l1lllll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1lll11l, temp_file)
        if not os.path.exists(os.path.join(l1llll, l1lllll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11ll1=l1lllll (u"ࠦࡵࡿࠢࠣ")
            key=l1lllll (u"ࠧࠨࠤ")
        else:
            l11ll1=l1lllll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lllll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l1l=l1lllll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11ll1,temp_file.name)
        l11llll=[l1lllll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lllll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll, l1ll1l1l)]
        p = subprocess.Popen(l11llll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lllll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lllll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lllll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11ll
    logger.debug(l1lllll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lllll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lllll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lllll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111ll1=os.path.abspath(l11ll)
    logger.debug(l1lllll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111ll1)
    return l111ll1
def l1l1111(l111l1, l11l1l, l1l11ll, l1l11):
    l1lllll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1ll111l(title):
        l1ll11ll=30
        if len(title)>l1ll11ll:
            l111111=title.split(l1lllll (u"ࠨ࠯ࠣ࠳"))
            l111l=l1lllll (u"ࠧࠨ࠴")
            for block in l111111:
                l111l+=block+l1lllll (u"ࠣ࠱ࠥ࠵")
                if len(l111l) > l1ll11ll:
                    l111l+=l1lllll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l111l
        return title
    def l1llll1l(l1ll111, password):
        l1lllll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1lllll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1lllll (u"ࠧࠦࠢ࠹").join(l1ll111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l = l1lllll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l.encode())
        l1l1l1l = [l1lllll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1ll1ll = l1lllll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1ll1ll)
            for e in l1l1l1l:
                if e in l1ll1ll: return False
            raise l11l1(l1ll1ll, l1l1111=l1llll1.l1l1l11(), l11l1l=l11l1l)
        logger.info(l1lllll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1lll1 = l1lllll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1lllll (u"ࠦࠧ࠿")
    os.system(l1lllll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11lll = l11111(l111l1)
    l11ll = l11111(hashlib.sha1(l111l1.encode()).hexdigest()[:10])
    l1ll1l(l11ll)
    logger.info(l1lllll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l11ll))
    if l1l11ll:
        l1ll111 = [l1lllll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lllll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lllll (u"ࠤ࠰ࡸࠧࡄ"), l1lllll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lllll (u"ࠫ࠲ࡵࠧࡆ"), l1lllll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1lll1, l1l11ll),
                    urllib.parse.unquote(l11l1l), os.path.abspath(l11ll)]
        l1llll1l(l1ll111, password)
    else:
        while True:
            l1lll1, password = l1l1lll(l11ll, l11l1l, l1l11)
            if l1lll1.lower() != l1lllll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll111 = [l1lllll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1lllll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1lllll (u"ࠤ࠰ࡸࠧࡋ"), l1lllll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1lllll (u"ࠫ࠲ࡵࠧࡍ"), l1lllll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1lll1,
                            urllib.parse.unquote(l11l1l), os.path.abspath(l11ll)]
            else:
                raise l1lll1ll()
            if l1llll1l(l1ll111, password): break
    os.system(l1lllll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l11ll, l11lll))
    l111ll1=os.path.abspath(l11lll)
    return l111ll1
def l1l1lll(l111l1, l11l1l, l1l11):
    l1l1l = os.path.join(os.environ[l1lllll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1lllll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1lllll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l1l)):
       os.makedirs(os.path.dirname(l1l1l))
    l1l111 = l1l11.get_value(l1lllll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1lllll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1111l1 = l111l1l(l111l1, l1l111)
    l1lll1, password = l1111l1.l1l1l1(l1lllll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11l1l + l1lllll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11l1l + l1lllll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1lll1 != l1lllll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111(l111l1, l1lll1):
        l11111l = l1lllll (u"ࠤ࡙ࠣࠦ").join([l111l1, l1lll1, l1lllll (u"࡚ࠪࠦࠬ") + password + l1lllll (u"࡛ࠫࠧ࠭"), l1lllll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l1l, l1lllll (u"࠭ࡷࠬࠩ࡝")) as l1lll11:
            l1lll11.write(l11111l)
        os.chmod(l1l1l, 0o600)
    return l1lll1, password
def l111(l111l1, l1lll1):
    l1l1l = l11lll1 = os.path.join(os.environ[l1lllll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1lllll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1lllll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l1l):
        with open(l1l1l, l1lllll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1 = data[0].split(l1lllll (u"ࠦࠥࠨࡢ"))
            if l111l1 == l1[0] and l1lll1 == l1[1]:
                return True
    return False