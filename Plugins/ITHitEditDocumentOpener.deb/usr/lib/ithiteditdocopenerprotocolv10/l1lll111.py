#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l1l = 2048
l1lll11l = 7
def l11lll1 (l1ll1l1):
    global l1lll1
    l1111l = ord (l1ll1l1 [-1])
    l11111l = l1ll1l1 [:-1]
    l1l11l1 = l1111l % len (l11111l)
    l11l1l1 = l11111l [:l1l11l1] + l11111l [l1l11l1:]
    if l1l11l:
        l11ll = l1l111l () .join ([unichr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1l - (l1llll + l1111l) % l1lll11l) for l1llll, char in enumerate (l11l1l1)])
    return eval (l11ll)
import re
class l11l111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1lll = kwargs.get(l11lll1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l11llll = kwargs.get(l11lll1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l11111l1 = self.l1lllll1l(args)
        if l11111l1:
            args=args+ l11111l1
        self.args = [a for a in args]
    def l1lllll1l(self, *args):
        l11111l1=None
        l1l111l1 = args[0][0]
        if re.search(l11lll1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l111l1):
            l11111l1 = (l11lll1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1lll
                            ,)
        return l11111l1
class l111111l(Exception):
    def __init__(self, *args, **kwargs):
        l11111l1 = self.l1lllll1l(args)
        if l11111l1:
            args = args + l11111l1
        self.args = [a for a in args]
    def l1lllll1l(self, *args):
        s = l11lll1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l11lll1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1ll1(Exception):
    pass
class l111ll1(Exception):
    pass
class l1lll11ll(Exception):
    def __init__(self, message, l1lllllll, url):
        super(l1lll11ll,self).__init__(message)
        self.l1lllllll = l1lllllll
        self.url = url
class l1llll1l1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1111111(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1llll111(Exception):
    pass
class l11111ll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1llll11l(Exception):
    pass
class l111l1ll(Exception):
    pass