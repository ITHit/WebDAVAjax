#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import gi
gi.require_version(l1llll1 (u"࠭ࡇࡵ࡭ࠪ঻"), l1llll1 (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l1l11111
import logging
logger = logging.getLogger(l1llll1 (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l1ll11l1(Gtk.Window):
    def __init__(self, l1l1l1l1ll, l1l11ll1l1):
        Gtk.Window.__init__(self)
        self.l111l1l=30
        self.l1ll1ll11l = False
        self.service = l1l1l1l1ll
        self.l1lll11=l1l11ll1l1
        self.l1l1ll=l1l11111.l1l1llll
        self.l1l1ll111l = Gtk.ListStore(str)
        self.l1ll1lll1l()
    def l1l1lll1ll(self, service):
        l1l1l11111 = self.l1l1ll.l1l1lll1(l1llll1 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1l1l11111
    def l1ll1lll1l(self, l1l1l1l1ll=None):
        if l1l1l1l1ll:
            self.l1l1ll111l.clear()
            l1l1l1111l=self.l1l1lll1ll(l1l1l1l1ll)
            self.l1l1ll111l.append([l1llll1 (u"ࠥࠦি")])
            for l1lll11 in l1l1l1111l:
                self.l1l1ll111l.append([l1lll11])
        else:
            self.l1l1ll111l.clear()
            self.l1l1ll111l.append([l1llll1 (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1ll1111ll(self, widget, data=None):
        l1ll1l1lll= widget.get_active()
        if data == l1llll1 (u"ࠧ࠷ࠢু") and l1ll1l1lll:
            self.l1ll1lll1l()
            self.l1ll11lll1.set_active(0)
            self.l1l1lllll1.set_text(l1llll1 (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1l1lllll1.set_sensitive(False)
            self.l1ll11lll1.set_sensitive(False)
        else:
            self.l1ll1lll1l(l1l1l1l1ll=self.service)
            self.l1ll11lll1.set_active(0)
            self.l1l1lllll1.set_text(l1llll1 (u"ࠢࠣৃ"))
            self.l1ll11lll1.set_sensitive(True)
            self.l1l1lllll1.set_sensitive(True)
    def l1ll11l1l1(self, widget):
        if widget.get_active():
            l1lll11 = widget.get_child().get_text()
        else:
            l1lll11 = self.l1l1ll111l[widget.get_active()][0]
        password = self.l1ll111l1l(self.service, l1lll11)
        if password:
            self.l1l1lllll1.set_text(password)
        else:
            self.l1l1lllll1.set_text(l1llll1 (u"ࠣࠤৄ"))
    def l1l1l1l1l1(self, l1lll11, pwd, service):
        keyring.set_password(service, l1lll11, pwd)
        l1l1l11111=self.l1l1ll.l1l1lll1(l1llll1 (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l1lll11 in l1l1l11111:
            value = self.l1l1ll.get_value(l1llll1 (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l1l1ll.l1l111l1(l1llll1 (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l1llll1 (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l1lll11))
    def l1ll111l1l(self, service, l1lll11):
        l1ll11l111 = keyring.get_password(service, l1lll11)
        return l1ll11l111
    def l1l11ll1ll(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll11llll(self, widget, data=None):
        self.l1ll1ll11l=widget.get_active()
    def l111lll(self, message, title=l1llll1 (u"࠭ࠧ৉"), l11ll11ll=True):
        if l11ll11ll:
            l1ll1l11l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1l11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1ll1111 = Gtk.MessageDialog(self,
            l1ll1l11l1,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1ll1111.set_title(title)
        l1l1ll1111.set_default_response(Gtk.ResponseType.OK)
        l1ll11ll11 = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l11lllll = Gtk.VBox()
        l1l1ll11ll = Gtk.Box(spacing=1)
        l1l1ll11ll.set_homogeneous(False)
        l1l1lll1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll1l1.set_homogeneous(False)
        l1l11l1lll = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l11l1lll.set_homogeneous(False)
        l1l1ll11ll.pack_start(l1l1lll1l1, True, True, 0)
        l1l1ll11ll.pack_start(l1l11l1lll, True, True, 0)
        l1l1l11lll = l1l1ll1111.get_content_area()
        l1lll11111 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l11lll.pack_start(l1lll11111, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1l1ll1lll = Gtk.Label()
        l1ll1ll111 = Gtk.Label()
        l1ll1ll111.set_text(l1llll1 (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1ll1ll111, True, True, 0)
        l1l1ll1lll.set_text(l1llll1 (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1l1ll1lll.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1l1ll1lll, 0, 1, 0, 1)
        l1ll1l1l1l = Gtk.RadioButton.new_with_label_from_widget(None, l1llll1 (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1ll1l1l1l.connect(l1llll1 (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1ll1111ll, l1llll1 (u"ࠦ࠶ࠨৎ"))
        table.attach(l1ll1l1l1l, 1, 2, 0, 1)
        l1l1l111ll = Gtk.RadioButton.new_with_label_from_widget(l1ll1l1l1l, l1llll1 (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1l1l111ll.connect(l1llll1 (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1ll1111ll, l1llll1 (u"ࠢ࠳ࠤ৑"))
        table.attach(l1l1l111ll, 1, 2, 1, 2)
        l1ll11l1ll = Gtk.Label()
        l1ll11l1ll.set_text(l1llll1 (u"ࠣࠢࠥ৒"))
        table.attach(l1ll11l1ll, 0, 1, 4, 6)
        l1l1ll1l1l = Gtk.Label()
        l1l1ll1l1l.set_text(l1llll1 (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1l1ll1l1l.set_justify(Gtk.Justification.RIGHT)
        l1l1ll1l1l.set_alignment(xalign=1, yalign=0.5)
        self.l1ll11lll1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1ll111l)
        self.l1ll11lll1.set_entry_text_column(0)
        table.attach(l1l1ll1l1l, 0, 1, 6, 8)
        table.attach(self.l1ll11lll1, 1, 3, 6, 8)
        self.l1ll11lll1.connect(l1llll1 (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1ll11l1l1)
        l1l1ll1ll1 = Gtk.Label()
        l1l1ll1ll1.set_text(l1llll1 (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1l1ll1ll1.set_justify(Gtk.Justification.RIGHT)
        l1l1ll1ll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l1lllll1 = Gtk.Entry()
        self.l1l1lllll1.set_visibility(False)
        self.l1l1lllll1.connect(l1llll1 (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1l11ll1ll, l1l1ll1111)
        table.attach(l1l1ll1ll1, 0, 1, 8, 10)
        table.attach(self.l1l1lllll1, 1, 3, 8, 10)
        l1l1ll11l1 = Gtk.CheckButton(l1llll1 (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1l1ll11l1.connect(l1llll1 (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1ll11llll, l1l1ll11l1)
        l1l1ll11l1.set_active(False)
        table.attach(l1l1ll11l1, 1, 3, 12, 14)
        l1ll111l11 = Gtk.Label()
        l1ll111l11.set_text(l1llll1 (u"ࠣࠢࠥ৙") * 5)
        l1l11lllll.pack_start(l1ll111l11, True, True, 0)
        if self.l1lll11:
            l1l1l111ll.set_active(True)
            self.l1ll11lll1.set_active(0)
            self.l1ll11lll1.set_sensitive(True)
            self.l1l1lllll1.set_text(l1llll1 (u"ࠤࠥ৚"))
            self.l1l1lllll1.set_sensitive(True)
        else:
            self.l1ll11lll1.set_active(0)
            self.l1ll11lll1.set_sensitive(False)
            self.l1l1lllll1.set_text(l1llll1 (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1l1lllll1.set_sensitive(False)
        l1ll11ll11.pack_start(vbox, True, True, 0)
        l1ll11ll11.pack_start(table, True, True, 0)
        l1ll11ll11.pack_end(l1l11lllll, True, True, 0)
        l1lll11111.pack_start(l1ll11ll11, True, True, 0)
        l1l1ll1111.show_all()
        response = l1l1ll1111.run()
        if self.l1ll11lll1.get_active():
            l1lll11 = self.l1ll11lll1.get_child().get_text()
        else:
            l1lll11 = self.l1l1ll111l[self.l1ll11lll1.get_active()][0]
        pwd = self.l1l1lllll1.get_text()
        l1l1ll1111.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll1ll11l:
                self.l1l1l1l1l1(l1lll11, pwd, self.service)
            return l1lll11, pwd
        else:
            return l1llll1 (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l1llll1 (u"ࠬ࠭ঢ়")
class l1l11111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll11l11l(self, l11ll1ll):
        l1l1l1l11l = Gtk.ScrolledWindow()
        l1l1l1l11l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1llll1l=None
        self.l1l1l1l111 = Gtk.TextBuffer()
        self.l1l1l1l111.set_text(l11ll1ll)
        self.set_style()
        regexp= l1llll1 (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll11ll1l = self._1ll111111(l11ll1ll, regexp)
        self.l1l1ll1l11(l1ll11ll1l, self.l1l1l1l111.get_start_iter())
        self.l1l11ll111 = Gtk.TextView(buffer=self.l1l1l1l111)
        self.l1l11ll111.set_property(l1llll1 (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1l11ll111.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l11ll111.connect(l1llll1 (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1ll111lll)
        self.l1l11ll111.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1l1l11l.set_size_request(300,100)
        self.l1l11ll111.show()
        l1l1l1l11l.add(self.l1l11ll111)
        l1l1l1l11l.show()
        return l1l1l1l11l
    def _1ll111lll(self, *args, **kwargs):
        l1l1l11l1l, l1l11l1l1l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l11l1l, l1l11l1l1l).get_tags()
        if not self.l1l1llll1l:
            self.l1l1llll1l = args[1].window.get_cursor()
            self.l1l1lll111 = Gdk.Cursor(Gdk.CursorType.l1l1l1llll)
        elif tag:
            args[1].window.set_cursor(self.l1l1lll111)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1llll1l:
                args[1].window.set_cursor(self.l1l1llll1l)
    def _1ll111111(self, l11ll1ll, l1l1l11l11):
        res=[]
        l1ll1ll1ll=re.findall(l1l1l11l11,l11ll1ll)
        for l1ll1111l1 in l1ll1ll1ll:
            for el in l1ll1111l1:
                if el:
                    res.append(el)
        return res
    def l1l1ll1l11(self, l1ll11ll1l, start):
        l1l1llllll=0
        for text in l1ll11ll1l:
            end = self.l1l1l1l111.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1llllll+=1
                l1l11lll1l, l1l1l1ll1l = match
                tag = self.l1l1l1l111.create_tag(str(l1l1llllll), foreground=l1llll1 (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1llll1 (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1ll1lll11, text)
                self.l1l1l1l111.apply_tag(tag, l1l11lll1l, l1l1l1ll1l)
                self.l1l1ll1l11(l1ll11ll1l, l1l1l1ll1l)
    def _1ll1lll11(self, tag, widget, l1ll111ll1, _1ll1ll1l1, text):
        _1lll1111l = l1ll111ll1.type
        _1ll1llll1 = l1ll111ll1.window
        if _1lll1111l == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1lll1111l in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1ll111ll1.button
            self.l1l1llll1l = Gdk.Cursor(Gdk.CursorType.l1l1l1llll)
            if _1lll1111l == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1llll1 (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l11l1l1ll(self, message, title=l1llll1 (u"ࠬ࠭৤"), l11ll11ll=True, l1ll1l1111=None):
        if l11ll11ll:
            l1ll1l11l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1l11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1ll1l11l1,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll1l1111:
            l1l1l11lll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1l1ll11ll = Gtk.HBox(spacing=0)
            l1ll1lllll = Gtk.HBox(spacing=5)
            l1ll11111l = Gtk.Label()
            l1ll11111l.set_markup(l1llll1 (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1ll11111l.set_line_wrap(True)
            l1ll11111l.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1llll1 (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l11lll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lll11.show()
            l1ll1l1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l11.show()
            l1l1lll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1lll11l.show()
            l1l1ll11ll.pack_start(separator, True, True, 0)
            l1l1ll11ll.pack_start(l1l11lll11, True, True, 0)
            l1l1ll11ll.pack_start(l1ll1l1l11, True, True, 0)
            l1l1ll11ll.pack_start(l1l1lll11l, True, True, 0)
            l1l1ll11ll.pack_start(l1ll11111l, False, True, 0)
            l1ll1l11ll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l11ll.show()
            l1l1ll11ll.pack_end(l1ll1l11ll, True, True, 0)
            l1l11ll11l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11ll11l.show()
            vbox.pack_start(l1l1ll11ll, True, True, 0)
            l1l1l1l11l=self.__1ll11l11l(l11ll1ll=l1ll1l1111)
            vbox.pack_start(l1l1l1l11l, False, False, 0)
            vbox.pack_end(l1l11ll11l, False, False, 0)
            l1ll1lllll.pack_start(vbox, True, True,5)
            l1ll1lllll.show()
            l1l1l11lll.pack_end(l1ll1lllll, False, False, 0)
            vbox.show()
            l1l1ll11ll.show()
        window.run()
class l11l1111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11llll1(self, widget, l1ll1l1ll1):
        if l1ll1l1ll1 == Gtk.ResponseType.OK:
            self.result = l1llll1 (u"ࠣࡑࡎࠦ১")
        elif l1ll1l1ll1 == Gtk.ResponseType.CANCEL:
            self.result = l1llll1 (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1ll1l1ll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1llll1 (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1l1ll1l1(self, title=l1llll1 (u"ࠦࠧ৪"), message=l1llll1 (u"ࠧࠨ৫") , l11ll11ll=True):
        if l11ll11ll:
            l1ll1l11l1 = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1l11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1l11l1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1llll1 (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1l11llll1)
        window.run()
class l1ll1l111l(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1l1lll1=None
        self.result = None
    def l1l11llll1(self, widget, l1ll1l1ll1):
        print(widget, l1ll1l1ll1)
        if l1ll1l1ll1 == Gtk.ResponseType.OK:
            self.result = True
        elif l1ll1l1ll1 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1ll1l1ll1 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll11llll(self, widget, l1l1l111l1):
        if l1l1l111l1.get_active():
            self.l1l1l1lll1 = 1
        else:
            self.l1l1l1lll1 = 0
    def l1l1llll11(self, title=l1llll1 (u"ࠢࠣ৭"), message=l1llll1 (u"ࠣࠤ৮"), l1l1l1ll11 =l1llll1 (u"ࠤࠥ৯"),l11ll11ll=True):
        if l11ll11ll:
            l1ll1l11l1= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1ll1l11l1 = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1ll1l11l1,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1llll1 (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1l11llll1)
        l1l1ll11l1 = Gtk.CheckButton(l1l1l1ll11)
        l1l1ll11l1.connect(l1llll1 (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1ll11llll, l1l1ll11l1)
        l1l1ll11l1.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1ll11l1, expand=True, fill=True, padding=0)
        l1l1ll11l1.show()
        window.run()
def l1ll1l1ll(title, msg, l1l1l1ll11=l1llll1 (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l11ll11ll=True):
    result=None
    try:
        l1l1l11ll1 = l1ll1l111l()
        l1l1l11ll1.l1l1llll11(title, msg, l1l1l1ll11, l11ll11ll)
        result = {l1llll1 (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1l1l11ll1.result,  l1llll1 (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1l1l11ll1.l1l1l1lll1}
    except Exception as e:
        logger.exception(l1llll1 (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l1llll1 (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l1l1ll1ll = l1l11111l()
    message= l1llll1 (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1l11l1ll1 = l1llll1 (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l1l1ll1ll.l11l1l1ll(message, l1llll1 (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l11ll11ll=True, l1ll1l1111=l1l11l1ll1)