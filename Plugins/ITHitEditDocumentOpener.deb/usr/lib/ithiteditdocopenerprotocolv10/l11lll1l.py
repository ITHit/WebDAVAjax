#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1l = 2048
l1llll1l = 7
def l11l (l11ll1):
    global l1lll11l
    l1ll1 = ord (l11ll1 [-1])
    l11ll11 = l11ll1 [:-1]
    l11l111 = l1ll1 % len (l11ll11)
    l1l1l = l11ll11 [:l11l111] + l11ll11 [l11l111:]
    if l111ll1:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    return eval (l11l11l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll11 import l1lllll
from configobj import ConfigObj
l1l11ll1 = l11l (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1ll111l = l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠳࠴࠱࠴ࠧࡢ")
l1l11111 = l11l (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l11l (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠲࠳࠰࠳ࠦࡤ")
l11ll11l=os.path.join(os.environ.get(l11l (u"ࠧࡉࡑࡐࡉࠬࡥ")),l11l (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l11111.replace(l11l (u"ࠤࠣࠦࡧ"), l11l (u"ࠥࡣࠧࡨ")).lower())
l11llll1=os.environ.get(l11l (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l11l (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l11ll1ll=l1ll111l.replace(l11l (u"ࠨࠠࠣ࡫"), l11l (u"ࠢࡠࠤ࡬"))+l11l (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l11lll=os.path.join(os.environ.get(l11l (u"ࠪࡘࡊࡓࡐࠨ࡯")),l11ll1ll)
elif platform.system() == l11l (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l1lll1=l1lllll(l11ll11l+l11l (u"ࠧ࠵ࠢࡱ"))
    l1l11lll = os.path.join(l1l1lll1, l11ll1ll)
else:
    l1l11lll = os.path.join( l11ll1ll)
l11llll1=l11llll1.upper()
if l11llll1 == l11l (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l1l111=logging.DEBUG
elif l11llll1 == l11l (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l1l111 = logging.INFO
elif l11llll1 == l11l (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l1l111 = logging.WARNING
elif l11llll1 == l11l (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l1l111 = logging.ERROR
elif l11llll1 == l11l (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l1l111 = logging.CRITICAL
elif l11llll1 == l11l (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l1l111 = logging.NOTSET
logger = logging.getLogger(l11l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l1l111)
l1l111l1 = logging.FileHandler(l1l11lll, mode=l11l (u"ࠨࡷࠬࠤࡹ"))
l1l111l1.setLevel(l1l1l111)
formatter = logging.Formatter(l11l (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l11l (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l111l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l111)
l1l11l11 = SysLogHandler(address=l11l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l111l1)
logger.addHandler(ch)
logger.addHandler(l1l11l11)
class Settings():
    l11lllll = l11l (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l111ll = l11l (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l11l1l = l11l (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1ll111l):
        self.l11ll1l1 = self._1l1l11l(l1ll111l)
        self._1l1llll()
    def _1l1l11l(self, l1ll111l):
        l1l1ll11 = l1ll111l.split(l11l (u"ࠨࠠࠣࢀ"))
        l1l1ll11 = l11l (u"ࠢࠡࠤࢁ").join(l1l1ll11)
        if platform.system() == l11l (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11ll1l1 = os.path.join(l11ll11l, l11l (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1ll11 + l11l (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11ll1l1
    def l11lll11(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11l (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11l (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1ll1l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1llll(self):
        if not os.path.exists(os.path.dirname(self.l11ll1l1)):
            os.makedirs(os.path.dirname(self.l11ll1l1))
        if not os.path.exists(self.l11ll1l1):
            self.config = ConfigObj(self.l11ll1l1)
            self.config[l11l (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l11l (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l11l (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l11l1l
            self.config[l11l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l11l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l111ll
            self.config[l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l11lllll
            self.config[l11l (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll1l1)
            self.l1l11l1l = self.get_value(l11l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l11l (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l111ll = self.get_value(l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l11l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l11lllll = self.get_value(l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1111l(self):
        l1l1l1ll = l11l (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l11lllll
        l1l1l1ll += l11l (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l111ll
        l1l1l1ll += l11l (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l11l1l
        return l1l1l1ll
    def __unicode__(self):
        return self._1l1111l()
    def __str__(self):
        return self._1l1111l()
    def __del__(self):
        self.config.write()
l1ll1111 = Settings(l1ll111l)