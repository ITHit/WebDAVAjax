#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1 = sys.version_info [0] == 2
l11l1 = 2048
l1ll1l11 = 7
def l1ll1lll (l1):
    global l1l1lll
    l1lll1l1 = ord (l1 [-1])
    l1l11l1 = l1 [:-1]
    l111l = l1lll1l1 % len (l1l11l1)
    l1ll1l1 = l1l11l1 [:l111l] + l1l11l1 [l111l:]
    if l1l1:
        l11lll = l11llll () .join ([unichr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    else:
        l11lll = str () .join ([chr (ord (char) - l11l1 - (l1llllll + l1lll1l1) % l1ll1l11) for l1llllll, char in enumerate (l1ll1l1)])
    return eval (l11lll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11ll11 import l111l11
from configobj import ConfigObj
l11lll1l = l1ll1lll (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l1ll11 = l1ll1lll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠹࠵࠳࠶ࠢࡤ")
l1l1llll = l1ll1lll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1ll1lll (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠸࠴࠲࠵ࠨࡦ")
l1l1l1ll=os.path.join(os.environ.get(l1ll1lll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1ll1lll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l1llll.replace(l1ll1lll (u"ࠦࠥࠨࡩ"), l1ll1lll (u"ࠧࡥࠢࡪ")).lower())
l1l11lll=os.environ.get(l1ll1lll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1ll1lll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l11l11=l1l1ll11.replace(l1ll1lll (u"ࠣࠢࠥ࡭"), l1ll1lll (u"ࠤࡢࠦ࡮"))+l1ll1lll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1ll1lll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l1lll1=os.path.join(os.environ.get(l1ll1lll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l11l11)
elif platform.system() == l1ll1lll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l111ll=l111l11(l1l1l1ll+l1ll1lll (u"ࠢ࠰ࠤࡳ"))
    l1l1lll1 = os.path.join(l1l111ll, l1l11l11)
else:
    l1l1lll1 = os.path.join( l1l11l11)
l1l11lll=l1l11lll.upper()
if l1l11lll == l1ll1lll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l11lllll=logging.DEBUG
elif l1l11lll == l1ll1lll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l11lllll = logging.INFO
elif l1l11lll == l1ll1lll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l11lllll = logging.WARNING
elif l1l11lll == l1ll1lll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l11lllll = logging.ERROR
elif l1l11lll == l1ll1lll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l11lllll = logging.CRITICAL
elif l1l11lll == l1ll1lll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l11lllll = logging.NOTSET
logger = logging.getLogger(l1ll1lll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l11lllll)
l11llll1 = logging.FileHandler(l1l1lll1, mode=l1ll1lll (u"ࠣࡹ࠮ࠦࡻ"))
l11llll1.setLevel(l11lllll)
formatter = logging.Formatter(l1ll1lll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1ll1lll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11llll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lllll)
l11ll1ll = SysLogHandler(address=l1ll1lll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l11llll1)
logger.addHandler(ch)
logger.addHandler(l11ll1ll)
class Settings():
    l1l1l1l1 = l1ll1lll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l1l1ll1l = l1ll1lll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l11111 = l1ll1lll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l1ll11):
        self.l11ll1l1 = self._1l1l111(l1l1ll11)
        self._1l11l1l()
    def _1l1l111(self, l1l1ll11):
        l1l11ll1 = l1l1ll11.split(l1ll1lll (u"ࠣࠢࠥࢂ"))
        l1l11ll1 = l1ll1lll (u"ࠤࠣࠦࢃ").join(l1l11ll1)
        if platform.system() == l1ll1lll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l11ll1l1 = os.path.join(l1l1l1ll, l1ll1lll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l11ll1 + l1ll1lll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l11ll1l1
    def l1l111l1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l11l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1lll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1lll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11lll11(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11l1l(self):
        if not os.path.exists(os.path.dirname(self.l11ll1l1)):
            os.makedirs(os.path.dirname(self.l11ll1l1))
        if not os.path.exists(self.l11ll1l1):
            self.config = ConfigObj(self.l11ll1l1)
            self.config[l1ll1lll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1ll1lll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1ll1lll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l11111
            self.config[l1ll1lll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1ll1lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1lll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l1l1ll1l
            self.config[l1ll1lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1ll1lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l1l1l1l1
            self.config[l1ll1lll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll1l1)
            self.l1l11111 = self.get_value(l1ll1lll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1ll1lll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l1l1ll1l = self.get_value(l1ll1lll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1lll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l1l1l1l1 = self.get_value(l1ll1lll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1ll1lll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11ll11l(self):
        l11l1lll = l1ll1lll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l1l1l1l1
        l11l1lll += l1ll1lll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l1l1ll1l
        l11l1lll += l1ll1lll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l11111
        return l11l1lll
    def __unicode__(self):
        return self._11ll11l()
    def __str__(self):
        return self._11ll11l()
    def __del__(self):
        self.config.write()
l11ll111 = Settings(l1l1ll11)