#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1ll = 7
def l1l111 (l11ll):
    global l1lll11l
    l1ll1l1l = ord (l11ll [-1])
    l111 = l11ll [:-1]
    l11 = l1ll1l1l % len (l111)
    l1ll1ll = l111 [:l11] + l111 [l11:]
    if l1llll:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    return eval (l1ll1l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l1lll import l111lll
from configobj import ConfigObj
l1l11l11 = l1l111 (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l11llll1 = l1l111 (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠶࠻࠸࠽࠳࠶ࠢࡤ")
l11ll11l = l1l111 (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1l111 (u"ࠣ࠷࠱࠶࠶࠴࠵࠺࠷࠼࠲࠵ࠨࡦ")
l1l11lll=os.path.join(os.environ.get(l1l111 (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1l111 (u"ࠥ࠲ࠪࡹࠢࡨ") %l11ll11l.replace(l1l111 (u"ࠦࠥࠨࡩ"), l1l111 (u"ࠧࡥࠢࡪ")).lower())
l11lllll=os.environ.get(l1l111 (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1l111 (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l1lll1=l11llll1.replace(l1l111 (u"ࠣࠢࠥ࡭"), l1l111 (u"ࠤࡢࠦ࡮"))+l1l111 (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1l111 (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l1l111ll=os.path.join(os.environ.get(l1l111 (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l1lll1)
elif platform.system() == l1l111 (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l11lll11=l111lll(l1l11lll+l1l111 (u"ࠢ࠰ࠤࡳ"))
    l1l111ll = os.path.join(l11lll11, l1l1lll1)
else:
    l1l111ll = os.path.join( l1l1lll1)
l11lllll=l11lllll.upper()
if l11lllll == l1l111 (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1ll11=logging.DEBUG
elif l11lllll == l1l111 (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1ll11 = logging.INFO
elif l11lllll == l1l111 (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1ll11 = logging.WARNING
elif l11lllll == l1l111 (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1ll11 = logging.ERROR
elif l11lllll == l1l111 (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1ll11 = logging.CRITICAL
elif l11lllll == l1l111 (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1ll11 = logging.NOTSET
logger = logging.getLogger(l1l111 (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1ll11)
l1l1l111 = logging.FileHandler(l1l111ll, mode=l1l111 (u"ࠣࡹ࠮ࠦࡻ"))
l1l1l111.setLevel(l1l1ll11)
formatter = logging.Formatter(l1l111 (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1l111 (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l1l1l111.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1ll11)
l1l11l1l = SysLogHandler(address=l1l111 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l1l11l1l.setFormatter(formatter)
logger.addHandler(l1l1l111)
logger.addHandler(ch)
logger.addHandler(l1l11l1l)
class Settings():
    l11ll1ll = l1l111 (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11ll111 = l1l111 (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l1l111l1 = l1l111 (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l11llll1):
        self.l1l11111 = self._1l11ll1(l11llll1)
        self._1l1llll()
    def _1l11ll1(self, l11llll1):
        l1l1l1l1 = l11llll1.split(l1l111 (u"ࠣࠢࠥࢂ"))
        l1l1l1l1 = l1l111 (u"ࠤࠣࠦࢃ").join(l1l1l1l1)
        if platform.system() == l1l111 (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11111 = os.path.join(l1l11lll, l1l111 (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l1l1 + l1l111 (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11111
    def l11l1lll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l111 (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l111 (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11lll1l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1llll(self):
        if not os.path.exists(os.path.dirname(self.l1l11111)):
            os.makedirs(os.path.dirname(self.l1l11111))
        if not os.path.exists(self.l1l11111):
            self.config = ConfigObj(self.l1l11111)
            self.config[l1l111 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1l111 (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1l111 (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l1l111l1
            self.config[l1l111 (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1l111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11ll111
            self.config[l1l111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1l111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11ll1ll
            self.config[l1l111 (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11111)
            self.l1l111l1 = self.get_value(l1l111 (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1l111 (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11ll111 = self.get_value(l1l111 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l111 (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11ll1ll = self.get_value(l1l111 (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1l111 (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _1l1ll1l(self):
        l1l1l11l = l1l111 (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11ll1ll
        l1l1l11l += l1l111 (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11ll111
        l1l1l11l += l1l111 (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l1l111l1
        return l1l1l11l
    def __unicode__(self):
        return self._1l1ll1l()
    def __str__(self):
        return self._1l1ll1l()
    def __del__(self):
        self.config.write()
l11ll1l1 = Settings(l11llll1)