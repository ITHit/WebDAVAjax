#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111lll = 2048
l1lll11 = 7
def l1l1l11 (l1l11):
    global l111l
    l1ll1l11 = ord (l1l11 [-1])
    l11l = l1l11 [:-1]
    l1lll = l1ll1l11 % len (l11l)
    l1lll11l = l11l [:l1lll] + l11l [l1lll:]
    if l1ll1l:
        l11ll1l = l1llll1l () .join ([unichr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    return eval (l11ll1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l1ll import l1lll1ll
from configobj import ConfigObj
l1l1l1ll = l1l1l11 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l111ll = l1l1l11 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠸࠵࠱࠴ࠧࡢ")
l11lllll = l1l1l11 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1l1l11 (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠷࠴࠰࠳ࠦࡤ")
l1l1lll1=os.path.join(os.environ.get(l1l1l11 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1l1l11 (u"ࠣ࠰ࠨࡷࠧࡦ") %l11lllll.replace(l1l1l11 (u"ࠤࠣࠦࡧ"), l1l1l11 (u"ࠥࡣࠧࡨ")).lower())
l1ll1111=os.environ.get(l1l1l11 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1l1l11 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l11llll1=l1l111ll.replace(l1l1l11 (u"ࠨࠠࠣ࡫"), l1l1l11 (u"ࠢࡠࠤ࡬"))+l1l1l11 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1l1l11 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1llll=os.path.join(os.environ.get(l1l1l11 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l11llll1)
elif platform.system() == l1l1l11 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l11lll=l1lll1ll(l1l1lll1+l1l1l11 (u"ࠧ࠵ࠢࡱ"))
    l1l1llll = os.path.join(l1l11lll, l11llll1)
else:
    l1l1llll = os.path.join( l11llll1)
l1ll1111=l1ll1111.upper()
if l1ll1111 == l1l1l11 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11ll1ll=logging.DEBUG
elif l1ll1111 == l1l1l11 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11ll1ll = logging.INFO
elif l1ll1111 == l1l1l11 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11ll1ll = logging.WARNING
elif l1ll1111 == l1l1l11 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11ll1ll = logging.ERROR
elif l1ll1111 == l1l1l11 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11ll1ll = logging.CRITICAL
elif l1ll1111 == l1l1l11 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11ll1ll = logging.NOTSET
logger = logging.getLogger(l1l1l11 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11ll1ll)
l11ll1l1 = logging.FileHandler(l1l1llll, mode=l1l1l11 (u"ࠨࡷࠬࠤࡹ"))
l11ll1l1.setLevel(l11ll1ll)
formatter = logging.Formatter(l1l1l11 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1l1l11 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l11ll1l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11ll1ll)
l1l1l111 = SysLogHandler(address=l1l1l11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l1l111.setFormatter(formatter)
logger.addHandler(l11ll1l1)
logger.addHandler(ch)
logger.addHandler(l1l1l111)
class Settings():
    l1l11ll1 = l1l1l11 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l1l1l1 = l1l1l11 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1ll111l = l1l1l11 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l111ll):
        self.l11ll11l = self._1l1l11l(l1l111ll)
        self._11lll1l()
    def _1l1l11l(self, l1l111ll):
        l1l1ll1l = l1l111ll.split(l1l1l11 (u"ࠨࠠࠣࢀ"))
        l1l1ll1l = l1l1l11 (u"ࠢࠡࠤࢁ").join(l1l1ll1l)
        if platform.system() == l1l1l11 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11ll11l = os.path.join(l1l1lll1, l1l1l11 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1ll1l + l1l1l11 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11ll11l
    def l1l11l1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l1l11 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l1l11 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l111l1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll1l(self):
        if not os.path.exists(os.path.dirname(self.l11ll11l)):
            os.makedirs(os.path.dirname(self.l11ll11l))
        if not os.path.exists(self.l11ll11l):
            self.config = ConfigObj(self.l11ll11l)
            self.config[l1l1l11 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1l1l11 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1l1l11 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1ll111l
            self.config[l1l1l11 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1l1l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1l1l11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l1l1l1
            self.config[l1l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l1l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l11ll1
            self.config[l1l1l11 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11ll11l)
            self.l1ll111l = self.get_value(l1l1l11 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1l1l11 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l1l1l1 = self.get_value(l1l1l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1l1l11 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l11ll1 = self.get_value(l1l1l11 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l1l11 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l11111(self):
        l1l11l11 = l1l1l11 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l11ll1
        l1l11l11 += l1l1l11 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l1l1l1
        l1l11l11 += l1l1l11 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1ll111l
        return l1l11l11
    def __unicode__(self):
        return self._1l11111()
    def __str__(self):
        return self._1l11111()
    def __del__(self):
        self.config.write()
l1l1ll11 = Settings(l1l111ll)