#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def l111l (l111l1l):
    global l1l1ll1
    l1l11l1 = ord (l111l1l [-1])
    l1lllll1 = l111l1l [:-1]
    l1l1l1 = l1l11l1 % len (l1lllll1)
    l1ll1lll = l1lllll1 [:l1l1l1] + l1lllll1 [l1l1l1:]
    if l11l11:
        l1llll1l = l111l1 () .join ([unichr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1llll1l = str () .join ([chr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1llll1l)
import hashlib
import os
import l1lll11l
from l1l11ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll11l import l11l1ll
from l1ll1l11 import l1111, l1llll11
import logging
logger = logging.getLogger(l111l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l11l():
    def __init__(self, l111lll,l1ll11l1, l1ll1ll1= None, l11111l=None):
        self.l1lll1l=False
        self.l1ll1ll = self._11l1()
        self.l1ll11l1 = l1ll11l1
        self.l1ll1ll1 = l1ll1ll1
        self.l1111ll = l111lll
        if l1ll1ll1:
            self.l1l1 = True
        else:
            self.l1l1 = False
        self.l11111l = l11111l
    def _11l1(self):
        try:
            return l1lll11l.l1llllll() is not None
        except:
            return False
    def open(self):
        l111l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll1ll:
            raise NotImplementedError(l111l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll1l = self.l1111ll
        if self.l1ll11l1.lower().startswith(self.l1111ll.lower()):
            l1lll1ll = re.compile(re.escape(self.l1111ll), re.IGNORECASE)
            l1ll11l1 = l1lll1ll.sub(l111l (u"ࠨࠩࠄ"), self.l1ll11l1)
            l1ll11l1 = l1ll11l1.replace(l111l (u"ࠩࡧࡥࡻ࠭ࠅ"), l111l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11(self.l1111ll, l1ll1l, l1ll11l1, self.l1ll1ll1)
    def l11(self,l1111ll, l1ll1l, l1ll11l1, l1ll1ll1):
        l111l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll11 = l1llll(l1111ll)
        l1l111 = self.l111l11(l1lll11)
        logger.info(l111l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll11)
        if l1l111:
            logger.info(l111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l1ll(l1lll11)
            l1lll11 = l111111(l1111ll, l1ll1l, l1ll1ll1, self.l11111l)
        logger.debug(l111l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1l1l=l1lll11 + l111l (u"ࠤ࠲ࠦࠌ") + l1ll11l1
        l1l = l111l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1l1l+ l111l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l)
        l11ll = os.system(l1l)
        if (l11ll != 0):
            raise IOError(l111l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1l1l, l11ll))
    def l111l11(self, l1lll11):
        if os.path.exists(l1lll11):
            if os.path.islink(l1lll11):
                l1lll11 = os.readlink(l1lll11)
            if os.path.ismount(l1lll11):
                return True
        return False
def l1llll(l1111ll):
    l11ll1l = l1111ll.replace(l111l (u"࠭࡜࡝ࠩࠐ"), l111l (u"ࠧࡠࠩࠑ")).replace(l111l (u"ࠨ࠱ࠪࠒ"), l111l (u"ࠩࡢࠫࠓ"))
    l1l11 = l111l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11llll=os.environ[l111l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll=os.path.join(l11llll,l1l11, l11ll1l)
    l1ll11l=os.path.abspath(l1lll)
    return l1ll11l
def l11ll1(l1l1ll):
    if not os.path.exists(l1l1ll):
        os.makedirs(l1l1ll)
def l1l1lll(l1111ll, l1ll1l, ll=None, password=None):
    l111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1l1ll = l1llll(l1111ll)
    l11ll1(l1l1ll)
    if not ll:
        l1lllll = l1()
        l11lll =l1lllll.l11l(l111l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll1l + l111l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll1l + l111l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11lll, str):
            ll, password = l11lll
        else:
            raise l1llll11()
        logger.info(l111l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1l1ll))
    l11111 = pwd.getpwuid( os.getuid())[0]
    l1ll11ll=os.environ[l111l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1llll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1l1l1l={l111l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11111, l111l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1111ll, l111l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1l1ll, l111l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11ll, l111l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):ll, l111l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1l1l1l, temp_file)
        if not os.path.exists(os.path.join(l1llll1, l111l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll111=l111l (u"ࠦࡵࡿࠢࠣ")
            key=l111l (u"ࠧࠨࠤ")
        else:
            l1ll111=l111l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111ll1=l111l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll111,temp_file.name)
        l11ll11=[l111l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1llll1, l111ll1)]
        p = subprocess.Popen(l11ll11, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1l1ll
    logger.debug(l111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11l=os.path.abspath(l1l1ll)
    logger.debug(l111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11l)
    return l1ll11l
def l111111(l1111ll, l1ll1l, l1ll1ll1, l11111l):
    l111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l1l1(title):
        l1111l=30
        if len(title)>l1111l:
            l11l111=title.split(l111l (u"ࠨ࠯ࠣ࠳"))
            l1111l1=l111l (u"ࠧࠨ࠴")
            for block in l11l111:
                l1111l1+=block+l111l (u"ࠣ࠱ࠥ࠵")
                if len(l1111l1) > l1111l:
                    l1111l1+=l111l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1111l1
        return title
    ll = l111l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l111l (u"ࠦࠧ࠸")
    os.system(l111l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l111ll = l1llll(l1111ll)
    l1l1ll = l1llll(hashlib.sha1(l1111ll.encode()).hexdigest()[:10])
    l11ll1(l1l1ll)
    logger.info(l111l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l1l1ll))
    if l1ll1ll1:
        l11l1l = [l111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l111l (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l111l (u"ࠤ࠰ࡸࠧ࠽"), l111l (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l111l (u"ࠫ࠲ࡵࠧ࠿"), l111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (ll, l1ll1ll1),
                    urllib.parse.unquote(l1ll1l), os.path.abspath(l1l1ll)]
    else:
        ll, password = l1l1l11(l1l1ll, l1ll1l, l11111l)
        if ll.lower() != l111l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l11l1l = [l111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111l (u"ࠤ࠰ࡸࠧࡄ"), l111l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111l (u"ࠫ࠲ࡵࠧࡆ"), l111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %ll,
                        urllib.parse.unquote(l1ll1l), os.path.abspath(l1l1ll)]
        else:
            raise l1llll11()
    logger.info(l111l (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l111l (u"ࠢࠡࠤࡉ").join(l11l1l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1l1111 = l111l (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1l1111.encode())
    if len(err) > 0:
        l1lll1l1 = l111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1lll1l1)
        raise l1111(l1lll1l1, l111111=l1lll11l.l1llllll(), l1ll1l=l1ll1l)
    logger.info(l111l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l111l (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l1l1ll, l111ll))
    l1ll11l=os.path.abspath(l111ll)
    return l1ll11l
def l1l1l11(l1111ll, l1ll1l, l11111l):
    l111 = os.path.join(os.environ[l111l (u"ࠧࡎࡏࡎࡇࠥࡎ")], l111l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l111l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l111)):
       os.makedirs(os.path.dirname(l111))
    l1ll11 = l11111l.get_value(l111l (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l111l (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1lllll = l1(l1111ll, l1ll11)
    ll, password = l1lllll.l11l(l111l (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1ll1l + l111l (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1ll1l + l111l (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if ll != l111l (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1lll111(l1111ll, ll):
        l1l111l = l111l (u"ࠢࠡࠤࡗ").join([l1111ll, ll, l111l (u"ࠨࠤࠪࡘ") + password + l111l (u"࡙ࠩࠥࠫ"), l111l (u"ࠪࡠࡳ࡚࠭")])
        with open(l111, l111l (u"ࠫࡼ࠱࡛ࠧ")) as l1ll1:
            l1ll1.write(l1l111l)
        os.chmod(l111, 0o600)
    return ll, password
def l1lll111(l1111ll, ll):
    l111 = l11l11l = os.path.join(os.environ[l111l (u"ࠧࡎࡏࡎࡇࠥ࡜")], l111l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l111l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l111):
        with open(l111, l111l (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l11lll1 = data[0].split(l111l (u"ࠤࠣࠦࡠ"))
            if l1111ll == l11lll1[0] and ll == l11lll1[1]:
                return True
    return False