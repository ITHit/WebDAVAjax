#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11ll1 import l1111ll
from configobj import ConfigObj
l11ll1ll = l1l11l (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l1llll = l1l11l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠶࠷࠱࠴ࠧࡢ")
l1l1l1l1 = l1l11l (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1l11l (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠵࠶࠰࠳ࠦࡤ")
l1l11111=os.path.join(os.environ.get(l1l11l (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1l11l (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l1l1l1.replace(l1l11l (u"ࠤࠣࠦࡧ"), l1l11l (u"ࠥࡣࠧࡨ")).lower())
l1l1ll1l=os.environ.get(l1l11l (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1l11l (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l11l1l=l1l1llll.replace(l1l11l (u"ࠨࠠࠣ࡫"), l1l11l (u"ࠢࡠࠤ࡬"))+l1l11l (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1l11l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1l111=os.path.join(os.environ.get(l1l11l (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l11l1l)
elif platform.system() == l1l11l (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11ll11l=l1111ll(l1l11111+l1l11l (u"ࠧ࠵ࠢࡱ"))
    l1l1l111 = os.path.join(l11ll11l, l1l11l1l)
else:
    l1l1l111 = os.path.join( l1l11l1l)
l1l1ll1l=l1l1ll1l.upper()
if l1l1ll1l == l1l11l (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11lll11=logging.DEBUG
elif l1l1ll1l == l1l11l (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11lll11 = logging.INFO
elif l1l1ll1l == l1l11l (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11lll11 = logging.WARNING
elif l1l1ll1l == l1l11l (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11lll11 = logging.ERROR
elif l1l1ll1l == l1l11l (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11lll11 = logging.CRITICAL
elif l1l1ll1l == l1l11l (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11lll11 = logging.NOTSET
logger = logging.getLogger(l1l11l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11lll11)
l1l1lll1 = logging.FileHandler(l1l1l111, mode=l1l11l (u"ࠨࡷࠬࠤࡹ"))
l1l1lll1.setLevel(l11lll11)
formatter = logging.Formatter(l1l11l (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1l11l (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l1lll1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll11)
l1ll111l = SysLogHandler(address=l1l11l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1ll111l.setFormatter(formatter)
logger.addHandler(l1l1lll1)
logger.addHandler(ch)
logger.addHandler(l1ll111l)
class Settings():
    l11lllll = l1l11l (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l1111l = l1l11l (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l111ll = l1l11l (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l1llll):
        self.l1l11l11 = self._1l1l1ll(l1l1llll)
        self._1ll1111()
    def _1l1l1ll(self, l1l1llll):
        l1l11ll1 = l1l1llll.split(l1l11l (u"ࠨࠠࠣࢀ"))
        l1l11ll1 = l1l11l (u"ࠢࠡࠤࢁ").join(l1l11ll1)
        if platform.system() == l1l11l (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l11l11 = os.path.join(l1l11111, l1l11l (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l11ll1 + l1l11l (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l11l11
    def l1l11lll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1l11l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l11l (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l11l (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11llll1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1ll1111(self):
        if not os.path.exists(os.path.dirname(self.l1l11l11)):
            os.makedirs(os.path.dirname(self.l1l11l11))
        if not os.path.exists(self.l1l11l11):
            self.config = ConfigObj(self.l1l11l11)
            self.config[l1l11l (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1l11l (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1l11l (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l111ll
            self.config[l1l11l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1l11l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l1111l
            self.config[l1l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l11lllll
            self.config[l1l11l (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11l11)
            self.l1l111ll = self.get_value(l1l11l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1l11l (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l1111l = self.get_value(l1l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1l11l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l11lllll = self.get_value(l1l11l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l11l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11lll1l(self):
        l1l1ll11 = l1l11l (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l11lllll
        l1l1ll11 += l1l11l (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l1111l
        l1l1ll11 += l1l11l (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l111ll
        return l1l1ll11
    def __unicode__(self):
        return self._11lll1l()
    def __str__(self):
        return self._11lll1l()
    def __del__(self):
        self.config.write()
l1l111l1 = Settings(l1l1llll)