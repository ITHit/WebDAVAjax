#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l1 = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1l1l = 7
def l1ll1 (l11l1l1):
    global l1lll11
    l111l11 = ord (l11l1l1 [-1])
    l1111l1 = l11l1l1 [:-1]
    l1l1ll = l111l11 % len (l1111l1)
    l1l1l1 = l1111l1 [:l1l1ll] + l1111l1 [l1l1ll:]
    if l1lll1l1:
        l1111l = l11ll11 () .join ([unichr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    return eval (l1111l)
import hashlib
import os
import l1ll11l
from l1lll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll11l import l11l111
from l1ll1lll import l1111, l1l111
import logging
logger = logging.getLogger(l1ll1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111l():
    def __init__(self, l11l11,l1ll1ll, l1lllll= None, l1l=None):
        self.l1l11=False
        self.l1ll11l1 = self._11ll1()
        self.l1ll1ll = l1ll1ll
        self.l1lllll = l1lllll
        self.l1l1l = l11l11
        if l1lllll:
            self.l111111 = True
        else:
            self.l111111 = False
        self.l1l = l1l
    def _11ll1(self):
        try:
            return l1ll11l.l11() is not None
        except:
            return False
    def open(self):
        l1ll1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1ll11l1:
            raise NotImplementedError(l1ll1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1ll1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1111ll = self.l1l1l
        if self.l1ll1ll.lower().startswith(self.l1l1l.lower()):
            l111ll = re.compile(re.escape(self.l1l1l), re.IGNORECASE)
            l1ll1ll = l111ll.sub(l1ll1 (u"ࠨࠩࠄ"), self.l1ll1ll)
            l1ll1ll = l1ll1ll.replace(l1ll1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1ll1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11lll1(self.l1l1l, l1111ll, l1ll1ll, self.l1lllll)
    def l11lll1(self,l1l1l, l1111ll, l1ll1ll, l1lllll):
        l1ll1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1ll1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll = l11111l(l1l1l)
        l1ll11 = self.l1llllll(l1lll)
        logger.info(l1ll1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll)
        if l1ll11:
            logger.info(l1ll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11l111(l1lll)
            l1lll = l1ll(l1l1l, l1111ll, l1lllll, self.l1l)
        logger.debug(l1ll1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1ll1=l1lll + l1ll1 (u"ࠤ࠲ࠦࠌ") + l1ll1ll
        l1l11l = l1ll1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1ll1+ l1ll1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l11l)
        l11lll = os.system(l1l11l)
        if (l11lll != 0):
            raise IOError(l1ll1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1ll1, l11lll))
    def l1llllll(self, l1lll):
        if os.path.exists(l1lll):
            if os.path.islink(l1lll):
                l1lll = os.readlink(l1lll)
            if os.path.ismount(l1lll):
                return True
        return False
def l11111l(l1l1l):
    l11ll = l1l1l.replace(l1ll1 (u"࠭࡜࡝ࠩࠐ"), l1ll1 (u"ࠧࡠࠩࠑ")).replace(l1ll1 (u"ࠨ࠱ࠪࠒ"), l1ll1 (u"ࠩࡢࠫࠓ"))
    l1l1l11 = l1ll1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l1ll1=os.environ[l1ll1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1lll111=os.path.join(l1l1ll1,l1l1l11, l11ll)
    l1lllll1=os.path.abspath(l1lll111)
    return l1lllll1
def l1l11l1(l11l11l):
    if not os.path.exists(l11l11l):
        os.makedirs(l11l11l)
def l11l1l(l1l1l, l1111ll, l111ll1=None, password=None):
    l1ll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l11l = l11111l(l1l1l)
    l1l11l1(l11l11l)
    if not l111ll1:
        l1l1lll = l111lll()
        l1llll =l1l1lll.l1lll11l(l1ll1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1111ll + l1ll1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1111ll + l1ll1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll, str):
            l111ll1, password = l1llll
        else:
            raise l1l111()
        logger.info(l1ll1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l11l))
    l11ll1l = pwd.getpwuid( os.getuid())[0]
    l1ll111=os.environ[l1ll1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll1l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11111={l1ll1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11ll1l, l1ll1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1l, l1ll1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l11l, l1ll1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll111, l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111ll1, l1ll1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11111, temp_file)
        if not os.path.exists(os.path.join(l1lll1l, l1ll1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1llll1=l1ll1 (u"ࠦࡵࡿࠢࠣ")
            key=l1ll1 (u"ࠧࠨࠤ")
        else:
            l1llll1=l1ll1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1ll1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l11=l1ll1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1llll1,temp_file.name)
        l1lll1ll=[l1ll1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1ll1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll1l, l1ll1l11)]
        p = subprocess.Popen(l1lll1ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1ll1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1ll1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1ll1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l11l
    logger.debug(l1ll1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1ll1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1ll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1ll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1lllll1=os.path.abspath(l11l11l)
    logger.debug(l1ll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1lllll1)
    return l1lllll1
def l1ll(l1l1l, l1111ll, l1lllll, l1l):
    l1ll1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1llll11(title):
        l1ll1l1=30
        if len(title)>l1ll1l1:
            l111=title.split(l1ll1 (u"ࠨ࠯ࠣ࠳"))
            l1llll1l=l1ll1 (u"ࠧࠨ࠴")
            for block in l111:
                l1llll1l+=block+l1ll1 (u"ࠣ࠱ࠥ࠵")
                if len(l1llll1l) > l1ll1l1:
                    l1llll1l+=l1ll1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1llll1l
        return title
    l111ll1 = l1ll1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1ll1 (u"ࠦࠧ࠸")
    os.system(l1ll1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l11l1ll = l11111l(l1l1l)
    l11l11l = l11111l(hashlib.sha1(l1l1l.encode()).hexdigest()[:10])
    l1l11l1(l11l11l)
    logger.info(l1ll1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11l11l))
    if l1lllll:
        l1l1l1l = [l1ll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1ll1 (u"ࠤ࠰ࡸࠧ࠽"), l1ll1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1ll1 (u"ࠫ࠲ࡵࠧ࠿"), l1ll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l111ll1, l1lllll),
                    urllib.parse.unquote(l1111ll), os.path.abspath(l11l11l)]
    else:
        l111ll1, password = l1l1(l11l11l, l1111ll, l1l)
        if l111ll1.lower() != l1ll1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1l1l1l = [l1ll1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1ll1 (u"ࠤ࠰ࡸࠧࡄ"), l1ll1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1ll1 (u"ࠫ࠲ࡵࠧࡆ"), l1ll1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l111ll1,
                        urllib.parse.unquote(l1111ll), os.path.abspath(l11l11l)]
        else:
            raise l1l111()
    logger.info(l1ll1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1ll1 (u"ࠢࠡࠤࡉ").join(l1l1l1l)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l11l = l1ll1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l11l.encode())
    if len(err) > 0:
        l11l1 = l1ll1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l11l1)
        raise l1111(l11l1, l1ll=l1ll11l.l11(), l1111ll=l1111ll)
    logger.info(l1ll1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1ll1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11l11l, l11l1ll))
    l1lllll1=os.path.abspath(l11l1ll)
    return l1lllll1
def l1l1(l1l1l, l1111ll, l1l):
    ll = os.path.join(os.environ[l1ll1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1ll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1ll1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(ll)):
       os.makedirs(os.path.dirname(ll))
    l1ll1l = l1l.get_value(l1ll1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1ll1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1l1lll = l111lll(l1l1l, l1ll1l)
    l111ll1, password = l1l1lll.l1lll11l(l1ll1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1111ll + l1ll1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1111ll + l1ll1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l111ll1 != l1ll1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1(l1l1l, l111ll1):
        l1ll11ll = l1ll1 (u"ࠢࠡࠤࡗ").join([l1l1l, l111ll1, l1ll1 (u"ࠨࠤࠪࡘ") + password + l1ll1 (u"࡙ࠩࠥࠫ"), l1ll1 (u"ࠪࡠࡳ࡚࠭")])
        with open(ll, l1ll1 (u"ࠫࡼ࠱࡛ࠧ")) as l11llll:
            l11llll.write(l1ll11ll)
        os.chmod(ll, 0o600)
    return l111ll1, password
def l1(l1l1l, l111ll1):
    ll = l111l1 = os.path.join(os.environ[l1ll1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1ll1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1ll1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(ll):
        with open(ll, l1ll1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1l111l = data[0].split(l1ll1 (u"ࠤࠣࠦࡠ"))
            if l1l1l == l1l111l[0] and l111ll1 == l1l111l[1]:
                return True
    return False