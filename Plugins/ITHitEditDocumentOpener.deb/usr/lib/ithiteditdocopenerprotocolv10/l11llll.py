#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1l11l1 = 2048
l1l = 7
def l1l11l (l1lll1l1):
    global l1l111l
    l1ll11ll = ord (l1lll1l1 [-1])
    l111ll1 = l1lll1l1 [:-1]
    l111l1 = l1ll11ll % len (l111ll1)
    l111111 = l111ll1 [:l111l1] + l111ll1 [l111l1:]
    if l1l1lll:
        l1111ll = l11l11 () .join ([unichr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    return eval (l1111ll)
import logging
import os
import re
from l1ll1l1l import l1llllll1
logger = logging.getLogger(l1l11l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1lll11l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l11l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll111l():
    try:
        out = os.popen(l1l11l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l11l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l11l (u"ࠤࠥॸ").join(result)
                logger.info(l1l11l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l11l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l11l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l11l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llllll1(l1l11l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l11l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1lll11l(l1l11l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))