#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11ll = sys.version_info [0] == 2
l1l111 = 2048
l1l1l1 = 7
def l11111l (l1ll11l):
    global l1l1lll
    l11ll11 = ord (l1ll11l [-1])
    l1l1111 = l1ll11l [:-1]
    l111ll = l11ll11 % len (l1l1111)
    l1ll1lll = l1l1111 [:l111ll] + l1l1111 [l111ll:]
    if l1l11ll:
        l1ll111 = l1ll1l1l () .join ([unichr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1ll111 = str () .join ([chr (ord (char) - l1l111 - (l1ll1l1 + l11ll11) % l1l1l1) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1ll111)
import logging
import os
import re
from l1llllll import l1lll1lll
logger = logging.getLogger(l11111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l11111l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11l1l():
    try:
        out = os.popen(l11111l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l11111l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l11111l (u"ࠤࠥॸ").join(result)
                logger.info(l11111l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l11111l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l11111l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l11111l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll1lll(l11111l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l11111l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1l1(l11111l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))