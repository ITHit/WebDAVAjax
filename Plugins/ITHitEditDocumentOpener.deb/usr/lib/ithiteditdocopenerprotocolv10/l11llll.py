#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import gi
gi.require_version(l1lll1l (u"࠭ࡇࡵ࡭ࠪ঻"), l1lll1l (u"ࠧ࠴࠰࠳়ࠫ"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11ll1ll
import logging
logger = logging.getLogger(l1lll1l (u"ࠣࡦࡲࡧࡺࡳࡥ࡯ࡶࡢࡳࡵ࡫࡮ࡦࡴ࠱࡫ࡺ࡯ࠢঽ"))
class l111ll1(Gtk.Window):
    def __init__(self, l1l1ll1l11, l1l1l1l111):
        Gtk.Window.__init__(self)
        self.l1111ll=30
        self.l1ll1ll1ll = False
        self.service = l1l1ll1l11
        self.l1ll11l=l1l1l1l111
        self.l111l11=l11ll1ll.l1l111l1
        self.l1l1lll1l1 = Gtk.ListStore(str)
        self.l1l11llll1()
    def l1l1l111ll(self, service):
        l1ll111lll = self.l111l11.l1l11l11(l1lll1l (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤা"), service)
        return l1ll111lll
    def l1l11llll1(self, l1l1ll1l11=None):
        if l1l1ll1l11:
            self.l1l1lll1l1.clear()
            l1ll1lll1l=self.l1l1l111ll(l1l1ll1l11)
            self.l1l1lll1l1.append([l1lll1l (u"ࠥࠦি")])
            for l1ll11l in l1ll1lll1l:
                self.l1l1lll1l1.append([l1ll11l])
        else:
            self.l1l1lll1l1.clear()
            self.l1l1lll1l1.append([l1lll1l (u"ࠦࡳࡵ࡬ࡰࡩ࡬ࡲࠧী")])
    def l1ll11ll1l(self, widget, data=None):
        l1l1ll1ll1= widget.get_active()
        if data == l1lll1l (u"ࠧ࠷ࠢু") and l1l1ll1ll1:
            self.l1l11llll1()
            self.l1l1ll11l1.set_active(0)
            self.l1l11ll111.set_text(l1lll1l (u"ࠨ࡮ࡰࡲࡤࡷࡸࠨূ"))
            self.l1l11ll111.set_sensitive(False)
            self.l1l1ll11l1.set_sensitive(False)
        else:
            self.l1l11llll1(l1l1ll1l11=self.service)
            self.l1l1ll11l1.set_active(0)
            self.l1l11ll111.set_text(l1lll1l (u"ࠢࠣৃ"))
            self.l1l1ll11l1.set_sensitive(True)
            self.l1l11ll111.set_sensitive(True)
    def l1ll1l1l1l(self, widget):
        if widget.get_active():
            l1ll11l = widget.get_child().get_text()
        else:
            l1ll11l = self.l1l1lll1l1[widget.get_active()][0]
        password = self.l1l1lll11l(self.service, l1ll11l)
        if password:
            self.l1l11ll111.set_text(password)
        else:
            self.l1l11ll111.set_text(l1lll1l (u"ࠣࠤৄ"))
    def l1ll1lllll(self, l1ll11l, pwd, service):
        keyring.set_password(service, l1ll11l, pwd)
        l1ll111lll=self.l111l11.l1l11l11(l1lll1l (u"ࠤࡏࡳ࡬࡯࡮ࡴࠤ৅"), service)
        if not l1ll11l in l1ll111lll:
            value = self.l111l11.get_value(l1lll1l (u"ࠥࡐࡴ࡭ࡩ࡯ࡵࠥ৆"), service)
            self.l111l11.l1l1111l(l1lll1l (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service,l1lll1l (u"ࠧࠫࡳࡽࠢࠨࡷࠥࢂࠢৈ")%(value, l1ll11l))
    def l1l1lll11l(self, service, l1ll11l):
        l1ll11lll1 = keyring.get_password(service, l1ll11l)
        return l1ll11lll1
    def l1ll111l1l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1ll1111ll(self, widget, data=None):
        self.l1ll1ll1ll=widget.get_active()
    def l1l11l1(self, message, title=l1lll1l (u"࠭ࠧ৉"), l1l111ll1=True):
        if l1l111ll1:
            l1l1lll1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1ll11ll11 = Gtk.MessageDialog(self,
            l1l1lll1ll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1ll11ll11.set_title(title)
        l1ll11ll11.set_default_response(Gtk.ResponseType.OK)
        l1l11l1lll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l11111 = Gtk.VBox()
        l1ll1lll11 = Gtk.Box(spacing=1)
        l1ll1lll11.set_homogeneous(False)
        l1ll1111l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1111l1.set_homogeneous(False)
        l1l1lll111 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lll111.set_homogeneous(False)
        l1ll1lll11.pack_start(l1ll1111l1, True, True, 0)
        l1ll1lll11.pack_start(l1l1lll111, True, True, 0)
        l1l1l1l11l = l1ll11ll11.get_content_area()
        l1l1l1ll11 = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l1l1l11l.pack_start(l1l1l1ll11, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll1ll11l = Gtk.Label()
        l1l11ll1l1 = Gtk.Label()
        l1l11ll1l1.set_text(l1lll1l (u"ࠢࠡࠤ৊")*5)
        vbox.pack_start(l1l11ll1l1, True, True, 0)
        l1ll1ll11l.set_text(l1lll1l (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵࠢࡄࡷ࠿ࠦࠢো"))
        l1ll1ll11l.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll1ll11l, 0, 1, 0, 1)
        l1l1llll1l = Gtk.RadioButton.new_with_label_from_widget(None, l1lll1l (u"ࠤࡊࡹࡪࡹࡴࠣৌ"))
        l1l1llll1l.connect(l1lll1l (u"ࠥࡸࡴ࡭ࡧ࡭ࡧࡧ্ࠦ"), self.l1ll11ll1l, l1lll1l (u"ࠦ࠶ࠨৎ"))
        table.attach(l1l1llll1l, 1, 2, 0, 1)
        l1ll111ll1 = Gtk.RadioButton.new_with_label_from_widget(l1l1llll1l, l1lll1l (u"ࠧࡘࡥࡨ࡫ࡶࡸࡪࡸࡥࡥࠢࡘࡷࡪࡸࠢ৏"))
        l1ll111ll1.connect(l1lll1l (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৐"), self.l1ll11ll1l, l1lll1l (u"ࠢ࠳ࠤ৑"))
        table.attach(l1ll111ll1, 1, 2, 1, 2)
        l1lll1111l = Gtk.Label()
        l1lll1111l.set_text(l1lll1l (u"ࠣࠢࠥ৒"))
        table.attach(l1lll1111l, 0, 1, 4, 6)
        l1l11l1l1l = Gtk.Label()
        l1l11l1l1l.set_text(l1lll1l (u"ࠤࡏࡳ࡬࡯࡮࠻ࠢࠥ৓"))
        l1l11l1l1l.set_justify(Gtk.Justification.RIGHT)
        l1l11l1l1l.set_alignment(xalign=1, yalign=0.5)
        self.l1l1ll11l1 = Gtk.ComboBox.new_with_model_and_entry(self.l1l1lll1l1)
        self.l1l1ll11l1.set_entry_text_column(0)
        table.attach(l1l11l1l1l, 0, 1, 6, 8)
        table.attach(self.l1l1ll11l1, 1, 3, 6, 8)
        self.l1l1ll11l1.connect(l1lll1l (u"ࠥࡧ࡭ࡧ࡮ࡨࡧࡧࠦ৔"), self.l1ll1l1l1l)
        l1ll1llll1 = Gtk.Label()
        l1ll1llll1.set_text(l1lll1l (u"ࠦࡕࡧࡳࡴࡹࡲࡶࡩࡀࠠࠣ৕"))
        l1ll1llll1.set_justify(Gtk.Justification.RIGHT)
        l1ll1llll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l11ll111 = Gtk.Entry()
        self.l1l11ll111.set_visibility(False)
        self.l1l11ll111.connect(l1lll1l (u"ࠧࡧࡣࡵ࡫ࡹࡥࡹ࡫ࠢ৖"), self.l1ll111l1l, l1ll11ll11)
        table.attach(l1ll1llll1, 0, 1, 8, 10)
        table.attach(self.l1l11ll111, 1, 3, 8, 10)
        l1l11ll1ll = Gtk.CheckButton(l1lll1l (u"ࠨࡓࡢࡸࡨࠤࡱࡵࡧࡪࡰࠣࡥࡳࡪࠠࡱࡣࡶࡷࡼࡵࡲࡥࠤৗ"))
        l1l11ll1ll.connect(l1lll1l (u"ࠢࡵࡱࡪ࡫ࡱ࡫ࡤࠣ৘"), self.l1ll1111ll, l1l11ll1ll)
        l1l11ll1ll.set_active(False)
        table.attach(l1l11ll1ll, 1, 3, 12, 14)
        l1l1ll1l1l = Gtk.Label()
        l1l1ll1l1l.set_text(l1lll1l (u"ࠣࠢࠥ৙") * 5)
        l1l1l11111.pack_start(l1l1ll1l1l, True, True, 0)
        if self.l1ll11l:
            l1ll111ll1.set_active(True)
            self.l1l1ll11l1.set_active(0)
            self.l1l1ll11l1.set_sensitive(True)
            self.l1l11ll111.set_text(l1lll1l (u"ࠤࠥ৚"))
            self.l1l11ll111.set_sensitive(True)
        else:
            self.l1l1ll11l1.set_active(0)
            self.l1l1ll11l1.set_sensitive(False)
            self.l1l11ll111.set_text(l1lll1l (u"ࠥࡲࡴࡶࡡࡴࡵࠥ৛"))
            self.l1l11ll111.set_sensitive(False)
        l1l11l1lll.pack_start(vbox, True, True, 0)
        l1l11l1lll.pack_start(table, True, True, 0)
        l1l11l1lll.pack_end(l1l1l11111, True, True, 0)
        l1l1l1ll11.pack_start(l1l11l1lll, True, True, 0)
        l1ll11ll11.show_all()
        response = l1ll11ll11.run()
        if self.l1l1ll11l1.get_active():
            l1ll11l = self.l1l1ll11l1.get_child().get_text()
        else:
            l1ll11l = self.l1l1lll1l1[self.l1l1ll11l1.get_active()][0]
        pwd = self.l1l11ll111.get_text()
        l1ll11ll11.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll1ll1ll:
                self.l1ll1lllll(l1ll11l, pwd, self.service)
            return l1ll11l, pwd
        else:
            return l1lll1l (u"ࠦࡈࡧ࡮ࡤࡧ࡯ࠦড়"), l1lll1l (u"ࠬ࠭ঢ়")
class l11l11ll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1ll1l1ll1(self, l11lll1l):
        l1l1l1111l = Gtk.ScrolledWindow()
        l1l1l1111l.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1ll1l11ll=None
        self.l1ll11l1ll = Gtk.TextBuffer()
        self.l1ll11l1ll.set_text(l11lll1l)
        self.set_style()
        regexp= l1lll1l (u"ࡸࠢࠩࡪࡷࡸࡵࡀ࠮ࠬࡁࠬࡠࡸࢂࠨࡩࡶࡷࡴࡸࡀ࠮ࠬࡁࠬࡠࡸࠨ৞")
        l1ll111l11 = self._1ll1ll1l1(l11lll1l, regexp)
        self.l1ll11l11l(l1ll111l11, self.l1ll11l1ll.get_start_iter())
        self.l1l1l11l1l = Gtk.TextView(buffer=self.l1ll11l1ll)
        self.l1l1l11l1l.set_property(l1lll1l (u"ࠧࡦࡦ࡬ࡸࡦࡨ࡬ࡦࠩয়"), False)
        self.l1l1l11l1l.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l11l1l.connect(l1lll1l (u"ࠣ࡯ࡲࡸ࡮ࡵ࡮ࡠࡰࡲࡸ࡮࡬ࡹࡠࡧࡹࡩࡳࡺࠢৠ"), self._1lll11111)
        self.l1l1l11l1l.set_wrap_mode(Gtk.WrapMode.WORD)
        l1l1l1111l.set_size_request(300,100)
        self.l1l1l11l1l.show()
        l1l1l1111l.add(self.l1l1l11l1l)
        l1l1l1111l.show()
        return l1l1l1111l
    def _1lll11111(self, *args, **kwargs):
        l1l1l1ll1l, l1ll11111l=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l1ll1l, l1ll11111l).get_tags()
        if not self.l1ll1l11ll:
            self.l1ll1l11ll = args[1].window.get_cursor()
            self.l1l1l11lll = Gdk.Cursor(Gdk.CursorType.l1l1l1l1l1)
        elif tag:
            args[1].window.set_cursor(self.l1l1l11lll)
        elif not tag:
            if args[1].window.get_cursor() != self.l1ll1l11ll:
                args[1].window.set_cursor(self.l1ll1l11ll)
    def _1ll1ll1l1(self, l11lll1l, l1l11ll11l):
        res=[]
        l1ll1ll111=re.findall(l1l11ll11l,l11lll1l)
        for l1ll111111 in l1ll1ll111:
            for el in l1ll111111:
                if el:
                    res.append(el)
        return res
    def l1ll11l11l(self, l1ll111l11, start):
        l1l1l11ll1=0
        for text in l1ll111l11:
            end = self.l1ll11l1ll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1l11ll1+=1
                l1l1ll1lll, l1l1ll1111 = match
                tag = self.l1ll11l1ll.create_tag(str(l1l1l11ll1), foreground=l1lll1l (u"ࠤࠦ࠴࠵࠶࠰ࡇࡈࠥৡ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1lll1l (u"ࠪࡩࡻ࡫࡮ࡵࠩৢ"), self._1l1l1l1ll, text)
                self.l1ll11l1ll.apply_tag(tag, l1l1ll1lll, l1l1ll1111)
                self.l1ll11l11l(l1ll111l11, l1l1ll1111)
    def _1l1l1l1ll(self, tag, widget, l1l1ll111l, _1ll1l1111, text):
        _1l1l1llll = l1l1ll111l.type
        _1ll11l111 = l1l1ll111l.window
        if _1l1l1llll == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l1llll in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l1ll111l.button
            self.l1ll1l11ll = Gdk.Cursor(Gdk.CursorType.l1l1l1l1l1)
            if _1l1l1llll == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1lll1l (u"ࠫࡽࡪࡧ࠮ࡱࡳࡩࡳ࠭ৣ"), text])
    def l1ll11111(self, message, title=l1lll1l (u"ࠬ࠭৤"), l1l111ll1=True, l1ll11llll=None):
        if l1l111ll1:
            l1l1lll1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1lll1ll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll11llll:
            l1l1l1l11l = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll1lll11 = Gtk.HBox(spacing=0)
            l1l1ll11ll = Gtk.HBox(spacing=5)
            l1l1l111l1 = Gtk.Label()
            l1l1l111l1.set_markup(l1lll1l (u"ࠨࡅ࡙ࡖࡈࡒࡉࠦࡉࡏࡈࡒࠦ৥"))
            l1l1l111l1.set_line_wrap(True)
            l1l1l111l1.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1lll1l (u"ࠢࠤࡆ࠶ࡈ࠸ࡊ࠳ࠣ০")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1ll1l1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l11.show()
            l1l11l1ll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11l1ll1.show()
            l1l1l1lll1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1lll1.show()
            l1ll1lll11.pack_start(separator, True, True, 0)
            l1ll1lll11.pack_start(l1ll1l1l11, True, True, 0)
            l1ll1lll11.pack_start(l1l11l1ll1, True, True, 0)
            l1ll1lll11.pack_start(l1l1l1lll1, True, True, 0)
            l1ll1lll11.pack_start(l1l1l111l1, False, True, 0)
            l1ll1l1lll = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1lll.show()
            l1ll1lll11.pack_end(l1ll1l1lll, True, True, 0)
            l1l11lll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lll1l.show()
            vbox.pack_start(l1ll1lll11, True, True, 0)
            l1l1l1111l=self.__1ll1l1ll1(l11lll1l=l1ll11llll)
            vbox.pack_start(l1l1l1111l, False, False, 0)
            vbox.pack_end(l1l11lll1l, False, False, 0)
            l1l1ll11ll.pack_start(vbox, True, True,5)
            l1l1ll11ll.show()
            l1l1l1l11l.pack_end(l1l1ll11ll, False, False, 0)
            vbox.show()
            l1ll1lll11.show()
        window.run()
class l1111111l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1ll1l111l(self, widget, l1l1llllll):
        if l1l1llllll == Gtk.ResponseType.OK:
            self.result = l1lll1l (u"ࠣࡑࡎࠦ১")
        elif l1l1llllll == Gtk.ResponseType.CANCEL:
            self.result = l1lll1l (u"ࠤࡆࡅࡓࡉࡅࡍࠤ২")
        elif l1l1llllll == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1lll1l (u"ࠥࡇࡆࡔࡃࡆࡎࠥ৩")
        widget.destroy()
    def l1111l11l(self, title=l1lll1l (u"ࠦࠧ৪"), message=l1lll1l (u"ࠧࠨ৫") , l1l111ll1=True):
        if l1l111ll1:
            l1l1lll1ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll1ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1lll1l (u"ࠨࡲࡦࡵࡳࡳࡳࡹࡥࠣ৬"), self.l1ll1l111l)
        window.run()
class l1l11lll11(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1l1llll11=None
        self.result = None
    def l1ll1l111l(self, widget, l1l1llllll):
        print(widget, l1l1llllll)
        if l1l1llllll == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1llllll == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1llllll == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1ll1111ll(self, widget, l1ll11l1l1):
        if l1ll11l1l1.get_active():
            self.l1l1llll11 = 1
        else:
            self.l1l1llll11 = 0
    def l1l1l11l11(self, title=l1lll1l (u"ࠢࠣ৭"), message=l1lll1l (u"ࠣࠤ৮"), l1l11lllll =l1lll1l (u"ࠤࠥ৯"),l1l111ll1=True):
        if l1l111ll1:
            l1l1lll1ll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1lll1ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1lll1ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1lll1l (u"ࠥࡶࡪࡹࡰࡰࡰࡶࡩࠧৰ"), self.l1ll1l111l)
        l1l11ll1ll = Gtk.CheckButton(l1l11lllll)
        l1l11ll1ll.connect(l1lll1l (u"ࠦࡹࡵࡧࡨ࡮ࡨࡨࠧৱ"), self.l1ll1111ll, l1l11ll1ll)
        l1l11ll1ll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l11ll1ll, expand=True, fill=True, padding=0)
        l1l11ll1ll.show()
        window.run()
def l1ll111ll(title, msg, l1l11lllll=l1lll1l (u"ࠧࡊ࡯ࠡࡰࡲࡸࠥࡹࡨࡰࡹࠣࡸ࡭࡯ࡳࠡ࡯ࡨࡷࡸࡧࡧࡦࠢࡤ࡫ࡦ࡯࡮ࠣ৲"),l1l111ll1=True):
    result=None
    try:
        l1ll1l11l1 = l1l11lll11()
        l1ll1l11l1.l1l1l11l11(title, msg, l1l11lllll, l1l111ll1)
        result = {l1lll1l (u"ࠨࡂࡶࡶࡷࡳࡳࠨ৳"):l1ll1l11l1.result,  l1lll1l (u"ࠢࡅࡱࡑࡳࡹ࡙ࡨࡰࡹࠥ৴"):l1ll1l11l1.l1l1llll11}
    except Exception as e:
        logger.exception(l1lll1l (u"ࠣࡅࡵࡩࡦࡺࡥࠡ࡯ࡥࡳࡽࠦࡥ࡯ࡦࡨࡨࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠥ৵"))
    return result
if __name__ == l1lll1l (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ৶"):
    l1ll1l111 = l11l11ll1()
    message= l1lll1l (u"ࠥࡉࡷࡵࡲࡳࠢࡌࠤࡦࡳࠠࡷࡧࡵࡽࠥࡲ࡯࡯ࡩࠣࡩࡱ࡫࡭ࡦࡰࡷࠦ৷")
    l1l1lllll1 = l1lll1l (u"࡙ࠦ࡮ࡥࠡ࠾ࡥࡂࡸ࡮࡯ࡸࠪࠬࡀ࠴ࡨ࠾ࠡ࡯ࡨࡸ࡭ࡵࡤࠡ࡞ࡱࡧࡦࡻࡳࡦࡵࠣࡥࠥࡽࡩࡥࡩࡨࡸࠥࡺ࡯ࠡࡤࡨࠤࡩ࡯ࡳࡱ࡮ࡤࡽࡪࡪࠠࡢࡵࠣࡷࡴࡵ࡮ࠡࡣࡶࠤࡵࡸࡡࡤࡶ࡬ࡧࡦࡲ࠮ࠡࡃࡱࡽࠥࡽࡩࡥࡩࡨࡸࠥࡺࡨࡢࡶࠣ࡭ࡸࡴࠧࡵࠢࡶ࡬ࡴࡽ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࠦࡴࡩࡧࠣࡷࡨࡸࡥࡦࡰ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡥࡱࡲࠠࡵࡪࡨࠤࡼ࡯ࡤࡨࡧࡷࡷࠥ࡯࡮ࠡࡣࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠲ࠠࡪࡶࠪࡷࠥ࡫ࡡࡴ࡫ࡨࡶࠥࡺ࡯ࠡࡥࡤࡰࡱࠦࡴࡩࡧࠣࡷ࡭ࡵࡷࡠࡣ࡯ࡰ࠭࠯ࠠࡰࡰࠣࡸ࡭࡫ࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠯ࠤ࡮ࡴࡳࡵࡧࡤࡨࠥࡵࡦࠡ࡫ࡱࡨ࡮ࡼࡩࡥࡷࡤࡰࡱࡿࠠࡴࡪࡲࡻ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡽࡩࡥࡩࡨࡸࡸ࠴ࠠࡐࡨࠣࡧࡴࡻࡲࡴࡧࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡺ࡯ࠡࡵ࡫ࡳࡼࠦࡴࡩࡧࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡦࠦࡷࡪࡦࡪࡩࡹ࠲ࠠࡢࡵࠣࡻࡪࡲ࡬ࠡࡣࡶࠤࡹ࡮ࡥࠡࡹ࡬ࡨ࡬࡫ࡴࠡ࡫ࡷࡷࡪࡲࡦ࠭ࠢࡥࡩ࡫ࡵࡲࡦࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡥࡵࡶࡥࡢࡴࠣࡳࡳࡹࡣࡳࡧࡨࡲ࠳ࠦࡗࡩࡧࡱࠤࡦࠦࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤ࡮ࡹࠠࡴࡪࡲࡻࡳ࠲ࠠࡪࡶࠣ࡭ࡸࠦࡩ࡮࡯ࡨࡨ࡮ࡧࡴࡦ࡮ࡼࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦ࠾ࠤࡴࡺࡨࡦࡴࠣࡷ࡭ࡵࡷ࡯ࠢࡺ࡭ࡩ࡭ࡥࡵࡵࠣࡥࡷ࡫ࠠࡳࡧࡤࡰ࡮ࢀࡥࡥࠢࡤࡲࡩࠦ࡭ࡢࡲࡳࡩࡩࠦࡷࡩࡧࡱࠤࡹ࡮ࡥࡪࡴࠣࡸࡴࡶ࡬ࡦࡸࡨࡰࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡡ࡭࡫ࡽࡩࡩࠦࡡ࡯ࡦࠣࡱࡦࡶࡰࡦࡦࠥ৸")
    l1ll1l111.l1ll11111(message, l1lll1l (u"ࠧࡺࡩࡵ࡮ࡨࠦ৹"), l1l111ll1=True, l1ll11llll=l1l1lllll1)