#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1ll = sys.version_info [0] == 2
l1lll1l = 2048
l11l11 = 7
def l1ll11l1 (l11l1ll):
    global l1l1ll
    l1l111l = ord (l11l1ll [-1])
    l11l11l = l11l1ll [:-1]
    l11ll = l1l111l % len (l11l11l)
    l1l111 = l11l11l [:l11ll] + l11l11l [l11ll:]
    if l1lll1ll:
        l11ll11 = l111ll1 () .join ([unichr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    return eval (l11ll11)
import re
class ll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1l1l = kwargs.get(l1ll11l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l1111 = kwargs.get(l1ll11l1 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll11ll = self.l11111l1(args)
        if l1lll11ll:
            args=args+ l1lll11ll
        self.args = [a for a in args]
    def l11111l1(self, *args):
        l1lll11ll=None
        l11ll1l1 = args[0][0]
        if re.search(l1ll11l1 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l11ll1l1):
            l1lll11ll = (l1ll11l1 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1l1l
                            ,)
        return l1lll11ll
class l1lll1ll1(Exception):
    def __init__(self, *args, **kwargs):
        l1lll11ll = self.l11111l1(args)
        if l1lll11ll:
            args = args + l1lll11ll
        self.args = [a for a in args]
    def l11111l1(self, *args):
        s = l1ll11l1 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1ll11l1 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1lll1lll(Exception):
    pass
class l111(Exception):
    pass
class l1llllll1(Exception):
    def __init__(self, message, l1llll11l, url):
        super(l1llllll1,self).__init__(message)
        self.l1llll11l = l1llll11l
        self.url = url
class l1111111(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l111111l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l1111ll1(Exception):
    pass