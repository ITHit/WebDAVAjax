#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l1l1ll1 (l11ll1):
    global l1llll1
    l1ll111 = ord (l11ll1 [-1])
    l1lll1 = l11ll1 [:-1]
    l1l1111 = l1ll111 % len (l1lll1)
    l1lll1l = l1lll1 [:l1l1111] + l1lll1 [l1l1111:]
    if l1:
        l111ll = l1ll1111 () .join ([unichr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    return eval (l111ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llllll11=logging.WARNING
logger = logging.getLogger(l1l1ll1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llllll11)
l1l11lll = SysLogHandler(address=l1l1ll1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1l1ll1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l11lll.setFormatter(formatter)
logger.addHandler(l1l11lll)
ch = logging.StreamHandler()
ch.setLevel(l1llllll11)
logger.addHandler(ch)
class l1llll111l(io.FileIO):
    l1l1ll1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1l1ll1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1lll111l1, l1lllllll1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll111l1 = l1lll111l1
            self.l1lllllll1 = l1lllllll1
            if not options:
                options = l1l1ll1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l1ll1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1lll111l1,
                                              self.l1lllllll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1111 = os.path.join(os.path.sep, l1l1ll1 (u"ࠪࡩࡹࡩࠧই"), l1l1ll1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1111l = path
        else:
            self._1lll1111l = self.l1llll1111
        super(l1llll111l, self).__init__(self._1lll1111l, l1l1ll1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll11111(self, line):
        return l1llll111l.Entry(*[x for x in line.strip(l1l1ll1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1l1ll1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l1ll1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1l1ll1 (u"ࠤࠦࠦ঍")):
                    yield self._1lll11111(line)
            except ValueError:
                pass
    def l1llll11l1(self, attr, value):
        for entry in self.entries:
            l1lll11l11 = getattr(entry, attr)
            if l1lll11l11 == value:
                return entry
        return None
    def l1lll111ll(self, entry):
        if self.l1llll11l1(l1l1ll1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1l1ll1 (u"ࠫࡡࡴࠧএ")).encode(l1l1ll1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1l1l(self, entry):
        self.seek(0)
        lines = [l.decode(l1l1ll1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l1ll1 (u"ࠢࠤࠤ঒")):
                if self._1lll11111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l1ll1 (u"ࠨࠩও").join(lines).encode(l1l1ll1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll11l1l(cls, l1lll111l1, path=None):
        l1lll1llll = cls(path=path)
        entry = l1lll1llll.l1llll11l1(l1l1ll1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1lll111l1)
        if entry:
            return l1lll1llll.l1llll1l1l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll111l1, l1lllllll1, options=None, path=None):
        return cls(path=path).l1lll111ll(l1llll111l.Entry(device,
                                                    l1lll111l1, l1lllllll1,
                                                    options=options))
class l1llll11ll(object):
    def __init__(self, l1lllll111):
        self.l1lll1l111=l1l1ll1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll11lll=l1l1ll1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll111=l1lllll111
        self.l1llll1lll()
        self.l1llll1l11()
        self.l1lll1l11l()
        self.l1lll1ll11()
        self.l1llll1ll1()
    def l1llll1lll(self):
        temp_file=open(l1lllll1ll,l1l1ll1 (u"࠭ࡲࠨঘ"))
        l111111=temp_file.read()
        data=json.loads(l111111)
        self.user=data[l1l1ll1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1ll11l=data[l1l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1lll1l1=data[l1l1ll1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1ll1l=data[l1l1ll1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll11l=data[l1l1ll1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll1l1l1=data[l1l1ll1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1l11l(self):
        l1ll1ll1=os.path.join(l1l1ll1 (u"ࠨ࠯ࠣট"),l1l1ll1 (u"ࠢࡶࡵࡵࠦঠ"),l1l1ll1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1l1ll1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1l1ll1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1ll1ll1)
    def l1llll1ll1(self):
        logger.info(l1l1ll1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1lll1l1=os.path.join(self.l1ll1l,self.l1lll1l111)
        l1lll1l1ll = pwd.getpwnam(self.user).pw_uid
        l1lll11ll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1lll1l1):
            os.makedirs(l1lll1l1)
            os.system(l1l1ll1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1lll1l1))
            logger.debug(l1l1ll1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1lll1l1)
        else:
            logger.debug(l1l1ll1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1lll1l1)
        l1ll1ll1=os.path.join(l1lll1l1, self.l1lll11lll)
        print(l1ll1ll1)
        logger.debug(l1l1ll1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1ll1ll1)
        with open(l1ll1ll1, l1l1ll1 (u"ࠤࡺ࠯ࠧ঩")) as l1lll1ll1l:
            logger.debug(self.l1ll11l + l1l1ll1 (u"ࠪࠤࠬপ")+self.l1lllll11l+l1l1ll1 (u"ࠫࠥࠨࠧফ")+self.l1lll1l1l1+l1l1ll1 (u"ࠬࠨࠧব"))
            l1lll1ll1l.writelines(self.l1ll11l + l1l1ll1 (u"࠭ࠠࠨভ")+self.l1lllll11l+l1l1ll1 (u"ࠧࠡࠤࠪম")+self.l1lll1l1l1+l1l1ll1 (u"ࠨࠤࠪয"))
        os.chmod(l1ll1ll1, 0o600)
        os.chown(l1ll1ll1, l1lll1l1ll, l1lll11ll1)
    def l1llll1l11(self, l1lll1lll1=l1l1ll1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1l1ll1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1lll1 in groups:
            logger.info(l1l1ll1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1lll1))
        else:
            logger.warning(l1l1ll1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1lll1))
            l1l1=l1l1ll1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1lll1,self.user)
            logger.debug(l1l1ll1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l1)
            os.system(l1l1)
            logger.debug(l1l1ll1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll1ll11(self):
        logger.debug(l1l1ll1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1llll=l1llll111l()
        l1lll1llll.add(self.l1ll11l, self.l1lll1l1, l1lllllll1=l1l1ll1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1l1ll1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1l1ll1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll1ll = urllib.parse.unquote(sys.argv[1])
        if l1lllll1ll:
            l1llllll1l=l1llll11ll(l1lllll1ll)
        else:
            raise (l1l1ll1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1l1ll1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise