#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l11 = 7
def l1l111l (l11ll1):
    global l1l1l
    l11lll1 = ord (l11ll1 [-1])
    l111 = l11ll1 [:-1]
    l1l = l11lll1 % len (l111)
    l11lll = l111 [:l1l] + l111 [l1l:]
    if l1ll111:
        l1l11l1 = l11l11l () .join ([unichr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    return eval (l1l11l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1lll=logging.WARNING
logger = logging.getLogger(l1l111l (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll1lll)
l1ll1111 = SysLogHandler(address=l1l111l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1l111l (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1ll1111.setFormatter(formatter)
logger.addHandler(l1ll1111)
ch = logging.StreamHandler()
ch.setLevel(l1llll1lll)
logger.addHandler(ch)
class l1lll111l1(io.FileIO):
    l1l111l (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1l111l (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1ll1l, l1lll1llll,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll1l = l1lll1ll1l
            self.l1lll1llll = l1lll1llll
            if not options:
                options = l1l111l (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l111l (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1ll1l,
                                              self.l1lll1llll,
                                              self.options,
                                              self.d,
                                              self.p)
    l11111111 = os.path.join(os.path.sep, l1l111l (u"ࠨࡧࡷࡧࠬঅ"), l1l111l (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lllllll1 = path
        else:
            self._1lllllll1 = self.l11111111
        super(l1lll111l1, self).__init__(self._1lllllll1, l1l111l (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll11l1l(self, line):
        return l1lll111l1.Entry(*[x for x in line.strip(l1l111l (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1l111l (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l111l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1l111l (u"ࠢࠤࠤঋ")):
                    yield self._1lll11l1l(line)
            except ValueError:
                pass
    def l1lllll11l(self, attr, value):
        for entry in self.entries:
            l1lll1lll1 = getattr(entry, attr)
            if l1lll1lll1 == value:
                return entry
        return None
    def l1lll11lll(self, entry):
        if self.l1lllll11l(l1l111l (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1l111l (u"ࠩ࡟ࡲࠬ঍")).encode(l1l111l (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll1l1l1(self, entry):
        self.seek(0)
        lines = [l.decode(l1l111l (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l111l (u"ࠧࠩࠢঐ")):
                if self._1lll11l1l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l111l (u"࠭ࠧ঑").join(lines).encode(l1l111l (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l11l(cls, l1lll1ll1l, path=None):
        l1llll11l1 = cls(path=path)
        entry = l1llll11l1.l1lllll11l(l1l111l (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1ll1l)
        if entry:
            return l1llll11l1.l1lll1l1l1(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll1l, l1lll1llll, options=None, path=None):
        return cls(path=path).l1lll11lll(l1lll111l1.Entry(device,
                                                    l1lll1ll1l, l1lll1llll,
                                                    options=options))
class l1llll11ll(object):
    def __init__(self, l1llllll1l):
        self.l1llll1l11=l1l111l (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll1ll11=l1l111l (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llllll1l=l1llllll1l
        self.l1lll1l111()
        self.l1lll11ll1()
        self.l1llllll11()
        self.l1lll1l1ll()
        self.l1lllll1ll()
    def l1lll1l111(self):
        temp_file=open(l1lll111ll,l1l111l (u"ࠫࡷ࠭খ"))
        l1lll1l=temp_file.read()
        data=json.loads(l1lll1l)
        self.user=data[l1l111l (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1111ll=data[l1l111l (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11l111=data[l1l111l (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1llll11=data[l1l111l (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1llll111l=data[l1l111l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1llll1ll1=data[l1l111l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1llllll11(self):
        l1lll11l=os.path.join(l1l111l (u"ࠦ࠴ࠨঝ"),l1l111l (u"ࠧࡻࡳࡳࠤঞ"),l1l111l (u"ࠨࡳࡣ࡫ࡱࠦট"),l1l111l (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1l111l (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1lll11l)
    def l1lllll1ll(self):
        logger.info(l1l111l (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11l111=os.path.join(self.l1llll11,self.l1llll1l11)
        l1llll1l1l = pwd.getpwnam(self.user).pw_uid
        l1lllll111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l111):
            os.makedirs(l11l111)
            os.system(l1l111l (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11l111))
            logger.debug(l1l111l (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11l111)
        else:
            logger.debug(l1l111l (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11l111)
        l1lll11l=os.path.join(l11l111, self.l1lll1ll11)
        print(l1lll11l)
        logger.debug(l1l111l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1lll11l)
        with open(l1lll11l, l1l111l (u"ࠢࡸ࠭ࠥধ")) as l1llll1111:
            logger.debug(self.l1111ll + l1l111l (u"ࠨࠢࠪন")+self.l1llll111l+l1l111l (u"ࠩࠣࠦࠬ঩")+self.l1llll1ll1+l1l111l (u"ࠪࠦࠬপ"))
            l1llll1111.writelines(self.l1111ll + l1l111l (u"ࠫࠥ࠭ফ")+self.l1llll111l+l1l111l (u"ࠬࠦࠢࠨব")+self.l1llll1ll1+l1l111l (u"࠭ࠢࠨভ"))
        os.chmod(l1lll11l, 0o600)
        os.chown(l1lll11l, l1llll1l1l, l1lllll111)
    def l1lll11ll1(self, l1llllllll=l1l111l (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1l111l (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllllll in groups:
            logger.info(l1l111l (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llllllll))
        else:
            logger.warning(l1l111l (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llllllll))
            l1l1ll1=l1l111l (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llllllll,self.user)
            logger.debug(l1l111l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1l1ll1)
            os.system(l1l1ll1)
            logger.debug(l1l111l (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll1l1ll(self):
        logger.debug(l1l111l (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llll11l1=l1lll111l1()
        l1llll11l1.add(self.l1111ll, self.l11l111, l1lll1llll=l1l111l (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1l111l (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1l111l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll111ll = urllib.parse.unquote(sys.argv[1])
        if l1lll111ll:
            l1lll11l11=l1llll11ll(l1lll111ll)
        else:
            raise (l1l111l (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1l111l (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise