#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l1l1ll1 = 7
def l111lll (l11):
    global l111l1
    l1ll1l1 = ord (l11 [-1])
    l1lllll1 = l11 [:-1]
    l1l1111 = l1ll1l1 % len (l1lllll1)
    l1l11ll = l1lllll1 [:l1l1111] + l1lllll1 [l1l1111:]
    if l1ll111:
        l1ll11l1 = l1l11l1 () .join ([unichr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    else:
        l1ll11l1 = str () .join ([chr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    return eval (l1ll11l1)
import logging
import os
import re
from l1ll1l1l import l11111l1
logger = logging.getLogger(l111lll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1l111l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111lll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11llll():
    try:
        out = os.popen(l111lll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l111lll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l111lll (u"ࠤࠥॸ").join(result)
                logger.info(l111lll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l111lll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l111lll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l111lll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l11111l1(l111lll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l111lll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1l111l(l111lll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))