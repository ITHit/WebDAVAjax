#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l11 = sys.version_info [0] == 2
l1lll1 = 2048
l1l1l = 7
def l111l (l111l1l):
    global l1l1ll1
    l1l11l1 = ord (l111l1l [-1])
    l1lllll1 = l111l1l [:-1]
    l1l1l1 = l1l11l1 % len (l1lllll1)
    l1ll1lll = l1lllll1 [:l1l1l1] + l1lllll1 [l1l1l1:]
    if l11l11:
        l1llll1l = l111l1 () .join ([unichr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    else:
        l1llll1l = str () .join ([chr (ord (char) - l1lll1 - (l1ll1l1 + l1l11l1) % l1l1l) for l1ll1l1, char in enumerate (l1ll1lll)])
    return eval (l1llll1l)
import logging
import os
import re
from l1ll1l11 import l1llll1l1
logger = logging.getLogger(l111l (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l11l1ll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l111l (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llllll():
    try:
        out = os.popen(l111l (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l111l (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l111l (u"ࠢࠣॶ").join(result)
                logger.info(l111l (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l111l (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l111l (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l111l (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1l1(l111l (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l111l (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l11l1ll(l111l (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))