#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1111 = 7
def l111l (l1lll1l1):
    global l111ll
    l1ll11ll = ord (l1lll1l1 [-1])
    l1lll11 = l1lll1l1 [:-1]
    l1 = l1ll11ll % len (l1lll11)
    l111l1l = l1lll11 [:l1] + l1lll11 [l1:]
    if l1111:
        l1l111 = l11ll1l () .join ([unichr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    return eval (l1l111)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllll1l1=logging.WARNING
logger = logging.getLogger(l111l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lllll1l1)
l1l1l1ll = SysLogHandler(address=l111l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l111l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1l1ll.setFormatter(formatter)
logger.addHandler(l1l1l1ll)
ch = logging.StreamHandler()
ch.setLevel(l1lllll1l1)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l111l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l111l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1lll, l1llllll1l,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1lll = l1llll1lll
            self.l1llllll1l = l1llllll1l
            if not options:
                options = l111l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l111l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1lll,
                                              self.l1llllll1l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll1l = os.path.join(os.path.sep, l111l (u"ࠪࡩࡹࡩࠧই"), l111l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1llll1l11 = path
        else:
            self._1llll1l11 = self.l1lll1ll1l
        super(l1llll1l1l, self).__init__(self._1llll1l11, l111l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lllll11l(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l111l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l111l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l111l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l111l (u"ࠤࠦࠦ঍")):
                    yield self._1lllll11l(line)
            except ValueError:
                pass
    def l1lll111l1(self, attr, value):
        for entry in self.entries:
            l1llllll11 = getattr(entry, attr)
            if l1llllll11 == value:
                return entry
        return None
    def l1llll111l(self, entry):
        if self.l1lll111l1(l111l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l111l (u"ࠫࡡࡴࠧএ")).encode(l111l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lllll111(self, entry):
        self.seek(0)
        lines = [l.decode(l111l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l111l (u"ࠢࠤࠤ঒")):
                if self._1lllll11l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l111l (u"ࠨࠩও").join(lines).encode(l111l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l1l1(cls, l1llll1lll, path=None):
        l1lll1l111 = cls(path=path)
        entry = l1lll1l111.l1lll111l1(l111l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1lll)
        if entry:
            return l1lll1l111.l1lllll111(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1lll, l1llllll1l, options=None, path=None):
        return cls(path=path).l1llll111l(l1llll1l1l.Entry(device,
                                                    l1llll1lll, l1llllll1l,
                                                    options=options))
class l1lll11l1l(object):
    def __init__(self, l1lll11ll1):
        self.l1lllllll1=l111l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1ll11=l111l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll11ll1=l1lll11ll1
        self.l1lll11111()
        self.l1lll11l11()
        self.l1lll1111l()
        self.l1llll1111()
        self.l1llll1ll1()
    def l1lll11111(self):
        temp_file=open(l1llll11l1,l111l (u"࠭ࡲࠨঘ"))
        l1ll11l=temp_file.read()
        data=json.loads(l1ll11l)
        self.user=data[l111l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l1l11=data[l111l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1llllll=data[l111l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1lll1l=data[l111l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll1ll=data[l111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111ll=data[l111l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1111l(self):
        l1lll111=os.path.join(l111l (u"ࠨ࠯ࠣট"),l111l (u"ࠢࡶࡵࡵࠦঠ"),l111l (u"ࠣࡵࡥ࡭ࡳࠨড"),l111l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l111l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1lll111)
    def l1llll1ll1(self):
        logger.info(l111l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1llllll=os.path.join(self.l1lll1l,self.l1lllllll1)
        l1lll11lll = pwd.getpwnam(self.user).pw_uid
        l1lll1l11l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1llllll):
            os.makedirs(l1llllll)
            os.system(l111l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1llllll))
            logger.debug(l111l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1llllll)
        else:
            logger.debug(l111l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1llllll)
        l1lll111=os.path.join(l1llllll, self.l1lll1ll11)
        print(l1lll111)
        logger.debug(l111l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1lll111)
        with open(l1lll111, l111l (u"ࠤࡺ࠯ࠧ঩")) as l1lll1l1ll:
            logger.debug(self.l1l1l11 + l111l (u"ࠪࠤࠬপ")+self.l1lllll1ll+l111l (u"ࠫࠥࠨࠧফ")+self.l1lll111ll+l111l (u"ࠬࠨࠧব"))
            l1lll1l1ll.writelines(self.l1l1l11 + l111l (u"࠭ࠠࠨভ")+self.l1lllll1ll+l111l (u"ࠧࠡࠤࠪম")+self.l1lll111ll+l111l (u"ࠨࠤࠪয"))
        os.chmod(l1lll111, 0o600)
        os.chown(l1lll111, l1lll11lll, l1lll1l11l)
    def l1lll11l11(self, l1lll1llll=l111l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l111l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1llll in groups:
            logger.info(l111l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll1llll))
        else:
            logger.warning(l111l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll1llll))
            l1ll1l=l111l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll1llll,self.user)
            logger.debug(l111l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll1l)
            os.system(l1ll1l)
            logger.debug(l111l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1llll1111(self):
        logger.debug(l111l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l111=l1llll1l1l()
        l1lll1l111.add(self.l1l1l11, self.l1llllll, l1llllll1l=l111l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l111l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l111l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llll11l1 = urllib.parse.unquote(sys.argv[1])
        if l1llll11l1:
            l1lll1lll1=l1lll11l1l(l1llll11l1)
        else:
            raise (l111l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l111l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise