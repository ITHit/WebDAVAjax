#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1ll = sys.version_info [0] == 2
l1lll1l = 2048
l11l11 = 7
def l1ll11l1 (l11l1ll):
    global l1l1ll
    l1l111l = ord (l11l1ll [-1])
    l11l11l = l11l1ll [:-1]
    l11ll = l1l111l % len (l11l11l)
    l1l111 = l11l11l [:l11ll] + l11l11l [l11ll:]
    if l1lll1ll:
        l11ll11 = l111ll1 () .join ([unichr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    else:
        l11ll11 = str () .join ([chr (ord (char) - l1lll1l - (l1ll1 + l1l111l) % l11l11) for l1ll1, char in enumerate (l1l111)])
    return eval (l11ll11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll1llll=logging.WARNING
logger = logging.getLogger(l1ll11l1 (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll1llll)
l11ll11l = SysLogHandler(address=l1ll11l1 (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll11l1 (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll11l.setFormatter(formatter)
logger.addHandler(l11ll11l)
ch = logging.StreamHandler()
ch.setLevel(l1lll1llll)
logger.addHandler(ch)
class l1lll111ll(io.FileIO):
    l1ll11l1 (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll11l1 (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llllll11, l1lll1l111,
                     options, d=0, p=0):
            self.device = device
            self.l1llllll11 = l1llllll11
            self.l1lll1l111 = l1lll1l111
            if not options:
                options = l1ll11l1 (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll11l1 (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llllll11,
                                              self.l1lll1l111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lllll1l1 = os.path.join(os.path.sep, l1ll11l1 (u"ࠪࡩࡹࡩࠧই"), l1ll11l1 (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l11l = path
        else:
            self._1lll1l11l = self.l1lllll1l1
        super(l1lll111ll, self).__init__(self._1lll1l11l, l1ll11l1 (u"ࠬࡸࡢࠬࠩউ"))
    def _1llll111l(self, line):
        return l1lll111ll.Entry(*[x for x in line.strip(l1ll11l1 (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll11l1 (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll11l1 (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll11l1 (u"ࠤࠦࠦ঍")):
                    yield self._1llll111l(line)
            except ValueError:
                pass
    def l1lll1ll11(self, attr, value):
        for entry in self.entries:
            l1lll1111l = getattr(entry, attr)
            if l1lll1111l == value:
                return entry
        return None
    def l1llll1l1l(self, entry):
        if self.l1lll1ll11(l1ll11l1 (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll11l1 (u"ࠫࡡࡴࠧএ")).encode(l1ll11l1 (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1llll1lll(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll11l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll11l1 (u"ࠢࠤࠤ঒")):
                if self._1llll111l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll11l1 (u"ࠨࠩও").join(lines).encode(l1ll11l1 (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll11l1l(cls, l1llllll11, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1lll1ll11(l1ll11l1 (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llllll11)
        if entry:
            return l1llll1ll1.l1llll1lll(entry)
        return False
    @classmethod
    def add(cls, device, l1llllll11, l1lll1l111, options=None, path=None):
        return cls(path=path).l1llll1l1l(l1lll111ll.Entry(device,
                                                    l1llllll11, l1lll1l111,
                                                    options=options))
class l1lll11lll(object):
    def __init__(self, l1llllll1l):
        self.l1llll1111=l1ll11l1 (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll1l11=l1ll11l1 (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1llllll1l=l1llllll1l
        self.l1lll11l11()
        self.l1lllllll1()
        self.l1lll1ll1l()
        self.l1lllll111()
        self.l1lll11ll1()
    def l1lll11l11(self):
        temp_file=open(l1lll11111,l1ll11l1 (u"࠭ࡲࠨঘ"))
        l1ll1l1l=temp_file.read()
        data=json.loads(l1ll1l1l)
        self.user=data[l1ll11l1 (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1111l1=data[l1ll11l1 (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l111lll=data[l1ll11l1 (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l111111=data[l1ll11l1 (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lll1l1l1=data[l1ll11l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllll11l=data[l1ll11l1 (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1ll1l(self):
        l11111=os.path.join(l1ll11l1 (u"ࠨ࠯ࠣট"),l1ll11l1 (u"ࠢࡶࡵࡵࠦঠ"),l1ll11l1 (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll11l1 (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll11l1 (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l11111)
    def l1lll11ll1(self):
        logger.info(l1ll11l1 (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l111lll=os.path.join(self.l111111,self.l1llll1111)
        l1llll11l1 = pwd.getpwnam(self.user).pw_uid
        l1lll1lll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l111lll):
            os.makedirs(l111lll)
            os.system(l1ll11l1 (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l111lll))
            logger.debug(l1ll11l1 (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l111lll)
        else:
            logger.debug(l1ll11l1 (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l111lll)
        l11111=os.path.join(l111lll, self.l1llll1l11)
        print(l11111)
        logger.debug(l1ll11l1 (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l11111)
        with open(l11111, l1ll11l1 (u"ࠤࡺ࠯ࠧ঩")) as l1lll111l1:
            logger.debug(self.l1111l1 + l1ll11l1 (u"ࠪࠤࠬপ")+self.l1lll1l1l1+l1ll11l1 (u"ࠫࠥࠨࠧফ")+self.l1lllll11l+l1ll11l1 (u"ࠬࠨࠧব"))
            l1lll111l1.writelines(self.l1111l1 + l1ll11l1 (u"࠭ࠠࠨভ")+self.l1lll1l1l1+l1ll11l1 (u"ࠧࠡࠤࠪম")+self.l1lllll11l+l1ll11l1 (u"ࠨࠤࠪয"))
        os.chmod(l11111, 0o600)
        os.chown(l11111, l1llll11l1, l1lll1lll1)
    def l1lllllll1(self, l1lllll1ll=l1ll11l1 (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll11l1 (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lllll1ll in groups:
            logger.info(l1ll11l1 (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lllll1ll))
        else:
            logger.warning(l1ll11l1 (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lllll1ll))
            l1l1l1l=l1ll11l1 (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lllll1ll,self.user)
            logger.debug(l1ll11l1 (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1l1l1l)
            os.system(l1l1l1l)
            logger.debug(l1ll11l1 (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lllll111(self):
        logger.debug(l1ll11l1 (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1ll1=l1lll111ll()
        l1llll1ll1.add(self.l1111l1, self.l111lll, l1lll1l111=l1ll11l1 (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll11l1 (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll11l1 (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lll11111 = urllib.parse.unquote(sys.argv[1])
        if l1lll11111:
            l1lll1l1ll=l1lll11lll(l1lll11111)
        else:
            raise (l1ll11l1 (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll11l1 (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise