#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1 = sys.version_info [0] == 2
l1lll1l = 2048
l1llll = 7
def l111 (l1l1111):
    global l1l11l
    l1llllll = ord (l1l1111 [-1])
    l111111 = l1l1111 [:-1]
    l1ll1ll = l1llllll % len (l111111)
    l11l = l111111 [:l1ll1ll] + l111111 [l1ll1ll:]
    if l1ll1:
        l11l111 = l1ll11 () .join ([unichr (ord (char) - l1lll1l - (l1ll1lll + l1llllll) % l1llll) for l1ll1lll, char in enumerate (l11l)])
    else:
        l11l111 = str () .join ([chr (ord (char) - l1lll1l - (l1ll1lll + l1llllll) % l1llll) for l1ll1lll, char in enumerate (l11l)])
    return eval (l11l111)
import hashlib
import os
import l111l11
from l11l1ll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l111l11 import l1l111
from l1lll111 import l1l1ll, l1l11ll
import logging
logger = logging.getLogger(l111 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111lll():
    def __init__(self, l11l1l,l1lll, l1ll= None, ll=None):
        self.l1ll1l11=False
        self.l1111 = self._1lll1ll()
        self.l1lll = l1lll
        self.l1ll = l1ll
        self.l11ll11 = l11l1l
        if l1ll:
            self.l1 = True
        else:
            self.l1 = False
        self.ll = ll
    def _1lll1ll(self):
        try:
            return l111l11.l1lllll1() is not None
        except:
            return False
    def open(self):
        l111 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1111:
            raise NotImplementedError(l111 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1ll111 = self.l11ll11
        if self.l1lll.lower().startswith(self.l11ll11.lower()):
            l1lll1 = re.compile(re.escape(self.l11ll11), re.IGNORECASE)
            l1lll = l1lll1.sub(l111 (u"ࠨࠩࠄ"), self.l1lll)
            l1lll = l1lll.replace(l111 (u"ࠩࡧࡥࡻ࠭ࠅ"), l111 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l(self.l11ll11, l1ll111, l1lll, self.l1ll)
    def l1l(self,l11ll11, l1ll111, l1lll, l1ll):
        l111 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1lll1l1 = l11l11l(l11ll11)
        l11111 = self.l1ll111l(l1lll1l1)
        logger.info(l111 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1lll1l1)
        if l11111:
            logger.info(l111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l111(l1lll1l1)
            l1lll1l1 = l111ll(l11ll11, l1ll111, l1ll, self.ll)
        logger.debug(l111 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l1l1=l1lll1l1 + l111 (u"ࠤ࠲ࠦࠌ") + l1lll
        l11lll = l111 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l1l1+ l111 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11lll)
        l1111ll = os.system(l11lll)
        if (l1111ll != 0):
            raise IOError(l111 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l1l1, l1111ll))
    def l1ll111l(self, l1lll1l1):
        if os.path.exists(l1lll1l1):
            if os.path.islink(l1lll1l1):
                l1lll1l1 = os.readlink(l1lll1l1)
            if os.path.ismount(l1lll1l1):
                return True
        return False
def l11l11l(l11ll11):
    l1l11 = l11ll11.replace(l111 (u"࠭࡜࡝ࠩࠐ"), l111 (u"ࠧࡠࠩࠑ")).replace(l111 (u"ࠨ࠱ࠪࠒ"), l111 (u"ࠩࡢࠫࠓ"))
    l111l = l111 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1ll1111=os.environ[l111 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11ll1=os.path.join(l1ll1111,l111l, l1l11)
    l1l1lll=os.path.abspath(l11ll1)
    return l1l1lll
def l1ll1l1l(l111ll1):
    if not os.path.exists(l111ll1):
        os.makedirs(l111ll1)
def l1ll1ll1(l11ll11, l1ll111, l11ll1l=None, password=None):
    l111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111ll1 = l11l11l(l11ll11)
    l1ll1l1l(l111ll1)
    if not l11ll1l:
        l1l1l11 = l1111l1()
        l11ll =l1l1l11.l1l1l(l111 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1ll111 + l111 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1ll111 + l111 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11ll, str):
            l11ll1l, password = l11ll
        else:
            raise l1l11ll()
        logger.info(l111 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111ll1))
    l11l11 = pwd.getpwuid( os.getuid())[0]
    l1ll11l1=os.environ[l111 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11111l={l111 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11l11, l111 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll11, l111 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111ll1, l111 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11l1, l111 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11ll1l, l111 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11111l, temp_file)
        if not os.path.exists(os.path.join(l1l1, l111 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11=l111 (u"ࠦࡵࡿࠢࠣ")
            key=l111 (u"ࠧࠨࠤ")
        else:
            l11=l111 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1l1=l111 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11,temp_file.name)
        l1111l=[l111 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1, l1ll1l1)]
        p = subprocess.Popen(l1111l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111ll1
    logger.debug(l111 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1lll=os.path.abspath(l111ll1)
    logger.debug(l111 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1lll)
    return l1l1lll
def l111ll(l11ll11, l1ll111, l1ll, ll):
    l111 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11llll(title):
        l1ll11l=30
        if len(title)>l1ll11l:
            l1lll11=title.split(l111 (u"ࠨ࠯ࠣ࠳"))
            l1lllll=l111 (u"ࠧࠨ࠴")
            for block in l1lll11:
                l1lllll+=block+l111 (u"ࠣ࠱ࠥ࠵")
                if len(l1lllll) > l1ll11l:
                    l1lllll+=l111 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lllll
        return title
    def l111l1(l1l11l1, password):
        l111 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111 (u"ࠧࠦࠢ࠹").join(l1l11l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1llll1l = l111 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1llll1l.encode())
        l1ll11ll = [l111 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l1l1l = l111 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l1l1l)
            for e in l1ll11ll:
                if e in l1l1l1l: return False
            raise l1l1ll(l1l1l1l, l111ll=l111l11.l1lllll1(), l1ll111=l1ll111)
        logger.info(l111 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11ll1l = l111 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111 (u"ࠦࠧ࠿")
    os.system(l111 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1llll1 = l11l11l(l11ll11)
    l111ll1 = l11l11l(hashlib.sha1(l11ll11.encode()).hexdigest()[:10])
    l1ll1l1l(l111ll1)
    logger.info(l111 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111ll1))
    if l1ll:
        l1l11l1 = [l111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111 (u"ࠤ࠰ࡸࠧࡄ"), l111 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111 (u"ࠫ࠲ࡵࠧࡆ"), l111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11ll1l, l1ll),
                    urllib.parse.unquote(l1ll111), os.path.abspath(l111ll1)]
        l111l1(l1l11l1, password)
    else:
        while True:
            l11ll1l, password = l1l111l(l111ll1, l1ll111, ll)
            if l11ll1l.lower() != l111 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1l11l1 = [l111 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111 (u"ࠤ࠰ࡸࠧࡋ"), l111 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111 (u"ࠫ࠲ࡵࠧࡍ"), l111 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11ll1l,
                            urllib.parse.unquote(l1ll111), os.path.abspath(l111ll1)]
            else:
                raise l1l11ll()
            if l111l1(l1l11l1, password): break
    os.system(l111 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111ll1, l1llll1))
    l1l1lll=os.path.abspath(l1llll1)
    return l1l1lll
def l1l111l(l11ll11, l1ll111, ll):
    l1l1ll1 = os.path.join(os.environ[l111 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l1ll1)):
       os.makedirs(os.path.dirname(l1l1ll1))
    l1lll11l = ll.get_value(l111 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l1l11 = l1111l1(l11ll11, l1lll11l)
    l11ll1l, password = l1l1l11.l1l1l(l111 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1ll111 + l111 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1ll111 + l111 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11ll1l != l111 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111l1l(l11ll11, l11ll1l):
        l1llll11 = l111 (u"ࠤ࡙ࠣࠦ").join([l11ll11, l11ll1l, l111 (u"࡚ࠪࠦࠬ") + password + l111 (u"࡛ࠫࠧ࠭"), l111 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l1ll1, l111 (u"࠭ࡷࠬࠩ࡝")) as l11lll1:
            l11lll1.write(l1llll11)
        os.chmod(l1l1ll1, 0o600)
    return l11ll1l, password
def l111l1l(l11ll11, l11ll1l):
    l1l1ll1 = l1ll1l = os.path.join(os.environ[l111 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l1ll1):
        with open(l1l1ll1, l111 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l1 = data[0].split(l111 (u"ࠦࠥࠨࡢ"))
            if l11ll11 == l11l1[0] and l11ll1l == l11l1[1]:
                return True
    return False