#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l11l1 = 2048
l1l111l = 7
def l1ll1l1l (l11ll1l):
    global l1l11
    l1 = ord (l11ll1l [-1])
    l1lll = l11ll1l [:-1]
    l1lllll = l1 % len (l1lll)
    l1lll11 = l1lll [:l1lllll] + l1lll [l1lllll:]
    if l1l1ll1:
        l1l11l = l111l11 () .join ([unichr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    else:
        l1l11l = str () .join ([chr (ord (char) - l11l1 - (l1l1l1l + l1) % l1l111l) for l1l1l1l, char in enumerate (l1lll11)])
    return eval (l1l11l)
import logging
import os
import re
from l1ll1lll import l1lll11ll
logger = logging.getLogger(l1ll1l1l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1111l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1l1l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l1l():
    try:
        out = os.popen(l1ll1l1l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll1l1l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll1l1l (u"ࠤࠥॸ").join(result)
                logger.info(l1ll1l1l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll1l1l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll1l1l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll1l1l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1lll11ll(l1ll1l1l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll1l1l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1111l(l1ll1l1l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))