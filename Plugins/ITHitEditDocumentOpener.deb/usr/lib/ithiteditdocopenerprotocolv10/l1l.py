#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llllll = sys.version_info [0] == 2
l11ll1 = 2048
l1111ll = 7
def l1ll1l1 (l11ll11):
    global l1lll11
    l1lll111 = ord (l11ll11 [-1])
    l1ll11l1 = l11ll11 [:-1]
    l11l111 = l1lll111 % len (l1ll11l1)
    l1llll1 = l1ll11l1 [:l11l111] + l1ll11l1 [l11l111:]
    if l1llllll:
        l1lll1l = l1l1l1 () .join ([unichr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    else:
        l1lll1l = str () .join ([chr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    return eval (l1lll1l)
import re
class l11l1ll(Exception):
    def __init__(self, *args,**kwargs):
        self.l11111ll = kwargs.get(l1ll1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11l1l = kwargs.get(l1ll1l1 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1llll11l = self.l1llll111(args)
        if l1llll11l:
            args=args+ l1llll11l
        self.args = [a for a in args]
    def l1llll111(self, *args):
        l1llll11l=None
        l1l1111l = args[0][0]
        if re.search(l1ll1l1 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l1111l):
            l1llll11l = (l1ll1l1 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l11111ll
                            ,)
        return l1llll11l
class l1lllllll(Exception):
    def __init__(self, *args, **kwargs):
        l1llll11l = self.l1llll111(args)
        if l1llll11l:
            args = args + l1llll11l
        self.args = [a for a in args]
    def l1llll111(self, *args):
        s = l1ll1l1 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1ll1l1 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1llllll1(Exception):
    pass
class l1lll1l1(Exception):
    pass
class l1lll1lll(Exception):
    def __init__(self, message, l1llll1ll, url):
        super(l1lll1lll,self).__init__(message)
        self.l1llll1ll = l1llll1ll
        self.url = url
class l1111l11(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1111ll1(Exception):
    pass
class l111111l(Exception):
    pass
class l1111l1l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllll11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1111111(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l11l11l1(Exception):
    pass