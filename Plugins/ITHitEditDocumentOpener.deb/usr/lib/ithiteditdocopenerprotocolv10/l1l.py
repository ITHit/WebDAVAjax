#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1ll = 7
def l11ll11 (l1lll11l):
    global l1ll
    l1l1ll1 = ord (l1lll11l [-1])
    l11l1l1 = l1lll11l [:-1]
    l111ll1 = l1l1ll1 % len (l11l1l1)
    l11lll = l11l1l1 [:l111ll1] + l11l1l1 [l111ll1:]
    if l1l1l:
        l1lll = l111111 () .join ([unichr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    return eval (l1lll)
import re
class l1lllll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllll1l = kwargs.get(l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11lll1 = kwargs.get(l11ll11 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1lllll11 = self.l1llll1ll(args)
        if l1lllll11:
            args=args+ l1lllll11
        self.args = [a for a in args]
    def l1llll1ll(self, *args):
        l1lllll11=None
        l11lll11 = args[0][0]
        if re.search(l11ll11 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l11lll11):
            l1lllll11 = (l11ll11 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1lllll1l
                            ,)
        return l1lllll11
class l1llll1l1(Exception):
    def __init__(self, *args, **kwargs):
        l1lllll11 = self.l1llll1ll(args)
        if l1lllll11:
            args = args + l1lllll11
        self.args = [a for a in args]
    def l1llll1ll(self, *args):
        s = l11ll11 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l11ll11 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1llll111(Exception):
    pass
class l11111(Exception):
    pass
class l11111ll(Exception):
    def __init__(self, message, l1llllll1, url):
        super(l11111ll,self).__init__(message)
        self.l1llllll1 = l1llllll1
        self.url = url
class l1111l1l(Exception):
    pass
class l1111ll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l111111l(Exception):
    pass
class l1111111(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llll11l(Exception):
    pass
class l11l1ll1(Exception):
    pass