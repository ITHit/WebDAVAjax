#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l11l1 (l1llll11):
    global l11l11l
    l1l1l1l = ord (l1llll11 [-1])
    l1llll1l = l1llll11 [:-1]
    l111ll = l1l1l1l % len (l1llll1l)
    l1l11 = l1llll1l [:l111ll] + l1llll1l [l111ll:]
    if l1l11l:
        l11ll1l = l1111 () .join ([unichr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    return eval (l11ll1l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll11ll=logging.WARNING
logger = logging.getLogger(l11l1 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll11ll)
l1l111l1 = SysLogHandler(address=l11l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l11l1 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l111l1.setFormatter(formatter)
logger.addHandler(l1l111l1)
ch = logging.StreamHandler()
ch.setLevel(l1llll11ll)
logger.addHandler(ch)
class l1llll1l1l(io.FileIO):
    l11l1 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l11l1 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1llll, l1lll1l11l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1llll = l1lll1llll
            self.l1lll1l11l = l1lll1l11l
            if not options:
                options = l11l1 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11l1 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1llll,
                                              self.l1lll1l11l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lllll1l1 = os.path.join(os.path.sep, l11l1 (u"ࠨࡧࡷࡧࠬঅ"), l11l1 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1llll11l1 = path
        else:
            self._1llll11l1 = self.l1lllll1l1
        super(l1llll1l1l, self).__init__(self._1llll11l1, l11l1 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1llll1111(self, line):
        return l1llll1l1l.Entry(*[x for x in line.strip(l11l1 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l11l1 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l11l1 (u"ࠢࠤࠤঋ")):
                    yield self._1llll1111(line)
            except ValueError:
                pass
    def l1lll1l1ll(self, attr, value):
        for entry in self.entries:
            l1lll1lll1 = getattr(entry, attr)
            if l1lll1lll1 == value:
                return entry
        return None
    def l1llllll1l(self, entry):
        if self.l1lll1l1ll(l11l1 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l11l1 (u"ࠩ࡟ࡲࠬ঍")).encode(l11l1 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lllll1ll(self, entry):
        self.seek(0)
        lines = [l.decode(l11l1 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11l1 (u"ࠧࠩࠢঐ")):
                if self._1llll1111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11l1 (u"࠭ࠧ঑").join(lines).encode(l11l1 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lllllll1(cls, l1lll1llll, path=None):
        l1lll1l1l1 = cls(path=path)
        entry = l1lll1l1l1.l1lll1l1ll(l11l1 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1llll)
        if entry:
            return l1lll1l1l1.l1lllll1ll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1llll, l1lll1l11l, options=None, path=None):
        return cls(path=path).l1llllll1l(l1llll1l1l.Entry(device,
                                                    l1lll1llll, l1lll1l11l,
                                                    options=options))
class l1llll1ll1(object):
    def __init__(self, l1llll1l11):
        self.l1llllllll=l11l1 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1llllll11=l11l1 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll1l11=l1llll1l11
        self.l1lll11ll1()
        self.l1llll1lll()
        self.l1lll11l11()
        self.l1lll1l111()
        self.l1lll11lll()
    def l1lll11ll1(self):
        temp_file=open(l1llll111l,l11l1 (u"ࠫࡷ࠭খ"))
        l11l1l1=temp_file.read()
        data=json.loads(l11l1l1)
        self.user=data[l11l1 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l11l1ll=data[l11l1 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11=data[l11l1 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1=data[l11l1 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll1ll1l=data[l11l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lllll111=data[l11l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll11l11(self):
        l1l1l=os.path.join(l11l1 (u"ࠦ࠴ࠨঝ"),l11l1 (u"ࠧࡻࡳࡳࠤঞ"),l11l1 (u"ࠨࡳࡣ࡫ࡱࠦট"),l11l1 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l11l1 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1l1l)
    def l1lll11lll(self):
        logger.info(l11l1 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11=os.path.join(self.l1,self.l1llllllll)
        l1lll111ll = pwd.getpwnam(self.user).pw_uid
        l11111111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11):
            os.makedirs(l11)
            os.system(l11l1 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11))
            logger.debug(l11l1 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11)
        else:
            logger.debug(l11l1 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11)
        l1l1l=os.path.join(l11, self.l1llllll11)
        print(l1l1l)
        logger.debug(l11l1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1l1l)
        with open(l1l1l, l11l1 (u"ࠢࡸ࠭ࠥধ")) as l1lll11l1l:
            logger.debug(self.l11l1ll + l11l1 (u"ࠨࠢࠪন")+self.l1lll1ll1l+l11l1 (u"ࠩࠣࠦࠬ঩")+self.l1lllll111+l11l1 (u"ࠪࠦࠬপ"))
            l1lll11l1l.writelines(self.l11l1ll + l11l1 (u"ࠫࠥ࠭ফ")+self.l1lll1ll1l+l11l1 (u"ࠬࠦࠢࠨব")+self.l1lllll111+l11l1 (u"࠭ࠢࠨভ"))
        os.chmod(l1l1l, 0o600)
        os.chown(l1l1l, l1lll111ll, l11111111)
    def l1llll1lll(self, l1lll1ll11=l11l1 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l11l1 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll1ll11 in groups:
            logger.info(l11l1 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1lll1ll11))
        else:
            logger.warning(l11l1 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1lll1ll11))
            l1l1111=l11l1 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1lll1ll11,self.user)
            logger.debug(l11l1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1l1111)
            os.system(l1l1111)
            logger.debug(l11l1 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll1l111(self):
        logger.debug(l11l1 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lll1l1l1=l1llll1l1l()
        l1lll1l1l1.add(self.l11l1ll, self.l11, l1lll1l11l=l11l1 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l11l1 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l11l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llll111l = urllib.parse.unquote(sys.argv[1])
        if l1llll111l:
            l1lll111l1=l1llll1ll1(l1llll111l)
        else:
            raise (l11l1 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l11l1 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise