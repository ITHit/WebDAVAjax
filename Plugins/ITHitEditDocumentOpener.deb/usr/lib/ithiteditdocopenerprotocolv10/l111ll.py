#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import hashlib
import os
import l1ll1lll
from l11llll import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll1lll import l11lll1
from l111l import l1ll1ll1, l1l11ll
import logging
logger = logging.getLogger(l1lll1l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l11l():
    def __init__(self, l1lll1,l11ll1, l1llll1= None, l111l11=None):
        self.l1ll=False
        self.l1l = self._11l()
        self.l11ll1 = l11ll1
        self.l1llll1 = l1llll1
        self.l1l111l = l1lll1
        if l1llll1:
            self.l1lll = True
        else:
            self.l1lll = False
        self.l111l11 = l111l11
    def _11l(self):
        try:
            return l1ll1lll.l1l1111() is not None
        except:
            return False
    def open(self):
        l1lll1l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l:
            raise NotImplementedError(l1lll1l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll11 = self.l1l111l
        if self.l11ll1.lower().startswith(self.l1l111l.lower()):
            l1l1 = re.compile(re.escape(self.l1l111l), re.IGNORECASE)
            l11ll1 = l1l1.sub(l1lll1l (u"ࠨࠩࠄ"), self.l11ll1)
            l11ll1 = l11ll1.replace(l1lll1l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11l1l1(self.l1l111l, l11ll11, l11ll1, self.l1llll1)
    def l11l1l1(self,l1l111l, l11ll11, l11ll1, l1llll1):
        l1lll1l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11l1ll = l1lllll1(l1l111l)
        l1111l = self.l1l11(l11l1ll)
        logger.info(l1lll1l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11l1ll)
        if l1111l:
            logger.info(l1lll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11lll1(l11l1ll)
            l11l1ll = l1ll1l(l1l111l, l11ll11, l1llll1, self.l111l11)
        logger.debug(l1lll1l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l111lll=l11l1ll + l1lll1l (u"ࠤ࠲ࠦࠌ") + l11ll1
        l1ll1ll = l1lll1l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l111lll+ l1lll1l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1ll1ll)
        l1lll1ll = os.system(l1ll1ll)
        if (l1lll1ll != 0):
            raise IOError(l1lll1l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l111lll, l1lll1ll))
    def l1l11(self, l11l1ll):
        if os.path.exists(l11l1ll):
            if os.path.islink(l11l1ll):
                l11l1ll = os.readlink(l11l1ll)
            if os.path.ismount(l11l1ll):
                return True
        return False
def l1lllll1(l1l111l):
    l11ll1l = l1l111l.replace(l1lll1l (u"࠭࡜࡝ࠩࠐ"), l1lll1l (u"ࠧࡠࠩࠑ")).replace(l1lll1l (u"ࠨ࠱ࠪࠒ"), l1lll1l (u"ࠩࡢࠫࠓ"))
    l1l1lll = l1lll1l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1llllll=os.environ[l1lll1l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l11=os.path.join(l1llllll,l1l1lll, l11ll1l)
    l1ll11l1=os.path.abspath(l11l11)
    return l1ll11l1
def l1lll11l(l11111):
    if not os.path.exists(l11111):
        os.makedirs(l11111)
def l111l1l(l1l111l, l11ll11, l1ll11l=None, password=None):
    l1lll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11111 = l1lllll1(l1l111l)
    l1lll11l(l11111)
    if not l1ll11l:
        l1lll11 = l111ll1()
        l1ll1l1l =l1lll11.l1l11l1(l1lll1l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll11 + l1lll1l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll11 + l1lll1l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll1l1l, str):
            l1ll11l, password = l1ll1l1l
        else:
            raise l1l11ll()
        logger.info(l1lll1l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11111))
    l1l1l = pwd.getpwuid( os.getuid())[0]
    l11ll=os.environ[l1lll1l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l11l=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1llll1l={l1lll1l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l1l, l1lll1l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l111l, l1lll1l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11111, l1lll1l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11ll, l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll11l, l1lll1l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1llll1l, temp_file)
        if not os.path.exists(os.path.join(l11l11l, l1lll1l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1ll1=l1lll1l (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1l (u"ࠧࠨࠤ")
        else:
            l1ll1=l1lll1l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1llll=l1lll1l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1ll1,temp_file.name)
        l11l111=[l1lll1l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l11l, l1llll)]
        p = subprocess.Popen(l11l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11111
    logger.debug(l1lll1l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11l1=os.path.abspath(l11111)
    logger.debug(l1lll1l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11l1)
    return l1ll11l1
def l1ll1l(l1l111l, l11ll11, l1llll1, l111l11):
    l1lll1l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1llll11(title):
        l1111ll=30
        if len(title)>l1111ll:
            l1ll111=title.split(l1lll1l (u"ࠨ࠯ࠣ࠳"))
            l1l1l1=l1lll1l (u"ࠧࠨ࠴")
            for block in l1ll111:
                l1l1l1+=block+l1lll1l (u"ࠣ࠱ࠥ࠵")
                if len(l1l1l1) > l1111ll:
                    l1l1l1+=l1lll1l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l1l1
        return title
    l1ll11l = l1lll1l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1lll1l (u"ࠦࠧ࠸")
    os.system(l1lll1l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1111l1 = l1lllll1(l1l111l)
    l11111 = l1lllll1(hashlib.sha1(l1l111l.encode()).hexdigest()[:10])
    l1lll11l(l11111)
    logger.info(l1lll1l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11111))
    if l1llll1:
        l1l1ll1 = [l1lll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1lll1l (u"ࠤ࠰ࡸࠧ࠽"), l1lll1l (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1lll1l (u"ࠫ࠲ࡵࠧ࠿"), l1lll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l1ll11l, l1llll1),
                    urllib.parse.unquote(l11ll11), os.path.abspath(l11111)]
    else:
        l1ll11l, password = l1lll111(l11111, l11ll11, l111l11)
        if l1ll11l.lower() != l1lll1l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1l1ll1 = [l1lll1l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1l (u"ࠤ࠰ࡸࠧࡄ"), l1lll1l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1l (u"ࠫ࠲ࡵࠧࡆ"), l1lll1l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l1ll11l,
                        urllib.parse.unquote(l11ll11), os.path.abspath(l11111)]
        else:
            raise l1l11ll()
    logger.info(l1lll1l (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1lll1l (u"ࠢࠡࠤࡉ").join(l1l1ll1)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1ll11ll = l1lll1l (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1ll11ll.encode())
    if len(err) > 0:
        l1111 = l1lll1l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l1111)
        raise l1ll1ll1(l1111, l1ll1l=l1ll1lll.l1l1111(), l11ll11=l11ll11)
    logger.info(l1lll1l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1lll1l (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11111, l1111l1))
    l1ll11l1=os.path.abspath(l1111l1)
    return l1ll11l1
def l1lll111(l1l111l, l11ll11, l111l11):
    l111 = os.path.join(os.environ[l1lll1l (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1lll1l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1lll1l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l111)):
       os.makedirs(os.path.dirname(l111))
    l1ll1l11 = l111l11.get_value(l1lll1l (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1lll1l (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1lll11 = l111ll1(l1l111l, l1ll1l11)
    l1ll11l, password = l1lll11.l1l11l1(l1lll1l (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l11ll11 + l1lll1l (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l11ll11 + l1lll1l (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l1ll11l != l1lll1l (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1l1l1l(l1l111l, l1ll11l):
        l11111l = l1lll1l (u"ࠢࠡࠤࡗ").join([l1l111l, l1ll11l, l1lll1l (u"ࠨࠤࠪࡘ") + password + l1lll1l (u"࡙ࠩࠥࠫ"), l1lll1l (u"ࠪࡠࡳ࡚࠭")])
        with open(l111, l1lll1l (u"ࠫࡼ࠱࡛ࠧ")) as l1:
            l1.write(l11111l)
        os.chmod(l111, 0o600)
    return l1ll11l, password
def l1l1l1l(l1l111l, l1ll11l):
    l111 = l1l1l11 = os.path.join(os.environ[l1lll1l (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1lll1l (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1lll1l (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l111):
        with open(l111, l1lll1l (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1lllll = data[0].split(l1lll1l (u"ࠤࠣࠦࡠ"))
            if l1l111l == l1lllll[0] and l1ll11l == l1lllll[1]:
                return True
    return False