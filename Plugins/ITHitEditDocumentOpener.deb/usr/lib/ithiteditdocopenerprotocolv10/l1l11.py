#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l1l1ll = 7
def l1ll11 (l1l1ll1):
    global l1llll1
    l111 = ord (l1l1ll1 [-1])
    l1ll11l = l1l1ll1 [:-1]
    l11l11l = l111 % len (l1ll11l)
    l1llll = l1ll11l [:l11l11l] + l1ll11l [l11l11l:]
    if l111l1:
        l1111l1 = l11111l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    else:
        l1111l1 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll11l + l111) % l1l1ll) for l1lll11l, char in enumerate (l1llll)])
    return eval (l1111l1)
import logging
import os
import re
from l1ll1ll import l1llll1ll
logger = logging.getLogger(l1ll11 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1l1l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll11 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1llll1l():
    try:
        out = os.popen(l1ll11 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1ll11 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1ll11 (u"ࠢࠣॶ").join(result)
                logger.info(l1ll11 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1ll11 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1ll11 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1ll11 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll1ll(l1ll11 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1ll11 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1l1l(l1ll11 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))