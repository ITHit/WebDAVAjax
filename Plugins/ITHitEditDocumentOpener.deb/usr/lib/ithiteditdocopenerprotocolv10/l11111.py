#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1l1l1 = 2048
l11l1ll = 7
def l1l111 (l11ll):
    global l1lll11l
    l1ll1l1l = ord (l11ll [-1])
    l111 = l11ll [:-1]
    l11 = l1ll1l1l % len (l111)
    l1ll1ll = l111 [:l11] + l111 [l11:]
    if l1llll:
        l1ll1l1 = l1ll1l () .join ([unichr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l1l1 - (l1111 + l1ll1l1l) % l11l1ll) for l1111, char in enumerate (l1ll1ll)])
    return eval (l1ll1l1)
import re
class l11l111(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1ll1 = kwargs.get(l1l111 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1llllll = kwargs.get(l1l111 (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lll11ll = self.l1111111(args)
        if l1lll11ll:
            args=args+ l1lll11ll
        self.args = [a for a in args]
    def l1111111(self, *args):
        l1lll11ll=None
        l1l1l11l = args[0][0]
        if re.search(l1l111 (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l1l11l):
            l1lll11ll = (l1l111 (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lll1ll1
                            ,)
        return l1lll11ll
class l111111l(Exception):
    def __init__(self, *args, **kwargs):
        l1lll11ll = self.l1111111(args)
        if l1lll11ll:
            args = args + l1lll11ll
        self.args = [a for a in args]
    def l1111111(self, *args):
        s = l1l111 (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l1l111 (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l1llll11l(Exception):
    pass
class l1ll1l11(Exception):
    pass
class l1lllllll(Exception):
    def __init__(self, message, l1111l11, url):
        super(l1lllllll,self).__init__(message)
        self.l1111l11 = l1111l11
        self.url = url
class l1lll1l11(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l11111ll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lllll11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l11l1l1l(Exception):
    pass