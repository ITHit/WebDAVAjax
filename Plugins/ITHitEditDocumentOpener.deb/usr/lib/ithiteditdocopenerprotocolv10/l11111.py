#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll11 = sys.version_info [0] == 2
l1llll1 = 2048
l11ll = 7
def l1l1ll1 (l11l1l):
    global l1111l1
    l1lllll1 = ord (l11l1l [-1])
    l11llll = l11l1l [:-1]
    l1ll1l11 = l1lllll1 % len (l11llll)
    l1ll1lll = l11llll [:l1ll1l11] + l11llll [l1ll1l11:]
    if l1llll11:
        l1l1l = l11 () .join ([unichr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    return eval (l1l1l)
import logging
import os
import re
from l1111ll import l1111ll1
logger = logging.getLogger(l1l1ll1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l1l11ll(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1ll1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111():
    try:
        out = os.popen(l1l1ll1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1l1ll1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1l1ll1 (u"ࠢࠣॶ").join(result)
                logger.info(l1l1ll1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1l1ll1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1l1ll1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1l1ll1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1111ll1(l1l1ll1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1l1ll1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l1l11ll(l1l1ll1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))