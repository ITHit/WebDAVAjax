#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1l11l1 = 2048
l1l = 7
def l1l11l (l1lll1l1):
    global l1l111l
    l1ll11ll = ord (l1lll1l1 [-1])
    l111ll1 = l1lll1l1 [:-1]
    l111l1 = l1ll11ll % len (l111ll1)
    l111111 = l111ll1 [:l111l1] + l111ll1 [l111l1:]
    if l1l1lll:
        l1111ll = l11l11 () .join ([unichr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l1l11l1 - (l11l11l + l1ll11ll) % l1l) for l11l11l, char in enumerate (l111111)])
    return eval (l1111ll)
import hashlib
import os
import l11llll
from l1l1l1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11llll import l1lll11l
from l1ll1l1l import l11lll1, l11
import logging
logger = logging.getLogger(l1l11l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l1():
    def __init__(self, l11l111,l1ll1111, l11ll= None, l1lll11=None):
        self.l11l1ll=False
        self.l1l1l11 = self._1ll1l()
        self.l1ll1111 = l1ll1111
        self.l11ll = l11ll
        self.l1111l1 = l11l111
        if l11ll:
            self.l1l1l1l = True
        else:
            self.l1l1l1l = False
        self.l1lll11 = l1lll11
    def _1ll1l(self):
        try:
            return l11llll.l1ll111l() is not None
        except:
            return False
    def open(self):
        l1l11l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1l11:
            raise NotImplementedError(l1l11l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1l11l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1lll = self.l1111l1
        if self.l1ll1111.lower().startswith(self.l1111l1.lower()):
            l11111l = re.compile(re.escape(self.l1111l1), re.IGNORECASE)
            l1ll1111 = l11111l.sub(l1l11l (u"ࠨࠩࠄ"), self.l1ll1111)
            l1ll1111 = l1ll1111.replace(l1l11l (u"ࠩࡧࡥࡻ࠭ࠅ"), l1l11l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1lll111(self.l1111l1, l1lll, l1ll1111, self.l11ll)
    def l1lll111(self,l1111l1, l1lll, l1ll1111, l11ll):
        l1l11l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1l11l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll11 = l1l111(l1111l1)
        l1111l = self.l111l(l1ll11)
        logger.info(l1l11l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll11)
        if l1111l:
            logger.info(l1l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1lll11l(l1ll11)
            l1ll11 = l1ll1ll(l1111l1, l1lll, l11ll, self.l1lll11)
        logger.debug(l1l11l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l11111=l1ll11 + l1l11l (u"ࠤ࠲ࠦࠌ") + l1ll1111
        l1lll1 = l1l11l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l11111+ l1l11l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1lll1)
        l11l1l = os.system(l1lll1)
        if (l11l1l != 0):
            raise IOError(l1l11l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l11111, l11l1l))
    def l111l(self, l1ll11):
        if os.path.exists(l1ll11):
            if os.path.islink(l1ll11):
                l1ll11 = os.readlink(l1ll11)
            if os.path.ismount(l1ll11):
                return True
        return False
def l1l111(l1111l1):
    l11ll1 = l1111l1.replace(l1l11l (u"࠭࡜࡝ࠩࠐ"), l1l11l (u"ࠧࡠࠩࠑ")).replace(l1l11l (u"ࠨ࠱ࠪࠒ"), l1l11l (u"ࠩࡢࠫࠓ"))
    l1lllll1 = l1l11l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111l1l=os.environ[l1l11l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l1=os.path.join(l111l1l,l1lllll1, l11ll1)
    l1l1l=os.path.abspath(l11l1)
    return l1l1l
def l1ll1l11(l111):
    if not os.path.exists(l111):
        os.makedirs(l111)
def l1lll1l(l1111l1, l1lll, l1l11=None, password=None):
    l1l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l111 = l1l111(l1111l1)
    l1ll1l11(l111)
    if not l1l11:
        l1ll = l11ll11()
        l1llll11 =l1ll.l111lll(l1l11l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1lll + l1l11l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1lll + l1l11l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1llll11, str):
            l1l11, password = l1llll11
        else:
            raise l11()
        logger.info(l1l11l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l111))
    l1ll1ll1 = pwd.getpwuid( os.getuid())[0]
    l1ll11l=os.environ[l1l11l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1llll={l1l11l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll1ll1, l1l11l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1111l1, l1l11l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l111, l1l11l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1ll11l, l1l11l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l11, l1l11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1llll, temp_file)
        if not os.path.exists(os.path.join(l1, l1l11l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lllll=l1l11l (u"ࠦࡵࡿࠢࠣ")
            key=l1l11l (u"ࠧࠨࠤ")
        else:
            l1lllll=l1l11l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1l11l (u"ࠢ࠮ࡑࠣࠦࠦ")
        ll=l1l11l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lllll,temp_file.name)
        l1llllll=[l1l11l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1l11l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1, ll)]
        p = subprocess.Popen(l1llllll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1l11l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1l11l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1l11l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l111
    logger.debug(l1l11l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1l11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1l11l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1l1l=os.path.abspath(l111)
    logger.debug(l1l11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1l1l)
    return l1l1l
def l1ll1ll(l1111l1, l1lll, l11ll, l1lll11):
    l1l11l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l(title):
        l111l11=30
        if len(title)>l111l11:
            l11ll1l=title.split(l1l11l (u"ࠨ࠯ࠣ࠳"))
            l1ll1l1=l1l11l (u"ࠧࠨ࠴")
            for block in l11ll1l:
                l1ll1l1+=block+l1l11l (u"ࠣ࠱ࠥ࠵")
                if len(l1ll1l1) > l111l11:
                    l1ll1l1+=l1l11l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1ll1l1
        return title
    def l1111(l1ll111, password):
        l1l11l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l1l11l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l1l11l (u"ࠧࠦࠢ࠹").join(l1ll111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1l1111 = l1l11l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1l1111.encode())
        l1llll1 = [l1l11l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1l1ll1 = l1l11l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1l1ll1)
            for e in l1llll1:
                if e in l1l1ll1: return False
            raise l11lll1(l1l1ll1, l1ll1ll=l11llll.l1ll111l(), l1lll=l1lll)
        logger.info(l1l11l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l11 = l1l11l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l1l11l (u"ࠦࠧ࠿")
    os.system(l1l11l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1lll1ll = l1l111(l1111l1)
    l111 = l1l111(hashlib.sha1(l1111l1.encode()).hexdigest()[:10])
    l1ll1l11(l111)
    logger.info(l1l11l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l111))
    if l11ll:
        l1ll111 = [l1l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1l11l (u"ࠤ࠰ࡸࠧࡄ"), l1l11l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1l11l (u"ࠫ࠲ࡵࠧࡆ"), l1l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l11, l11ll),
                    urllib.parse.unquote(l1lll), os.path.abspath(l111)]
        l1111(l1ll111, password)
    else:
        while True:
            l1l11, password = l1l11ll(l111, l1lll, l1lll11)
            if l1l11.lower() != l1l11l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll111 = [l1l11l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l1l11l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l1l11l (u"ࠤ࠰ࡸࠧࡋ"), l1l11l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l1l11l (u"ࠫ࠲ࡵࠧࡍ"), l1l11l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l11,
                            urllib.parse.unquote(l1lll), os.path.abspath(l111)]
            else:
                raise l11()
            if l1111(l1ll111, password): break
    os.system(l1l11l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l111, l1lll1ll))
    l1l1l=os.path.abspath(l1lll1ll)
    return l1l1l
def l1l11ll(l1111l1, l1lll, l1lll11):
    l1llll1l = os.path.join(os.environ[l1l11l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l1l11l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l1l11l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1llll1l)):
       os.makedirs(os.path.dirname(l1llll1l))
    l1l1ll = l1lll11.get_value(l1l11l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l1l11l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll = l11ll11(l1111l1, l1l1ll)
    l1l11, password = l1ll.l111lll(l1l11l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1lll + l1l11l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1lll + l1l11l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l11 != l1l11l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111ll(l1111l1, l1l11):
        l11l1l1 = l1l11l (u"ࠤ࡙ࠣࠦ").join([l1111l1, l1l11, l1l11l (u"࡚ࠪࠦࠬ") + password + l1l11l (u"࡛ࠫࠧ࠭"), l1l11l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1llll1l, l1l11l (u"࠭ࡷࠬࠩ࡝")) as l1ll1:
            l1ll1.write(l11l1l1)
        os.chmod(l1llll1l, 0o600)
    return l1l11, password
def l111ll(l1111l1, l1l11):
    l1llll1l = l1ll1lll = os.path.join(os.environ[l1l11l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l1l11l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l1l11l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1llll1l):
        with open(l1llll1l, l1l11l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll11l1 = data[0].split(l1l11l (u"ࠦࠥࠨࡢ"))
            if l1111l1 == l1ll11l1[0] and l1l11 == l1ll11l1[1]:
                return True
    return False