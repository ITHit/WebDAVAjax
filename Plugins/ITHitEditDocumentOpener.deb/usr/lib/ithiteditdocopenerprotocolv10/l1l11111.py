#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llllll = sys.version_info [0] == 2
l11ll1 = 2048
l1111ll = 7
def l1ll1l1 (l11ll11):
    global l1lll11
    l1lll111 = ord (l11ll11 [-1])
    l1ll11l1 = l11ll11 [:-1]
    l11l111 = l1lll111 % len (l1ll11l1)
    l1llll1 = l1ll11l1 [:l11l111] + l1ll11l1 [l11l111:]
    if l1llllll:
        l1lll1l = l1l1l1 () .join ([unichr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    else:
        l1lll1l = str () .join ([chr (ord (char) - l11ll1 - (l1l1 + l1lll111) % l1111ll) for l1l1, char in enumerate (l1llll1)])
    return eval (l1lll1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1llll11 import l1111
from configobj import ConfigObj
l1l111ll = l1ll1l1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l11lll11 = l1ll1l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠶࠸࠱࠴ࠧࡢ")
l11ll1ll = l1ll1l1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1ll1l1 (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠵࠷࠰࠳ࠦࡤ")
l11ll11l=os.path.join(os.environ.get(l1ll1l1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1ll1l1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l11ll1ll.replace(l1ll1l1 (u"ࠤࠣࠦࡧ"), l1ll1l1 (u"ࠥࡣࠧࡨ")).lower())
l1l1l111=os.environ.get(l1ll1l1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1ll1l1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1ll111l=l11lll11.replace(l1ll1l1 (u"ࠨࠠࠣ࡫"), l1ll1l1 (u"ࠢࡠࠤ࡬"))+l1ll1l1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1ll1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1ll11=os.path.join(os.environ.get(l1ll1l1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1ll111l)
elif platform.system() == l1ll1l1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l11l1l=l1111(l11ll11l+l1ll1l1 (u"ࠧ࠵ࠢࡱ"))
    l1l1ll11 = os.path.join(l1l11l1l, l1ll111l)
else:
    l1l1ll11 = os.path.join( l1ll111l)
l1l1l111=l1l1l111.upper()
if l1l1l111 == l1ll1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l1l1l1=logging.DEBUG
elif l1l1l111 == l1ll1l1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l1l1l1 = logging.INFO
elif l1l1l111 == l1ll1l1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l1l1l1 = logging.WARNING
elif l1l1l111 == l1ll1l1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l1l1l1 = logging.ERROR
elif l1l1l111 == l1ll1l1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l1l1l1 = logging.CRITICAL
elif l1l1l111 == l1ll1l1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l1l1l1 = logging.NOTSET
logger = logging.getLogger(l1ll1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l1l1l1)
l1l111l1 = logging.FileHandler(l1l1ll11, mode=l1ll1l1 (u"ࠨࡷࠬࠤࡹ"))
l1l111l1.setLevel(l1l1l1l1)
formatter = logging.Formatter(l1ll1l1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1ll1l1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l111l1.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l1l1)
l1l11l11 = SysLogHandler(address=l1ll1l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l111l1)
logger.addHandler(ch)
logger.addHandler(l1l11l11)
class Settings():
    l1l11lll = l1ll1l1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11llll1 = l1ll1l1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l11ll1 = l1ll1l1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l11lll11):
        self.l1l1l1ll = self._11lll1l(l11lll11)
        self._1l1ll1l()
    def _11lll1l(self, l11lll11):
        l11ll1l1 = l11lll11.split(l1ll1l1 (u"ࠨࠠࠣࢀ"))
        l11ll1l1 = l1ll1l1 (u"ࠢࠡࠤࢁ").join(l11ll1l1)
        if platform.system() == l1ll1l1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l1l1ll = os.path.join(l11ll11l, l1ll1l1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l11ll1l1 + l1ll1l1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l1l1ll
    def l1l1lll1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1ll1111(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll1l1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll1l1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1ll1l(self):
        if not os.path.exists(os.path.dirname(self.l1l1l1ll)):
            os.makedirs(os.path.dirname(self.l1l1l1ll))
        if not os.path.exists(self.l1l1l1ll):
            self.config = ConfigObj(self.l1l1l1ll)
            self.config[l1ll1l1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1ll1l1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1ll1l1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l11ll1
            self.config[l1ll1l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1ll1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1ll1l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11llll1
            self.config[l1ll1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l11lll
            self.config[l1ll1l1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1l1ll)
            self.l1l11ll1 = self.get_value(l1ll1l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1ll1l1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11llll1 = self.get_value(l1ll1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1ll1l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l11lll = self.get_value(l1ll1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11lllll(self):
        l1l1111l = l1ll1l1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l11lll
        l1l1111l += l1ll1l1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11llll1
        l1l1111l += l1ll1l1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l11ll1
        return l1l1111l
    def __unicode__(self):
        return self._11lllll()
    def __str__(self):
        return self._11lllll()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l11lll11)