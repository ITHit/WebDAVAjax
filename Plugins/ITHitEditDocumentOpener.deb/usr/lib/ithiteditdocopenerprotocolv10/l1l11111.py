#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l1l = sys.version_info [0] == 2
l1l1ll1 = 2048
l1ll1l1l = 7
def l1llll1 (l1ll1ll1):
    global l11l11
    l1l1lll = ord (l1ll1ll1 [-1])
    l111l1 = l1ll1ll1 [:-1]
    l1l11ll = l1l1lll % len (l111l1)
    l11l = l111l1 [:l1l11ll] + l111l1 [l1l11ll:]
    if l1l1l1l:
        l11111l = l1l11 () .join ([unichr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    else:
        l11111l = str () .join ([chr (ord (char) - l1l1ll1 - (l1llll + l1l1lll) % l1ll1l1l) for l1llll, char in enumerate (l11l)])
    return eval (l11111l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1l11l import l111l11
from configobj import ConfigObj
l11lllll = l1llll1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l11ll1 = l1llll1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠷࠴࠴࠱࠴ࠧࡢ")
l1l111ll = l1llll1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1llll1 (u"ࠨ࠵࠯࠴࠳࠲࠺࠽࠳࠳࠰࠳ࠦࡤ")
l1l1111l=os.path.join(os.environ.get(l1llll1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1llll1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l111ll.replace(l1llll1 (u"ࠤࠣࠦࡧ"), l1llll1 (u"ࠥࡣࠧࡨ")).lower())
l1l1l11l=os.environ.get(l1llll1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1llll1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l1l1ll=l1l11ll1.replace(l1llll1 (u"ࠨࠠࠣ࡫"), l1llll1 (u"ࠢࡠࠤ࡬"))+l1llll1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1llll1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l11l11=os.path.join(os.environ.get(l1llll1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l1l1ll)
elif platform.system() == l1llll1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l1l111=l111l11(l1l1111l+l1llll1 (u"ࠧ࠵ࠢࡱ"))
    l1l11l11 = os.path.join(l1l1l111, l1l1l1ll)
else:
    l1l11l11 = os.path.join( l1l1l1ll)
l1l1l11l=l1l1l11l.upper()
if l1l1l11l == l1llll1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l11lll=logging.DEBUG
elif l1l1l11l == l1llll1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l11lll = logging.INFO
elif l1l1l11l == l1llll1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l11lll = logging.WARNING
elif l1l1l11l == l1llll1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l11lll = logging.ERROR
elif l1l1l11l == l1llll1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l11lll = logging.CRITICAL
elif l1l1l11l == l1llll1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l11lll = logging.NOTSET
logger = logging.getLogger(l1llll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l11lll)
l11lll11 = logging.FileHandler(l1l11l11, mode=l1llll1 (u"ࠨࡷࠬࠤࡹ"))
l11lll11.setLevel(l1l11lll)
formatter = logging.Formatter(l1llll1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1llll1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l11lll11.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l11lll)
l1l11l1l = SysLogHandler(address=l1llll1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l11l1l.setFormatter(formatter)
logger.addHandler(l11lll11)
logger.addHandler(ch)
logger.addHandler(l1l11l1l)
class Settings():
    l1l1l1l1 = l1llll1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11ll11l = l1llll1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l1ll1l = l1llll1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l11ll1):
        self.l11lll1l = self._11llll1(l1l11ll1)
        self._1l1ll11()
    def _11llll1(self, l1l11ll1):
        l1ll111l = l1l11ll1.split(l1llll1 (u"ࠨࠠࠣࢀ"))
        l1ll111l = l1llll1 (u"ࠢࠡࠤࢁ").join(l1ll111l)
        if platform.system() == l1llll1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11lll1l = os.path.join(l1l1111l, l1llll1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1ll111l + l1llll1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11lll1l
    def l1l111l1(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1lll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1llll1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1llll1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1ll1111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1ll11(self):
        if not os.path.exists(os.path.dirname(self.l11lll1l)):
            os.makedirs(os.path.dirname(self.l11lll1l))
        if not os.path.exists(self.l11lll1l):
            self.config = ConfigObj(self.l11lll1l)
            self.config[l1llll1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1llll1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1llll1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l1ll1l
            self.config[l1llll1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1llll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1llll1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11ll11l
            self.config[l1llll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1llll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1l1l1
            self.config[l1llll1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11lll1l)
            self.l1l1ll1l = self.get_value(l1llll1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1llll1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11ll11l = self.get_value(l1llll1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1llll1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1l1l1 = self.get_value(l1llll1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1llll1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11ll1l1(self):
        l11ll1ll = l1llll1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1l1l1
        l11ll1ll += l1llll1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11ll11l
        l11ll1ll += l1llll1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l1ll1l
        return l11ll1ll
    def __unicode__(self):
        return self._11ll1l1()
    def __str__(self):
        return self._11ll1l1()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l1l11ll1)