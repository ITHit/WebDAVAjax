#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll1 = sys.version_info [0] == 2
l111l11 = 2048
l1lll11 = 7
def l11llll (l1ll111):
    global l1lll
    l1llll11 = ord (l1ll111 [-1])
    l11lll = l1ll111 [:-1]
    l1lll1l1 = l1llll11 % len (l11lll)
    l1lll1l = l11lll [:l1lll1l1] + l11lll [l1lll1l1:]
    if l1llll1:
        l111lll = l1lll11l () .join ([unichr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    else:
        l111lll = str () .join ([chr (ord (char) - l111l11 - (ll + l1llll11) % l1lll11) for ll, char in enumerate (l1lll1l)])
    return eval (l111lll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll111 import l1lll1
from configobj import ConfigObj
l1l1111l = l11llll (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l1ll1l = l11llll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠵࠳࠱࠴ࠧࡢ")
l1l1llll = l11llll (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l11llll (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠴࠲࠰࠳ࠦࡤ")
l11ll1l1=os.path.join(os.environ.get(l11llll (u"ࠧࡉࡑࡐࡉࠬࡥ")),l11llll (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l1llll.replace(l11llll (u"ࠤࠣࠦࡧ"), l11llll (u"ࠥࡣࠧࡨ")).lower())
l1ll111l=os.environ.get(l11llll (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l11llll (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l111ll=l1l1ll1l.replace(l11llll (u"ࠨࠠࠣ࡫"), l11llll (u"ࠢࡠࠤ࡬"))+l11llll (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l11llll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l11lll=os.path.join(os.environ.get(l11llll (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l111ll)
elif platform.system() == l11llll (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l11ll1=l1lll1(l11ll1l1+l11llll (u"ࠧ࠵ࠢࡱ"))
    l1l11lll = os.path.join(l1l11ll1, l1l111ll)
else:
    l1l11lll = os.path.join( l1l111ll)
l1ll111l=l1ll111l.upper()
if l1ll111l == l11llll (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l111l1=logging.DEBUG
elif l1ll111l == l11llll (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l111l1 = logging.INFO
elif l1ll111l == l11llll (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l111l1 = logging.WARNING
elif l1ll111l == l11llll (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l111l1 = logging.ERROR
elif l1ll111l == l11llll (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l111l1 = logging.CRITICAL
elif l1ll111l == l11llll (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l111l1 = logging.NOTSET
logger = logging.getLogger(l11llll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l111l1)
l11ll11l = logging.FileHandler(l1l11lll, mode=l11llll (u"ࠨࡷࠬࠤࡹ"))
l11ll11l.setLevel(l1l111l1)
formatter = logging.Formatter(l11llll (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l11llll (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l11ll11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l111l1)
l1ll1111 = SysLogHandler(address=l11llll (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1ll1111.setFormatter(formatter)
logger.addHandler(l11ll11l)
logger.addHandler(ch)
logger.addHandler(l1ll1111)
class Settings():
    l1l1lll1 = l11llll (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l11l1l = l11llll (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l11lll11 = l11llll (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l1ll1l):
        self.l1l11l11 = self._11ll1ll(l1l1ll1l)
        self._1l1l111()
    def _11ll1ll(self, l1l1ll1l):
        l1l1l1l1 = l1l1ll1l.split(l11llll (u"ࠨࠠࠣࢀ"))
        l1l1l1l1 = l11llll (u"ࠢࠡࠤࢁ").join(l1l1l1l1)
        if platform.system() == l11llll (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l11l11 = os.path.join(l11ll1l1, l11llll (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1l1l1 + l11llll (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l11l11
    def l11lllll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11lll1l(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11llll (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11llll (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1l111(self):
        if not os.path.exists(os.path.dirname(self.l1l11l11)):
            os.makedirs(os.path.dirname(self.l1l11l11))
        if not os.path.exists(self.l1l11l11):
            self.config = ConfigObj(self.l1l11l11)
            self.config[l11llll (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l11llll (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l11llll (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l11lll11
            self.config[l11llll (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l11llll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l11llll (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l11l1l
            self.config[l11llll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11llll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1lll1
            self.config[l11llll (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11l11)
            self.l11lll11 = self.get_value(l11llll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l11llll (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l11l1l = self.get_value(l11llll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l11llll (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1lll1 = self.get_value(l11llll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11llll (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _11llll1(self):
        l1l1ll11 = l11llll (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1lll1
        l1l1ll11 += l11llll (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l11l1l
        l1l1ll11 += l11llll (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l11lll11
        return l1l1ll11
    def __unicode__(self):
        return self._11llll1()
    def __str__(self):
        return self._11llll1()
    def __del__(self):
        self.config.write()
l1l1l1ll = Settings(l1l1ll1l)