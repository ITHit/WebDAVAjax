#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll1 = sys.version_info [0] == 2
l111111 = 2048
l111ll1 = 7
def l1lll1ll (l1ll1l1l):
    global l111lll
    l1ll11ll = ord (l1ll1l1l [-1])
    l1llll = l1ll1l1l [:-1]
    l111l = l1ll11ll % len (l1llll)
    l11l1l = l1llll [:l111l] + l1llll [l111l:]
    if l11lll1:
        l1l1ll1 = l111l1l () .join ([unichr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    else:
        l1l1ll1 = str () .join ([chr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    return eval (l1l1ll1)
import logging
import os
import re
from l1lll1 import l1llll1ll
logger = logging.getLogger(l1lll1ll (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1111l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1ll (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11():
    try:
        out = os.popen(l1lll1ll (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1lll1ll (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1lll1ll (u"ࠤࠥॸ").join(result)
                logger.info(l1lll1ll (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1lll1ll (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1lll1ll (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1lll1ll (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1llll1ll(l1lll1ll (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1lll1ll (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1111l1(l1lll1ll (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))