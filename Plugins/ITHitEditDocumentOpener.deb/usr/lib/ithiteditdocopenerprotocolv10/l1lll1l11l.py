#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1ll = 7
def l11ll11 (l1lll11l):
    global l1ll
    l1l1ll1 = ord (l1lll11l [-1])
    l11l1l1 = l1lll11l [:-1]
    l111ll1 = l1l1ll1 % len (l11l1l1)
    l11lll = l11l1l1 [:l111ll1] + l11l1l1 [l111ll1:]
    if l1l1l:
        l1lll = l111111 () .join ([unichr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    else:
        l1lll = str () .join ([chr (ord (char) - l1l1l11 - (l1ll11l + l1l1ll1) % l11l1ll) for l1ll11l, char in enumerate (l11lll)])
    return eval (l1lll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llll1lll=logging.WARNING
logger = logging.getLogger(l11ll11 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llll1lll)
l1l1ll1l = SysLogHandler(address=l11ll11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l11ll11 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l1ll1l.setFormatter(formatter)
logger.addHandler(l1l1ll1l)
ch = logging.StreamHandler()
ch.setLevel(l1llll1lll)
logger.addHandler(ch)
class l1lll11lll(io.FileIO):
    l11ll11 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l11ll11 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1l1ll, l1lll1lll1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1l1ll = l1lll1l1ll
            self.l1lll1lll1 = l1lll1lll1
            if not options:
                options = l11ll11 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11ll11 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1l1ll,
                                              self.l1lll1lll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll11 = os.path.join(os.path.sep, l11ll11 (u"ࠨࡧࡷࡧࠬঅ"), l11ll11 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1llll1l1l = path
        else:
            self._1llll1l1l = self.l1lll1ll11
        super(l1lll11lll, self).__init__(self._1llll1l1l, l11ll11 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lllll1l1(self, line):
        return l1lll11lll.Entry(*[x for x in line.strip(l11ll11 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l11ll11 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11ll11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l11ll11 (u"ࠢࠤࠤঋ")):
                    yield self._1lllll1l1(line)
            except ValueError:
                pass
    def l1lll111l1(self, attr, value):
        for entry in self.entries:
            l1lll1l111 = getattr(entry, attr)
            if l1lll1l111 == value:
                return entry
        return None
    def l1llll1ll1(self, entry):
        if self.l1lll111l1(l11ll11 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l11ll11 (u"ࠩ࡟ࡲࠬ঍")).encode(l11ll11 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lllll11l(self, entry):
        self.seek(0)
        lines = [l.decode(l11ll11 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11ll11 (u"ࠧࠩࠢঐ")):
                if self._1lllll1l1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11ll11 (u"࠭ࠧ঑").join(lines).encode(l11ll11 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lllll111(cls, l1lll1l1ll, path=None):
        l1llll1l11 = cls(path=path)
        entry = l1llll1l11.l1lll111l1(l11ll11 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1l1ll)
        if entry:
            return l1llll1l11.l1lllll11l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1l1ll, l1lll1lll1, options=None, path=None):
        return cls(path=path).l1llll1ll1(l1lll11lll.Entry(device,
                                                    l1lll1l1ll, l1lll1lll1,
                                                    options=options))
class l1lll11l1l(object):
    def __init__(self, l1llllllll):
        self.l1lll1l1l1=l11ll11 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lllll1ll=l11ll11 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llllllll=l1llllllll
        self.l1llll11ll()
        self.l1llll1111()
        self.l1lll1ll1l()
        self.l1llll111l()
        self.l1lll1llll()
    def l1llll11ll(self):
        temp_file=open(l1lllllll1,l11ll11 (u"ࠫࡷ࠭খ"))
        l1=temp_file.read()
        data=json.loads(l1)
        self.user=data[l11ll11 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l11ll1l=data[l11ll11 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11111l=data[l11ll11 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1ll111=data[l11ll11 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll11l11=data[l11ll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1llllll11=data[l11ll11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll1ll1l(self):
        l11l111=os.path.join(l11ll11 (u"ࠦ࠴ࠨঝ"),l11ll11 (u"ࠧࡻࡳࡳࠤঞ"),l11ll11 (u"ࠨࡳࡣ࡫ࡱࠦট"),l11ll11 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l11ll11 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l11l111)
    def l1lll1llll(self):
        logger.info(l11ll11 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11111l=os.path.join(self.l1ll111,self.l1lll1l1l1)
        l1lll11ll1 = pwd.getpwnam(self.user).pw_uid
        l11111111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11111l):
            os.makedirs(l11111l)
            os.system(l11ll11 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11111l))
            logger.debug(l11ll11 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11111l)
        else:
            logger.debug(l11ll11 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11111l)
        l11l111=os.path.join(l11111l, self.l1lllll1ll)
        print(l11l111)
        logger.debug(l11ll11 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l11l111)
        with open(l11l111, l11ll11 (u"ࠢࡸ࠭ࠥধ")) as l1lll111ll:
            logger.debug(self.l11ll1l + l11ll11 (u"ࠨࠢࠪন")+self.l1lll11l11+l11ll11 (u"ࠩࠣࠦࠬ঩")+self.l1llllll11+l11ll11 (u"ࠪࠦࠬপ"))
            l1lll111ll.writelines(self.l11ll1l + l11ll11 (u"ࠫࠥ࠭ফ")+self.l1lll11l11+l11ll11 (u"ࠬࠦࠢࠨব")+self.l1llllll11+l11ll11 (u"࠭ࠢࠨভ"))
        os.chmod(l11l111, 0o600)
        os.chown(l11l111, l1lll11ll1, l11111111)
    def l1llll1111(self, l1llll11l1=l11ll11 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l11ll11 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11l1 in groups:
            logger.info(l11ll11 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llll11l1))
        else:
            logger.warning(l11ll11 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llll11l1))
            l11ll1=l11ll11 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llll11l1,self.user)
            logger.debug(l11ll11 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l11ll1)
            os.system(l11ll1)
            logger.debug(l11ll11 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1llll111l(self):
        logger.debug(l11ll11 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llll1l11=l1lll11lll()
        l1llll1l11.add(self.l11ll1l, self.l11111l, l1lll1lll1=l11ll11 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l11ll11 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l11ll11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lllllll1 = urllib.parse.unquote(sys.argv[1])
        if l1lllllll1:
            l1llllll1l=l1lll11l1l(l1lllllll1)
        else:
            raise (l11ll11 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l11ll11 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise