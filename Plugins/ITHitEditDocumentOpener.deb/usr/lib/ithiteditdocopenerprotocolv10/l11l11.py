#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1 = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l1l1ll1 (l11ll1):
    global l1llll1
    l1ll111 = ord (l11ll1 [-1])
    l1lll1 = l11ll1 [:-1]
    l1l1111 = l1ll111 % len (l1lll1)
    l1lll1l = l1lll1 [:l1l1111] + l1lll1 [l1l1111:]
    if l1:
        l111ll = l1ll1111 () .join ([unichr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    else:
        l111ll = str () .join ([chr (ord (char) - l11l - (l1l11l + l1ll111) % l1111l1) for l1l11l, char in enumerate (l1lll1l)])
    return eval (l111ll)
import logging
import os
import re
from l1111ll import l1111111
logger = logging.getLogger(l1l1ll1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l11l1l1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1l1ll1 (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll11l1():
    try:
        out = os.popen(l1l1ll1 (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1l1ll1 (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1l1ll1 (u"ࠤࠥॸ").join(result)
                logger.info(l1l1ll1 (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1l1ll1 (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1l1ll1 (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1l1ll1 (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1111111(l1l1ll1 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1l1ll1 (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l11l1l1(l1l1ll1 (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))