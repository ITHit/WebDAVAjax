#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111l = sys.version_info [0] == 2
l11l11l = 2048
l11l111 = 7
def l1ll11l1 (l111l1):
    global l1l1111
    l1ll11ll = ord (l111l1 [-1])
    l1lll11 = l111l1 [:-1]
    l1l1l11 = l1ll11ll % len (l1lll11)
    l1l111l = l1lll11 [:l1l1l11] + l1lll11 [l1l1l11:]
    if l1111l:
        l1ll1l = l11l () .join ([unichr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    else:
        l1ll1l = str () .join ([chr (ord (char) - l11l11l - (l111ll + l1ll11ll) % l11l111) for l111ll, char in enumerate (l1l111l)])
    return eval (l1ll1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll1l1 import l111
from configobj import ConfigObj
l1l1lll1 = l1ll11l1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1ll1111 = l1ll11l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠸࠱࠷࠱࠴ࠧࡢ")
l1l1llll = l1ll11l1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1ll11l1 (u"ࠨ࠵࠯࠴࠳࠲࠺࠾࠰࠶࠰࠳ࠦࡤ")
l1l11ll1=os.path.join(os.environ.get(l1ll11l1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1ll11l1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l1llll.replace(l1ll11l1 (u"ࠤࠣࠦࡧ"), l1ll11l1 (u"ࠥࡣࠧࡨ")).lower())
l11lll1l=os.environ.get(l1ll11l1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1ll11l1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l1ll11=l1ll1111.replace(l1ll11l1 (u"ࠨࠠࠣ࡫"), l1ll11l1 (u"ࠢࡠࠤ࡬"))+l1ll11l1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1ll11l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l1l1ll=os.path.join(os.environ.get(l1ll11l1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l1ll11)
elif platform.system() == l1ll11l1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l1l1ll1l=l111(l1l11ll1+l1ll11l1 (u"ࠧ࠵ࠢࡱ"))
    l1l1l1ll = os.path.join(l1l1ll1l, l1l1ll11)
else:
    l1l1l1ll = os.path.join( l1l1ll11)
l11lll1l=l11lll1l.upper()
if l11lll1l == l1ll11l1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l1l111=logging.DEBUG
elif l11lll1l == l1ll11l1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l1l111 = logging.INFO
elif l11lll1l == l1ll11l1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l1l111 = logging.WARNING
elif l11lll1l == l1ll11l1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l1l111 = logging.ERROR
elif l11lll1l == l1ll11l1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l1l111 = logging.CRITICAL
elif l11lll1l == l1ll11l1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l1l111 = logging.NOTSET
logger = logging.getLogger(l1ll11l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l1l111)
l1l11lll = logging.FileHandler(l1l1l1ll, mode=l1ll11l1 (u"ࠨࡷࠬࠤࡹ"))
l1l11lll.setLevel(l1l1l111)
formatter = logging.Formatter(l1ll11l1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1ll11l1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l11lll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l111)
l1ll111l = SysLogHandler(address=l1ll11l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1ll111l.setFormatter(formatter)
logger.addHandler(l1l11lll)
logger.addHandler(ch)
logger.addHandler(l1ll111l)
class Settings():
    l1l11l11 = l1ll11l1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l11l1l = l1ll11l1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l111l1 = l1ll11l1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1ll1111):
        self.l11llll1 = self._11lllll(l1ll1111)
        self._11lll11()
    def _11lllll(self, l1ll1111):
        l1l1111l = l1ll1111.split(l1ll11l1 (u"ࠨࠠࠣࢀ"))
        l1l1111l = l1ll11l1 (u"ࠢࠡࠤࢁ").join(l1l1111l)
        if platform.system() == l1ll11l1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l11llll1 = os.path.join(l1l11ll1, l1ll11l1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1111l + l1ll11l1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l11llll1
    def l11ll1ll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll1l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1ll11l1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1ll11l1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll11(self):
        if not os.path.exists(os.path.dirname(self.l11llll1)):
            os.makedirs(os.path.dirname(self.l11llll1))
        if not os.path.exists(self.l11llll1):
            self.config = ConfigObj(self.l11llll1)
            self.config[l1ll11l1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1ll11l1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1ll11l1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l111l1
            self.config[l1ll11l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1ll11l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1ll11l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l11l1l
            self.config[l1ll11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1ll11l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l11l11
            self.config[l1ll11l1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l11llll1)
            self.l1l111l1 = self.get_value(l1ll11l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1ll11l1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l11l1l = self.get_value(l1ll11l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1ll11l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l11l11 = self.get_value(l1ll11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1ll11l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l111ll(self):
        l1l1l11l = l1ll11l1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l11l11
        l1l1l11l += l1ll11l1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l11l1l
        l1l1l11l += l1ll11l1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l111l1
        return l1l1l11l
    def __unicode__(self):
        return self._1l111ll()
    def __str__(self):
        return self._1l111ll()
    def __del__(self):
        self.config.write()
l11ll11l = Settings(l1ll1111)