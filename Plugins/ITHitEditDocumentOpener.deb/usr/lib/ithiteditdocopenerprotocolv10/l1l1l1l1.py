#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll1 = sys.version_info [0] == 2
l111111 = 2048
l111ll1 = 7
def l1lll1ll (l1ll1l1l):
    global l111lll
    l1ll11ll = ord (l1ll1l1l [-1])
    l1llll = l1ll1l1l [:-1]
    l111l = l1ll11ll % len (l1llll)
    l11l1l = l1llll [:l111l] + l1llll [l111l:]
    if l11lll1:
        l1l1ll1 = l111l1l () .join ([unichr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    else:
        l1l1ll1 = str () .join ([chr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    return eval (l1l1ll1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l11l111 import l1111l1
from configobj import ConfigObj
l11lll11 = l1lll1ll (u"ࠧࡪࡡࡷ࠳࠳ࠦࡣ")
l1l111ll = l1lll1ll (u"ࠨࡉࡕࠢࡋ࡭ࡹࠦࡅࡥ࡫ࡷࠤࡉࡵࡣࠡࡑࡳࡩࡳ࡫ࡲࠡࠪࡓࡶࡴࡺ࡯ࡤࡱ࡯ࠤࡻ࠷࠰ࠪࠢࡇࡅ࡛࠷࠰ࠡࡸ࠸࠲࠷࠷࠮࠷࠲࠳࠵࠳࠶ࠢࡤ")
l1l11lll = l1lll1ll (u"ࠢࡊࡖࠣࡌ࡮ࡺࠢࡥ")
VERSION = l1lll1ll (u"ࠣ࠷࠱࠶࠶࠴࠶࠱࠲࠴࠲࠵ࠨࡦ")
l1l1l111=os.path.join(os.environ.get(l1lll1ll (u"ࠩࡋࡓࡒࡋࠧࡧ")),l1lll1ll (u"ࠥ࠲ࠪࡹࠢࡨ") %l1l11lll.replace(l1lll1ll (u"ࠦࠥࠨࡩ"), l1lll1ll (u"ࠧࡥࠢࡪ")).lower())
l1l1ll11=os.environ.get(l1lll1ll (u"࠭ࡉࡕࡊࡌࡘࡤࡒࡏࡈࡎࡈ࡚ࡊࡒࠧ࡫"), l1lll1ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࡬"))
l1l111l1=l1l111ll.replace(l1lll1ll (u"ࠣࠢࠥ࡭"), l1lll1ll (u"ࠤࡢࠦ࡮"))+l1lll1ll (u"ࠥ࠲ࡱࡵࡧࠣ࡯")
if platform.system() == l1lll1ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࡰ"):
    l11ll11l=os.path.join(os.environ.get(l1lll1ll (u"࡚ࠬࡅࡎࡒࠪࡱ")),l1l111l1)
elif platform.system() == l1lll1ll (u"ࠨࡌࡪࡰࡸࡼࠧࡲ"):
    l1l1lll1=l1111l1(l1l1l111+l1lll1ll (u"ࠢ࠰ࠤࡳ"))
    l11ll11l = os.path.join(l1l1lll1, l1l111l1)
else:
    l11ll11l = os.path.join( l1l111l1)
l1l1ll11=l1l1ll11.upper()
if l1l1ll11 == l1lll1ll (u"ࠣࡆࡈࡆ࡚ࡍࠢࡴ"): l1l1l11l=logging.DEBUG
elif l1l1ll11 == l1lll1ll (u"ࠤࡌࡒࡋࡕࠢࡵ"): l1l1l11l = logging.INFO
elif l1l1ll11 == l1lll1ll (u"࡛ࠥࡆࡘࡎࡊࡐࡊࠦࡶ"): l1l1l11l = logging.WARNING
elif l1l1ll11 == l1lll1ll (u"ࠦࡊࡘࡒࡐࡔࠥࡷ"): l1l1l11l = logging.ERROR
elif l1l1ll11 == l1lll1ll (u"ࠧࡉࡒࡊࡖࡌࡇࡆࡒࠢࡸ"):  l1l1l11l = logging.CRITICAL
elif l1l1ll11 == l1lll1ll (u"ࠨࡎࡐࡖࡖࡉ࡙ࠨࡹ"): l1l1l11l = logging.NOTSET
logger = logging.getLogger(l1lll1ll (u"ࠢࡥࡱࡦࡹࡲ࡫࡮ࡵࡡࡲࡴࡪࡴࡥࡳࠤࡺ"))
logger.setLevel(l1l1l11l)
l11ll111 = logging.FileHandler(l11ll11l, mode=l1lll1ll (u"ࠣࡹ࠮ࠦࡻ"))
l11ll111.setLevel(l1l1l11l)
formatter = logging.Formatter(l1lll1ll (u"ࠩࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࠮ࠢࠨࠬࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࡼ"),l1lll1ll (u"ࠥࠩࡦ࠲ࠠࠦࡦ࠰ࠩࡧ࠳࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠤࡌࡓࡔࠣࡽ"))
formatter.converter = time.gmtime
l11ll111.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1l11l)
l11ll1ll = SysLogHandler(address=l1lll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ࡾ"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l11ll111)
logger.addHandler(ch)
logger.addHandler(l11ll1ll)
class Settings():
    l11lllll = l1lll1ll (u"࡚ࠬࡲࡶࡧࠪࡿ")
    l11l1lll = l1lll1ll (u"࠭ࡎࡰࡰࡨࠫࢀ")
    l11llll1 = l1lll1ll (u"ࠧ࠳࠶ࠪࢁ")
    def __init__(self, l1l111ll):
        self.l1l11111 = self._1l1llll(l1l111ll)
        self._1l1111l()
    def _1l1llll(self, l1l111ll):
        l1l1l1ll = l1l111ll.split(l1lll1ll (u"ࠣࠢࠥࢂ"))
        l1l1l1ll = l1lll1ll (u"ࠤࠣࠦࢃ").join(l1l1l1ll)
        if platform.system() == l1lll1ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࢄ"):
            l1l11111 = os.path.join(l1l1l111, l1lll1ll (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࠦࢅ"), l1l1l1ll + l1lll1ll (u"ࠧ࠴ࡣࡧࡩࠥࢆ"))
        return l1l11111
    def l1l1ll1l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l11ll1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll1ll (u"ࡸࠢ࡝ࡾ࡟ࡷ࠭࠴ࠫࡀࠫ࡟ࡷࡡࢂࠢࢇ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll1ll (u"ࠢࠣ࢈")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l11lll1l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l1111l(self):
        if not os.path.exists(os.path.dirname(self.l1l11111)):
            os.makedirs(os.path.dirname(self.l1l11111))
        if not os.path.exists(self.l1l11111):
            self.config = ConfigObj(self.l1l11111)
            self.config[l1lll1ll (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩࢉ")] = {}
            self.config[l1lll1ll (u"ࠩࡆࡳࡴࡱࡩࡦࡵࠪࢊ")][l1lll1ll (u"ࠪࡩࡽࡶࡩࡳࡧࡧࡣࡹ࡯࡭ࡦࡡࡳࡰࡺࡹ࡟ࡩࡱࡸࡶࠬࢋ")] = self.l11llll1
            self.config[l1lll1ll (u"ࠫࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠩࢌ")] = {}
            self.config[l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨࢎ")] = self.l11l1lll
            self.config[l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢏")][l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩ࢐")] = self.l11lllll
            self.config[l1lll1ll (u"ࠩࡏࡳ࡬࡯࡮ࡴࠩ࢑")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11111)
            self.l11llll1 = self.get_value(l1lll1ll (u"ࠪࡇࡴࡵ࡫ࡪࡧࡶࠫ࢒"),l1lll1ll (u"ࠫࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷ࠭࢓"))
            self.l11l1lll = self.get_value(l1lll1ll (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll1ll (u"࠭ࡥࡹࡶࡨࡲࡩࡥࡥࡹࡲ࡬ࡶࡪࡪ࡟ࡤࡱࡲ࡯࡮࡫ࡳࠨ࢕"))
            self.l11lllll = self.get_value(l1lll1ll (u"ࠧࡑࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠬ࢖"),l1lll1ll (u"ࠨࡵ࡫ࡳࡼࡥ࡭ࡦࡵࡶࡥ࡬࡫࡟ࡢࡵࡢࡱࡴࡪࡡ࡭ࠩࢗ"))
    def _11ll1l1(self):
        l1l11l1l = l1lll1ll (u"ࠤࡶ࡬ࡴࡽ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡣࡶࡣࡲࡵࡤࡢ࡮࠽ࠤࠪࡹࠠࡽࠢࠥ࢘") % self.l11lllll
        l1l11l1l += l1lll1ll (u"ࠥࡩࡽࡺࡥ࡯ࡦࡢࡩࡽࡶࡩࡳࡧࡧࡣࡨࡵ࡯࡬࡫ࡨࡷ࠿ࠦࠥࡴࠢࡿࠤ࢙ࠧ") % self.l11l1lll
        l1l11l1l += l1lll1ll (u"ࠦࡪࡾࡰࡪࡴࡨࡨࡤࡺࡩ࡮ࡧࡢࡴࡱࡻࡳࡠࡪࡲࡹࡷࡀࠠࠦࡵ࢚ࠥ") % self.l11llll1
        return l1l11l1l
    def __unicode__(self):
        return self._11ll1l1()
    def __str__(self):
        return self._11ll1l1()
    def __del__(self):
        self.config.write()
l1l11l11 = Settings(l1l111ll)