#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11 = sys.version_info [0] == 2
l1l111 = 2048
ll = 7
def l1lll1l (l111l1):
    global l111111
    l1l1ll = ord (l111l1 [-1])
    l11lll = l111l1 [:-1]
    l11l1 = l1l1ll % len (l11lll)
    l11l1l = l11lll [:l11l1] + l11lll [l11l1:]
    if l11:
        l1ll1l1 = l1lll1l1 () .join ([unichr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    else:
        l1ll1l1 = str () .join ([chr (ord (char) - l1l111 - (l1ll11 + l1l1ll) % ll) for l1ll11, char in enumerate (l11l1l)])
    return eval (l1ll1l1)
import re
class l1ll1ll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llll111 = kwargs.get(l1lll1l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11ll11 = kwargs.get(l1lll1l (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1llllll1 = self.l11111ll(args)
        if l1llllll1:
            args=args+ l1llllll1
        self.args = [a for a in args]
    def l11111ll(self, *args):
        l1llllll1=None
        l11lll1l = args[0][0]
        if re.search(l1lll1l (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l11lll1l):
            l1llllll1 = (l1lll1l (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1llll111
                            ,)
        return l1llllll1
class l1llll1l1(Exception):
    def __init__(self, *args, **kwargs):
        l1llllll1 = self.l11111ll(args)
        if l1llllll1:
            args = args + l1llllll1
        self.args = [a for a in args]
    def l11111ll(self, *args):
        s = l1lll1l (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1lll1l (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1111l11(Exception):
    pass
class l1l11ll(Exception):
    pass
class l1llll1ll(Exception):
    def __init__(self, message, l1lll1lll, url):
        super(l1llll1ll,self).__init__(message)
        self.l1lll1lll = l1lll1lll
        self.url = url
class l1lll1ll1(Exception):
    pass
class l11111l1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1111111(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1111ll1(Exception):
    pass
class l111111l(Exception):
    pass
class l1111l1l(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllllll(Exception):
    pass
class l111l11l(Exception):
    pass