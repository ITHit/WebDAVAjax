#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11lll1 = sys.version_info [0] == 2
l111111 = 2048
l111ll1 = 7
def l1lll1ll (l1ll1l1l):
    global l111lll
    l1ll11ll = ord (l1ll1l1l [-1])
    l1llll = l1ll1l1l [:-1]
    l111l = l1ll11ll % len (l1llll)
    l11l1l = l1llll [:l111l] + l1llll [l111l:]
    if l11lll1:
        l1l1ll1 = l111l1l () .join ([unichr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    else:
        l1l1ll1 = str () .join ([chr (ord (char) - l111111 - (l1111l + l1ll11ll) % l111ll1) for l1111l, char in enumerate (l11l1l)])
    return eval (l1l1ll1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llllll1l=logging.WARNING
logger = logging.getLogger(l1lll1ll (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1llllll1l)
l11ll1ll = SysLogHandler(address=l1lll1ll (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1lll1ll (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l11ll1ll.setFormatter(formatter)
logger.addHandler(l11ll1ll)
ch = logging.StreamHandler()
ch.setLevel(l1llllll1l)
logger.addHandler(ch)
class l1lll1l111(io.FileIO):
    l1lll1ll (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1lll1ll (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll1111, l1lll11ll1,
                     options, d=0, p=0):
            self.device = device
            self.l1llll1111 = l1llll1111
            self.l1lll11ll1 = l1lll11ll1
            if not options:
                options = l1lll1ll (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1ll (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll1111,
                                              self.l1lll11ll1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll111l = os.path.join(os.path.sep, l1lll1ll (u"ࠪࡩࡹࡩࠧই"), l1lll1ll (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll111ll = path
        else:
            self._1lll111ll = self.l1llll111l
        super(l1lll1l111, self).__init__(self._1lll111ll, l1lll1ll (u"ࠬࡸࡢࠬࠩউ"))
    def _1lll1ll11(self, line):
        return l1lll1l111.Entry(*[x for x in line.strip(l1lll1ll (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1lll1ll (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1ll (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1ll (u"ࠤࠦࠦ঍")):
                    yield self._1lll1ll11(line)
            except ValueError:
                pass
    def l1llll11l1(self, attr, value):
        for entry in self.entries:
            l1llll1l11 = getattr(entry, attr)
            if l1llll1l11 == value:
                return entry
        return None
    def l1lll1lll1(self, entry):
        if self.l1llll11l1(l1lll1ll (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1lll1ll (u"ࠫࡡࡴࠧএ")).encode(l1lll1ll (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll111l1(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1ll (u"ࠢࠤࠤ঒")):
                if self._1lll1ll11(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1ll (u"ࠨࠩও").join(lines).encode(l1lll1ll (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lllllll1(cls, l1llll1111, path=None):
        l1lll1l11l = cls(path=path)
        entry = l1lll1l11l.l1llll11l1(l1lll1ll (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll1111)
        if entry:
            return l1lll1l11l.l1lll111l1(entry)
        return False
    @classmethod
    def add(cls, device, l1llll1111, l1lll11ll1, options=None, path=None):
        return cls(path=path).l1lll1lll1(l1lll1l111.Entry(device,
                                                    l1llll1111, l1lll11ll1,
                                                    options=options))
class l1llll1lll(object):
    def __init__(self, l1lllll11l):
        self.l1llll11ll=l1lll1ll (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1lll1ll1l=l1lll1ll (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lllll11l=l1lllll11l
        self.l1lll1l1l1()
        self.l1llllll11()
        self.l1lll11l1l()
        self.l1lll11lll()
        self.l1llll1l1l()
    def l1lll1l1l1(self):
        temp_file=open(l1lllll111,l1lll1ll (u"࠭ࡲࠨঘ"))
        l1ll11l1=temp_file.read()
        data=json.loads(l1ll11l1)
        self.user=data[l1lll1ll (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l11l1ll=data[l1lll1ll (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.l1ll111=data[l1lll1ll (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1llllll=data[l1lll1ll (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll1l1=data[l1lll1ll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lllll1ll=data[l1lll1ll (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll11l1l(self):
        l111ll=os.path.join(l1lll1ll (u"ࠨ࠯ࠣট"),l1lll1ll (u"ࠢࡶࡵࡵࠦঠ"),l1lll1ll (u"ࠣࡵࡥ࡭ࡳࠨড"),l1lll1ll (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1lll1ll (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l111ll)
    def l1llll1l1l(self):
        logger.info(l1lll1ll (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        l1ll111=os.path.join(self.l1llllll,self.l1llll11ll)
        l1lll11l11 = pwd.getpwnam(self.user).pw_uid
        l1lll1l1ll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll111):
            os.makedirs(l1ll111)
            os.system(l1lll1ll (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, l1ll111))
            logger.debug(l1lll1ll (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %l1ll111)
        else:
            logger.debug(l1lll1ll (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %l1ll111)
        l111ll=os.path.join(l1ll111, self.l1lll1ll1l)
        print(l111ll)
        logger.debug(l1lll1ll (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l111ll)
        with open(l111ll, l1lll1ll (u"ࠤࡺ࠯ࠧ঩")) as l1llll1ll1:
            logger.debug(self.l11l1ll + l1lll1ll (u"ࠪࠤࠬপ")+self.l1lllll1l1+l1lll1ll (u"ࠫࠥࠨࠧফ")+self.l1lllll1ll+l1lll1ll (u"ࠬࠨࠧব"))
            l1llll1ll1.writelines(self.l11l1ll + l1lll1ll (u"࠭ࠠࠨভ")+self.l1lllll1l1+l1lll1ll (u"ࠧࠡࠤࠪম")+self.l1lllll1ll+l1lll1ll (u"ࠨࠤࠪয"))
        os.chmod(l111ll, 0o600)
        os.chown(l111ll, l1lll11l11, l1lll1l1ll)
    def l1llllll11(self, l1lll11111=l1lll1ll (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1lll1ll (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11111 in groups:
            logger.info(l1lll1ll (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1lll11111))
        else:
            logger.warning(l1lll1ll (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1lll11111))
            l11lll=l1lll1ll (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1lll11111,self.user)
            logger.debug(l1lll1ll (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l11lll)
            os.system(l11lll)
            logger.debug(l1lll1ll (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll11lll(self):
        logger.debug(l1lll1ll (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1lll1l11l=l1lll1l111()
        l1lll1l11l.add(self.l11l1ll, self.l1ll111, l1lll11ll1=l1lll1ll (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1lll1ll (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1lll1ll (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1lllll111 = urllib.parse.unquote(sys.argv[1])
        if l1lllll111:
            l1lll1111l=l1llll1lll(l1lllll111)
        else:
            raise (l1lll1ll (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1lll1ll (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise