#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11l1l = sys.version_info [0] == 2
l1ll1 = 2048
l11111 = 7
def l11 (l1l111l):
    global l1lll11
    l11l11 = ord (l1l111l [-1])
    l1l1ll1 = l1l111l [:-1]
    l1llll = l11l11 % len (l1l1ll1)
    l1lll1ll = l1l1ll1 [:l1llll] + l1l1ll1 [l1llll:]
    if l11l1l:
        l1l1l1 = l1ll1l1 () .join ([unichr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    else:
        l1l1l1 = str () .join ([chr (ord (char) - l1ll1 - (l111l + l11l11) % l11111) for l111l, char in enumerate (l1lll1ll)])
    return eval (l1l1l1)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11ll1=logging.WARNING
logger = logging.getLogger(l11 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1lll11ll1)
l1l11ll1 = SysLogHandler(address=l11 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l11 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l11ll1.setFormatter(formatter)
logger.addHandler(l1l11ll1)
ch = logging.StreamHandler()
ch.setLevel(l1lll11ll1)
logger.addHandler(ch)
class l1lll11lll(io.FileIO):
    l11 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l11 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lllllll1, l1llllll11,
                     options, d=0, p=0):
            self.device = device
            self.l1lllllll1 = l1lllllll1
            self.l1llllll11 = l1llllll11
            if not options:
                options = l11 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lllllll1,
                                              self.l1llllll11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll1ll1l = os.path.join(os.path.sep, l11 (u"ࠨࡧࡷࡧࠬঅ"), l11 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lllll11l = path
        else:
            self._1lllll11l = self.l1lll1ll1l
        super(l1lll11lll, self).__init__(self._1lllll11l, l11 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll1l11l(self, line):
        return l1lll11lll.Entry(*[x for x in line.strip(l11 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l11 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l11 (u"ࠢࠤࠤঋ")):
                    yield self._1lll1l11l(line)
            except ValueError:
                pass
    def l1llllllll(self, attr, value):
        for entry in self.entries:
            l1lll1l111 = getattr(entry, attr)
            if l1lll1l111 == value:
                return entry
        return None
    def l1lll11l11(self, entry):
        if self.l1llllllll(l11 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l11 (u"ࠩ࡟ࡲࠬ঍")).encode(l11 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lllll111(self, entry):
        self.seek(0)
        lines = [l.decode(l11 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11 (u"ࠧࠩࠢঐ")):
                if self._1lll1l11l(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11 (u"࠭ࠧ঑").join(lines).encode(l11 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1l1ll(cls, l1lllllll1, path=None):
        l1llllll1l = cls(path=path)
        entry = l1llllll1l.l1llllllll(l11 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lllllll1)
        if entry:
            return l1llllll1l.l1lllll111(entry)
        return False
    @classmethod
    def add(cls, device, l1lllllll1, l1llllll11, options=None, path=None):
        return cls(path=path).l1lll11l11(l1lll11lll.Entry(device,
                                                    l1lllllll1, l1llllll11,
                                                    options=options))
class l1llll11ll(object):
    def __init__(self, l1llll1l1l):
        self.l1llll1lll=l11 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lllll1ll=l11 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll1l1l=l1llll1l1l
        self.l1llll1l11()
        self.l11111111()
        self.l1lll1l1l1()
        self.l1llll11l1()
        self.l1llll111l()
    def l1llll1l11(self):
        temp_file=open(l1llll1ll1,l11 (u"ࠫࡷ࠭খ"))
        l111=temp_file.read()
        data=json.loads(l111)
        self.user=data[l11 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1llll11=data[l11 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1l111=data[l11 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1l11=data[l11 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll11l1l=data[l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll1ll11=data[l11 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll1l1l1(self):
        l1ll1ll1=os.path.join(l11 (u"ࠦ࠴ࠨঝ"),l11 (u"ࠧࡻࡳࡳࠤঞ"),l11 (u"ࠨࡳࡣ࡫ࡱࠦট"),l11 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l11 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1ll1ll1)
    def l1llll111l(self):
        logger.info(l11 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1l111=os.path.join(self.l1l11,self.l1llll1lll)
        l1lll111ll = pwd.getpwnam(self.user).pw_uid
        l1lll1lll1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1l111):
            os.makedirs(l1l111)
            os.system(l11 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1l111))
            logger.debug(l11 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1l111)
        else:
            logger.debug(l11 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1l111)
        l1ll1ll1=os.path.join(l1l111, self.l1lllll1ll)
        print(l1ll1ll1)
        logger.debug(l11 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1ll1ll1)
        with open(l1ll1ll1, l11 (u"ࠢࡸ࠭ࠥধ")) as l1llll1111:
            logger.debug(self.l1llll11 + l11 (u"ࠨࠢࠪন")+self.l1lll11l1l+l11 (u"ࠩࠣࠦࠬ঩")+self.l1lll1ll11+l11 (u"ࠪࠦࠬপ"))
            l1llll1111.writelines(self.l1llll11 + l11 (u"ࠫࠥ࠭ফ")+self.l1lll11l1l+l11 (u"ࠬࠦࠢࠨব")+self.l1lll1ll11+l11 (u"࠭ࠢࠨভ"))
        os.chmod(l1ll1ll1, 0o600)
        os.chown(l1ll1ll1, l1lll111ll, l1lll1lll1)
    def l11111111(self, l1lll111l1=l11 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l11 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll111l1 in groups:
            logger.info(l11 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1lll111l1))
        else:
            logger.warning(l11 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1lll111l1))
            l1ll1l1l=l11 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1lll111l1,self.user)
            logger.debug(l11 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1ll1l1l)
            os.system(l1ll1l1l)
            logger.debug(l11 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1llll11l1(self):
        logger.debug(l11 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llllll1l=l1lll11lll()
        l1llllll1l.add(self.l1llll11, self.l1l111, l1llllll11=l11 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l11 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l11 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llll1ll1 = urllib.parse.unquote(sys.argv[1])
        if l1llll1ll1:
            l1lllll1l1=l1llll11ll(l1llll1ll1)
        else:
            raise (l11 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l11 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise