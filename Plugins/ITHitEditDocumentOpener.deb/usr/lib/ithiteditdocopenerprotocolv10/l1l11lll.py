#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l11 = 7
def l1l111l (l11ll1):
    global l1l1l
    l11lll1 = ord (l11ll1 [-1])
    l111 = l11ll1 [:-1]
    l1l = l11lll1 % len (l111)
    l11lll = l111 [:l1l] + l111 [l1l:]
    if l1ll111:
        l1l11l1 = l11l11l () .join ([unichr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l1lll11 - (l111l11 + l11lll1) % l11) for l111l11, char in enumerate (l11lll)])
    return eval (l1l11l1)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1lll1ll import l1l1l1l
from configobj import ConfigObj
l11ll1l1 = l1l111l (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l11l11 = l1l111l (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠵࠳࠻࠸࠲࠷࠱࠴ࠧࡢ")
l11ll11l = l1l111l (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1l111l (u"ࠨ࠵࠯࠴࠴࠲࠺࠾࠱࠶࠰࠳ࠦࡤ")
l1l1llll=os.path.join(os.environ.get(l1l111l (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1l111l (u"ࠣ࠰ࠨࡷࠧࡦ") %l11ll11l.replace(l1l111l (u"ࠤࠣࠦࡧ"), l1l111l (u"ࠥࡣࠧࡨ")).lower())
l1l1111l=os.environ.get(l1l111l (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1l111l (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l1l1l1=l1l11l11.replace(l1l111l (u"ࠨࠠࠣ࡫"), l1l111l (u"ࠢࡠࠤ࡬"))+l1l111l (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1l111l (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l1l111l1=os.path.join(os.environ.get(l1l111l (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l1l1l1)
elif platform.system() == l1l111l (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11llll1=l1l1l1l(l1l1llll+l1l111l (u"ࠧ࠵ࠢࡱ"))
    l1l111l1 = os.path.join(l11llll1, l1l1l1l1)
else:
    l1l111l1 = os.path.join( l1l1l1l1)
l1l1111l=l1l1111l.upper()
if l1l1111l == l1l111l (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l1l1lll1=logging.DEBUG
elif l1l1111l == l1l111l (u"ࠢࡊࡐࡉࡓࠧࡳ"): l1l1lll1 = logging.INFO
elif l1l1111l == l1l111l (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l1l1lll1 = logging.WARNING
elif l1l1111l == l1l111l (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l1l1lll1 = logging.ERROR
elif l1l1111l == l1l111l (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l1l1lll1 = logging.CRITICAL
elif l1l1111l == l1l111l (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l1l1lll1 = logging.NOTSET
logger = logging.getLogger(l1l111l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l1l1lll1)
l11lllll = logging.FileHandler(l1l111l1, mode=l1l111l (u"ࠨࡷࠬࠤࡹ"))
l11lllll.setLevel(l1l1lll1)
formatter = logging.Formatter(l1l111l (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1l111l (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l11lllll.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l1l1lll1)
l1ll1111 = SysLogHandler(address=l1l111l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1ll1111.setFormatter(formatter)
logger.addHandler(l11lllll)
logger.addHandler(ch)
logger.addHandler(l1ll1111)
class Settings():
    l11lll1l = l1l111l (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11lll11 = l1l111l (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l11l1l = l1l111l (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l11l11):
        self.l1l1ll1l = self._1l1l111(l1l11l11)
        self._1l11ll1()
    def _1l1l111(self, l1l11l11):
        l1l11111 = l1l11l11.split(l1l111l (u"ࠨࠠࠣࢀ"))
        l1l11111 = l1l111l (u"ࠢࠡࠤࢁ").join(l1l11111)
        if platform.system() == l1l111l (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l1ll1l = os.path.join(l1l1llll, l1l111l (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l11111 + l1l111l (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l1ll1l
    def l1l1l1ll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll1ll(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1l111l (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1l111l (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l1l11l(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11ll1(self):
        if not os.path.exists(os.path.dirname(self.l1l1ll1l)):
            os.makedirs(os.path.dirname(self.l1l1ll1l))
        if not os.path.exists(self.l1l1ll1l):
            self.config = ConfigObj(self.l1l1ll1l)
            self.config[l1l111l (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1l111l (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1l111l (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l11l1l
            self.config[l1l111l (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1l111l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11lll11
            self.config[l1l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1l111l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l11lll1l
            self.config[l1l111l (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1ll1l)
            self.l1l11l1l = self.get_value(l1l111l (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1l111l (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11lll11 = self.get_value(l1l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1l111l (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l11lll1l = self.get_value(l1l111l (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1l111l (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1ll111l(self):
        l1l111ll = l1l111l (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l11lll1l
        l1l111ll += l1l111l (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11lll11
        l1l111ll += l1l111l (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l11l1l
        return l1l111ll
    def __unicode__(self):
        return self._1ll111l()
    def __str__(self):
        return self._1ll111l()
    def __del__(self):
        self.config.write()
l1l1ll11 = Settings(l1l11l11)