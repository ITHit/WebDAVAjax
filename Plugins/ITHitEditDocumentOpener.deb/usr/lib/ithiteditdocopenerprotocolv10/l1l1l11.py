#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l11111l = 7
def l1ll11l (l1lll1l1):
    global l111111
    l1ll1l1 = ord (l1lll1l1 [-1])
    l1ll111 = l1lll1l1 [:-1]
    l11l1 = l1ll1l1 % len (l1ll111)
    l1l1111 = l1ll111 [:l11l1] + l1ll111 [l11l1:]
    if l11ll1:
        l1ll11 = l1llll1l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    return eval (l1ll11)
import logging
import os
import re
from l1ll1 import l1111111
logger = logging.getLogger(l1ll11l (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢॴ"))
def l1llll1(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll11l (u"ࠨࡾࠣॵ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1l1lll():
    try:
        out = os.popen(l1ll11l (u"ࠢ࠰ࡷࡶࡶ࠴ࡹࡢࡪࡰ࠲ࡱࡴࡻ࡮ࡵ࠰ࡧࡥࡻ࡬ࡳࠡ࠯࡙ࠦॶ")).read()
        if out:
            result = re.findall(l1ll11l (u"ࡳࠤࡧࡥࡻ࡬ࡳ࠯࠭ࡂࠬࡠࡢࡤࡽ࡞࠱ࡡ࠰ࡅࠩ࡝ࡵࠥॷ"), out)
            if result:
                result = l1ll11l (u"ࠤࠥॸ").join(result)
                logger.info(l1ll11l (u"࡚ࠥࡪࡸࡳࡪࡱࡱࠤࡴ࡬ࠠࡥࡣࡹࡪࡸࠦࡵࡴࡧ࠽ࡠࡳࡢࡴࠡࠧࡶࠦॹ") % l1ll11l (u"ࠦࠧॺ").join(result))
                return result
        else:
            raise Exception(l1ll11l (u"ࠧࡪࡡࡷࡨࡶ࠶ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣॻ"))
    except:
        logger.exception(l1ll11l (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡩࡵࡪࠣࡨࡪࡺࡥࡤࡶࠣࡨࡦࡼࡦࡴ࠴ࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠧॼ"))
        raise l1111111(l1ll11l (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡤࡦࡶࡨࡧࡹࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠡࡏࡤࡽࠥࡨࡥࠡ࡫ࡷࠤ࡮ࡹࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࠮ࠣॽ"))
if __name__ == l1ll11l (u"ࠣࡡࡢࡱࡦ࡯࡮ࡠࡡࠥॾ"):
    l1llll1(l1ll11l (u"ࠤࢁ࠳࠳࡯ࡴࡩ࡫ࡷ࠳ࡩࡪࡤ࠰ࡨࡩࡪ࡫࠵ࡦࡧࡨ࠱ࡸࡽࡺࠢॿ"))