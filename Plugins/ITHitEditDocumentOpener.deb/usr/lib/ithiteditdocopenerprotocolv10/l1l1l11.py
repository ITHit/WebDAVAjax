#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import re
class l1lllll(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllll1l = kwargs.get(l111lll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡩࡷࠧࢮ"))
        self.l1l111l = kwargs.get(l111lll (u"ࠦࡸ࡫ࡲࡷࡧࡵ࡙ࡷ࡯ࠢࢯ"))
        l1lllllll = self.l1111l11(args)
        if l1lllllll:
            args=args+ l1lllllll
        self.args = [a for a in args]
    def l1111l11(self, *args):
        l1lllllll=None
        l1l11ll1 = args[0][0]
        if re.search(l111lll (u"ࠧࡔ࡯ࠡࡍࡨࡶࡧ࡫ࡲࡰࡵࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠦࢰ"), l1l11ll1):
            l1lllllll = (l111lll (u"࡙࠭ࡰࡷࠣ࡬ࡦࡼࡥࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࠨࡷࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠯ࠢࡌࡲࠥࡩࡡࡴࡧࠣࡽࡴࡻࡲࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡹࡩ࡯ࡩࠣࡒ࡙ࡒࡍࠡࡱࡵࠤࡐ࡫ࡲࡣࡧࡵࡳࡸࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡥࡣࡹࡪࡸ࠸ࠠ࠲࠰࠸࠲࠷ࠦ࡯ࡳࠢ࡯ࡥࡹ࡫ࡲࠡ࡫ࡶࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩ࠴ࠧࢱ") %self.l1lllll1l
                            ,)
        return l1lllllll
class l1llll11l(Exception):
    def __init__(self, *args, **kwargs):
        l1lllllll = self.l1111l11(args)
        if l1lllllll:
            args = args + l1lllllll
        self.args = [a for a in args]
    def l1111l11(self, *args):
        s = l111lll (u"ࠢࠡ࠯ࠣࡊࡴࡸࠠࡐࡲࡨࡲࡘࡻࡳࡦࠢࡳࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡈࡦࡼࡦࡴ࠴ࠣࡂࡂ࠷࠮࠶࠰࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦ࡜࡯࡛ࡲࡹࠥࡩࡡ࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࡮ࡺࠠࡧࡴࡲࡱࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡰࡨࡷࡻࡦࡸࡥ࠯ࡱࡳࡩࡳࡹࡵࡴࡧ࠱ࡳࡷ࡭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰࡫ࡸࡲࡲ࠿ࡱࡴࡲ࡮ࡪࡩࡴ࠾ࡪࡲࡱࡪࠫ࠳ࡂࡕࡤࡹࡪࡸ࡬ࡢࡰࡧࠪࡵࡧࡣ࡬ࡣࡪࡩࡂࡪࡡࡷࡨࡶ࠶ࠥࡢ࡮ࠣࢲ")
        s += l111lll (u"ࠣࠢ࠰ࠤࡋࡵࡲࠡࡆࡨࡦ࡮ࡧ࡮ࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴࡳࠡࠪࡘࡦࡺࡴࡴࡶ࠮ࠣࡏࡺࡨࡵ࡯ࡶࡸ࠰ࠥ࡫ࡴࡤ࠰ࠬࠤ࡮ࡴࠠࡤࡱࡱࡷࡴࡲࡥࠡࡹ࡬ࡸ࡭ࠦࡲࡰࡱࡷࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡨࡼࡪࡩࡵࡵࡧࠣࡠࠧࡹࡵࡥࡱࠣࡥࡵࡺ࠭ࡨࡧࡷࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡪࡡࡷࡨࡶ࠶ࡡࠨࠠ࡝ࡰࠥࢳ")
        return (s,)
class l11111ll(Exception):
    pass
class l1ll11ll(Exception):
    pass
class l1lllll11(Exception):
    def __init__(self, message, l1llll111, url):
        super(l1lllll11,self).__init__(message)
        self.l1llll111 = l1llll111
        self.url = url
class l1llll1ll(Exception):
    pass
class l1111111(Exception):
    pass
class l1lll1l11(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lll11ll(Exception):
    pass
class l111111l(Exception):
    pass
class l1llll1l1(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1llllll1(Exception):
    pass
class l111l1l1(Exception):
    pass