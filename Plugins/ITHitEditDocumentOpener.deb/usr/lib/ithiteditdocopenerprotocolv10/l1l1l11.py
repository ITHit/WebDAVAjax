#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll111 = sys.version_info [0] == 2
l1l1lll = 2048
l11l1l1 = 7
def l11ll11 (l1ll1lll):
    global l1llllll
    l111111 = ord (l1ll1lll [-1])
    l1lll11l = l1ll1lll [:-1]
    l11111l = l111111 % len (l1lll11l)
    l11l111 = l1lll11l [:l11111l] + l1lll11l [l11111l:]
    if l1lll111:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l1lll - (l11l1 + l111111) % l11l1l1) for l11l1, char in enumerate (l11l111)])
    return eval (l11l11l)
import hashlib
import os
import l1l11l1
from l1111l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1l11l1 import l1ll1l1
from l1ll1ll1 import l1l1, l1lll1
import logging
logger = logging.getLogger(l11ll11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l111ll1():
    def __init__(self, l11ll,l1lll1l1, l11llll= None, l1lll1ll=None):
        self.l11ll1=False
        self.l11l = self._1ll11ll()
        self.l1lll1l1 = l1lll1l1
        self.l11llll = l11llll
        self.l1lllll1 = l11ll
        if l11llll:
            self.l1ll1 = True
        else:
            self.l1ll1 = False
        self.l1lll1ll = l1lll1ll
    def _1ll11ll(self):
        try:
            return l1l11l1.l11l1l() is not None
        except:
            return False
    def open(self):
        l11ll11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11l:
            raise NotImplementedError(l11ll11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11ll11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1llll1 = self.l1lllll1
        if self.l1lll1l1.lower().startswith(self.l1lllll1.lower()):
            l1l = re.compile(re.escape(self.l1lllll1), re.IGNORECASE)
            l1lll1l1 = l1l.sub(l11ll11 (u"ࠨࠩࠄ"), self.l1lll1l1)
            l1lll1l1 = l1lll1l1.replace(l11ll11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11ll11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1l1l(self.l1lllll1, l1llll1, l1lll1l1, self.l11llll)
    def l1l1l1l(self,l1lllll1, l1llll1, l1lll1l1, l11llll):
        l11ll11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11ll11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1ll1 = l1111ll(l1lllll1)
        l1lll1l = self.l1ll1l11(l1l1ll1)
        logger.info(l11ll11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1ll1)
        if l1lll1l:
            logger.info(l11ll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1ll1l1(l1l1ll1)
            l1l1ll1 = l1ll1ll(l1lllll1, l1llll1, l11llll, self.l1lll1ll)
        logger.debug(l11ll11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1l111l=l1l1ll1 + l11ll11 (u"ࠤ࠲ࠦࠌ") + l1lll1l1
        l1l1111 = l11ll11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1l111l+ l11ll11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1111)
        l1llll1l = os.system(l1l1111)
        if (l1llll1l != 0):
            raise IOError(l11ll11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1l111l, l1llll1l))
    def l1ll1l11(self, l1l1ll1):
        if os.path.exists(l1l1ll1):
            if os.path.islink(l1l1ll1):
                l1l1ll1 = os.readlink(l1l1ll1)
            if os.path.ismount(l1l1ll1):
                return True
        return False
def l1111ll(l1lllll1):
    l1ll1111 = l1lllll1.replace(l11ll11 (u"࠭࡜࡝ࠩࠐ"), l11ll11 (u"ࠧࡠࠩࠑ")).replace(l11ll11 (u"ࠨ࠱ࠪࠒ"), l11ll11 (u"ࠩࡢࠫࠓ"))
    l1ll11l = l11ll11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1l1ll=os.environ[l11ll11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l111l=os.path.join(l1l1ll,l1ll11l, l1ll1111)
    l1ll11=os.path.abspath(l111l)
    return l1ll11
def l11lll(l1ll1l1l):
    if not os.path.exists(l1ll1l1l):
        os.makedirs(l1ll1l1l)
def l1l1l1(l1lllll1, l1llll1, l111=None, password=None):
    l11ll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1ll1l1l = l1111ll(l1lllll1)
    l11lll(l1ll1l1l)
    if not l111:
        l1lll = l1lll11()
        l1l11 =l1lll.l1ll(l11ll11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1llll1 + l11ll11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1llll1 + l11ll11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1l11, str):
            l111, password = l1l11
        else:
            raise l1lll1()
        logger.info(l11ll11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1ll1l1l))
    l111l11 = pwd.getpwuid( os.getuid())[0]
    l11ll1l=os.environ[l11ll11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11lll1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1llll={l11ll11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l111l11, l11ll11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1lllll1, l11ll11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1ll1l1l, l11ll11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l11ll1l, l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111, l11ll11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1llll, temp_file)
        if not os.path.exists(os.path.join(l11lll1, l11ll11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1l1l=l11ll11 (u"ࠦࡵࡿࠢࠣ")
            key=l11ll11 (u"ࠧࠨࠤ")
        else:
            l1l1l=l11ll11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11ll11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        ll=l11ll11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1l1l,temp_file.name)
        l11l1ll=[l11ll11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11ll11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11lll1, ll)]
        p = subprocess.Popen(l11l1ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11ll11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11ll11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11ll11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1ll1l1l
    logger.debug(l11ll11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11ll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11ll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11ll11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11=os.path.abspath(l1ll1l1l)
    logger.debug(l11ll11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11)
    return l1ll11
def l1ll1ll(l1lllll1, l1llll1, l11llll, l1lll1ll):
    l11ll11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1(title):
        l1111=30
        if len(title)>l1111:
            l1ll1l=title.split(l11ll11 (u"ࠨ࠯ࠣ࠳"))
            l1l11l=l11ll11 (u"ࠧࠨ࠴")
            for block in l1ll1l:
                l1l11l+=block+l11ll11 (u"ࠣ࠱ࠥ࠵")
                if len(l1l11l) > l1111:
                    l1l11l+=l11ll11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l11l
        return title
    def l11l11(l11111, password):
        l11ll11 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11ll11 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11ll11 (u"ࠧࠦࠢ࠹").join(l11111)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11 = l11ll11 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11.encode())
        l1l11ll = [l11ll11 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1llll11 = l11ll11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1llll11)
            for e in l1l11ll:
                if e in l1llll11: return False
            raise l1l1(l1llll11, l1ll1ll=l1l11l1.l11l1l(), l1llll1=l1llll1)
        logger.info(l11ll11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l111 = l11ll11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11ll11 (u"ࠦࠧ࠿")
    os.system(l11ll11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1ll111l = l1111ll(l1lllll1)
    l1ll1l1l = l1111ll(hashlib.sha1(l1lllll1.encode()).hexdigest()[:10])
    l11lll(l1ll1l1l)
    logger.info(l11ll11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1ll1l1l))
    if l11llll:
        l11111 = [l11ll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11ll11 (u"ࠤ࠰ࡸࠧࡄ"), l11ll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11ll11 (u"ࠫ࠲ࡵࠧࡆ"), l11ll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l111, l11llll),
                    urllib.parse.unquote(l1llll1), os.path.abspath(l1ll1l1l)]
        l11l11(l11111, password)
    else:
        while True:
            l111, password = l1ll11l1(l1ll1l1l, l1llll1, l1lll1ll)
            if l111.lower() != l11ll11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11111 = [l11ll11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11ll11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11ll11 (u"ࠤ࠰ࡸࠧࡋ"), l11ll11 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11ll11 (u"ࠫ࠲ࡵࠧࡍ"), l11ll11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l111,
                            urllib.parse.unquote(l1llll1), os.path.abspath(l1ll1l1l)]
            else:
                raise l1lll1()
            if l11l11(l11111, password): break
    os.system(l11ll11 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1ll1l1l, l1ll111l))
    l1ll11=os.path.abspath(l1ll111l)
    return l1ll11
def l1ll11l1(l1lllll1, l1llll1, l1lll1ll):
    l111ll = os.path.join(os.environ[l11ll11 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11ll11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11ll11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l111ll)):
       os.makedirs(os.path.dirname(l111ll))
    l111l1 = l1lll1ll.get_value(l11ll11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11ll11 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1lll = l1lll11(l1lllll1, l111l1)
    l111, password = l1lll.l1ll(l11ll11 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1llll1 + l11ll11 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1llll1 + l11ll11 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l111 != l11ll11 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l111(l1lllll1, l111):
        l111lll = l11ll11 (u"ࠤ࡙ࠣࠦ").join([l1lllll1, l111, l11ll11 (u"࡚ࠪࠦࠬ") + password + l11ll11 (u"࡛ࠫࠧ࠭"), l11ll11 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l111ll, l11ll11 (u"࠭ࡷࠬࠩ࡝")) as l111l1l:
            l111l1l.write(l111lll)
        os.chmod(l111ll, 0o600)
    return l111, password
def l1l111(l1lllll1, l111):
    l111ll = l1ll111 = os.path.join(os.environ[l11ll11 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11ll11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11ll11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l111ll):
        with open(l111ll, l11ll11 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1lllll = data[0].split(l11ll11 (u"ࠦࠥࠨࡢ"))
            if l1lllll1 == l1lllll[0] and l111 == l1lllll[1]:
                return True
    return False