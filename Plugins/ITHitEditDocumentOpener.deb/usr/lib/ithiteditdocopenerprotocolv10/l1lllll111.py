#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1l = 2048
l1llll1l = 7
def l11l (l11ll1):
    global l1lll11l
    l1ll1 = ord (l11ll1 [-1])
    l11ll11 = l11ll1 [:-1]
    l11l111 = l1ll1 % len (l11ll11)
    l1l1l = l11ll11 [:l11l111] + l11ll11 [l11l111:]
    if l111ll1:
        l11l11l = l1111l1 () .join ([unichr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    else:
        l11l11l = str () .join ([chr (ord (char) - l1l - (l111l1 + l1ll1) % l1llll1l) for l111l1, char in enumerate (l1l1l)])
    return eval (l11l11l)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1llllll11=logging.WARNING
logger = logging.getLogger(l11l (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1llllll11)
l1l11l11 = SysLogHandler(address=l11l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l11l (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l11l11.setFormatter(formatter)
logger.addHandler(l1l11l11)
ch = logging.StreamHandler()
ch.setLevel(l1llllll11)
logger.addHandler(ch)
class l1lll1l11l(io.FileIO):
    l11l (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l11l (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll111ll, l1lll11l1l,
                     options, d=0, p=0):
            self.device = device
            self.l1lll111ll = l1lll111ll
            self.l1lll11l1l = l1lll11l1l
            if not options:
                options = l11l (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l11l (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll111ll,
                                              self.l1lll11l1l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1lll11lll = os.path.join(os.path.sep, l11l (u"ࠨࡧࡷࡧࠬঅ"), l11l (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._11111111 = path
        else:
            self._11111111 = self.l1lll11lll
        super(l1lll1l11l, self).__init__(self._11111111, l11l (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lll111l1(self, line):
        return l1lll1l11l.Entry(*[x for x in line.strip(l11l (u"ࠦࡡࡴࠢঈ")).split() if x not in (l11l (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l11l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l11l (u"ࠢࠤࠤঋ")):
                    yield self._1lll111l1(line)
            except ValueError:
                pass
    def l1llll11l1(self, attr, value):
        for entry in self.entries:
            l1lllll1l1 = getattr(entry, attr)
            if l1lllll1l1 == value:
                return entry
        return None
    def l1lll1ll11(self, entry):
        if self.l1llll11l1(l11l (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l11l (u"ࠩ࡟ࡲࠬ঍")).encode(l11l (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1llll1l1l(self, entry):
        self.seek(0)
        lines = [l.decode(l11l (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l11l (u"ࠧࠩࠢঐ")):
                if self._1lll111l1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l11l (u"࠭ࠧ঑").join(lines).encode(l11l (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll1ll1l(cls, l1lll111ll, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1llll11l1(l11l (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll111ll)
        if entry:
            return l1llll1ll1.l1llll1l1l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll111ll, l1lll11l1l, options=None, path=None):
        return cls(path=path).l1lll1ll11(l1lll1l11l.Entry(device,
                                                    l1lll111ll, l1lll11l1l,
                                                    options=options))
class l1llllllll(object):
    def __init__(self, l1llllll1l):
        self.l1lll1l1ll=l11l (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll1l1l1=l11l (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llllll1l=l1llllll1l
        self.l1llll1111()
        self.l1lll1llll()
        self.l1lll1lll1()
        self.l1lllll1ll()
        self.l1llll111l()
    def l1llll1111(self):
        temp_file=open(l1llll11ll,l11l (u"ࠫࡷ࠭খ"))
        l111l=temp_file.read()
        data=json.loads(l111l)
        self.user=data[l11l (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1lllll1=data[l11l (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11ll=data[l11l (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1l111=data[l11l (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll11l11=data[l11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll1l111=data[l11l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll1lll1(self):
        l11lll=os.path.join(l11l (u"ࠦ࠴ࠨঝ"),l11l (u"ࠧࡻࡳࡳࠤঞ"),l11l (u"ࠨࡳࡣ࡫ࡱࠦট"),l11l (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l11l (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l11lll)
    def l1llll111l(self):
        logger.info(l11l (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11ll=os.path.join(self.l1l111,self.l1lll1l1ll)
        l1llll1l11 = pwd.getpwnam(self.user).pw_uid
        l1lllll11l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11ll):
            os.makedirs(l11ll)
            os.system(l11l (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11ll))
            logger.debug(l11l (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11ll)
        else:
            logger.debug(l11l (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11ll)
        l11lll=os.path.join(l11ll, self.l1lll1l1l1)
        print(l11lll)
        logger.debug(l11l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l11lll)
        with open(l11lll, l11l (u"ࠢࡸ࠭ࠥধ")) as l1lll11ll1:
            logger.debug(self.l1lllll1 + l11l (u"ࠨࠢࠪন")+self.l1lll11l11+l11l (u"ࠩࠣࠦࠬ঩")+self.l1lll1l111+l11l (u"ࠪࠦࠬপ"))
            l1lll11ll1.writelines(self.l1lllll1 + l11l (u"ࠫࠥ࠭ফ")+self.l1lll11l11+l11l (u"ࠬࠦࠢࠨব")+self.l1lll1l111+l11l (u"࠭ࠢࠨভ"))
        os.chmod(l11lll, 0o600)
        os.chown(l11lll, l1llll1l11, l1lllll11l)
    def l1lll1llll(self, l1lllllll1=l11l (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l11l (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lllllll1 in groups:
            logger.info(l11l (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1lllllll1))
        else:
            logger.warning(l11l (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1lllllll1))
            l1l1l1l=l11l (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1lllllll1,self.user)
            logger.debug(l11l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1l1l1l)
            os.system(l1l1l1l)
            logger.debug(l11l (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lllll1ll(self):
        logger.debug(l11l (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llll1ll1=l1lll1l11l()
        l1llll1ll1.add(self.l1lllll1, self.l11ll, l1lll11l1l=l11l (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l11l (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llll11ll = urllib.parse.unquote(sys.argv[1])
        if l1llll11ll:
            l1llll1lll=l1llllllll(l1llll11ll)
        else:
            raise (l11l (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l11l (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise