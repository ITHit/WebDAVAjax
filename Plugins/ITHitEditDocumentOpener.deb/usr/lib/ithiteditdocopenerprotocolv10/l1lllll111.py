#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll11l1 = sys.version_info [0] == 2
l11 = 2048
l1ll11ll = 7
def l1lll1ll (l1lll111):
    global l1l1ll1
    l1l11 = ord (l1lll111 [-1])
    l1llll11 = l1lll111 [:-1]
    l1l1 = l1l11 % len (l1llll11)
    l1l1111 = l1llll11 [:l1l1] + l1llll11 [l1l1:]
    if l1ll11l1:
        l1111ll = l111l1 () .join ([unichr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    else:
        l1111ll = str () .join ([chr (ord (char) - l11 - (l1l11l1 + l1l11) % l1ll11ll) for l1l11l1, char in enumerate (l1l1111)])
    return eval (l1111ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllll1l1=logging.WARNING
logger = logging.getLogger(l1lll1ll (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1lllll1l1)
l1l11lll = SysLogHandler(address=l1lll1ll (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1lll1ll (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l11lll.setFormatter(formatter)
logger.addHandler(l1l11lll)
ch = logging.StreamHandler()
ch.setLevel(l1lllll1l1)
logger.addHandler(ch)
class l1lll1llll(io.FileIO):
    l1lll1ll (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1lll1ll (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1ll11, l1llll11l1,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll11 = l1lll1ll11
            self.l1llll11l1 = l1llll11l1
            if not options:
                options = l1lll1ll (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1ll (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1ll11,
                                              self.l1llll11l1,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll111l = os.path.join(os.path.sep, l1lll1ll (u"ࠨࡧࡷࡧࠬঅ"), l1lll1ll (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1ll = path
        else:
            self._1lll1l1ll = self.l1llll111l
        super(l1lll1llll, self).__init__(self._1lll1l1ll, l1lll1ll (u"ࠪࡶࡧ࠱ࠧই"))
    def _1llllllll(self, line):
        return l1lll1llll.Entry(*[x for x in line.strip(l1lll1ll (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1lll1ll (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1ll (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1ll (u"ࠢࠤࠤঋ")):
                    yield self._1llllllll(line)
            except ValueError:
                pass
    def l1lll11ll1(self, attr, value):
        for entry in self.entries:
            l1lll1l11l = getattr(entry, attr)
            if l1lll1l11l == value:
                return entry
        return None
    def l1lll111l1(self, entry):
        if self.l1lll11ll1(l1lll1ll (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1lll1ll (u"ࠩ࡟ࡲࠬ঍")).encode(l1lll1ll (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll11l1l(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1ll (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1ll (u"ࠧࠩࠢঐ")):
                if self._1llllllll(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1ll (u"࠭ࠧ঑").join(lines).encode(l1lll1ll (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lllll1ll(cls, l1lll1ll11, path=None):
        l1llll1111 = cls(path=path)
        entry = l1llll1111.l1lll11ll1(l1lll1ll (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1ll11)
        if entry:
            return l1llll1111.l1lll11l1l(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll11, l1llll11l1, options=None, path=None):
        return cls(path=path).l1lll111l1(l1lll1llll.Entry(device,
                                                    l1lll1ll11, l1llll11l1,
                                                    options=options))
class l1lll11lll(object):
    def __init__(self, l1llll11ll):
        self.l1llllll1l=l1lll1ll (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lllllll1=l1lll1ll (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll11ll=l1llll11ll
        self.l1lll1ll1l()
        self.l1llll1ll1()
        self.l1lll1lll1()
        self.l1lll111ll()
        self.l1llll1l1l()
    def l1lll1ll1l(self):
        temp_file=open(l1lll1l111,l1lll1ll (u"ࠫࡷ࠭খ"))
        l111ll1=temp_file.read()
        data=json.loads(l111ll1)
        self.user=data[l1lll1ll (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1lll1l1=data[l1lll1ll (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1ll1lll=data[l1lll1ll (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1lll1=data[l1lll1ll (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1llll1l11=data[l1lll1ll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1llll1lll=data[l1lll1ll (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lll1lll1(self):
        l11111l=os.path.join(l1lll1ll (u"ࠦ࠴ࠨঝ"),l1lll1ll (u"ࠧࡻࡳࡳࠤঞ"),l1lll1ll (u"ࠨࡳࡣ࡫ࡱࠦট"),l1lll1ll (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1lll1ll (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l11111l)
    def l1llll1l1l(self):
        logger.info(l1lll1ll (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1ll1lll=os.path.join(self.l1lll1,self.l1llllll1l)
        l1llllll11 = pwd.getpwnam(self.user).pw_uid
        l11111111 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1ll1lll):
            os.makedirs(l1ll1lll)
            os.system(l1lll1ll (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1ll1lll))
            logger.debug(l1lll1ll (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1ll1lll)
        else:
            logger.debug(l1lll1ll (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1ll1lll)
        l11111l=os.path.join(l1ll1lll, self.l1lllllll1)
        print(l11111l)
        logger.debug(l1lll1ll (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l11111l)
        with open(l11111l, l1lll1ll (u"ࠢࡸ࠭ࠥধ")) as l1lll1l1l1:
            logger.debug(self.l1lll1l1 + l1lll1ll (u"ࠨࠢࠪন")+self.l1llll1l11+l1lll1ll (u"ࠩࠣࠦࠬ঩")+self.l1llll1lll+l1lll1ll (u"ࠪࠦࠬপ"))
            l1lll1l1l1.writelines(self.l1lll1l1 + l1lll1ll (u"ࠫࠥ࠭ফ")+self.l1llll1l11+l1lll1ll (u"ࠬࠦࠢࠨব")+self.l1llll1lll+l1lll1ll (u"࠭ࠢࠨভ"))
        os.chmod(l11111l, 0o600)
        os.chown(l11111l, l1llllll11, l11111111)
    def l1llll1ll1(self, l1lll11l11=l1lll1ll (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1lll1ll (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1lll11l11 in groups:
            logger.info(l1lll1ll (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1lll11l11))
        else:
            logger.warning(l1lll1ll (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1lll11l11))
            l11l11l=l1lll1ll (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1lll11l11,self.user)
            logger.debug(l1lll1ll (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l11l11l)
            os.system(l11l11l)
            logger.debug(l1lll1ll (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll111ll(self):
        logger.debug(l1lll1ll (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1llll1111=l1lll1llll()
        l1llll1111.add(self.l1lll1l1, self.l1ll1lll, l1llll11l1=l1lll1ll (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1lll1ll (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1lll1ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1l111 = urllib.parse.unquote(sys.argv[1])
        if l1lll1l111:
            l1lllll11l=l1lll11lll(l1lll1l111)
        else:
            raise (l1lll1ll (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1lll1ll (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise