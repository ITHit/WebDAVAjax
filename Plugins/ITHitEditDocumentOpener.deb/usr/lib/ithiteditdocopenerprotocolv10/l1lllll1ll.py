#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l11ll1 = sys.version_info [0] == 2
l1ll11l1 = 2048
l11111l = 7
def l1ll11l (l1lll1l1):
    global l111111
    l1ll1l1 = ord (l1lll1l1 [-1])
    l1ll111 = l1lll1l1 [:-1]
    l11l1 = l1ll1l1 % len (l1ll111)
    l1l1111 = l1ll111 [:l11l1] + l1ll111 [l11l1:]
    if l11ll1:
        l1ll11 = l1llll1l () .join ([unichr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1ll11l1 - (l1lll1 + l1ll1l1) % l11111l) for l1lll1, char in enumerate (l1l1111)])
    return eval (l1ll11)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11l1l=logging.WARNING
logger = logging.getLogger(l1ll11l (u"ࠥ࡭ࡹ࡮ࡩࡵࡧࡧ࡭ࡹࡪ࡯ࡤࡷࡰࡩࡳࡺ࡯ࡱࡧࡱࡩࡷ࠴ࡳࡦࡶࡢࡱࡴࡻ࡮ࡵࡡࡧ࡭ࡸࡱࠢঀ"))
logger.setLevel(l1lll11l1l)
l1l1111l = SysLogHandler(address=l1ll11l (u"ࠫ࠴ࡪࡥࡷ࠱࡯ࡳ࡬࠭ঁ"))
formatter = logging.Formatter(l1ll11l (u"ࠬࠫࠨ࡯ࡣࡰࡩ࠮ࡹࠠࠦࠪ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩ࠮ࡹ࠺ࠦࠪࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࡸࡀࠥࠩ࡮࡬ࡲࡪࡴ࡯ࠪࡦࠣ࠱࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫং"))
l1l1111l.setFormatter(formatter)
logger.addHandler(l1l1111l)
ch = logging.StreamHandler()
ch.setLevel(l1lll11l1l)
logger.addHandler(ch)
class l1lll1lll1(io.FileIO):
    l1ll11l (u"ࠨࠢࠣࡖ࡫࡭ࡸࠦࡣ࡭ࡣࡶࡷࠥ࡫ࡸࡵࡧࡱࡨࡸࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡰࡴࡧࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡲࡥ࡮ࡧࡱࡸࠥࡧࠠࡧ࡫࡯ࡩࠥࡸࡥࡢࡦࡨࡶ࠴ࡽࡲࡪࡶࡨࡶࠏࠦࠠࠡࠢࡩࡳࡷࠦࡦࡪ࡮ࡨࠤࡥ࠵ࡥࡵࡥ࠲ࡪࡸࡺࡡࡣࡢࠍࠤࠥࠦࠠࠣࠤࠥঃ")
    class Entry(object):
        l1ll11l (u"ࠢࠣࠤࡈࡲࡹࡸࡹࠡࡥ࡯ࡥࡸࡹࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡶࠤࡦࠦ࡮ࡰࡰ࠰ࡧࡴࡳ࡭ࡦࡰࡷࠤࡱ࡯࡮ࡦࠢࡲࡲࠥࡺࡨࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠡࡨ࡬ࡰࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ঄")
        def __init__(self, device, l1llll11ll, l1lllll11l,
                     options, d=0, p=0):
            self.device = device
            self.l1llll11ll = l1llll11ll
            self.l1lllll11l = l1lllll11l
            if not options:
                options = l1ll11l (u"ࠣࡦࡨࡪࡦࡻ࡬ࡵࡵࠥঅ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1ll11l (u"ࠤࡾࢁࠥࢁࡽࠡࡽࢀࠤࢀࢃࠠࡼࡿࠣࡿࢂࠨআ").format(self.device,
                                              self.l1llll11ll,
                                              self.l1lllll11l,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll111l = os.path.join(os.path.sep, l1ll11l (u"ࠪࡩࡹࡩࠧই"), l1ll11l (u"ࠫ࡫ࡹࡴࡢࡤࠪঈ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1ll = path
        else:
            self._1lll1l1ll = self.l1llll111l
        super(l1lll1lll1, self).__init__(self._1lll1l1ll, l1ll11l (u"ࠬࡸࡢࠬࠩউ"))
    def _1lllll111(self, line):
        return l1lll1lll1.Entry(*[x for x in line.strip(l1ll11l (u"ࠨ࡜࡯ࠤঊ")).split() if x not in (l1ll11l (u"ࠧࠨঋ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1ll11l (u"ࠨࡷࡶ࠱ࡦࡹࡣࡪ࡫ࠪঌ"))
            try:
                if line.strip() and not line.strip().startswith(l1ll11l (u"ࠤࠦࠦ঍")):
                    yield self._1lllll111(line)
            except ValueError:
                pass
    def l1lll11ll1(self, attr, value):
        for entry in self.entries:
            l1lll1ll1l = getattr(entry, attr)
            if l1lll1ll1l == value:
                return entry
        return None
    def l1lll1l11l(self, entry):
        if self.l1lll11ll1(l1ll11l (u"ࠪࡨࡪࡼࡩࡤࡧࠪ঎"), entry.device):
            return False
        self.write((str(entry) + l1ll11l (u"ࠫࡡࡴࠧএ")).encode(l1ll11l (u"ࠬࡻࡳ࠮ࡣࡶࡧ࡮࡯ࠧঐ")))
        self.truncate()
        return entry
    def l1lll1l1l1(self, entry):
        self.seek(0)
        lines = [l.decode(l1ll11l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨ঑")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1ll11l (u"ࠢࠤࠤ঒")):
                if self._1lllll111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1ll11l (u"ࠨࠩও").join(lines).encode(l1ll11l (u"ࠩࡸࡷ࠲ࡧࡳࡤ࡫࡬ࠫঔ")))
        self.truncate()
        return True
    @classmethod
    def l1lll111l1(cls, l1llll11ll, path=None):
        l1llll1ll1 = cls(path=path)
        entry = l1llll1ll1.l1lll11ll1(l1ll11l (u"ࠪࡱࡴࡻ࡮ࡵࡲࡲ࡭ࡳࡺࠧক"), l1llll11ll)
        if entry:
            return l1llll1ll1.l1lll1l1l1(entry)
        return False
    @classmethod
    def add(cls, device, l1llll11ll, l1lllll11l, options=None, path=None):
        return cls(path=path).l1lll1l11l(l1lll1lll1.Entry(device,
                                                    l1llll11ll, l1lllll11l,
                                                    options=options))
class l1llll1l11(object):
    def __init__(self, l1lll11111):
        self.l1lllllll1=l1ll11l (u"ࠦ࠳ࡪࡡࡷࡨࡶ࠶ࠧখ")
        self.l1llll1l1l=l1ll11l (u"ࠧࡹࡥࡤࡴࡨࡸࡸࠨগ")
        self.l1lll11111=l1lll11111
        self.l1lll1llll()
        self.l1lll1l111()
        self.l1lll1ll11()
        self.l1lll11l11()
        self.l1lll1111l()
    def l1lll1llll(self):
        temp_file=open(l1llllll11,l1ll11l (u"࠭ࡲࠨঘ"))
        l1lll11l=temp_file.read()
        data=json.loads(l1lll11l)
        self.user=data[l1ll11l (u"ࠢࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦঙ")]
        self.l1l111l=data[l1ll11l (u"ࠣ࡯ࡲࡹࡳࡺࡐࡢࡶ࡫ࠦচ")]
        self.ll=data[l1ll11l (u"ࠤࡧ࡭ࡷࡖࡡࡵࡪࠥছ")]
        self.l1l1l1l=data[l1ll11l (u"ࠥ࡬ࡴࡳࡥࡠࡨࡲࡰࡩ࡫ࡲࠣজ")]
        self.l1lllll1l1=data[l1ll11l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡹࡸ࡫ࡲࡠ࡮ࡲ࡫࡮ࡴࠢঝ")]
        self.l1lll111ll=data[l1ll11l (u"ࠧࡳ࡯ࡶࡰࡷࡣࡺࡹࡥࡳࡡࡳࡥࡸࡹࠢঞ")]
    def l1lll1ll11(self):
        l1llll11=os.path.join(l1ll11l (u"ࠨ࠯ࠣট"),l1ll11l (u"ࠢࡶࡵࡵࠦঠ"),l1ll11l (u"ࠣࡵࡥ࡭ࡳࠨড"),l1ll11l (u"ࠤࡰࡳࡺࡴࡴ࠯ࡦࡤࡺ࡫ࡹࠢঢ"))
        os.system(l1ll11l (u"ࠥࡧ࡭ࡳ࡯ࡥࠢ࠷࠻࠺࠻ࠠࠦࡵࠥণ") %l1llll11)
    def l1lll1111l(self):
        logger.info(l1ll11l (u"ࠦࡸࡺࡡࡳࡶࠣࡧࡷ࡫ࡡࡵࡧࠣࡱࡴࡻ࡮ࡵࡨࡶ࠶ࠥࡹࡥࡤࡴࡨࡸࠥ࡬ࡩ࡭ࡧࠥত"))
        ll=os.path.join(self.l1l1l1l,self.l1lllllll1)
        l1llll1111 = pwd.getpwnam(self.user).pw_uid
        l1lll11lll = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(ll):
            os.makedirs(ll)
            os.system(l1ll11l (u"ࠧࡩࡨࡰࡹࡱࠤࠪࡹ࠺ࠦࡵࠣࠩࡸࠨথ") %(self.user,self.user, ll))
            logger.debug(l1ll11l (u"ࠨࡦࡰ࡮ࡧࡩࡷࠦࠥࡴࠢ࡬ࡷࠥࡩࡲࡦࡣࡷࡩࠧদ") %ll)
        else:
            logger.debug(l1ll11l (u"ࠢࡧࡱ࡯ࡨࡪࡸࠠࠦࡵࠣࡻࡦࡹࠠࡧࡱࡸࡲࡩࠨধ") %ll)
        l1llll11=os.path.join(ll, self.l1llll1l1l)
        print(l1llll11)
        logger.debug(l1ll11l (u"ࠣࡥࡵࡩࡦࡺࡥࠡࡨ࡬ࡰࡪࠦ࠭ࠡࠧࡶࠤࠧন")%l1llll11)
        with open(l1llll11, l1ll11l (u"ࠤࡺ࠯ࠧ঩")) as l1llll1lll:
            logger.debug(self.l1l111l + l1ll11l (u"ࠪࠤࠬপ")+self.l1lllll1l1+l1ll11l (u"ࠫࠥࠨࠧফ")+self.l1lll111ll+l1ll11l (u"ࠬࠨࠧব"))
            l1llll1lll.writelines(self.l1l111l + l1ll11l (u"࠭ࠠࠨভ")+self.l1lllll1l1+l1ll11l (u"ࠧࠡࠤࠪম")+self.l1lll111ll+l1ll11l (u"ࠨࠤࠪয"))
        os.chmod(l1llll11, 0o600)
        os.chown(l1llll11, l1llll1111, l1lll11lll)
    def l1lll1l111(self, l1llll11l1=l1ll11l (u"ࠩࡧࡥࡻ࡬ࡳ࠳ࠩর")):
        logger.debug(l1ll11l (u"࡚ࠥࡦࡲࡩࡥࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡹࡸ࡫ࡲࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠥ঱"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11l1 in groups:
            logger.info(l1ll11l (u"࡚ࠦࡹࡥࡳࠢࠨࡷࠥ࡯ࡳࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨল") %(self.user,l1llll11l1))
        else:
            logger.warning(l1ll11l (u"࡛ࠧࡳࡦࡴࠣࠩࡸࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡧࡳࡱࡸࡴࠥࠫࡳࠣ঳") %(self.user,l1llll11l1))
            l1ll1l11=l1ll11l (u"࠭ࡵࡴࡧࡵࡱࡴࡪࠠ࠮ࡣࠣ࠱ࡌࠦࠥࡴࠢࠨࡷࠬ঴") %(l1llll11l1,self.user)
            logger.debug(l1ll11l (u"ࠢࡤࡱࡰࡱࡦࡴࡤࠡࡨࡲࡶࠥࡧࡤࡥࠢࡸࡷࡪࡸࠠࠦࡵࠥ঵") %l1ll1l11)
            os.system(l1ll1l11)
            logger.debug(l1ll11l (u"ࠣࡣࡧࡨࡪࡪࠠࡴࡷࡦࡩࡸࡹࡦࡶ࡮࡯ࠦশ"))
    def l1lll11l11(self):
        logger.debug(l1ll11l (u"ࠤ࡙ࡥࡱ࡯ࡤࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨࠤ࠴࡫ࡴࡤ࠱ࡩࡷࡹࡧࡢࠡࡱࡱࠤ࡮ࡹࠠࡩࡣࡹࡩࠥࡳ࡯ࡶࡰࡷ࡭ࡳࠦࡲࡦࡵࡲࡹࡷࡩࡥࠡࠤষ"))
        l1llll1ll1=l1lll1lll1()
        l1llll1ll1.add(self.l1l111l, self.ll, l1lllll11l=l1ll11l (u"ࠥࡨࡦࡼࡦࡴࠤস"),options=l1ll11l (u"ࠦࡺࡹࡥࡳ࠮ࡵࡻ࠱ࡴ࡯ࡢࡷࡷࡳࠧহ") )
if __name__==l1ll11l (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢ঺"):
    try:
        l1llllll11 = urllib.parse.unquote(sys.argv[1])
        if l1llllll11:
            l1llllll1l=l1llll1l11(l1llllll11)
        else:
            raise (l1ll11l (u"ࠨࡥࡹࡧࡦࡹࡹ࡫ࠠࡵࡪ࡬ࡷࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡷࡵࡪࡴࡨࠤࡹ࡫࡭ࡱࠢࡩ࡭ࡱ࡫ࠠࡸ࡫ࡷ࡬ࠥࡶࡡࡳࡣࡰࡷࠥࡳ࡯ࡶࡰࡷ࡭ࡳ࡭ࠢ঻"))
    except Exception as e:
        logger.error(l1ll11l (u"ࠢࡆࡴࡵࡳࡷࡀ়ࠢ")+e)
        raise