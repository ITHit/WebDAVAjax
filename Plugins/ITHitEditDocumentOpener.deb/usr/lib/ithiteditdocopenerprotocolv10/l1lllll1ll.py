#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1ll1 = sys.version_info [0] == 2
l1ll11 = 2048
l1ll11l1 = 7
def l1l11l (l111ll):
    global l1l1l11
    l1ll1l = ord (l111ll [-1])
    l1l = l111ll [:-1]
    l1lllll = l1ll1l % len (l1l)
    l1111 = l1l [:l1lllll] + l1l [l1lllll:]
    if l1l1ll1:
        l11ll = l11111 () .join ([unichr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    else:
        l11ll = str () .join ([chr (ord (char) - l1ll11 - (l11lll + l1ll1l) % l1ll11l1) for l11lll, char in enumerate (l1111)])
    return eval (l11ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lll11ll1=logging.WARNING
logger = logging.getLogger(l1l11l (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1lll11ll1)
l1ll111l = SysLogHandler(address=l1l11l (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1l11l (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1ll111l.setFormatter(formatter)
logger.addHandler(l1ll111l)
ch = logging.StreamHandler()
ch.setLevel(l1lll11ll1)
logger.addHandler(ch)
class l1lll111l1(io.FileIO):
    l1l11l (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1l11l (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lllll1l1, l1llllll11,
                     options, d=0, p=0):
            self.device = device
            self.l1lllll1l1 = l1lllll1l1
            self.l1llllll11 = l1llllll11
            if not options:
                options = l1l11l (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1l11l (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lllll1l1,
                                              self.l1llllll11,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llllllll = os.path.join(os.path.sep, l1l11l (u"ࠨࡧࡷࡧࠬঅ"), l1l11l (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lll11lll = path
        else:
            self._1lll11lll = self.l1llllllll
        super(l1lll111l1, self).__init__(self._1lll11lll, l1l11l (u"ࠪࡶࡧ࠱ࠧই"))
    def _1lllll111(self, line):
        return l1lll111l1.Entry(*[x for x in line.strip(l1l11l (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1l11l (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1l11l (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1l11l (u"ࠢࠤࠤঋ")):
                    yield self._1lllll111(line)
            except ValueError:
                pass
    def l1llll11l1(self, attr, value):
        for entry in self.entries:
            l1lll1lll1 = getattr(entry, attr)
            if l1lll1lll1 == value:
                return entry
        return None
    def l1llll11ll(self, entry):
        if self.l1llll11l1(l1l11l (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1l11l (u"ࠩ࡟ࡲࠬ঍")).encode(l1l11l (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll1l111(self, entry):
        self.seek(0)
        lines = [l.decode(l1l11l (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1l11l (u"ࠧࠩࠢঐ")):
                if self._1lllll111(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1l11l (u"࠭ࠧ঑").join(lines).encode(l1l11l (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1llll111l(cls, l1lllll1l1, path=None):
        l1lll1l11l = cls(path=path)
        entry = l1lll1l11l.l1llll11l1(l1l11l (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lllll1l1)
        if entry:
            return l1lll1l11l.l1lll1l111(entry)
        return False
    @classmethod
    def add(cls, device, l1lllll1l1, l1llllll11, options=None, path=None):
        return cls(path=path).l1llll11ll(l1lll111l1.Entry(device,
                                                    l1lllll1l1, l1llllll11,
                                                    options=options))
class l1lll1llll(object):
    def __init__(self, l1llll1l11):
        self.l1lll11l1l=l1l11l (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1llll1lll=l1l11l (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1llll1l11=l1llll1l11
        self.l1llll1111()
        self.l1lll11l11()
        self.l1lllll11l()
        self.l1lll1l1ll()
        self.l11111111()
    def l1llll1111(self):
        temp_file=open(l1lll1ll11,l1l11l (u"ࠫࡷ࠭খ"))
        l11l1l1=temp_file.read()
        data=json.loads(l11l1l1)
        self.user=data[l1l11l (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1llll1l=data[l1l11l (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l1=data[l1l11l (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1111l=data[l1l11l (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll1ll1l=data[l1l11l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1llll1ll1=data[l1l11l (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1lllll11l(self):
        l1ll1l1=os.path.join(l1l11l (u"ࠦ࠴ࠨঝ"),l1l11l (u"ࠧࡻࡳࡳࠤঞ"),l1l11l (u"ࠨࡳࡣ࡫ࡱࠦট"),l1l11l (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1l11l (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1ll1l1)
    def l11111111(self):
        logger.info(l1l11l (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l1=os.path.join(self.l1111l,self.l1lll11l1l)
        l1llll1l1l = pwd.getpwnam(self.user).pw_uid
        l1lll1l1l1 = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l1):
            os.makedirs(l1)
            os.system(l1l11l (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l1))
            logger.debug(l1l11l (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l1)
        else:
            logger.debug(l1l11l (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l1)
        l1ll1l1=os.path.join(l1, self.l1llll1lll)
        print(l1ll1l1)
        logger.debug(l1l11l (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1ll1l1)
        with open(l1ll1l1, l1l11l (u"ࠢࡸ࠭ࠥধ")) as l1lll111ll:
            logger.debug(self.l1llll1l + l1l11l (u"ࠨࠢࠪন")+self.l1lll1ll1l+l1l11l (u"ࠩࠣࠦࠬ঩")+self.l1llll1ll1+l1l11l (u"ࠪࠦࠬপ"))
            l1lll111ll.writelines(self.l1llll1l + l1l11l (u"ࠫࠥ࠭ফ")+self.l1lll1ll1l+l1l11l (u"ࠬࠦࠢࠨব")+self.l1llll1ll1+l1l11l (u"࠭ࠢࠨভ"))
        os.chmod(l1ll1l1, 0o600)
        os.chown(l1ll1l1, l1llll1l1l, l1lll1l1l1)
    def l1lll11l11(self, l1llllll1l=l1l11l (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1l11l (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llllll1l in groups:
            logger.info(l1l11l (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llllll1l))
        else:
            logger.warning(l1l11l (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llllll1l))
            l1lll1l1=l1l11l (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llllll1l,self.user)
            logger.debug(l1l11l (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1lll1l1)
            os.system(l1lll1l1)
            logger.debug(l1l11l (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l1lll1l1ll(self):
        logger.debug(l1l11l (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lll1l11l=l1lll111l1()
        l1lll1l11l.add(self.l1llll1l, self.l1, l1llllll11=l1l11l (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1l11l (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1l11l (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1lll1ll11 = urllib.parse.unquote(sys.argv[1])
        if l1lll1ll11:
            l1lllllll1=l1lll1llll(l1lll1ll11)
        else:
            raise (l1l11l (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1l11l (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise