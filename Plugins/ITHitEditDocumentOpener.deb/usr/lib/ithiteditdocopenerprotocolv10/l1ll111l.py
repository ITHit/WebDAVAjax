#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111l1l = sys.version_info [0] == 2
l1l1l11 = 2048
l11l1l = 7
def l11 (l1ll11l1):
    global l1l1111
    l1lll = ord (l1ll11l1 [-1])
    l1llllll = l1ll11l1 [:-1]
    l1l11l = l1lll % len (l1llllll)
    l1111ll = l1llllll [:l1l11l] + l1llllll [l1l11l:]
    if l111l1l:
        l11l = l11l1l1 () .join ([unichr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    else:
        l11l = str () .join ([chr (ord (char) - l1l1l11 - (l11l11l + l1lll) % l11l1l) for l11l11l, char in enumerate (l1111ll)])
    return eval (l11l)
import hashlib
import os
import l11l1ll
from l1lll11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l11l1ll import l11111l
from l1l1ll1 import l11ll11, l1ll1ll
import logging
logger = logging.getLogger(l11 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11llll():
    def __init__(self, l111111,l1ll1l, l1llll11= None, l1ll1ll1=None):
        self.l111ll1=False
        self.l1l1l = self._1lllll()
        self.l1ll1l = l1ll1l
        self.l1llll11 = l1llll11
        self.l11ll1l = l111111
        if l1llll11:
            self.l1llll = True
        else:
            self.l1llll = False
        self.l1ll1ll1 = l1ll1ll1
    def _1lllll(self):
        try:
            return l11l1ll.l1l1lll() is not None
        except:
            return False
    def open(self):
        l11 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l1l:
            raise NotImplementedError(l11 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l11 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l11ll = self.l11ll1l
        if self.l1ll1l.lower().startswith(self.l11ll1l.lower()):
            l11l111 = re.compile(re.escape(self.l11ll1l), re.IGNORECASE)
            l1ll1l = l11l111.sub(l11 (u"ࠨࠩࠄ"), self.l1ll1l)
            l1ll1l = l1ll1l.replace(l11 (u"ࠩࡧࡥࡻ࠭ࠅ"), l11 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1l1l1(self.l11ll1l, l11ll, l1ll1l, self.l1llll11)
    def l1l1l1(self,l11ll1l, l11ll, l1ll1l, l1llll11):
        l11 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l11 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l11111 = l1ll(l11ll1l)
        l1111l1 = self.l11l1(l11111)
        logger.info(l11 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l11111)
        if l1111l1:
            logger.info(l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11111l(l11111)
            l11111 = l111(l11ll1l, l11ll, l1llll11, self.l1ll1ll1)
        logger.debug(l11 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll11l=l11111 + l11 (u"ࠤ࠲ࠦࠌ") + l1ll1l
        l1lll1 = l11 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll11l+ l11 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1lll1)
        l1ll1l1 = os.system(l1lll1)
        if (l1ll1l1 != 0):
            raise IOError(l11 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll11l, l1ll1l1))
    def l11l1(self, l11111):
        if os.path.exists(l11111):
            if os.path.islink(l11111):
                l11111 = os.readlink(l11111)
            if os.path.ismount(l11111):
                return True
        return False
def l1ll(l11ll1l):
    l1 = l11ll1l.replace(l11 (u"࠭࡜࡝ࠩࠐ"), l11 (u"ࠧࡠࠩࠑ")).replace(l11 (u"ࠨ࠱ࠪࠒ"), l11 (u"ࠩࡢࠫࠓ"))
    l1l1l1l = l11 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1lllll1=os.environ[l11 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1111=os.path.join(l1lllll1,l1l1l1l, l1)
    l1ll11=os.path.abspath(l1ll1111)
    return l1ll11
def l11lll1(l1llll1l):
    if not os.path.exists(l1llll1l):
        os.makedirs(l1llll1l)
def l1l11(l11ll1l, l11ll, l1111=None, password=None):
    l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1llll1l = l1ll(l11ll1l)
    l11lll1(l1llll1l)
    if not l1111:
        l1lll111 = l111lll()
        l1ll11ll =l1lll111.l1l(l11 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l11ll + l11 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l11ll + l11 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11ll, str):
            l1111, password = l1ll11ll
        else:
            raise l1ll1ll()
        logger.info(l11 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1llll1l))
    l1lll1ll = pwd.getpwuid( os.getuid())[0]
    l1l1ll=os.environ[l11 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l11ll=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll1={l11 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1lll1ll, l11 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll1l, l11 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1llll1l, l11 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1ll, l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1111, l11 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll1, temp_file)
        if not os.path.exists(os.path.join(l1l11ll, l11 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l1lll1l=l11 (u"ࠦࡵࡿࠢࠣ")
            key=l11 (u"ࠧࠨࠤ")
        else:
            l1lll1l=l11 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l11 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l111l=l11 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l1lll1l,temp_file.name)
        ll=[l11 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l11 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l11ll, l111l)]
        p = subprocess.Popen(ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l11 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l11 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l11 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1llll1l
    logger.debug(l11 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l11 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll11=os.path.abspath(l1llll1l)
    logger.debug(l11 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll11)
    return l1ll11
def l111(l11ll1l, l11ll, l1llll11, l1ll1ll1):
    l11 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1llll1(title):
        l111ll=30
        if len(title)>l111ll:
            l1l111l=title.split(l11 (u"ࠨ࠯ࠣ࠳"))
            l1l11l1=l11 (u"ࠧࠨ࠴")
            for block in l1l111l:
                l1l11l1+=block+l11 (u"ࠣ࠱ࠥ࠵")
                if len(l1l11l1) > l111ll:
                    l1l11l1+=l11 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1l11l1
        return title
    def l1ll1l11(l1ll1lll, password):
        l11 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l11 (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l11 (u"ࠧࠦࠢ࠹").join(l1ll1lll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l11 = l11 (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l11.encode())
        l1ll11l = [l11 (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll1l1 = l11 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll1l1)
            for e in l1ll11l:
                if e in l1lll1l1: return False
            raise l11ll11(l1lll1l1, l111=l11l1ll.l1l1lll(), l11ll=l11ll)
        logger.info(l11 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1111 = l11 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l11 (u"ࠦࠧ࠿")
    os.system(l11 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l111 = l1ll(l11ll1l)
    l1llll1l = l1ll(hashlib.sha1(l11ll1l.encode()).hexdigest()[:10])
    l11lll1(l1llll1l)
    logger.info(l11 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1llll1l))
    if l1llll11:
        l1ll1lll = [l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l11 (u"ࠤ࠰ࡸࠧࡄ"), l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l11 (u"ࠫ࠲ࡵࠧࡆ"), l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1111, l1llll11),
                    urllib.parse.unquote(l11ll), os.path.abspath(l1llll1l)]
        l1ll1l11(l1ll1lll, password)
    else:
        while True:
            l1111, password = l1l1(l1llll1l, l11ll, l1ll1ll1)
            if l1111.lower() != l11 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1ll1lll = [l11 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l11 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l11 (u"ࠤ࠰ࡸࠧࡋ"), l11 (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l11 (u"ࠫ࠲ࡵࠧࡍ"), l11 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1111,
                            urllib.parse.unquote(l11ll), os.path.abspath(l1llll1l)]
            else:
                raise l1ll1ll()
            if l1ll1l11(l1ll1lll, password): break
    os.system(l11 (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1llll1l, l1l111))
    l1ll11=os.path.abspath(l1l111)
    return l1ll11
def l1l1(l11ll1l, l11ll, l1ll1ll1):
    l11ll1 = os.path.join(os.environ[l11 (u"ࠢࡉࡑࡐࡉࠧࡐ")], l11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l11ll1)):
       os.makedirs(os.path.dirname(l11ll1))
    l1ll111 = l1ll1ll1.get_value(l11 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l11 (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1lll111 = l111lll(l11ll1l, l1ll111)
    l1111, password = l1lll111.l1l(l11 (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l11ll + l11 (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l11ll + l11 (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1111 != l11 (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1ll1l1l(l11ll1l, l1111):
        l111l1 = l11 (u"ࠤ࡙ࠣࠦ").join([l11ll1l, l1111, l11 (u"࡚ࠪࠦࠬ") + password + l11 (u"࡛ࠫࠧ࠭"), l11 (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l11ll1, l11 (u"࠭ࡷࠬࠩ࡝")) as l1111l:
            l1111l.write(l111l1)
        os.chmod(l11ll1, 0o600)
    return l1111, password
def l1ll1l1l(l11ll1l, l1111):
    l11ll1 = l11lll = os.path.join(os.environ[l11 (u"ࠢࡉࡑࡐࡉࠧ࡞")], l11 (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l11 (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l11ll1):
        with open(l11ll1, l11 (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l111l11 = data[0].split(l11 (u"ࠦࠥࠨࡢ"))
            if l11ll1l == l111l11[0] and l1111 == l111l11[1]:
                return True
    return False