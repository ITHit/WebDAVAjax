#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll = sys.version_info [0] == 2
l1lll11 = 2048
l1lll11l = 7
def l111lll (l1lll1ll):
    global l1ll11l1
    l11l1l = ord (l1lll1ll [-1])
    l1ll1ll1 = l1lll1ll [:-1]
    l1l1lll = l11l1l % len (l1ll1ll1)
    l11lll = l1ll1ll1 [:l1l1lll] + l1ll1ll1 [l1l1lll:]
    if l1llll:
        l1ll11 = l1lllll1 () .join ([unichr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    else:
        l1ll11 = str () .join ([chr (ord (char) - l1lll11 - (l111ll1 + l11l1l) % l1lll11l) for l111ll1, char in enumerate (l11lll)])
    return eval (l1ll11)
import hashlib
import os
import l1lll111
from l1l11l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll111 import l11llll
from l1l1l11 import l1lllll, l1ll11ll
import logging
logger = logging.getLogger(l111lll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1l1():
    def __init__(self, l111l,l1l11ll, l111l1l= None, l1l=None):
        self.l11l11=False
        self.l1 = self._11ll()
        self.l1l11ll = l1l11ll
        self.l111l1l = l111l1l
        self.l1ll1l11 = l111l
        if l111l1l:
            self.l1111ll = True
        else:
            self.l1111ll = False
        self.l1l = l1l
    def _11ll(self):
        try:
            return l1lll111.l1ll() is not None
        except:
            return False
    def open(self):
        l111lll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1:
            raise NotImplementedError(l111lll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111lll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l111l = self.l1ll1l11
        if self.l1l11ll.lower().startswith(self.l1ll1l11.lower()):
            l1lll1l1 = re.compile(re.escape(self.l1ll1l11), re.IGNORECASE)
            l1l11ll = l1lll1l1.sub(l111lll (u"ࠨࠩࠄ"), self.l1l11ll)
            l1l11ll = l1l11ll.replace(l111lll (u"ࠩࡧࡥࡻ࠭ࠅ"), l111lll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11l1(self.l1ll1l11, l1l111l, l1l11ll, self.l111l1l)
    def l11l1(self,l1ll1l11, l1l111l, l1l11ll, l111l1l):
        l111lll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111lll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1111l = l11lll1(l1ll1l11)
        l111111 = self.ll(l1111l)
        logger.info(l111lll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1111l)
        if l111111:
            logger.info(l111lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11llll(l1111l)
            l1111l = l1ll11l(l1ll1l11, l1l111l, l111l1l, self.l1l)
        logger.debug(l111lll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1l1l=l1111l + l111lll (u"ࠤ࠲ࠦࠌ") + l1l11ll
        l11l = l111lll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1l1l+ l111lll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11l)
        l1llllll = os.system(l11l)
        if (l1llllll != 0):
            raise IOError(l111lll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1l1l, l1llllll))
    def ll(self, l1111l):
        if os.path.exists(l1111l):
            if os.path.islink(l1111l):
                l1111l = os.readlink(l1111l)
            if os.path.ismount(l1111l):
                return True
        return False
def l11lll1(l1ll1l11):
    l11l11l = l1ll1l11.replace(l111lll (u"࠭࡜࡝ࠩࠐ"), l111lll (u"ࠧࡠࠩࠑ")).replace(l111lll (u"ࠨ࠱ࠪࠒ"), l111lll (u"ࠩࡢࠫࠓ"))
    l11ll1l = l111lll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1111=os.environ[l111lll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1l1l1l=os.path.join(l1111,l11ll1l, l11l11l)
    l1ll111=os.path.abspath(l1l1l1l)
    return l1ll111
def l1llll1l(l1lll1):
    if not os.path.exists(l1lll1):
        os.makedirs(l1lll1)
def l1ll1lll(l1ll1l11, l1l111l, l1l11=None, password=None):
    l111lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1lll1 = l11lll1(l1ll1l11)
    l1llll1l(l1lll1)
    if not l1l11:
        l1ll1l = l11111()
        l11ll11 =l1ll1l.l111ll(l111lll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l111l + l111lll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l111l + l111lll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l11ll11, str):
            l1l11, password = l11ll11
        else:
            raise l1ll11ll()
        logger.info(l111lll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1lll1))
    l1l11l1 = pwd.getpwuid( os.getuid())[0]
    l1l1111=os.environ[l111lll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l11l1l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l111l1={l111lll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1l11l1, l111lll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1ll1l11, l111lll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1lll1, l111lll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1l1111, l111lll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1l11, l111lll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l111l1, temp_file)
        if not os.path.exists(os.path.join(l11l1l1, l111lll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11ll1=l111lll (u"ࠦࡵࡿࠢࠣ")
            key=l111lll (u"ࠧࠨࠤ")
        else:
            l11ll1=l111lll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111lll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1ll1=l111lll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11ll1,temp_file.name)
        l111=[l111lll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111lll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l11l1l1, l1ll1)]
        p = subprocess.Popen(l111, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111lll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111lll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111lll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1lll1
    logger.debug(l111lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111lll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll111=os.path.abspath(l1lll1)
    logger.debug(l111lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll111)
    return l1ll111
def l1ll11l(l1ll1l11, l1l111l, l111l1l, l1l):
    l111lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l111(title):
        l1l1ll1=30
        if len(title)>l1l1ll1:
            l11=title.split(l111lll (u"ࠨ࠯ࠣ࠳"))
            l1lll1l=l111lll (u"ࠧࠨ࠴")
            for block in l11:
                l1lll1l+=block+l111lll (u"ࠣ࠱ࠥ࠵")
                if len(l1lll1l) > l1l1ll1:
                    l1lll1l+=l111lll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll1l
        return title
    def l1l1l1(l1111l1, password):
        l111lll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111lll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111lll (u"ࠧࠦࠢ࠹").join(l1111l1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1llll11 = l111lll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1llll11.encode())
        l1l1l = [l111lll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11111l = l111lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11111l)
            for e in l1l1l:
                if e in l11111l: return False
            raise l1lllll(l11111l, l1ll11l=l1lll111.l1ll(), l1l111l=l1l111l)
        logger.info(l111lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1l11 = l111lll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111lll (u"ࠦࠧ࠿")
    os.system(l111lll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l11l1ll = l11lll1(l1ll1l11)
    l1lll1 = l11lll1(hashlib.sha1(l1ll1l11.encode()).hexdigest()[:10])
    l1llll1l(l1lll1)
    logger.info(l111lll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1lll1))
    if l111l1l:
        l1111l1 = [l111lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111lll (u"ࠤ࠰ࡸࠧࡄ"), l111lll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111lll (u"ࠫ࠲ࡵࠧࡆ"), l111lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1l11, l111l1l),
                    urllib.parse.unquote(l1l111l), os.path.abspath(l1lll1)]
        l1l1l1(l1111l1, password)
    else:
        while True:
            l1l11, password = l1llll1(l1lll1, l1l111l, l1l)
            if l1l11.lower() != l111lll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l1111l1 = [l111lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111lll (u"ࠤ࠰ࡸࠧࡋ"), l111lll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111lll (u"ࠫ࠲ࡵࠧࡍ"), l111lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1l11,
                            urllib.parse.unquote(l1l111l), os.path.abspath(l1lll1)]
            else:
                raise l1ll11ll()
            if l1l1l1(l1111l1, password): break
    os.system(l111lll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1lll1, l11l1ll))
    l1ll111=os.path.abspath(l11l1ll)
    return l1ll111
def l1llll1(l1ll1l11, l1l111l, l1l):
    l1l111 = os.path.join(os.environ[l111lll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1l111)):
       os.makedirs(os.path.dirname(l1l111))
    l111l11 = l1l.get_value(l111lll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111lll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1ll1l = l11111(l1ll1l11, l111l11)
    l1l11, password = l1ll1l.l111ll(l111lll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l111l + l111lll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l111l + l111lll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1l11 != l111lll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1lll(l1ll1l11, l1l11):
        l1l1ll = l111lll (u"ࠤ࡙ࠣࠦ").join([l1ll1l11, l1l11, l111lll (u"࡚ࠪࠦࠬ") + password + l111lll (u"࡛ࠫࠧ࠭"), l111lll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1l111, l111lll (u"࠭ࡷࠬࠩ࡝")) as l1ll1l1:
            l1ll1l1.write(l1l1ll)
        os.chmod(l1l111, 0o600)
    return l1l11, password
def l1lll(l1ll1l11, l1l11):
    l1l111 = l1ll1ll = os.path.join(os.environ[l111lll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1l111):
        with open(l1l111, l111lll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1ll1111 = data[0].split(l111lll (u"ࠦࠥࠨࡢ"))
            if l1ll1l11 == l1ll1111[0] and l1l11 == l1ll1111[1]:
                return True
    return False