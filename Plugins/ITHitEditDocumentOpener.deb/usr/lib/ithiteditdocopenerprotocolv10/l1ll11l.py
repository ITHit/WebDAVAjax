#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l111ll1 = sys.version_info [0] == 2
l1lll111 = 2048
l1111 = 7
def l1ll (l11lll):
    global l1l1l1
    l1ll1l1 = ord (l11lll [-1])
    l1l1lll = l11lll [:-1]
    l1ll11l1 = l1ll1l1 % len (l1l1lll)
    l111 = l1l1lll [:l1ll11l1] + l1l1lll [l1ll11l1:]
    if l111ll1:
        l11llll = l1ll1l11 () .join ([unichr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    else:
        l11llll = str () .join ([chr (ord (char) - l1lll111 - (l1l111 + l1ll1l1) % l1111) for l1l111, char in enumerate (l111)])
    return eval (l11llll)
import gi
gi.require_version(l1ll (u"ࠨࡉࡷ࡯ࠬঽ"), l1ll (u"ࠩ࠶࠲࠵࠭া"))
from gi.repository import Gtk, Pango, Gdk
import re, subprocess
import keyring
import l11lll11
import logging
logger = logging.getLogger(l1ll (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶ࠳࡭ࡵࡪࠤি"))
class l1ll1lll(Gtk.Window):
    def __init__(self, l1ll1l1111, l1l1l11l11):
        Gtk.Window.__init__(self)
        self.l11=30
        self.l1ll1l1l1l = False
        self.service = l1ll1l1111
        self.l1l1ll=l1l1l11l11
        self.l11l11l=l11lll11.l1l11lll
        self.l1ll1ll111 = Gtk.ListStore(str)
        self.l1ll111lll()
    def l1ll1l11l1(self, service):
        l1l1lll1ll = self.l11l11l.l11ll111(l1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦী"), service)
        return l1l1lll1ll
    def l1ll111lll(self, l1ll1l1111=None):
        if l1ll1l1111:
            self.l1ll1ll111.clear()
            l1ll111l11=self.l1ll1l11l1(l1ll1l1111)
            self.l1ll1ll111.append([l1ll (u"ࠧࠨু")])
            for l1l1ll in l1ll111l11:
                self.l1ll1ll111.append([l1l1ll])
        else:
            self.l1ll1ll111.clear()
            self.l1ll1ll111.append([l1ll (u"ࠨ࡮ࡰ࡮ࡲ࡫࡮ࡴࠢূ")])
    def l1l1llll11(self, widget, data=None):
        l1ll1lll11= widget.get_active()
        if data == l1ll (u"ࠢ࠲ࠤৃ") and l1ll1lll11:
            self.l1ll111lll()
            self.l1l11lllll.set_active(0)
            self.l1l1l111l1.set_text(l1ll (u"ࠣࡰࡲࡴࡦࡹࡳࠣৄ"))
            self.l1l1l111l1.set_sensitive(False)
            self.l1l11lllll.set_sensitive(False)
        else:
            self.l1ll111lll(l1ll1l1111=self.service)
            self.l1l11lllll.set_active(0)
            self.l1l1l111l1.set_text(l1ll (u"ࠤࠥ৅"))
            self.l1l11lllll.set_sensitive(True)
            self.l1l1l111l1.set_sensitive(True)
    def l1l1l1l11l(self, widget):
        if widget.get_active():
            l1l1ll = widget.get_child().get_text()
        else:
            l1l1ll = self.l1ll1ll111[widget.get_active()][0]
        password = self.l1l1l1l1l1(self.service, l1l1ll)
        if password:
            self.l1l1l111l1.set_text(password)
        else:
            self.l1l1l111l1.set_text(l1ll (u"ࠥࠦ৆"))
    def l1l1lll111(self, l1l1ll, pwd, service):
        keyring.set_password(service, l1l1ll, pwd)
        l1l1lll1ll=self.l11l11l.l11ll111(l1ll (u"ࠦࡑࡵࡧࡪࡰࡶࠦে"), service)
        if not l1l1ll in l1l1lll1ll:
            value = self.l11l11l.get_value(l1ll (u"ࠧࡒ࡯ࡨ࡫ࡱࡷࠧৈ"), service)
            self.l11l11l.l11l1lll(l1ll (u"ࠨࡌࡰࡩ࡬ࡲࡸࠨ৉"), service,l1ll (u"ࠢࠦࡵࡿࠤࠪࡹࠠࡽࠤ৊")%(value, l1l1ll))
    def l1l1l1l1l1(self, service, l1l1ll):
        l1ll1lllll = keyring.get_password(service, l1l1ll)
        return l1ll1lllll
    def l1l1l11l1l(self, window, *args):
        args[0].response(Gtk.ResponseType.OK)
    def l1l1lll11l(self, widget, data=None):
        self.l1ll1l1l1l=widget.get_active()
    def l11l1ll(self, message, title=l1ll (u"ࠨࠩো"), l1ll111ll=True):
        if l1ll111ll:
            l1l1ll11ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        l1l1ll1l11 = Gtk.MessageDialog(self,
            l1l1ll11ll,
            Gtk.MessageType.INFO,
            Gtk.ButtonsType.OK_CANCEL,
            message)
        l1l1ll1l11.set_title(title)
        l1l1ll1l11.set_default_response(Gtk.ResponseType.OK)
        l1l1l111ll = Gtk.HBox()
        vbox = Gtk.VBox()
        l1l1l1111l = Gtk.VBox()
        l1ll11ll11 = Gtk.Box(spacing=1)
        l1ll11ll11.set_homogeneous(False)
        l1l1lllll1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1l1lllll1.set_homogeneous(False)
        l1ll1ll1l1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        l1ll1ll1l1.set_homogeneous(False)
        l1ll11ll11.pack_start(l1l1lllll1, True, True, 0)
        l1ll11ll11.pack_start(l1ll1ll1l1, True, True, 0)
        l1l11l11ll = l1l1ll1l11.get_content_area()
        l1l1ll111l = Gtk.Box(spacing=1, orientation=Gtk.Orientation.VERTICAL)
        l1l11l11ll.pack_start(l1l1ll111l, True, True, 0)
        table = Gtk.Table(14, 3, False)
        l1ll111ll1 = Gtk.Label()
        l1l1llll1l = Gtk.Label()
        l1l1llll1l.set_text(l1ll (u"ࠤࠣࠦৌ")*5)
        vbox.pack_start(l1l1llll1l, True, True, 0)
        l1ll111ll1.set_text(l1ll (u"ࠥࡇࡴࡴ࡮ࡦࡥࡷࠤࡆࡹ࠺ࠡࠤ্"))
        l1ll111ll1.set_alignment(xalign=1, yalign=0.5)
        table.attach(l1ll111ll1, 0, 1, 0, 1)
        l1l11ll1ll = Gtk.RadioButton.new_with_label_from_widget(None, l1ll (u"ࠦࡌࡻࡥࡴࡶࠥৎ"))
        l1l11ll1ll.connect(l1ll (u"ࠧࡺ࡯ࡨࡩ࡯ࡩࡩࠨ৏"), self.l1l1llll11, l1ll (u"ࠨ࠱ࠣ৐"))
        table.attach(l1l11ll1ll, 1, 2, 0, 1)
        l1ll111l1l = Gtk.RadioButton.new_with_label_from_widget(l1l11ll1ll, l1ll (u"ࠢࡓࡧࡪ࡭ࡸࡺࡥࡳࡧࡧࠤ࡚ࡹࡥࡳࠤ৑"))
        l1ll111l1l.connect(l1ll (u"ࠣࡶࡲ࡫࡬ࡲࡥࡥࠤ৒"), self.l1l1llll11, l1ll (u"ࠤ࠵ࠦ৓"))
        table.attach(l1ll111l1l, 1, 2, 1, 2)
        l1l11llll1 = Gtk.Label()
        l1l11llll1.set_text(l1ll (u"ࠥࠤࠧ৔"))
        table.attach(l1l11llll1, 0, 1, 4, 6)
        l1ll11111l = Gtk.Label()
        l1ll11111l.set_text(l1ll (u"ࠦࡑࡵࡧࡪࡰ࠽ࠤࠧ৕"))
        l1ll11111l.set_justify(Gtk.Justification.RIGHT)
        l1ll11111l.set_alignment(xalign=1, yalign=0.5)
        self.l1l11lllll = Gtk.ComboBox.new_with_model_and_entry(self.l1ll1ll111)
        self.l1l11lllll.set_entry_text_column(0)
        table.attach(l1ll11111l, 0, 1, 6, 8)
        table.attach(self.l1l11lllll, 1, 3, 6, 8)
        self.l1l11lllll.connect(l1ll (u"ࠧࡩࡨࡢࡰࡪࡩࡩࠨ৖"), self.l1l1l1l11l)
        l1l1l1lll1 = Gtk.Label()
        l1l1l1lll1.set_text(l1ll (u"ࠨࡐࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࠥৗ"))
        l1l1l1lll1.set_justify(Gtk.Justification.RIGHT)
        l1l1l1lll1.set_alignment(xalign=1, yalign=0.5)
        self.l1l1l111l1 = Gtk.Entry()
        self.l1l1l111l1.set_visibility(False)
        self.l1l1l111l1.connect(l1ll (u"ࠢࡢࡥࡷ࡭ࡻࡧࡴࡦࠤ৘"), self.l1l1l11l1l, l1l1ll1l11)
        table.attach(l1l1l1lll1, 0, 1, 8, 10)
        table.attach(self.l1l1l111l1, 1, 3, 8, 10)
        l1l1l1l1ll = Gtk.CheckButton(l1ll (u"ࠣࡕࡤࡺࡪࠦ࡬ࡰࡩ࡬ࡲࠥࡧ࡮ࡥࠢࡳࡥࡸࡹࡷࡰࡴࡧࠦ৙"))
        l1l1l1l1ll.connect(l1ll (u"ࠤࡷࡳ࡬࡭࡬ࡦࡦࠥ৚"), self.l1l1lll11l, l1l1l1l1ll)
        l1l1l1l1ll.set_active(False)
        table.attach(l1l1l1l1ll, 1, 3, 12, 14)
        l1l1l1ll1l = Gtk.Label()
        l1l1l1ll1l.set_text(l1ll (u"ࠥࠤࠧ৛") * 5)
        l1l1l1111l.pack_start(l1l1l1ll1l, True, True, 0)
        if self.l1l1ll:
            l1ll111l1l.set_active(True)
            self.l1l11lllll.set_active(0)
            self.l1l11lllll.set_sensitive(True)
            self.l1l1l111l1.set_text(l1ll (u"ࠦࠧড়"))
            self.l1l1l111l1.set_sensitive(True)
        else:
            self.l1l11lllll.set_active(0)
            self.l1l11lllll.set_sensitive(False)
            self.l1l1l111l1.set_text(l1ll (u"ࠧࡴ࡯ࡱࡣࡶࡷࠧঢ়"))
            self.l1l1l111l1.set_sensitive(False)
        l1l1l111ll.pack_start(vbox, True, True, 0)
        l1l1l111ll.pack_start(table, True, True, 0)
        l1l1l111ll.pack_end(l1l1l1111l, True, True, 0)
        l1l1ll111l.pack_start(l1l1l111ll, True, True, 0)
        l1l1ll1l11.show_all()
        response = l1l1ll1l11.run()
        if self.l1l11lllll.get_active():
            l1l1ll = self.l1l11lllll.get_child().get_text()
        else:
            l1l1ll = self.l1ll1ll111[self.l1l11lllll.get_active()][0]
        pwd = self.l1l1l111l1.get_text()
        l1l1ll1l11.destroy()
        if response == Gtk.ResponseType.OK:
            if self.l1ll1l1l1l:
                self.l1l1lll111(l1l1ll, pwd, self.service)
            return l1l1ll, pwd
        else:
            return l1ll (u"ࠨࡃࡢࡰࡦࡩࡱࠨ৞"), l1ll (u"ࠧࠨয়")
class l1l1l1ll1(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
    def __1l1lll1l1(self, l11ll11l):
        l1ll1111ll = Gtk.ScrolledWindow()
        l1ll1111ll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.l1l1ll1l1l=None
        self.l1ll11l1ll = Gtk.TextBuffer()
        self.l1ll11l1ll.set_text(l11ll11l)
        self.set_style()
        regexp= l1ll (u"ࡳࠤࠫ࡬ࡹࡺࡰ࠻࠰࠮ࡃ࠮ࡢࡳࡽࠪ࡫ࡸࡹࡶࡳ࠻࠰࠮ࡃ࠮ࡢࡳࠣৠ")
        l1ll1l1lll = self._1l11ll11l(l11ll11l, regexp)
        self.l1ll11ll1l(l1ll1l1lll, self.l1ll11l1ll.get_start_iter())
        self.l1l1l11111 = Gtk.TextView(buffer=self.l1ll11l1ll)
        self.l1l1l11111.set_property(l1ll (u"ࠩࡨࡨ࡮ࡺࡡࡣ࡮ࡨࠫৡ"), False)
        self.l1l1l11111.add_events(Gdk.EventType.LEAVE_NOTIFY|Gdk.EventType.ENTER_NOTIFY|Gdk.EventType.MOTION_NOTIFY)
        self.l1l1l11111.connect(l1ll (u"ࠥࡱࡴࡺࡩࡰࡰࡢࡲࡴࡺࡩࡧࡻࡢࡩࡻ࡫࡮ࡵࠤৢ"), self._1l1ll1ll1)
        self.l1l1l11111.set_wrap_mode(Gtk.WrapMode.WORD)
        l1ll1111ll.set_size_request(300,100)
        self.l1l1l11111.show()
        l1ll1111ll.add(self.l1l1l11111)
        l1ll1111ll.show()
        return l1ll1111ll
    def _1l1ll1ll1(self, *args, **kwargs):
        l1l1l11lll, l1ll1llll1=args[0].get_pointer()
        tag = args[0].get_iter_at_location(l1l1l11lll, l1ll1llll1).get_tags()
        if not self.l1l1ll1l1l:
            self.l1l1ll1l1l = args[1].window.get_cursor()
            self.l1l11l1l1l = Gdk.Cursor(Gdk.CursorType.l1ll1l111l)
        elif tag:
            args[1].window.set_cursor(self.l1l11l1l1l)
        elif not tag:
            if args[1].window.get_cursor() != self.l1l1ll1l1l:
                args[1].window.set_cursor(self.l1l1ll1l1l)
    def _1l11ll11l(self, l11ll11l, l1ll11l1l1):
        res=[]
        l1l1ll1lll=re.findall(l1ll11l1l1,l11ll11l)
        for l1l1llllll in l1l1ll1lll:
            for el in l1l1llllll:
                if el:
                    res.append(el)
        return res
    def l1ll11ll1l(self, l1ll1l1lll, start):
        l1l1ll11l1=0
        for text in l1ll1l1lll:
            end = self.l1ll11l1ll.get_end_iter()
            match = start.forward_search(text, 0, end)
            if match != None:
                l1l1ll11l1+=1
                l1ll1l11ll, l1ll11lll1 = match
                tag = self.l1ll11l1ll.create_tag(str(l1l1ll11l1), foreground=l1ll (u"ࠦࠨ࠶࠰࠱࠲ࡉࡊࠧৣ"), underline=Pango.Underline.SINGLE)
                tag.connect(l1ll (u"ࠬ࡫ࡶࡦࡰࡷࠫ৤"), self._1ll111111, text)
                self.l1ll11l1ll.apply_tag(tag, l1ll1l11ll, l1ll11lll1)
                self.l1ll11ll1l(l1ll1l1lll, l1ll11lll1)
    def _1ll111111(self, tag, widget, l1l11ll111, _1l11ll1l1, text):
        _1l1l11ll1 = l1l11ll111.type
        _1ll1ll1ll = l1l11ll111.window
        if _1l1l11ll1 == Gdk.EventType.MOTION_NOTIFY:
            pass
        elif _1l1l11ll1 in [Gdk.EventType.BUTTON_PRESS, Gdk.EventType.BUTTON_RELEASE]:
            button = l1l11ll111.button
            self.l1l1ll1l1l = Gdk.Cursor(Gdk.CursorType.l1ll1l111l)
            if _1l1l11ll1 == Gdk.EventType.BUTTON_PRESS:
                subprocess.Popen([l1ll (u"࠭ࡸࡥࡩ࠰ࡳࡵ࡫࡮ࠨ৥"), text])
    def l1l1ll1ll(self, message, title=l1ll (u"ࠧࠨ০"), l1ll111ll=True, l1ll11l11l=None):
        if l1ll111ll:
            l1l1ll11ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
            l1l1ll11ll,
            Gtk.MessageType.ERROR,
            Gtk.ButtonsType.OK,
            message)
        window.set_title(title)
        window.set_size_request(600,100 )
        window.set_default_response(Gtk.ResponseType.OK)
        if l1ll11l11l:
            l1l11l11ll = window.get_content_area()
            vbox = Gtk.VBox(spacing=3)
            l1ll11ll11 = Gtk.HBox(spacing=0)
            l1l11l1ll1 = Gtk.HBox(spacing=5)
            l1l1l1l111 = Gtk.Label()
            l1l1l1l111.set_markup(l1ll (u"ࠣࡇ࡛ࡘࡊࡔࡄࠡࡋࡑࡊࡔࠨ১"))
            l1l1l1l111.set_line_wrap(True)
            l1l1l1l111.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse(l1ll (u"ࠤࠦࡈ࠸ࡊ࠳ࡅ࠵ࠥ২")))
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.show()
            l1l1l1ll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l1l1ll11.show()
            l1ll1l1l11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1l1l11.show()
            l1ll11l111 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll11l111.show()
            l1ll11ll11.pack_start(separator, True, True, 0)
            l1ll11ll11.pack_start(l1l1l1ll11, True, True, 0)
            l1ll11ll11.pack_start(l1ll1l1l11, True, True, 0)
            l1ll11ll11.pack_start(l1ll11l111, True, True, 0)
            l1ll11ll11.pack_start(l1l1l1l111, False, True, 0)
            l1ll1lll1l = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1ll1lll1l.show()
            l1ll11ll11.pack_end(l1ll1lll1l, True, True, 0)
            l1l11lll11 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            l1l11lll11.show()
            vbox.pack_start(l1ll11ll11, True, True, 0)
            l1ll1111ll=self.__1l1lll1l1(l11ll11l=l1ll11l11l)
            vbox.pack_start(l1ll1111ll, False, False, 0)
            vbox.pack_end(l1l11lll11, False, False, 0)
            l1l11l1ll1.pack_start(vbox, True, True,5)
            l1l11l1ll1.show()
            l1l11l11ll.pack_end(l1l11l1ll1, False, False, 0)
            vbox.show()
            l1ll11ll11.show()
        window.run()
class l1l11l11l(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self)
        self.result=None
    def l1l11lll1l(self, widget, l1l1ll1111):
        if l1l1ll1111 == Gtk.ResponseType.OK:
            self.result = l1ll (u"ࠥࡓࡐࠨ৩")
        elif l1l1ll1111 == Gtk.ResponseType.CANCEL:
            self.result = l1ll (u"ࠦࡈࡇࡎࡄࡇࡏࠦ৪")
        elif l1l1ll1111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = l1ll (u"ࠧࡉࡁࡏࡅࡈࡐࠧ৫")
        widget.destroy()
    def l11l1llll(self, title=l1ll (u"ࠨࠢ৬"), message=l1ll (u"ࠢࠣ৭") , l1ll111ll=True):
        if l1ll111ll:
            l1l1ll11ll = Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll11ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL ,
                                   message)
        window.set_title(title)
        window.connect(l1ll (u"ࠣࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ৮"), self.l1l11lll1l)
        window.run()
class l1l11l1lll(Gtk.Window):
    def __init__(self, *args, **kwargs):
        Gtk.Window.__init__(self)
        self.l1ll1ll11l=None
        self.result = None
    def l1l11lll1l(self, widget, l1l1ll1111):
        print(widget, l1l1ll1111)
        if l1l1ll1111 == Gtk.ResponseType.OK:
            self.result = True
        elif l1l1ll1111 == Gtk.ResponseType.CANCEL:
            self.result = False
        elif l1l1ll1111 == Gtk.ResponseType.DELETE_EVENT:
            self.result = False
        widget.destroy()
    def l1l1lll11l(self, widget, l1l1l1llll):
        if l1l1l1llll.get_active():
            self.l1ll1ll11l = 1
        else:
            self.l1ll1ll11l = 0
    def l1ll1l1ll1(self, title=l1ll (u"ࠤࠥ৯"), message=l1ll (u"ࠥࠦৰ"), l1ll1111l1 =l1ll (u"ࠦࠧৱ"),l1ll111ll=True):
        if l1ll111ll:
            l1l1ll11ll= Gtk.DialogFlags.MODAL | Gtk.DialogFlags.DESTROY_WITH_PARENT
        else:
            l1l1ll11ll = Gtk.DialogFlags.DESTROY_WITH_PARENT
        window = Gtk.MessageDialog(self,
                                   l1l1ll11ll,
                                   Gtk.MessageType.WARNING,
                                   Gtk.ButtonsType.OK_CANCEL,
                                   message)
        window.set_title(title)
        window.connect(l1ll (u"ࠧࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ৲"), self.l1l11lll1l)
        l1l1l1l1ll = Gtk.CheckButton(l1ll1111l1)
        l1l1l1l1ll.connect(l1ll (u"ࠨࡴࡰࡩࡪࡰࡪࡪࠢ৳"), self.l1l1lll11l, l1l1l1l1ll)
        l1l1l1l1ll.set_active(False)
        dd=window.get_message_area()
        dd.pack_end(child=l1l1l1l1ll, expand=True, fill=True, padding=0)
        l1l1l1l1ll.show()
        window.run()
def l111l1l11(title, msg, l1ll1111l1=l1ll (u"ࠢࡅࡱࠣࡲࡴࡺࠠࡴࡪࡲࡻࠥࡺࡨࡪࡵࠣࡱࡪࡹࡳࡢࡩࡨࠤࡦ࡭ࡡࡪࡰࠥ৴"),l1ll111ll=True):
    result=None
    try:
        l1l11l1l11 = l1l11l1lll()
        l1l11l1l11.l1ll1l1ll1(title, msg, l1ll1111l1, l1ll111ll)
        result = {l1ll (u"ࠣࡄࡸࡸࡹࡵ࡮ࠣ৵"):l1l11l1l11.result,  l1ll (u"ࠤࡇࡳࡓࡵࡴࡔࡪࡲࡻࠧ৶"):l1l11l1l11.l1ll1ll11l}
    except Exception as e:
        logger.exception(l1ll (u"ࠥࡇࡷ࡫ࡡࡵࡧࠣࡱࡧࡵࡸࠡࡧࡱࡨࡪࡪࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠧ৷"))
    return result
if __name__ == l1ll (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ৸"):
    l11lllll1 = l1l1l1ll1()
    message= l1ll (u"ࠧࡋࡲࡰࡴࡵࠤࡎࠦࡡ࡮ࠢࡹࡩࡷࡿࠠ࡭ࡱࡱ࡫ࠥ࡫࡬ࡦ࡯ࡨࡲࡹࠨ৹")
    l1ll11llll = l1ll (u"ࠨࡔࡩࡧࠣࡀࡧࡄࡳࡩࡱࡺࠬ࠮ࡂ࠯ࡣࡀࠣࡱࡪࡺࡨࡰࡦࠣࡠࡳࡩࡡࡶࡵࡨࡷࠥࡧࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡱࠣࡦࡪࠦࡤࡪࡵࡳࡰࡦࡿࡥࡥࠢࡤࡷࠥࡹ࡯ࡰࡰࠣࡥࡸࠦࡰࡳࡣࡦࡸ࡮ࡩࡡ࡭࠰ࠣࡅࡳࡿࠠࡸ࡫ࡧ࡫ࡪࡺࠠࡵࡪࡤࡸࠥ࡯ࡳ࡯ࠩࡷࠤࡸ࡮࡯ࡸࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡹࡣࡳࡧࡨࡲ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡷࡪࡦࡪࡩࡹࡹࠠࡪࡰࠣࡥࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠭ࠢ࡬ࡸࠬࡹࠠࡦࡣࡶ࡭ࡪࡸࠠࡵࡱࠣࡧࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡹࡨࡰࡹࡢࡥࡱࡲࠨࠪࠢࡲࡲࠥࡺࡨࡦࠢࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠱ࠦࡩ࡯ࡵࡷࡩࡦࡪࠠࡰࡨࠣ࡭ࡳࡪࡩࡷ࡫ࡧࡹࡦࡲ࡬ࡺࠢࡶ࡬ࡴࡽࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡸ࡫ࡧ࡫ࡪࡺࡳ࠯ࠢࡒࡪࠥࡩ࡯ࡶࡴࡶࡩࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡶ࡫ࡩࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡴࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡡࠡࡹ࡬ࡨ࡬࡫ࡴ࠭ࠢࡤࡷࠥࡽࡥ࡭࡮ࠣࡥࡸࠦࡴࡩࡧࠣࡻ࡮ࡪࡧࡦࡶࠣ࡭ࡹࡹࡥ࡭ࡨ࠯ࠤࡧ࡫ࡦࡰࡴࡨࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠥࡧࡰࡱࡧࡤࡶࠥࡵ࡮ࡴࡥࡵࡩࡪࡴ࠮࡙ࠡ࡫ࡩࡳࠦࡡࠡࡶࡲࡴࡱ࡫ࡶࡦ࡮ࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡩࡴࠢࡶ࡬ࡴࡽ࡮࠭ࠢ࡬ࡸࠥ࡯ࡳࠡ࡫ࡰࡱࡪࡪࡩࡢࡶࡨࡰࡾࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࡀࠦ࡯ࡵࡪࡨࡶࠥࡹࡨࡰࡹࡱࠤࡼ࡯ࡤࡨࡧࡷࡷࠥࡧࡲࡦࠢࡵࡩࡦࡲࡩࡻࡧࡧࠤࡦࡴࡤࠡ࡯ࡤࡴࡵ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡴࡩࡧ࡬ࡶࠥࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠣ࡭ࡸࠦࡲࡦࡣ࡯࡭ࡿ࡫ࡤࠡࡣࡱࡨࠥࡳࡡࡱࡲࡨࡨࠧ৺")
    l11lllll1.l1l1ll1ll(message, l1ll (u"ࠢࡵ࡫ࡷࡰࡪࠨ৻"), l1ll111ll=True, l1ll11l11l=l1ll11llll)