#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1lll1l1 = sys.version_info [0] == 2
l1l1111 = 2048
l1ll1l1l = 7
def l1ll1 (l11l1l1):
    global l1lll11
    l111l11 = ord (l11l1l1 [-1])
    l1111l1 = l11l1l1 [:-1]
    l1l1ll = l111l11 % len (l1111l1)
    l1l1l1 = l1111l1 [:l1l1ll] + l1111l1 [l1l1ll:]
    if l1lll1l1:
        l1111l = l11ll11 () .join ([unichr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    else:
        l1111l = str () .join ([chr (ord (char) - l1l1111 - (l1l11ll + l111l11) % l1ll1l1l) for l1l11ll, char in enumerate (l1l1l1)])
    return eval (l1111l)
import logging
import os
import re
from l1ll1lll import l11111ll
logger = logging.getLogger(l1ll1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l11l111(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1ll1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l11():
    try:
        out = os.popen(l1ll1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1ll1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1ll1 (u"ࠢࠣॶ").join(result)
                logger.info(l1ll1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1ll1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1ll1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1ll1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l11111ll(l1ll1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1ll1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l11l111(l1ll1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))