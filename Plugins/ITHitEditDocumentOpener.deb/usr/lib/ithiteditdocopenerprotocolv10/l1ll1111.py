#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l11l = sys.version_info [0] == 2
l11l = 2048
l1111l1 = 7
def l11l1 (l1llll11):
    global l11l11l
    l1l1l1l = ord (l1llll11 [-1])
    l1llll1l = l1llll11 [:-1]
    l111ll = l1l1l1l % len (l1llll1l)
    l1l11 = l1llll1l [:l111ll] + l1llll1l [l111ll:]
    if l1l11l:
        l11ll1l = l1111 () .join ([unichr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l11l - (l111l1 + l1l1l1l) % l1111l1) for l111l1, char in enumerate (l1l11)])
    return eval (l11ll1l)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1ll1l import l1l1ll
from configobj import ConfigObj
l1l1l111 = l11l1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l11llll1 = l11l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠴࠳࠱࠴ࠧࡢ")
l1l1llll = l11l1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l11l1 (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠳࠲࠰࠳ࠦࡤ")
l1l11ll1=os.path.join(os.environ.get(l11l1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l11l1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l1llll.replace(l11l1 (u"ࠤࠣࠦࡧ"), l11l1 (u"ࠥࡣࠧࡨ")).lower())
l1l11l1l=os.environ.get(l11l1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l11l1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l1l1l1=l11llll1.replace(l11l1 (u"ࠨࠠࠣ࡫"), l11l1 (u"ࠢࡠࠤ࡬"))+l11l1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l11l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l11lll11=os.path.join(os.environ.get(l11l1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l1l1l1)
elif platform.system() == l11l1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11ll11l=l1l1ll(l1l11ll1+l11l1 (u"ࠧ࠵ࠢࡱ"))
    l11lll11 = os.path.join(l11ll11l, l1l1l1l1)
else:
    l11lll11 = os.path.join( l1l1l1l1)
l1l11l1l=l1l11l1l.upper()
if l1l11l1l == l11l1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11lll1l=logging.DEBUG
elif l1l11l1l == l11l1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11lll1l = logging.INFO
elif l1l11l1l == l11l1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11lll1l = logging.WARNING
elif l1l11l1l == l11l1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11lll1l = logging.ERROR
elif l1l11l1l == l11l1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11lll1l = logging.CRITICAL
elif l1l11l1l == l11l1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11lll1l = logging.NOTSET
logger = logging.getLogger(l11l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11lll1l)
l1l1l11l = logging.FileHandler(l11lll11, mode=l11l1 (u"ࠨࡷࠬࠤࡹ"))
l1l1l11l.setLevel(l11lll1l)
formatter = logging.Formatter(l11l1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l11l1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l1l11l.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll1l)
l1l111l1 = SysLogHandler(address=l11l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l111l1.setFormatter(formatter)
logger.addHandler(l1l1l11l)
logger.addHandler(ch)
logger.addHandler(l1l111l1)
class Settings():
    l11ll1l1 = l11l1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l11ll1ll = l11l1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l1l1ll1l = l11l1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l11llll1):
        self.l1l1111l = self._11lllll(l11llll1)
        self._1l11l11()
    def _11lllll(self, l11llll1):
        l1l1lll1 = l11llll1.split(l11l1 (u"ࠨࠠࠣࢀ"))
        l1l1lll1 = l11l1 (u"ࠢࠡࠤࢁ").join(l1l1lll1)
        if platform.system() == l11l1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l1111l = os.path.join(l1l11ll1, l11l1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1l1lll1 + l11l1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l1111l
    def l1ll111l(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l1l1ll11(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l11l1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l11l1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11111(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _1l11l11(self):
        if not os.path.exists(os.path.dirname(self.l1l1111l)):
            os.makedirs(os.path.dirname(self.l1l1111l))
        if not os.path.exists(self.l1l1111l):
            self.config = ConfigObj(self.l1l1111l)
            self.config[l11l1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l11l1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l11l1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l1l1ll1l
            self.config[l11l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l11l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l11l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l11ll1ll
            self.config[l11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l11l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l11ll1l1
            self.config[l11l1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l1111l)
            self.l1l1ll1l = self.get_value(l11l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l11l1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l11ll1ll = self.get_value(l11l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l11l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l11ll1l1 = self.get_value(l11l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l11l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1l1ll(self):
        l1l111ll = l11l1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l11ll1l1
        l1l111ll += l11l1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l11ll1ll
        l1l111ll += l11l1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l1l1ll1l
        return l1l111ll
    def __unicode__(self):
        return self._1l1l1ll()
    def __str__(self):
        return self._1l1l1ll()
    def __del__(self):
        self.config.write()
l1l11lll = Settings(l11llll1)