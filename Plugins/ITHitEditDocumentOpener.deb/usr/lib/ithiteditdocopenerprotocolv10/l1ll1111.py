#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll111 = sys.version_info [0] == 2
l1lll11 = 2048
l1l1ll1 = 7
def l111lll (l11):
    global l111l1
    l1ll1l1 = ord (l11 [-1])
    l1lllll1 = l11 [:-1]
    l1l1111 = l1ll1l1 % len (l1lllll1)
    l1l11ll = l1lllll1 [:l1l1111] + l1lllll1 [l1l1111:]
    if l1ll111:
        l1ll11l1 = l1l11l1 () .join ([unichr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    else:
        l1ll11l1 = str () .join ([chr (ord (char) - l1lll11 - (l1ll11 + l1ll1l1) % l1l1ll1) for l1ll11, char in enumerate (l1l11ll)])
    return eval (l1ll11l1)
import hashlib
import os
import l1lll11l
from l1ll11l import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1lll11l import l1l111l
from l1ll1l1l import l11l1, l1l1l1l
import logging
logger = logging.getLogger(l111lll (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l1l1():
    def __init__(self, l1ll111l,l111, l1ll1lll= None, l1ll1l11=None):
        self.l1llll1=False
        self.l11lll1 = self._11l()
        self.l111 = l111
        self.l1ll1lll = l1ll1lll
        self.l11ll11 = l1ll111l
        if l1ll1lll:
            self.l1lll1ll = True
        else:
            self.l1lll1ll = False
        self.l1ll1l11 = l1ll1l11
    def _11l(self):
        try:
            return l1lll11l.l11llll() is not None
        except:
            return False
    def open(self):
        l111lll (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l11lll1:
            raise NotImplementedError(l111lll (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111lll (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1l1lll = self.l11ll11
        if self.l111.lower().startswith(self.l11ll11.lower()):
            l1lll = re.compile(re.escape(self.l11ll11), re.IGNORECASE)
            l111 = l1lll.sub(l111lll (u"ࠨࠩࠄ"), self.l111)
            l111 = l111.replace(l111lll (u"ࠩࡧࡥࡻ࠭ࠅ"), l111lll (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l1ll1ll(self.l11ll11, l1l1lll, l111, self.l1ll1lll)
    def l1ll1ll(self,l11ll11, l1l1lll, l111, l1ll1lll):
        l111lll (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111lll (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1ll1 = l1l1ll(l11ll11)
        l1l11 = self.l11l11(l1ll1)
        logger.info(l111lll (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1ll1)
        if l1l11:
            logger.info(l111lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l1l111l(l1ll1)
            l1ll1 = l1(l11ll11, l1l1lll, l1ll1lll, self.l1ll1l11)
        logger.debug(l111lll (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1lll1l=l1ll1 + l111lll (u"ࠤ࠲ࠦࠌ") + l111
        l111l = l111lll (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1lll1l+ l111lll (u"ࠫࠧ࠭ࠎ")
        logger.debug(l111l)
        l1111l = os.system(l111l)
        if (l1111l != 0):
            raise IOError(l111lll (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1lll1l, l1111l))
    def l11l11(self, l1ll1):
        if os.path.exists(l1ll1):
            if os.path.islink(l1ll1):
                l1ll1 = os.readlink(l1ll1)
            if os.path.ismount(l1ll1):
                return True
        return False
def l1l1ll(l11ll11):
    l1l = l11ll11.replace(l111lll (u"࠭࡜࡝ࠩࠐ"), l111lll (u"ࠧࡠࠩࠑ")).replace(l111lll (u"ࠨ࠱ࠪࠒ"), l111lll (u"ࠩࡢࠫࠓ"))
    l1ll1ll1 = l111lll (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l1lllll=os.environ[l111lll (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll1l=os.path.join(l1lllll,l1ll1ll1, l1l)
    l1llllll=os.path.abspath(l1ll1l)
    return l1llllll
def l111l11(l1111ll):
    if not os.path.exists(l1111ll):
        os.makedirs(l1111ll)
def l111111(l11ll11, l1l1lll, l11lll=None, password=None):
    l111lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1111ll = l1l1ll(l11ll11)
    l111l11(l1111ll)
    if not l11lll:
        l11111l = l1l1()
        l1ll11ll =l11111l.ll(l111lll (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1l1lll + l111lll (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1l1lll + l111lll (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1ll11ll, str):
            l11lll, password = l1ll11ll
        else:
            raise l1l1l1l()
        logger.info(l111lll (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1111ll))
    l1ll = pwd.getpwuid( os.getuid())[0]
    l111l1l=os.environ[l111lll (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1lll1l1=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1llll1l={l111lll (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l1ll, l111lll (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l11ll11, l111lll (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1111ll, l111lll (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l111l1l, l111lll (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l11lll, l111lll (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1llll1l, temp_file)
        if not os.path.exists(os.path.join(l1lll1l1, l111lll (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l11l11l=l111lll (u"ࠦࡵࡿࠢࠣ")
            key=l111lll (u"ࠧࠨࠤ")
        else:
            l11l11l=l111lll (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111lll (u"ࠢ࠮ࡑࠣࠦࠦ")
        l11ll1=l111lll (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l11l11l,temp_file.name)
        l111ll=[l111lll (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111lll (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1lll1l1, l11ll1)]
        p = subprocess.Popen(l111ll, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111lll (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111lll (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111lll (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1111ll
    logger.debug(l111lll (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111lll (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1llllll=os.path.abspath(l1111ll)
    logger.debug(l111lll (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1llllll)
    return l1llllll
def l1(l11ll11, l1l1lll, l1ll1lll, l1ll1l11):
    l111lll (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1111(title):
        l1l1l11=30
        if len(title)>l1l1l11:
            l11ll=title.split(l111lll (u"ࠨ࠯ࠣ࠳"))
            l1lll1=l111lll (u"ࠧࠨ࠴")
            for block in l11ll:
                l1lll1+=block+l111lll (u"ࠣ࠱ࠥ࠵")
                if len(l1lll1) > l1l1l11:
                    l1lll1+=l111lll (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l1lll1
        return title
    def l1llll(l111ll1, password):
        l111lll (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111lll (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111lll (u"ࠧࠦࠢ࠹").join(l111ll1)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l11l111 = l111lll (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l11l111.encode())
        l11ll1l = [l111lll (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l11l1ll = l111lll (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l11l1ll)
            for e in l11ll1l:
                if e in l11l1ll: return False
            raise l11l1(l11l1ll, l1=l1lll11l.l11llll(), l1l1lll=l1l1lll)
        logger.info(l111lll (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l11lll = l111lll (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111lll (u"ࠦࠧ࠿")
    os.system(l111lll (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l1l = l1l1ll(l11ll11)
    l1111ll = l1l1ll(hashlib.sha1(l11ll11.encode()).hexdigest()[:10])
    l111l11(l1111ll)
    logger.info(l111lll (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1111ll))
    if l1ll1lll:
        l111ll1 = [l111lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111lll (u"ࠤ࠰ࡸࠧࡄ"), l111lll (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111lll (u"ࠫ࠲ࡵࠧࡆ"), l111lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l11lll, l1ll1lll),
                    urllib.parse.unquote(l1l1lll), os.path.abspath(l1111ll)]
        l1llll(l111ll1, password)
    else:
        while True:
            l11lll, password = l1l1l1(l1111ll, l1l1lll, l1ll1l11)
            if l11lll.lower() != l111lll (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l111ll1 = [l111lll (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111lll (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111lll (u"ࠤ࠰ࡸࠧࡋ"), l111lll (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111lll (u"ࠫ࠲ࡵࠧࡍ"), l111lll (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l11lll,
                            urllib.parse.unquote(l1l1lll), os.path.abspath(l1111ll)]
            else:
                raise l1l1l1l()
            if l1llll(l111ll1, password): break
    os.system(l111lll (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1111ll, l1l1l))
    l1llllll=os.path.abspath(l1l1l)
    return l1llllll
def l1l1l1(l11ll11, l1l1lll, l1ll1l11):
    l1111l1 = os.path.join(os.environ[l111lll (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1111l1)):
       os.makedirs(os.path.dirname(l1111l1))
    l1lll111 = l1ll1l11.get_value(l111lll (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111lll (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l11111l = l1l1(l11ll11, l1lll111)
    l11lll, password = l11111l.ll(l111lll (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1l1lll + l111lll (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1l1lll + l111lll (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l11lll != l111lll (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l1l111(l11ll11, l11lll):
        l11111 = l111lll (u"ࠤ࡙ࠣࠦ").join([l11ll11, l11lll, l111lll (u"࡚ࠪࠦࠬ") + password + l111lll (u"࡛ࠫࠧ࠭"), l111lll (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1111l1, l111lll (u"࠭ࡷࠬࠩ࡝")) as l11l1l:
            l11l1l.write(l11111)
        os.chmod(l1111l1, 0o600)
    return l11lll, password
def l1l111(l11ll11, l11lll):
    l1111l1 = l1l11l = os.path.join(os.environ[l111lll (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111lll (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111lll (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1111l1):
        with open(l1111l1, l111lll (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l1llll11 = data[0].split(l111lll (u"ࠦࠥࠨࡢ"))
            if l11ll11 == l1llll11[0] and l11lll == l1llll11[1]:
                return True
    return False