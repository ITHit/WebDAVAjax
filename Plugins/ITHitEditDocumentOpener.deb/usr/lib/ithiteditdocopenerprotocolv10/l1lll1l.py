#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1ll = sys.version_info [0] == 2
l11l = 2048
l1l1l11 = 7
def l111l11 (l1ll):
    global l11lll
    l1ll1l1l = ord (l1ll [-1])
    l11ll1l = l1ll [:-1]
    l1l1 = l1ll1l1l % len (l11ll1l)
    l11l1ll = l11ll1l [:l1l1] + l11ll1l [l1l1:]
    if l1ll1ll:
        l1l11l1 = l1ll1ll1 () .join ([unichr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    else:
        l1l11l1 = str () .join ([chr (ord (char) - l11l - (l1l1lll + l1ll1l1l) % l1l1l11) for l1l1lll, char in enumerate (l11l1ll)])
    return eval (l1l11l1)
import re
class l111ll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lllll11 = kwargs.get(l111l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1ll11l = kwargs.get(l111l11 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111ll1 = self.l1llll111(args)
        if l1111ll1:
            args=args+ l1111ll1
        self.args = [a for a in args]
    def l1llll111(self, *args):
        l1111ll1=None
        l1l1ll11 = args[0][0]
        if re.search(l111l11 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l1ll11):
            l1111ll1 = (l111l11 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1lllll11
                            ,)
        return l1111ll1
class l1lll1lll(Exception):
    def __init__(self, *args, **kwargs):
        l1111ll1 = self.l1llll111(args)
        if l1111ll1:
            args = args + l1111ll1
        self.args = [a for a in args]
    def l1llll111(self, *args):
        s = l111l11 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l111l11 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1111l11(Exception):
    pass
class l1lll11(Exception):
    pass
class l1llll1l1(Exception):
    def __init__(self, message, l1llllll1, url):
        super(l1llll1l1,self).__init__(message)
        self.l1llllll1 = l1llllll1
        self.url = url
class l11111ll(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1111111(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1111l1l(Exception):
    pass
class l11111l1(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l111111l(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l11l1l11(Exception):
    pass