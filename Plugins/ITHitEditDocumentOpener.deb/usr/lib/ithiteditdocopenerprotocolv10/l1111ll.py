#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1llll11 = sys.version_info [0] == 2
l1llll1 = 2048
l11ll = 7
def l1l1ll1 (l11l1l):
    global l1111l1
    l1lllll1 = ord (l11l1l [-1])
    l11llll = l11l1l [:-1]
    l1ll1l11 = l1lllll1 % len (l11llll)
    l1ll1lll = l11llll [:l1ll1l11] + l11llll [l1ll1l11:]
    if l1llll11:
        l1l1l = l11 () .join ([unichr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    else:
        l1l1l = str () .join ([chr (ord (char) - l1llll1 - (l11l111 + l1lllll1) % l11ll) for l11l111, char in enumerate (l1ll1lll)])
    return eval (l1l1l)
import re
class l1l11l(Exception):
    def __init__(self, *args,**kwargs):
        self.l111111l = kwargs.get(l1l1ll1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11lll = kwargs.get(l1l1ll1 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111111 = self.l1llll1l1(args)
        if l1111111:
            args=args+ l1111111
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        l1111111=None
        l1l1l111 = args[0][0]
        if re.search(l1l1ll1 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l1l111):
            l1111111 = (l1l1ll1 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l111111l
                            ,)
        return l1111111
class l1111ll1(Exception):
    def __init__(self, *args, **kwargs):
        l1111111 = self.l1llll1l1(args)
        if l1111111:
            args = args + l1111111
        self.args = [a for a in args]
    def l1llll1l1(self, *args):
        s = l1l1ll1 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1l1ll1 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1llll111(Exception):
    pass
class l1l1l1l(Exception):
    pass
class l1lll1l1l(Exception):
    def __init__(self, message, l11111l1, url):
        super(l1lll1l1l,self).__init__(message)
        self.l11111l1 = l11111l1
        self.url = url
class l1lllll1l(Exception):
    pass
class l1111l1l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1111l11(Exception):
    pass
class l111l11l(Exception):
    pass