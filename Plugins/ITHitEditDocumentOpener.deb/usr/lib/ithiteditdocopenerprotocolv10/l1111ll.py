#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll1l = sys.version_info [0] == 2
l111lll = 2048
l1lll11 = 7
def l1l1l11 (l1l11):
    global l111l
    l1ll1l11 = ord (l1l11 [-1])
    l11l = l1l11 [:-1]
    l1lll = l1ll1l11 % len (l11l)
    l1lll11l = l11l [:l1lll] + l11l [l1lll:]
    if l1ll1l:
        l11ll1l = l1llll1l () .join ([unichr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    else:
        l11ll1l = str () .join ([chr (ord (char) - l111lll - (l1ll111 + l1ll1l11) % l1lll11) for l1ll111, char in enumerate (l1lll11l)])
    return eval (l11ll1l)
import re
class l1lllll1(Exception):
    def __init__(self, *args,**kwargs):
        self.l1lll1ll1 = kwargs.get(l1l1l11 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l11l11l = kwargs.get(l1l1l11 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1111ll1 = self.l111111l(args)
        if l1111ll1:
            args=args+ l1111ll1
        self.args = [a for a in args]
    def l111111l(self, *args):
        l1111ll1=None
        l1l11l11 = args[0][0]
        if re.search(l1l1l11 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l11l11):
            l1111ll1 = (l1l1l11 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1lll1ll1
                            ,)
        return l1111ll1
class l11111l1(Exception):
    def __init__(self, *args, **kwargs):
        l1111ll1 = self.l111111l(args)
        if l1111ll1:
            args = args + l1111ll1
        self.args = [a for a in args]
    def l111111l(self, *args):
        s = l1l1l11 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1l1l11 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1111l11(Exception):
    pass
class l1lll1l(Exception):
    pass
class l1111l1l(Exception):
    def __init__(self, message, l1lllll11, url):
        super(l1111l1l,self).__init__(message)
        self.l1lllll11 = l1lllll11
        self.url = url
class l1llll1l1(Exception):
    pass
class l1llllll1(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1llll111(Exception):
    pass
class l1lllllll(Exception):
    pass
class l1llll11l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1lll1l1l(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1111111(Exception):
    pass
class l11111ll(Exception):
    pass
class l11l1l1l(Exception):
    pass