#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1111 = sys.version_info [0] == 2
l1l1l = 2048
l1ll1111 = 7
def l111l (l1lll1l1):
    global l111ll
    l1ll11ll = ord (l1lll1l1 [-1])
    l1lll11 = l1lll1l1 [:-1]
    l1 = l1ll11ll % len (l1lll11)
    l111l1l = l1lll11 [:l1] + l1lll11 [l1:]
    if l1111:
        l1l111 = l11ll1l () .join ([unichr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    else:
        l1l111 = str () .join ([chr (ord (char) - l1l1l - (l1l11 + l1ll11ll) % l1ll1111) for l1l11, char in enumerate (l111l1l)])
    return eval (l1l111)
import hashlib
import os
import l1ll11l1
from l11l11 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1ll11l1 import l111l1
from l1lllll1 import l11111, l1l1111
import logging
logger = logging.getLogger(l111l (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l1llll1l():
    def __init__(self, l1ll,l1l1ll, l1ll1lll= None, l1llll1=None):
        self.l11l1l=False
        self.l1l11l = self._1l()
        self.l1l1ll = l1l1ll
        self.l1ll1lll = l1ll1lll
        self.l1l1l11 = l1ll
        if l1ll1lll:
            self.l1l1ll1 = True
        else:
            self.l1l1ll1 = False
        self.l1llll1 = l1llll1
    def _1l(self):
        try:
            return l1ll11l1.l1l11ll() is not None
        except:
            return False
    def open(self):
        l111l (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l11l:
            raise NotImplementedError(l111l (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l111l (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1llll = self.l1l1l11
        if self.l1l1ll.lower().startswith(self.l1l1l11.lower()):
            l11ll = re.compile(re.escape(self.l1l1l11), re.IGNORECASE)
            l1l1ll = l11ll.sub(l111l (u"ࠨࠩࠄ"), self.l1l1ll)
            l1l1ll = l1l1ll.replace(l111l (u"ࠩࡧࡥࡻ࠭ࠅ"), l111l (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l11(self.l1l1l11, l1llll, l1l1ll, self.l1ll1lll)
    def l11(self,l1l1l11, l1llll, l1l1ll, l1ll1lll):
        l111l (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l111l (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l1l1 = l11l11l(l1l1l11)
        l1111l = self.l1ll1l1(l1l1)
        logger.info(l111l (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l1l1)
        if l1111l:
            logger.info(l111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l111l1(l1l1)
            l1l1 = l111111(l1l1l11, l1llll, l1ll1lll, self.l1llll1)
        logger.debug(l111l (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll1=l1l1 + l111l (u"ࠤ࠲ࠦࠌ") + l1l1ll
        l11ll1 = l111l (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll1+ l111l (u"ࠫࠧ࠭ࠎ")
        logger.debug(l11ll1)
        l1lll11l = os.system(l11ll1)
        if (l1lll11l != 0):
            raise IOError(l111l (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll1, l1lll11l))
    def l1ll1l1(self, l1l1):
        if os.path.exists(l1l1):
            if os.path.islink(l1l1):
                l1l1 = os.readlink(l1l1)
            if os.path.ismount(l1l1):
                return True
        return False
def l11l11l(l1l1l11):
    l1llll11 = l1l1l11.replace(l111l (u"࠭࡜࡝ࠩࠐ"), l111l (u"ࠧࡠࠩࠑ")).replace(l111l (u"ࠨ࠱ࠪࠒ"), l111l (u"ࠩࡢࠫࠓ"))
    l1ll111 = l111l (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l11111l=os.environ[l111l (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l11l111=os.path.join(l11111l,l1ll111, l1llll11)
    l1ll1ll=os.path.abspath(l11l111)
    return l1ll1ll
def ll(l1llllll):
    if not os.path.exists(l1llllll):
        os.makedirs(l1llllll)
def l1111l1(l1l1l11, l1llll, l1ll1ll1=None, password=None):
    l111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l1llllll = l11l11l(l1l1l11)
    ll(l1llllll)
    if not l1ll1ll1:
        l1l11l1 = l111lll()
        l1lllll =l1l11l1.l1ll11(l111l (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1llll + l111l (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1llll + l111l (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1lllll, str):
            l1ll1ll1, password = l1lllll
        else:
            raise l1l1111()
        logger.info(l111l (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l1llllll))
    l11lll1 = pwd.getpwuid( os.getuid())[0]
    l1lll1l=os.environ[l111l (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1ll1l11=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l11l={l111l (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11lll1, l111l (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1l11, l111l (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l1llllll, l111l (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1lll1l, l111l (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l1ll1ll1, l111l (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l11l, temp_file)
        if not os.path.exists(os.path.join(l1ll1l11, l111l (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111l11=l111l (u"ࠦࡵࡿࠢࠣ")
            key=l111l (u"ࠧࠨࠤ")
        else:
            l111l11=l111l (u"ࠨࡰࡺࡱࠥࠥ")
            key=l111l (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lll=l111l (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111l11,temp_file.name)
        l1ll1l=[l111l (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l111l (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1ll1l11, l1lll)]
        p = subprocess.Popen(l1ll1l, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l111l (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l111l (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l111l (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l1llllll
    logger.debug(l111l (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l111l (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l1ll1ll=os.path.abspath(l1llllll)
    logger.debug(l111l (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l1ll1ll)
    return l1ll1ll
def l111111(l1l1l11, l1llll, l1ll1lll, l1llll1):
    l111l (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l11l1(title):
        l1ll111l=30
        if len(title)>l1ll111l:
            l11ll11=title.split(l111l (u"ࠨ࠯ࠣ࠳"))
            l11lll=l111l (u"ࠧࠨ࠴")
            for block in l11ll11:
                l11lll+=block+l111l (u"ࠣ࠱ࠥ࠵")
                if len(l11lll) > l1ll111l:
                    l11lll+=l111l (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11lll
        return title
    def l1l1lll(l11llll, password):
        l111l (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡅࡱ࡬ࡲ࡬ࠦ࡭ࡰࡷࡱࡸࠥࡻࡳࡪࡰࡪࠤࡨࡳࡤࠡࡣࡱࡨࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤ࡙ࡸࡵࡦࠢ࡬ࡪࠥࡳ࡯ࡶࡰࡷࠤ࡮ࡹࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯࠰ࠥࡌࡡ࡭ࡵࡨࠤ࡮࡬ࠠࡸࡧࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡷ࡭ࡵࡷࠡࡦ࡬ࡥࡱࡵࡧࠡࡱࡱࡧࡪࠦ࡭ࡰࡴࡨࠤࡦࡴࡤࠡࡴࡨࡸࡷࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡥ࡮ࡹࡥ࠻ࠢࡐࡳࡺࡴࡴࡆࡴࡵࡳࡷࠦࡩࡧࠢࡰࡳࡺࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡣࡱࡨࠥ࡫ࡲࡳࡱࡵࠤࡳࡵࡴࠡࡴࡨࡰࡦࡺࡥࡥࠢࡷࡳࠥࡻࡳࡦࡴࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧ࠷")
        logger.info(l111l (u"ࠦࡒࡵࡵ࡯ࡶࠣࡻ࡮ࡺࡨࠡࡥࡲࡱࡲࡧ࡮ࡥ࠼ࠥ࠸"))
        cmd = l111l (u"ࠧࠦࠢ࠹").join(l11llll)
        logger.info(cmd)
        proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        l1ll1l1l = l111l (u"ࠨࠥࡴ࡞ࡱࠦ࠺") % password
        out, err = proc.communicate(l1ll1l1l.encode())
        l1l111l = [l111l (u"ࠧࡄࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡦࠢࡷࡳࠥࡹࡥࡳࡸࡨࡶࠬ࠻")]
        if len(err) > 0:
            l1lll1 = l111l (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠪࡹࠢ࠼") % err.decode()
            logger.error(l1lll1)
            for e in l1l111l:
                if e in l1lll1: return False
            raise l11111(l1lll1, l111111=l1ll11l1.l1l11ll(), l1llll=l1llll)
        logger.info(l111l (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤࡸࡻࡣࡤࡧࡶࡷࠧ࠽"))
        return True
    l1ll1ll1 = l111l (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠾")
    password = l111l (u"ࠦࠧ࠿")
    os.system(l111l (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧࡀ"))
    l1l1l1 = l11l11l(l1l1l11)
    l1llllll = l11l11l(hashlib.sha1(l1l1l11.encode()).hexdigest()[:10])
    ll(l1llllll)
    logger.info(l111l (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥࡁ") + os.path.abspath(l1llllll))
    if l1ll1lll:
        l11llll = [l111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l111l (u"ࠤ࠰ࡸࠧࡄ"), l111l (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l111l (u"ࠫ࠲ࡵࠧࡆ"), l111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡇ") % (l1ll1ll1, l1ll1lll),
                    urllib.parse.unquote(l1llll), os.path.abspath(l1llllll)]
        l1l1lll(l11llll, password)
    else:
        while True:
            l1ll1ll1, password = l111(l1llllll, l1llll, l1llll1)
            if l1ll1ll1.lower() != l111l (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡈ"):
                l11llll = [l111l (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡉ"), l111l (u"ࠣ࡯ࡲࡹࡳࡺࠢࡊ"), l111l (u"ࠤ࠰ࡸࠧࡋ"), l111l (u"ࠪࡨࡦࡼࡦࡴࠩࡌ"), l111l (u"ࠫ࠲ࡵࠧࡍ"), l111l (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠦࠪࡹࠢࠨࡎ") %l1ll1ll1,
                            urllib.parse.unquote(l1llll), os.path.abspath(l1llllll)]
            else:
                raise l1l1111()
            if l1l1lll(l11llll, password): break
    os.system(l111l (u"࠭࡬࡯ࠢ࠰ࡷࠥࠨࠥࡴࠤࠣࠦࠪࡹࠢࠨࡏ") % (l1llllll, l1l1l1))
    l1ll1ll=os.path.abspath(l1l1l1)
    return l1ll1ll
def l111(l1l1l11, l1llll, l1llll1):
    l1lll1ll = os.path.join(os.environ[l111l (u"ࠢࡉࡑࡐࡉࠧࡐ")], l111l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤࡑ"), l111l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡒ"))
    if not os.path.exists(os.path.dirname(l1lll1ll)):
       os.makedirs(os.path.dirname(l1lll1ll))
    l11l1ll = l1llll1.get_value(l111l (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࡓ"), l111l (u"ࠫࡱࡧࡳࡵࡡ࡯ࡳ࡬࡯࡮ࡠࡰࡤࡱࡪ࠭ࡔ"))
    l1l11l1 = l111lll(l1l1l11, l11l1ll)
    l1ll1ll1, password = l1l11l1.l1ll11(l111l (u"ࠧࡖ࡬ࡦࡣࡶࡩࠥࡹࡰࡦࡥ࡬ࡪࡾࠦࡹࡰࡷࡵࠤࠧࡕ") + l1llll + l111l (u"ࠨࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠧࡖ"),
                                               l1llll + l111l (u"ࠢࠡࡅࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨࡗ"))
    if l1ll1ll1 != l111l (u"ࠨࡰࡲࡰࡴ࡭ࡩ࡯ࠩࡘ") and not l111ll1(l1l1l11, l1ll1ll1):
        l1l1l1l = l111l (u"ࠤ࡙ࠣࠦ").join([l1l1l11, l1ll1ll1, l111l (u"࡚ࠪࠦࠬ") + password + l111l (u"࡛ࠫࠧ࠭"), l111l (u"ࠬࡢ࡮ࠨ࡜")])
        with open(l1lll1ll, l111l (u"࠭ࡷࠬࠩ࡝")) as l1ll11l:
            l1ll11l.write(l1l1l1l)
        os.chmod(l1lll1ll, 0o600)
    return l1ll1ll1, password
def l111ll1(l1l1l11, l1ll1ll1):
    l1lll1ll = l1lll111 = os.path.join(os.environ[l111l (u"ࠢࡉࡑࡐࡉࠧ࡞")], l111l (u"ࠣ࠰ࡧࡥࡻ࡬ࡳ࠳ࠤ࡟"), l111l (u"ࠤࡶࡩࡨࡸࡥࡵࡵࠥࡠ"))
    if os.path.exists(l1lll1ll):
        with open(l1lll1ll, l111l (u"ࠥࡶࠧࡡ")) as f:
            data = f.readlines()
            l11l1l1 = data[0].split(l111l (u"ࠦࠥࠨࡢ"))
            if l1l1l11 == l11l1l1[0] and l1ll1ll1 == l11l1l1[1]:
                return True
    return False