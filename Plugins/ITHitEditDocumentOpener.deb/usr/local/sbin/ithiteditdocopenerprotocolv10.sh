#!/bin/bash

python -O /usr/lib/ithiteditdocopenerprotocolv10/document_opener.pyo "$@"

