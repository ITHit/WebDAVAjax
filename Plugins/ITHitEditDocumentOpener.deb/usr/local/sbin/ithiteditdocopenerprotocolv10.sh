#!/bin/bash

python3 /usr/lib/ithiteditdocopenerprotocolv10/document_opener.py "$@"

