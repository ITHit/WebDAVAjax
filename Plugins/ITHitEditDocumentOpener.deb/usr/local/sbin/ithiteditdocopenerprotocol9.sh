#!/bin/bash

python -O /usr/lib/ithiteditdocopenerprotocol9/document_opener.pyo "$@"

