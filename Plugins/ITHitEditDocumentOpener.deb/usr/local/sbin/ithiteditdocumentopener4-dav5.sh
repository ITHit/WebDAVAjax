#!/bin/bash

python -O /usr/lib/ithiteditdocumentopener4-dav5/document_opener.pyo "$@"

