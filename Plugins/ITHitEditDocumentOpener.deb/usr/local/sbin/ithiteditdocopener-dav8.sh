#!/bin/bash

python -O /usr/lib/ithiteditdocopener-dav8/document_opener.pyo "$@"

