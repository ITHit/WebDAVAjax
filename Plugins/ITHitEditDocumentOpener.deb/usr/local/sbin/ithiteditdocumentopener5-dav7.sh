#!/bin/bash

python -O /usr/lib/ithiteditdocumentopener5-dav7/document_opener.pyo "$@"

