#!/bin/bash

python -O /usr/lib/ithiteditdocopenerprotocol10/document_opener.pyo "$@"

