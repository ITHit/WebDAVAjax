#!/bin/bash

python -O /usr/lib/ithiteditdocopenerprotocol8/document_opener.pyo "$@"

