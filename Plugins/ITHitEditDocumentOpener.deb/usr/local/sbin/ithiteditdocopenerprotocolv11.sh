#!/bin/bash

python3 /usr/lib/ithiteditdocopenerprotocolv11/document_opener.py "$@"

