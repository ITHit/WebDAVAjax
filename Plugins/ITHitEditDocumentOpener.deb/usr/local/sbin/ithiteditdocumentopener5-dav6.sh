#!/bin/bash

python -O /usr/lib/ithiteditdocumentopener5-dav6/document_opener.pyo "$@"

